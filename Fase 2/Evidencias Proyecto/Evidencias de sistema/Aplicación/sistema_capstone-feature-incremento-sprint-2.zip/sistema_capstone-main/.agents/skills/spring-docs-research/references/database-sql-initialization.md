# Inicialización SQL previa a JPA

- **Fuente oficial:** [Spring Boot 3.2.5, §9.3](https://docs.spring.io/spring-boot/docs/3.2.5/reference/html/howto.html#howto.data-initialization.using-basic-sql-scripts).
- **Versión:** Spring Boot 3.2.5 / Java 21.
- **Fecha:** 2026-09-30.

## Resumen

Los scripts se ejecutan antes de JPA por defecto. PostgreSQL requiere `mode: always`. `schema-locations` selecciona el archivo. `defer-datasource-initialization: true` invierte ese orden. Los errores detienen el arranque salvo configuración contraria.

## Dependencias Maven

La infraestructura JDBC/JPA existente es suficiente.

## Configuración de referencia

```yaml
spring:
  sql:
    init:
      mode: always
      schema-locations: classpath:db/area-schema.sql
      continue-on-error: false
      encoding: UTF-8
      separator: "^^^ END OF SCRIPT ^^^"
  jpa:
    defer-datasource-initialization: false
```

## Aplicación al diseño de áreas

Implementado en `sistema-principal`: `db/area-schema.sql` es un único DO atómico para tabla nueva o existente. Inspecciona tipos, nombres inválidos y duplicados antes de modificar el catálogo; conserva IDs, relaciones, timestamps y precisión. La inspección local previa encontró una tabla vacía con timestamp con zona.

## Código Java

No requiere un inicializador Java adicional. El script se ejecuta por la inicialización SQL de Boot.

## Advertencias

La documentación recomienda un único mecanismo de inicialización. Mantener Hibernate `update` mientras un script gestiona áreas es una decisión transitoria del proyecto. `AreaSchemaFilterProvider.getMigrateFilter()` excluye solo la tabla `area` de `update` para que no altere los tipos históricos después del script. No ocultar errores ni mezclarlo con Flyway/Liquibase.

## Bloques DO y timestamps (referencias adquiridas 30-09-2026)

- [Spring Framework 6.1.6 ScriptUtils](https://docs.spring.io/spring-framework/docs/6.1.6/javadoc-api/org/springframework/jdbc/datasource/init/ScriptUtils.html): su separador virtual EOF ejecuta una sentencia completa sin dividirla por los puntos y comas internos. El script no debe contener literalmente el separador.
- [Hibernate 6.4 SchemaFilterProvider](https://docs.hibernate.org/orm/6.4/javadocs/org/hibernate/tool/schema/spi/SchemaFilterProvider.html) y [SchemaFilter](https://docs.hibernate.org/orm/6.4/javadocs/org/hibernate/tool/schema/spi/SchemaFilter.html): permiten limitar tablas por operación. Se configura con `hibernate.hbm2ddl.schema_filter_provider`; crear/borrar/validar conservan los filtros normales, migrar excluye `area`.
- [Descriptor UTC de Hibernate 6.4.4](https://github.com/hibernate/hibernate-orm/blob/6.4.4/hibernate-core/src/main/java/org/hibernate/type/descriptor/jdbc/TimestampUtcAsJdbcTimestampJdbcType.java): usa `setTimestamp/getTimestamp` con calendario UTC. `@JdbcType(TimestampUtcAsJdbcTimestampJdbcType.class)` en las dos fechas de `Area` evita exigir `OffsetDateTime` a una columna legacy sin zona y no convierte su tipo SQL.

No se atribuye una zona histórica desconocida a datos legacy: se conserva la columna y sus valores. Para representarlos como `Instant`, la lectura de timestamps sin zona usa UTC como convención explícita del contrato; si esos valores se grabaron en otra zona, su interpretación requiere revisión del equipo.
