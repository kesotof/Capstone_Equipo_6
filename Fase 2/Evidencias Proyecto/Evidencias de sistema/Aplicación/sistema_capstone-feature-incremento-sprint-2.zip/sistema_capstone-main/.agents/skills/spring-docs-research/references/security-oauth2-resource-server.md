# Spring Security 6.2 - OAuth2 Resource Server con Keycloak JWT

- **Fuente Oficial**: https://docs.spring.io/spring-security/reference/6.2/servlet/oauth2/resource-server/jwt.html
- **Versión de Referencia**: Spring Boot 3.2.x / Spring Security 6.2.x / Java 21
- **Fecha de Adquisición**: 2026-09-11

---

## Resumen Conceptual

En Spring Security 6 (incluido en Spring Boot 3), las APIs han sido modernizadas completamente hacia un enfoque funcional basado en lambdas (`HttpSecurity.authorizeHttpRequests(Customizer)`). `WebSecurityConfigurerAdapter` está eliminado.
Como Resource Server, la aplicación no maneja sesiones de usuario (`SessionCreationPolicy.STATELESS`); en su lugar, valida el token Bearer JWT enviado en el header `Authorization`.

---

## Dependencias Maven (`pom.xml`)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-resource-server</artifactId>
</dependency>
```

---

## Configuración en `application.yml`

Para validar JWT emitidos por Keycloak, se recomienda configurar `jwk-set-uri` o `issuer-uri`:

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          # Para validar firmas usando las claves públicas de Keycloak
          jwk-set-uri: ${KEYCLOAK_AUTH_SERVER_URL:http://localhost:8080}/realms/${KEYCLOAK_REALM:capstone-realm}/protocol/openid-connect/certs
          # Opcional (si se requiere validar iss explícitamente):
          issuer-uri: ${KEYCLOAK_AUTH_SERVER_URL:http://localhost:8080}/realms/${KEYCLOAK_REALM:capstone-realm}
```

> **Consejo de Resiliencia en Docker**: Usar `jwk-set-uri` en lugar de `issuer-uri` evita que Spring Boot intente conectarse de forma síncrona y bloqueante durante el arranque del contexto (OpenID Discovery), tolerando inicios lentos de Keycloak.

---

## Extracción de Roles de Keycloak para RBAC (`JwtAuthenticationConverter`)

Keycloak coloca los roles en claims anidados (`realm_access.roles` o `resource_access.<client>.roles`). Para que `@PreAuthorize("hasRole('ADMIN')")` funcione en Spring Security, se debe registrar un convertidor de autoridades:

```java
package com.capstone.sistema.auth;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class KeycloakJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        Collection<GrantedAuthority> authorities = extractRealmRoles(jwt);
        return new JwtAuthenticationToken(jwt, authorities, jwt.getClaimAsString("preferred_username"));
    }

    @SuppressWarnings("unchecked")
    private Collection<GrantedAuthority> extractRealmRoles(Jwt jwt) {
        Map<String, Object> realmAccess = jwt.getClaim("realm_access");
        if (realmAccess == null || realmAccess.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> roles = (List<String>) realmAccess.get("roles");
        if (roles == null) {
            return Collections.emptyList();
        }
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                .collect(Collectors.toList());
    }
}
```

---

## Configuración de Seguridad (`SecurityConfig.java`)

```java
package com.capstone.sistema.auth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/**", "/api/public/**", "/error").permitAll()
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(new KeycloakJwtAuthenticationConverter()))
            );

        return http.build();
    }
}
```

---

## Validación de cuenta local por cada JWT

Además de validar firma, emisor y vigencia del JWT, una aplicación puede usar un
`Converter<Jwt, AbstractAuthenticationToken>` para resolver el `sub` contra su
propio dominio. Spring Security invoca ese convertidor dentro de
`JwtAuthenticationProvider` después de decodificar y validar el token, antes de
guardar el `JwtAuthenticationToken` en el contexto de seguridad.

En Capstone, `KeycloakJwtAuthenticationConverter` consulta `usuario.keycloak_id`
por el `sub` del JWT. La autenticación continúa únicamente si la cuenta existe y
está activa (`usuario.activo = true`); una cuenta ausente o inactiva lanza
`InvalidBearerTokenException`, que el Resource Server responde como HTTP 401.
La consulta se ejecuta para cada solicitud con Bearer token, por lo que borrar o
desactivar localmente una cuenta invalida el acceso aunque conserve un JWT vigente.

- **Fuente oficial adicional**: https://docs.spring.io/spring-security/reference/6.2/servlet/oauth2/resource-server/jwt.html
- **Verificado**: 2026-09-16

---

## Errores Comunes
1. **403 Forbidden al validar roles**: Keycloak emite roles como `"ADMIN"`. Spring Security espera el prefijo `"ROLE_ADMIN"` cuando se evalúa `hasRole('ADMIN')`. Siempre anteponer `"ROLE_"` en el converter.
2. **Issuer mismatch en Docker**: Si el frontend obtiene el token desde `http://localhost:8080` y el backend en Docker valida `http://keycloak:8080`, el claim `iss` no coincidirá a menos que Keycloak tenga configurado `KC_HOSTNAME` homogéneo o se valide solo la firma por JWK.
