---
name: spring-docs-research
description: >-
  Busca, consulta y persiste documentación técnica oficial de Spring Boot (3.x), Spring Security 6, Spring Data JPA, Spring AMQP y afines. Usar cuando se requiera resolver dudas de APIs, configuraciones avanzadas o sintaxis específica que no esté cubierta en la guía general de buenas prácticas. Prioriza la lectura en referencias locales (.md); si no existe, investiga en la web oficial (docs.spring.io) y persiste lo aprendido en archivos markdown locales para optimizar lecturas futuras.
---

# Spring Boot Docs Research & Local Knowledge Collector

Esta skill define el procedimiento estándar para adquirir, consultar y cachear documentación técnica oficial de Spring Boot 3.x y el ecosistema Spring.

El principio rector es **Local-First**: nunca salgas a la web si el conocimiento ya fue investigado y persistido localmente. Cuando investigues un tema nuevo en la web, documenta lo aprendido en la carpeta de referencias para que cualquier agente posterior lo aproveche sin gastar tiempo ni tokens en navegación.

---

## Flujo de Ejecución (Paso a Paso)

```mermaid
graph TD
    Start([Necesidad de documentación Spring]) --> CheckLocal{¿Existe en referencias locales?}
    CheckLocal -->|Sí| ReadLocal[Leer archivo .md en references/]
    CheckLocal -->|No| CheckCrawl4AI{¿Crawl4AI MCP activo?}
    CheckCrawl4AI -->|Sí: Opcional| ScrapeCrawl4AI[Scrapear vía Crawl4AI MCP / puerto 11235]
    CheckCrawl4AI -->|No: Backup estándar| NativeFallback[Buscar vía search_web + read_url_content]
    ScrapeCrawl4AI --> Synthesize[Sintetizar conceptos, yaml y código Java 21]
    NativeFallback --> Synthesize
    Synthesize --> SaveLocal[Guardar nuevo .md en references/]
    SaveLocal --> UpdateIndex[Actualizar references/INDEX.md]
    UpdateIndex --> ApplyCode[Aplicar conocimiento al código]
    ReadLocal --> ApplyCode
```

---

## 1. Fase Local (Local-First Check)

Antes de realizar cualquier búsqueda web:

1. Revisa el índice maestro de documentación local:
   [`references/INDEX.md`](./references/INDEX.md)
2. Si el tema o una versión previa existe en `references/`:
   - Lee el archivo correspondiente mediante `view_file`.
   - Si contiene la información requerida, úsala de inmediato y finaliza la búsqueda.
3. Si el archivo local no responde a la duda o el tema no existe en el índice, procede a la Fase Web.

---

## 2. Fase Web: Estrategia Dual (Crawl4AI vs. Backup Nativo)

> [!IMPORTANT]
> **Compatibilidad para Todo el Equipo (Zero Dependencies)**:
> No todos los desarrolladores o agentes tendrán Crawl4AI instalado en su máquina. Por diseño del proyecto, **Crawl4AI es una optimización opcional, nunca un bloqueo obligatorio**. Si no está instalado o no responde, el agente **debe degradar automáticamente al canal nativo de backup**.

### Opción A: Backup Nativo (Por defecto para cualquier desarrollador)
Si el servidor Crawl4AI no está encendido o el MCP no está registrado en el entorno actual:
1. Utiliza las herramientas estándar del asistente:
   - `search_web`: Para buscar en `docs.spring.io`.
   - `read_url_content`: Para descargar el contenido HTML y convertirlo a Markdown estándar.
2. Esta ruta funciona de forma inmediata sin necesidad de contenedores adicionales ni configuraciones especiales.

### Opción B: Scraper Avanzado con Crawl4AI MCP (Si está disponible)
Si la máquina local cuenta con el servidor Crawl4AI corriendo en `http://localhost:11235`:
1. Utiliza la herramienta MCP `crawl4ai` (o el endpoint `POST http://localhost:11235/md`) para extraer Markdown limpio procesado por headless Chromium (con soporte para scripts, selector de fit y bypass de elementos interactivos).
2. Es especialmente útil en páginas con documentación interactiva o tabs dinámicos de JavaScript.

### Guía de Instalación Opcional de Crawl4AI para Desarrolladores
Si un desarrollador desea habilitar el servidor Crawl4AI en su máquina local (fuera del proyecto):
```bash
docker run -d -p 11235:11235 --name crawl4ai --shm-size=1g -e CRAWL4AI_API_TOKEN=crawl4ai_mcp_token_2026 --restart unless-stopped unclecode/crawl4ai:latest
```
Y agregar en su `~/.gemini/config/mcp_config.json`:
```json
{
  "mcpServers": {
    "crawl4ai": {
      "serverUrl": "http://localhost:11235/mcp/sse"
    }
  }
}
```

---

## 3. Fuentes Oficiales Recomendadas

Cuando requieras buscar información externa (sea por Crawl4AI o por backup nativo):

1. **Restringe la búsqueda a fuentes oficiales**:
   Prioriza siempre:
   - `docs.spring.io` (Spring Boot Reference Documentation, Spring Framework, Spring Security, etc.)
   - Versión objetivo: **Spring Boot 3.2+**, **Spring Framework 6.1+**, **Spring Security 6.2+**, **Java 21**.
2. **Formato de consulta recomendado**:
   ```
   site:docs.spring.io/spring-boot/docs/3.2.x/reference/html/ <tema>
   site:docs.spring.io/spring-security/reference/6.2/ <tema>
   site:docs.spring.io/spring-data/jpa/docs/current/reference/html/ <tema>
   ```

---

## 4. Fase de Síntesis y Persistencia Local

Una vez recopilada y verificada la información oficial:

1. **Crea un archivo Markdown en `references/<modulo-tema>.md`**:
   - Utiliza nombres semánticos: por ejemplo `security-jwt-resource-server.md`, `amqp-rabbitmq-json.md`, `jpa-auditing.md`, `restclient-fluent-api.md`.
   - Sigue la plantilla de documentación definida abajo.
2. **Estructura requerida de la nota local**:
   ```markdown
   # [Título del Módulo / Tema]
   
   - **Fuente Oficial**: [URL de docs.spring.io]
   - **Versión de Referencia**: Spring Boot 3.2.x / Java 21
   - **Fecha de Adquisición**: YYYY-MM-DD
   
   ## Resumen Conceptual
   Breve explicación del funcionamiento según el estándar de Spring.
   
   ## Dependencias Maven (pom.xml)
   Coordenadas requeridas si aplica.
   
   ## Configuración en application.yml
   Fragmento YAML idiomático con placeholders o valores recomendados.
   
   ## Implementación de Código (Java 21)
   Clases, anotaciones y snippets mínimos funcionales.
   
   ## Advertencias y Errores Comunes
   Puntos críticos a considerar (por ejemplo, cambios entre Spring Boot 2 y 3).
   ```
3. **Actualiza `references/INDEX.md`**:
   - Agrega la fila correspondiente en la tabla del índice con el enlace relativo, categoría y breve descripción.

---

## 5. Criterios de Calidad del Conocimiento Guardado

- **Específico de Spring Boot 3 / Java 21**: No guardes snippets obsoletos de Spring Boot 2 o Java 8 (ej. `WebSecurityConfigurerAdapter` fue eliminado en Spring Security 6; `RestTemplate` se prefiere reemplazar por `RestClient` en Spring Boot 3.2).
- **Conciso y Práctico**: La nota debe permitir que un agente implemente la solución de inmediato sin necesidad de volver a leer la web.
- **Evitar Duplicados**: Si ya existe un documento similar, amplíalo o refactorízalo en lugar de crear uno nuevo.
