# Guía de Implementación RBAC con Spring Security 6 y Keycloak

## 1. Jerarquía de Roles en Capstone
- `ROLE_ADMIN`: Acceso irrestricto a parametrizaciones, catálogos de usuarios y auditoría global.
- `ROLE_APPROVER`: Capacidad de revisar documentos, aprobar, rechazar o solicitar correcciones.
- `ROLE_USER`: Usuario base con permiso para emitir solicitudes, subir documentos propios y completar formularios.

## 2. Aseguramiento por Métodos (`@PreAuthorize`)
La anotación `@EnableMethodSecurity(prePostEnabled = true)` activa el control por métodos:

```java
@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    // Cualquier usuario autenticado puede listar sus propios documentos
    @GetMapping("/my-documents")
    public ResponseEntity<List<DocumentResponse>> getMyDocuments(@AuthenticationPrincipal Jwt jwt) {
        String username = jwt.getClaimAsString("preferred_username");
        return ResponseEntity.ok(documentService.findByOwner(username));
    }

    // Solo Aprobadores y Administradores pueden acceder a la bandeja de revisión
    @GetMapping("/pending-review")
    @PreAuthorize("hasAnyRole('APPROVER', 'ADMIN')")
    public ResponseEntity<List<DocumentResponse>> getPendingReviews() {
        return ResponseEntity.ok(documentService.findPendingReviews());
    }

    // Solo Administradores pueden configurar las reglas globales
    @PutMapping("/configuration")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> updateGlobalRules(@Valid @RequestBody GlobalRulesDto rules) {
        documentService.updateRules(rules);
        return ResponseEntity.noContent().build();
    }
}
```

## 3. Comprobación de Propiedad a Nivel de Negocio
Cuando un usuario solo debe poder modificar o ver sus propios documentos, combina `@PreAuthorize` con SpEL o valida programáticamente en el servicio:

```java
@PreAuthorize("hasRole('ADMIN') or @documentSecurityService.isDocumentOwner(#id, authentication.name)")
@GetMapping("/{id}")
public ResponseEntity<DocumentResponse> getDocumentById(@PathVariable UUID id) { ... }
```
O de manera más legible y depurable en el Service:
```java
public DocumentEntity getDocumentById(UUID id, String currentUsername, boolean isAdmin) {
    DocumentEntity doc = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Documento no encontrado"));
    if (!isAdmin && !doc.getOwnerUsername().equals(currentUsername)) {
        throw new AccessDeniedException("No tiene permisos para acceder a este documento");
    }
    return doc;
}
```
