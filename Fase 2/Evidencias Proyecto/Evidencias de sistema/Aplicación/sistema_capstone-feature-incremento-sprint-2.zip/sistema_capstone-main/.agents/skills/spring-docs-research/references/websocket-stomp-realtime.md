# Spring Boot 3 - Realtime WebSockets con STOMP y SockJS

- **Fuentes Oficiales**:
  - https://docs.spring.io/spring-framework/reference/web/websocket/stomp.html
  - https://docs.spring.io/spring-boot/reference/web/servlet.html#web.servlet.websocket
- **Versión de Referencia**: Spring Boot 3.2.x / Spring Framework 6.1.x / Java 21
- **Fecha de Adquisición**: 2026-09-11 (vía Crawl4AI MCP)

---

## Resumen Conceptual

Para la actualización en tiempo real de estados de documentos, notificaciones al usuario y aprobaciones de flujo en el frontend (React), Spring Boot proporciona soporte para **STOMP (Simple Text Oriented Messaging Protocol)** sobre WebSockets.

- **Broker simple en memoria**: Spring incluye un message broker interno para destinos `/topic` (publicar a muchos) y `/queue` (mensajes a usuario individual).
- **SockJS**: Proveer fallback automático si el navegador o proxy del cliente no soporta WebSockets puros.
- **`SimpMessagingTemplate`**: Bean inyectable para emitir mensajes asíncronamente desde cualquier servicio de negocio (por ejemplo, al recibir un evento de RabbitMQ).

---

## Dependencias Maven (`pom.xml`)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-websocket</artifactId>
</dependency>
<!-- Para seguridad en canales WebSocket -->
<dependency>
    <groupId>org.springframework.security</groupId>
    <artifactId>spring-security-messaging</artifactId>
</dependency>
```

---

## Configuración del Message Broker (`WebSocketConfig.java`)

```java
package com.capstone.sistema.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // Prefijos para los destinos a los cuales el cliente puede suscribirse:
        // /topic: Mensajes broadcast (ej. actualización general de estado)
        // /queue: Mensajes privados para un usuario específico
        config.enableSimpleBroker("/topic", "/queue");

        // Prefijo para mensajes enviados desde el cliente al servidor (@MessageMapping)
        config.setApplicationDestinationPrefixes("/app");

        // Prefijo para suscripciones de usuario específico (/user/queue/notifications)
        config.setUserDestinationPrefix("/user");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // Endpoint HTTP donde el cliente realiza el handshake WebSocket inicial
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*")
                .withSockJS(); // Fallback para clientes que no soportan WS directo
    }
}
```

---

## Emisión de Eventos desde Servicios de Negocio (`SimpMessagingTemplate`)

Inyecta `SimpMessagingTemplate` en servicios de negocio o listeners de RabbitMQ para notificar al frontend en tiempo real:

```java
package com.capstone.sistema.notification;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class RealtimeNotificationService {

    private final SimpMessagingTemplate messagingTemplate;

    /**
     * Notifica a todos los suscriptores de un documento específico que su estado cambió.
     * El frontend se suscribe a: /topic/documents/{documentId}
     */
    public void notifyDocumentStatusChanged(UUID documentId, String newStatus) {
        String destination = "/topic/documents/" + documentId;
        DocumentStatusEvent payload = new DocumentStatusEvent(documentId, newStatus);
        
        log.info("Enviando evento WebSocket a {}: {}", destination, payload);
        messagingTemplate.convertAndSend(destination, payload);
    }

    /**
     * Envía una notificación privada a un usuario específico.
     * El frontend se suscribe a: /user/queue/notifications
     */
    public void sendPrivateNotification(String username, String message) {
        log.info("Enviando notificación privada a {}: {}", username, message);
        messagingTemplate.convertAndSendToUser(username, "/queue/notifications", message);
    }

    public record DocumentStatusEvent(UUID documentId, String status) {}
}
```

---

## Integración con RabbitMQ (Patrón Event-Driven a Realtime)

Cuando un evento de aprobación llega desde RabbitMQ (`service-notificaciones` o `sistema-principal`), se reenvía directamente al cliente WebSocket:

```java
@Component
@RequiredArgsConstructor
@Slf4j
public class FlowNotificationListener {

    private final RealtimeNotificationService realtimeService;

    @RabbitListener(queues = "${app.rabbitmq.queues.flow-notifications}")
    public void onFlowEvent(FlowApprovedEvent event) {
        log.info("Evento de flujo recibido de RabbitMQ para documento: {}", event.documentId());
        realtimeService.notifyDocumentStatusChanged(event.documentId(), event.status());
    }
}
```

---

## Autenticación JWT en WebSocket Handshake / STOMP

Para validar el token JWT de Keycloak en las conexiones WebSocket:

```java
@Configuration
@RequiredArgsConstructor
public class WebSocketSecurityConfig implements WebSocketMessageBrokerConfigurer {

    private final JwtDecoder jwtDecoder;

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
                if (accessor != null && StompCommand.CONNECT.equals(accessor.getCommand())) {
                    String authHeader = accessor.getFirstNativeHeader("Authorization");
                    if (authHeader != null && authHeader.startsWith("Bearer ")) {
                        String token = authHeader.substring(7);
                        Jwt jwt = jwtDecoder.decode(token);
                        accessor.setUser(new JwtAuthenticationToken(jwt));
                    }
                }
                return message;
            }
        });
    }
}
```
