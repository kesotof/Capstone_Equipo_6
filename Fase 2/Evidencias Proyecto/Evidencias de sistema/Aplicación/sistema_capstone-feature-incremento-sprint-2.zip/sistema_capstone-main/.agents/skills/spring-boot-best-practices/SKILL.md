---
name: spring-boot-best-practices
description: >-
  Guía de buenas prácticas, patrones de diseño y estándares de codificación para el desarrollo con Spring Boot 3.x y Java 21 en el proyecto Capstone. Usar siempre antes de crear o refactorizar controladores, servicios, repositorios, entidades JPA, configuraciones de seguridad, consumidores RabbitMQ y tests.
---

# Guía de Buenas Prácticas Spring Boot 3.x & Java 21 (Capstone)

Esta skill proporciona el compendio técnico de directrices, patrones arquitectónicos y reglas de codificación que todo agente de desarrollo debe seguir rigurosamente al trabajar en los servicios backend (`sistema-principal`, `service-notificaciones`, `service-ia`).

---

## 1. Arquitectura de Capas y Organización de Paquetes

Adoptamos un diseño **Feature/Module Driven** dentro de cada microservicio:

```
com.capstone.<servicio>.<modulo>/
├── controller/         # Adaptadores HTTP (@RestController), mapeo DTO <-> Servicio
├── service/            # Lógica de negocio pura e interfaces (@Service)
│   └── impl/           # Implementaciones si la complejidad lo amerita
├── repository/         # Interfaces Spring Data JPA (@Repository)
├── model/              # Entidades JPA (@Entity) y Enums
├── dto/                # Records Java 21 inmutables (Requests y Responses)
├── mapper/             # Conversores Entity <-> DTO (MapStruct o métodos estáticos)
└── config/             # Beans y configuraciones específicas del módulo
```

### Reglas de Capas:
- **Controladores delgados (Thin Controllers)**: No deben contener lógica de negocio, validaciones complejas ni transacciones directas con la BD. Su única función es recibir la petición, delegar al servicio y devolver un `ResponseEntity<T>`.
- **Servicios autocontenidos**: Toda la orquestación transaccional y reglas de negocio residen en la capa de servicio.
- **DTOs estrictos**: Nunca expongas entidades JPA (`@Entity`) directamente en los endpoints REST para evitar acoplamientos, fugas de datos sensibles y problemas de serialización recursiva / lazy loading.

---

## 2. Inyección de Dependencias Limpia

- **Regla Estricta**: **Nunca utilices `@Autowired` sobre atributos privados** (field injection).
- **Patrón Recomendado**: Usa inyección por constructor utilizando `@RequiredArgsConstructor` de Lombok y marca todos los colaboradores como `private final`.

```java
// BIEN
@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;
    private final MinioStorageService storageService;
    private final FlowEventPublisher eventPublisher;

    // Métodos de negocio...
}
```

---

## 3. Clases Inmutables con Records de Java 21

Aprovecha los **`record`** de Java 21 para definir DTOs, mensajes de RabbitMQ y respuestas de API:

```java
// DTO de Entrada con validación Bean Validation (Jakarta)
public record CreateDocumentRequest(
    @NotBlank(message = "El título es obligatorio")
    @Size(min = 3, max = 150)
    String title,

    @NotNull(message = "El departamento es requerido")
    Long departmentId,

    String description
) {}

// DTO de Salida
public record DocumentResponse(
    UUID id,
    String title,
    String status,
    String fileKey,
    LocalDateTime createdAt
) {}
```

---

## 4. Manejo Global de Errores con `ProblemDetail` (RFC 7807)

En Spring Boot 3, el estándar oficial para respuestas de error es el RFC 7807 (`ProblemDetail`).
1. **Activar en `application.yml`**:
   Configura la propiedad oficial para que las excepciones estándar del framework (404, 405, 415) se serialicen como ProblemDetail automáticamente:
   ```yaml
   spring:
     mvc:
       problemdetails:
         enabled: true
   ```
2. **Centralizar Excepciones de Negocio con `@RestControllerAdvice`**:
   ```java
   @RestControllerAdvice
   @Slf4j
   public class GlobalExceptionHandler {

       @ExceptionHandler(ResourceNotFoundException.class)
       public ProblemDetail handleNotFound(ResourceNotFoundException ex) {
           log.warn("Recurso no encontrado: {}", ex.getMessage());
           ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
           problem.setTitle("Recurso Inexistente");
           problem.setProperty("timestamp", Instant.now());
           return problem;
       }

       @ExceptionHandler(MethodArgumentNotValidException.class)
       public ProblemDetail handleValidation(MethodArgumentNotValidException ex) {
           ProblemDetail problem = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
           problem.setTitle("Error de Validación");
           Map<String, String> errors = ex.getBindingResult().getFieldErrors().stream()
                   .collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
           problem.setProperty("invalidFields", errors);
           return problem;
       }
   }
   ```

---

## 5. Persistencia Eficiente con Spring Data JPA

1. **Relaciones siempre `LAZY`**:
   - Todo `@ManyToOne` y `@OneToOne` debe declarar explícitamente `fetch = FetchType.LAZY`. Por defecto en JPA son `EAGER`, lo que genera consultas redundantes masivas (problema N+1).
2. **Consultas con Proyecciones o `JOIN FETCH`**:
   - Si requieres cargar una relación en una sola consulta, utiliza `JOIN FETCH`:
     ```java
     @Query("SELECT d FROM DocumentEntity d JOIN FETCH d.organization WHERE d.id = :id")
     Optional<DocumentEntity> findByIdWithOrg(@Param("id") UUID id);
     ```
3. **Transaccionalidad Explícita**:
   - En métodos de solo lectura en la capa de servicio, aplica siempre `@Transactional(readOnly = true)`. Permite optimizaciones en Hibernate (modo dirty checking desactivado) y en el driver JDBC.
   - En métodos de escritura, usa `@Transactional` delimitando la unidad atómica de trabajo.

---

## 6. Seguridad y Control de Acceso (RBAC)

- **Validación Declarativa**: Usa `@PreAuthorize` en controladores o servicios para restringir operaciones:
  ```java
  @PreAuthorize("hasRole('ADMIN')")
  @PostMapping("/admin/config")
  public ResponseEntity<Void> updateConfig(@RequestBody OrgConfigDto config) { ... }

  @PreAuthorize("hasAnyRole('ADMIN', 'APPROVER')")
  @GetMapping("/flow/reviews")
  public ResponseEntity<List<FlowReviewDto>> listPendingReviews() { ... }
  ```
- **Contexto de Usuario**: Accede al usuario autenticado de forma limpia mediante inyección:
  ```java
  @GetMapping("/me")
  public ResponseEntity<UserProfileDto> getCurrentUser(@AuthenticationPrincipal Jwt jwt) {
      String username = jwt.getClaimAsString("preferred_username");
      String email = jwt.getClaimAsString("email");
      return ResponseEntity.ok(new UserProfileDto(username, email));
  }
  ```

---

## 7. Mensajería Asincrónica con RabbitMQ

- **Idempotencia**: Diseña a los consumidores de eventos asumiendo que un mensaje puede llegar más de una vez (at-least-once delivery).
- **Payloads en JSON**: Asegura que el `RabbitTemplate` y los listeners utilicen `Jackson2JsonMessageConverter`.
- **Manejo de Errores en Listeners**: No dejes que excepciones no controladas generen bucles infinitos de reentrega. Usa reintentos configurados o captura excepciones con logging de diagnóstico.

---

## 8. Notificaciones en Tiempo Real con WebSockets (STOMP & SockJS)

- **Patrón Recomendado**: Usa STOMP sobre WebSocket con fallback a SockJS (`@EnableWebSocketMessageBroker`).
- **Destinos Estandarizados**:
  - `/topic/*`: Mensajes broadcast (ej. `/topic/documents/{id}` para actualizar estado a observadores).
  - `/queue/*` o `/user/queue/*`: Mensajes directos a un usuario autenticado.
- **Emisión Desacoplada**: Inyecta `SimpMessagingTemplate` en servicios de negocio o listeners de RabbitMQ:
  ```java
  @Service
  @RequiredArgsConstructor
  public class DocumentNotificationService {
      private final SimpMessagingTemplate messagingTemplate;

      public void publishStatusChange(UUID documentId, String newStatus) {
          messagingTemplate.convertAndSend("/topic/documents/" + documentId,
                  new DocumentStatusUpdate(documentId, newStatus));
      }
  }
  ```

---

## 9. Clientes Externos (`RestClient` vs APIs externas)

- **Inyección de `RestClient.Builder`**: La documentación oficial de Spring Boot recomienda explícitamente inyectar el Bean prototipo autoconfigurado `RestClient.Builder` (en lugar de invocar `RestClient.create()` estático) para heredar los conversores de mensajes, métricas y bundles SSL configurados por Spring:
  ```java
  @Service
  public class MasterBaseClientService {

      private final RestClient restClient;

      public MasterBaseClientService(RestClient.Builder builder,
                                     @Value("${masterbase.api.url}") String baseUrl,
                                     @Value("${masterbase.api.key}") String apiKey) {
          this.restClient = builder
                  .baseUrl(baseUrl)
                  .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                  .build();
      }
  }
  ```
- Envuelve las llamadas HTTP externas en bloques `.onStatus(status -> status.isError(), ...)` para proveer fallbacks o registrar diagnósticos claros en caso de indisponibilidad.

---

## 10. Logging y Trazabilidad

- **Usa SLF4J**: Siempre anota con `@Slf4j` de Lombok o declara `LoggerFactory.getLogger(...)`.
- **Niveles adecuados**:
  - `log.debug(...)`: Detalles finos de depuración (payloads completos).
  - `log.info(...)`: Eventos de ciclo de vida del negocio (solicitud iniciada, aprobación completada).
  - `log.warn(...)`: Situaciones anómalas recuperables (fallback activado, reintento).
  - `log.error(...)`: Errores críticos no recuperables (fallo de BD, excepción inesperada).
- **Prohibición**: Nunca uses `System.out.println()` ni `e.printStackTrace()`.

---

## 11. Checklist de Verificación para Agentes

Antes de dar por completada una tarea en Spring Boot:

1. [ ] ¿Compila limpiamente con Maven? (`mvn clean compile -DskipTests`)
2. [ ] ¿Los nombres de variables y clases siguen las convenciones estándar de Java (`camelCase`, `PascalCase`)?
3. [ ] ¿Todas las dependencias inyectadas son `private final` mediante constructor?
4. [ ] ¿Los endpoints REST devuelven códigos HTTP semánticos (200 OK, 201 Created, 204 No Content, 400 Bad Request, 404 Not Found)?
5. [ ] ¿No se expone ninguna entidad JPA en los contratos REST?
6. [ ] ¿El endpoint `/actuator/health` responde `{ "status": "UP" }` al levantar el servicio?

