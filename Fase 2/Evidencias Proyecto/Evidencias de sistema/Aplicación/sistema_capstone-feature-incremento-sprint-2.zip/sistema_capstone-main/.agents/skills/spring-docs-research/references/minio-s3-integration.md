# MinIO Java SDK 8.5+ con Spring Boot

- **Fuente Oficial**: https://min.io/docs/minio/linux/developers/java/minio-java.html
- **Versión de Referencia**: MinIO Java SDK 8.5.10 / Spring Boot 3.2.x / Java 21
- **Fecha de Adquisición**: 2026-09-11

---

## Resumen Conceptual

MinIO provee compatibilidad nativa con la API AWS S3. En Spring Boot se utiliza el SDK oficial `io.minio:minio` configurando un singleton de `MinioClient` inyectable. Las operaciones de carga y descarga deben realizarse mediante Streams para evitar saturar la memoria heap de la JVM con archivos pesados (.pdf, .docx).

---

## Dependencias Maven (`pom.xml`)

```xml
<dependency>
    <groupId>io.minio</groupId>
    <artifactId>minio</artifactId>
    <version>8.5.10</version>
</dependency>
```

---

## Configuración en `application.yml`

```yaml
minio:
  endpoint: ${MINIO_ENDPOINT:http://localhost:9000}
  access-key: ${MINIO_ROOT_USER:minioadmin}
  secret-key: ${MINIO_ROOT_PASSWORD:minioadmin_secure_pass}
  bucket: ${MINIO_DEFAULT_BUCKET:documentos}
```

---

## Bean del Cliente (`MinioConfig.java`)

```java
package com.capstone.sistema.doc.config;

import io.minio.MinioClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MinioConfig {

    @Bean
    public MinioClient minioClient(
            @Value("${minio.endpoint}") String endpoint,
            @Value("${minio.access-key}") String accessKey,
            @Value("${minio.secret-key}") String secretKey) {
        return MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
    }
}
```

---

## Servicio de Carga y Descarga Eficiente (`MinioService.java`)

```java
package com.capstone.sistema.doc.service;

import io.minio.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MinioService {

    private final MinioClient minioClient;

    @Value("${minio.bucket}")
    private String bucketName;

    public String uploadDocument(MultipartFile file) throws Exception {
        ensureBucket();
        String objectName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        
        try (InputStream stream = file.getInputStream()) {
            minioClient.putObject(
                PutObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .stream(stream, file.getSize(), -1)
                    .contentType(file.getContentType())
                    .build()
            );
        }
        return objectName;
    }

    public InputStream downloadDocument(String objectName) throws Exception {
        return minioClient.getObject(
            GetObjectArgs.builder()
                .bucket(bucketName)
                .object(objectName)
                .build()
        );
    }

    private void ensureBucket() throws Exception {
        boolean found = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
        if (!found) {
            minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
        }
    }
}
```

---

## Puntos Críticos
1. **Part Size en `putObject`**: Pasar `-1` como `partSize` permite que MinIO calcule dinámicamente el tamaño de partes cuando el tamaño del archivo se conoce (`file.getSize()`).
2. **Cierre de Streams**: El `InputStream` retornado por `minioClient.getObject` debe ser cerrado por el consumidor para liberar el socket HTTP subyacente.
