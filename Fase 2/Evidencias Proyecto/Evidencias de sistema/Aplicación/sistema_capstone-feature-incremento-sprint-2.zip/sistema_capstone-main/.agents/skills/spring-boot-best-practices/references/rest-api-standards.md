# Estándares de Diseño de APIs RESTful en Spring Boot 3

## 1. Nomenclatura de URIs
- Utilizar sustantivos en plural y en minúsculas: `/api/documents`, `/api/flows`, `/api/users`.
- Subrecursos jerárquicos: `/api/flows/{flowId}/steps`, `/api/documents/{id}/history`.
- Acciones que no encajan en CRUD se nombran con verbos descriptivos: `/api/documents/{id}/submit`, `/api/documents/{id}/approve`.

## 2. Códigos de Estado HTTP
- `200 OK`: Petición exitosa con cuerpo de respuesta (GET, PUT, PATCH).
- `201 Created`: Recurso creado exitosamente (POST). Incluir header `Location` o el DTO creado con su ID.
- `204 No Content`: Petición exitosa sin cuerpo de respuesta (DELETE).
- `400 Bad Request`: Parámetros o cuerpo inválidos (validación Jakarta `@Valid`).
- `401 Unauthorized`: Falta de token JWT o token expirado/inválido.
- `403 Forbidden`: Token válido pero el usuario no posee el rol requerido (`@PreAuthorize`).
- `404 Not Found`: El recurso solicitado con el identificador provisto no existe.
- `409 Conflict`: Conflicto de estado de negocio (ej. intentar aprobar un documento ya rechazado).
- `500 Internal Server Error`: Error inesperado no controlado.

## 3. Paginación y Ordenamiento
Para endpoints que retornan colecciones, utilizar `Pageable` de Spring Data:
```java
@GetMapping
public ResponseEntity<Page<DocumentResponse>> listDocuments(
        @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
    return ResponseEntity.ok(documentService.findAll(pageable));
}
```

## 4. Estructura de Respuesta para Errores (ProblemDetail)
```json
{
  "type": "about:blank",
  "title": "Recurso Inexistente",
  "status": 404,
  "detail": "No se encontró el documento con identificador 123e4567-e89b-12d3-a456-426614174000",
  "instance": "/api/documents/123e4567-e89b-12d3-a456-426614174000",
  "timestamp": "2026-09-11T12:00:00Z"
}
```
