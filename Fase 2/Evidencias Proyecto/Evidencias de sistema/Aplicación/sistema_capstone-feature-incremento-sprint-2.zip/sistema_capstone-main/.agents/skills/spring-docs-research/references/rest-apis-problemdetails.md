# Spring Boot 3 - REST APIs Estándar y ProblemDetail (RFC 7807)

- **Fuentes Oficiales**:
  - https://docs.spring.io/spring-boot/reference/web/servlet.html
  - https://docs.spring.io/spring-framework/reference/web/webmvc/mvc-controller/ann-rest-exceptions.html
- **Versión de Referencia**: Spring Boot 3.2.x / Spring Framework 6.1.x / Java 21
- **Fecha de Adquisición**: 2026-09-11 (vía Crawl4AI MCP)

---

## Resumen Conceptual

En Spring Boot 3, el desarrollo de APIs REST se apoya en:
1. **Modelado inmutable de Requests y Responses** con `record` de Java 21 y validaciones declarativas Jakarta Validation (`@Valid`, `@NotNull`, `@NotBlank`, etc.).
2. **Estandarización de errores con RFC 7807 (`ProblemDetail`)**: Respuestas de error uniformes y semánticas para el frontend (`type`, `title`, `status`, `detail`, `instance` y propiedades dinámicas).
3. **Controladores delgados**: Mapeo y retorno con `ResponseEntity<T>`, delegando toda la lógica al `@Service`.

---

## Dependencias Maven (`pom.xml`)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

---

## Configuración en `application.yml`

Activar el soporte automático de `ProblemDetail` para excepciones del framework:

```yaml
spring:
  mvc:
    problemdetails:
      enabled: true
```

---

## Controlador REST Estándar (`@RestController`)

```java
package com.capstone.sistema.document.controller;

import com.capstone.sistema.document.dto.CreateDocumentRequest;
import com.capstone.sistema.document.dto.DocumentResponse;
import com.capstone.sistema.document.service.DocumentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    @PostMapping
    public ResponseEntity<DocumentResponse> createDocument(
            @Valid @RequestBody CreateDocumentRequest request) {
        DocumentResponse response = documentService.createDocument(request);
        URI location = URI.create("/api/v1/documents/" + response.id());
        return ResponseEntity.created(location).body(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<DocumentResponse> getDocumentById(@PathVariable UUID id) {
        return ResponseEntity.ok(documentService.findById(id));
    }

    @GetMapping
    public ResponseEntity<List<DocumentResponse>> listDocuments() {
        return ResponseEntity.ok(documentService.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDocument(@PathVariable UUID id) {
        documentService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
```

---

## Centralización de Errores con `@RestControllerAdvice` y RFC 7807

```java
package com.capstone.sistema.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;
import java.time.Instant;
import java.util.Map;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ProblemDetail handleResourceNotFound(ResourceNotFoundException ex) {
        log.warn("Recurso no encontrado: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Recurso Inexistente");
        problem.setType(URI.create("https://api.capstone.duoc.cl/errors/not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidationException(MethodArgumentNotValidException ex) {
        log.warn("Fallo de validación en request: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problem.setTitle("Error de Validación de Datos");
        problem.setType(URI.create("https://api.capstone.duoc.cl/errors/bad-request"));

        Map<String, String> invalidFields = ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage, (a, b) -> a));

        problem.setProperty("invalidFields", invalidFields);
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(BusinessException.class)
    public ProblemDetail handleBusinessException(BusinessException ex) {
        log.warn("Violación de regla de negocio: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage());
        problem.setTitle("Regla de Negocio Incumplida");
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }
}
```
