# Spring Framework 6.1 / Spring Boot 3.2 - Nueva API Fluida `RestClient`

- **Fuente Oficial**: https://docs.spring.io/spring-framework/reference/integration/rest-clients.html#rest-restclient
- **Versión de Referencia**: Spring Boot 3.2.x / Spring Framework 6.1.x / Java 21
- **Fecha de Adquisición**: 2026-09-11

---

## Resumen Conceptual

Introducido en Spring Framework 6.1 (Spring Boot 3.2), `RestClient` es el nuevo cliente HTTP sincrónico con diseño fluido. Combina la simplicidad imperativa del clásico `RestTemplate` (hoy en modo de mantenimiento) con la interfaz expresiva basada en builders de `WebClient`, pero sin obligar a incluir la dependencia reactiva `spring-boot-starter-webflux`.

---

## Creación y Configuración del Bean

```java
package com.capstone.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import java.time.Duration;

@Configuration
public class ClientConfig {

    @Bean
    public RestClient masterBaseRestClient(
            @Value("${masterbase.api.url}") String baseUrl,
            @Value("${masterbase.api.key}") String apiKey) {

        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(Duration.ofSeconds(5));
        requestFactory.setReadTimeout(Duration.ofSeconds(10));

        return RestClient.builder()
                .baseUrl(baseUrl)
                .requestFactory(requestFactory)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }
}
```

---

## Ejemplos de Invocación Fluida

### Petición POST con Cuerpo y Respuesta Mapeada

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class MasterBaseClientService {

    private final RestClient masterBaseRestClient;

    public EmailSendResponse sendEmail(EmailPayload payload) {
        return masterBaseRestClient.post()
                .uri("/messages/send")
                .body(payload)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(), (request, response) -> {
                    log.error("Error 4xx en API MasterBase: {}", response.getStatusCode());
                    throw new ExternalApiException("Error en cliente MasterBase: " + response.getStatusText());
                })
                .onStatus(status -> status.is5xxServerError(), (request, response) -> {
                    log.error("Error 5xx en API MasterBase: {}", response.getStatusCode());
                    throw new ExternalApiException("Servidor MasterBase no disponible");
                })
                .body(EmailSendResponse.class);
    }
}
```

---

## Ventajas Clave sobre `RestTemplate`
1. **Manejo declarativo de errores**: Métodos `.onStatus(predicate, handler)` para personalizar excepciones sin `ResponseErrorHandler` globales confusos.
2. **Sintaxis moderna de Java**: Excelente integración con `record` classes de Java 21 para payloads y respuestas.
3. **Liviano**: No requiere Netty ni reactor-core en el classpath.
