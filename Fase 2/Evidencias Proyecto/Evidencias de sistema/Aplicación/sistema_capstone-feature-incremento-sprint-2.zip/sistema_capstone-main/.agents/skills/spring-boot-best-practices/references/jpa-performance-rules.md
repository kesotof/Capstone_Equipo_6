# Reglas de Rendimiento y Buenas Prácticas en Spring Data JPA

## 1. Regla de Oro: FetchType.LAZY por Defecto
En JPA/Hibernate, las relaciones `@ManyToOne` y `@OneToOne` tienen por defecto `FetchType.EAGER`.
Esto provoca que cada consulta a la entidad principal ejecute consultas SQL secundarias para cada fila recuperada (el temido problema N+1).

```java
// MAL
@ManyToOne
private Organization organization;

// BIEN
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "organization_id", nullable = false)
private Organization organization;
```

## 2. Prevención del Problema N+1
Cuando necesites las relaciones asociadas para construir un DTO, usa una de las siguientes técnicas:

### A. EntityGraph Declarativo
```java
@EntityGraph(attributePaths = {"organization", "author"})
List<DocumentEntity> findByStatus(DocumentStatus status);
```

### B. JPQL con `JOIN FETCH`
```java
@Query("SELECT d FROM DocumentEntity d JOIN FETCH d.organization WHERE d.status = :status")
List<DocumentEntity> findWithOrgByStatus(@Param("status") DocumentStatus status);
```

### C. Proyecciones DTO de Interfaz o Clase Record
```java
public interface DocumentSummaryProjection {
    UUID getId();
    String getTitle();
    String getStatus();
    @Value("#{target.organization.name}")
    String getOrgName();
}
```

## 3. Transacciones de Solo Lectura
Aplica `@Transactional(readOnly = true)` a nivel de clase de servicio para consultas:
```java
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class DocumentQueryService { ... }
```
Hibernate desactiva el dirty-checking sobre los objetos gestionados, ahorrando memoria y ciclos de CPU.

## 4. Auditoría Automática (`@EntityListeners`)
Utiliza `AuditingEntityListener` para gestionar `createdAt`, `updatedAt`, `createdBy`:
```java
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
public abstract class BaseAuditableEntity {

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(nullable = false)
    private LocalDateTime updatedAt;
}
```
Actívalo en la clase de configuración con `@EnableJpaAuditing`.
