# Spring AMQP 3.1 - RabbitMQ con Serialización JSON

- **Fuente Oficial**: https://docs.spring.io/spring-amqp/reference/amqp/message-converters.html
- **Versión de Referencia**: Spring Boot 3.2.x / Spring AMQP 3.1.x / Java 21
- **Fecha de Adquisición**: 2026-09-11

---

## Resumen Conceptual

Por defecto, Spring AMQP utiliza la serialización nativa de Java (`SimpleMessageConverter`), la cual produce payloads binarios acoplados a clases específicas y representa un vector de riesgo de seguridad.
La buena práctica estándar en microservicios consiste en configurar `Jackson2JsonMessageConverter`, permitiendo el intercambio interoperable de mensajes JSON legibles entre el Sistema Principal, Notificaciones e Inteligencia Artificial.

---

## Dependencias Maven (`pom.xml`)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-amqp</artifactId>
</dependency>
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
</dependency>
```

---

## Configuración de AMQP y Converter (`RabbitMqConfig.java`)

```java
package com.capstone.common.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMqConfig {

    public static final String EXCHANGE_NAME = "capstone.exchange";
    public static final String NOTIFICATIONS_QUEUE = "notifications.queue";
    public static final String AI_QUEUE = "ai.queue";

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, MessageConverter jsonMessageConverter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter);
        return template;
    }

    @Bean
    public TopicExchange capstoneExchange() {
        return new TopicExchange(EXCHANGE_NAME, true, false);
    }

    @Bean
    public Queue notificationsQueue() {
        return QueueBuilder.durable(NOTIFICATIONS_QUEUE).build();
    }

    @Bean
    public Binding notificationsBinding(Queue notificationsQueue, TopicExchange capstoneExchange) {
        return BindingBuilder.bind(notificationsQueue).to(capstoneExchange).with("notifications.#");
    }
}
```

---

## Publicación de Eventos (Productor)

```java
@Service
@RequiredArgsConstructor
public class FlowEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public void publishDocumentSubmitted(DocumentSubmittedEvent event) {
        rabbitTemplate.convertAndSend(
            RabbitMqConfig.EXCHANGE_NAME,
            "notifications.document.submitted",
            event
        );
    }
}
```

---

## Consumo Tipado de Eventos (Consumidor)

```java
@Component
@Slf4j
public class NotificationConsumer {

    @RabbitListener(queues = RabbitMqConfig.NOTIFICATIONS_QUEUE)
    public void handleNotification(DocumentSubmittedEvent event) {
        log.info("Evento recibido para documento ID: {}", event.documentId());
        // Procesamiento asincrónico...
    }
}
```

---

## Errores Comunes
1. **`MessageConversionException: Could not resolve type id`**: Ocurre si el productor y el consumidor usan paquetes Java distintos para el DTO. Solución: configurar `DefaultClassMapper` con mapeo de tipos o recibir `Map<String, Object>` / DTO plano con `@JsonIgnoreProperties(ignoreUnknown = true)`.
2. **Mensajes infinitos en cola de error**: Si el listener lanza una excepción sin capturar, RabbitMQ reintentará indefinidamente por defecto. Solución: configurar Dead Letter Exchange (DLX) o limitar reintentos con `spring.rabbitmq.listener.simple.retry.enabled=true`.
