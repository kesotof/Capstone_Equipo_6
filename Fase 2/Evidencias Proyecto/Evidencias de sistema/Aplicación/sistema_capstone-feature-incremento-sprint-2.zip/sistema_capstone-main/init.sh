#!/usr/bin/env bash
# ==============================================================================
# Script de Inicialización y Verificación Base - Sistema Capstone
# ==============================================================================
set -e

echo "=== [1/4] Verificando entorno y variables (.env) ==="
if [ ! -f .env ]; then
    echo "Creando .env a partir de .env.example..."
    cp .env.example .env
fi
echo ".env presente y configurado."

echo "=== [2/4] Verificando herramientas de sistema (Docker & Compose) ==="
if command -v docker >/dev/null 2>&1; then
    echo "Docker instalado: $(docker --version)"
else
    echo "ADVERTENCIA: Docker no se encuentra en el PATH actual."
fi

if docker compose version >/dev/null 2>&1; then
    echo "Docker Compose instalado: $(docker compose version)"
elif command -v docker-compose >/dev/null 2>&1; then
    echo "Docker Compose instalado: $(docker-compose --version)"
else
    echo "ADVERTENCIA: Docker Compose no se encuentra en el PATH actual."
fi

echo "=== [3/4] Verificando estructura de directorios del proyecto ==="
REQUIRED_DIRS=(
    "docker/postgres/init"
    "docker/minio"
    "frontend/src/views/acceso"
    "frontend/src/views/configuracion"
    "frontend/src/views/documentos"
    "frontend/src/views/flujos"
    "backend/sistema-principal"
    "backend/service-notificaciones"
    "backend/service-ia"
    "tests/e2e/src/specs"
    "tests/e2e/src/pages"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$dir" ]; then
        echo "Creando directorio faltante: $dir"
        mkdir -p "$dir"
    fi
done
echo "Estructura de directorios validada correctamente."

echo "=== [4/4] Verificando sintaxis de docker-compose.yml ==="
if docker compose config >/dev/null 2>&1; then
    echo "docker-compose.yml es sintácticamente válido."
else
    echo "Nota: docker compose config no se ejecutó o requiere Docker daemon activo."
fi

echo "=================================================================="
echo "Inicialización completada exitosamente."
echo "Para levantar la infraestructura base de Docker:"
echo "  docker compose up -d postgres keycloak rabbitmq minio minio-init"
echo "Para levantar todos los servicios (incluyendo apps):"
echo "  docker compose --profile apps up -d"
echo "=================================================================="
