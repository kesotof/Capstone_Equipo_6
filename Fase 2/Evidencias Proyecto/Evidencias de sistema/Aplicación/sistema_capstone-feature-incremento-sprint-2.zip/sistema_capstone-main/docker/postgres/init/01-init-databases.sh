#!/bin/bash
set -e

echo "Iniciando aprovisionamiento de bases de datos para Keycloak y Sistema Principal..."

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${KEYCLOAK_DB_USER:-keycloak_user}') THEN
            CREATE ROLE ${KEYCLOAK_DB_USER:-keycloak_user} LOGIN PASSWORD '${KEYCLOAK_DB_PASSWORD:-keycloak_secure_pass}';
        END IF;
    END
    \$\$;
    SELECT 'CREATE DATABASE ${KEYCLOAK_DB_NAME:-keycloak_db} OWNER ${KEYCLOAK_DB_USER:-keycloak_user}'
    WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${KEYCLOAK_DB_NAME:-keycloak_db}')\gexec
    GRANT ALL PRIVILEGES ON DATABASE ${KEYCLOAK_DB_NAME:-keycloak_db} TO ${KEYCLOAK_DB_USER:-keycloak_user};
    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${SISTEMA_DB_USER:-sistema_user}') THEN
            CREATE ROLE ${SISTEMA_DB_USER:-sistema_user} LOGIN PASSWORD '${SISTEMA_DB_PASSWORD:-sistema_secure_pass}';
        END IF;
    END
    \$\$;
    SELECT 'CREATE DATABASE ${SISTEMA_DB_NAME:-sistema_db} OWNER ${SISTEMA_DB_USER:-sistema_user}'
    WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${SISTEMA_DB_NAME:-sistema_db}')\gexec
    GRANT ALL PRIVILEGES ON DATABASE ${SISTEMA_DB_NAME:-sistema_db} TO ${SISTEMA_DB_USER:-sistema_user};
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "${KEYCLOAK_DB_NAME:-keycloak_db}" <<-EOSQL
    GRANT ALL ON SCHEMA public TO ${KEYCLOAK_DB_USER:-keycloak_user};
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "${SISTEMA_DB_NAME:-sistema_db}" <<-EOSQL
    GRANT ALL ON SCHEMA public TO ${SISTEMA_DB_USER:-sistema_user};
EOSQL

echo "Aprovisionamiento de bases de datos completado exitosamente."
