#!/bin/sh
set -e

echo "Esperando que MinIO esté listo..."
until /usr/bin/mc alias set myminio http://minio:9000 "${MINIO_ROOT_USER}" "${MINIO_ROOT_PASSWORD}"; do
    echo "MinIO no responde aún, esperando 2 segundos..."
    sleep 2
done

echo "Creando bucket: ${MINIO_DEFAULT_BUCKET:-documentos}"
/usr/bin/mc mb "myminio/${MINIO_DEFAULT_BUCKET:-documentos}" --ignore-existing
/usr/bin/mc anonymous set none "myminio/${MINIO_DEFAULT_BUCKET:-documentos}"
echo "Bucket inicial configurado con política privada."
