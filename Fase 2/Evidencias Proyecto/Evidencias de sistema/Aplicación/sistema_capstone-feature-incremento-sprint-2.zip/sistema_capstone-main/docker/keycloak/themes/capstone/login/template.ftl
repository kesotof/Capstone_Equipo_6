<#-- Keycloak 24 registration layout: preserve the native forms, messages and session checks. -->
<#macro registrationLayout bodyClass="" displayInfo=false displayMessage=true displayRequiredFields=false>
<!DOCTYPE html>
<html class="${properties.kcHtmlClass!}"<#if realm.internationalizationEnabled> lang="${locale.currentLanguageTag}"</#if>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>${msg("loginTitle",(realm.displayName!''))}</title>
    <link rel="icon" href="${url.resourcesPath}/img/masterbase-automata.png">
    <#if properties.stylesCommon?has_content>
        <#list properties.stylesCommon?split(' ') as style>
            <link href="${url.resourcesCommonPath}/${style}" rel="stylesheet">
        </#list>
    </#if>
    <#if properties.styles?has_content>
        <#list properties.styles?split(' ') as style>
            <link href="${url.resourcesPath}/${style}" rel="stylesheet">
        </#list>
    </#if>
    <#if properties.scripts?has_content>
        <#list properties.scripts?split(' ') as script>
            <script src="${url.resourcesPath}/${script}" defer></script>
        </#list>
    </#if>
    <script src="${url.resourcesPath}/js/menu-button-links.js" type="module"></script>
    <#if scripts??>
        <#list scripts as script><script src="${script}" defer></script></#list>
    </#if>
    <#if authenticationSession??>
        <script type="module">
            import { checkCookiesAndSetTimer } from "${url.resourcesPath}/js/authChecker.js";
            checkCookiesAndSetTimer("${authenticationSession.authSessionId}", "${authenticationSession.tabId}", "${url.ssoLoginInOtherTabsUrl?no_esc}");
        </script>
    </#if>
    <script src="${url.resourcesPath}/js/capstone-login.js?v=20260922-2" defer></script>
</head>
<body class="${properties.kcBodyClass!} ${bodyClass}">
  <div class="${properties.kcLoginClass!}">
    <main class="auth-shell">
      <div class="${properties.kcFormCardClass!}">
        <div id="kc-header" class="auth-brand">
          <img src="${url.resourcesPath}/img/masterbase-wordmark.png" alt="MasterBase" width="154" height="29">
          <span>${msg("capstoneBrandCaption")}</span>
        </div>
        <div class="auth-form-content">
          <header class="${properties.kcFormHeaderClass!}">
            <#if realm.internationalizationEnabled && locale.supported?size gt 1>
              <div class="${properties.kcLocaleMainClass!}" id="kc-locale">
                <div id="kc-locale-wrapper" class="${properties.kcLocaleWrapperClass!}">
                  <div id="kc-locale-dropdown" class="menu-button-links ${properties.kcLocaleDropDownClass!}">
                    <button tabindex="1" id="kc-current-locale-link" aria-label="${msg('languages')}" aria-haspopup="true" aria-expanded="false" aria-controls="language-switch1">${locale.current}</button>
                    <ul role="menu" tabindex="-1" aria-labelledby="kc-current-locale-link" id="language-switch1" class="${properties.kcLocaleListClass!}">
                      <#list locale.supported as l>
                        <li class="${properties.kcLocaleListItemClass!}" role="none"><a role="menuitem" id="language-${l?index}" class="${properties.kcLocaleItemClass!}" href="${l.url}">${l.label}</a></li>
                      </#list>
                    </ul>
                  </div>
                </div>
              </div>
            </#if>
            <p class="auth-eyebrow">${msg("capstoneSecureAccess")}</p>
            <#if !(auth?has_content && auth.showUsername() && !auth.showResetCredentials())>
              <#if displayRequiredFields><p class="subtitle"><span class="required">*</span> ${msg("requiredFields")}</p></#if>
              <h1 id="kc-page-title"><#nested "header"></h1>
            <#else>
              <#if displayRequiredFields><p class="subtitle"><span class="required">*</span> ${msg("requiredFields")}</p></#if>
              <#nested "show-username">
              <div id="kc-username" class="${properties.kcFormGroupClass!}">
                <label id="kc-attempted-username">${auth.attemptedUsername}</label>
                <a id="reset-login" href="${url.loginRestartFlowUrl}" aria-label="${msg('restartLoginTooltip')}">
                  <div class="kc-login-tooltip"><i class="${properties.kcResetFlowIcon!}"></i><span class="kc-tooltip-text">${msg("restartLoginTooltip")}</span></div>
                </a>
              </div>
            </#if>
            <p class="auth-login-intro">${msg("capstoneLoginIntro")}</p>
          </header>
          <div id="kc-content"><div id="kc-content-wrapper">
            <#if displayMessage && message?has_content && (message.type != 'warning' || !isAppInitiatedAction??)>
              <div class="alert-${message.type} ${properties.kcAlertClass!} pf-m-<#if message.type = 'error'>danger<#else>${message.type}</#if>" role="<#if message.type = 'error'>alert<#else>status</#if>">
                <div class="pf-c-alert__icon">
                  <#if message.type = 'success'><span class="${properties.kcFeedbackSuccessIcon!}"></span></#if>
                  <#if message.type = 'warning'><span class="${properties.kcFeedbackWarningIcon!}"></span></#if>
                  <#if message.type = 'error'><span class="${properties.kcFeedbackErrorIcon!}"></span></#if>
                  <#if message.type = 'info'><span class="${properties.kcFeedbackInfoIcon!}"></span></#if>
                </div>
                <span class="${properties.kcAlertTitleClass!}">${kcSanitize(message.summary)?no_esc}</span>
              </div>
            </#if>
            <#nested "form">
            <#if auth?has_content && auth.showTryAnotherWayLink()>
              <form id="kc-select-try-another-way-form" action="${url.loginAction}" method="post">
                <div class="${properties.kcFormGroupClass!}"><input type="hidden" name="tryAnotherWay" value="on">
                  <a href="#" id="try-another-way" onclick="document.forms['kc-select-try-another-way-form'].submit();return false;">${msg("doTryAnotherWay")}</a>
                </div>
              </form>
            </#if>
            <#nested "socialProviders">
            <#if displayInfo>
              <div id="kc-info" class="${properties.kcSignUpClass!}"><div id="kc-info-wrapper" class="${properties.kcInfoAreaWrapperClass!}"><#nested "info"></div></div>
            </#if>
          </div></div>
        </div>
        <p class="auth-form-footer"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6Z"/><path d="m8 12 3 3 5-6"/></svg>${msg("capstoneAccessFooter")}</p>
      </div>
      <aside class="auth-illustration" aria-label="${msg('capstoneMascotLabel')}">
        <div class="auth-mascot-stage"><#include "mascot.svg"></div>
        <div class="auth-illustration-copy">
          <div class="auth-copy-login"><h2>${msg("capstoneWelcomeTitle")}</h2><p>${msg("capstoneWelcomeText")}</p></div>
          <div class="auth-copy-recovery"><h2>${msg("capstoneRecoveryTitle")}</h2><p>${msg("capstoneRecoveryText")}</p></div>
        </div>
        <span class="auth-illustration-footer">${msg("capstoneIllustrationFooter")}</span>
      </aside>
      <div class="auth-shooting-star" aria-hidden="true"><span></span><svg viewBox="0 0 40 40"><path d="M20 0 25 15 40 20 25 25 20 40 15 25 0 20 15 15Z" fill="currentColor"/></svg></div>
    </main>
  </div>
</body>
</html>
</#macro>
