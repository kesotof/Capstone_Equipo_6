package com.capstone.keycloak.auth;

import java.util.List;
import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.credential.PasswordCredentialModel;
import org.keycloak.provider.ProviderConfigProperty;

/** Registers the Capstone username/password form in the Keycloak browser flow. */
public final class LockMessageUsernamePasswordFormFactory implements AuthenticatorFactory {

    public static final String PROVIDER_ID = "capstone-username-password-form";
    private static final Authenticator SINGLETON = new LockMessageUsernamePasswordForm();
    private static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
        AuthenticationExecutionModel.Requirement.REQUIRED
    };

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getDisplayType() {
        return "Username Password Form (Capstone lock message)";
    }

    @Override
    public String getReferenceCategory() {
        return PasswordCredentialModel.TYPE;
    }

    @Override
    public String getHelpText() {
        return "Validates username and password and explains temporary brute-force locks.";
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }

    @Override
    public boolean isConfigurable() {
        return false;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return null;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public void init(Config.Scope config) {
        // No provider-specific configuration is required.
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
        // No post-initialization work is required.
    }

    @Override
    public void close() {
        // Singleton authenticator has no resources to release.
    }
}
