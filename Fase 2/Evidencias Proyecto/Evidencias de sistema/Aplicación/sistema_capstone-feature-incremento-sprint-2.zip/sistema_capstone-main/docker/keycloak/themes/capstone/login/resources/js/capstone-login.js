/* Presentation only: Keycloak owns the forms, navigation and password toggle. */
(() => {
  'use strict';

  const shell = document.querySelector('.auth-shell');
  if (!shell) return;

  const mascot = shell.querySelector('.auth-mascot');
  const password = document.getElementById('password');
  const recoveryForm = document.getElementById('kc-reset-password-form');
  const loginForm = document.getElementById('kc-form-login');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const recoveryKey = 'capstone.auth.recovery';
  let frame = 0;
  let navigationTimer = 0;
  let passwordVisibilityChanged = false;

  // Only a presentation flag is retained across Keycloak's native pages.
  // Neither field values nor authentication URLs are saved.
  function setRecoveryFlag(value) {
    try {
      if (value) sessionStorage.setItem(recoveryKey, 'true');
      else sessionStorage.removeItem(recoveryKey);
    } catch (_) { /* The native form also works with storage disabled. */ }
  }

  function isRecoveryPage() {
    if (recoveryForm || document.getElementById('kc-passwd-update-form')) return true;
    if (loginForm) return false;
    try { return sessionStorage.getItem(recoveryKey) === 'true'; }
    catch (_) { return false; }
  }

  function resetPage() {
    clearTimeout(navigationTimer);
    shell.inert = false;
    shell.classList.remove('auth-switching', 'auth-to-login', 'auth-to-recovery');
    const recovery = isRecoveryPage();
    shell.classList.toggle('auth-recovery', recovery);
    setRecoveryFlag(recovery);
    updateEyes();
  }

  function updateEyes() {
    if (!password || !mascot) return;
    const hiddenPassword = password.type === 'password';
    const interacting = document.activeElement === password || password.value.length > 0 || passwordVisibilityChanged;
    mascot.classList.toggle('eyes-closed', hiddenPassword && interacting);
  }

  if (password) {
    password.addEventListener('focus', updateEyes);
    password.addEventListener('blur', updateEyes);
    password.addEventListener('input', updateEyes);
    new MutationObserver(() => {
      passwordVisibilityChanged = true;
      updateEyes();
    }).observe(password, { attributes: true, attributeFilter: ['type'] });
  }

  document.addEventListener('pointermove', (event) => {
    if (!mascot || reducedMotion.matches || !finePointer.matches || event.pointerType === 'touch') return;
    cancelAnimationFrame(frame);
    const { clientX, clientY } = event;
    frame = requestAnimationFrame(() => {
      const bounds = mascot.getBoundingClientRect();
      const dx = clientX - (bounds.left + bounds.width / 2);
      const dy = clientY - (bounds.top + bounds.height * .515);
      const distance = Math.hypot(dx, dy) || 1;
      const movement = Math.min(5, distance / 65);
      mascot.style.setProperty('--eye-x', `${(dx / distance * movement).toFixed(2)}px`);
      mascot.style.setProperty('--eye-y', `${(dy / distance * movement).toFixed(2)}px`);
    });
  }, { passive: true });

  function neutralEyes() {
    cancelAnimationFrame(frame);
    mascot?.style.setProperty('--eye-x', '0px');
    mascot?.style.setProperty('--eye-y', '0px');
  }
  document.documentElement.addEventListener('pointerleave', neutralEyes);
  reducedMotion.addEventListener('change', neutralEyes);

  function animateNavigation(link, toRecovery) {
    if (!link) return;
    link.addEventListener('click', (event) => {
      if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || link.target === '_blank') return;
      const destination = new URL(link.href, window.location.href);
      if (destination.origin !== window.location.origin) return;
      setRecoveryFlag(toRecovery);
      if (reducedMotion.matches) return;
      event.preventDefault();
      if (shell.classList.contains('auth-switching')) return;
      shell.classList.add('auth-switching', toRecovery ? 'auth-to-recovery' : 'auth-to-login');
      shell.inert = true;
      navigationTimer = window.setTimeout(() => window.location.assign(destination.href), 650);
    });
  }

  animateNavigation(loginForm?.querySelector('a[href*="/login-actions/reset-credentials"]'), true);
  animateNavigation(recoveryForm?.querySelector('#kc-form-options a'), false);
  window.addEventListener('pageshow', resetPage);
  window.addEventListener('pagehide', () => { cancelAnimationFrame(frame); clearTimeout(navigationTimer); });
  resetPage();
})();
