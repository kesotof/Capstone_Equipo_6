package com.capstone.keycloak.auth;

import org.keycloak.authentication.authenticators.browser.UsernamePasswordForm;

/**
 * Conserva el comportamiento estándar de usuario y contraseña de Keycloak,
 * excepto por el texto mostrado cuando la protección de fuerza bruta bloquea
 * temporalmente una cuenta.
 */
public final class LockMessageUsernamePasswordForm extends UsernamePasswordForm {

    public static final String TEMPORARY_LOCK_MESSAGE_KEY = "capstoneAccountTemporarilyLocked";

    @Override
    protected String disabledByBruteForceError() {
        return TEMPORARY_LOCK_MESSAGE_KEY;
    }
}
