#!/bin/sh
set -eu

REALM="${KEYCLOAK_REALM:-capstone-realm}"
FLOW="browser-capstone-lock-message"
CUSTOM_PROVIDER="capstone-username-password-form"
STANDARD_PROVIDER="auth-username-password-form"
SERVER="${KEYCLOAK_SERVER:-http://keycloak:8080}"

export HOME=/tmp
mkdir -p "$HOME/.keycloak"

if ! /opt/keycloak/bin/kcadm.sh config credentials \
  --server "$SERVER" \
  --realm master \
  --user "$KEYCLOAK_ADMIN" \
  --password "$KEYCLOAK_ADMIN_PASSWORD" 2>/dev/null; then
  SERVER="http://localhost:8080"
  /opt/keycloak/bin/kcadm.sh config credentials \
    --server "$SERVER" \
    --realm master \
    --user "$KEYCLOAK_ADMIN" \
    --password "$KEYCLOAK_ADMIN_PASSWORD"
fi

if ! /opt/keycloak/bin/kcadm.sh get authentication/flows -r "$REALM" | grep -q "\"alias\" : \"$FLOW\""; then
  /opt/keycloak/bin/kcadm.sh create "authentication/flows/browser/copy" -r "$REALM" -s "newName=$FLOW"
fi

executions() {
  /opt/keycloak/bin/kcadm.sh get "authentication/flows/$FLOW/executions" -r "$REALM"
}

execution_id_for() {
  provider="$1"
  executions | sed -n "
    /\"id\" :/ {
      s/.*\"id\" : \"\([^\"]*\)\".*/\1/
      h
    }
    /\"providerId\" : \"$provider\"/ {
      g
      p
      q
    }
  "
}

CUSTOM_EXECUTION_ID="$(execution_id_for "$CUSTOM_PROVIDER" || true)"
if [ -z "$CUSTOM_EXECUTION_ID" ]; then
  /opt/keycloak/bin/kcadm.sh create "authentication/flows/${FLOW}%20forms/executions/execution" -r "$REALM" \
    -s "provider=$CUSTOM_PROVIDER"
  CUSTOM_EXECUTION_ID="$(execution_id_for "$CUSTOM_PROVIDER")"
fi

/opt/keycloak/bin/kcadm.sh update "authentication/flows/$FLOW/executions" -r "$REALM" \
  -b "{\"id\":\"$CUSTOM_EXECUTION_ID\",\"requirement\":\"REQUIRED\"}" \
  -n

STANDARD_EXECUTION_ID="$(execution_id_for "$STANDARD_PROVIDER" || true)"
if [ -n "$STANDARD_EXECUTION_ID" ]; then
  /opt/keycloak/bin/kcadm.sh delete "authentication/executions/$STANDARD_EXECUTION_ID" -r "$REALM"
fi

/opt/keycloak/bin/kcadm.sh create "authentication/executions/$CUSTOM_EXECUTION_ID/raise-priority" -r "$REALM" || true

/opt/keycloak/bin/kcadm.sh update "realms/$REALM" -r master \
  -s "browserFlow=$FLOW" \
  -s "loginTheme=capstone" \
  -s "displayName=Masterbase" \
  -s "internationalizationEnabled=true" \
  -s 'supportedLocales=["es"]' \
  -s "defaultLocale=es"

echo "Browser flow '$FLOW' configured with the Capstone temporary-lock message."
