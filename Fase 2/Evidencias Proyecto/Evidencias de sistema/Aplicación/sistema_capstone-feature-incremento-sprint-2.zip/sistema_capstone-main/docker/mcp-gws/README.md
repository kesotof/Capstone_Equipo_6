# Servidor MCP: Google Workspace (Drive & Docs) para Agentes

Este directorio contiene la configuración del servidor **`google_workspace_mcp` (de Taylor Wilsdon)** para conectar la documentación, minutas y artefactos de Google Drive / Docs del proyecto Capstone a los agentes de IA (Antigravity, Cursor, Claude, etc.).

---

## 1. Características Principales

* **Lectura y Escritura Completa:** Lee carpetas, busca documentos, crea nuevos archivos y actualiza/anexa texto (*append*) en Google Docs sin lidiar con llamadas complejas de la API de Google.
* **Aislamiento Seguro (Mínimo Privilegio):** Mediante una **Service Account**, el agente **únicamente** puede ver y modificar las carpetas de Google Drive que hayan sido compartidas explícitamente con su correo de servicio.
* **Despliegue Contenerizado:** Se ejecuta como servicio Docker (`drive-mcp`) sobre transporte HTTP/SSE (`streamable-http`) en el puerto `8000`.
* **Herramientas Acotadas:** Configurado para exponer exclusivamente herramientas de **Google Drive** y **Google Docs** (`TOOLS="docs drive"`), bloqueando accesos innecesarios a Gmail, Calendar o Contactos.

---

## 2. Configuración de Credenciales (Google Cloud)

Puedes autenticar el servicio usando **Service Account** (recomendado para agentes headless/servidor) o **OAuth 2.0**.

### Opción A: Service Account (Recomendada)

1. En [Google Cloud Console](https://console.cloud.google.com/), crea o selecciona tu proyecto.
2. Habilita las siguientes APIs en **APIs & Services > Library**:
   * **Google Drive API**
   * **Google Docs API**
3. Ve a **IAM & Admin > Service Accounts** y crea una nueva Service Account (ej. `antigravity-docs-mcp`).
4. Entra a la cuenta de servicio creada, ve a la pestaña **Keys > Add Key > Create new key (JSON)**.
5. Guarda el archivo descargado como:
   ```
   docker/mcp-gws/credentials/credentials.json
   ```
6. **Compartir la carpeta en Google Drive:**
   * Abre Google Drive en tu navegador.
   * Crea o selecciona la carpeta del proyecto (ej. `Proyecto_Capstone_Docs`).
   * Haz clic en **Compartir** y añade el correo de tu Service Account (ej. `antigravity-docs-mcp@tu-proyecto.iam.gserviceaccount.com`) con rol de **Editor**.
   * *La Service Account solo tendrá acceso a esa carpeta y sus subcarpetas.*

---

### Opción B: OAuth 2.0 (Cuenta Personal / Workspace)

1. En Google Cloud Console, ve a **APIs & Services > Credentials > Create Credentials > OAuth client ID**.
2. Tipo de aplicación: **Desktop App** o **Web Application**.
3. Descarga el archivo JSON y guárdalo como:
   ```
   docker/mcp-gws/credentials/client_secret.json
   ```

---

## 3. Levantar el Servicio con Docker Compose

Una vez ubicado tu archivo de credenciales (`credentials.json`), levanta el contenedor:

```bash
# Solo el servidor MCP de Drive/Docs
docker compose up -d drive-mcp

# Verificar estado y logs
docker compose logs -f drive-mcp
```

El endpoint del servidor quedará disponible en:
```
http://localhost:8000/mcp
```
Y el healthcheck en:
```
http://localhost:8000/health
```

---

## 4. Conectar tu Agente al Servidor MCP

### Para Google Antigravity

En tu archivo global `~/.gemini/config/mcp_config.json` o en `.agents/mcp_config.json`:

```json
{
  "mcpServers": {
    "workspace-docs": {
      "url": "http://localhost:8000/mcp",
      "serverUrl": "http://localhost:8000/mcp"
    }
  }
}
```

### Para Cursor / Claude Desktop / Cline

```json
{
  "mcpServers": {
    "workspace-docs": {
      "url": "http://localhost:8000/mcp",
      "type": "sse"
    }
  }
}
```

---

---

## 5. Protocolo Obligatorio de Ediciones Seguras (Append-Only & Comentarios)

Para preservar la integridad de los artefactos del proyecto y evitar pérdidas accidentales de información, todos los agentes deben seguir estrictamente este protocolo:

### Reglas de Operación:
1. **Prohibición Total de Borrado o Sobreescritura Completa:**
   - Ningún agente tiene permitido reemplazar (`replace`) la totalidad de un documento, ni eliminar secciones preexistentes creadas por los desarrolladores.
2. **Edición Exclusiva por Anexo (*Append-Only*) y Comentarios:**
   - **En Documentos (.docx / Google Docs):** Las revisiones, sugerencias o nuevo contenido deben registrarse como **Comentarios de Documento** (`manage_document_comment`) o agregarse al final del archivo con el encabezado `[PROPUESTA AGENTE MCP - YYYY-MM-DD]`.
   - **En Hojas de Cálculo (.xlsx / Google Sheets):** Las adiciones deben anexarse al final o en pestañas de propuestas usando `append_table_rows` o comentarios, sin alterar las filas históricas existentes.
3. **Validación y Aplicación Humana (Dev-in-the-Loop):**
   - El equipo de desarrollo humano revisa las propuestas generadas en los comentarios/anexos, las valida y las consolida a mano en la versión final de la entrega.
4. **Lectura de Confirmación Obligatoria:**
   - Inmediatamente después de realizar un anexo o emitir un comentario, el agente **debe ejecutar una lectura de verificación** (`list_document_comments`, `get_drive_file_content` o `read_sheet_values`) para confirmar en vivo que el cambio quedó persistido y legible en Google Drive.

---

## 6. Inventario de Herramientas Recomendadas por Servicio

| Tipo de Archivo | Lectura | Edición / Propuestas Seguras | Verificación |
| :--- | :--- | :--- | :--- |
| **Documentos Word / Docs** (`.docx`, Google Docs) | `get_drive_file_content`, `get_doc_content` | `manage_document_comment` (action: `create`), `modify_doc_text` | `list_document_comments`, `get_doc_content` |
| **Planillas de Cálculo** (`.xlsx`, Google Sheets) | `read_sheet_values`, `get_spreadsheet_info` | `append_table_rows`, `manage_document_comment` | `read_sheet_values`, `list_document_comments` |
| **Carpetas y Archivos Generales** | `search_drive_files`, `list_drive_items` | `manage_drive_access` | `search_drive_files` |

