# ==============================================================================
# Script de Inicialización y Verificación Base (PowerShell) - Sistema Capstone
# ==============================================================================
param(
    [switch]$Clean,
    [switch]$Prune,
    [switch]$Compact
)

$ErrorActionPreference = "Continue"

Write-Host "=== [1/5] Verificando entorno y variables (.env) ===" -ForegroundColor Cyan
if (-not (Test-Path -Path ".env")) {
    Write-Host "Creando .env a partir de .env.example..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
}
Write-Host ".env presente y configurado." -ForegroundColor Green

Write-Host "=== [2/5] Verificando herramientas de sistema (Docker & Compose) ===" -ForegroundColor Cyan
if (Get-Command docker -ErrorAction SilentlyContinue) {
    Write-Host "Docker instalado: $(docker --version)" -ForegroundColor Green
} else {
    Write-Host "ADVERTENCIA: Docker no se encuentra en el PATH actual." -ForegroundColor Yellow
}

if (Get-Command docker-compose -ErrorAction SilentlyContinue) {
    Write-Host "Docker Compose instalado: $(docker-compose --version)" -ForegroundColor Green
} else {
    Write-Host "Comprobando 'docker compose'..."
    docker compose version
}

Write-Host "=== [3/5] Verificando almacenamiento y salud del disco ===" -ForegroundColor Cyan
$cDrive = Get-PSDrive C -ErrorAction SilentlyContinue
if ($cDrive) {
    $freeGB = [math]::Round($cDrive.Free / 1GB, 2)
    $usedGB = [math]::Round($cDrive.Used / 1GB, 2)
    if ($freeGB -lt 10) {
        Write-Host "CRÍTICO: Quedan solo $freeGB GB libres en disco C:. Docker podría fallar al iniciar." -ForegroundColor Red
    } elseif ($freeGB -lt 25) {
        Write-Host "ADVERTENCIA: Quedan $freeGB GB libres en disco C:." -ForegroundColor Yellow
    } else {
        Write-Host "Espacio en disco C: OK ($freeGB GB libres de $([math]::Round(($cDrive.Free+$cDrive.Used)/1GB,2)) GB totales)." -ForegroundColor Green
    }
}

# Monitoreo del archivo de disco virtual de Docker WSL2
$vhdxPath = "$env:LOCALAPPDATA\Docker\wsl\disk\docker_data.vhdx"
if (Test-Path $vhdxPath) {
    $vhdxSizeGB = [math]::Round(((Get-Item $vhdxPath).Length / 1GB), 2)
    Write-Host "Tamaño del disco virtual Docker (VHDX): $vhdxSizeGB GB" -ForegroundColor $(if ($vhdxSizeGB -gt 40) { "Yellow" } else { "White" })
    if ($vhdxSizeGB -gt 50) {
        Write-Host "AVISO: El disco virtual de Docker ha crecido ($vhdxSizeGB GB)." -ForegroundColor Yellow
        Write-Host "       Puedes compactarlo ejecutando: .\scripts\compact-docker-disk.ps1" -ForegroundColor Yellow
    }
}

# Limpieza si se solicita explícitamente o con flags
if ($Clean -or $Prune) {
    Write-Host "--- Ejecutando limpieza preventiva de Docker (builder cache & dangling images) ---" -ForegroundColor Yellow
    docker builder prune -f
    docker image prune -f
}

if ($Compact) {
    & ".\scripts\compact-docker-disk.ps1"
}

Write-Host "=== [4/5] Verificando estructura de directorios del proyecto ===" -ForegroundColor Cyan
$requiredDirs = @(
    "docker/postgres/init",
    "docker/minio",
    "docker/mcp-gws/credentials",
    "frontend/src/views/acceso",
    "frontend/src/views/configuracion",
    "frontend/src/views/documentos",
    "frontend/src/views/flujos",
    "backend/sistema-principal",
    "backend/service-notificaciones",
    "backend/service-ia",
    "tests/e2e/src/specs",
    "tests/e2e/src/pages"
)

foreach ($dir in $requiredDirs) {
    if (-not (Test-Path -Path $dir)) {
        Write-Host "Creando directorio: $dir" -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}
Write-Host "Estructura de directorios validada correctamente." -ForegroundColor Green

Write-Host "=== [5/5] Verificando sintaxis de docker-compose.yml ===" -ForegroundColor Cyan
docker compose config 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Host "docker-compose.yml es sintácticamente válido." -ForegroundColor Green
} else {
    Write-Host "Nota: docker compose config no se ejecutó o requiere Docker Desktop activo." -ForegroundColor Yellow
}

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "Inicialización completada exitosamente." -ForegroundColor Green
Write-Host "Opciones útiles de limpieza de espacio:" -ForegroundColor White
Write-Host "  .\init.ps1 -Clean     # Limpia cachés de construcción e imágenes huérfanas" -ForegroundColor Yellow
Write-Host "  .\scripts\compact-docker-disk.ps1  # Compacta el disco virtual WSL2 en Windows" -ForegroundColor Yellow
Write-Host "Para levantar la infraestructura base de Docker:" -ForegroundColor White
Write-Host "  docker compose up -d postgres keycloak rabbitmq minio minio-init" -ForegroundColor Yellow
Write-Host "Para levantar todos los servicios (incluyendo apps):" -ForegroundColor White
Write-Host "  docker compose --profile apps up -d" -ForegroundColor Yellow
Write-Host "==================================================================" -ForegroundColor Cyan
