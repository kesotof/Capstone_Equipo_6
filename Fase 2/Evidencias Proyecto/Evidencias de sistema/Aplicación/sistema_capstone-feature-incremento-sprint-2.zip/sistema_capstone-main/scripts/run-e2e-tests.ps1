# ==============================================================================
# Script de Ejecución de Pruebas Automatizadas E2E (Playwright en Docker)
# ==============================================================================
param(
    [switch]$UI,
    [switch]$Build,
    [string]$Spec = "",
    [string]$Module = "",
    [switch]$Clean
)

# Mapear módulo a ruta de spec si se especificó
if ($Module -ne "" -and $Spec -eq "") {
    switch ($Module.ToLower()) {
        "auth"       { $Spec = "src/specs/auth" }
        "login"      { $Spec = "src/specs/auth/login-flow.spec.ts" }
        "users"      { $Spec = "src/specs/auth/user-management.spec.ts" }
        "rut"        { $Spec = "src/specs/auth/rut-validation.spec.ts" }
        "org"         { $Spec = "src/specs/org" }
        "flow"        { $Spec = "src/specs/flow" }
        "flow-config" { $Spec = "src/specs/flow/flow-configuration.spec.ts" }
        "sla"         { $Spec = "src/specs/flow/sla-matrix-alerts.spec.ts" }
        "dashboard"   { $Spec = "src/specs/flow/dashboard-flow.spec.ts" }
        "request"    { $Spec = "src/specs/flow/simple-request-flow.spec.ts" }
        "doc"        { $Spec = "src/specs/flow/registrar-documento-sin-planilla.spec.ts" }
        "obs"        { $Spec = "src/specs/flow/ver-observaciones-revisor.spec.ts" }
        "security"   { $Spec = "src/specs/zz-security" }
        default      { $Spec = $Module }
    }
}

$ErrorActionPreference = "Continue"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "   Suite de Pruebas Automatizadas E2E y de Regresión (Playwright)" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 1. Comprobar Docker
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Docker no se encuentra disponible en el PATH." -ForegroundColor Red
    exit 1
}

# 2. Verificar que los contenedores necesarios del sistema se encuentren activos
Write-Host "`n[1/3] Verificando estado de los servicios del sistema..." -ForegroundColor Yellow
$requiredContainers = @("capstone-postgres", "capstone-keycloak", "capstone-frontend")
$missingContainers = @()

foreach ($c in $requiredContainers) {
    $running = docker ps --filter "name=^/${c}$" --filter "status=running" --format "{{.Names}}"
    if (-not $running) {
        $missingContainers += $c
    }
}

if ($missingContainers.Count -gt 0) {
    Write-Host "Los siguientes servicios requeridos no están en ejecución: $($missingContainers -join ', ')" -ForegroundColor Yellow
    Write-Host "Levantando infraestructura y frontend..." -ForegroundColor Cyan
    docker compose --profile apps up -d --build postgres keycloak frontend sistema-principal
    
    Write-Host "Esperando 5 segundos para estabilización de servicios..." -ForegroundColor Gray
    Start-Sleep -Seconds 5
} else {
    Write-Host "Servicios base y frontend activos y respondiendo." -ForegroundColor Green
}

# 2.1 Limpieza y reseteo seguro del entorno si se solicita
if ($Clean) {
    Write-Host "`n[2.1] Limpiando estado de bases de datos antes de la ejecución..." -ForegroundColor Yellow
    & "$PSScriptRoot\clean-test-db.ps1"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "ERROR: Falló el reseteo del entorno de pruebas." -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

# 3. Compilación de imagen de pruebas si se solicita o no existe
$imageExists = docker images -q sistema_capstone-playwright
if ($Build -or (-not $imageExists)) {
    Write-Host "`n[2/3] Construyendo imagen de pruebas Docker (playwright-tests)..." -ForegroundColor Yellow
    docker compose build playwright-tests
    if ($LASTEXITCODE -ne 0) {
        Write-Host "ERROR: Falló la construcción de la imagen de Playwright." -ForegroundColor Red
        exit $LASTEXITCODE
    }
} else {
    Write-Host "`n[2/3] Imagen de pruebas lista (sistema_capstone-playwright)." -ForegroundColor Green
}

# 4. Ejecución de la suite
Write-Host "`n[3/3] Ejecutando suite de pruebas en contenedor..." -ForegroundColor Yellow

if ($UI) {
    Write-Host ">>> Iniciando servidor interactivo Playwright UI Web en puerto 9323 <<<" -ForegroundColor Cyan
    Write-Host ">>> Abre tu navegador en: http://localhost:9323 <<<`n" -ForegroundColor Green
    docker compose run --rm -p 9323:9323 playwright-tests npm run test:ui:web
    $exitCode = $LASTEXITCODE
} else {
    if ($Spec -ne "") {
        docker compose run --rm playwright-tests npx playwright test $Spec
    } else {
        docker compose run --rm playwright-tests npm test
    }
    $exitCode = $LASTEXITCODE
}


Write-Host ""
Write-Host "==================================================================" -ForegroundColor Cyan
if ($exitCode -eq 0) {
    Write-Host "[OK] Todas las pruebas automatizadas pasaron exitosamente." -ForegroundColor Green
    Write-Host "     Grabaciones en video guardadas en: tests/e2e/test-results/" -ForegroundColor Green
} else {
    Write-Host "[FALLO] Se detectaron fallos en la ejecucion de pruebas (Exit Code: $exitCode)." -ForegroundColor Red
    Write-Host "  Revisa las capturas o reportes generados en: tests/e2e/test-results/" -ForegroundColor Yellow
}
Write-Host "==================================================================" -ForegroundColor Cyan

exit $exitCode

