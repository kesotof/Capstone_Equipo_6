# ==============================================================================
# Script de Limpieza y Reseteo Seguro del Entorno de Pruebas (Clean & Reset DB)
# ==============================================================================
param(
    [string]$KeycloakUrl = "http://localhost:8080",
    [string]$KeycloakAdminUser = "admin",
    [string]$KeycloakAdminPass = "admin_secure_pass",
    [string]$KeycloakRealm = "capstone-realm"
)

$ErrorActionPreference = "Stop"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "   Limpieza y Reseteo Seguro de Bases de Datos y Entorno de Tests " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 1. Verificar contenedores requeridos
Write-Host "`n[1/5] Verificando contenedores de infraestructura..." -ForegroundColor Yellow
$required = @("capstone-postgres", "capstone-keycloak", "capstone-minio")
foreach ($c in $required) {
    $running = docker ps --filter "name=^/${c}$" --filter "status=running" --format "{{.Names}}"
    if (-not $running) {
        Write-Host "ERROR: El contenedor $c debe estar en ejecucion." -ForegroundColor Red
        exit 1
    }
}
Write-Host "Contenedores activos." -ForegroundColor Green

# 2. Reseteo y Sincronizacion en Keycloak
Write-Host "`n[2/5] Restableciendo estado de usuarios en Keycloak ($KeycloakRealm)..." -ForegroundColor Yellow

# 2.1 Obtener token admin de Keycloak
$authBody = @{
    grant_type = "password"
    client_id  = "admin-cli"
    username   = $KeycloakAdminUser
    password   = $KeycloakAdminPass
}
$tokenResp = Invoke-RestMethod -Uri "$KeycloakUrl/realms/master/protocol/openid-connect/token" -Method Post -Body $authBody
$adminToken = $tokenResp.access_token
$authHeader = @{ Authorization = "Bearer $adminToken" }

# 2.2 Obtener roles del realm
$realmRoles = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/roles" -Headers $authHeader
$adminRole = $realmRoles | Where-Object { $_.name -eq "ADMIN" }
$approverRole = $realmRoles | Where-Object { $_.name -eq "APPROVER" }

if (-not $adminRole) {
    Write-Host "Creando rol ADMIN en Keycloak..." -ForegroundColor Gray
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/roles" -Method Post -Headers $authHeader -Body (@{name="ADMIN"; description="Administrador del sistema"} | ConvertTo-Json) -ContentType "application/json"
    $realmRoles = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/roles" -Headers $authHeader
    $adminRole = $realmRoles | Where-Object { $_.name -eq "ADMIN" }
}
if (-not $approverRole) {
    Write-Host "Creando rol APPROVER en Keycloak..." -ForegroundColor Gray
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/roles" -Method Post -Headers $authHeader -Body (@{name="APPROVER"; description="Usuario operativo"} | ConvertTo-Json) -ContentType "application/json"
    $realmRoles = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/roles" -Headers $authHeader
    $approverRole = $realmRoles | Where-Object { $_.name -eq "APPROVER" }
}

# 2.3 Listar usuarios actuales
$users = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users" -Headers $authHeader

# 2.4 Limpiar usuarios de prueba no base
$baseEmails = @("admin@capstone.local", "revisor@capstone.local")
foreach ($u in $users) {
    if ($u.email -notin $baseEmails) {
        Write-Host "Eliminando usuario residual de prueba: $($u.email) ($($u.id))..." -ForegroundColor Gray
        Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($u.id)" -Method Delete -Headers $authHeader
    }
}

# 2.5 Asegurar usuario admin@capstone.local
$adminKc = $users | Where-Object { $_.email -eq "admin@capstone.local" }
if (-not $adminKc) {
    Write-Host "Creando usuario admin@capstone.local en Keycloak..." -ForegroundColor Gray
    $createAdminBody = @{
        username      = "admin"
        email         = "admin@capstone.local"
        firstName     = "Admin"
        lastName      = "Capstone"
        enabled       = $true
        emailVerified = $true
    } | ConvertTo-Json
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users" -Method Post -Headers $authHeader -Body $createAdminBody -ContentType "application/json"
    $users = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users" -Headers $authHeader
    $adminKc = $users | Where-Object { $_.email -eq "admin@capstone.local" }
}

# Restablecer contraseña y habilitar admin
$adminPwdBody = @{
    type      = "password"
    value     = "admin123"
    temporary = $false
} | ConvertTo-Json
Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($adminKc.id)/reset-password" -Method Put -Headers $authHeader -Body $adminPwdBody -ContentType "application/json"

$adminUpdate = @{
    enabled = $true
    emailVerified = $true
} | ConvertTo-Json
Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($adminKc.id)" -Method Put -Headers $authHeader -Body $adminUpdate -ContentType "application/json"

# Asignar rol ADMIN
$adminRoleJson = "[{`"id`":`"$($adminRole.id)`",`"name`":`"$($adminRole.name)`"}]"
try {
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($adminKc.id)/role-mappings/realm" -Method Post -Headers $authHeader -Body $adminRoleJson -ContentType "application/json"
} catch {}

# Limpiar posibles bloqueos por fuerza bruta
try {
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/attack-detection/brute-force/users/$($adminKc.id)" -Method Delete -Headers $authHeader
} catch {}

# 2.6 Asegurar usuario revisor@capstone.local
$revisorKc = $users | Where-Object { $_.email -eq "revisor@capstone.local" }
if (-not $revisorKc) {
    Write-Host "Creando usuario revisor@capstone.local en Keycloak..." -ForegroundColor Gray
    $createRevisorBody = @{
        username      = "revisor"
        email         = "revisor@capstone.local"
        firstName     = "Revisor"
        lastName      = "Documental"
        enabled       = $true
        emailVerified = $true
    } | ConvertTo-Json
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users" -Method Post -Headers $authHeader -Body $createRevisorBody -ContentType "application/json"
    $users = Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users" -Headers $authHeader
    $revisorKc = $users | Where-Object { $_.email -eq "revisor@capstone.local" }
}

# Restablecer contraseña y habilitar revisor
$revisorPwdBody = @{
    type      = "password"
    value     = "revisor123"
    temporary = $false
} | ConvertTo-Json
Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($revisorKc.id)/reset-password" -Method Put -Headers $authHeader -Body $revisorPwdBody -ContentType "application/json"

$revisorUpdate = @{
    enabled = $true
    emailVerified = $true
} | ConvertTo-Json
Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($revisorKc.id)" -Method Put -Headers $authHeader -Body $revisorUpdate -ContentType "application/json"

# Asignar rol APPROVER
$approverRoleJson = "[{`"id`":`"$($approverRole.id)`",`"name`":`"$($approverRole.name)`"}]"
try {
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/users/$($revisorKc.id)/role-mappings/realm" -Method Post -Headers $authHeader -Body $approverRoleJson -ContentType "application/json"
} catch {}

# Limpiar bloqueos de fuerza bruta
try {
    Invoke-RestMethod -Uri "$KeycloakUrl/admin/realms/$KeycloakRealm/attack-detection/brute-force/users/$($revisorKc.id)" -Method Delete -Headers $authHeader
} catch {}

Write-Host "Usuarios base en Keycloak listos:" -ForegroundColor Green
Write-Host "  - admin@capstone.local (ID: $($adminKc.id), Rol: ADMIN)"
Write-Host "  - revisor@capstone.local (ID: $($revisorKc.id), Rol: APPROVER)"

# 3. Limpieza de Base de Datos PostgreSQL (sistema_db)
Write-Host "`n[3/5] Limpiando tablas de datos y sincronizando usuarios en PostgreSQL (sistema_db)..." -ForegroundColor Yellow

$sqlClean = @"
BEGIN;
-- Limpiar tablas transaccionales de solicitudes, flujos y auditoría
TRUNCATE TABLE observacion CASCADE;
TRUNCATE TABLE documento CASCADE;
TRUNCATE TABLE notificacion CASCADE;
TRUNCATE TABLE solicitud_transicion CASCADE;
TRUNCATE TABLE solicitud CASCADE;
DELETE FROM flujo_etapa WHERE flujo_definicion_id > 1;
DELETE FROM transicion WHERE flujo_definicion_id > 1;
DELETE FROM flujo_definicion WHERE id > 1;

-- Asegurar flujo base 'Revisión Simple' (id 1)
INSERT INTO flujo_definicion (id, nombre, descripcion, activo)
VALUES (1, E'Revisi\u00f3n Simple', E'Flujo de 1 etapa para revisi\u00f3n de documentos', true)
ON CONFLICT (id) DO UPDATE SET nombre = E'Revisi\u00f3n Simple', activo = true, descripcion = E'Flujo de 1 etapa para revisi\u00f3n de documentos';

INSERT INTO flujo_etapa (id, flujo_definicion_id, orden, nombre)
VALUES (1, 1, 1, E'Revisi\u00f3n')
ON CONFLICT (id) DO UPDATE SET orden = 1, nombre = E'Revisi\u00f3n';

INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 1, 1, NULL, 1, 1 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 1);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 2, 1, 1, 3, 2 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 2);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 3, 1, 1, 4, 3 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 3);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 4, 1, 1, 2, 4 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 4);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 5, 1, 2, 1, 5 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 5);

SELECT setval(pg_get_serial_sequence('flujo_definicion', 'id'), COALESCE(max(id), 1)) FROM flujo_definicion;
SELECT setval(pg_get_serial_sequence('flujo_etapa', 'id'), COALESCE(max(id), 1)) FROM flujo_etapa;
SELECT setval(pg_get_serial_sequence('transicion', 'id'), COALESCE(max(id), 1)) FROM transicion;

TRUNCATE TABLE audit_events CASCADE;
TRUNCATE TABLE log_evento CASCADE;

-- Limpiar y restaurar reglas SLA iniciales
DELETE FROM sla_config WHERE tipo_documento NOT IN ('Contrato', 'Factura', 'Informe', 'Memorando', 'General');
UPDATE sla_config SET plazo_dias = 5 WHERE tipo_documento = 'Contrato';
UPDATE sla_config SET plazo_dias = 3 WHERE tipo_documento = 'Factura';
UPDATE sla_config SET plazo_dias = 7 WHERE tipo_documento = 'Informe';
UPDATE sla_config SET plazo_dias = 2 WHERE tipo_documento = 'Memorando';
UPDATE sla_config SET plazo_dias = 5 WHERE tipo_documento = 'General';

-- Limpiar áreas y asociaciones de área
UPDATE usuario SET area_id = NULL;
UPDATE area SET administrador_id = NULL;
DELETE FROM area;

-- Limpiar usuarios residuales en usuario_rol y usuario
DELETE FROM usuario_rol WHERE usuario_id NOT IN (
    SELECT id FROM usuario WHERE email IN ('admin@capstone.local', 'revisor@capstone.local')
);
DELETE FROM usuario WHERE email NOT IN ('admin@capstone.local', 'revisor@capstone.local');
UPDATE usuario SET rut = NULL WHERE email IN ('admin@capstone.local', 'revisor@capstone.local');

-- Limpiar usuarios residuales en app_user_roles y app_users
DELETE FROM app_user_roles WHERE user_id NOT IN (
    SELECT id FROM app_users WHERE email IN ('admin@capstone.local', 'revisor@capstone.local')
);
DELETE FROM app_users WHERE email NOT IN ('admin@capstone.local', 'revisor@capstone.local');

-- Sincronizar usuario admin
INSERT INTO app_users (id, email, first_name, last_name, enabled, keycloak_user_id, created_at)
VALUES (
    gen_random_uuid(),
    'admin@capstone.local',
    'Admin',
    'Capstone',
    true,
    '$($adminKc.id)',
    NOW()
)
ON CONFLICT (email) DO UPDATE SET
    keycloak_user_id = EXCLUDED.keycloak_user_id,
    enabled = true,
    first_name = 'Admin',
    last_name = 'Capstone';

-- Sincronizar usuario revisor
INSERT INTO app_users (id, email, first_name, last_name, enabled, keycloak_user_id, created_at)
VALUES (
    gen_random_uuid(),
    'revisor@capstone.local',
    'Revisor',
    'Documental',
    true,
    '$($revisorKc.id)',
    NOW()
)
ON CONFLICT (email) DO UPDATE SET
    keycloak_user_id = EXCLUDED.keycloak_user_id,
    enabled = true,
    first_name = 'Revisor',
    last_name = 'Documental';

-- Asignar roles a admin
DELETE FROM app_user_roles WHERE user_id = (SELECT id FROM app_users WHERE email = 'admin@capstone.local');
INSERT INTO app_user_roles (user_id, role)
SELECT u.id, 'ADMIN' FROM app_users u WHERE u.email = 'admin@capstone.local';

-- Asignar roles a revisor
DELETE FROM app_user_roles WHERE user_id = (SELECT id FROM app_users WHERE email = 'revisor@capstone.local');
INSERT INTO app_user_roles (user_id, role)
SELECT u.id, 'APPROVER' FROM app_users u WHERE u.email = 'revisor@capstone.local';

-- Asegurar roles en usuario_rol
DELETE FROM usuario_rol WHERE usuario_id = (SELECT id FROM usuario WHERE email = 'admin@capstone.local');
INSERT INTO usuario_rol (usuario_id, rol_id)
SELECT u.id, 1 FROM usuario u WHERE u.email = 'admin@capstone.local';

DELETE FROM usuario_rol WHERE usuario_id = (SELECT id FROM usuario WHERE email = 'revisor@capstone.local');
INSERT INTO usuario_rol (usuario_id, rol_id)
SELECT u.id, rf.id FROM usuario u CROSS JOIN rol_flujo rf WHERE u.email = 'revisor@capstone.local' AND rf.nombre IN ('APPROVER', 'REVISOR', 'EMISOR');

-- Mantener etapa 1 de Revisión Simple sin revisor explícito según invariante del catálogo
UPDATE flujo_etapa SET revisor_id = NULL WHERE id = 1;

COMMIT;
"@

# Ejecutar SQL en postgres
$cleanProcess = docker exec -i capstone-postgres psql -v ON_ERROR_STOP=1 -U sistema_user -d sistema_db -c "$sqlClean"
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Falló la ejecución del script SQL de reseteo." -ForegroundColor Red
    exit $LASTEXITCODE
}
Write-Host "Base de datos sistema_db restablecida con éxito." -ForegroundColor Green

# 4. Limpieza de Archivos en MinIO S3
Write-Host "`n[4/5] Vaciando bucket de documentos en MinIO S3..." -ForegroundColor Yellow
docker exec capstone-minio mc alias set local http://localhost:9000 minioadmin minioadmin_secure_pass | Out-Null
docker exec capstone-minio mc rm --recursive --force local/documentos/ | Out-Null
Write-Host "Bucket 'documentos' vaciado correctamente." -ForegroundColor Green

# 5. Purgar Colas de RabbitMQ
Write-Host "`n[5/5] Purgando colas residuales en RabbitMQ..." -ForegroundColor Yellow
$queues = @("ai.results.queue", "ai.tasks.queue", "notifications.email.queue")
foreach ($q in $queues) {
    try {
        docker exec capstone-rabbitmq rabbitmqctl purge_queue $q | Out-Null
    } catch {}
}
Write-Host "Colas de RabbitMQ purgadas." -ForegroundColor Green

Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "   Entorno de Pruebas Restablecido y Listo para Testing Limpio!   " -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Cyan
