#!/usr/bin/env bash
# ==============================================================================
# Script de Limpieza y Reseteo Seguro del Entorno de Pruebas (Bash)
# ==============================================================================
set -euo pipefail

KEYCLOAK_URL="${KEYCLOAK_URL:-http://localhost:8080}"
KEYCLOAK_ADMIN_USER="${KEYCLOAK_ADMIN_USER:-admin}"
KEYCLOAK_ADMIN_PASS="${KEYCLOAK_ADMIN_PASS:-admin_secure_pass}"
KEYCLOAK_REALM="${KEYCLOAK_REALM:-capstone-realm}"

echo "=================================================================="
echo "   Limpieza y Reseteo Seguro de Bases de Datos y Entorno de Tests "
echo "=================================================================="

# 1. Verificar contenedores
echo -e "\n[1/5] Verificando contenedores de infraestructura..."
for c in capstone-postgres capstone-keycloak capstone-minio; do
    if ! docker ps --filter "name=^/${c}$" --filter "status=running" --format "{{.Names}}" | grep -q "${c}"; then
        echo "ERROR: El contenedor ${c} debe estar en ejecucion."
        exit 1
    fi
done

# 2. Token de Keycloak
echo -e "\n[2/5] Restableciendo estado de usuarios en Keycloak (${KEYCLOAK_REALM})..."
TOKEN=$(curl -s -X POST "${KEYCLOAK_URL}/realms/master/protocol/openid-connect/token" \
  -d "grant_type=password&client_id=admin-cli&username=${KEYCLOAK_ADMIN_USER}&password=${KEYCLOAK_ADMIN_PASS}" \
  | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)

# Limpiar usuarios ajenos y asegurar admin/revisor
USERS_JSON=$(curl -s -H "Authorization: Bearer ${TOKEN}" "${KEYCLOAK_URL}/admin/realms/${KEYCLOAK_REALM}/users")

# Eliminar usuarios residuales que no sean admin o revisor
for row in $(echo "${USERS_JSON}" | grep -o '{"id":"[^"]*","createdTimestamp":[0-9]*,"username":"[^"]*","enabled":[a-z]*,"totp":[a-z]*,"emailVerified":[a-z]*,"firstName":"[^"]*","lastName":"[^"]*","email":"[^"]*' || true); do
    EMAIL=$(echo "$row" | grep -o '"email":"[^"]*' | cut -d'"' -f4 || true)
    ID=$(echo "$row" | grep -o '"id":"[^"]*' | cut -d'"' -f4 || true)
    if [ -n "$EMAIL" ] && [ "$EMAIL" != "admin@capstone.local" ] && [ "$EMAIL" != "revisor@capstone.local" ]; then
        echo "Eliminando usuario residual: ${EMAIL} (${ID})"
        curl -s -X DELETE -H "Authorization: Bearer ${TOKEN}" "${KEYCLOAK_URL}/admin/realms/${KEYCLOAK_REALM}/users/${ID}" > /dev/null || true
    fi
done

# 3. Limpiar Base de Datos PostgreSQL
echo -e "\n[3/5] Limpiando tablas de datos y sincronizando usuarios en PostgreSQL (sistema_db)..."
docker exec -i capstone-postgres psql -U sistema_user -d sistema_db <<-EOSQL
BEGIN;
TRUNCATE TABLE observacion CASCADE;
TRUNCATE TABLE documento CASCADE;
TRUNCATE TABLE notificacion CASCADE;
TRUNCATE TABLE solicitud_transicion CASCADE;
TRUNCATE TABLE solicitud CASCADE;
DELETE FROM flujo_etapa WHERE flujo_definicion_id > 1;
DELETE FROM transicion WHERE flujo_definicion_id > 1;
DELETE FROM flujo_definicion WHERE id > 1;

-- Asegurar flujo base 'Revisión Simple' (id 1)
INSERT INTO flujo_definicion (id, nombre, descripcion, activo)
VALUES (1, 'Revisión Simple', 'Flujo de 1 etapa para revisión de documentos', true)
ON CONFLICT (id) DO UPDATE SET nombre = 'Revisión Simple', activo = true, descripcion = 'Flujo de 1 etapa para revisión de documentos';

INSERT INTO flujo_etapa (id, flujo_definicion_id, orden, nombre)
VALUES (1, 1, 1, 'Revisión')
ON CONFLICT (id) DO UPDATE SET orden = 1, nombre = 'Revisión';

INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 1, 1, NULL, 1, 1 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 1);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 2, 1, 1, 3, 2 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 2);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 3, 1, 1, 4, 3 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 3);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 4, 1, 1, 2, 4 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 4);
INSERT INTO transicion (id, flujo_definicion_id, estado_origen_id, estado_destino_id, accion_usuario_id)
SELECT 5, 1, 2, 1, 5 WHERE NOT EXISTS (SELECT 1 FROM transicion WHERE id = 5);

SELECT setval(pg_get_serial_sequence('flujo_definicion', 'id'), COALESCE(max(id), 1)) FROM flujo_definicion;
SELECT setval(pg_get_serial_sequence('flujo_etapa', 'id'), COALESCE(max(id), 1)) FROM flujo_etapa;
SELECT setval(pg_get_serial_sequence('transicion', 'id'), COALESCE(max(id), 1)) FROM transicion;

TRUNCATE TABLE audit_events CASCADE;
TRUNCATE TABLE log_evento CASCADE;

-- Limpiar y restaurar reglas SLA iniciales
DELETE FROM sla_config WHERE tipo_documento NOT IN ('Contrato', 'Factura', 'Informe', 'Memorando', 'General');
UPDATE sla_config SET plazo_dias = 5 WHERE tipo_documento = 'Contrato';
UPDATE sla_config SET plazo_dias = 3 WHERE tipo_documento = 'Factura';
UPDATE sla_config SET plazo_dias = 7 WHERE tipo_documento = 'Informe';
UPDATE sla_config SET plazo_dias = 2 WHERE tipo_documento = 'Memorando';
UPDATE sla_config SET plazo_dias = 5 WHERE tipo_documento = 'General';

-- Limpiar áreas y asociaciones de área
UPDATE usuario SET area_id = NULL;
UPDATE area SET administrador_id = NULL;
DELETE FROM area;

DELETE FROM usuario_rol WHERE usuario_id NOT IN (
    SELECT id FROM usuario WHERE email IN ('admin@capstone.local', 'revisor@capstone.local')
);
DELETE FROM usuario WHERE email NOT IN ('admin@capstone.local', 'revisor@capstone.local');
UPDATE usuario SET rut = NULL WHERE email IN ('admin@capstone.local', 'revisor@capstone.local');

DELETE FROM app_user_roles WHERE user_id NOT IN (
    SELECT id FROM app_users WHERE email IN ('admin@capstone.local', 'revisor@capstone.local')
);
DELETE FROM app_users WHERE email NOT IN ('admin@capstone.local', 'revisor@capstone.local');

COMMIT;
EOSQL

# 4. Limpieza MinIO S3
echo -e "\n[4/5] Vaciando bucket de documentos en MinIO S3..."
docker exec capstone-minio mc alias set local http://localhost:9000 minioadmin minioadmin_secure_pass > /dev/null 2>&1 || true
docker exec capstone-minio mc rm --recursive --force local/documentos/ > /dev/null 2>&1 || true

# 5. RabbitMQ
echo -e "\n[5/5] Purgando colas en RabbitMQ..."
for q in ai.results.queue ai.tasks.queue notifications.email.queue; do
    docker exec capstone-rabbitmq rabbitmqctl purge_queue "$q" > /dev/null 2>&1 || true
done

echo -e "\n[OK] Entorno restablecido exitosamente."
