# ==============================================================================
# Script de Compactación de Disco Virtual Docker Desktop (WSL2)
# ==============================================================================
# Este script requiere permisos de Administrador para ejecutar diskpart.
# Si no es Administrador, solicitará elevación UAC automáticamente.

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Solicitando permisos de Administrador..." -ForegroundColor Yellow
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$vhdxPath = "$env:LOCALAPPDATA\Docker\wsl\disk\docker_data.vhdx"

if (-not (Test-Path $vhdxPath)) {
    Write-Error "No se encontró el archivo de disco virtual en: $vhdxPath"
    pause
    exit 1
}

$initialSizeGB = [math]::Round(((Get-Item $vhdxPath).Length / 1GB), 2)
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "COMPACTACIÓN DE DISCO DOCKER WSL2" -ForegroundColor Cyan
Write-Host "Tamaño actual del VHDX: $initialSizeGB GB" -ForegroundColor Yellow
Write-Host "==================================================================" -ForegroundColor Cyan

Write-Host "1. Deteniendo procesos de Docker y apagando WSL..." -ForegroundColor Yellow
Get-Process *docker* -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
wsl --shutdown
Start-Sleep -Seconds 3

Write-Host "2. Ejecutando compactación mediante diskpart..." -ForegroundColor Yellow
$scriptFile = [System.IO.Path]::GetTempFileName()
@"
select vdisk file="$vhdxPath"
attach vdisk readonly
compact vdisk
detach vdisk
"@ | Set-Content -Path $scriptFile -Encoding ASCII

diskpart /s $scriptFile
Remove-Item $scriptFile -Force

$finalSizeGB = [math]::Round(((Get-Item $vhdxPath).Length / 1GB), 2)
$savedGB = [math]::Round(($initialSizeGB - $finalSizeGB), 2)

Write-Host "==================================================================" -ForegroundColor Green
Write-Host "COMPACTACIÓN COMPLETADA CON ÉXITO" -ForegroundColor Green
Write-Host "Tamaño previo: $initialSizeGB GB" -ForegroundColor White
Write-Host "Tamaño nuevo:  $finalSizeGB GB" -ForegroundColor White
Write-Host "Espacio recuperado: $savedGB GB" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "Ya puedes abrir Docker Desktop nuevamente." -ForegroundColor Cyan
pause
