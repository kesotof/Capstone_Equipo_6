import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';

test.describe('Seguridad y Fuerza Bruta OIDC en Keycloak (Regresión)', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
  });

  test('1. [CA 1.3] Debe bloquear temporalmente el acceso por 30 minutos tras 4 intentos fallidos consecutivos mostrando mensaje explícito en pantalla', async ({ request }) => {
    const keycloakUrl = process.env.KEYCLOAK_HOST
      ? `http://${process.env.KEYCLOAK_HOST}:${process.env.KEYCLOAK_PORT || '8080'}`
      : 'http://localhost:8080';

    // 1. Obtener token de administración de Keycloak
    const tokenResp = await request.post(`${keycloakUrl}/realms/master/protocol/openid-connect/token`, {
      form: {
        grant_type: 'password',
        client_id: 'admin-cli',
        username: 'admin',
        password: 'admin_secure_pass'
      }
    });
    expect(tokenResp.ok()).toBeTruthy();
    const { access_token } = await tokenResp.json();

    const bruteEmail = `brute_${Date.now()}@capstone.local`;
    const brutePass = 'CorrectPass123!';

    // 2. Crear usuario temporal de prueba en capstone-realm
    const createResp = await request.post(`${keycloakUrl}/admin/realms/capstone-realm/users`, {
      headers: { Authorization: `Bearer ${access_token}` },
      data: {
        username: bruteEmail,
        email: bruteEmail,
        enabled: true,
        credentials: [{ type: 'password', value: brutePass, temporary: false }]
      }
    });
    expect(createResp.status()).toBe(201);

    // Obtener ID del usuario creado para limpieza posterior
    const usersResp = await request.get(`${keycloakUrl}/admin/realms/capstone-realm/users?email=${encodeURIComponent(bruteEmail)}`, {
      headers: { Authorization: `Bearer ${access_token}` }
    });
    const users = await usersResp.json();
    const userId = users[0]?.id;

    try {
      await loginPage.goto();
      await loginPage.isDisplayed();

      // 3. Ejecutar 4 intentos consecutivos con contraseña errónea (con pausa de 1.2s para el detector)
      for (let attempt = 1; attempt <= 4; attempt++) {
        await loginPage.login(bruteEmail, `wrong_pass_${attempt}`);
        const errorText = await loginPage.getErrorMessage();
        if (attempt < 4) {
          expect(errorText.toLowerCase()).toContain('credenciales invalidas');
          await new Promise(r => setTimeout(r, 1200));
        }
      }

      // 4. Tras los fallos, intentar ingresar (incluso con la clave correcta) debe ser rechazado
      // mostrando claramente que la cuenta está bloqueada temporalmente por 30 minutos
      await new Promise(r => setTimeout(r, 1200));
      await loginPage.login(bruteEmail, brutePass);

      const lockError = await loginPage.getErrorMessage();
      console.log('Mensaje de bloqueo observado tras 4 fallos:', lockError);
      expect(lockError.toLowerCase()).toContain('demasiados intentos de inicio de sesión fallidos');
      expect(lockError.toLowerCase()).toContain('30 minutos');
    } finally {
      // 5. Limpieza: eliminar usuario temporal de prueba
      if (userId) {
        await request.delete(`${keycloakUrl}/admin/realms/capstone-realm/users/${userId}`, {
          headers: { Authorization: `Bearer ${access_token}` }
        });
      }
    }
  });
});
