# Especificación de Pruebas E2E - Sprint 1 (Playwright)

Este documento define la estrategia, flujos de prueba y mapeo de criterios de aceptación para la suite de pruebas End-to-End (E2E) con Playwright correspondiente al **Sprint 1: Sesiones, Flujo Base y Notificaciones**.

---

## 1. Principios de Diseño de Pruebas E2E

1. **Flujos Integrales de Usuario (Multi-Criterio)**:
   - En lugar de ejecutar pruebas atómicas aisladas que reinician el navegador en cada paso, cada suite simula una jornada completa de usuario (*User Journey*).
   - Un solo flujo E2E valida múltiples criterios de aceptación de forma encadenada (ej. validación de campos vacíos -> subida errónea -> subida correcta -> aparición en lista -> consulta de estado).
2. **Definición de Terminado (DoD) con Validación Visual**:
   - Una historia de usuario se considera terminada cuando su código está completo, la suite E2E automatizada pasa sin fallos y el **desarrollador verifica visualmente el flujo interactivo** (vía `.\scripts\run-e2e-tests.ps1 -UI` o navegador local `--headed`).
3. **Reseteo Determinista del Entorno**:
   - Para garantizar repetibilidad sin contaminación de datos previos, se utiliza el script `scripts/clean-test-db.ps1` (o flag `-Clean` en `run-e2e-tests.ps1`), el cual restablece PostgreSQL, Keycloak, MinIO S3 y RabbitMQ en menos de 6 segundos.

---

## 2. Catálogo de Suites de Prueba E2E (Sprint 1)

### `E2E-AUTH-01`: Flujo Completo de Autenticación OIDC, Control de Acceso y Logout Seguro
- **Archivo**: `src/specs/auth/login-flow.spec.ts` (6 tests)
- **Historias de Usuario Cubiertas**: `HU-01: Iniciar Sesión` (`auth-001`), `HU-02: Cerrar Sesión` (`auth-002`)
- **Criterios de Aceptación Verificados**:
  - `CA 1.1`: Formato de correo obligatorio en credenciales.
  - `CA 1.2`: Mensaje de error ante credenciales inválidas.
  - `CA 1.3`: Bloqueo por 30 minutos tras 4 intentos fallidos.
  - `CA 1.4`: Acceso exitoso al Dashboard tras login válido.
  - `CA 1.5`: Protección de rutas del sistema contra accesos sin sesión.
  - `CA 1.6`: Registro de auditoría de inicio de sesión (`app_audit_events`).
  - `CA 2.1 - 2.4`: Cierre de sesión, revocación de tokens y registro de auditoría de logout.
- **Estado**: **100% IMPLEMENTADO Y PASSING (6/6)**

---

### `E2E-USER-01`: Ciclo de Gestión de Usuarios y Restricción RBAC
- **Archivo**: `src/specs/auth/user-management.spec.ts` (9 tests)
- **Historias de Usuario Cubiertas**: `HU-03: Gestionar Usuarios` (`auth-003`)
- **Criterios de Aceptación Verificados**:
  - `CA 3.1`: Creación de usuario y validación de login en Keycloak y UI.
  - `CA 3.2`: Modificación de datos de usuario (nombre, apellido y contraseña).
  - `CA 3.3`: Desactivación lógica de usuario con bloqueo inmediato de acceso.
  - `CA 3.4`: Bloqueo ante correos duplicados.
  - `CA 3.5`: Restricción estricta de permisos: usuarios con rol `APPROVER` no ven la UI y reciben 401/403 en API.
  - `CA 3.6`: Registro de auditoría de eventos de gestión en base de datos (`log_evento`).
- **Estado**: **100% IMPLEMENTADO Y PASSING (9/9)**

---

### `E2E-DASH-01`: Dashboard de Solicitudes y Acciones Pendientes
- **Archivo**: `src/specs/flow/dashboard-flow.spec.ts` (4 tests)
- **Historias de Usuario Cubiertas**: `HU-05: Ver revisiones pendientes` (`flow-001`), `HU-09`
- **Criterios de Aceptación Verificados**:
  - `CA 5.1, 5.2`: Contadores de resumen, accesos directos y estructura general del dashboard.
  - `CA 5.3`: Aparición inmediata de nuevas solicitudes en la sección de acciones pendientes de revisión.
  - `CA 5.4`: Deep-linking interactivo directo desde el botón "Revisar" hacia la pantalla de revisión.
  - `CA 5.5, 9.1`: Sección dedicada a solicitudes que requieren subsanación por parte del emisor con observación previsualizada.
- **Estado**: **100% IMPLEMENTADO Y PASSING (4/4)**

---

### `E2E-DOC-01`: Registro de Documento sin Planilla
- **Archivo**: `src/specs/flow/registrar-documento-sin-planilla.spec.ts` (4 tests)
- **Historias de Usuario Cubiertas**: `HU-04: Registrar documento sin planilla` (`doc-001`)
- **Criterios de Aceptación Verificados**:
  - `CA 4.1`: Validación de extensiones y tipos MIME (`.pdf`, `.docx`, `.doc`, etc.) con bloqueo de ejecutables o no permitidos.
  - `CA 4.2`: Validación de campos obligatorios con códigos HTTP 400 y mensajes de error interactivos.
  - `CA 4.3`: Confirmación visual inmediata y almacenamiento exitoso en MinIO S3 y Postgres.
  - `CA 4.4`: Aparición inmediata en el listado de solicitudes del emisor con estado inicial `"Pendiente de revisión"`.
- **Estado**: **100% IMPLEMENTADO Y PASSING (4/4)**

---

### `E2E-FLOW-01`: Ciclo de Vida Completo de Solicitud Simple
- **Archivo**: `src/specs/flow/simple-request-flow.spec.ts` (7 tests)
- **Historias de Usuario Cubiertas**: `HU-04`, `HU-05`, `HU-06`, `HU-07`, `HU-08`, `HU-09`, `HU-10`, `HU-11`, `HU-12`
- **Criterios de Aceptación Verificados**:
  - Test 1 (`HU-04`): Registro de solicitud simple con archivo adjunto.
  - Test 2 (`HU-05`, `HU-08`): Revisión por aprobador, descarga de archivo y solicitud de corrección con observación obligatoria.
  - Test 3 (`HU-09`, `HU-10`): Emisor consulta observaciones del revisor, edita la solicitud y reenvía a revisión.
  - Test 4 (`HU-06`): Aprobador revisa versión corregida y aprueba definitivamente con modal de confirmación.
  - Test 5 (`HU-07`): Rechazo definitivo con motivo justificado obligatorio y bloqueo de transición sin motivo.
  - Test 6 (`HU-12`): Bandeja in-app de notificaciones, contador de no leídas y marcado como leída.
  - Test 7 (`HU-11`): Historial cronológico inmutable de eventos y transiciones en "Estado de solicitudes".
- **Estado**: **100% IMPLEMENTADO Y PASSING (7/7)**

---

### `E2E-OBS-01`: Ver Observaciones del Revisor y Control de Acceso
- **Archivo**: `src/specs/flow/ver-observaciones-revisor.spec.ts` (3 tests)
- **Historias de Usuario Cubiertas**: `HU-09: Ver observaciones del revisor` (`flow-005`)
- **Criterios de Aceptación Verificados**:
  - `CA 9.1`: Despliegue de observaciones y motivos de devolución dentro del detalle de la solicitud correspondiente.
  - `CA 9.2`: Control de acceso y denegación (401/403) a usuarios no autorizados o ajenos a la solicitud.
  - `CA 9.3`: Persistencia y disponibilidad continua de las observaciones mientras la solicitud permanezca en corrección, incluso durante la edición interactiva del emisor.
- **Estado**: **100% IMPLEMENTADO Y PASSING (3/3)**

---

## 3. Matriz de Cobertura E2E vs Criterios de Aceptación (33/33 Tests PASSING)

| Historia de Usuario | Código Trello / Backlog | Criterios de Aceptación Cubiertos | Suite E2E de Verificación | Estado |
| :--- | :--- | :--- | :--- | :--- |
| **HU-01: Iniciar Sesión** | `auth-001` | CA 1.1, CA 1.2, CA 1.3, CA 1.4, CA 1.5, CA 1.6 | `login-flow.spec.ts` | **PASSING** |
| **HU-02: Cerrar Sesión** | `auth-002` | CA 2.1, CA 2.2, CA 2.3, CA 2.4 | `login-flow.spec.ts` | **PASSING** |
| **HU-03: Gestionar Usuarios** | `auth-003` | CA 3.1, CA 3.2, CA 3.3, CA 3.4, CA 3.5, CA 3.6 | `user-management.spec.ts` | **PASSING** |
| **HU-04: Registrar documento sin planilla** | `doc-001` | CA 4.1, CA 4.2, CA 4.3, CA 4.4, CA 4.5 | `registrar-documento-sin-planilla.spec.ts`, `simple-request-flow.spec.ts` | **PASSING** |
| **HU-05: Ver revisiones pendientes** | `flow-001` | CA 5.1, CA 5.2, CA 5.3, CA 5.4, CA 5.5, CA 5.6 | `dashboard-flow.spec.ts`, `simple-request-flow.spec.ts` | **PASSING** |
| **HU-06: Aprobar documento** | `flow-002` | CA 6.1, CA 6.2, CA 6.3, CA 6.4, CA 6.5 | `simple-request-flow.spec.ts` | **PASSING** |
| **HU-07: Rechazar documento** | `flow-003` | CA 7.1, CA 7.2, CA 7.3, CA 7.4, CA 7.5 | `simple-request-flow.spec.ts` | **PASSING** |
| **HU-08: Solicitar corrección a documento** | `flow-004` | CA 8.1, CA 8.2, CA 8.3, CA 8.4, CA 8.5 | `simple-request-flow.spec.ts` | **PASSING** |
| **HU-09: Ver observaciones del revisor** | `flow-005` | CA 9.1, CA 9.2, CA 9.3, CA 9.4 | `ver-observaciones-revisor.spec.ts`, `simple-request-flow.spec.ts` | **PASSING** |
| **HU-10: Corregir documento** | `flow-006` | CA 10.1, CA 10.2, CA 10.3, CA 10.4, CA 10.5, CA 10.6 | `simple-request-flow.spec.ts` | **PASSING** |
| **HU-11: Consultar historial de flujos** | `flow-007` | CA 11.1, CA 11.2, CA 11.3, CA 11.4 | `simple-request-flow.spec.ts` | **PASSING** |
| **HU-12: Revisar notificaciones en bandeja** | `notif-001` | CA 12.1, CA 12.2, CA 12.3, CA 12.4, CA 12.5 | `simple-request-flow.spec.ts` | **PASSING** |

---

## 4. Procedimiento de Ejecución y Validación Visual

### Ejecución Headless Completa con Reseteo Seguro
```powershell
.\scripts\run-e2e-tests.ps1 -Clean
```

### Ejecución Visual Interactiva (Modo UI)
```powershell
.\scripts\run-e2e-tests.ps1 -UI
```
- Abre el navegador en `http://localhost:9323` para reproducir paso a paso, pausar, inspeccionar DOM y depurar cada prueba visualmente junto al desarrollador.
