import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe.serial('Dashboard de Solicitudes y Acciones Pendientes', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  const runId = Date.now();
  const requestTitle = `Doc Dashboard ${runId}`;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. Visualización del Dashboard y estructura general', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // Validar encabezado y bienvenida
    await expect(page.locator('#dashboard-heading')).toHaveText('Dashboard');
    await expect(page.locator('.dashboard-greeting')).toContainText('Bienvenido');
    await expect(page.locator('.dashboard-greeting')).toContainText('Administrador');

    // Validar presencia de botón de nueva solicitud y actualizar
    await expect(page.locator('.btn-new-request')).toBeVisible();
    await expect(page.locator('.btn-refresh')).toBeVisible();

    // Validar pestañas de navegación
    await expect(page.locator('.dashboard-tab-btn:has-text("Acciones Pendientes")')).toBeVisible();
    await expect(page.locator('.dashboard-tab-btn:has-text("Mis Solicitudes en Trámite")')).toBeVisible();
  });

  test('2. Registro de solicitud y aparición como acción pendiente de revisión en Dashboard', async ({ page }) => {
    await loginPage.goto();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // Crear solicitud documental
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Documento de prueba para verificación del dashboard.');
    await page.setInputFiles('#document-file', {
      name: `dashboard_test_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contenido de prueba para el dashboard operativo.')
    });

    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success')).toBeVisible({ timeout: 15000 });

    // Volver al Dashboard
    await page.click('aside.sidebar a[href="/dashboard"]');
    await dashboardPage.isDisplayed();

    // Verificar que aparece en "Acciones Pendientes" con tag de Revisión
    const actionRow = page.locator(`.dashboard-action-row:has-text("${requestTitle}")`);
    await expect(actionRow).toBeVisible({ timeout: 10000 });
    await expect(actionRow.locator('.action-tag-revision')).toContainText('Revisión Requerida');
    await expect(actionRow.locator('.btn-review')).toBeVisible();

    // Verificar en pestaña "Mis Solicitudes en Trámite"
    await dashboardPage.clickTab('en_tramite');
    const reqRow = page.locator(`.dashboard-request-row:has-text("${requestTitle}")`);
    await expect(reqRow).toBeVisible({ timeout: 10000 });
    await expect(reqRow.locator('.status-badge-pending')).toContainText(/Pendiente de revisi[oó]n/i);
    await expect(reqRow.locator('.btn-track')).toBeVisible();
  });

  test('3. Deep-linking de botón "Revisar" hacia Revisar Documento con solicitud preseleccionada', async ({ page }) => {
    await loginPage.goto();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // Clic en Revisar de la solicitud
    await dashboardPage.clickReview(requestTitle);

    // Debe navegar a /revisar-documento?id=...
    await expect(page).toHaveURL(/\/revisar-documento\?id=/);
    await expect(page.locator('#revisar-title')).toBeVisible({ timeout: 10000 });

    // El panel de detalle de revisión debe contener el título de la solicitud
    const detailTitle = page.locator('[data-testid="detail-title"]');
    await expect(detailTitle).toContainText(requestTitle);

    // Pedir corrección con motivo para probar flujo de subsanación
    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();
    await page.fill('[data-testid="modal-comment-input"]', `Observación de prueba dashboard ${runId}`);
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.page-message.form-message-success')).toBeVisible({ timeout: 15000 });
  });

  test('4. Aparición de "Subsanación Requerida" con observación en Dashboard y enlace directo', async ({ page }) => {
    await loginPage.goto();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // Verificar que la solicitud ahora aparece como "Subsanación Requerida"
    const actionRow = page.locator(`.dashboard-action-row:has-text("${requestTitle}")`);
    await expect(actionRow).toBeVisible({ timeout: 10000 });
    await expect(actionRow.locator('.action-tag-correction')).toContainText('Subsanación Requerida');
    await expect(actionRow.locator('.obs-snippet')).toContainText(`Observación de prueba dashboard ${runId}`);
    await expect(actionRow.locator('.btn-correct')).toBeVisible();

    // Clic en "Subsanar"
    await dashboardPage.clickCorrect(requestTitle);

    // Debe navegar a /corregir-documento?id=... con la solicitud seleccionada
    await expect(page).toHaveURL(/\/corregir-documento\?id=/);
    await expect(page.locator('#corregir-title')).toBeVisible({ timeout: 10000 });
  });
});
