import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { FlowsPage } from '../../pages/FlowsPage';
import { AreasPage } from '../../pages/AreasPage';

test.describe.serial('Configuración de Flujos por Área y Responsables de Revisión (HU-S2-05, HU-S2-06 / E2E-FLOW-CONFIG-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let flowsPage: FlowsPage;
  let areasPage: AreasPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    flowsPage = new FlowsPage(page);
    areasPage = new AreasPage(page);
  });

  test('1. [CA 5.1, 5.5] Admin crea un nuevo flujo documental asociado a un área y comprueba estado incompleto inicial', async () => {
    test.setTimeout(120000);
    // 1. Iniciar sesión como Administrador
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Configurar Flujos
    await flowsPage.goto();
    await flowsPage.isDisplayed();

    // Limpiar flujo previo si existía para garantizar idempotencia
    const existingFlow = flowsPage.getFlowRow('Flujo Contratos de Servicios');
    if (await existingFlow.isVisible().catch(() => false)) {
      await flowsPage.deleteFlow('Flujo Contratos de Servicios');
    }

    // 3. Crear flujo "Flujo Contratos de Servicios" asociado a "Operaciones"
    await flowsPage.createFlow(
      'Flujo Contratos de Servicios',
      'Flujo departamental para revisión y aprobación de contratos',
      'Operaciones'
    );

    // 4. Verificar que el flujo aparezca en la tabla con sus datos
    const flowRow = flowsPage.getFlowRow('Flujo Contratos de Servicios');
    await expect(flowRow).toBeVisible({ timeout: 15000 });
    await expect(flowRow.locator('td[data-label="Área corporativa"], .area-pill')).toHaveText('Operaciones');

    // 5. CA 5.5: Como recién se creó sin etapas, debe mostrar badge "Incompleto"
    const incompleteBadge = flowRow.locator('.flow-badge--incomplete, [data-label="Configuración"] .status-badge, .status-badge:has-text("Incompleta")');
    await expect(incompleteBadge).toBeVisible();
    await expect(incompleteBadge).toHaveText(/Incompleta|Incompleto/i);
  });

  test('2. [CA 5.2, 5.3, 6.1, 6.4, 6.5] Admin configura etapas secuenciales y revisores, impidiendo etapas huérfanas sin responsable', async () => {
    test.setTimeout(120000);
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    await flowsPage.goto();
    await flowsPage.isDisplayed();

    // 1. Abrir modal de configuración de etapas
    await flowsPage.openStagesModal('Flujo Contratos de Servicios');

    // 2. Configurar Etapa 1: "Revisión Técnica y Legal" asignada a Revisor Documental
    await flowsPage.fillStage(0, 'Revisión Técnica y Legal', 'Revisor Documental');

    // 3. Agregar Etapa 2
    await flowsPage.addStageButton.click();
    await expect(flowsPage.getStageCard(1)).toBeVisible();

    // 4. Llenar solo el nombre de Etapa 2 sin seleccionar revisor (etapa huérfana)
    await flowsPage.fillStage(1, 'Aprobación Financiera');

    // 5. Intentar guardar: CA 6.4 el sistema debe impedir dejar la etapa sin revisor
    const isSaveDisabled = await flowsPage.saveStagesButton.isDisabled();
    if (isSaveDisabled) {
      expect(isSaveDisabled).toBe(true);
    } else {
      await flowsPage.saveStages();
      await expect(flowsPage.stagesError).toBeVisible({ timeout: 5000 });
    }

    // El modal debe permanecer abierto
    await expect(flowsPage.stagesModal).toBeVisible();

    // 6. Asignar el responsable a la Etapa 2 (ej: Admin Capstone)
    await flowsPage.fillStage(1, 'Aprobación Financiera', 'Admin Capstone');

    // 7. Guardar etapas completas: CA 6.5 los cambios deben quedar guardados
    await flowsPage.saveStages();
    await expect(flowsPage.stagesModal).toBeHidden({ timeout: 25000 });

    // 8. Verificar que el flujo ahora tiene "2 etapa(s)" y badge "Completo"
    const flowRow = flowsPage.getFlowRow('Flujo Contratos de Servicios');
    await expect(flowRow).toBeVisible({ timeout: 15000 });
    await expect(flowRow).toContainText('2 etapas');

    const completeBadge = flowRow.locator('.flow-badge--complete, [data-label="Configuración"] .status-badge, .status-badge:has-text("Completa")');
    await expect(completeBadge).toBeVisible();
    await expect(completeBadge).toHaveText(/Completa|Completo/i);
  });

  test('3. [CA 5.4] Admin puede alterar el orden secuencial de las etapas y los cambios se persisten', async () => {
    test.setTimeout(120000);
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    await flowsPage.goto();
    await flowsPage.isDisplayed();

    // 1. Abrir modal de etapas
    await flowsPage.openStagesModal('Flujo Contratos de Servicios');

    // 2. Verificar orden inicial: Paso 1 es "Revisión Técnica y Legal", Paso 2 es "Aprobación Financiera"
    const card0 = flowsPage.getStageCard(0);
    const card1 = flowsPage.getStageCard(1);
    await expect(card0.locator('input[id^="stage-name-"]')).toHaveValue('Revisión Técnica y Legal');
    await expect(card1.locator('input[id^="stage-name-"]')).toHaveValue('Aprobación Financiera');

    // 3. Subir el Paso 2 para que sea el nuevo Paso 1
    await flowsPage.moveStageUp(1);

    // 4. Comprobar que en pantalla se invirtieron
    await expect(flowsPage.getStageCard(0).locator('input[id^="stage-name-"]')).toHaveValue('Aprobación Financiera');
    await expect(flowsPage.getStageCard(1).locator('input[id^="stage-name-"]')).toHaveValue('Revisión Técnica y Legal');

    // 5. Guardar los cambios
    await flowsPage.saveStages();
    await expect(flowsPage.stagesModal).toBeHidden({ timeout: 25000 });

    // 6. Reabrir modal para confirmar persistencia real en backend / BD
    await flowsPage.openStagesModal('Flujo Contratos de Servicios');
    await expect(flowsPage.getStageCard(0).locator('input[id^="stage-name-"]')).toHaveValue('Aprobación Financiera');
    await expect(flowsPage.getStageCard(1).locator('input[id^="stage-name-"]')).toHaveValue('Revisión Técnica y Legal');

    // Cerrar modal
    await flowsPage.cancelStagesButton.click();
    await expect(flowsPage.stagesModal).toBeHidden({ timeout: 10000 });
  });

  test('4. [CA 5.5] Un flujo incompleto no debe poder utilizarse para nuevas solicitudes', async ({ page }) => {
    test.setTimeout(120000);
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    await flowsPage.goto();
    await flowsPage.isDisplayed();

    // Limpiar borrador previo si existía para garantizar idempotencia
    const existingDraft = flowsPage.getFlowRow('Flujo Borrador Incompleto');
    if (await existingDraft.isVisible().catch(() => false)) {
      await flowsPage.deleteFlow('Flujo Borrador Incompleto');
    }

    // 1. Crear un flujo borrador sin etapas
    await flowsPage.createFlow(
      'Flujo Borrador Incompleto',
      'Flujo de prueba sin etapas asignadas',
      'Operaciones'
    );

    const draftRow = flowsPage.getFlowRow('Flujo Borrador Incompleto');
    await expect(draftRow).toBeVisible({ timeout: 15000 });
    const incompleteBadge = draftRow.locator('.flow-badge--incomplete, [data-label="Configuración"] .status-badge, .status-badge:has-text("Incompleta")');
    await expect(incompleteBadge).toBeVisible();

    // 2. Navegar a /nuevo-documento
    const navNuevoDoc = page.locator('aside.sidebar nav a:has-text("Nuevo documento"), aside.sidebar nav a[href="/nuevo-documento"]');
    if (await navNuevoDoc.isVisible({ timeout: 2000 }).catch(() => false)) {
      await navNuevoDoc.click();
    } else {
      await page.goto('/nuevo-documento');
    }
    const flowSelect = page.locator('#document-flujo, button#document-flujo');
    await expect(flowSelect).toBeVisible({ timeout: 10000 });

    // 3. CA 5.5: Comprobar que el flujo incompleto figura como deshabilitado o no seleccionable
    await flowSelect.click();
    const incompleteOption = page.locator('div[role="option"]:has-text("Flujo Borrador Incompleto")');
    await expect(incompleteOption).toHaveCount(0);

    // Comprobar que el flujo base "Revisión Simple" o los flujos completos están disponibles
    const availableOptions = page.locator('div[role="option"]');
    await expect(availableOptions.first()).toBeVisible({ timeout: 5000 });
  });

  test('5. [CA 2.5 / RBAC] Restricción RBAC: usuario no administrador (APPROVER) no puede configurar flujos', async ({ page }) => {
    test.setTimeout(120000);
    // 1. Login con usuario operativo APPROVER
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    // 2. Verificar que en la barra lateral NO figure el enlace a "Configurar flujos"
    const flowNavLink = page.locator('nav a[href="/configurar-flujos"], aside.sidebar nav a:has-text("Configurar flujos")');
    await expect(flowNavLink).toHaveCount(0);

    // 3. Intentar navegar directamente por URL a /configurar-flujos
    await page.goto('/configurar-flujos');

    // 4. Debe ser redirigido automáticamente al Dashboard o no mostrar permisos de gestión
    await expect(page).toHaveURL(/\/dashboard/);
  });
});
