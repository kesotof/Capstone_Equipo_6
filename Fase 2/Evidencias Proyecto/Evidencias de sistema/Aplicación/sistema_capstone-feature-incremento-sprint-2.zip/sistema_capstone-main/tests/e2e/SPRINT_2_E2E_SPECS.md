# Planificación y Especificación de Pruebas E2E - Sprint 2 (Playwright)

Este documento establece la **estrategia de testing automatizado, catálogo de flujos propuestos y matriz de cobertura multicriterio** para el **Sprint 2: Flujos Configurables, Organización, RUT y SLA**, asegurando que el **100% de los criterios de aceptación** de las 14 historias de usuario del Sprint Backlog queden cubiertos por pruebas verificables de extremo a extremo.

---

## 1. Principios y Estrategia de Testing Automatizado

Siguiendo el estándar de calidad y la *Definition of Done* (DoD) formalizada en [`AGENTS.md`](../../AGENTS.md):

1. **Jornadas Integrales de Usuario (*User Journeys*)**:
   - En lugar de tests unitarios de interfaz atómicos y desarticulados, cada suite ejecuta una jornada de usuario fluida y encadenada.
   - Un solo flujo E2E valida de forma secuencial casos límite, errores controlados de validación, persistencia en base de datos y reflejo inmediato en la interfaz visual.
2. **Cobertura Exhaustiva de Criterios (76/76 CAs)**:
   - Ningún criterio de aceptación queda sin prueba automatizada. Se combinan verificaciones de cliente (DOM, validaciones de formularios, badges visuales, modals) con aserciones de backend (códigos HTTP, contratos REST, eventos de auditoría y almacenamiento MinIO S3).
3. **Validación Visual Conjunta con el Desarrollador**:
   - Cada suite puede ejecutarse de forma desatendida en CI/Docker o de forma interactiva visual con el desarrollador mediante `.\scripts\run-e2e-tests.ps1 -UI` (o flag `--headed`).
   - La aprobación de la historia requiere comprobar en pantalla el comportamiento esperado.
4. **Reseteo Determinista del Entorno**:
   - Cada ciclo de ejecución parte de un estado limpio y determinista mediante el script `scripts/clean-test-db.ps1` (o parámetro `-Clean`), restaurando datos maestros en PostgreSQL, Keycloak, MinIO y colas RabbitMQ.

---

## 2. Catálogo de Flujos y Suites E2E Propuestas (Sprint 2)

Se estructuran **7 suites especializadas** en Playwright que agrupan funcionalmente las 14 historias de usuario:

```
tests/e2e/src/specs/
├── auth/
│   ├── rut-validation.spec.ts         # E2E-RUT-01 (HU-S2-01)
│   └── change-password.spec.ts        # E2E-SEC-AUTH-01 (HU-S2-13)
├── org/
│   └── corporate-areas.spec.ts        # E2E-ORG-01 (HU-S2-02, HU-S2-03, HU-S2-04)
├── flow/
│   ├── flow-configuration.spec.ts     # E2E-FLOW-CONFIG-01 (HU-S2-05, HU-S2-06)
│   ├── sla-matrix-alerts.spec.ts      # E2E-SLA-01 (HU-S2-08)
│   └── dashboard-general-summary.spec.ts # E2E-DASH-METRICS-01 (HU-S2-14)
└── doc/
    └── document-search-isolation.spec.ts # E2E-DOC-SEARCH-01 (HU-S2-07, HU-S2-09, HU-S2-10, HU-S2-11, HU-S2-12)
```

---

### `E2E-RUT-01`: Validación, Autoformato y Unicidad de RUT Chileno al Crear Usuarios
- **Archivo Propuesto**: `src/specs/auth/rut-validation.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-01: Asignar un RUT al crear usuario` (Trello: `6abac8b22eb672e2c03aa317` / PB: `6abac6d69e1634dec1893867`)
- **Criterios de Aceptación Verificados**:
  - `CA 1.1`: Campo obligatorio de RUT asociado a la cuenta al crear usuario.
  - `CA 1.2`: Autoformateo dinámico en tiempo real a formato `NN.NNN.NNN-N` a medida que se tipea.
  - `CA 1.3`: Conversión automática de letra `"k"` minúscula a `"K"` mayúscula con el autoformato.
  - `CA 1.4`: Bloqueo inmediato de caracteres distintos a números, "k" o "K".
  - `CA 1.5`: Prohibición de ingreso de espacios en blanco.
  - `CA 1.6`: Bloqueo de caracteres en exceso (longitud máxima acotada al estándar chileno).
  - `CA 1.7`: Rechazo de creación ante RUT inválido por Dígito Verificador (DV) o RUT duplicado.
  - `CA 1.8`: Despliegue de mensajes de error explicativos en pantalla según la causa.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Login como Administrador*: Acceder al sistema y navegar a `/configurar-org-usuarios`.
  2. *Abrir Modal de Nuevo Usuario*: Clic en botón "Nuevo Usuario".
  3. *Prueba de Filtro de Teclas y Espacios*: Tipear caracteres especiales (`abc !@#`) y espacios en el campo RUT; comprobar que el valor del campo no los admite.
  4. *Prueba de Autoformato*: Tipear secuencialmente `19876543`; comprobar que el input muestra dinámicamente `19.876.543`.
  5. *Prueba de Conversión de K*: Tipear letra `k` minúscula al final; comprobar que se transforma automáticamente en `-K` mayúscula (`19.876.543-K`).
  6. *Prueba de Límite de Longitud*: Intentar tipear dígitos adicionales; comprobar que el campo bloquea el exceso.
  7. *Caso Negativo - DV Inválido*: Ingresar RUT con DV intencionalmente erróneo (ej. `11.111.111-2`); presionar "Guardar"; comprobar que no envía petición o la API responde 400 y se muestra el mensaje de error explicativo de "Dígito verificador inválido".
  8. *Caso Negativo - RUT Duplicado*: Ingresar RUT de un usuario previamente existente en el sistema con datos de nombre y correo válidos; presionar "Guardar"; comprobar código HTTP 409 y mensaje interactivo de "El RUT ingresado ya se encuentra registrado".
  9. *Caso Positivo - Creación Exitosa*: Ingresar RUT válido real (ej. `12.345.678-5`), nombre, apellido y correo único; guardar; comprobar mensaje de confirmación, cierre del modal y presencia del nuevo usuario con su RUT formateado en la grilla y en PostgreSQL.

---

### `E2E-ORG-01`: Gestión de Estructura Organizacional, Departamentos y Asignaciones
- **Archivo Propuesto**: `src/specs/org/corporate-areas.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-02: Gestionar areas corporativas` (Trello: `6abac5222fe8f491e650d0fb`)
  - `HU-S2-03: Asignar administrador de área` (Trello: `6abac5446c5284bcd007bca9`)
  - `HU-S2-04: Vincular usuarios con sus áreas` (Trello: `6abac5536ab271708b508519`)
- **Criterios de Aceptación Verificados**:
  - `CA 2.1 - 2.5`: Creación de área corporativa, edición de datos, desactivación lógica, unicidad de nombre y restricción RBAC a administradores.
  - `CA 3.1 - 3.5`: Asignación exclusiva por admin, selección de usuario activo, visibilidad del área administrada, cambio de administrador y registro en auditoría.
  - `CA 4.1 - 4.5`: Validación de existencia previa de usuario y área, selector de departamento, visualización en ficha de usuario, reasignación y auditoría de cambios.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Creación de Áreas Corporativas*: Admin accede al módulo de organización; crea tres áreas basadas en el organigrama de Masterbase: "Operaciones", "Finanzas" y "Tecnología".
  2. *Validación de Unicidad de Nombre*: Intenta crear un área con nombre repetido ("Finanzas"); el sistema bloquea con mensaje "Ya existe un área con ese nombre".
  3. *Edición de Área*: Modifica el área "Tecnología" renombrándola a "Tecnología e Infraestructura".
  4. *Asignación de Administrador de Área*:
     - Selecciona el área "Finanzas" y asigna al usuario activo `finanzas.admin@capstone.local` como responsable.
     - Comprueba que en la vista y en las tarjetas de área figura claramente asignado.
     - Reasigna el cargo a otro usuario activo; valida que el cambio se persiste y genera evento en `log_evento`.
  5. *Vinculación Bidireccional Usuario - Departamento*:
     - Admin abre ficha de un usuario operativo y le asigna el departamento "Operaciones".
     - Comprueba que el área asignada aparece en la columna y ficha del usuario.
     - Cambia al usuario de "Operaciones" a "Finanzas"; valida registro de auditoría.
  6. *Desactivación de Área Corporativa*:
     - Desactiva un área sin asignaciones activas; comprueba que cambia de estado a "Inactiva" y ya no puede ser seleccionada para nuevos trámites ni flujos.
  7. *Control de Acceso RBAC*:
     - Inicia sesión con un usuario operativo (`APPROVER`); comprueba que no tiene acceso a la gestión de áreas (menú oculto y endpoints devuelven HTTP 403 Forbidden).

---

### `E2E-FLOW-CONFIG-01`: Configuración de Flujos por Área y Responsables de Revisión
- **Archivo Propuesto**: `src/specs/flow/flow-configuration.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-05: Gestionar flujos` (Trello: `6abac56a5dd4367af193f826`)
  - `HU-S2-06: Configurar responsables de revisión` (Trello: `6abac58f50dc5ec3df943eae`)
- **Criterios de Aceptación Verificados**:
  - `CA 5.1 - 5.5`: Creación de flujo con nombre y área, definición de etapas secuenciales, asignación de revisor por paso, reordenamiento interactivo y bloqueo de uso de flujos incompletos.
  - `CA 6.1 - 6.5`: Selección de responsable por etapa, filtro de usuarios activos disponibles, sustitución de responsables, prohibición de etapas sin revisor y persistencia auditada.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Creación de Nuevo Flujo Documental*: Admin navega a `/configurar-flujos`; hace clic en "Crear Flujo"; ingresa nombre "Flujo Contratos de Servicios" y asocia el área "Finanzas".
  2. *Adición de Etapas Secuenciales*:
     - Añade Etapa 1: "Revisión Técnica y Legal".
     - Añade Etapa 2: "Aprobación Financiera".
  3. *Asignación de Revisores*:
     - En Etapa 1 selecciona a un usuario con rol de revisor activo.
     - En Etapa 2 intenta guardar sin asignar responsable; comprueba que el sistema valida e impide dejar la etapa huérfana ("Toda etapa de revisión debe contar con un responsable asignado").
     - Asigna el responsable correspondiente a la Etapa 2.
  4. *Reordenamiento de Etapas*:
     - Utiliza los controles de reordenamiento para alterar la secuencia de los pasos; comprueba que el nuevo orden numérico se actualiza en pantalla.
  5. *Validación de Flujo Incompleto*:
     - Intenta activar un flujo borrador que no contiene etapas; comprueba que el sistema marca el flujo como "Incompleto" e impide seleccionarlo en el formulario de nuevas solicitudes.
  6. *Publicación y Guardado*:
     - Guarda el flujo completo; comprueba confirmación visual y registro en las tablas `flujo_definicion` y `flujo_etapa`.

---

### `E2E-SLA-01`: Matriz de Plazos de Aprobación (SLA) y Alertas Visuales de Vencimiento
- **Archivo Propuesto**: `src/specs/flow/sla-matrix-alerts.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-08: Configurar plazos de aprobación y alertas por tipo de documento` (Trello: `6abad413a4c55641782295e2`)
- **Criterios de Aceptación Verificados**:
  - `CA 8.1`: Configuración de plazo máximo en días hábiles según tipo de documento (ej. 4 días para contratos, 2 días para órdenes de compra).
  - `CA 8.2`: Inicio del cómputo del plazo a partir del registro y envío a revisión excluyendo días no hábiles.
  - `CA 8.3`: Despliegue de alertas visuales semánticas (badges) en la bandeja del revisor: normal, por vencer y vencido.
  - `CA 8.4`: Aplicación de los plazos a todas las decisiones del flujo (aprobar, rechazar, pedir corrección).
  - `CA 8.5`: Configuración y edición restringida exclusivamente a administradores.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Configuración de la Matriz SLA*:
     - Admin accede a la matriz de plazos; define:
       - Tipo "Contrato de Servicios": plazo de 4 días hábiles.
       - Tipo "Orden de Compra": plazo de 2 días hábiles.
     - Guarda la matriz; comprueba notificación de éxito y persistencia.
  2. *Control RBAC*:
     - Usuario no administrador intenta consultar/modificar endpoints de configuración SLA; recibe HTTP 403 Forbidden.
  3. *Cálculo de Plazo al Iniciar Solicitud*:
     - Emisor registra solicitud de tipo "Contrato de Servicios" con archivo adjunto.
     - El backend calcula la fecha límite (*deadline*) sumando 4 días hábiles desde la fecha/hora de envío.
  4. *Inspección Visual de Estados SLA en Bandeja de Revisiones*:
     - Revisor accede a "Revisiones Pendientes".
     - **Caso Normal**: Solicitud recién enviada muestra badge informativo/plazo con fecha límite clara.
     - **Caso Próximo a Vencer**: Solicitud con menos de 24 horas corridas restantes, hasta el instante límite inclusive, muestra badge de advertencia ámbar/amarillo "Por vencer". Exactamente 24 horas restantes es "A tiempo"; después del límite es "Vencido". Regla documentada el 12-10-2026 en [diseño SLA](../../docs/design/matriz-sla-dias-habiles-sprint-2.md); esta planificación no acredita ejecución de esos casos.
     - **Caso Vencido**: Solicitud cuya fecha límite ha expirado muestra badge de alerta rojo "Vencido".
  5. *Resolución Bajo SLA*:
     - Revisor aprueba, rechaza o pide corrección; el sistema registra por decisión si fue emitida antes, exactamente o después del límite. Sin plazo histórico registra null. Etapas, correcciones y reenvíos conservan el deadline original.

---

### `E2E-SEC-AUTH-01`: Autogestión de Credenciales (Cambio de Contraseña)

- **Archivo implementado**: `src/specs/auth/change-password.spec.ts`
- **Historia cubierta**: `HU-S2-13: Cambiar Contraseña` (Trello: `6abac5e4c1604e7b8b0d286a`).
- **Criterios de aceptación verificados**:
  - `CA 13.1`: Contraseña actual obligatoria.
  - `CA 13.2`: Nueva contraseña y confirmación obligatorias.
  - `CA 13.3`: Contraseña actual incorrecta devuelve HTTP 400/CURRENT_PASSWORD_INVALID y muestra “La contraseña actual es incorrecta, inténtelo nuevamente.”.
  - `CA 13.4`: Validación de la política efectiva: mínimo ocho y máximo 1024 caracteres, sin grupos obligatorios ni reglas adicionales.
  - `CA 13.5`: Mensaje de error si las contraseñas nuevas no coinciden.
  - `CA 13.6`: Confirmación del cambio, continuidad de sesión y acceso posterior con la nueva contraseña.
- **Flujo verificado**:
  1. Usuario autenticado abre `/cambiar-contrasena` desde el menú Cuenta.
  2. Comprueba campos obligatorios y errores asociados a cada campo.
  3. Ingresa contraseña actual incorrecta y confirma el rechazo y el mensaje exacto al pulsar “Actualizar contraseña”.
  4. Comprueba la longitud mínima de la política efectiva y el error de confirmación diferente.
  5. Guarda una contraseña válida, comprueba confirmación, retirada del formulario y continuidad hacia el Dashboard.
  6. Cierra sesión; comprueba rechazo de la contraseña anterior y acceso con la nueva.
- **Resultado final (14-10-2026)**: 6/6 casos correctos en 30.4 s, Chromium, un worker, cero reintentos y cero omisiones. Regresión backend PasswordChangeOperationsTest: 9/9 correctas en 12.592 s. Credencial original restaurada y acceso comprobado con HTTP 200; sesión temporal cerrada con HTTP 204.
- **Evidencia técnica**: reporte `playwright-report/password-2026-10-14-docker-05/index.html`, seis videos en `test-results/password-2026-10-14-docker-05` y XML backend en `backend/sistema-principal/target/surefire-reports/TEST-com.capstone.sistema.users.password.PasswordChangeOperationsTest.xml` desde la raíz del repositorio.

---

### `E2E-DOC-SEARCH-01`: Inventario, Búsqueda Multicriterio, Correlativo y Aislamiento Departamental y Jerárquico
- **Archivo Propuesto**: `src/specs/doc/document-search-isolation.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-07: Gestionar roles y permisos` (Trello: `6abac57cf46c0ced5e0dcb37`)
  - `HU-S2-09: Ver detalle de una solicitud (Emisor/Revisor)` (Trello: `6abac5cbe57497ce0ac4653c`)
  - `HU-S2-10: Consultar documentos` (Trello: `6abac613487611c98ad7f89e`)
  - `HU-S2-11: Consultar estado de mis solicitudes` (Trello: `6abac635d5ba9c0fb81aec6b`)
  - `HU-S2-12: Descargar documentos` (Trello: `6abac625c9a5cbe76d9340dc`)
- **Criterios de Aceptación Verificados**:
  - `CA 7.5 - 7.6`: Aislamiento horizontal de documentos por área corporativa y jerarquía vertical estricta (jefatura ve subordinados, pero no superiores).
  - `CA 9.1 - 9.5`: Vista detallada de solicitud (metadatos, correlativo, adjuntos, observaciones, estado y control de acceso).
  - `CA 10.1 - 10.6`: Búsqueda textual y filtros por tipo de documento, estado, área y fecha, visualización de código correlativo y acceso al detalle.
  - `CA 11.1 - 11.5`: Vista de solicitudes del emisor con estado visible, correlativo (ej. `CONT-001`) e historial inmutable.
  - `CA 12.1 - 12.4`: Descarga de archivo físico manteniendo nombre original, formato e integridad desde MinIO, con mensaje de error si no estuviera disponible.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Aislamiento Horizontal por Departamento*:
     - Se registran documentos en el área "Finanzas" y documentos en "Operaciones".
     - Usuario operador de Finanzas ingresa a "Consultar Documentos": solo visualiza documentos de Finanzas; ningún documento de Operaciones aparece en la grilla ni en los resultados de búsqueda.
  2. *Aislamiento Jerárquico Vertical Estricto*:
     - Colaborador de Finanzas emite solicitud A.
     - Jefatura de Finanzas emite solicitud B.
     - Gerencia General emite solicitud C.
     - **Verificación Jefatura**: Inicia sesión la Jefatura de Finanzas; puede consultar la solicitud A (de su colaborador directo), pero tiene bloqueada la visualización de la solicitud C (de su superior jerárquico).
  3. *Código Correlativo Unificado*:
     - En todas las vistas ("Consultar Documentos", "Mis Documentos", "Estado de Solicitudes"), cada trámite exhibe su correlativo estructurado (ej. `CONT-001`, `FAC-014`).
  4. *Búsqueda y Filtros Combinados*:
     - Se ingresa texto en la barra de búsqueda y se aplican filtros por tipo ("Contrato"), estado ("Pendiente de revisión") y rango de fechas; la tabla filtra en vivo con coincidencia exacta.
  5. *Detalle Completo de la Solicitud e Historial Inmutable*:
     - Al hacer clic en una solicitud, se abre el diálogo/pantalla de detalle mostrando datos generales, correlativo, panel de observaciones y la línea de tiempo inmutable.
  6. *Descarga Segura desde MinIO S3*:
     - Clic en el botón "Descargar documento"; se intercepta la descarga mediante Playwright; se verifica que el archivo descargado conserva el nombre original (`contrato_proveedor.pdf`), tamaño en bytes e integridad de contenido.
     - Intento de forzar la descarga de un documento ajeno mediante endpoint directo devuelve HTTP 403 Forbidden.

---

### `E2E-DASH-METRICS-01`: Dashboard de Resumen General de Solicitudes y Métricas por Área
- **Archivo Propuesto**: `src/specs/flow/dashboard-general-summary.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-S2-14: Ver resumen general de solicitudes` (Trello: `6abac65daf0bbca6ae17bbea`)
- **Criterios de Aceptación Verificados**:
  - `CA 14.1`: Despliegue de métricas cuantitativas: total de solicitudes pendientes, aprobadas, rechazadas y en corrección.
  - `CA 14.2`: Capacidad de filtrar o desglosar información métrica por área corporativa.
  - `CA 14.3`: Actualización reactiva o inmediata de los conteos al producirse transiciones de estado en solicitudes.
  - `CA 14.4`: Aislamiento de métricas: cada perfil visualiza únicamente los datos que tiene permitido consultar.
  - `CA 14.5`: Claridad visual y comprensión ergonómica de los indicadores en el dashboard.
- **Flujo General Propuesto (Paso a Paso)**:
  1. *Inspección de Contadores Iniciales*:
     - Admin accede al Dashboard; verifica tarjetas numéricas de balance general (Pendientes, Aprobadas, Rechazadas, En Corrección).
  2. *Desglose y Filtro Departamental*:
     - Selecciona filtro de área "Finanzas"; comprueba que los contadores se recalculan instantáneamente para reflejar solo el área seleccionada.
  3. *Aislamiento de Métricas para Usuarios Operativos*:
     - Inicia sesión como usuario perteneciente únicamente a "Operaciones"; comprueba que su dashboard resume exclusivamente las solicitudes de su departamento asignado.
  4. *Actualización Dinámica tras Transición de Flujo*:
     - Un revisor aprueba una solicitud pendiente.
     - Se navega al Dashboard; se constata que el contador de "Pendientes" disminuyó en 1 y el de "Aprobadas" se incrementó en 1 de forma consistente sin inconsistencias numéricas.

---

## 3. Matriz Maestra de Trazabilidad (76 Criterios de Aceptación vs Suites E2E)

| ID Historia | Historia de Usuario | Card ID Trello | Total CAs | Criterios Cubiertos | Suite E2E Designada | Estado Planificado |
| :--- | :--- | :--- | :---: | :--- | :--- | :---: |
| **HU-S2-01** | Asignar un RUT al crear usuario | `6abac8b22eb672e2c03aa317` | 8 | CA 1.1 a CA 1.8 | `rut-validation.spec.ts` (`E2E-RUT-01`) | **ESPECIFICADO** |
| **HU-S2-02** | Gestionar areas corporativas | `6abac5222fe8f491e650d0fb` | 5 | CA 2.1 a CA 2.5 | `corporate-areas.spec.ts` (`E2E-ORG-01`) | **ESPECIFICADO** |
| **HU-S2-03** | Asignar administrador de área | `6abac5446c5284bcd007bca9` | 5 | CA 3.1 a CA 3.5 | `corporate-areas.spec.ts` (`E2E-ORG-01`) | **ESPECIFICADO** |
| **HU-S2-04** | Vincular usuarios con sus áreas | `6abac5536ab271708b508519` | 5 | CA 4.1 a CA 4.5 | `corporate-areas.spec.ts` (`E2E-ORG-01`) | **ESPECIFICADO** |
| **HU-S2-05** | Gestionar flujos | `6abac56a5dd4367af193f826` | 5 | CA 5.1 a CA 5.5 | `flow-configuration.spec.ts` (`E2E-FLOW-CONFIG-01`) | **ESPECIFICADO** |
| **HU-S2-06** | Configurar responsables de revisión | `6abac58f50dc5ec3df943eae` | 5 | CA 6.1 a CA 6.5 | `flow-configuration.spec.ts` (`E2E-FLOW-CONFIG-01`) | **ESPECIFICADO** |
| **HU-S2-07** | Gestionar roles y permisos | `6abac57cf46c0ced5e0dcb37` | 7 | CA 7.1 a CA 7.7 | `document-search-isolation.spec.ts` (`E2E-DOC-SEARCH-01`) | **ESPECIFICADO** |
| **HU-S2-08** | Configurar plazos y alertas SLA | `6abad413a4c55641782295e2` | 5 | CA 8.1 a CA 8.5 | `sla-matrix-alerts.spec.ts` (`E2E-SLA-01`) | **ESPECIFICADO** |
| **HU-S2-09** | Ver detalle de una solicitud | `6abac5cbe57497ce0ac4653c` | 5 | CA 9.1 a CA 9.5 | `document-search-isolation.spec.ts` (`E2E-DOC-SEARCH-01`) | **ESPECIFICADO** |
| **HU-S2-10** | Consultar documentos | `6abac613487611c98ad7f89e` | 6 | CA 10.1 a CA 10.6 | `document-search-isolation.spec.ts` (`E2E-DOC-SEARCH-01`) | **ESPECIFICADO** |
| **HU-S2-11** | Consultar estado de mis solicitudes | `6abac635d5ba9c0fb81aec6b` | 5 | CA 11.1 a CA 11.5 | `document-search-isolation.spec.ts` (`E2E-DOC-SEARCH-01`) | **ESPECIFICADO** |
| **HU-S2-12** | Descargar documentos | `6abac625c9a5cbe76d9340dc` | 4 | CA 12.1 a CA 12.4 | `document-search-isolation.spec.ts` (`E2E-DOC-SEARCH-01`) | **ESPECIFICADO** |
| **HU-S2-13** | Cambiar Contraseña | `6abac5e4c1604e7b8b0d286a` | 6 | CA 13.1 a CA 13.6 | `change-password.spec.ts` (`E2E-SEC-AUTH-01`) | **VERIFICADO (6/6)** |
| **HU-S2-14** | Ver resumen general de solicitudes | `6abac65daf0bbca6ae17bbea` | 5 | CA 14.1 a CA 14.5 | `dashboard-general-summary.spec.ts` (`E2E-DASH-METRICS-01`) | **ESPECIFICADO** |
| **TOTAL** | **14 Historias de Usuario** | — | **76** | **76 Criterios Cubiertos (100%)** | **7 Suites Automatizadas** | **COBERTURA TOTAL** |

---

## 4. Procedimiento de Ejecución y Validación

### Ejecución de Pruebas E2E del Sprint 2
```powershell
# Ejecución completa en modo headless con reseteo previo de base de datos
.\scripts\run-e2e-tests.ps1 -Clean

# Ejecución interactiva visual (UI Mode) para validación con el desarrollador
.\scripts\run-e2e-tests.ps1 -UI

# Ejecución focalizada de una suite específica
.\scripts\run-e2e-tests.ps1 -Spec "rut-validation"
.\scripts\run-e2e-tests.ps1 -Spec "corporate-areas"
.\scripts\run-e2e-tests.ps1 -Spec "sla-matrix-alerts"
```

### Ejecución en Linux / WSL / Bash
```bash
./scripts/run-e2e-tests.sh -Clean
./scripts/run-e2e-tests.sh -Spec rut-validation
```

---

## 5. Referencias y Documentos Vivos
- [`docs/sprint-backlog/sprint-2.md`](../../docs/sprint-backlog/sprint-2.md): Detalle de historias y actas de reunión.
- [`tests/e2e/SPRINT_1_E2E_SPECS.md`](./SPRINT_1_E2E_SPECS.md): Especificación de referencia del Sprint 1 (33 tests pasando).
- [`PROJECT_STRUCTURE.md`](../../PROJECT_STRUCTURE.md): Catálogo de componentes y arquitectura de integración.
- [`AGENTS.md`](../../AGENTS.md): Reglas operativas y definición de terminado.
