import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { UsersPage, generateValidRut } from '../../pages/UsersPage';

/**
 * Suite E2E-RUT-01: Validación, Autoformato y Unicidad de RUT Chileno al Crear Usuarios
 * Historia: HU-S2-01 (auth-005)
 */
test.describe.serial('Validación y Autoformato de RUT Chileno (HU-S2-01 / E2E-RUT-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let usersPage: UsersPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    usersPage = new UsersPage(page);
  });

  test('1. [CA 1.4 y 1.5] No debe permitir caracteres diferentes a números, k o K, ni espacios vacíos', async () => {
    // 1. Login como Admin y navegar a Organización y Usuarios
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 2. Abrir modal de creación
    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();

    // 3. Tipear caracteres especiales, letras no permitidas y espacios
    await usersPage.rutInput.pressSequentially('abc !@#');
    expect(await usersPage.rutInput.inputValue()).toBe('');

    // Cerrar modal
    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('2. [CA 1.2, 1.3 y 1.6] Autoformateo interactivo a NN.NNN.NNN-N, conversión de k a K y bloqueo de caracteres en exceso', async () => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();
    await usersPage.goto();
    await usersPage.isDisplayed();

    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();

    // 1. Tipear secuencialmente números sin guion y comprobar autoformato con puntos
    await usersPage.rutInput.pressSequentially('19876543');
    expect(await usersPage.rutInput.inputValue()).toBe('19.876.543');

    // 2. Tipear letra 'k' minúscula y comprobar transformación a '-K'
    await usersPage.rutInput.pressSequentially('k');
    expect(await usersPage.rutInput.inputValue()).toBe('19.876.543-K');

    // 3. Intentar tipear caracteres adicionales (de más) y comprobar bloqueo de longitud
    await usersPage.rutInput.pressSequentially('999');
    expect(await usersPage.rutInput.inputValue()).toBe('19.876.543-K');

    // Cerrar modal
    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('3. [CA 1.1] Campo RUT es obligatorio al crear un usuario', async () => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();
    await usersPage.goto();
    await usersPage.isDisplayed();

    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();

    // Llenar todos los campos excepto el RUT
    await usersPage.emailInput.fill(`sin_rut_${Date.now()}@capstone.local`);
    await usersPage.firstNameInput.fill('Usuario');
    await usersPage.lastNameInput.fill('SinRUT');
    await usersPage.passwordInput.fill('Password123!');
    await usersPage.confirmPasswordInput.fill('Password123!');
    await usersPage.rutInput.fill('');

    await usersPage.submitCreateButton.click();

    // El modal debe permanecer abierto y mostrar mensaje de RUT obligatorio
    await expect(usersPage.createModal).toBeVisible();
    await expect(usersPage.errorMessage).toBeVisible();
    const errorText = await usersPage.errorMessage.textContent();
    expect(errorText?.toLowerCase()).toContain('rut es obligatorio');

    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('4. [CA 1.7] Rechazo de creación ante RUT inválido por Dígito Verificador (DV)', async () => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();
    await usersPage.goto();
    await usersPage.isDisplayed();

    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();

    // 22459056-3 es válido; 22459056-4 tiene DV inválido
    await usersPage.emailInput.fill(`dv_invalido_${Date.now()}@capstone.local`);
    await usersPage.rutInput.fill('22.459.056-4');
    await usersPage.firstNameInput.fill('Test');
    await usersPage.lastNameInput.fill('DVInvalido');
    await usersPage.passwordInput.fill('Password123!');
    await usersPage.confirmPasswordInput.fill('Password123!');

    await usersPage.submitCreateButton.click();

    // Debe mostrar error explicativo de dígito verificador / RUT inválido
    await expect(usersPage.createModal).toBeVisible();
    await expect(usersPage.errorMessage).toBeVisible();
    const errorText = await usersPage.errorMessage.textContent();
    expect(errorText?.toLowerCase()).toMatch(/dígito verificador|no es válido|invalido/i);

    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('5. [CA 1.7 y 1.8] Creación exitosa con RUT válido y rechazo posterior por RUT duplicado', async () => {
    test.setTimeout(120000);

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();
    await usersPage.goto();
    await usersPage.isDisplayed();

    // Generar RUT chileno válido dinámico
    const validRut = generateValidRut();
    const cleanRut = validRut.replace(/\./g, '');
    const email1 = `rut_exitoso_${Date.now()}@capstone.local`;

    // 1. Crear primer usuario con RUT válido
    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();
    await usersPage.emailInput.fill(email1);
    await usersPage.rutInput.fill(validRut);
    await usersPage.firstNameInput.fill('Usuario');
    await usersPage.lastNameInput.fill('ValidoRUT');
    await usersPage.passwordInput.fill('Password123!');
    await usersPage.confirmPasswordInput.fill('Password123!');
    await usersPage.submitCreateButton.click();

    // Comprobar que el modal se cierra y el usuario aparece en la grilla con su RUT
    await expect(usersPage.createModal).toBeHidden({ timeout: 25000 });
    const userRow = usersPage.getUserRow(email1);
    await expect(userRow).toBeVisible({ timeout: 15000 });
    await expect(userRow).toContainText(cleanRut);

    // 2. Intentar crear segundo usuario con diferente email pero el MISMO RUT (duplicado)
    const email2 = `rut_duplicado_${Date.now()}@capstone.local`;
    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();
    await usersPage.emailInput.fill(email2);
    await usersPage.rutInput.fill(validRut);
    await usersPage.firstNameInput.fill('Otro');
    await usersPage.lastNameInput.fill('Duplicado');
    await usersPage.passwordInput.fill('Password123!');
    await usersPage.confirmPasswordInput.fill('Password123!');
    await usersPage.submitCreateButton.click();

    // El modal debe permanecer abierto mostrando error explicativo de RUT duplicado
    await expect(usersPage.createModal).toBeVisible();
    await expect(usersPage.errorMessage).toBeVisible({ timeout: 10000 });
    const errorText = await usersPage.errorMessage.textContent();
    expect(errorText?.toLowerCase()).toContain('ya está registrado');

    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });
});
