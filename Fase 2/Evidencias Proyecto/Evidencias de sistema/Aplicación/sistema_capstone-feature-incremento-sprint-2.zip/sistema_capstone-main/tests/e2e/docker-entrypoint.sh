#!/bin/bash
set -e

# Proxy local de puertos hacia la red interna de Docker
# Permite que las llamadas a localhost:3000 y localhost:8080 funcionen idénticas dentro del contenedor
FRONTEND_HOST="${FRONTEND_HOST:-capstone-frontend}"
FRONTEND_PORT="${FRONTEND_PORT:-80}"
KEYCLOAK_HOST="${KEYCLOAK_HOST:-capstone-keycloak}"
KEYCLOAK_PORT="${KEYCLOAK_PORT:-8080}"
BACKEND_HOST="${BACKEND_HOST:-capstone-sistema-principal}"
BACKEND_PORT="${BACKEND_PORT:-8081}"

if command -v socat >/dev/null 2>&1; then
    # Iniciar redirecciones en segundo plano
    socat TCP-LISTEN:3000,fork,reuseaddr,bind=127.0.0.1 TCP:${FRONTEND_HOST}:${FRONTEND_PORT} >/dev/null 2>&1 &
    socat TCP-LISTEN:8080,fork,reuseaddr,bind=127.0.0.1 TCP:${KEYCLOAK_HOST}:${KEYCLOAK_PORT} >/dev/null 2>&1 &
    socat TCP-LISTEN:8081,fork,reuseaddr,bind=127.0.0.1 TCP:${BACKEND_HOST}:${BACKEND_PORT} >/dev/null 2>&1 &
fi

if [ $# -eq 1 ]; then
    exec /bin/sh -c "$1"
else
    exec "$@"
fi

