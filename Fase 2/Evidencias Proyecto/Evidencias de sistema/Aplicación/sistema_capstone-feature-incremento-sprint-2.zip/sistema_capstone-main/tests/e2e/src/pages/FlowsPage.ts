import { Page, Locator, expect } from '@playwright/test';

export class FlowsPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly createFlowButton: Locator;
  readonly refreshButton: Locator;
  readonly searchInput: Locator;
  readonly areaFilter: Locator;
  readonly table: Locator;

  // Modal Flujo (Crear / Editar)
  readonly flowModal: Locator;
  readonly flowModalTitle: Locator;
  readonly flowNameInput: Locator;
  readonly flowDescriptionInput: Locator;
  readonly flowAreaSelect: Locator;
  readonly flowActiveCheckbox: Locator;
  readonly saveFlowButton: Locator;
  readonly cancelFlowButton: Locator;

  // Modal Etapas
  readonly stagesModal: Locator;
  readonly stagesModalTitle: Locator;
  readonly addStageButton: Locator;
  readonly saveStagesButton: Locator;
  readonly cancelStagesButton: Locator;
  readonly stagesError: Locator;

  // Modal Eliminación
  readonly deleteModal: Locator;
  readonly confirmDeleteButton: Locator;
  readonly cancelDeleteButton: Locator;

  // SLA Locators
  readonly tabFlujos: Locator;
  readonly tabSla: Locator;
  readonly createSlaButton: Locator;
  readonly slaModal: Locator;
  readonly slaTipoInput: Locator;
  readonly slaPlazoInput: Locator;
  readonly submitSlaButton: Locator;
  readonly editSlaModal: Locator;
  readonly editSlaPlazoInput: Locator;
  readonly submitEditSlaButton: Locator;
  readonly deleteSlaModal: Locator;
  readonly confirmDeleteSlaButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('h1, h2').filter({ hasText: /Flujos de aprobación|Configurar flujos|Matriz de plazos SLA/i });
    this.createFlowButton = page.locator('[data-testid="create-flow-btn"]');
    this.refreshButton = page.locator('button:has-text("Actualizar")');
    this.searchInput = page.locator('input[placeholder*="Buscar por nombre"]');
    this.areaFilter = page.locator('select[aria-label="Filtrar por área"]');
    this.table = page.locator('.flows-table, table');

    // Modal Flujo
    this.flowModal = page.locator('.flow-modal-dialog:has(#flow-dialog-title:has-text("flujo de aprobación")), .flow-modal-dialog:has(#flow-name)');
    this.flowModalTitle = page.locator('#flow-dialog-title');
    this.flowNameInput = this.flowModal.locator('#flow-name');
    this.flowDescriptionInput = this.flowModal.locator('#flow-description');
    this.flowAreaSelect = this.flowModal.locator('button#flow-area, select#flow-area');
    this.flowActiveCheckbox = this.flowModal.locator('input[type="checkbox"]');
    this.saveFlowButton = this.flowModal.locator('button[type="submit"]');
    this.cancelFlowButton = this.flowModal.locator('footer button:has-text("Cancelar")');

    // Modal Etapas
    this.stagesModal = page.locator('.flow-modal-dialog:has(#flow-dialog-title:has-text("Secuencia de revisión")), .flow-modal-dialog:has(.stages-builder)');
    this.stagesModalTitle = page.locator('#flow-dialog-title');
    this.addStageButton = this.stagesModal.locator('button:has-text("Agregar etapa")');
    this.saveStagesButton = this.stagesModal.locator('button[type="submit"]');
    this.cancelStagesButton = this.stagesModal.locator('footer button:has-text("Cancelar"), footer button:has-text("Cerrar")');
    this.stagesError = this.stagesModal.locator('[role="alert"], .feedback-message--error, .ui-feedback--error, .reviewer-selector p, .reviewer-selector [role="alert"]');

    // Modal Eliminación
    this.deleteModal = page.locator('.flow-modal-dialog:has(#flow-dialog-title:has-text("Eliminar")), .flow-modal-dialog:has(button:has-text("Confirmar eliminación"))');
    this.confirmDeleteButton = this.deleteModal.locator('button[type="submit"]:has-text("Confirmar eliminación"), button:has-text("Confirmar")');
    this.cancelDeleteButton = this.deleteModal.locator('footer button:has-text("Cancelar")');

    // SLA Locators
    this.tabFlujos = page.locator('[data-testid="tab-flujos"]');
    this.tabSla = page.locator('[data-testid="tab-sla"]');
    this.createSlaButton = page.locator('[data-testid="create-sla-btn"], [data-testid="empty-create-sla-btn"]').first();
    this.slaModal = page.locator('.flow-modal-dialog:has(#sla-rule-title:has-text("Nueva regla")), .flow-modal-dialog:has([data-testid="submit-sla-btn"])');
    this.slaTipoInput = page.locator('[data-testid="sla-tipo-input"]');
    this.slaPlazoInput = page.locator('[data-testid="sla-plazo-input"]');
    this.submitSlaButton = page.locator('[data-testid="submit-sla-btn"]');
    this.editSlaModal = page.locator('.flow-modal-dialog:has(#sla-rule-title:has-text("Editar plazo")), .flow-modal-dialog:has([data-testid="submit-edit-sla-btn"])');
    this.editSlaPlazoInput = page.locator('[data-testid="edit-sla-plazo-input"]');
    this.submitEditSlaButton = page.locator('[data-testid="submit-edit-sla-btn"]');
    this.deleteSlaModal = page.locator('.flow-modal-dialog:has(#sla-rule-title:has-text("Eliminar regla")), .flow-modal-dialog:has([data-testid="confirm-delete-sla-btn"])');
    this.confirmDeleteSlaButton = page.locator('[data-testid="confirm-delete-sla-btn"]');
  }

  private async selectDropdownOption(trigger: Locator, optionText: string) {
    const tagName = await trigger.evaluate((el) => el.tagName.toLowerCase()).catch(() => '');
    if (tagName === 'select') {
      await trigger.selectOption({ label: optionText });
    } else {
      await trigger.click();
      const option = this.page.locator('div[role="option"]').filter({ hasText: optionText }).first();
      await expect(option).toBeVisible({ timeout: 10000 });
      await option.click();
    }
  }

  async goto() {
    const navLink = this.page.locator('aside.sidebar nav a:has-text("Configurar flujos")');
    if (await navLink.isVisible({ timeout: 2000 }).catch(() => false)) {
      await navLink.click();
    } else {
      await this.page.goto('/configurar-flujos');
    }
  }

  async isDisplayed() {
    await expect(this.heading).toBeVisible({ timeout: 15000 });
    await expect(this.page.locator('.loading-state, text="Cargando flujos"')).toBeHidden({ timeout: 15000 }).catch(() => {});
  }

  getFlowRow(name: string): Locator {
    return this.page.locator(`tr:has(.flow-name:has-text("${name}"))`);
  }

  async createFlow(name: string, description: string = '', areaName?: string) {
    await this.createFlowButton.click();
    await expect(this.flowModal).toBeVisible({ timeout: 10000 });

    await this.flowNameInput.fill(name);
    if (description) {
      await this.flowDescriptionInput.fill(description);
    }
    if (areaName) {
      await this.selectDropdownOption(this.flowAreaSelect, areaName);
    }

    await this.saveFlowButton.click();
    await expect(this.flowModal).toBeHidden({ timeout: 25000 });
  }

  async openStagesModal(flowName: string) {
    const row = this.getFlowRow(flowName);
    await expect(row).toBeVisible({ timeout: 10000 });
    await row.locator('button:has-text("Configurar etapas")').click();
    await expect(this.stagesModal).toBeVisible({ timeout: 10000 });
  }

  getStageCard(index: number): Locator {
    return this.stagesModal.locator(`[data-testid="stage-item-${index}"]`);
  }

  async fillStage(index: number, name: string, reviewerLabel?: string) {
    const card = this.getStageCard(index);
    if (!(await card.isVisible({ timeout: 1500 }).catch(() => false))) {
      await this.addStageButton.click();
    }
    await expect(card).toBeVisible({ timeout: 10000 });

    const nameInput = card.locator(`input[id^="stage-name-"]`);
    await nameInput.fill(name);

    if (reviewerLabel) {
      const trigger = card.locator(`button[id$="-assignee"], select[id^="stage-reviewer-"]`).first();
      await expect(trigger).toBeEnabled({ timeout: 15000 });
      await expect(card.locator('text="Comprobando responsables disponibles…"')).toBeHidden({ timeout: 10000 }).catch(() => {});
      const simpleName = reviewerLabel.split('(')[0].trim();
      await this.selectDropdownOption(trigger, simpleName);
    }
  }

  async moveStageUp(index: number) {
    const card = this.getStageCard(index);
    await card.locator('button[aria-label^="Subir"]').click();
  }

  async moveStageDown(index: number) {
    const card = this.getStageCard(index);
    await card.locator('button[aria-label^="Bajar"]').click();
  }

  async removeStage(index: number) {
    const card = this.getStageCard(index);
    await card.locator('button[aria-label^="Eliminar"]').click();
  }

  async saveStages() {
    await expect(this.saveStagesButton).toBeEnabled({ timeout: 15000 });
    await this.saveStagesButton.click();
  }

  async deleteFlow(flowName: string) {
    await expect(this.page.locator('.loading-state, text="Cargando flujos"')).toBeHidden({ timeout: 15000 }).catch(() => {});
    const row = this.getFlowRow(flowName);
    if (!(await row.isVisible({ timeout: 5000 }).catch(() => false))) return;
    const deleteBtn = row.locator('button[title="Eliminar flujo"], button[aria-label*="Eliminar"], [data-testid^="delete-flow-btn"]');
    await deleteBtn.click();
    await expect(this.deleteModal).toBeVisible({ timeout: 10000 });
    await this.confirmDeleteButton.click();
    await expect(this.deleteModal).toBeHidden({ timeout: 25000 });
    await expect(this.getFlowRow(flowName)).toBeHidden({ timeout: 10000 });
  }

  // SLA Methods
  async switchToSlaTab() {
    await this.tabSla.click();
    await expect(this.page.locator('#sla-panel, table.sla-table, [data-testid="create-sla-btn"], [data-testid="empty-create-sla-btn"]').first()).toBeVisible({ timeout: 15000 });
  }

  async switchToFlujosTab() {
    await this.tabFlujos.click();
    await expect(this.page.locator('table[aria-label="Flujos de aprobación por área"], table:visible').first()).toBeVisible({ timeout: 10000 });
  }

  getSlaRow(tipo: string): Locator {
    return this.page.locator(`tr:has([data-testid^="sla-tipo"]:has-text("${tipo}"))`);
  }

  async createSlaRule(tipo: string, dias: number) {
    await this.switchToSlaTab();
    await this.createSlaButton.click();
    await expect(this.slaModal).toBeVisible({ timeout: 5000 });
    await this.slaTipoInput.fill(tipo);
    await this.slaPlazoInput.fill(String(dias));
    await this.submitSlaButton.click();
    await expect(this.slaModal).toBeHidden({ timeout: 10000 });
  }

  async updateSlaRule(tipo: string, dias: number) {
    await this.switchToSlaTab();
    const row = this.getSlaRow(tipo);
    await expect(row).toBeVisible({ timeout: 5000 });
    await row.locator('button:has-text("Editar plazo")').click();
    await expect(this.editSlaModal).toBeVisible({ timeout: 5000 });
    await this.editSlaPlazoInput.fill(String(dias));
    await this.submitEditSlaButton.click();
    await expect(this.editSlaModal).toBeHidden({ timeout: 10000 });
  }

  async deleteSlaRule(tipo: string) {
    await this.switchToSlaTab();
    const row = this.getSlaRow(tipo);
    await expect(row).toBeVisible({ timeout: 5000 });
    await row.locator('button[title*="Eliminar"]').click();
    await expect(this.deleteSlaModal).toBeVisible({ timeout: 5000 });
    await this.confirmDeleteSlaButton.click();
    await expect(this.deleteSlaModal).toBeHidden({ timeout: 10000 });
    await expect(this.getSlaRow(tipo)).toBeHidden({ timeout: 5000 });
  }
}
