import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { FlowsPage } from '../../pages/FlowsPage';

test.describe.serial('Matriz de Plazos SLA y Alertas Visuales (HU-S2-08 / E2E-SLA-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let flowsPage: FlowsPage;

  const runId = Date.now();
  const contratoTitle = `Contrato de Servicios para Proveedores ${runId}`;
  const ocTitle = `Orden de Compra Insumos ${runId}`;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    flowsPage = new FlowsPage(page);
  });

  test('1. [CA 8.1, 8.5] Administrador accede a la matriz SLA, define plazos por tipo y actualiza reglas', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Administrador
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Configurar Flujos y cambiar a pestaña SLA
    await flowsPage.goto();
    await flowsPage.isDisplayed();
    await flowsPage.switchToSlaTab();

    // 3. Verificar que la pestaña SLA despliega la matriz y el botón de nueva regla
    await expect(flowsPage.createSlaButton).toBeVisible({ timeout: 10000 });

    // Limpieza preventiva si existían reglas con el mismo nombre para asegurar idempotencia
    const existingContrato = flowsPage.getSlaRow('Contrato de Servicios');
    if (await existingContrato.isVisible({ timeout: 2000 }).catch(() => false)) {
      await flowsPage.deleteSlaRule('Contrato de Servicios');
    }
    const existingOc = flowsPage.getSlaRow('Orden de Compra');
    if (await existingOc.isVisible({ timeout: 2000 }).catch(() => false)) {
      await flowsPage.deleteSlaRule('Orden de Compra');
    }

    // 4. CA 8.1: Configurar regla "Contrato de Servicios" con plazo de 4 días hábiles
    await flowsPage.createSlaRule('Contrato de Servicios', 4);
    const contratoRow = flowsPage.getSlaRow('Contrato de Servicios');
    await expect(contratoRow).toBeVisible({ timeout: 10000 });
    await expect(contratoRow.locator('[data-testid^="sla-plazo"]')).toContainText('4 días hábiles');

    // 5. CA 8.1: Configurar regla "Orden de Compra" con plazo inicial de 2 días hábiles
    await flowsPage.createSlaRule('Orden de Compra', 2);
    const ocRow = flowsPage.getSlaRow('Orden de Compra');
    await expect(ocRow).toBeVisible({ timeout: 10000 });
    await expect(ocRow.locator('[data-testid^="sla-plazo"]')).toContainText('2 días hábiles');

    // 6. Actualizar regla: Modificar plazo de "Orden de Compra" a 3 días hábiles
    await flowsPage.updateSlaRule('Orden de Compra', 3);
    await expect(ocRow.locator('[data-testid^="sla-plazo"]')).toContainText('3 días hábiles');
  });

  test('2. [CA 8.5] Control RBAC: Usuario sin rol ADMIN no tiene acceso a la matriz SLA ni por UI ni por API', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Revisor (usuario operativo sin rol ADMIN)
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await dashboardPage.isDisplayed();

    // 2. Verificar que en la barra lateral NO existe el enlace a Configurar Flujos
    const configFlujosLink = page.locator('aside.sidebar a[href="/configurar-flujos"]');
    await expect(configFlujosLink).toHaveCount(0);

    // 3. Intentar navegar directamente a /configurar-flujos en la URL
    await page.goto('/configurar-flujos');
    // Debe ser redirigido automáticamente al dashboard por regla de protección en App.jsx
    await page.waitForURL('**/dashboard', { timeout: 15000 });
    await expect(dashboardPage.brandTitle).toBeVisible();

    // 4. Intentar invocar la API protegida de creación SLA usando el token del revisor
    const apiResult = await page.evaluate(async () => {
      try {
        await (window as any).api.post('/api/sla', {
          tipoDocumento: 'Regla No Autorizada',
          plazoDias: 5
        });
        return { authorized: true, status: 200 };
      } catch (err: any) {
        return {
          authorized: false,
          status: err.response?.status || (err.status ?? 0)
        };
      }
    });

    // CA 8.5: Spring Security debe retornar HTTP 403 Forbidden
    expect(apiResult.authorized).toBe(false);
    expect(apiResult.status).toBe(403);
  });

  test('3. [CA 8.2] Cómputo del plazo inicia al registrarse la solicitud y excluye fines de semana', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Admin / Emisor
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Registrar Documento
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible({ timeout: 15000 });

    // Seleccionar tipo de documento según catálogo (Fase F2)
    const tipoSelect = page.locator('#document-tipo');
    if (await tipoSelect.isVisible().catch(() => false)) {
      await tipoSelect.selectOption('Contrato de Servicios');
    }

    // Seleccionar flujo activo para habilitar el botón de envío
    const flowPicker = page.locator('#document-flujo');
    if (await flowPicker.isVisible().catch(() => false)) {
      await flowPicker.click();
      await page.locator('[role="option"]:not([aria-disabled="true"])').first().click();
    }

    // 3. Registrar documento de tipo "Contrato de Servicios" (regla configurada de 4 días hábiles)
    await page.fill('#document-title', contratoTitle);
    await page.fill('#document-description', 'Solicitud contractual para validación de cálculo de deadline en días hábiles.');
    await page.setInputFiles('#document-file', {
      name: `contrato_servicios_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contenido del contrato de servicios para prueba de SLA.')
    });

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 4. Consultar la solicitud registrada vía API para inspeccionar el deadline computado
    const queryResult = await page.evaluate(async (title: string) => {
      const resp = await (window as any).api.get('/api/solicitudes/pendientes-revision', {
        params: { pagina: 0, tamanio: 20 }
      });
      const items = resp.data?.contenido || resp.data?.content || resp.data || [];
      return items.find((item: any) => item.titulo === title);
    }, contratoTitle);

    expect(queryResult).toBeTruthy();
    expect(queryResult.deadline).toBeTruthy();
    expect(queryResult.fechaCreacion).toBeTruthy();

    const createdTime = new Date(queryResult.fechaCreacion).getTime();
    const deadlineTime = new Date(queryResult.deadline).getTime();

    // CA 8.2: El deadline debe ser posterior a la fecha de creación
    expect(deadlineTime).toBeGreaterThan(createdTime);

    // Verificar que entre creación y deadline hayan transcurrido al menos 4 días (4 días hábiles >= 4 días naturales)
    const diffDays = (deadlineTime - createdTime) / (1000 * 60 * 60 * 24);
    expect(diffDays).toBeGreaterThanOrEqual(3.8); // al menos 4 días naturales
    expect(diffDays).toBeLessThanOrEqual(6.2); // máximo 6 días naturales (4 días + fin de semana)

    // CA 8.2: La fecha de vencimiento NO debe caer en día sábado ni domingo
    const deadlineDate = new Date(queryResult.deadline);
    const dayOfWeek = deadlineDate.getDay(); // 0 = Domingo, 6 = Sábado
    expect(dayOfWeek).not.toBe(0);
    expect(dayOfWeek).not.toBe(6);
  });

  test('4. [CA 8.3] Alertas visuales semánticas desplegadas en la bandeja de revisión y modal de detalle', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Revisor
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Bandeja de Revisión
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible({ timeout: 15000 });

    // 3. Ubicar la fila de la solicitud recién registrada
    const row = page.locator(`tr:has-text("${contratoTitle}")`);
    await expect(row).toBeVisible({ timeout: 25000 });

    // CA 8.3: Debe exhibir badge semántico "A tiempo" en la columna de Plazo SLA
    const slaBadge = row.locator('[data-testid="sla-badge-a-tiempo"], [data-testid="sla-badge-normal"]');
    await expect(slaBadge).toBeVisible();
    await expect(slaBadge).toHaveText('A tiempo');

    // Debe mostrar la fecha/hora estimada de vencimiento
    await expect(row.locator('.sla-deadline-text')).toBeVisible();

    // 4. Abrir modal de detalle haciendo clic en la fila
    await row.click();
    const detailModal = page.locator('.review-detail-modal');
    await expect(detailModal).toBeVisible({ timeout: 10000 });

    // CA 8.3: En la tarjeta de resumen del modal de detalle, debe desplegar badge "A tiempo" y plazo
    const detailSlaBadge = page.locator('[data-testid="detail-sla-badge-a-tiempo"], [data-testid="detail-sla-badge-normal"]');
    await expect(detailSlaBadge).toBeVisible();
    await expect(detailSlaBadge).toHaveText('A tiempo');
  });

  test('5. [CA 8.4] Decisiones del flujo (aprobación y corrección) evalúan cumplimiento de SLA y persisten dentro_sla = true', async ({ page }) => {
    test.setTimeout(90000);

    // 1. Iniciar sesión como Revisor
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Bandeja de Revisión
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible({ timeout: 15000 });

    // 3. Localizar el documento de "Contrato de Servicios" y abrir modal
    const row = page.locator(`tr:has-text("${contratoTitle}")`);
    await expect(row).toBeVisible({ timeout: 25000 });
    await row.click();
    await expect(page.locator('.review-detail-modal')).toBeVisible({ timeout: 10000 });

    // 4. Obtener ID de la solicitud desde el estado o API
    const solicitudId = await page.evaluate(async (title: string) => {
      const resp = await (window as any).api.get('/api/solicitudes/pendientes-revision', {
        params: { pagina: 0, tamanio: 20 }
      });
      const items = resp.data?.contenido || resp.data?.content || resp.data || [];
      const match = items.find((item: any) => item.titulo === title);
      return match?.id;
    }, contratoTitle);

    expect(solicitudId).toBeTruthy();

    // 5. CA 8.4: Ejecutar acción de APROBACIÓN dentro del plazo vigente
    await page.click('[data-testid="btn-aprobar"]');
    await expect(page.locator('.review-action-modal')).toBeVisible({ timeout: 5000 });
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.review-feedback-toast, .form-message-success')).toBeVisible({ timeout: 25000 });

    // 6. CA 8.4: Verificar en el historial de transiciones que la decisión registró dentro_sla = true
    const transitions = await page.evaluate(async (id: string) => {
      const resp = await (window as any).api.get(`/api/solicitudes/${id}/historial`);
      return resp.data;
    }, solicitudId);

    expect(Array.isArray(transitions)).toBe(true);
    const aprobacionTransicion = transitions.find((t: any) => t.accion === 'APROBAR' || t.estadoDestino === 'APROBADO');
    expect(aprobacionTransicion).toBeTruthy();
    expect(aprobacionTransicion.dentroSla).toBe(true);

    // 7. CA 8.4: Verificar también decisión de "Pedir Corrección" con una segunda solicitud
    // 7.1 Registrar solicitud "Orden de Compra Insumos" como Admin
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible({ timeout: 15000 });

    // Seleccionar tipo de documento según catálogo (Fase F2)
    const tipoSelectOc = page.locator('#document-tipo');
    if (await tipoSelectOc.isVisible().catch(() => false)) {
      await tipoSelectOc.selectOption('Orden de Compra');
    }

    // Seleccionar flujo activo para habilitar el botón de envío
    const flowPickerOc = page.locator('#document-flujo');
    if (await flowPickerOc.isVisible().catch(() => false)) {
      await flowPickerOc.click();
      await page.locator('[role="option"]:not([aria-disabled="true"])').first().click();
    }

    await page.fill('#document-title', ocTitle);
    await page.fill('#document-description', 'Solicitud de orden de compra para verificar SLA en correcciones.');
    await page.setInputFiles('#document-file', {
      name: `oc_insumos_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contenido de orden de compra preliminar.')
    });
    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 7.2 Revisor ingresa a revisar y solicita corrección
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible({ timeout: 15000 });

    const ocRow = page.locator(`tr:has-text("${ocTitle}")`);
    await expect(ocRow).toBeVisible({ timeout: 25000 });
    await ocRow.click();
    await expect(page.locator('.review-detail-modal')).toBeVisible({ timeout: 10000 });

    const ocSolicitudId = await page.evaluate(async (title: string) => {
      const resp = await (window as any).api.get('/api/solicitudes/pendientes-revision', {
        params: { pagina: 0, tamanio: 20 }
      });
      const items = resp.data?.contenido || resp.data?.content || resp.data || [];
      const match = items.find((item: any) => item.titulo === title);
      return match?.id;
    }, ocTitle);

    expect(ocSolicitudId).toBeTruthy();

    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.review-action-modal')).toBeVisible({ timeout: 5000 });
    await page.fill('[data-testid="modal-comment-input"]', 'Se requiere adjuntar desglose detallado de precios unitarios.');
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.review-feedback-toast, .form-message-success')).toBeVisible({ timeout: 25000 });

    // 7.3 Verificar que la transición de corrección también registró dentro_sla = true
    const ocTransitions = await page.evaluate(async (id: string) => {
      const resp = await (window as any).api.get(`/api/solicitudes/${id}/historial`);
      return resp.data;
    }, ocSolicitudId);

    const correccionTransicion = ocTransitions.find((t: any) => t.accion === 'PEDIR_CORRECCION' || t.estadoDestino === 'REQUIERE_AJUSTES');
    expect(correccionTransicion).toBeTruthy();
    expect(correccionTransicion.dentroSla).toBe(true);
  });
});
