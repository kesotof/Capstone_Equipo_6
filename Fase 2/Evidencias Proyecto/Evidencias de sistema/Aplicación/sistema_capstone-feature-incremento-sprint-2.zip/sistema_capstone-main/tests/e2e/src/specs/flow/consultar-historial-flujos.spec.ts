import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import * as fs from 'fs';

const CONTEXT_FILE = '/app/test-results/test-historial-context.json';

test.describe.serial('[TEST] Validación de criterios de aceptación para Consultar historial de flujos', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 1] Verificar orden cronológico estricto e inclusión de qué ocurrió, quién lo realizó y cuándo', async ({ page }) => {
    test.setTimeout(80000);

    const runId = Date.now();
    const requestTitle = `Solicitud Auditoria Historial E2E ${runId}`;
    const observacionTexto = `OBS-HISTORIAL-${runId}: Cláusula de confidencialidad y entregables deben ser detallados antes de continuar.`;

    // 1. Iniciar sesión como Emisor / Administrador
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Registrar nuevo documento (generando primer evento en el historial: REGISTRAR)
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Solicitud para validación completa del historial de flujo y auditoría.');
    await page.setInputFiles('#document-file', {
      name: `contrato_auditoria_${runId}.pdf`,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Historial test stream content')
    });

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 3. Revisar el documento (generando segundo evento: SOLICITAR_CORRECCION con comentario)
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    const rowReview = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowReview).toBeVisible({ timeout: 20000 });
    await rowReview.click();

    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();
    await page.fill('[data-testid="modal-comment-input"]', observacionTexto);
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.page-message.form-message-success, .form-message-success')).toBeVisible({ timeout: 25000 });

    // 4. Navegar a Estado Solicitudes para consultar el historial completo
    const misSolicitudesPromise = page.waitForResponse(
      (resp) => resp.url().includes('/api/solicitudes/mis-solicitudes') && resp.status() === 200
    );
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const misSolResp = await misSolicitudesPromise;
    const items = await misSolResp.json();
    const currentItem = items.find((s: any) => s.titulo === requestTitle);
    expect(currentItem).toBeDefined();
    const createdSolicitudId = currentItem.id;

    // Guardar contexto para los siguientes tests de la suite
    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      createdSolicitudId,
      requestTitle,
      observacionTexto
    }));

    // 5. Seleccionar la solicitud en la lista maestra para abrir el panel de detalle
    const rowEstado = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowEstado).toBeVisible({ timeout: 15000 });

    const historialPromise = page.waitForResponse(
      (resp) => resp.url().includes(`/api/solicitudes/${createdSolicitudId}/historial`) && resp.status() === 200
    );
    await rowEstado.click();
    await historialPromise;

    await expect(page.locator('.inline-loading')).not.toBeVisible({ timeout: 10000 });

    // 6. Verificar contenedor de línea de tiempo e ítems del historial
    const timelineContainer = page.locator('[data-testid="timeline-container"]');
    await expect(timelineContainer).toBeVisible({ timeout: 15000 });
    await timelineContainer.scrollIntoViewIfNeeded();

    const timelineItems = timelineContainer.locator('[data-testid="timeline-item"]');
    await expect(timelineItems.first()).toBeVisible({ timeout: 15000 });
    const count = await timelineItems.count();
    expect(count).toBeGreaterThanOrEqual(2);

    // 7. CRITERIO 1: Validar inclusión de Qué Ocurrió, Quién lo realizó y Cuándo
    // Primer ítem del timeline (orden cronológico ascendente: CREAR)
    const firstItem = timelineItems.first();
    await expect(firstItem.locator('.timeline-title')).toBeVisible();
    await expect(firstItem.locator('.timeline-title')).toContainText('CREAR');
    await expect(firstItem.locator('.timeline-meta')).toContainText(/Admin Capstone|admin@capstone\.local|Administrador/i);

    // Segundo ítem del timeline (evento posterior: PEDIR_CORRECCION)
    const secondItem = timelineItems.nth(1);
    await expect(secondItem.locator('.timeline-title')).toBeVisible();
    await expect(secondItem.locator('.timeline-title')).toContainText('PEDIR_CORRECCION');
    await expect(secondItem.locator('.timeline-meta')).toContainText(/Admin Capstone|admin@capstone\.local|Administrador/i);

    // 8. CRITERIO 1: Validar orden cronológico estricto a través de la API
    const historialApiData = await page.evaluate(async (id) => {
      const resp = await window.api.get(`/api/solicitudes/${id}/historial`);
      return resp.data;
    }, createdSolicitudId);

    expect(Array.isArray(historialApiData)).toBeTruthy();
    expect(historialApiData.length).toBeGreaterThanOrEqual(2);

    // Backend devuelve en orden estrictamente ascendente por createdAt
    for (let i = 0; i < historialApiData.length - 1; i++) {
      const timeCurrent = new Date(historialApiData[i].createdAt).getTime();
      const timeNext = new Date(historialApiData[i + 1].createdAt).getTime();
      expect(timeCurrent).toBeLessThanOrEqual(timeNext);
    }

    // Verificar que los datos del evento contienen qué ocurrió, quién y cuándo
    const registroEvent = historialApiData[0];
    expect(registroEvent.accion).toBe('CREAR');
    expect(registroEvent.usuarioEmail).toContain('admin@capstone.local');
    expect(registroEvent.createdAt).toBeTruthy();

    const correccionEvent = historialApiData[1];
    expect(correccionEvent.accion).toBe('PEDIR_CORRECCION');
    expect(correccionEvent.usuarioEmail).toContain('admin@capstone.local');
    expect(correccionEvent.createdAt).toBeTruthy();

    // Evidencia fotográfica para Criterio 1
    await page.screenshot({
      path: '/app/test-results/screenshots/01-historial-orden-cronologico-y-metadata.png',
      fullPage: true
    });
  });

  test('2. [CA 2] Presencia de observaciones de revisores en el historial', async ({ page }) => {
    test.setTimeout(75000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle, observacionTexto } = contextData;

    // 1. Iniciar sesión como emisor/admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Navegar a Estado Solicitudes y abrir el detalle
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const row = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(row).toBeVisible({ timeout: 15000 });

    const histPromise = page.waitForResponse(
      (resp) => resp.url().includes(`/api/solicitudes/${createdSolicitudId}/historial`) && resp.status() === 200
    );
    await row.click();
    await histPromise;

    await expect(page.locator('.inline-loading')).not.toBeVisible({ timeout: 10000 });

    // 3. CRITERIO 2: Verificar la presencia de la observación del revisor en la UI
    const commentBlock = page.locator('.timeline-comment', { hasText: observacionTexto });
    await expect(commentBlock).toBeVisible({ timeout: 15000 });
    await commentBlock.scrollIntoViewIfNeeded();
    await expect(commentBlock).toContainText(observacionTexto);

    // 4. CRITERIO 2: Verificar también a nivel API de historial
    const transitionWithComment = await page.evaluate(async (id) => {
      const resp = await window.api.get(`/api/solicitudes/${id}/historial`);
      return resp.data.find((t: any) => t.accion === 'PEDIR_CORRECCION');
    }, createdSolicitudId);

    expect(transitionWithComment).toBeDefined();
    expect(transitionWithComment.comentario).toBe(observacionTexto);
    expect(transitionWithComment.accion).toBe('PEDIR_CORRECCION');

    // Evidencia fotográfica para Criterio 2
    await page.screenshot({
      path: '/app/test-results/screenshots/02-observaciones-revisor-en-historial.png',
      fullPage: true
    });
  });

  test('3. [CA 3] Inmutabilidad del historial (sin endpoints de modificación o borrado)', async ({ page }) => {
    test.setTimeout(75000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId } = contextData;

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // CRITERIO 3: Inmutabilidad
    // Validar que el historial es de solo lectura y no existen endpoints para modificarlo o eliminarlo
    const mutationResults = await page.evaluate(async (id) => {
      const results: Record<string, number> = {};

      try {
        const putResp = await window.api.put(`/api/solicitudes/${id}/historial`, { comentario: 'Hack' });
        results['PUT'] = putResp.status;
      } catch (err: any) {
        results['PUT'] = err.response?.status || 500;
      }

      try {
        const patchResp = await window.api.patch(`/api/solicitudes/${id}/historial`, { comentario: 'Hack' });
        results['PATCH'] = patchResp.status;
      } catch (err: any) {
        results['PATCH'] = err.response?.status || 500;
      }

      try {
        const deleteResp = await window.api.delete(`/api/solicitudes/${id}/historial`);
        results['DELETE'] = deleteResp.status;
      } catch (err: any) {
        results['DELETE'] = err.response?.status || 500;
      }

      try {
        const deleteItemResp = await window.api.delete(`/api/solicitudes/${id}/historial/1`);
        results['DELETE_ITEM'] = deleteItemResp.status;
      } catch (err: any) {
        results['DELETE_ITEM'] = err.response?.status || 500;
      }

      return results;
    }, createdSolicitudId);

    // Métodos no permitidos retornan 405 Method Not Allowed o 404 Not Found (nunca 200/201/204)
    expect([401, 404, 405]).toContain(mutationResults['PUT']);
    expect([401, 404, 405]).toContain(mutationResults['PATCH']);
    expect([401, 404, 405]).toContain(mutationResults['DELETE']);
    expect([401, 404, 405]).toContain(mutationResults['DELETE_ITEM']);

    // Verificar en la UI que la línea de tiempo no renderiza controles de borrado/edición
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const timelineDeleteBtn = page.locator('[data-testid="timeline-container"] button:has-text("Eliminar")');
    const timelineEditBtn = page.locator('[data-testid="timeline-container"] button:has-text("Editar")');
    await expect(timelineDeleteBtn).not.toBeVisible();
    await expect(timelineEditBtn).not.toBeVisible();

    // Evidencia fotográfica para Criterio 3
    await page.screenshot({
      path: '/app/test-results/screenshots/03-inmutabilidad-historial.png',
      fullPage: true
    });
  });

  test('4. [CA 4] Control de acceso al historial según permisos sobre la solicitud', async ({ page, request }) => {
    test.setTimeout(75000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle } = contextData;

    // 1. Acceso NO autenticado: petición sin token debe retornar 401 Unauthorized
    const unauthResponse = await request.get(`http://sistema-principal:8081/api/solicitudes/${createdSolicitudId}/historial`);
    expect(unauthResponse.status()).toBe(401);

    // 2. Solicitud inexistente con usuario autenticado debe retornar 404 Not Found
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    const notFoundStatus = await page.evaluate(async () => {
      try {
        const resp = await window.api.get('/api/solicitudes/00000000-0000-0000-0000-000000000000/historial');
        return resp.status;
      } catch (err: any) {
        return err.response?.status || 500;
      }
    });
    expect(notFoundStatus).toBe(404);

    // 3. Usuario ajeno/sin permisos en la UI y API:
    await page.click('button.logout-btn');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    // En "Mis solicitudes", la solicitud creada por otro usuario no debe aparecer
    await expect(page.locator(`tr:has-text("${requestTitle}")`)).not.toBeVisible();

    // Comprobar control de acceso según permisos a nivel API:
    // Para solicitudes sin área corporativa asignada (Sprint 1) permite acceso autenticado (200),
    // y si tuviera restricción de área rechazaría con 403 Forbidden (validado en backend MockMvc).
    const apiAccessStatus = await page.evaluate(async (id) => {
      try {
        const resp = await window.api.get(`/api/solicitudes/${id}/historial`);
        return resp.status;
      } catch (err: any) {
        return err.response?.status || 500;
      }
    }, createdSolicitudId);
    expect([200, 403]).toContain(apiAccessStatus);

    // Evidencia fotográfica para Criterio 4
    await page.screenshot({
      path: '/app/test-results/screenshots/04-control-acceso-historial.png',
      fullPage: true
    });
  });
});
