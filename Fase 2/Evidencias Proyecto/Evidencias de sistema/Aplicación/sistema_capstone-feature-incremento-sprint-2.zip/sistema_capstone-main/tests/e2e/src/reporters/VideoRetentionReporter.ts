import type { FullConfig, FullResult, Reporter } from '@playwright/test/reporter';
import fs from 'fs';
import path from 'path';

/**
 * Reporter personalizado para la retención condicional de videos de Playwright.
 * Regla: Los videos de la suite solo se conservan si la ejecución completa termina 100% exitosa (passed).
 * Si ocurre cualquier fallo o interrupción, los archivos de video son eliminados automáticamente.
 */
export default class VideoRetentionReporter implements Reporter {
  private outputDirs: string[] = [];

  onBegin(config: FullConfig) {
    this.outputDirs = [];
    for (const project of config.projects) {
      if (project.outputDir) {
        this.outputDirs.push(project.outputDir);
      }
    }
    const fallbackDir = path.resolve(process.cwd(), 'test-results');
    if (!this.outputDirs.includes(fallbackDir)) {
      this.outputDirs.push(fallbackDir);
    }
  }

  async onEnd(result: FullResult) {
    const allPassed = result.status === 'passed';

    if (!allPassed) {
      console.log('\n[VideoRetention] ⚠️ La suite de pruebas no finalizó al 100%. Descartando videos de ejecución...');
      for (const dir of this.outputDirs) {
        this.deleteVideos(dir);
      }
      console.log('[VideoRetention] Videos descartados. Solo se conservan evidencias de video cuando todas las pruebas pasan.\n');
    } else {
      console.log('\n[VideoRetention] ✅ ¡Todas las pruebas pasaron exitosamente!');
      console.log('[VideoRetention] Grabaciones en video conservadas en test-results/ como evidencia completa de la suite.\n');
    }
  }

  private deleteVideos(dir: string) {
    if (!fs.existsSync(dir)) return;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          this.deleteVideos(fullPath);
        } else if (entry.isFile() && (entry.name.endsWith('.webm') || entry.name.endsWith('.mp4'))) {
          try {
            fs.unlinkSync(fullPath);
          } catch {
            // Ignorar si el archivo está en uso momentáneamente
          }
        }
      }
    } catch (err) {
      console.error('[VideoRetention] Error limpiando videos:', err);
    }
  }
}
