import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe.serial('[TEST] Validación de criterios de aceptación para Ver revisiones pendientes (sin roles)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  const runId = Date.now();
  const requestTitle = `Solicitud Revision Pendiente E2E ${runId}`;
  const fileName = `doc_revision_${runId}.pdf`;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 1] Acceso a la bandeja de revisiones por cualquier usuario autenticado (Sprint 1 - Sin roles)', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como usuario estándar/emisor
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(page.locator('aside.sidebar')).toBeVisible({ timeout: 15000 });

    // 2. Navegar a Revisar Documentos (Bandeja de revisión)
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#revisar-title')).toContainText(/pendientes de revisión|revisar documentos/i);

    // 3. Comprobar que la vista y la bandeja de revisión cargan correctamente
    await expect(page.locator('.review-table-card')).toBeVisible();
    await expect(page.locator('.review-table-heading h3')).toContainText('Bandeja de revisión');

    // 4. Validación a nivel API: cualquier usuario autenticado accede a /api/solicitudes/pendientes-revision
    const apiAccessResult = await page.evaluate(async () => {
      try {
        const resp = await window.api.get('/api/solicitudes/pendientes-revision', {
          params: { pagina: 0, tamanio: 10 }
        });
        return {
          status: resp.status,
          totalElementos: resp.data?.totalElementos,
          isPaginaValida: typeof resp.data?.pagina === 'number'
        };
      } catch (err) {
        return { status: err.response?.status };
      }
    });

    expect(apiAccessResult.status).toBe(200);
    expect(apiAccessResult.isPaginaValida).toBe(true);

    // Captura de evidencia para CA 1
    await page.screenshot({
      path: '/app/test-results/screenshots/01-acceso-bandeja-usuario-autenticado.png',
      fullPage: true
    });
  });

  test('2. [CA 2] Listado de documentos en estado pendiente de revisión y visualización de detalle', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Registrar una solicitud pendiente para asegurar existencia de datos frescos
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Solicitud creada para verificar su aparición en la bandeja de revisión.');
    await page.setInputFiles('#document-file', {
      name: fileName,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Contrato de prueba para verificación de bandeja de revisiones pendientes.')
    });

    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 3. Navegar a la bandeja de revisión esperando la respuesta del endpoint
    const listResponsePromise = page.waitForResponse(
      (resp) => resp.url().includes('/api/solicitudes/pendientes-revision') && resp.status() === 200,
      { timeout: 20000 }
    ).catch(() => null);
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await listResponsePromise;
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 4. Ubicar la fila de la solicitud recién registrada
    const row = page.locator('.review-data-table tbody tr').filter({ hasText: requestTitle }).first();
    await expect(row).toBeVisible({ timeout: 20000 });

    // 5. Validar las columnas de información requeridas (CA 5.2):
    // Documento (título y archivo), Emisor, Fecha de envío y Estado
    await expect(row.locator('td[data-label="Documento"]')).toContainText(requestTitle);
    await expect(row.locator('td[data-label="Documento"]')).toContainText(fileName);
    await expect(row.locator('td[data-label="Emisor"]')).toContainText(/@capstone\.local/i);
    await expect(row.locator('td[data-label="Fecha de envío"]')).toBeVisible();
    await expect(row.locator('td[data-label="Estado"] .status-badge')).toContainText(/Pendiente/i);

    // 6. Seleccionar la solicitud para abrir el modal de detalle
    await row.locator('.review-open-detail').click();
    const modalDetail = page.locator('.review-detail-modal');
    await expect(modalDetail).toBeVisible({ timeout: 15000 });

    // Verificar contenido del detalle cargado
    await expect(page.locator('#review-detail-title')).toContainText(requestTitle);
    await expect(page.locator('[data-testid="btn-descargar"]')).toBeVisible();
    await expect(page.locator('[data-testid="btn-aprobar"]')).toBeVisible();
    await expect(page.locator('[data-testid="btn-pedir-correccion"]')).toBeVisible();
    await expect(page.locator('[data-testid="btn-rechazar"]')).toBeVisible();

    // Captura de evidencia para CA 2 con modal de detalle abierto
    await page.screenshot({
      path: '/app/test-results/screenshots/02-listado-documentos-pendientes-detalle.png',
      fullPage: true
    });

    // Cerrar el modal
    await page.locator('.review-detail-modal-header button[aria-label="Cerrar detalle"]').click();
    await expect(modalDetail).not.toBeVisible();
  });

  test('3. [CA 3] Filtro por nombre de archivo (búsqueda positiva y negativa)', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Navegar a la bandeja de revisión
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 3. Verificar que la sección de filtros está visible
    const filterCard = page.locator('.review-filter-card');
    await expect(filterCard).toBeVisible({ timeout: 15000 });

    // 4. Búsqueda positiva por nombre de archivo
    const inputNombre = page.locator('input[name="nombreArchivo"]');
    await inputNombre.fill(fileName);
    await page.waitForTimeout(600); // Espera de debounce de búsqueda (350ms)

    const row = page.locator('.review-data-table tbody tr').filter({ hasText: requestTitle }).first();
    await expect(row).toBeVisible({ timeout: 15000 });
    await expect(row.locator('td[data-label="Documento"]')).toContainText(fileName);

    // 5. Búsqueda negativa (archivo inexistente)
    await inputNombre.fill(`archivo_inexistente_${runId}_xyz`);
    await page.waitForTimeout(600); // Espera de debounce

    // La fila no debe aparecer y debe mostrar estado de bandeja vacía para los filtros
    await expect(row).not.toBeVisible();
    await expect(page.locator('[data-testid="empty-pendientes"]')).toBeVisible({ timeout: 10000 });

    // Limpiar filtro de nombre de archivo
    await inputNombre.fill('');
    await page.waitForTimeout(600);

    // Captura de evidencia para CA 3
    await page.screenshot({
      path: '/app/test-results/screenshots/03-filtro-nombre-archivo.png',
      fullPage: true
    });
  });

  test('4. [CA 4] Filtro por emisor, por rango de fechas y reseteo de filtros', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Navegar a la bandeja de revisión
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 3. Verificar que la sección de filtros está visible
    const filterCard = page.locator('.review-filter-card');
    await expect(filterCard).toBeVisible({ timeout: 15000 });

    // 4. Filtro por emisor
    const inputEmisor = page.locator('input[name="emisor"]');
    await inputEmisor.fill('admin@capstone.local');
    await page.waitForTimeout(600); // Espera debounce

    const row = page.locator('.review-data-table tbody tr').filter({ hasText: requestTitle }).first();
    await expect(row).toBeVisible({ timeout: 15000 });
    await expect(row.locator('td[data-label="Emisor"]')).toContainText('admin@capstone.local');

    // Filtro por emisor inexistente
    await inputEmisor.fill('usuario_inexistente_999@capstone.local');
    await page.waitForTimeout(600);
    await expect(row).not.toBeVisible();
    await expect(page.locator('[data-testid="empty-pendientes"]')).toBeVisible({ timeout: 10000 });

    // Limpiar emisor
    await inputEmisor.fill('');
    await page.waitForTimeout(600);

    // 5. Filtro por rango de fechas (Fecha actual)
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const fechaActual = `${year}-${month}-${day}`;

    // Seleccionar Fecha Desde usando botón "Hoy" o celda del día
    await page.getByTestId('fechaDesde-trigger').click();
    const btnHoyDesde = page.locator('.review-calendar-footer button', { hasText: 'Hoy' });
    if (await btnHoyDesde.isVisible()) {
      await btnHoyDesde.click();
    } else {
      await page.locator(`.review-calendar button[data-value="${fechaActual}"]`).first().click();
    }

    // Seleccionar Fecha Hasta usando botón "Hoy" o celda del día
    await page.getByTestId('fechaHasta-trigger').click();
    const btnHoyHasta = page.locator('.review-calendar-footer button', { hasText: 'Hoy' });
    if (await btnHoyHasta.isVisible()) {
      await btnHoyHasta.click();
    } else {
      await page.locator(`.review-calendar button[data-value="${fechaActual}"]`).first().click();
    }

    await page.waitForTimeout(600);
    await expect(row).toBeVisible({ timeout: 15000 });

    // 6. Probar botón "Limpiar filtros"
    await page.click('.review-clear-filters');
    await page.waitForTimeout(600);

    // Comprobar que los triggers de fechas se restablecen a placeholder
    await expect(page.getByTestId('fechaDesde-trigger')).toContainText('Seleccionar fecha');
    await expect(page.getByTestId('fechaHasta-trigger')).toContainText('Seleccionar fecha');

    // Captura de evidencia para CA 4
    await page.screenshot({
      path: '/app/test-results/screenshots/04-filtros-emisor-fecha.png',
      fullPage: true
    });
  });
});
