import { defineConfig, devices } from '@playwright/test';

/**
 * Configuración de Playwright para Sistema Capstone.
 * Diseñado para ejecutarse tanto dentro del contenedor Docker como localmente en el host.
 */
export default defineConfig({
  testDir: './src/specs',
  timeout: 30000,
  expect: {
    timeout: 10000
  },
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1,
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['./src/reporters/VideoRetentionReporter.ts']
  ],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'on',
    ignoreHTTPSErrors: true
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        viewport: { width: 1280, height: 720 }
      }
    }
  ],
  outputDir: 'test-results'
});
