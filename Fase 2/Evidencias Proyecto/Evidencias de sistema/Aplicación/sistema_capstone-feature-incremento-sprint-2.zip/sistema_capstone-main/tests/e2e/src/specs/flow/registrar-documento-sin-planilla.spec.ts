import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe.serial('[TEST] Validación de criterios de aceptación para Registrar documento sin planilla', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  const runId = Date.now();
  const requestTitle = `Solicitud Sin Planilla E2E ${runId}`;
  const requestDescription = 'Registro de documento sin planilla para validación de flujo y criterios de aceptación.';
  const validFileName = `contrato_auditoria_${runId}.pdf`;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 1] Validación de tipos MIME y rechazo de archivos no permitidos (UI + API)', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Emisor (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(page.locator('aside.sidebar')).toBeVisible({ timeout: 15000 });

    // 2. Navegar a Registrar Documento
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    // 3. Intento en UI de adjuntar un archivo con extensión y tipo no permitido (.exe)
    await page.setInputFiles('#document-file', {
      name: `script_invalido_${runId}.exe`,
      mimeType: 'application/octet-stream',
      buffer: Buffer.from('MZ... executable content not allowed')
    });

    // 4. Validar mensaje de error en UI
    const errorMsg = page.locator('.form-message-error, .document-upload-message');
    await expect(errorMsg).toBeVisible({ timeout: 10000 });
    await expect(errorMsg).toContainText('El archivo debe estar en formato .doc, .docx, .pdf, .xml, .txt, .xlsx o .xls');

    // Comprobar que no queda archivo seleccionado
    await expect(page.locator('.selected-document')).not.toBeVisible();

    // 5. Validación directa a nivel Backend API: Confirmar rechazo con 400 Bad Request
    const apiResult = await page.evaluate(async () => {
      try {
        const formData = new FormData();
        formData.append('titulo', 'Prueba Archivo No Permitido');
        const blob = new Blob(['binario'], { type: 'application/octet-stream' });
        formData.append('file', blob, 'programa.exe');

        const resp = await window.api.post('/api/solicitudes', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        return { status: resp.status, data: resp.data };
      } catch (err) {
        return {
          status: err.response?.status,
          title: err.response?.data?.title,
          detail: err.response?.data?.detail
        };
      }
    });

    expect(apiResult.status).toBe(400);
    expect(apiResult.title).toBe('Documento Inválido');
    expect(apiResult.detail).toContain('Formato de archivo no permitido (.exe)');

    // Captura de evidencia para CA 1
    await page.screenshot({
      path: '/app/test-results/screenshots/01-rechazo-archivo-no-permitido.png',
      fullPage: true
    });
  });

  test('2. [CA 2] Error 400 Bad Request y validación si faltan campos obligatorios (UI + API)', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión si no está activa
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(page.locator('aside.sidebar')).toBeVisible({ timeout: 15000 });

    // 2. Navegar a Registrar Documento
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    // Seleccionar flujo activo para habilitar el botón de envío
    const flowPicker = page.locator('#document-flujo');
    if (await flowPicker.isVisible().catch(() => false)) {
      await flowPicker.click();
      await page.locator('[role="option"]:not([aria-disabled="true"])').first().click();
    }

    // 3. Caso A: Enviar sin título obligatorio
    await page.fill('#document-title', '');
    await page.click('button.document-upload-submit');

    const errorTitulo = page.locator('.form-message-error, .document-upload-message');
    await expect(errorTitulo).toBeVisible({ timeout: 10000 });
    await expect(errorTitulo).toContainText('Ingresa el título del documento antes de enviarlo a revisión');

    // 4. Caso B: Ingresar título pero sin adjuntar archivo obligatorio
    await page.fill('#document-title', 'Título Válido Sin Archivo');
    await page.click('button.document-upload-submit');

    const errorArchivo = page.locator('.form-message-error, .document-upload-message');
    await expect(errorArchivo).toBeVisible({ timeout: 10000 });
    await expect(errorArchivo).toContainText('Selecciona un archivo para continuar');

    // 5. Validación directa a nivel Backend API: Confirmar rechazo con 400 Bad Request si faltan campos
    const apiErrorMissingFields = await page.evaluate(async () => {
      const results = [];

      // Test API: Falta título (vacío)
      try {
        const formData = new FormData();
        formData.append('titulo', '');
        const blob = new Blob(['dummy pdf'], { type: 'application/pdf' });
        formData.append('file', blob, 'test.pdf');
        const resp = await window.api.post('/api/solicitudes', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        results.push({ test: 'missing-title', status: resp.status });
      } catch (err) {
        results.push({ test: 'missing-title', status: err.response?.status, detail: err.response?.data?.detail });
      }

      // Test API: Falta archivo
      try {
        const formData = new FormData();
        formData.append('titulo', 'Solo Título');
        const resp = await window.api.post('/api/solicitudes', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        results.push({ test: 'missing-file', status: resp.status });
      } catch (err) {
        results.push({ test: 'missing-file', status: err.response?.status });
      }

      return results;
    });

    expect(apiErrorMissingFields[0].status).toBe(400);
    expect(apiErrorMissingFields[0].detail).toContain('título del documento es obligatorio');
    expect(apiErrorMissingFields[1].status).toBe(400);

    // Captura de evidencia para CA 2
    await page.screenshot({
      path: '/app/test-results/screenshots/02-error-400-campos-obligatorios.png',
      fullPage: true
    });
  });

  test('3. [CA 3] Registro exitoso con confirmación visual', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Emisor
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(page.locator('aside.sidebar')).toBeVisible({ timeout: 15000 });

    // 2. Navegar al formulario de registro
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    // Seleccionar flujo activo para habilitar el botón de envío
    const flowPicker = page.locator('#document-flujo');
    if (await flowPicker.isVisible().catch(() => false)) {
      await flowPicker.click();
      await page.locator('[role="option"]:not([aria-disabled="true"])').first().click();
    }

    // 3. Completar campos obligatorios válidos
    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', requestDescription);

    // Adjuntar archivo permitido (.pdf)
    await page.setInputFiles('#document-file', {
      name: validFileName,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Contenido válido de contrato para prueba automatizada.')
    });

    // 4. Verificar que se renderiza el archivo seleccionado con indicador de formato válido
    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('.selected-document-info strong')).toContainText(validFileName);
    await expect(page.locator('.selected-document-info span')).toContainText('Formato válido');

    // 5. Enviar a revisión
    await page.click('button.document-upload-submit');

    // 6. Verificar confirmación visual clara en pantalla
    const successMsg = page.locator('.form-message-success, .document-upload-message');
    await expect(successMsg).toBeVisible({ timeout: 35000 });
    await expect(successMsg).toContainText('Documento registrado correctamente');
    await expect(successMsg).toContainText('revisión');

    // Verificar presencia de botones de navegación tras el registro
    await expect(page.locator('a[href="/estado-solicitudes"]').first()).toBeVisible();
    await expect(page.locator('a[href="/mis-documentos"]').first()).toBeVisible();

    // Captura de evidencia para CA 3 (Confirmación visual)
    await page.screenshot({
      path: '/app/test-results/screenshots/03-confirmacion-visual-registro.png',
      fullPage: true
    });
  });

  test('4. [CA 4] Verificación de que la solicitud aparece inmediatamente en la vista del emisor con su estado actual', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Emisor
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(page.locator('aside.sidebar')).toBeVisible({ timeout: 15000 });

    // 2. Navegar a "Mis documentos"
    await page.click('aside.sidebar a[href="/mis-documentos"]');
    await expect(page.locator('#mis-docs-title')).toBeVisible();

    // 3. Verificar que la solicitud aparece inmediatamente en la tabla del emisor
    const rowMisDocs = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowMisDocs).toBeVisible({ timeout: 20000 });

    // 4. Verificar que se muestra su estado actual ("Pendiente" / "Pendiente de Revisión")
    await expect(rowMisDocs.locator('.status-badge-pending, .status-badge')).toContainText(/Pendiente/i);

    // 5. Verificar que se muestra el nombre del archivo registrado
    await expect(rowMisDocs).toContainText(validFileName);

    // 6. Verificar también en la vista "Estado de solicitudes"
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const rowEstado = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowEstado).toBeVisible({ timeout: 20000 });
    await expect(rowEstado.locator('.status-badge-pending, .status-badge')).toContainText(/Pendiente/i);

    // Captura de evidencia para CA 4 (Visualización inmediata y estado actual)
    await page.screenshot({
      path: '/app/test-results/screenshots/04-solicitud-inmediata-vista-emisor.png',
      fullPage: true
    });
  });
});
