import { Page, Locator, expect } from '@playwright/test';

/**
 * Page Object Model para la vista de Cambio de Contraseña (HU-S2-13 / auth-006).
 */
export class ChangePasswordPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly currentPasswordInput: Locator;
  readonly newPasswordInput: Locator;
  readonly confirmPasswordInput: Locator;
  readonly submitButton: Locator;
  readonly errorMessage: Locator;
  readonly successMessage: Locator;
  readonly rulesList: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('#change-password-title, h2:has-text("Cambiar contraseña")');
    this.currentPasswordInput = page.locator('#current-password, input[name="currentPassword"], [data-testid="current-password-input"]');
    this.newPasswordInput = page.locator('#new-password, input[name="newPassword"], [data-testid="new-password-input"]');
    this.confirmPasswordInput = page.locator('#confirm-password, input[name="confirmPassword"], [data-testid="confirm-password-input"]');
    this.submitButton = page.getByRole('button', { name: 'Actualizar contraseña', exact: true });
    this.errorMessage = page.locator('.form-message-error, .change-password-field-error').first();
    this.successMessage = page.locator('.form-message-success, [data-testid="change-password-success"]');
    this.rulesList = page.locator('#change-password-rules ul');
  }

  async goto() {
    const navLink = this.page.locator('a[href="/cambiar-contrasena"]').first();
    if (await navLink.isVisible({ timeout: 5000 }).catch(() => false)) {
      await navLink.click();
    } else {
      await this.page.goto('/cambiar-contrasena');
    }
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.heading).toBeVisible({ timeout: 15000 });
    await expect(this.submitButton).toBeEnabled({ timeout: 25000 });
    return true;
  }

  async fillForm(current: string, newPass: string, confirm: string) {
    await this.currentPasswordInput.fill(current);
    await this.newPasswordInput.fill(newPass);
    await this.confirmPasswordInput.fill(confirm);
  }

  async submit() {
    await this.submitButton.click();
  }

  async changePassword(current: string, newPass: string, confirm: string) {
    await this.fillForm(current, newPass, confirm);
    await this.submit();
  }

  async getErrorMessage(): Promise<string> {
    await expect(this.errorMessage).toBeVisible({ timeout: 10000 });
    return (await this.errorMessage.textContent())?.trim() || '';
  }

  async getSuccessMessage(): Promise<string> {
    await expect(this.successMessage).toBeVisible({ timeout: 10000 });
    return (await this.successMessage.textContent())?.trim() || '';
  }

  fieldError(name: 'currentPassword' | 'newPassword' | 'confirmPassword'): Locator {
    return this.page.locator(`#change-password-${name}-error`);
  }
}
