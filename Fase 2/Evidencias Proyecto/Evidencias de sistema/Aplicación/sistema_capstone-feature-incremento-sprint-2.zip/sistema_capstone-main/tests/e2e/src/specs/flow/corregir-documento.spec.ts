import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import * as fs from 'fs';

const CONTEXT_FILE = '/app/test-results/test-corregir-context.json';

test.describe.serial('[TEST] Validación de criterios de aceptación para Corregir documento', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 1] Validar que solo se puedan editar y reenviar solicitudes en NEEDS_CORRECTION (rechazar en otro estado)', async ({ page }) => {
    test.setTimeout(120000);

    const runId = Date.now();
    const requestTitle = `Doc Corregir Estado ${runId}`;

    // 1. Iniciar sesión como Emisor (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Registrar nuevo documento (queda inicialmente en estado PENDIENTE_REVISION)
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Documento para validar que no puede corregirse en estado pendiente.');
    await page.setInputFiles('#document-file', {
      name: `corregir_test_${runId}.pdf`,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Contenido preliminar para prueba de estado de correccion')
    });

    const flowPicker = page.locator('#document-flujo');
    if (await flowPicker.isVisible().catch(() => false)) {
      await flowPicker.focus();
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(300);
      await page.keyboard.press('Enter');
    }

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 3. Obtener ID de la solicitud registrada
    const createdSolicitud = await page.evaluate(async (title) => {
      const resp = await window.api.get('/api/solicitudes/mis-solicitudes');
      return resp.data?.find((s: any) => s.titulo === title);
    }, requestTitle);

    expect(createdSolicitud).toBeDefined();
    expect(createdSolicitud.estado).toBe('PENDIENTE_REVISION');
    const createdSolicitudId = createdSolicitud.id;

    // 4. Navegar a /corregir-documento
    await page.click('aside.sidebar a[href="/corregir-documento"]');
    await expect(page.locator('#corregir-title')).toBeVisible();

    // 5. CRITERIO 1 VALIDACIÓN EN BANDEJA:
    // La solicitud en PENDIENTE_REVISION NO debe aparecer en la lista de solicitudes observadas
    await expect(page.locator(`tr:has-text("${requestTitle}")`)).not.toBeVisible();

    // 6. CRITERIO 1 VALIDACIÓN POR URL DIRECTA:
    // Al intentar forzar la carga por parámetro id en la URL, el frontend debe rechazarla
    await page.goto(`/corregir-documento?id=${createdSolicitudId}`);
    await expect(page.locator('#corregir-title')).toBeVisible();
    await expect(page.locator('.page-message, .form-message-error, .feedback-message')).toContainText(/no está disponible para corrección/i);
    // El formulario de edición no se renderiza para solicitudes que no estén en CORRECCION_REQUERIDA
    await expect(page.locator('[data-testid="btn-reenviar"]')).not.toBeVisible();

    // 7. CRITERIO 1 VALIDACIÓN EN BACKEND API:
    // Intentar reenviar directamente a la API una solicitud que no esté en CORRECCION_REQUERIDA debe retornar 409 Conflict
    const apiStatusConflict = await page.evaluate(async (id) => {
      const formData = new FormData();
      formData.append('version', '1');
      formData.append('titulo', 'Intento reenvio forzado');
      try {
        await window.api.put(`/api/solicitudes/${id}/reenviar`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        return 200;
      } catch (err: any) {
        return err.response?.status || 500;
      }
    }, createdSolicitudId);

    expect(apiStatusConflict).toBe(409);

    // 8. Revisor solicita corrección para que la solicitud transicione a CORRECCION_REQUERIDA
    await page.click('button.logout-btn');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    const rowReview = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowReview).toBeVisible({ timeout: 20000 });
    await rowReview.click();

    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible({ timeout: 10000 });
    const obsTexto = `Falta firma y precision en clausulas ${Date.now()}`;
    await page.fill('[data-testid="modal-comment-input"]', obsTexto);
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.page-message.form-message-success, .form-message-success')).toBeVisible({ timeout: 25000 });

    // Persistir contexto para siguientes pruebas
    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      createdSolicitudId,
      requestTitle,
      obsTexto,
      runId
    }, null, 2));

    // Captura fotográfica de evidencia para Criterio 1
    await page.screenshot({
      path: '/app/test-results/screenshots/01-rechazo-reenvio-estado-invalido.png',
      fullPage: true
    });
  });

  test('2. [CA 2] Comprobación de campos obligatorios antes de enviar (validación frontend y backend)', async ({ page }) => {
    test.setTimeout(100000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle } = contextData;

    // 1. Iniciar sesión como Emisor (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Navegar a Corregir Documento para la solicitud observada
    await page.goto(`/corregir-documento?id=${createdSolicitudId}`);
    await expect(page.locator('#corregir-title')).toBeVisible();

    const tituloInput = page.locator('[data-testid="corregir-titulo-input"]');
    await expect(tituloInput).toBeVisible({ timeout: 15000 });
    await expect(tituloInput).toHaveValue(requestTitle);

    // 3. CRITERIO 2 VALIDACIÓN EN FRONTEND:
    // Vaciar el campo obligatorio Título del documento
    await tituloInput.fill('');
    await expect(tituloInput).toHaveValue('');

    // Intentar reenviar
    const btnReenviar = page.locator('[data-testid="btn-reenviar"]');
    await expect(btnReenviar).toBeVisible();
    await btnReenviar.click();

    // Debe mostrarse el mensaje de error de validación sin enviar el formulario
    const validationError = page.locator('.page-message, .form-message-error, .feedback-message');
    await expect(validationError).toBeVisible({ timeout: 10000 });
    await expect(validationError).toContainText(/El título del documento es obligatorio/i);

    // 4. CRITERIO 2 VALIDACIÓN EN BACKEND API:
    // Si se invoca el endpoint con título vacío o solo espacios en blanco, retorna 400 Bad Request
    const apiStatusBlankTitle = await page.evaluate(async (id) => {
      const formData = new FormData();
      formData.append('version', '1');
      formData.append('titulo', '   ');
      try {
        await window.api.put(`/api/solicitudes/${id}/reenviar`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        return 200;
      } catch (err: any) {
        return err.response?.status || 500;
      }
    }, createdSolicitudId);

    expect(apiStatusBlankTitle).toBe(400);

    // Captura fotográfica de evidencia para Criterio 2
    await page.screenshot({
      path: '/app/test-results/screenshots/02-validacion-campos-obligatorios.png',
      fullPage: true
    });
  });

  test('3. [CA 3] Verificación de transición a PENDING_REVIEW tras reenvío exitoso', async ({ page }) => {
    test.setTimeout(100000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, runId } = contextData;
    const nuevoTitulo = `Doc Corregido y Subsanado ${runId}`;

    // 1. Iniciar sesión como Emisor (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Navegar a Corregir Documento
    await page.goto(`/corregir-documento?id=${createdSolicitudId}`);
    await expect(page.locator('#corregir-title')).toBeVisible();

    const tituloInput = page.locator('[data-testid="corregir-titulo-input"]');
    await expect(tituloInput).toBeVisible({ timeout: 15000 });

    // 3. Completar campos válidos de subsanación
    await tituloInput.fill(nuevoTitulo);
    await page.fill('[data-testid="corregir-descripcion-input"]', 'Se subsanan las observaciones de clausulas y se adjunta version corregida.');

    // Adjuntar archivo corregido (opcional)
    await page.setInputFiles('#corregir-file', {
      name: `contrato_subsanado_${runId}.pdf`,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Archivo corregido y actualizado segun observaciones del revisor.')
    });

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });

    // 4. Enviar corrección
    const btnReenviar = page.locator('[data-testid="btn-reenviar"]');
    await btnReenviar.click();

    // 5. CRITERIO 3 VALIDACIÓN: Mensaje de confirmación y salida de observadas
    const successMsg = page.locator('.page-message, .form-message-success, .feedback-message');
    await expect(successMsg).toBeVisible({ timeout: 25000 });
    await expect(successMsg).toContainText(/corregida y reenviada a revisión exitosamente/i);

    // Comprobar que en la API la solicitud pasó de CORRECCION_REQUERIDA a PENDIENTE_REVISION
    const updatedSol = await page.evaluate(async (id) => {
      const resp = await window.api.get(`/api/solicitudes/${id}`);
      return resp.data;
    }, createdSolicitudId);

    expect(updatedSol.estado).toBe('PENDIENTE_REVISION');
    expect(updatedSol.titulo).toBe(nuevoTitulo);

    // Actualizar contexto
    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      ...contextData,
      nuevoTitulo
    }, null, 2));

    // Captura fotográfica de evidencia para Criterio 3
    await page.screenshot({
      path: '/app/test-results/screenshots/03-transicion-exitosa-a-pending-review.png',
      fullPage: true
    });
  });

  test('4. [CA 3/CA 4] Disponibilidad inmediata en bandeja de revisión y registro en historial', async ({ page }) => {
    test.setTimeout(100000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, nuevoTitulo } = contextData;

    // 1. Iniciar sesión como Revisor
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Navegar a Revisar Documentos
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 3. CRITERIO 3/4 VALIDACIÓN: La solicitud corregida ya figura disponible en estado Pendiente
    const rowInReview = page.locator(`tr:has-text("${nuevoTitulo}")`);
    await expect(rowInReview).toBeVisible({ timeout: 20000 });
    await expect(rowInReview.locator('td[data-label="Estado"]')).toContainText(/Pendiente/i);

    // 4. Verificar historial cronológico de la solicitud
    const historial = await page.evaluate(async (id) => {
      const resp = await window.api.get(`/api/solicitudes/${id}/historial`);
      return resp.data;
    }, createdSolicitudId);

    expect(historial).toBeDefined();
    expect(historial.length).toBeGreaterThanOrEqual(3);

    // Último evento debe ser el reenvío
    const transicionReenvio = historial[historial.length - 1];
    expect(transicionReenvio.accion).toMatch(/REENVIAR/);
    expect(transicionReenvio.estadoOrigen).toBe('CORRECCION_REQUERIDA');
    expect(transicionReenvio.estadoDestino).toBe('PENDIENTE_REVISION');

    // 5. Verificar notificación recibida en la campana del revisor
    const bellBtn = page.locator('button.notification-bell-btn');
    await bellBtn.click();
    const dropdown = page.locator('#notification-panel');
    await expect(dropdown).toBeVisible({ timeout: 10000 });

    const notifItem = dropdown.locator(`.notification-item:has-text("${nuevoTitulo}")`);
    await expect(notifItem).toBeVisible({ timeout: 15000 });
    await expect(notifItem).toContainText(/subsanado|reenviada|revisión/i);

    // Captura fotográfica de evidencia para Criterio 4
    await page.screenshot({
      path: '/app/test-results/screenshots/04-disponibilidad-en-revision-y-historial.png',
      fullPage: true
    });
  });
});
