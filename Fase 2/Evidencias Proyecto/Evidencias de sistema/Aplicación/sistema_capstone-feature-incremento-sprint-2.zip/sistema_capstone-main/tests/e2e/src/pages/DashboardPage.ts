import { Page, Locator, expect } from '@playwright/test';

/**
 * Page Object Model para el Dashboard principal de la aplicación React.
 */
export class DashboardPage {
  readonly page: Page;
  readonly sidebar: Locator;
  readonly brandTitle: Locator;
  readonly dashboardHeading: Locator;
  readonly logoutButton: Locator;
  readonly areaFilter: Locator;
  readonly areaBadge: Locator;
  readonly slaIndicator: Locator;
  readonly kpiPendientes: Locator;
  readonly kpiAprobadas: Locator;
  readonly kpiRechazadas: Locator;
  readonly kpiCorreccion: Locator;
  readonly refreshButton: Locator;
  readonly breakdownSection: Locator;
  readonly breakdownTable: Locator;

  constructor(page: Page) {
    this.page = page;
    this.sidebar = page.locator('aside.sidebar');
    this.brandTitle = page.locator('aside.sidebar .brand h1');
    this.dashboardHeading = page.locator('section.view-container h2, #dashboard-heading, h2:has-text("Dashboard")');
    this.logoutButton = page.locator('button.logout-btn, button.logout-button, button:has-text("Cerrar sesión")');
    this.areaFilter = page.locator('#dashboard-area-filter');
    this.areaBadge = page.locator('[data-testid="dashboard-area-badge"]');
    this.slaIndicator = page.locator('[data-testid="dashboard-sla-indicator"]');
    this.kpiPendientes = page.locator('[data-testid="kpi-pendientes"]');
    this.kpiAprobadas = page.locator('[data-testid="kpi-aprobadas"]');
    this.kpiRechazadas = page.locator('[data-testid="kpi-rechazadas"]');
    this.kpiCorreccion = page.locator('[data-testid="kpi-correccion"]');
    this.refreshButton = page.locator('.btn-refresh');
    this.breakdownSection = page.locator('[data-testid="dashboard-breakdown-section"]');
    this.breakdownTable = page.locator('[data-testid="dashboard-breakdown-table"]');
  }

  async goto() {
    await this.page.goto('/dashboard');
    await this.isDisplayed();
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.dashboardHeading.first()).toBeVisible({ timeout: 20000 });
    return true;
  }

  async logout() {
    await this.logoutButton.click();
  }

  async clickTab(tabName: 'acciones' | 'en_tramite') {
    const tabButton = tabName === 'acciones'
      ? this.page.locator('.dashboard-tab-btn:has-text("Acciones Pendientes")')
      : this.page.locator('.dashboard-tab-btn:has-text("Mis Solicitudes en Trámite")');
    await tabButton.click();
  }

  async getActionRows(): Promise<Locator> {
    return this.page.locator('.dashboard-action-row');
  }

  async clickReview(title: string) {
    const row = this.page.locator(`.dashboard-action-row:has-text("${title}")`);
    await row.locator('.btn-review').click();
  }

  async clickCorrect(title: string) {
    const row = this.page.locator(`.dashboard-action-row:has-text("${title}")`);
    await row.locator('.btn-correct').click();
  }

  async clickTrack(title: string) {
    const row = this.page.locator(`.dashboard-request-row:has-text("${title}")`);
    await row.locator('.btn-track').click();
  }
}

