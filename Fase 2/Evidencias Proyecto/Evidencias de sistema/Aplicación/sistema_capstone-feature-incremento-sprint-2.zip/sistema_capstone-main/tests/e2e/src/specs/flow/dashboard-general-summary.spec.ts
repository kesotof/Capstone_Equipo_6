import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe.serial('Resumen General de Solicitudes y Métricas por Área (HU-S2-14 / E2E-DASH-METRICS-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 14.1, 14.5] Administrador visualiza tarjetas KPI cuantitativas y cumplimiento de SLA', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Administrador con aislamiento SSO
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Verificar visibilidad del contenedor de estadísticas y métricas
    await expect(page.locator('.dashboard-stats')).toBeVisible({ timeout: 15000 });

    // 3. CA 14.1: Verificar que las 4 tarjetas KPI cuantitativas están desplegadas
    await expect(dashboardPage.kpiPendientes).toBeVisible();
    await expect(dashboardPage.kpiPendientes.locator('.stat-tile-label')).toContainText('Pendientes de revisión');
    await expect(dashboardPage.kpiPendientes.locator('.stat-tile-value')).toBeVisible();

    await expect(dashboardPage.kpiAprobadas).toBeVisible();
    await expect(dashboardPage.kpiAprobadas.locator('.stat-tile-label')).toContainText('Aprobadas');
    await expect(dashboardPage.kpiAprobadas.locator('.stat-tile-value')).toBeVisible();

    await expect(dashboardPage.kpiRechazadas).toBeVisible();
    await expect(dashboardPage.kpiRechazadas.locator('.stat-tile-label')).toContainText('Rechazadas');
    await expect(dashboardPage.kpiRechazadas.locator('.stat-tile-value')).toBeVisible();

    await expect(dashboardPage.kpiCorreccion).toBeVisible();
    await expect(dashboardPage.kpiCorreccion.locator('.stat-tile-label')).toContainText('En corrección');
    await expect(dashboardPage.kpiCorreccion.locator('.stat-tile-value')).toBeVisible();

    // 4. CA 14.1 & 14.5: Indicador de cumplimiento SLA presente con formato "en plazo · fuera de plazo"
    await expect(dashboardPage.slaIndicator).toBeVisible();
    await expect(dashboardPage.slaIndicator).toContainText(/en plazo.*fuera de plazo/i);
  });

  test('2. [CA 14.2, 14.5] Administrador filtra métricas por área corporativa y visualiza desglose consolidado', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Administrador
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. CA 14.2: Verificar presencia del filtro selector por área
    await expect(dashboardPage.areaFilter).toBeVisible({ timeout: 15000 });
    await expect(dashboardPage.areaFilter).toBeEnabled();

    // 3. Verificar que la opción inicial es "Todas las áreas"
    await expect(dashboardPage.areaFilter).toHaveValue('');

    // 4. Verificar que existen opciones de áreas activas en el selector
    const options = dashboardPage.areaFilter.locator('option');
    const optionCount = await options.count();
    expect(optionCount).toBeGreaterThanOrEqual(1);

    // 5. Si "Todas las áreas" está seleccionada, verificar presencia de sección de desglose
    const hasBreakdown = await dashboardPage.breakdownSection.isVisible({ timeout: 5000 }).catch(() => false);
    if (hasBreakdown) {
      await expect(dashboardPage.breakdownTable).toBeVisible();
      await expect(dashboardPage.breakdownSection.locator('h3')).toContainText('Desglose por área corporativa');
    }

    // 6. Si hay áreas disponibles para filtrar, seleccionar una y validar reactividad
    if (optionCount > 1) {
      const firstAreaOption = options.nth(1);
      const areaValue = await firstAreaOption.getAttribute('value');
      const areaText = await firstAreaOption.textContent();

      if (areaValue && areaText) {
        // Interceptar llamada a /api/solicitudes/metricas con el parámetro areaId
        const metricasPromise = page.waitForResponse(
          resp => resp.url().includes('/api/solicitudes/metricas') && resp.status() === 200,
          { timeout: 15000 }
        );

        await dashboardPage.areaFilter.selectOption(areaValue);
        await metricasPromise;

        // Comprobar que los KPIs siguen visibles y actualizados
        await expect(dashboardPage.kpiPendientes).toBeVisible();
        await expect(dashboardPage.kpiAprobadas).toBeVisible();
      }
    }
  });

  test('3. [CA 14.4] Usuario restringido a un área única visualiza badge y métricas delimitadas a su alcance', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Revisor (usuario operativo con ámbito restringido)
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    // 2. CA 14.4: Verificar que el selector de área está fijo/deshabilitado o muestra badge de área asignada
    const hasFilter = await dashboardPage.areaFilter.isVisible({ timeout: 5000 }).catch(() => false);
    if (hasFilter) {
      // El selector debe estar deshabilitado para usuario restringido a una única área
      const isDisabled = await dashboardPage.areaFilter.isDisabled();
      const hasBadge = await dashboardPage.areaBadge.isVisible({ timeout: 3000 }).catch(() => false);

      expect(isDisabled || hasBadge).toBe(true);
    }

    // 3. Verificar que los KPIs son accesibles conforme a sus permisos
    await expect(page.locator('.dashboard-stats')).toBeVisible({ timeout: 15000 });
    await expect(dashboardPage.kpiPendientes).toBeVisible();
    await expect(dashboardPage.kpiAprobadas).toBeVisible();
    await expect(dashboardPage.slaIndicator).toBeVisible();
  });

  test('4. [CA 14.3] Botón Actualizar refresca reactivamente las métricas y listados del dashboard con protección anti doble clic', async ({ page }) => {
    test.setTimeout(75000);

    // 1. Iniciar sesión como Administrador
    await page.context().clearCookies();
    await page.goto('/');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Localizar botón Actualizar
    await expect(dashboardPage.refreshButton).toBeVisible();
    await expect(dashboardPage.refreshButton).toBeEnabled();

    // 3. Disparar actualización y verificar llamada de red
    const refreshPromise = page.waitForResponse(
      resp => resp.url().includes('/api/solicitudes/dashboard') && resp.status() === 200,
      { timeout: 15000 }
    );

    await dashboardPage.refreshButton.click();
    await refreshPromise;

    // 4. Confirmar que el botón vuelve a estar disponible tras completar la recarga
    await expect(dashboardPage.refreshButton).toBeEnabled({ timeout: 10000 });
    await expect(dashboardPage.kpiPendientes).toBeVisible();
    await expect(dashboardPage.kpiAprobadas).toBeVisible();
  });
});
