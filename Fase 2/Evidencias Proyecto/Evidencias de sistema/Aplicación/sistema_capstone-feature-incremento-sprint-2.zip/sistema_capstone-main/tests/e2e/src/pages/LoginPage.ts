import { Page, Locator, expect } from '@playwright/test';

/**
 * Page Object Model para la pantalla de inicio de sesión de Keycloak (MasterBase).
 */
export class LoginPage {
  readonly page: Page;
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorMessage: Locator;
  readonly pageTitle: Locator;

  constructor(page: Page) {
    this.page = page;
    // Keycloak standard selectors con fallbacks resilientes
    this.usernameInput = page.locator('input#username, input[name="username"]');
    this.passwordInput = page.locator('input#password, input[name="password"]');
    this.loginButton = page.locator('input#kc-login, button[type="submit"], input[type="submit"]');
    this.errorMessage = page.locator('.kc-feedback-text, #input-error, .alert-error').first();
    this.pageTitle = page.locator('#kc-page-title, h1');
  }

  async goto() {
    // Al navegar a la raíz del frontend (/), este redirige automáticamente a Keycloak OIDC
    await this.page.goto('/', { waitUntil: 'domcontentloaded' });
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.usernameInput).toBeVisible({ timeout: 15000 });
    return true;
  }

  async login(username: string, pass: string) {
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(pass);
    await this.loginButton.click();
    await this.page.waitForSelector('.app-loading', { state: 'detached', timeout: 30000 }).catch(() => {});
  }

  async getErrorMessage(): Promise<string> {
    await expect(this.errorMessage).toBeVisible({ timeout: 5000 });
    return (await this.errorMessage.textContent())?.trim() || '';
  }
}
