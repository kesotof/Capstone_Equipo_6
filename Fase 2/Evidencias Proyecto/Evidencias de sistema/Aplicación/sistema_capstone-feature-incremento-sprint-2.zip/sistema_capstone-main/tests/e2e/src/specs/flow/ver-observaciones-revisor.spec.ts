import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import * as fs from 'fs';

const CONTEXT_FILE = '/app/test-results/test-observaciones-context.json';

test.describe.serial('[TEST] Validación de criterios de aceptación para Ver observaciones del revisor', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 1] Validar que las observaciones se muestren dentro de la solicitud correspondiente', async ({ page }) => {
    test.setTimeout(75000);

    const runId = Date.now();
    const requestTitle = `Solicitud Observaciones E2E ${runId}`;
    const observacionTexto = `OBS-${runId}: Cláusula de vigencia incompleta. Se requiere especificar 12 meses de garantía y firma del representante legal.`;

    // 1. Iniciar sesión como Admin (Emisor)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Registrar nuevo documento
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Solicitud inicial para verificación de observaciones del revisor.');
    await page.setInputFiles('#document-file', {
      name: `contrato_observaciones_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contenido preliminar del contrato pendiente de revisión.')
    });

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 3. Revisar el documento como Revisor / Evaluador
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    const row = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(row).toBeVisible({ timeout: 20000 });
    await row.click();

    // 4. Solicitar Corrección indicando la observación del revisor
    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();
    await page.fill('[data-testid="modal-comment-input"]', observacionTexto);
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.page-message.form-message-success, .form-message-success')).toBeVisible({ timeout: 25000 });

    // 5. Navegar a Corregir Documento como Emisor
    const misSolicitudesPromise = page.waitForResponse(
      (resp) => resp.url().includes('/api/solicitudes/mis-solicitudes') && resp.status() === 200
    );
    await page.click('aside.sidebar a[href="/corregir-documento"]');
    await expect(page.locator('#corregir-title')).toBeVisible();

    const misSolResp = await misSolicitudesPromise;
    const items = await misSolResp.json();
    const currentItem = items.find((s: any) => s.titulo === requestTitle);
    expect(currentItem).toBeDefined();
    const createdSolicitudId = currentItem.id;

    // Persistir contexto para siguientes tests serializados
    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      createdSolicitudId,
      requestTitle,
      observacionTexto
    }));

    // 6. Seleccionar la solicitud correspondiente en la tabla de observadas
    const rowCorregir = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowCorregir).toBeVisible({ timeout: 15000 });
    await rowCorregir.click();

    // 7. CRITERIO 1 VALIDACIÓN: Las observaciones se muestran dentro de la solicitud correspondiente
    const obsBox = page.locator('[data-testid="observations-box"]');
    await expect(obsBox).toBeVisible({ timeout: 10000 });

    const obsText = page.locator('[data-testid="observation-item-text"]');
    await expect(obsText).toBeVisible();
    await expect(obsText).toContainText(observacionTexto);

    // Validar que corresponde al documento correcto
    await expect(page.locator('[data-testid="corregir-titulo-input"]')).toHaveValue(requestTitle);

    // Captura de pantalla de evidencia para Criterio 1
    await page.screenshot({
      path: '/app/test-results/screenshots/01-observaciones-dentro-de-solicitud.png',
      fullPage: true
    });
  });

  test('2. [CA 2] Comprobar acceso denegado a usuarios no autorizados', async ({ page }) => {
    test.setTimeout(75000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle } = contextData;
    expect(createdSolicitudId).toBeTruthy();

    // 1. Iniciar sesión con un usuario no autorizado (revisor no es emisor de esta solicitud ni admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Navegar a la pantalla Corregir Documento
    await page.click('aside.sidebar a[href="/corregir-documento"]');
    await expect(page.locator('#corregir-title')).toBeVisible();

    // 3. CRITERIO 2 VALIDACIÓN EN UI:
    // La solicitud ajena NO debe aparecer en la lista de solicitudes observadas del usuario no autorizado
    await expect(page.locator(`tr:has-text("${requestTitle}")`)).not.toBeVisible();
    // La caja de observaciones no se renderiza
    await expect(page.locator('[data-testid="observations-box"]')).not.toBeVisible();

    // Intentar forzar acceso por parámetro targetId en la URL
    await page.evaluate((id) => {
      window.history.pushState({}, '', `/corregir-documento?id=${id}`);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }, createdSolicitudId);

    // Comprobar mensaje de acceso denegado o lista vacía sin acceso a observaciones
    const errorMsg = page.locator('.form-message-error, .page-message.form-message-error');
    if (await errorMsg.isVisible({ timeout: 4000 }).catch(() => false)) {
      await expect(errorMsg).toContainText(/no pertenece al usuario actual|no fue posible cargar/i);
    }
    await expect(page.locator('[data-testid="observations-box"]')).not.toBeVisible();

    // 4. CRITERIO 2 VALIDACIÓN EN BACKEND API: Comprobar rechazo con 403 Forbidden
    const apiStatus = await page.evaluate(async (id) => {
      try {
        const resp = await window.api.get(`/api/solicitudes/${id}/observaciones`);
        return resp.status;
      } catch (err) {
        return err.response?.status || 403;
      }
    }, createdSolicitudId);
    expect([401, 403]).toContain(apiStatus);

    // Captura de pantalla de evidencia para Criterio 2
    await page.screenshot({
      path: '/app/test-results/screenshots/02-acceso-denegado-usuario-no-autorizado.png',
      fullPage: true
    });
  });

  test('3. [CA 3] Verificar que las observaciones permanezcan disponibles mientras la solicitud esté pendiente de corrección', async ({ page }) => {
    test.setTimeout(75000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { requestTitle, observacionTexto } = contextData;

    // 1. Iniciar sesión nuevamente como el Emisor autorizado (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Navegar a Estado Solicitudes para confirmar que el estado sigue en CORRECCION_REQUERIDA
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const rowEstado = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(rowEstado).toBeVisible({ timeout: 15000 });
    await expect(rowEstado.locator('.status-badge-pending, .status-badge-rejected, .status-badge')).toContainText(
      /Corrección requerida/i
    );

    // 3. Simular navegación intermedia dentro de la SPA
    await page.click('aside.sidebar a[href="/dashboard"]');
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 15000 });

    // 4. Volver a entrar a Corregir Documento
    await page.click('aside.sidebar a[href="/corregir-documento"]');
    await expect(page.locator('#corregir-title')).toBeVisible();

    const row = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(row).toBeVisible({ timeout: 15000 });
    await row.click();

    // 5. CRITERIO 3 VALIDACIÓN: La observación sigue completamente disponible y legible
    const obsBox = page.locator('[data-testid="observations-box"]');
    await expect(obsBox).toBeVisible({ timeout: 15000 });
    await expect(page.locator('[data-testid="observation-item-text"]')).toContainText(observacionTexto);

    // 6. Probar edición en progreso: el usuario edita campos y las observaciones se mantienen visibles
    await page.fill(
      '[data-testid="corregir-descripcion-input"]',
      'Edición en progreso: revisando y subsanando las observaciones del revisor antes de reenviar.'
    );
    await expect(obsBox).toBeVisible();
    await expect(page.locator('[data-testid="observation-item-text"]')).toContainText(observacionTexto);

    // Captura de pantalla de evidencia para Criterio 3
    await page.screenshot({
      path: '/app/test-results/screenshots/03-observaciones-disponibles-en-correccion.png',
      fullPage: true
    });
  });
});
