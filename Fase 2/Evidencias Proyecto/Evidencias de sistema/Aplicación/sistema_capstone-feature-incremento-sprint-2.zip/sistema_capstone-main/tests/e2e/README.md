# Suite de Pruebas Automatizadas E2E y de Regresión (Playwright)

Este módulo contiene la suite oficial de pruebas de extremo a extremo (E2E) y pruebas de regresión para el **Sistema de Gestión Documental y Flujos de Aprobación (Capstone)**. Está diseñado para garantizar que a medida que el sistema crezca, las funcionalidades existentes se mantengan estables.

---

## 1. Estructura de Directorios

```
tests/e2e/
├── Dockerfile                  # Imagen oficial mcr.microsoft.com/playwright con socat para red Docker
├── docker-entrypoint.sh        # Enrutamiento de localhost hacia la red capstone-net
├── package.json                # Configuración de dependencias y scripts npm
├── tsconfig.json               # Configuración de compilación TypeScript
├── playwright.config.ts        # Configuración de timeouts, reporter de consola, traces y capturas
├── src/
│   ├── pages/                  # Page Object Models (POM) para modularizar selectores y acciones
│   │   ├── LoginPage.ts        # Pantalla de acceso Keycloak MasterBase
│   │   └── DashboardPage.ts    # Dashboard y navegación principal
│   └── specs/                  # Casos de prueba organizados por módulo funcional
│       └── auth/
│           └── login-flow.spec.ts # Pruebas de redirección OIDC, errores y login exitoso
├── playwright-report/          # (Ignorado en git) Reporte HTML generado tras ejecuciones
└── test-results/               # (Ignorado en git) Capturas de pantalla y videos de fallos
```

---

## 2. Cómo Ejecutar los Tests

### Opción A: Mediante Scripts Unificados (Recomendado)

Desde la raíz del repositorio:

**En Windows (PowerShell):**
```powershell
.\scripts\run-e2e-tests.ps1
```

**En Linux / macOS / WSL (Bash):**
```bash
./scripts/run-e2e-tests.sh
```

El script verifica automáticamente que la infraestructura y el frontend estén activos, levanta el contenedor de Playwright, ejecuta los tests y muestra los resultados en la terminal con formato de lista y colores.

---

### Opción B: Modo Visual Interactivo Web (Playwright UI en el Navegador)

Para ver paso a paso la ejecución en vivo, pausar, ver el DOM renderizado y depurar sin salir del contenedor:

```powershell
.\scripts\run-e2e-tests.ps1 -UI
```
O con Docker Compose:
```bash
docker compose run --rm -p 9323:9323 playwright-tests npm run test:ui:web
```

Luego abre en tu navegador host (Chrome/Edge):
```
http://localhost:9323
```

---

### Opción C: Ejecución Directa con Docker Compose

```bash
docker compose run --rm playwright-tests
```

Para ejecutar una especificación en particular:
```bash
docker compose run --rm playwright-tests npx playwright test src/specs/auth/login-flow.spec.ts
```

---

### Opción D: Ejecución Local en el Host (Desarrollo rápido)

Si cuentas con Node.js instalado en tu máquina y prefieres ver la ventana de Chromium abriéndose en tu escritorio:

```powershell
cd tests/e2e
npm install
npx playwright install chromium
npm test -- --headed
```

---

## 3. Artefactos de Diagnóstico ante Fallos

Cuando una prueba falla:
1. Playwright captura automáticamente un screenshot del estado de la pantalla en `tests/e2e/test-results/`.
2. Graba un video de los últimos segundos de la interacción.
3. Almacena el archivo de traza interactivo `trace.zip`. Puedes reproducirlo con:
   ```bash
   npx playwright show-trace tests/e2e/test-results/.../trace.zip
   ```

---

## 4. Guía para Agregar Nuevas Pruebas

1. **Crear o reutilizar un Page Object** en `src/pages/` para encapsular la lógica de interacción de la vista correspondiente.
2. **Crear la especificación** en la carpeta del módulo adecuado dentro de `src/specs/` (ej. `src/specs/documentos/upload.spec.ts`).
3. Importar `@playwright/test` y utilizar assertions declarativas (`expect(locator).toBeVisible()`).
4. Ejecutar `.\scripts\run-e2e-tests.ps1` para validar la regresión completa.

---

## 5. Patrones Obligatorios y Buenas Prácticas para Agentes

### 5.1 Aislamiento de Sesión SSO Keycloak (Pruebas Multi-Usuario)
En suites que alternan roles de usuario (ej. Administrador y Revisor), **Playwright reutiliza las cookies del contexto del navegador**, por lo que navegar a `/login` NO cierra la sesión activa de Keycloak y causa timeouts al esperar componentes del nuevo usuario.
**Regla obligatoria**: Antes de iniciar sesión con un usuario diferente, limpia explícitamente las cookies:
```typescript
await page.context().clearCookies();
await page.goto('/');
await loginPage.isDisplayed();
await loginPage.login('nuevo-usuario@capstone.local', 'password123');
```

### 5.2 Estructura Estricta de Page Objects (TypeScript)
**Nunca** inicialices locators como propiedades de clase fuera del constructor si hacen referencia a `this.page`. En TypeScript, los inicializadores de campo se ejecutan antes del cuerpo del constructor, lo que provoca `TypeError: Cannot read properties of undefined (reading 'locator')`.

```typescript
// ❌ INCORRECTO:
export class MiPage {
  readonly miBoton: Locator = this.page.locator('button');
  constructor(public page: Page) {}
}

// ✅ CORRECTO:
export class MiPage {
  readonly miBoton: Locator;
  constructor(public page: Page) {
    this.miBoton = page.locator('button');
  }
}
```

### 5.3 Invocación Segura de APIs del Backend (`window.api`)
El frontend expone la instancia configurada de Axios en `window.api`, la cual incluye automáticamente la cabecera `Authorization: Bearer <token>` del usuario logueado. Puedes usarla en `page.evaluate()` para verificar estados o invocar endpoints sin lidiar con tokens manuales:

```typescript
const result = await page.evaluate(async () => {
  try {
    const resp = await (window as any).api.get('/api/solicitudes/pendientes-revision', {
      params: { pagina: 0, tamanio: 20 }
    });
    return { ok: true, data: resp.data };
  } catch (err: any) {
    return { ok: false, status: err.response?.status };
  }
});
```

