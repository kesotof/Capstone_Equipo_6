const { chromium } = require('@playwright/test');
const path = require('path');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });

  const reportPath = 'file://' + path.resolve('/app/playwright-report/index.html');
  console.log('Cargando reporte Playwright desde:', reportPath);
  await page.goto(reportPath, { waitUntil: 'load' });
  await page.waitForTimeout(2000);

  // Captura 1: Vista general del reporte Playwright
  await page.screenshot({
    path: '/app/test-results/screenshots/05-playwright-report-resumen.png',
    fullPage: true
  });
  console.log('✓ Captura guardada: 05-playwright-report-resumen.png');

  // Buscar el enlace o entrada del test para ver el detalle de los pasos
  const testLinks = page.locator('a[href*="#?testId="], .test-file-test');
  const count = await testLinks.count();
  if (count > 0) {
    await testLinks.first().click();
    await page.waitForTimeout(1500);
    // Captura 2: Detalle de los pasos ejecutados del test
    await page.screenshot({
      path: '/app/test-results/screenshots/06-playwright-report-detalle-pasos.png',
      fullPage: true
    });
    console.log('✓ Captura guardada: 06-playwright-report-detalle-pasos.png');
  }

  await browser.close();
})();
