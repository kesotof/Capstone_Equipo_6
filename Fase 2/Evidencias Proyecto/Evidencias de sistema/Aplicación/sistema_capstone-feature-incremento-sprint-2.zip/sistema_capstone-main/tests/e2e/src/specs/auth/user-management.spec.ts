import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { UsersPage, generateValidRut } from '../../pages/UsersPage';

test.describe.serial('Gestión de Usuarios (HU-03 / auth-003)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let usersPage: UsersPage;

  const runId = Date.now();
  const testUser = {
    email: `operador_${runId}@capstone.local`,
    firstName: 'Operador',
    lastName: 'E2E',
    password: 'Password123',
    newPassword: 'NewPassword456',
    updatedFirstName: 'Operador Editado',
    updatedLastName: 'Actualizado'
  };

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    usersPage = new UsersPage(page);
  });

  test('1. [CA 3.1] Admin crea nuevo usuario y este puede iniciar sesión efectivamente en el sistema', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Crear usuario
    await usersPage.createUser(
      testUser.email,
      testUser.firstName,
      testUser.lastName,
      testUser.password
    );

    // 4. Verificar que aparece en la tabla como Activo y con rol 'Emisor y Revisor'
    const row = usersPage.getUserRow(testUser.email);
    await expect(row).toBeVisible({ timeout: 10000 });
    await expect(row.locator('td').first()).toContainText(testUser.email);
    await expect(row.locator('.status-badge')).toHaveText('Activo');
    await expect(row.locator('.role-badges')).toContainText('Emisor y Revisor');

    // 5. Cerrar sesión de Admin
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });

    // 6. Nuevo usuario inicia sesión efectivamente
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.password);
    await dashboardPage.isDisplayed();
    await expect(page).toHaveURL(/.*\/dashboard/);

    // 7. Cerrar sesión del nuevo usuario
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });
  });

  test('2. [CA 3.2] Admin puede modificar datos del usuario (nombre, apellido y asignar nueva contraseña)', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Editar nombre, apellido y asignar nueva contraseña
    await usersPage.editUser(
      testUser.email,
      testUser.updatedFirstName,
      testUser.updatedLastName,
      testUser.newPassword,
      false
    );

    // 4. Verificar mensaje de éxito y tabla actualizada
    await expect(usersPage.successMessage).toBeVisible();
    const row = usersPage.getUserRow(testUser.email);
    await expect(row.locator('strong')).toHaveText(`${testUser.updatedFirstName} ${testUser.updatedLastName}`);

    // 5. Cerrar sesión de Admin y verificar que el usuario inicia sesión con su NUEVA contraseña
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });

    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.newPassword);
    await dashboardPage.isDisplayed();
    await expect(page).toHaveURL(/.*\/dashboard/);

    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });
  });

  test('3. [CA 3.3] Admin desactiva usuario sin borrar historial y se bloquea el inicio de sesión', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Desactivar usuario
    await usersPage.toggleUserStatus(testUser.email);

    // 4. Verificar que el badge cambia a Inactivo
    const row = usersPage.getUserRow(testUser.email);
    await expect(row.locator('.status-badge')).toHaveText('Inactivo', { timeout: 10000 });

    // 5. Cerrar sesión de Admin
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });

    // 6. Usuario desactivado intenta iniciar sesión con su contraseña actual -> debe ser rechazado
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.newPassword);

    // Keycloak debe mostrar mensaje de cuenta desactivada
    const errorText = await loginPage.getErrorMessage();
    expect(errorText.toLowerCase()).toMatch(/desactivada|deshabilitada|invalida/i);
  });

  test('4. Admin reactiva usuario y este puede volver a iniciar sesión exitosamente', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Reactivar usuario
    await usersPage.goto();
    await usersPage.isDisplayed();
    await usersPage.toggleUserStatus(testUser.email);

    const row = usersPage.getUserRow(testUser.email);
    await expect(row.locator('.status-badge')).toHaveText('Activo', { timeout: 10000 });

    // 3. Cerrar sesión de Admin
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });

    // 4. Usuario reactivado inicia sesión exitosamente con su contraseña vigente
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.newPassword);
    await dashboardPage.isDisplayed();
    await expect(page).toHaveURL(/.*\/dashboard/);

    // 5. Cerrar sesión
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });
  });

  test('5. Validación: Las contraseñas deben coincidir al crear un usuario', async () => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Abrir modal e ingresar contraseñas distintas
    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();
    await usersPage.emailInput.fill(`mismatch_${Date.now()}@capstone.local`);
    await usersPage.firstNameInput.fill('Test');
    await usersPage.lastNameInput.fill('Mismatch');
    await usersPage.passwordInput.fill('Password123');
    await usersPage.confirmPasswordInput.fill('PasswordDistinta999');
    await usersPage.submitCreateButton.click();

    // 4. Debe mantenerse el modal abierto y mostrar el mensaje de discrepancia
    await expect(usersPage.createModal).toBeVisible();
    await expect(usersPage.errorMessage).toBeVisible();
    const errorText = await usersPage.errorMessage.textContent();
    expect(errorText?.toLowerCase()).toContain('no coinciden');

    // Cerrar modal
    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('6. [CA 3.4] No permitir dos usuarios con el mismo correo', async () => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Intentar crear usuario con correo ya existente
    await usersPage.addUserButton.click();
    await expect(usersPage.createModal).toBeVisible();
    await usersPage.emailInput.fill(testUser.email);
    if (await usersPage.rutInput.isVisible().catch(() => false)) {
      await usersPage.rutInput.fill(generateValidRut());
    }
    await usersPage.firstNameInput.fill('Duplicado');
    await usersPage.lastNameInput.fill('Test');
    await usersPage.passwordInput.fill('Password123');
    await usersPage.confirmPasswordInput.fill('Password123');
    await usersPage.submitCreateButton.click();

    // 4. Debe mantenerse el modal abierto mostrando el mensaje de error de duplicado
    await expect(usersPage.createModal).toBeVisible();
    await expect(usersPage.errorMessage).toBeVisible();
    const errorText = await usersPage.errorMessage.textContent();
    expect(errorText?.toLowerCase()).toContain('ya existe');

    // Cerrar modal
    await usersPage.createModal.locator('button:has-text("Cancelar")').click();
    await expect(usersPage.createModal).toBeHidden();
  });

  test('7. Admin elimina usuario y este desaparece del sistema', async () => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Gestión de Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Eliminar usuario
    await usersPage.deleteUser(testUser.email);

    // 4. Verificar que la fila ya no existe en la tabla
    const row = usersPage.getUserRow(testUser.email);
    await expect(row).toBeHidden({ timeout: 10000 });
  });

  test('8. [CA 3.6] Toda acción de gestión de usuario queda registrada en la base de datos (log_evento)', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a una vista autenticada para asegurar sesión activa
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 3. Consultar eventos de auditoría desde el backend mediante el cliente autenticado
    const events: any[] = await page.evaluate(async () => {
      const resp = await (window as any).api.get('/api/audit/events?limit=50');
      return resp.data;
    });

    expect(Array.isArray(events)).toBe(true);

    // 4. Filtrar los eventos de gestión de usuario correspondientes al usuario de prueba generado en esta corrida
    const userEvents = events.filter((e: any) =>
      ['CREAR_USUARIO', 'ACTUALIZAR_USUARIO', 'DESACTIVAR_USUARIO', 'ACTIVAR_USUARIO', 'ELIMINAR_USUARIO'].includes(e.eventType) &&
      e.detalle && e.detalle.includes(testUser.email)
    );
    const eventTypes = userEvents.map((e: any) => e.eventType);

    // 5. Verificar que cada acción ejecutada se persistió en la tabla relacional log_evento
    expect(eventTypes).toContain('CREAR_USUARIO');
    expect(eventTypes).toContain('ACTUALIZAR_USUARIO');
    expect(eventTypes).toContain('DESACTIVAR_USUARIO');
    expect(eventTypes).toContain('ACTIVAR_USUARIO');
    expect(eventTypes).toContain('ELIMINAR_USUARIO');

    // 6. Verificar que el usuario asociado a la acción de gestión es el administrador con sesión activa (admin@capstone.local)
    expect(userEvents.length).toBeGreaterThanOrEqual(5);
    for (const event of userEvents) {
      expect(event.email).toBe('admin@capstone.local');
    }
  });

  test('9. [CA 3.5] Solo los administradores deben poder gestionar usuarios (rol APPROVER restringido en UI y API)', async ({ page }) => {
    // 1. Iniciar sesión como usuario operativo con rol APPROVER
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await dashboardPage.isDisplayed();

    // 2. Verificar que en la barra lateral NO existe la opción de gestión de usuarios
    const usersLink = page.locator('aside.sidebar a[href="/configurar-org-usuarios"]');
    await expect(usersLink).not.toBeVisible();

    // 3. Intentar acceder directamente por URL (debe redirigir al dashboard)
    await page.goto('/configurar-org-usuarios');
    await expect(page).toHaveURL(/.*\/dashboard/, { timeout: 10000 });

    // 4. Verificar que a nivel API recibe 403 Forbidden o 401 Unauthorized al no tener rol ADMIN
    const apiStatus = await page.evaluate(async () => {
      try {
        const resp = await (window as any).api.get('/api/users');
        return resp.status;
      } catch (err: any) {
        return err.response?.status || 403;
      }
    });
    expect([401, 403]).toContain(apiStatus);

    // 5. Cerrar sesión
    await dashboardPage.logout();
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });
  });
});
