import { Page, Locator, expect } from '@playwright/test';

export class AreasPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly createAreaButton: Locator;
  readonly refreshButton: Locator;
  readonly areaTable: Locator;
  readonly searchInput: Locator;
  readonly searchButton: Locator;
  readonly clearFiltersButton: Locator;

  // Modal de Área
  readonly dialog: Locator;
  readonly nameInput: Locator;
  readonly descriptionInput: Locator;
  readonly parentDropdownTrigger: Locator;
  readonly adminDropdownTrigger: Locator;
  readonly submitButton: Locator;
  readonly cancelButton: Locator;

  // Modal de Estado (Desactivar/Activar)
  readonly statusDialog: Locator;
  readonly confirmStatusButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('h2:has-text("Áreas corporativas"), #areas-page-title');
    this.createAreaButton = page.locator('button:has-text("Crear área")');
    this.refreshButton = page.locator('button:has-text("Actualizar")');
    this.areaTable = page.locator('table.areas-table');
    this.searchInput = page.locator('input#areas-search');
    this.searchButton = page.locator('button:has-text("Buscar")');
    this.clearFiltersButton = page.locator('button:has-text("Limpiar filtros")');

    this.dialog = page.locator('.area-dialog:has(#area-form-title), [role="dialog"]:has(#area-form-title)');
    this.nameInput = this.dialog.locator('input#area-nombre');
    this.descriptionInput = this.dialog.locator('textarea#area-descripcion');
    this.parentDropdownTrigger = this.dialog.locator('button#area-areaPadreId');
    this.adminDropdownTrigger = this.dialog.locator('button#area-administradorId');
    this.submitButton = this.dialog.locator('button[type="submit"]');
    this.cancelButton = this.dialog.locator('footer button:has-text("Cancelar")');

    this.statusDialog = page.locator('.area-dialog:has(#area-status-title), [role="dialog"]:has(#area-status-title)');
    this.confirmStatusButton = this.statusDialog.locator('footer button:has-text("Desactivar área"), footer button:has-text("Activar área")');
  }

  async goto() {
    const navLink = this.page.locator('aside.sidebar nav a:has-text("Áreas corporativas"), aside.sidebar nav a[href="/configurar-areas"]');
    if (await navLink.isVisible({ timeout: 10000 }).catch(() => false)) {
      await navLink.click();
    } else {
      await this.page.goto('/configurar-areas');
    }
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.heading).toBeVisible({ timeout: 15000 });
    await expect(this.page.locator('.loading-state')).toBeHidden({ timeout: 15000 }).catch(() => {});
    await expect(this.areaTable).toBeVisible({ timeout: 15000 }).catch(() => {});
    return true;
  }

  getAreaRow(nombre: string): Locator {
    return this.page.locator(`tr[data-area-name="${nombre}"]`);
  }

  async selectDropdownOption(trigger: Locator, optionText: string) {
    await trigger.click();
    const option = this.page.locator(`div[role="option"]:has-text("${optionText}")`).first();
    await expect(option).toBeVisible({ timeout: 5000 });
    await option.click();
  }

  async createArea(nombre: string, descripcion?: string, parentNombre?: string, adminEmailOrName?: string) {
    await this.createAreaButton.click();
    await expect(this.dialog).toBeVisible();
    await expect(this.dialog.locator('text=Cargando áreas superiores')).toBeHidden({ timeout: 10000 }).catch(() => {});
    await this.nameInput.fill(nombre);
    if (descripcion) {
      await this.descriptionInput.fill(descripcion);
    }
    if (parentNombre) {
      await expect(this.parentDropdownTrigger).toBeEnabled({ timeout: 10000 });
      await this.selectDropdownOption(this.parentDropdownTrigger, parentNombre);
    }
    if (adminEmailOrName) {
      await expect(this.adminDropdownTrigger).toBeEnabled({ timeout: 10000 });
      await this.selectDropdownOption(this.adminDropdownTrigger, adminEmailOrName);
    }
    await expect(this.submitButton).toBeEnabled({ timeout: 10000 });
    await this.submitButton.click();
    await expect(this.dialog).toBeHidden({ timeout: 25000 });
  }

  async editArea(currentNombre: string, nuevoNombre?: string, nuevaDescripcion?: string, nuevoAdminEmailOrName?: string) {
    const row = this.getAreaRow(currentNombre);
    await row.locator('button:has-text("Editar")').click();
    await expect(this.dialog).toBeVisible();
    await expect(this.dialog.locator('text=Cargando áreas superiores')).toBeHidden({ timeout: 10000 }).catch(() => {});

    if (nuevoNombre) {
      await this.nameInput.fill(nuevoNombre);
    }
    if (nuevaDescripcion) {
      await this.descriptionInput.fill(nuevaDescripcion);
    }
    if (nuevoAdminEmailOrName !== undefined) {
      await expect(this.adminDropdownTrigger).toBeEnabled({ timeout: 10000 });
      await this.selectDropdownOption(this.adminDropdownTrigger, nuevoAdminEmailOrName);
    }
    await expect(this.submitButton).toBeEnabled({ timeout: 10000 });
    await this.submitButton.click();
    await expect(this.dialog).toBeHidden({ timeout: 25000 });
  }

  async toggleStatus(nombre: string) {
    const row = this.getAreaRow(nombre);
    const toggleBtn = row.locator('button:has-text("Desactivar"), button:has-text("Activar")');
    await toggleBtn.click();
    await expect(this.statusDialog).toBeVisible();
    await this.confirmStatusButton.click();
    await expect(this.statusDialog).toBeHidden({ timeout: 25000 });
  }
}
