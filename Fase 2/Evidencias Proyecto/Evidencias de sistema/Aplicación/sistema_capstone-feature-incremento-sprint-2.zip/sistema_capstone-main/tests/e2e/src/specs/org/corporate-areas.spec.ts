import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { AreasPage } from '../../pages/AreasPage';
import { UsersPage, generateValidRut } from '../../pages/UsersPage';

test.describe.serial('Gestión de Áreas Corporativas y Organización (HU-S2-02, HU-S2-03, HU-S2-04 / E2E-ORG-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let areasPage: AreasPage;
  let usersPage: UsersPage;

  const runId = Date.now();
  const testOrgUser = {
    email: `usuario_org_${runId}@capstone.local`,
    firstName: 'Usuario',
    lastName: 'Departamental',
    password: 'Password123'
  };

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    areasPage = new AreasPage(page);
    usersPage = new UsersPage(page);
  });

  test('1. [CA 2.1, 2.4] Admin crea áreas corporativas y valida la restricción de nombres duplicados', async ({ page }) => {
    test.setTimeout(120000);

    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Navegar a Áreas Corporativas
    await areasPage.goto();
    await areasPage.isDisplayed();

    // 3. Área base "Operaciones" (semilla corporativa existente)
    const rowOperaciones = areasPage.getAreaRow('Operaciones');
    if (!(await rowOperaciones.isVisible().catch(() => false))) {
      await areasPage.createArea('Operaciones', 'Área de operaciones y logística empresarial');
      await expect(areasPage.dialog).toBeHidden({ timeout: 20000 });
      await expect(rowOperaciones).toBeVisible({ timeout: 15000 });
    }
    await expect(rowOperaciones.locator('.status-badge')).toHaveText('Activo');

    // 4. Crear nueva área "Finanzas"
    const rowFinanzas = areasPage.getAreaRow('Finanzas');
    if (!(await rowFinanzas.isVisible().catch(() => false))) {
      await areasPage.createArea('Finanzas', 'Área de finanzas, contabilidad y tesorería');
      await expect(areasPage.dialog).toBeHidden({ timeout: 20000 });
      await expect(rowFinanzas).toBeVisible({ timeout: 15000 });
    }
    await expect(rowFinanzas.locator('.status-badge')).toHaveText('Activo');

    // 5. Crear área "Tecnología" jerárquicamente dependiente de "Operaciones" según organigrama
    const rowTecnologia = areasPage.getAreaRow('Tecnología');
    const rowTecRenombrada = areasPage.getAreaRow('Tecnología e Infraestructura');
    if (!(await rowTecnologia.isVisible().catch(() => false)) && !(await rowTecRenombrada.isVisible().catch(() => false))) {
      await areasPage.createArea('Tecnología', 'Área de tecnologías de la información', 'Operaciones');
      await expect(areasPage.dialog).toBeHidden({ timeout: 20000 });
      await expect(rowTecnologia).toBeVisible({ timeout: 15000 });
      await expect(rowTecnologia.locator('.status-badge')).toHaveText('Activo');
      await expect(rowTecnologia.locator('td[data-label="Área superior"]')).toHaveText('Operaciones');
    }

    // 6. Validar restricción de unicidad de nombre (rechazo de duplicado "Finanzas")
    await areasPage.createAreaButton.click();
    await expect(areasPage.dialog).toBeVisible();
    await expect(areasPage.submitButton).toBeEnabled({ timeout: 10000 });
    await areasPage.nameInput.fill('Finanzas');
    await areasPage.submitButton.click();

    // Comprobar mensaje de conflicto de nombre duplicado
    const errorMessage = areasPage.dialog.locator('p:has-text("Ya existe un área con ese nombre")');
    await expect(errorMessage).toBeVisible({ timeout: 10000 });
    await expect(errorMessage).toContainText('Ya existe un área con ese nombre');

    // Cancelar diálogo
    await areasPage.cancelButton.click();
    await expect(areasPage.dialog).toBeHidden({ timeout: 10000 });
  });

  test('2. [CA 2.2] Admin edita el área existente Tecnología renombrándola a Tecnología e Infraestructura', async ({ page }) => {
    test.setTimeout(120000);

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    await areasPage.goto();
    await areasPage.isDisplayed();

    // Editar "Tecnología" si aún no ha sido renombrada
    const rowTecOriginal = areasPage.getAreaRow('Tecnología');
    if (await rowTecOriginal.isVisible().catch(() => false)) {
      await areasPage.editArea('Tecnología', 'Tecnología e Infraestructura', 'Área de TI, infraestructura y redes');
    }

    // Verificar que aparece el nuevo nombre en la grilla
    const rowRenombrada = areasPage.getAreaRow('Tecnología e Infraestructura');
    await expect(rowRenombrada).toBeVisible({ timeout: 15000 });
    await expect(rowRenombrada.locator('.status-badge')).toHaveText('Activo');

    // El nombre anterior ya no debe existir
    await expect(areasPage.getAreaRow('Tecnología')).toHaveCount(0);
  });

  test('3. [CA 3.1 - 3.5] Admin asigna y reasigna administrador de área con visibilidad en tabla y organigrama', async ({ page }) => {
    test.setTimeout(120000);

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    await areasPage.goto();
    await areasPage.isDisplayed();

    // 1. Asignar administrador a "Finanzas" (revisor@capstone.local)
    await areasPage.editArea('Finanzas', undefined, undefined, 'Revisor Documental');

    // 2. Verificar que en la columna "Administrador" de Finanzas aparece el administrador
    const rowFinanzas = areasPage.getAreaRow('Finanzas');
    await expect(rowFinanzas).toBeVisible({ timeout: 15000 });
    const adminCell = rowFinanzas.locator('td[data-label="Administrador"]');
    await expect(adminCell).toContainText('Revisor Documental');
    await expect(adminCell).toContainText('revisor@capstone.local');

    // 3. Reasignar administrador a Admin Capstone
    await areasPage.editArea('Finanzas', undefined, undefined, 'Admin Capstone');
    await expect(adminCell).toContainText('Admin Capstone');
    await expect(adminCell).toContainText('admin@capstone.local');

    // 4. Verificar visibilidad del organigrama en las columnas de la grilla
    const rowTec = areasPage.getAreaRow('Tecnología e Infraestructura');
    if (await rowTec.isVisible().catch(() => false)) {
      await expect(rowTec.locator('td[data-label="Área superior"]')).toHaveText('Operaciones');
    }
  });

  test('4. [CA 4.1 - 4.5] Vinculación bidireccional usuario - departamento y reasignación', async ({ page }) => {
    test.setTimeout(120000);

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 1. Navegar a Organización y Usuarios
    await usersPage.goto();
    await usersPage.isDisplayed();

    // 2. Crear usuario vinculado al área "Operaciones"
    await usersPage.createUser(
      testOrgUser.email,
      testOrgUser.firstName,
      testOrgUser.lastName,
      testOrgUser.password,
      false,
      undefined,
      generateValidRut(),
      'Operaciones'
    );

    // 3. Verificar que aparece con el área asignada "Operaciones"
    const userRow = usersPage.getUserRow(testOrgUser.email);
    await expect(userRow).toBeVisible({ timeout: 15000 });
    const areaCell = userRow.locator('td[data-label="Área"]');
    await expect(areaCell).toHaveText('Operaciones');

    // 4. Reasignar usuario a "Finanzas"
    await usersPage.editUser(
      testOrgUser.email,
      testOrgUser.firstName,
      testOrgUser.lastName,
      undefined,
      false,
      'Finanzas'
    );

    // 5. Verificar que el área se actualizó a "Finanzas" en la ficha del usuario
    await expect(areaCell).toHaveText('Finanzas');
  });

  test('5. [CA 2.3] Desactivación lógica con diálogo de confirmación y bloqueo ante dependencias activas', async ({ page }) => {
    test.setTimeout(120000);

    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    await areasPage.goto();
    await areasPage.isDisplayed();

    // 1. Desactivar "Tecnología e Infraestructura" con diálogo de confirmación (sin dependencias de usuarios)
    const rowTec = areasPage.getAreaRow('Tecnología e Infraestructura');
    if ((await rowTec.locator('.status-badge').textContent()) === 'Activo') {
      await areasPage.toggleStatus('Tecnología e Infraestructura');
    }
    await expect(rowTec.locator('.status-badge')).toHaveText('Inactivo', { timeout: 15000 });

    // 2. Intentar desactivar "Finanzas" (posee dependencias activas: usuario testOrgUser)
    const rowFinanzas = areasPage.getAreaRow('Finanzas');
    const deactivateBtn = rowFinanzas.locator('button:has-text("Desactivar")');
    await deactivateBtn.click();
    await expect(areasPage.statusDialog).toBeVisible({ timeout: 10000 });

    // Confirmar intento de desactivación en diálogo
    await areasPage.confirmStatusButton.click();

    // El sistema debe rechazar mostrando las dependencias activas (usuarios activos: 1)
    const errorNotice = areasPage.statusDialog.locator('.area-dependencies');
    await expect(errorNotice).toBeVisible({ timeout: 10000 });
    await expect(errorNotice).toContainText('Usuarios activos: 1');

    // Cancelar diálogo de estado
    await areasPage.statusDialog.locator('footer button:has-text("Cancelar")').click();
    await expect(areasPage.statusDialog).toBeHidden({ timeout: 10000 });

    // Finanzas sigue activo
    await expect(rowFinanzas.locator('.status-badge')).toHaveText('Activo');
  });

  test('6. [CA 2.5, 3.1] Restricción RBAC: usuario no administrador (APPROVER) no puede gestionar áreas', async ({ page }) => {
    test.setTimeout(120000);

    // 1. Iniciar sesión como Revisor (rol APPROVER)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });

    // 2. Verificar que en la barra lateral NO existe el menú "Áreas corporativas"
    const areasLink = page.locator('aside.sidebar nav a:has-text("Áreas corporativas")');
    await expect(areasLink).toHaveCount(0);

    // 3. Intento de navegación directa a /configurar-areas
    await page.goto('/configurar-areas');
    const createButton = page.locator('button:has-text("Crear área")');
    await expect(createButton).toBeDisabled({ timeout: 5000 }).catch(() => {
      // Si la UI oculta la vista o redirige, también es válido
    });

    // 4. Intento de consumo de API GET /api/areas como usuario APPROVER vía frontend apiClient
    const apiStatus = await page.evaluate(async () => {
      try {
        const resp = await (window as any).api.get('/api/areas');
        return resp.status;
      } catch (err: any) {
        return err.response?.status || 403;
      }
    });

    expect(apiStatus).toBe(403);
  });
});
