import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { ChangePasswordPage } from '../../pages/ChangePasswordPage';

/**
 * Suite E2E-SEC-AUTH-01: Autogestión de Credenciales (Cambio de Contraseña)
 * Historia: HU-S2-13 (auth-006)
 *
 * Criterios de Aceptación:
 * - CA 13.1: El usuario debe ingresar su contraseña actual antes de realizar el cambio.
 * - CA 13.2: El usuario debe ingresar una nueva contraseña y confirmarla.
 * - CA 13.3: Si la contraseña actual es incorrecta, mostrar el mensaje: “La contraseña actual es incorrecta, inténtelo nuevamente.”
 * - CA 13.4: La nueva contraseña debe cumplir con los requisitos mínimos de seguridad establecidos por el sistema.
 * - CA 13.5: Si las contraseñas nuevas no coinciden, mostrar un mensaje indicando que las contraseñas no coinciden.
 * - CA 13.6: Al cambiar correctamente la contraseña, mostrar un mensaje de confirmación y permitir al usuario continuar utilizando el sistema.
 */
test.describe.serial('HU-S2-13 / auth-006: Cambio de Contraseña (E2E-SEC-AUTH-01)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let changePasswordPage: ChangePasswordPage;
  let originalCredentialVerified = false;

  const testUser = {
    email: 'revisor@capstone.local',
    currentPass: 'revisor123',
    newValidPass: 'RevisorPass2026!',
    weakPassShort: 'Rev1',
    weakPassNoUpper: 'revisorpass2026',
    weakPassNoLower: 'REVISORPASS2026!',
    weakPassNoDigit: 'RevisorPassWord!'
  };

  async function keycloakIdentity(email: string) {
    const keycloakUrl = process.env.KEYCLOAK_URL || 'http://localhost:8080';
    const tokenResp = await fetch(`${keycloakUrl}/realms/master/protocol/openid-connect/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'password',
        client_id: 'admin-cli',
        username: process.env.KEYCLOAK_ADMIN_USER || 'admin',
        password: process.env.KEYCLOAK_ADMIN_PASSWORD || 'admin_secure_pass'
      })
    });

    expect(tokenResp.status, 'Acceso administrativo de limpieza disponible').toBe(200);
    const { access_token } = await tokenResp.json();

    const usersResp = await fetch(`${keycloakUrl}/admin/realms/capstone-realm/users?email=${encodeURIComponent(email)}`, {
      headers: { Authorization: `Bearer ${access_token}` }
    });

    expect(usersResp.status, 'Consulta de la cuenta de pruebas').toBe(200);
    const users = await usersResp.json();
    const exactUsers = users.filter((user: { email?: string }) => user.email === email);
    expect(exactUsers.length, 'Una única cuenta coincide con el correo de pruebas').toBe(1);
    return { keycloakUrl, accessToken: access_token, userId: exactUsers[0].id };
  }

  async function verifyOriginalPassword() {
    const keycloakUrl = process.env.KEYCLOAK_URL || 'http://localhost:8080';
    const response = await fetch(`${keycloakUrl}/realms/capstone-realm/protocol/openid-connect/token`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'password', client_id: 'capstone-client',
        username: testUser.email, password: testUser.currentPass })
    });
    expect(response.status, 'La credencial original de pruebas permite autenticarse').toBe(200);
    const { refresh_token } = await response.json();
    const logout = await fetch(`${keycloakUrl}/realms/capstone-realm/protocol/openid-connect/logout`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: 'capstone-client', refresh_token })
    });
    expect(logout.status, 'Cierre de la sesión temporal de verificación').toBe(204);
  }

  async function resetKeycloakPassword(email: string, targetPass: string) {
    const { keycloakUrl, accessToken, userId } = await keycloakIdentity(email);
    const reset = await fetch(`${keycloakUrl}/admin/realms/capstone-realm/users/${userId}/reset-password`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'password',
        value: targetPass,
        temporary: false
      })
    });
    expect(reset.status, 'Restauración de la credencial original en Keycloak').toBe(204);
    await verifyOriginalPassword();
  }

  test.beforeAll(async () => {
    await verifyOriginalPassword();
    await keycloakIdentity(testUser.email);
    originalCredentialVerified = true;
  });

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    changePasswordPage = new ChangePasswordPage(page);
  });

  test.afterAll(async () => {
    // Restaurar contraseña original del revisor
    if (originalCredentialVerified) await resetKeycloakPassword(testUser.email, testUser.currentPass);
  });

  test('1. [CA 13.1 y CA 13.2] Debe exigir ingresar contraseña actual, nueva contraseña y confirmación', async ({ page }) => {
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.currentPass);
    await dashboardPage.isDisplayed();

    await changePasswordPage.goto();
    await changePasswordPage.isDisplayed();

    // 1.1 Intentar enviar con campos vacíos
    await changePasswordPage.submit();
    await expect(changePasswordPage.fieldError('currentPassword')).toHaveText('La contraseña actual es obligatoria.');
    await expect(changePasswordPage.fieldError('newPassword')).toHaveText('La nueva contraseña es obligatoria.');
    await expect(changePasswordPage.fieldError('confirmPassword')).toHaveText('Confirme su nueva contraseña.');
    await expect(changePasswordPage.currentPasswordInput).toBeFocused();

    // 1.2 Ingresar clave actual pero sin nueva contraseña
    await changePasswordPage.currentPasswordInput.fill(testUser.currentPass);
    await changePasswordPage.submit();
    await expect(changePasswordPage.fieldError('newPassword')).toHaveText('La nueva contraseña es obligatoria.');
    await expect(changePasswordPage.fieldError('confirmPassword')).toHaveText('Confirme su nueva contraseña.');
    await changePasswordPage.newPasswordInput.fill(testUser.newValidPass);
    await changePasswordPage.submit();
    await expect(changePasswordPage.fieldError('confirmPassword')).toHaveText('Confirme su nueva contraseña.');
  });

  test('2. [CA 13.3] Si la contraseña actual es incorrecta, debe mostrar mensaje exacto', async ({ page }, testInfo) => {
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.currentPass);
    await dashboardPage.isDisplayed();

    await changePasswordPage.goto();
    await changePasswordPage.isDisplayed();

    // Ingresar contraseña actual errónea con nueva contraseña válida
    await changePasswordPage.fillForm(
      'claveIncorrecta999',
      testUser.newValidPass,
      testUser.newValidPass
    );
    const rejectedResponse = page.waitForResponse((response) =>
      response.url().endsWith('/api/auth/change-password') && response.request().method() === 'POST');
    await changePasswordPage.submit();
    const rejected = await rejectedResponse;
    const problem = await rejected.json();
    await testInfo.attach('respuesta-clave-actual-incorrecta', {
      body: JSON.stringify({ status: rejected.status(), code: problem.code,
        detail: problem.detail, invalidFields: problem.invalidFields }, null, 2),
      contentType: 'application/json'
    });
    expect(rejected.status(), 'Rechazo de contraseña actual incorrecta según contrato').toBe(400);
    expect(problem.code).toBe('CURRENT_PASSWORD_INVALID');

    // CA 13.3: Mensaje exacto requerido por el criterio de aceptación
    await expect(changePasswordPage.fieldError('currentPassword')).toHaveText('La contraseña actual es incorrecta, inténtelo nuevamente.');
  });

  test('3. [CA 13.4] La nueva contraseña debe cumplir la política efectiva de seguridad', async ({ page }, testInfo) => {
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.currentPass);
    await dashboardPage.isDisplayed();

    await changePasswordPage.goto();
    await changePasswordPage.isDisplayed();

    const policy = await page.evaluate(async () => {
      const { data } = await (window as any).api.get('/api/auth/password-policy');
      return { minLength: data.minLength, maxLength: data.maxLength,
        minUppercase: data.minUppercase, minLowercase: data.minLowercase,
        minDigits: data.minDigits, minSpecial: data.minSpecial, additionalRules: data.additionalRules };
    });
    expect(policy.minLength).toBeGreaterThanOrEqual(8);
    await testInfo.attach('politica-efectiva', { body: JSON.stringify(policy, null, 2), contentType: 'application/json' });
    await expect(changePasswordPage.rulesList).toContainText(`Al menos ${policy.minLength} caracteres`);
    const candidates = [testUser.weakPassShort];
    if (policy.minUppercase > 0) candidates.push(testUser.weakPassNoUpper);
    if (policy.minLowercase > 0) candidates.push(testUser.weakPassNoLower);
    if (policy.minDigits > 0) candidates.push(testUser.weakPassNoDigit);
    if (policy.minSpecial > 0) candidates.push('RevisorPass2026');
    for (const candidate of candidates) {
      await changePasswordPage.fillForm(testUser.currentPass, candidate, candidate);
      await changePasswordPage.submit();
      await expect(changePasswordPage.fieldError('newPassword')).toHaveText('La nueva contraseña no cumple los requisitos de seguridad.');
    }
  });

  test('4. [CA 13.5] Si las contraseñas nuevas no coinciden, debe mostrar mensaje indicando discrepancia', async ({ page }) => {
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.currentPass);
    await dashboardPage.isDisplayed();

    await changePasswordPage.goto();
    await changePasswordPage.isDisplayed();

    // Claves no coincidentes
    await changePasswordPage.fillForm(
      testUser.currentPass,
      testUser.newValidPass,
      'PasswordDiferente2026!'
    );
    await changePasswordPage.submit();

    await expect(changePasswordPage.fieldError('confirmPassword')).toHaveText('Las contraseñas no coinciden.');
  });

  test('5. [CA 13.6] Debe actualizar contraseña, confirmar y permitir continuar con la sesión', async ({ page }) => {
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.currentPass);
    await dashboardPage.isDisplayed();

    await changePasswordPage.goto();
    await changePasswordPage.isDisplayed();

    // Actualización exitosa
    await changePasswordPage.fillForm(
      testUser.currentPass,
      testUser.newValidPass,
      testUser.newValidPass
    );
    const changedResponse = page.waitForResponse((response) =>
      response.url().endsWith('/api/auth/change-password') && response.request().method() === 'POST');
    await changePasswordPage.submit();
    const changed = await changedResponse;
    expect(changed.status()).toBe(200);
    expect((await changed.json()).message).toBe('Contraseña actualizada exitosamente');

    // Verificar mensaje de confirmación
    const successMsg = await changePasswordPage.getSuccessMessage();
    expect(successMsg.toLowerCase()).toContain('actualizada exitosamente');

    // La confirmación retira el formulario y permite continuar con la sesión actual.
    await expect(changePasswordPage.currentPasswordInput).toHaveCount(0);
    await expect(changePasswordPage.newPasswordInput).toHaveCount(0);
    await expect(changePasswordPage.confirmPasswordInput).toHaveCount(0);
    await page.getByRole('link', { name: 'Continuar a la plataforma' }).click();
    await dashboardPage.isDisplayed();
    await expect(page).toHaveURL(/\/dashboard$/);
  });

  test('6. Verificación de credenciales actualizadas: login antiguo falla y nuevo accede al sistema', async ({ page }) => {
    // 6.1 Cerrar sesión activa
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();

    // 6.2 Intentar ingresar con contraseña antigua -> Debe fallar
    await loginPage.login(testUser.email, testUser.currentPass);
    const loginError = await loginPage.getErrorMessage();
    expect(loginError.toLowerCase()).toContain('credenciales invalidas');

    // 6.3 Ingresar con nueva contraseña -> Debe ingresar exitosamente al Dashboard
    await page.context().clearCookies();
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login(testUser.email, testUser.newValidPass);
    await dashboardPage.isDisplayed();
    expect(await page.url()).toContain('/dashboard');

    // afterAll restaura la credencial original y comprueba que vuelve a permitir autenticación.
  });
});
