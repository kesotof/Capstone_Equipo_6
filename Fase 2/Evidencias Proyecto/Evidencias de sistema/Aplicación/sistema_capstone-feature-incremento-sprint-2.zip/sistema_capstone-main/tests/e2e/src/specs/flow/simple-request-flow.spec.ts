import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe.serial('Flujo Completo de Solicitud Simple (Sprint 1)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  const runId = Date.now();
  const requestTitle = `Solicitud E2E ${runId}`;
  const rejectedTitle = `Solicitud Rechazo E2E ${runId}`;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [HU-04 / doc-001] Registro de documento simple con archivo adjunto', async ({ page }) => {
    // 1. Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 2. Navegar a Nuevo Documento
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    // 3. Completar formulario
    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Solicitud inicial de prueba para validación de flujo completo.');

    // 4. Adjuntar archivo de prueba
    await page.setInputFiles('#document-file', {
      name: `contrato_prueba_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contrato de prueba para verificación de flujo simple E2E.')
    });

    // 5. Verificar que el archivo seleccionado se muestra
    await expect(page.locator('.selected-document')).toBeVisible();
    await expect(page.locator('.selected-document-info strong')).toContainText(`contrato_prueba_${runId}.txt`);

    // 6. Enviar a revisión
    await page.click('button.document-upload-submit');

    // 7. Verificar mensaje de confirmación
    const successMsg = page.locator('.form-message-success');
    await expect(successMsg).toBeVisible({ timeout: 15000 });
    await expect(successMsg).toContainText('Documento registrado correctamente');

    // 8. Navegar a Estado Solicitudes y verificar estado Pendiente de Revisión
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    const row = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(row).toBeVisible({ timeout: 10000 });
    await expect(row.locator('.status-badge-pending')).toContainText(/Pendiente de revisi[oó]n/i);
  });

  test('2. [HU-05, HU-08 / flow-001, flow-004] Revisión con Solicitud de Corrección (Rechazo Parcial) y descarga', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Navegar a Revisar Documento
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 2. Aplicar filtros dinámicos de la bandeja y comprobar la paginación.
    // La espera implícita cubre el debounce de búsqueda del cliente.
    await page.locator('input[name="nombreArchivo"]').fill(`contrato_prueba_${runId}`);
    const item = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(item).toBeVisible({ timeout: 10000 });

    await page.locator('input[name="emisor"]').fill('admin@capstone.local');
    await expect(item).toBeVisible({ timeout: 10000 });

    const fechaActual = new Date().toISOString().slice(0, 10);
    await page.getByTestId('fechaDesde-trigger').click();
    await page.locator(`.review-calendar button[data-value="${fechaActual}"]`).click();
    await page.getByTestId('fechaHasta-trigger').click();
    await page.locator(`.review-calendar button[data-value="${fechaActual}"]`).click();
    await expect(item).toBeVisible({ timeout: 10000 });
    await expect(page.locator('.review-pagination')).toBeVisible();

    // 3. Seleccionar la solicitud pendiente
    await item.click();

    // 4. Verificar detalle cargado
    await expect(page.locator('[data-testid="detail-title"]')).toContainText(requestTitle);

    // 5. Probar descarga intermediada
    const downloadPromise = page.waitForEvent('download');
    await page.click('[data-testid="btn-descargar"]');
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toContain(`contrato_prueba_${runId}.txt`);

    // 6. Clic en "Pedir Corrección"
    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();

    // 7. Validar obligatoriedad de observación
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.form-message-error')).toContainText('obligatorio indicar las observaciones');

    // 8. Ingresar observación válida y confirmar
    const observacionTexto = 'Falta especificar claramente la cláusula de vigencia y firma del responsable.';
    await page.fill('[data-testid="modal-comment-input"]', observacionTexto);
    await page.click('[data-testid="modal-confirm-btn"]');

    // 9. Verificar mensaje de éxito
    await expect(page.locator('.page-message.form-message-success')).toContainText(/corrección solicitada|devuelta con observaciones|observaciones/i);
  });

  test('3. [HU-09, HU-10 / flow-005, flow-006] Visualización de Observaciones y Subsanación / Reenvío', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Navegar a Corregir Documento
    await page.click('aside.sidebar a[href="/corregir-documento"]');
    await expect(page.locator('#corregir-title')).toBeVisible();

    // 2. Seleccionar la solicitud observada
    const item = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(item).toBeVisible({ timeout: 10000 });
    await item.click();

    // 3. Verificar que la observación del revisor está claramente visible
    await expect(page.locator('[data-testid="observations-box"]')).toBeVisible();
    await expect(page.locator('[data-testid="observation-item-text"]')).toContainText(
      'Falta especificar claramente la cláusula de vigencia'
    );

    // 4. Modificar descripción y adjuntar archivo corregido
    await page.fill(
      '[data-testid="corregir-descripcion-input"]',
      'Se incorpora la cláusula de vigencia de 12 meses y firma digitalizada.'
    );

    await page.setInputFiles('#corregir-file', {
      name: `contrato_subsanado_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Contrato corregido con vigencia estipulada de 12 meses y firma adjunta.')
    });

    // 5. Reenviar a revisión
    await page.click('[data-testid="btn-reenviar"]');

    // 6. Verificar confirmación de reenvío
    await expect(page.locator('.page-message.form-message-success')).toContainText(
      'corregida y reenviada a revisión'
    );
  });

  test('4. [HU-06 / flow-002] Aprobación final de solicitud subsanada', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Navegar a Revisar Documento
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    // 2. La solicitud debe volver a aparecer en pendientes
    const item = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(item).toBeVisible({ timeout: 10000 });
    await item.click();

    // 3. Confirmar que el archivo vigente es la versión subsanada
    await expect(page.locator('.detail-card-body')).toContainText(`contrato_subsanado_${runId}.txt`);

    // 4. Clic en "Aprobar"
    await page.click('[data-testid="btn-aprobar"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();
    await page.click('[data-testid="modal-confirm-btn"]');

    // 5. Verificar mensaje de aprobación
    await expect(page.locator('.page-message.form-message-success')).toContainText('aprobada exitosamente');
  });

  test('5. [HU-07 / flow-003] Rechazo con motivo obligatorio', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Crear documento para rechazar
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await page.fill('#document-title', rejectedTitle);
    await page.setInputFiles('#document-file', {
      name: `propuesta_inviable_${runId}.txt`,
      mimeType: 'text/plain',
      buffer: Buffer.from('Propuesta técnica no alineada con presupuesto.')
    });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success')).toBeVisible({ timeout: 15000 });

    // 2. Ir a Revisar Documento
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    const item = page.locator(`tr:has-text("${rejectedTitle}")`);
    await expect(item).toBeVisible({ timeout: 10000 });
    await item.click();

    // 3. Clic en Rechazar
    await page.click('[data-testid="btn-rechazar"]');
    await expect(page.locator('.user-form-modal')).toBeVisible();

    // 4. Validar motivo obligatorio
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.form-message-error')).toContainText('obligatorio indicar el motivo');

    // 5. Escribir motivo y confirmar
    await page.fill('[data-testid="modal-comment-input"]', 'Rechazado por inviabilidad presupuestaria.');
    await page.click('[data-testid="modal-confirm-btn"]');

    // 6. Verificar mensaje de rechazo
    await expect(page.locator('.page-message.form-message-success')).toContainText('rechazada exitosamente');
  });

  test('6. [HU-12 / notif-001] Inbox de Notificaciones in-app y lectura', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Comprobar presencia del botón de campana
    const bellBtn = page.locator('.notification-bell-btn');
    await expect(bellBtn).toBeVisible();

    // 2. Abrir dropdown de notificaciones
    await bellBtn.click();
    const dropdown = page.locator('.notification-dropdown');
    await expect(dropdown).toBeVisible();

    // 3. Comprobar que hay notificaciones generadas por el flujo anterior
    await expect(page.locator('.notification-item').first()).toBeVisible({ timeout: 10000 });
    const notifItems = page.locator('.notification-item');
    const count = await notifItems.count();
    expect(count).toBeGreaterThan(0);

    // 4. Probar acción "Marcar todas leídas" si está visible
    const markAllBtn = page.locator('.mark-all-btn');
    if (await markAllBtn.isVisible()) {
      await markAllBtn.click();
      await expect(page.locator('[data-testid="notification-badge"]')).not.toBeVisible({ timeout: 10000 });
    }
  });

  test('7. [HU-11 / flow-007] Trazabilidad e historial cronológico inmutable en Estado Solicitudes', async ({ page }) => {
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // 1. Navegar a Estado Solicitudes
    await page.click('aside.sidebar a[href="/estado-solicitudes"]');
    await expect(page.locator('#estado-title')).toBeVisible();

    // 2. Seleccionar la solicitud aprobada
    const item = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(item).toBeVisible({ timeout: 10000 });
    await item.click();

    // 3. Verificar badge de estado APROBADO
    await expect(page.locator('.detail-card .status-badge-approved')).toContainText('Aprobado');

    // 4. Verificar presencia de la línea de tiempo con transiciones
    await expect(page.locator('[data-testid="timeline-container"]')).toBeVisible();
    const timelineItems = page.locator('[data-testid="timeline-item"]');
    await expect.poll(() => timelineItems.count(), { timeout: 10000 }).toBeGreaterThanOrEqual(4);
    const itemCount = await timelineItems.count();

    // Debe contener al menos CREAR, PEDIR_CORRECCION, REENVIAR, APROBAR (4 transiciones)
    expect(itemCount).toBeGreaterThanOrEqual(4);

    const timelineText = await page.locator('[data-testid="timeline-container"]').innerText();
    expect(timelineText).toContain('CREAR');
    expect(timelineText).toContain('PEDIR_CORRECCION');
    expect(timelineText).toContain('REENVIAR');
    expect(timelineText).toContain('APROBAR');
  });
});
