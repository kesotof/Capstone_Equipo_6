import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import * as fs from 'fs';

const CONTEXT_FILE = '/app/test-results/test-notificaciones-context.json';

test.describe.serial('[TEST] Validación de criterios de aceptación para Revisar notificaciones en bandeja de entrada', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. [CA 4] Persistencia inmediata tras evento de cambio de estado', async ({ page }) => {
    test.setTimeout(100000);

    const runId = Date.now();
    const requestTitle = `Doc Notif Inmediata ${runId}`;

    // 1. Iniciar sesión como Emisor (Admin)
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Registrar nuevo documento (generando evento de cambio de estado a PENDIENTE_REVISION)
    await page.click('aside.sidebar a[href="/nuevo-documento"]');
    await expect(page.locator('#document-upload-title')).toBeVisible();

    await page.fill('#document-title', requestTitle);
    await page.fill('#document-description', 'Validación de persistencia inmediata de notificación.');
    await page.setInputFiles('#document-file', {
      name: `notif_test_${runId}.pdf`,
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4 Notif test stream content')
    });

    await expect(page.locator('.selected-document')).toBeVisible({ timeout: 10000 });
    await page.click('button.document-upload-submit');
    await expect(page.locator('.form-message-success, .document-upload-message')).toBeVisible({ timeout: 35000 });

    // 3. Obtener el ID de la solicitud creada desde el backend
    const createdSolicitud = await page.evaluate(async (title) => {
      const resp = await window.api.get('/api/solicitudes/mis-solicitudes');
      return resp.data?.find((s: any) => s.titulo === title);
    }, requestTitle);

    expect(createdSolicitud).toBeDefined();
    const createdSolicitudId = createdSolicitud.id;

    // 4. Iniciar sesión como Revisor para verificar persistencia inmediata en su bandeja
    await page.click('button.logout-btn');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 5. CRITERIO 4 VALIDACIÓN: La campana de notificaciones y el badge deben reflejar la llegada inmediata
    const bellBtn = page.locator('button.notification-bell-btn');
    await expect(bellBtn).toBeVisible({ timeout: 15000 });

    // Abrir el panel de notificaciones
    await bellBtn.click();
    const dropdown = page.locator('#notification-panel');
    await expect(dropdown).toBeVisible({ timeout: 10000 });

    // La notificación recién generada debe existir en la lista de notificaciones de revisor
    const notifItem = dropdown.locator(`.notification-item:has-text("${requestTitle}")`);
    await expect(notifItem).toBeVisible({ timeout: 15000 });
    await expect(notifItem).toContainText(/Nueva solicitud/i);
    await expect(notifItem).toHaveClass(/notification-item-unread/);
    await expect(notifItem.locator('.notification-unread-dot')).toBeVisible();

    // Obtener detalles de la notificación
    const notifDetails = await page.evaluate(async (title) => {
      const resp = await window.api.get('/api/notificaciones');
      return resp.data?.find((n: any) => n.mensaje.includes(title));
    }, requestTitle);

    expect(notifDetails).toBeDefined();
    expect(notifDetails.solicitudId).toBe(createdSolicitudId);
    expect(notifDetails.leida).toBe(false);

    // Persistir contexto para pruebas subsiguientes
    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      createdSolicitudId,
      requestTitle,
      revisorNotifId: notifDetails.id
    }, null, 2));

    // Captura fotográfica de evidencia para Criterio 4
    await page.screenshot({
      path: '/app/test-results/screenshots/01-persistencia-inmediata-notificacion.png',
      fullPage: true
    });
  });

  test('2. [CA 1] Aislamiento estricto: usuario solo ve sus notificaciones', async ({ page }) => {
    test.setTimeout(140000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle } = contextData;
    const obsTexto = `Obs notif aislamiento ${Date.now()}`;

    // 1. Iniciar sesión explícitamente como Revisor
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 2. Revisor solicita corrección sobre el documento
    await page.click('aside.sidebar a[href="/revisar-documento"]');
    await expect(page.locator('#revisar-title')).toBeVisible();

    const row = page.locator(`tr:has-text("${requestTitle}")`);
    await expect(row).toBeVisible({ timeout: 20000 });
    await row.click();

    await page.click('[data-testid="btn-pedir-correccion"]');
    await expect(page.locator('.user-form-modal')).toBeVisible({ timeout: 10000 });
    await page.fill('[data-testid="modal-comment-input"]', obsTexto);
    await page.click('[data-testid="modal-confirm-btn"]');
    await expect(page.locator('.page-message.form-message-success, .form-message-success')).toBeVisible({ timeout: 25000 });

    // 3. CRITERIO 1 VALIDACIÓN EN UI:
    // El evento 'PEDIR_CORRECCION' genera notificación EXCLUSIVA para el emisor (Admin).
    // El Revisor NO debe ver en su propia bandeja la notificación de "Corrección requerida".
    const bellBtn = page.locator('button.notification-bell-btn');
    await bellBtn.click();
    const dropdown = page.locator('#notification-panel');
    await expect(dropdown).toBeVisible({ timeout: 10000 });

    // Verificar que en la bandeja del Revisor NO figure la notificación de corrección dirigida al emisor
    const notifCorreccionEnRevisor = dropdown.locator(`.notification-item:has-text("${obsTexto}")`);
    await expect(notifCorreccionEnRevisor).not.toBeVisible();

    // 4. Iniciar sesión como Emisor (Admin) para verificar que él SÍ la recibe
    await page.click('button.logout-btn');
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    const bellBtnAdmin = page.locator('button.notification-bell-btn');
    await bellBtnAdmin.click();
    const dropdownAdmin = page.locator('#notification-panel');
    await expect(dropdownAdmin).toBeVisible({ timeout: 10000 });

    const notifAdmin = dropdownAdmin.locator(`.notification-item:has-text("${requestTitle}")`);
    await expect(notifAdmin).toBeVisible({ timeout: 15000 });
    await expect(notifAdmin).toContainText(/Corrección requerida/i);

    // Obtener la notificación de corrección del admin
    const adminNotifData = await page.evaluate(async (title) => {
      const resp = await window.api.get('/api/notificaciones');
      return resp.data?.find((n: any) => n.mensaje.includes(title) && n.tipo === 'CORRECCION_REQUERIDA');
    }, requestTitle);

    expect(adminNotifData).toBeDefined();
    expect(adminNotifData.leida).toBe(false);

    fs.writeFileSync(CONTEXT_FILE, JSON.stringify({
      ...contextData,
      adminNotifId: adminNotifData.id,
      obsTexto
    }, null, 2));

    // Captura fotográfica de evidencia para Criterio 1
    await page.screenshot({
      path: '/app/test-results/screenshots/02-aislamiento-estricto-notificaciones.png',
      fullPage: true
    });

    // 5. CRITERIO 1 VALIDACIÓN EN API:
    // Un usuario no autorizado (Revisor) no puede marcar ni alterar notificaciones de otro usuario (Admin)
    // El endpoint PATCH /api/notificaciones/{id}/leer debe rechazar con 403 Forbidden cuando el destinatario no coincide.
    await page.click('button.logout-btn');
    await loginPage.isDisplayed();
    await loginPage.login('revisor@capstone.local', 'revisor123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });
    await expect(page.locator('button.notification-bell-btn')).toBeVisible({ timeout: 15000 });
    await page.waitForTimeout(2000);

    const status403 = await page.evaluate(async (notifId) => {
      try {
        await window.api.patch(`/api/notificaciones/${notifId}/leer`);
        return 200;
      } catch (err: any) {
        return err.response?.status || 500;
      }
    }, adminNotifData.id);

    expect(status403).toBe(403);
  });

  test('3. [CA 2] Correcta distinción entre estado leída/no leída y marcado de lectura', async ({ page }) => {
    test.setTimeout(100000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { requestTitle } = contextData;

    // Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 1. Abrir panel de notificaciones
    const bellBtn = page.locator('button.notification-bell-btn');
    await bellBtn.click();
    const dropdown = page.locator('#notification-panel');
    await expect(dropdown).toBeVisible({ timeout: 10000 });

    // 2. Comprobar distinción visual de no leída
    const notifItem = dropdown.locator(`.notification-item:has-text("${requestTitle}")`).first();
    await expect(notifItem).toBeVisible({ timeout: 15000 });
    await expect(notifItem).toHaveClass(/notification-item-unread/);
    await expect(notifItem.locator('.notification-unread-dot')).toBeVisible();

    // 3. Probar filtro "No leídas"
    const unreadFilterBtn = dropdown.locator('.notification-filters button:has-text("No leídas")');
    await unreadFilterBtn.click();
    await expect(unreadFilterBtn).toHaveClass(/is-active/);
    await expect(dropdown.locator(`.notification-item:has-text("${requestTitle}")`).first()).toBeVisible();

    // Volver a "Todas"
    const allFilterBtn = dropdown.locator('.notification-filters button:has-text("Todas")');
    await allFilterBtn.click();
    await expect(allFilterBtn).toHaveClass(/is-active/);

    // 4. Probar "Marcar todas leídas"
    const markAllBtn = dropdown.locator('button.mark-all-btn');
    if (await markAllBtn.isVisible().catch(() => false)) {
      await markAllBtn.click();
      await page.waitForTimeout(1000);
    }

    // 5. Verificar que el badge numérico desaparece y los ítems ya no tienen estilo unread
    await expect(dropdown.locator('.notification-item-unread')).toHaveCount(0);
    await expect(page.locator('.notification-badge')).not.toBeVisible();

    // 6. Verificar en filtro "No leídas" que ahora muestre el mensaje vacío "Todo al día"
    await unreadFilterBtn.click();
    await expect(dropdown.locator('.notification-empty')).toContainText(/Todo al día/i);

    // 7. Verificación a nivel API de count == 0 y flags leida == true
    const unreadCount = await page.evaluate(async () => {
      const resp = await window.api.get('/api/notificaciones/no-leidas/count');
      return resp.data?.count;
    });
    expect(unreadCount).toBe(0);

    // Captura fotográfica de evidencia para Criterio 2
    await page.screenshot({
      path: '/app/test-results/screenshots/03-distincion-leida-no-leida.png',
      fullPage: true
    });
  });

  test('4. [CA 3] Redirección precisa a la solicitud asociada', async ({ page }) => {
    test.setTimeout(100000);

    const contextData = JSON.parse(fs.readFileSync(CONTEXT_FILE, 'utf8'));
    const { createdSolicitudId, requestTitle } = contextData;

    // Iniciar sesión como Admin
    await loginPage.goto();
    await loginPage.isDisplayed();
    await loginPage.login('admin@capstone.local', 'admin123');
    await page.waitForURL('**/dashboard', { timeout: 30000 });
    await expect(dashboardPage.brandTitle).toBeVisible({ timeout: 20000 });

    // 1. Abrir panel de notificaciones en "Todas"
    const bellBtn = page.locator('button.notification-bell-btn');
    await bellBtn.click();
    const dropdown = page.locator('#notification-panel');
    await expect(dropdown).toBeVisible({ timeout: 10000 });

    const allFilterBtn = dropdown.locator('.notification-filters button:has-text("Todas")');
    await allFilterBtn.click();

    // 2. Localizar la notificación asociada a la solicitud de corrección
    const notifItem = dropdown.locator(`.notification-item:has-text("${requestTitle}")`).first();
    await expect(notifItem).toBeVisible({ timeout: 15000 });
    await expect(notifItem.locator('.notification-item-action')).toContainText(/Ver solicitud|Marcar como leída/i);

    // 3. CRITERIO 3 VALIDACIÓN: Hacer click en la notificación debe redirigir a la vista exacta de la solicitud
    await notifItem.click();

    // El panel de notificaciones debe cerrarse
    await expect(dropdown).not.toBeVisible({ timeout: 5000 });

    // Debe navegar hacia /corregir-documento?id={createdSolicitudId}
    await page.waitForURL((url) => url.searchParams.get('id') === createdSolicitudId || url.pathname.includes('/corregir-documento'), { timeout: 20000 });
    expect(page.url()).toContain(encodeURIComponent(createdSolicitudId));

    // Confirmar que la vista de corrección cargó la solicitud seleccionada
    await expect(page.locator('#corregir-title')).toBeVisible({ timeout: 10000 });

    // Captura fotográfica de evidencia para Criterio 3
    await page.screenshot({
      path: '/app/test-results/screenshots/04-redireccion-solicitud-asociada.png',
      fullPage: true
    });
  });
});
