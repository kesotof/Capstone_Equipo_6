import { Page, Locator, expect } from '@playwright/test';

export function generateValidRut(): string {
  const cuerpoNum = Math.floor(10000000 + Math.random() * 89999999);
  const cuerpoStr = String(cuerpoNum);
  let suma = 0;
  let multiplicador = 2;
  for (let i = cuerpoStr.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpoStr[i], 10) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }
  const resto = suma % 11;
  const dvNum = 11 - resto;
  let dv = '';
  if (dvNum === 11) dv = '0';
  else if (dvNum === 10) dv = 'K';
  else dv = String(dvNum);

  const formattedCuerpo = cuerpoStr.replace(/(\d{2})(\d{3})(\d{3})/, '$1.$2.$3');
  return `${formattedCuerpo}-${dv}`;
}

export class UsersPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly addUserButton: Locator;
  readonly refreshButton: Locator;
  readonly userTable: Locator;
  readonly successMessage: Locator;
  readonly errorMessage: Locator;

  // Modal Crear
  readonly createModal: Locator;
  readonly emailInput: Locator;
  readonly rutInput: Locator;
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly areaSelect: Locator;
  readonly passwordInput: Locator;
  readonly confirmPasswordInput: Locator;
  readonly requirePasswordChangeCheckbox: Locator;
  readonly submitCreateButton: Locator;

  // Modal Editar
  readonly editModal: Locator;
  readonly editFirstNameInput: Locator;
  readonly editLastNameInput: Locator;
  readonly editAreaSelect: Locator;
  readonly editNewPasswordInput: Locator;
  readonly editConfirmPasswordInput: Locator;
  readonly editRequirePasswordChangeCheckbox: Locator;
  readonly submitEditButton: Locator;

  // Modal Eliminar
  readonly deleteModal: Locator;
  readonly confirmDeleteButton: Locator;


  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('h2:has-text("Organización y usuarios"), .page-header h2');
    this.addUserButton = page.locator('button.add-user-button');
    this.refreshButton = page.locator('button[aria-label="Actualizar usuarios"]');
    this.userTable = page.locator('table.data-table');
    this.successMessage = page.locator('.page-message.form-message-success');
    this.errorMessage = page.locator('.page-message.form-message-error, .form-message.form-message-error');

    this.createModal = page.locator('form.user-form-modal[aria-labelledby="create-user-title"]');
    this.emailInput = this.createModal.locator('input[name="email"]');
    this.rutInput = this.createModal.locator('input[name="rut"]');
    this.firstNameInput = this.createModal.locator('input[name="firstName"]');
    this.lastNameInput = this.createModal.locator('input[name="lastName"]');
    this.areaSelect = this.createModal.locator('button#create-user-area, select[name="areaId"]');
    this.passwordInput = this.createModal.locator('input[name="password"]');
    this.confirmPasswordInput = this.createModal.locator('input[name="confirmPassword"]');
    this.requirePasswordChangeCheckbox = this.createModal.locator('input[name="requirePasswordChange"]');
    this.submitCreateButton = this.createModal.locator('button[type="submit"]');

    this.editModal = page.locator('form.user-form-modal[aria-labelledby="edit-user-title"]');
    this.editFirstNameInput = this.editModal.locator('input[name="firstName"]');
    this.editLastNameInput = this.editModal.locator('input[name="lastName"]');
    this.editAreaSelect = this.editModal.locator('button#edit-user-area, select[name="areaId"]');
    this.editNewPasswordInput = this.editModal.locator('input[name="newPassword"]');
    this.editConfirmPasswordInput = this.editModal.locator('input[name="confirmPassword"]');
    this.editRequirePasswordChangeCheckbox = this.editModal.locator('input[name="requirePasswordChange"]');
    this.submitEditButton = this.editModal.locator('button[type="submit"]');

    this.deleteModal = page.locator('div.user-form-modal[aria-labelledby="delete-user-title"]');
    this.confirmDeleteButton = this.deleteModal.locator('button.danger-btn');
  }

  private async selectAreaOption(trigger: Locator, areaName: string) {
    const tagName = await trigger.evaluate((el) => el.tagName.toLowerCase()).catch(() => '');
    if (tagName === 'select') {
      await trigger.selectOption({ label: areaName });
    } else {
      await trigger.click();
      const option = this.page.locator(`div[role="option"]:has-text("${areaName}")`).first();
      await expect(option).toBeVisible({ timeout: 10000 });
      await option.click();
    }
  }

  async goto() {
    const navLink = this.page.locator('aside.sidebar nav a:has-text("Organización y usuarios"), aside.sidebar nav a[href="/configurar-org-usuarios"]');
    if (await navLink.isVisible({ timeout: 10000 }).catch(() => false)) {
      await navLink.click();
    } else {
      await this.page.goto('/configurar-org-usuarios');
    }
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.heading).toBeVisible({ timeout: 15000 });
    return true;
  }

  async createUser(
    email: string,
    firstName: string,
    lastName: string,
    password: string,
    requirePasswordChange: boolean = false,
    confirmPassword?: string,
    rut?: string,
    areaName?: string
  ) {
    await this.addUserButton.click();
    await expect(this.createModal).toBeVisible();
    await this.emailInput.fill(email);
    if (await this.rutInput.isVisible().catch(() => false)) {
      await this.rutInput.fill(rut || generateValidRut());
    }
    await this.firstNameInput.fill(firstName);
    await this.lastNameInput.fill(lastName);
    if (areaName && await this.areaSelect.isVisible().catch(() => false)) {
      await this.selectAreaOption(this.areaSelect, areaName);
    }
    await this.passwordInput.fill(password);
    await this.confirmPasswordInput.fill(confirmPassword !== undefined ? confirmPassword : password);
    if (!requirePasswordChange && await this.requirePasswordChangeCheckbox.isChecked()) {
      await this.requirePasswordChangeCheckbox.uncheck();
    }
    await this.submitCreateButton.click();
    await expect(this.createModal).toBeHidden({ timeout: 25000 });
  }


  getUserRow(email: string) {
    return this.page.locator(`tr[data-user-email="${email}"]`);
  }

  async editUser(
    email: string,
    newFirstName: string,
    newLastName: string,
    newPassword?: string,
    requirePasswordChange: boolean = false,
    newAreaName?: string
  ) {
    const row = this.getUserRow(email);
    await row.locator('button[title="Editar datos de usuario"]').click();
    await expect(this.editModal).toBeVisible();
    await this.editFirstNameInput.fill(newFirstName);
    await this.editLastNameInput.fill(newLastName);
    if (newAreaName && await this.editAreaSelect.isVisible().catch(() => false)) {
      await this.selectAreaOption(this.editAreaSelect, newAreaName);
    }

    if (newPassword) {
      await this.editNewPasswordInput.fill(newPassword);
      await this.editConfirmPasswordInput.fill(newPassword);
      if (requirePasswordChange) {
        if (!await this.editRequirePasswordChangeCheckbox.isChecked()) {
          await this.editRequirePasswordChangeCheckbox.check();
        }
      } else {
        if (await this.editRequirePasswordChangeCheckbox.isChecked()) {
          await this.editRequirePasswordChangeCheckbox.uncheck();
        }
      }
    }

    await this.submitEditButton.click();
    await expect(this.editModal).toBeHidden({ timeout: 25000 });
  }

  async toggleUserStatus(email: string) {
    const row = this.getUserRow(email);
    const toggleButton = row.locator('button.action-btn-toggle-active, button.action-btn-toggle-inactive');
    await toggleButton.click();
  }


  async deleteUser(email: string) {
    const row = this.getUserRow(email);
    await row.locator('button.action-btn-danger').click();
    await expect(this.deleteModal).toBeVisible();
    await this.confirmDeleteButton.click();
    await expect(this.deleteModal).toBeHidden({ timeout: 10000 });
  }
}
