# Sistema de Gestión Documental y Flujos de Aprobación (Capstone)

Firma: Eduardo Kusar

Plataforma integral y modular para la gestión de documentos, flujos de aprobación multinivel, notificaciones transaccionales y asistencia de inteligencia artificial.

## Arquitectura General

```
                              ┌─────────────────────────┐
                              │  Frontend (React SPA)   │
                              │   Acceso / Config /     │
                              │   Documentos / Flujos   │
                              └────────────┬────────────┘
                                           │
                        ┌──────────────────┼──────────────────┐
                        │ Redirect         │ HTTPS + JWT      │
                        ▼                  ▼                  ▼
              ┌──────────────────┐  ┌───────────────┐  ┌──────────────┐
              │ Keycloak (OIDC)  │  │   Postgres    │  │ MinIO (S3)   │
              │  Motor de Auth   │  │   (Multi-DB)  │  │  Documentos  │
              └────────┬─────────┘  └───────┬───────┘  └──────┬───────┘
                       │                    │                 │
                       └──────────────┬─────┴─────────────────┘
                                      ▼
                       ┌───────────────────────────────┐
                       │   Sistema Principal (Spring)  │
                       │   - Flow (Motor de Flujos)    │
                       │   - Auth (RBAC / JWT)         │
                       │   - Doc (Gestor Documental)   │
                       │   - Org (Organización/Config) │
                       └──────────────┬────────────────┘
                                      │ Eventos
                                      ▼
                          ┌───────────────────────┐
                          │ RabbitMQ (Broker AMQP)│
                          └───────┬───────────┬───┘
                                  │           │
                     ┌────────────┴──┐     ┌──┴─────────────┐
                     ▼               ▼     ▼                ▼
         ┌───────────────────────┐             ┌───────────────────────┐
         │ Service Notificaciones│             │  Service Consultas IA │
         │     (Spring Boot)     │             │     (Spring Boot)     │
         └───────────┬───────────┘             └───────────┬───────────┘
                     │                                     │
                     ▼                                     ▼
             MasterBase® API                          Gemini API
```

## Estructura del Repositorio

- `frontend/`: Single Page Application desarrollada en React (Vite) con todas las vistas de negocio, flujos y autenticación.
- `backend/sistema-principal/`: Microservicio central en Spring Boot con los módulos `flow`, `auth`, `doc` y `org`.
- `backend/service-notificaciones/`: Microservicio en Spring Boot consumidor de RabbitMQ para despacho de correos vía MasterBase API.
- `backend/service-ia/`: Microservicio en Spring Boot consumidor de RabbitMQ para evaluaciones automáticas vía Gemini API.
- `docker/`: Scripts de inicialización para PostgreSQL y MinIO.
- `docker-compose.yml`: Orquestador de contenedores para desarrollo y despliegue.

## Inicio Rápido

### 1. Variables de Entorno
Copia el archivo de ejemplo y ajusta los valores necesarios:
```bash
cp .env.example .env
```

### 2. Levantar Infraestructura Base
Para iniciar las bases de datos (PostgreSQL), Keycloak, RabbitMQ y MinIO:
```bash
docker compose up -d postgres keycloak rabbitmq minio minio-init
```

### 3. Levantar Todo el Stack (Infraestructura + Aplicaciones)
```bash
docker compose --profile apps up -d
```

### Puertos por Defecto
| Servicio | Puerto | Descripción |
|---|---|---|
| Frontend (React) | `3000` | Interfaz web de usuario |
| Keycloak Admin | `8080` | Consola de administración SSO |
| Sistema Principal | `8081` | API REST Spring Boot |
| Service Notificaciones | `8082` | Microservicio de correo |
| Service Consultas IA | `8083` | Microservicio de análisis IA |
| PostgreSQL | `5432` | Bases de datos relacionales |
| RabbitMQ Management | `15672` | Consola web RabbitMQ (guest/guest) |
| MinIO Console | `9001` | Consola web S3 (minioadmin) |
| MinIO API | `9000` | Endpoint S3 compatible |