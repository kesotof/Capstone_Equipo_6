import React, { useRef } from 'react';
import { createPortal } from 'react-dom';
import { Download, X } from 'lucide-react';
import { Button, FeedbackMessage } from '../ui';
import useDocumentDownload from '../../hooks/useDocumentDownload';
import './DocumentDownloadButton.css';

export default function DocumentDownloadButton({ documentId, solicitudId, fileName, allowed,
  contextKey = '', compact = false, disabled = false, ...props }) {
  const download = useDocumentDownload({ documentId, solicitudId, fileName }, allowed, contextKey);
  const host = useRef(null);
  if (!download.permitted) return null;
  return <span ref={host} className="document-download-action">
    <Button {...props} variant="secondary" className={compact ? 'ui-button--compact' : ''}
      onClick={download.download} loading={download.busy} disabled={disabled}
      aria-label={(download.busy ? 'Descargando ' : 'Descargar ') + (fileName || 'documento')}>
      <Download size={compact ? 15 : 16} aria-hidden="true" />
      <span>{download.busy ? 'Descargando…' + (download.percent != null ? ' ' + download.percent + '%' : '') : 'Descargar'}</span>
    </Button>
    {download.notice?.tone === 'success' && <span className="visually-hidden" role="status">{download.notice.message}</span>}
    {download.notice?.tone === 'error' && createPortal(
      <FeedbackMessage tone="error" title="Descarga no disponible" className="document-download-toast">
        <p>{download.notice.message}</p>
        <Button variant="quiet" onClick={download.dismiss} className="document-download-toast-close" aria-label="Cerrar aviso de descarga">
          <X size={17} aria-hidden="true" />
        </Button>
      </FeedbackMessage>, host.current?.closest('[role="dialog"]') || document.body)}
  </span>;
}
