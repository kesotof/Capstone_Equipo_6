import api from './api';

const states = ['pendientes', 'aprobadas', 'rechazadas', 'enCorreccion', 'otros'];
const invalid = () => { const error = new Error('El resumen recibido no tiene un formato válido.'); error.code = 'DASHBOARD_CONTRACT'; throw error; };
const count = (value) => Number.isSafeInteger(value) && value >= 0;
const id = (value) => Number.isSafeInteger(value) && value > 0;
const name = (value) => typeof value === 'string' && value.trim().length > 0;
function validateTotals(totals) {
  if (!totals || !states.every((key) => count(totals[key])) || !count(totals.total)
      || states.reduce((sum, key) => sum + totals[key], 0) !== totals.total) invalid();
}
function validateSummary(data, selection) {
  if (!data || typeof data.puedeFiltrarPorArea !== 'boolean' || typeof data.sinArea !== 'boolean'
      || data.zonaHoraria !== 'America/Santiago' || typeof data.consultadoEn !== 'string' || !Number.isFinite(Date.parse(data.consultadoEn))
      || !Array.isArray(data.porArea) || !Array.isArray(data.catalogoAreas) || !Array.isArray(data.tendencias)
      || data.tendencias.length !== 7) invalid();
  const areaId = selection !== 'all' && selection !== 'unassigned' ? Number(selection) : null;
  if (data.areaId !== areaId || data.sinArea !== (selection === 'unassigned')) invalid();
  if (selection !== 'all' && !data.puedeFiltrarPorArea) invalid();
  validateTotals(data.totales);
  const seen = new Set();
  const sums = Object.fromEntries([...states, 'total'].map((key) => [key, 0]));
  for (const row of data.porArea) {
    if (!row || (row.areaId !== null && !id(row.areaId)) || seen.has(row.areaId) || !name(row.nombre)
        || (row.activa !== null && typeof row.activa !== 'boolean')
        || (areaId !== null && row.areaId !== areaId) || (data.sinArea && row.areaId !== null)) invalid();
    seen.add(row.areaId);
    validateTotals(row.totales);
    for (const key of Object.keys(sums)) sums[key] += row.totales[key];
  }
  if (Object.keys(sums).some((key) => sums[key] !== data.totales[key])) invalid();
  const catalogIds = new Set();
  for (const area of data.catalogoAreas) {
    if (!area || !id(area.id) || catalogIds.has(area.id) || !name(area.nombre) || typeof area.activa !== 'boolean') invalid();
    catalogIds.add(area.id);
  }
  if ((!data.puedeFiltrarPorArea && data.catalogoAreas.length) || (areaId !== null && !catalogIds.has(areaId))) invalid();
  let previous = null;
  let trendTotal = 0;
  for (const day of data.tendencias) {
    if (!day || !/^\d{4}-\d{2}-\d{2}$/.test(day.fecha) || !count(day.emitidas)) invalid();
    const timestamp = Date.parse(day.fecha + 'T00:00:00Z');
    if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== day.fecha
        || (previous !== null && timestamp - previous !== 86400000)) invalid();
    previous = timestamp;
    trendTotal += day.emitidas;
  }
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: data.zonaHoraria,
    year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date(data.consultadoEn));
  const part = (type) => today.find((item) => item.type === type)?.value;
  if (data.tendencias[6].fecha !== part('year') + '-' + part('month') + '-' + part('day')
      || trendTotal > data.totales.total) invalid();
  return data;
}
export async function getDashboardSummary(selection, signal) {
  const params = selection === 'unassigned' ? { sinArea: true } : selection === 'all' ? {} : { areaId: selection };
  const { data } = await api.get('/api/dashboard/summary', { params, signal, timeout: 20000 });
  return validateSummary(data, selection);
}
export async function getDashboardWork(_selection, signal) {
  const { data } = await api.get('/api/solicitudes/dashboard', { signal, timeout: 20000 });
  if (!data || !Array.isArray(data.accionesPendientes) || !Array.isArray(data.misSolicitudesPendientes)) invalid();
  const validId = (value) => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
  const actions = new Set();
  for (const row of data.accionesPendientes) {
    if (!row || !validId(row.solicitudId) || actions.has(row.solicitudId) || !name(row.titulo)
        || !['REVISION', 'CORRECCION'].includes(row.tipoAccion)) invalid();
    actions.add(row.solicitudId);
  }
  const own = new Set();
  for (const row of data.misSolicitudesPendientes) {
    if (!row || !validId(row.id) || own.has(row.id) || !name(row.titulo) || !name(row.estado)) invalid();
    own.add(row.id);
  }
  return data;
}
export function dashboardError(error) {
  const status = error.response?.status;
  if (status === 401 || status === 403) return { restricted: true, retryable: false, message: 'El acceso al panel ya no está disponible. Actualice los permisos o vuelva a iniciar sesión.' };
  if (status === 400) return { restricted: false, retryable: false, message: 'El área seleccionada ya no está disponible. Seleccione todas las áreas o actualice el panel.' };
  if (error.code === 'DASHBOARD_CONTRACT') return { restricted: false, retryable: true, message: 'No fue posible interpretar el resumen. Intente actualizar nuevamente.' };
  return { restricted: false, retryable: !status || status >= 500 || status === 429,
    message: 'No fue posible actualizar el panel. Intente nuevamente.' };
}
