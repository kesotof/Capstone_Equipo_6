import React, { forwardRef, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { LoaderCircle, LogOut, X } from 'lucide-react';
import { NAV_SECTIONS } from './navigation';

function SidebarLink({ item, onNavigate }) {
  const { to, icon: Icon, label, upcoming } = item;
  return (
    <NavLink to={to} onClick={onNavigate} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`} data-label={label}>
      <Icon size={18} aria-hidden="true" />
      <span className="nav-link-label">{label}</span>
      {upcoming && <span className="nav-link-tag">Pronto</span>}
    </NavLink>
  );
}

/**
 * Navegación lateral. Tres presentaciones según el ancho:
 * completa (≥ 1280 px), riel de iconos (768–1279 px o contraída por el usuario) y panel modal (< 768 px).
 */
const Sidebar = forwardRef(function Sidebar(
  { can, rail, overlay, open, user, roleLabel, onNavigate, onClose, closeButtonRef, onLogout, loggingOut },
  ref
) {
  const [tooltip, setTooltip] = useState(null);
  const sections = NAV_SECTIONS
    .map((section) => ({ ...section, items: section.items.filter((item) => !item.permission || can(item.permission)) }))
    .filter((section) => section.items.length > 0);

  // En modo riel las etiquetas quedan ocultas; un tooltip fijo las muestra al pasar el puntero o enfocar.
  const showTooltip = (event) => {
    if (!rail) return;
    const link = event.target.closest?.('.nav-link');
    if (!link) return;
    const rect = link.getBoundingClientRect();
    setTooltip({ label: link.dataset.label, top: rect.top + rect.height / 2, left: rect.right + 10 });
  };
  const hideTooltip = () => setTooltip(null);

  const className = ['sidebar', rail && 'sidebar--rail', overlay && 'sidebar--overlay', open && 'sidebar-open']
    .filter(Boolean).join(' ');

  return (
    <aside ref={ref} id="main-sidebar" className={className} aria-label="Menú lateral">
      <div className="brand">
        <div className="brand-identity">
          <h1>
            <img className="brand-wordmark" src="/masterbase-wordmark.png" alt="" width="132" height="18" />
            <span className="visually-hidden">MasterBase</span>
          </h1>
          <span className="brand-caption">Gestión documental</span>
        </div>
        <span className="brand-monogram" aria-hidden="true">M<span>B</span></span>
        {overlay && (
          <button ref={closeButtonRef} className="sidebar-close-btn" type="button" onClick={onClose} aria-label="Cerrar menú">
            <X size={20} aria-hidden="true" />
          </button>
        )}
      </div>

      <nav
        className="nav-menu"
        aria-label="Navegación principal"
        onMouseOver={showTooltip}
        onMouseLeave={hideTooltip}
        onFocus={showTooltip}
        onBlur={hideTooltip}
        onScroll={hideTooltip}
      >
        {sections.map((section) => (
          <div className="nav-section" key={section.title}>
            <h3>{section.title}</h3>
            {section.items.map((item) => <SidebarLink key={item.to} item={item} onNavigate={onNavigate} />)}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-user">
          <div className="sidebar-user-info">
            <strong title={user.name}>{user.name}</strong>
            <span title={user.email}>{roleLabel}</span>
          </div>
          <button className="logout-btn" type="button" onClick={onLogout} disabled={loggingOut} aria-label="Cerrar sesión" title="Cerrar sesión">
            {loggingOut ? <LoaderCircle className="button-spinner" size={18} aria-hidden="true" /> : <LogOut size={18} aria-hidden="true" />}
          </button>
        </div>
      </div>

      {rail && tooltip && (
        <div className="rail-tooltip" style={{ top: tooltip.top, left: tooltip.left }} aria-hidden="true">{tooltip.label}</div>
      )}
    </aside>
  );
});

export default Sidebar;
