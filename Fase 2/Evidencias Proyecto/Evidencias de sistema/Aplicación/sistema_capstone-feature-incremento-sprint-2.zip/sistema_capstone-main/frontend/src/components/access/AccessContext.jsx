import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Lock } from 'lucide-react';
import api from '../../services/api';
import { logout } from '../../services/keycloak';
import { AppLoadingScreen, Button, EmptyState } from '../ui';

const AccessContext = createContext(null);
export const useAccess = () => useContext(AccessContext);

export function AccessProvider({ children }) {
  const { pathname } = useLocation();
  const [context, setContext] = useState(null);
  const [error, setError] = useState('');
  const [revision, setRevision] = useState(0);
  const pending = useRef(null);
  const fingerprint = useRef('');
  const notifyRefresh = useRef(false);
  const queuedRefresh = useRef(false);
  const alive = useRef(true);
  const refresh = useCallback((options = {}) => {
    if (options.notify) notifyRefresh.current = true;
    if (pending.current) {
      if (options.force) queuedRefresh.current = true;
      return pending.current;
    }
    pending.current = api.get('/api/rbac/me', { accessRefresh: true })
      .then(({ data }) => {
        if (alive.current) {
          const nextFingerprint = JSON.stringify(data);
          setContext(data); setError('');
          if (nextFingerprint !== fingerprint.current || notifyRefresh.current) setRevision((v) => v + 1);
          fingerprint.current = nextFingerprint;
        }
        return data;
      })
      .catch((requestError) => {
        if (alive.current) {
          setContext(null);
          setError(requestError.response?.data?.detail || 'No fue posible cargar los permisos de la cuenta.');
        }
        return null;
      }).finally(() => {
        pending.current = null; notifyRefresh.current = false;
        if (queuedRefresh.current && alive.current) { queuedRefresh.current = false; refresh({ notify: true }); }
      });
    return pending.current;
  }, []);
  useEffect(() => { refresh({ notify: true }); }, [pathname, refresh]);
  useEffect(() => {
    alive.current = true;
    const focus = () => refresh({ notify: true });
    const invalidated = () => refresh();
    const changed = () => refresh({ notify: true, force: true });
    window.addEventListener('focus', focus);
    window.addEventListener('rbac:changed', changed);
    window.addEventListener('rbac:denied', invalidated);
    return () => {
      alive.current = false;
      window.removeEventListener('focus', focus);
      window.removeEventListener('rbac:changed', changed);
      window.removeEventListener('rbac:denied', invalidated);
    };
  }, [refresh]);
  const can = (permission) => {
    const grant = context?.permisos?.find((item) => item.codigo === permission);
    if (!grant?.alcances?.length) return false;
    if (permission === 'FLUJO_GESTIONAR') return context.administradorGlobal || context.areasAdministradas.length > 0;
    return true;
  };
  const roleLabel = context?.roles?.map((role) => role.nombre).join(' · ') || 'Sin roles funcionales';
  return <AccessContext.Provider value={{ context, can, refresh, revision, roleLabel }}>
    {context ? children : error ? <section className="access-error-page"><EmptyState tone="error" role="alert" title="No fue posible cargar tu acceso" action={<><Button variant="secondary" onClick={refresh}>Volver a cargar el acceso</Button><Button variant="quiet" onClick={logout}>Cerrar sesión</Button></>}>{error}</EmptyState></section> : <AppLoadingScreen />}
  </AccessContext.Provider>;
}

export function AccessGate({ permission, children }) {
  const { can } = useAccess();
  return can(permission) ? children : <EmptyState icon={Lock} className="access-denied" title="Acceso no disponible" action={<Button as={Link} to="/dashboard" variant="secondary">Volver al dashboard</Button>}>La cuenta no tiene permisos para esta sección. Solicite la revisión de su acceso a la administración.</EmptyState>;
}
