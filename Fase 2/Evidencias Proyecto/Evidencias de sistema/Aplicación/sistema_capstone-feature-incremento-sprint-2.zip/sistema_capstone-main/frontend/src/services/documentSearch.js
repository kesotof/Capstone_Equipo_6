import api from './api';

export const DOCUMENT_PAGE_SIZE = 10;
export const DOCUMENT_STATUSES = ['PENDIENTE_REVISION', 'CORRECCION_REQUERIDA', 'APROBADO', 'RECHAZADO'];
export const DOCUMENT_SORT_OPTIONS = [
  { value: 'createdAt,desc', label: 'Emisión: más recientes' },
  { value: 'createdAt,asc', label: 'Emisión: más antiguos' },
  { value: 'updatedAt,desc', label: 'Última actualización' },
  { value: 'titulo,asc', label: 'Título: A a Z' },
  { value: 'titulo,desc', label: 'Título: Z a A' },
  { value: 'correlativo,asc', label: 'Correlativo: ascendente' },
  { value: 'correlativo,desc', label: 'Correlativo: descendente' }
];
export const EMPTY_DOCUMENT_FILTERS = { query: '', documentType: '', status: '', areaId: '', dateFrom: '', dateTo: '' };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function documentFilters(values) {
  return Object.fromEntries(Object.keys(EMPTY_DOCUMENT_FILTERS).map((key) => [key,
    typeof values?.[key] === 'string' ? values[key].trim() : '']));
}

function validDate(value) {
  if (!value) return true;
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value) || value.startsWith('0000-')) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function documentFilterErrors(filters) {
  const errors = {};
  if (filters.query.length > 200 || /[\u0000-\u001f\u007f-\u009f]/.test(filters.query)) {
    errors.query = 'Usa hasta 200 caracteres y evita caracteres de control.';
  }
  if (filters.documentType && !/^[A-Z0-9][A-Z0-9_-]{0,35}$/.test(filters.documentType)) errors.documentType = 'Selecciona un formato válido.';
  if (filters.status && !DOCUMENT_STATUSES.includes(filters.status)) errors.status = 'Selecciona un estado válido.';
  if (filters.areaId && (!/^[0-9]{1,19}$/.test(filters.areaId) || BigInt(filters.areaId) < 1n || BigInt(filters.areaId) > 9223372036854775807n)) {
    errors.areaId = 'Selecciona un área válida.';
  }
  if (!validDate(filters.dateFrom)) errors.dateFrom = 'Selecciona una fecha válida.';
  if (!validDate(filters.dateTo)) errors.dateTo = 'Selecciona una fecha válida.';
  if (!errors.dateFrom && !errors.dateTo && filters.dateFrom && filters.dateTo && filters.dateFrom > filters.dateTo) {
    errors.dateTo = 'La fecha final debe ser igual o posterior a la fecha inicial.';
  }
  return errors;
}

export function restoreDocumentSearch(snapshot, userId) {
  if (snapshot?.userId !== userId) return { filters: { ...EMPTY_DOCUMENT_FILTERS }, draft: { ...EMPTY_DOCUMENT_FILTERS }, page: 0, sort: DOCUMENT_SORT_OPTIONS[0].value, filtersOpen: false };
  const filters = documentFilters(snapshot.filters);
  const valid = !Object.keys(documentFilterErrors(filters)).length;
  return {
    filters: valid ? filters : { ...EMPTY_DOCUMENT_FILTERS },
    draft: documentFilters(snapshot.draft || (valid ? filters : EMPTY_DOCUMENT_FILTERS)),
    page: valid && Number.isInteger(snapshot.page) && snapshot.page >= 0 && snapshot.page <= Math.floor(2147483647 / DOCUMENT_PAGE_SIZE) ? snapshot.page : 0,
    sort: DOCUMENT_SORT_OPTIONS.some((option) => option.value === snapshot.sort) ? snapshot.sort : DOCUMENT_SORT_OPTIONS[0].value,
    filtersOpen: Boolean(snapshot.filtersOpen)
  };
}

export function documentSearchParams(filters, page, sort) {
  return { ...Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== '')), page, size: DOCUMENT_PAGE_SIZE, sort };
}

const validArea = (area) => area === null || (Number.isSafeInteger(area?.id) && area.id > 0
  && (area.nombre === null || typeof area.nombre === 'string') && (area.activa === null || typeof area.activa === 'boolean'));

export async function searchDocuments(params, signal) {
  const { data } = await api.get('/api/documents/search', { params, signal });
  if (!Array.isArray(data?.contenido) || data.pagina !== params.page || data.tamanio !== DOCUMENT_PAGE_SIZE
      || !Number.isSafeInteger(data.totalElementos) || data.totalElementos < 0
      || data.totalPaginas !== Math.ceil(data.totalElementos / DOCUMENT_PAGE_SIZE)
      || typeof data.primera !== 'boolean' || typeof data.ultima !== 'boolean'
      || data.contenido.length > DOCUMENT_PAGE_SIZE
      || data.contenido.some((document) => !UUID.test(document.id) || !UUID.test(document.solicitudId)
        || typeof document.titulo !== 'string' || typeof document.nombreArchivo !== 'string'
        || typeof document.documentType !== 'string' || !DOCUMENT_STATUSES.includes(document.estado)
        || !Number.isInteger(document.version) || document.version < 1
        || !validArea(document.areaOrigen) || !validArea(document.areaFlujo)
        || (document.descargaUrl != null && document.descargaUrl !== '/api/documents/' + document.id + '/download')
        || document.detalleUrl !== `/api/requests/${document.solicitudId}/detail`)) {
    throw new Error('Respuesta de búsqueda no disponible.');
  }
  return data;
}

export async function documentSearchCatalog(signal) {
  const { data } = await api.get('/api/documents/search/filters', { signal });
  if (!Array.isArray(data?.documentTypes) || !Array.isArray(data.areas) || !Array.isArray(data.statuses)
      || data.documentTypes.some((type) => typeof type !== 'string' || !/^[A-Z0-9][A-Z0-9_-]{0,35}$/.test(type))
      || data.areas.some((area) => !area || !validArea(area))
      || data.statuses.some((status) => !DOCUMENT_STATUSES.includes(status))) {
    throw new Error('Catálogo de búsqueda no disponible.');
  }
  return data;
}

export function documentSearchError(error, catalog = false) {
  const status = error.response?.status;
  if (status === 401) return { message: 'La sesión ya no está disponible. Vuelve a iniciar sesión.', restricted: true };
  if (status === 403) return { message: 'El acceso a la consulta documental ya no está disponible. Solicita la revisión de tus permisos.', restricted: true };
  if (status === 400) return { message: 'Revisa los filtros, el rango de fechas y el orden seleccionado.', restricted: false };
  if (status === 409) return { message: 'La información documental requiere revisión. Contacta a la administración.', restricted: false };
  return { message: catalog ? 'No fue posible cargar las opciones de filtros. Puedes volver a intentarlo.' : 'No fue posible consultar los documentos. Intenta nuevamente.', restricted: false };
}
