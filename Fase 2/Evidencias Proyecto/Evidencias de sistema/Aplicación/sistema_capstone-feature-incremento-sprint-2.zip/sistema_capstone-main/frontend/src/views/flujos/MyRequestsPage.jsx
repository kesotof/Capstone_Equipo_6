import React, { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Activity, ChevronLeft, ChevronRight, FileEdit, FilePlus2, FilterX, RefreshCw, Search, SearchX, ShieldAlert } from 'lucide-react';
import { useAccess } from '../../components/access/AccessContext';
import { Button, Card, DataTable, DateTimeStack, DropdownSelect, EmptyState, FeedbackMessage, FormField, PageHeader, StatusBadge, getStatusLabel } from '../../components/ui';
import RequestDetailLink from '../../components/requests/RequestDetailLink';
import useMyRequests from '../../hooks/useMyRequests';
import { EMPTY_REQUEST_FILTERS, REQUEST_PAGE_SIZE, REQUEST_STATUSES, isRequestId, requestFilterErrors, requestFilters, restoreMyRequests } from '../../services/myRequests';
import { requestAreaLabel } from '../../services/requestDetails';
import './MyRequestsPage.css';

const TRAYS = [{ value: 'propias', label: 'Mis solicitudes' }, { value: 'autorizadas', label: 'Según mi acceso' }];
const STATES = [{ value: '', label: 'Todos los estados' }, ...REQUEST_STATUSES.map((status) => ({ value: status, label: getStatusLabel(status) }))];
const consultationTime = new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Santiago' });

function RequestStage({ request }) {
  const terminal = ['APROBADO', 'RECHAZADO'].includes(request.estado);
  return <div className="cell-stack my-requests-stage">
    {terminal && <strong>Finalizada</strong>}
    <span>{request.etapaActual ? `${terminal ? 'Última etapa' : 'Etapa'} ${request.etapaActual.orden} · ${request.etapaActual.nombre}` : terminal ? 'Última etapa no disponible' : 'Etapa no disponible'}</span>
    {request.estado === 'CORRECCION_REQUERIDA' && <span>Requiere corrección</span>}
  </div>;
}

export default function MyRequestsPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { context, can } = useAccess();
  const restored = useRef(restoreMyRequests(location.state?.requestDetailReturn, context.usuarioId)).current;
  const [tray, setTray] = useState(restored.tray);
  const [filters, setFilters] = useState(restored.filters);
  const [draft, setDraft] = useState(restored.draft);
  const [page, setPage] = useState(restored.page);
  const [validation, setValidation] = useState({});
  const searchRef = useRef(null);
  const pageAdjustment = useRef(false);
  const { data, loading, refreshing, stale, error, restricted, areas, areasError, areasLoading, announcement, refresh, refreshAreas } = useMyRequests(tray, filters, page);
  const lastPage = data ? Math.max(0, data.totalPaginas - 1) : page;
  const outOfRange = Boolean(data && page > lastPage);
  const pageUnavailable = outOfRange && pageAdjustment.current;
  const correctingPage = outOfRange && !pageUnavailable;
  const viewState = { userId: context.usuarioId, tray, filters, draft, page };
  const origin = { pathname: '/estado-solicitudes', search: '', state: { requestDetailReturn: viewState } };
  const queryParams = new URLSearchParams(location.search);
  const linkIds = queryParams.getAll('id');
  const linkId = linkIds.length === 1 && isRequestId(linkIds[0]) ? linkIds[0] : null;
  const invalidLink = linkIds.length > 0 && !linkId;

  useEffect(() => {
    if (linkId) navigate(`/solicitudes/${linkId}`, { replace: true, state: { requestOrigin: origin } });
    // El origen elimina id; regresar nunca vuelve a disparar este enlace.
  }, [linkId, navigate]);

  useEffect(() => {
    if (!outOfRange) { if (data) pageAdjustment.current = false; return; }
    if (!pageAdjustment.current) {
      pageAdjustment.current = true;
      setPage(lastPage);
    }
  }, [outOfRange, lastPage, data]);

  const apply = (next) => {
    const normalized = requestFilters(next, tray);
    const errors = requestFilterErrors(normalized);
    setValidation(errors);
    if (Object.keys(errors).length || restricted) { if (errors.query) searchRef.current?.focus(); return; }
    pageAdjustment.current = false;
    setFilters(normalized);
    setPage(0);
  };
  const submit = (event) => {
    event.preventDefault();
    const next = requestFilters({ ...filters, query: draft }, tray);
    const errors = requestFilterErrors(next);
    setValidation(errors);
    if (Object.keys(errors).length || restricted) { searchRef.current?.focus(); return; }
    setDraft(next.query);
    apply(next);
    if (page === 0 && JSON.stringify(next) === JSON.stringify(filters)) refresh();
  };
  const clear = () => {
    setDraft('');
    setValidation({});
    apply({ ...EMPTY_REQUEST_FILTERS });
    if (page === 0 && !Object.values(filters).some(Boolean)) refresh();
    searchRef.current?.focus();
  };
  const selectTray = (value) => {
    pageAdjustment.current = false;
    setTray(value);
    setFilters((current) => ({ ...current, areaId: '' }));
    setPage(0);
    setValidation({});
  };
  const update = () => { pageAdjustment.current = false; refresh(); };
  const total = data?.totalElementos;
  const hasFilters = Object.values(filters).some(Boolean);
  const pendingDraft = draft.trim() !== filters.query;
  const areaOptions = [{ value: '', label: 'Todas las áreas disponibles' }, ...(areas || []).map((area) => ({ value: String(area.id), label: area.nombre }))];
  const selectedArea = areas?.find((area) => String(area.id) === filters.areaId);
  if (filters.areaId && !selectedArea) areaOptions.push({ value: filters.areaId, label: 'Área seleccionada no disponible', disabled: true });
  const applied = [filters.query && `Búsqueda: ${filters.query}`, filters.status && getStatusLabel(filters.status), filters.areaId && `Área: ${selectedArea?.nombre || 'selección actual'}`].filter(Boolean);
  const busy = loading || refreshing || correctingPage;
  const markOrigin = (event) => {
    if (event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {
      navigate(`${origin.pathname}${origin.search}`, { replace: true, state: origin.state });
    }
  };

  return <section className="list-page my-requests-page" aria-labelledby="my-requests-title">
    <PageHeader eyebrow="Flujos de aprobación" title="Estado de solicitudes" titleId="my-requests-title" icon={Activity}
      description="Consulta el estado, la etapa y las acciones disponibles de tus solicitudes."
      actions={<Button variant="secondary" onClick={update} loading={refreshing} disabled={refreshing}><RefreshCw size={17} aria-hidden="true" />Actualizar</Button>} />
    {invalidLink && <FeedbackMessage tone="error" className="page-message" title="El enlace de la solicitud no es válido">Selecciona una solicitud de la tabla para consultar su detalle.</FeedbackMessage>}

    <Card className="my-requests-filters" aria-label="Bandeja y filtros de solicitudes">
      <div className={`my-requests-filter-grid${tray === 'autorizadas' ? ' my-requests-filter-grid--areas' : ''}`}>
        <FormField label="Bandeja" htmlFor="requests-tray"><DropdownSelect id="requests-tray" value={tray} options={TRAYS} onChange={selectTray} disabled={restricted} /></FormField>
        <FormField label="Estado" htmlFor="requests-status" error={validation.status}><DropdownSelect id="requests-status" value={filters.status} options={STATES} onChange={(value) => apply({ ...filters, status: value })} disabled={restricted} /></FormField>
        {tray === 'autorizadas' && <FormField label="Área" htmlFor="requests-area" error={validation.areaId}>
          <DropdownSelect id="requests-area" value={filters.areaId} options={areaOptions} onChange={(value) => apply({ ...filters, areaId: value })} disabled={restricted || !areas} />
        </FormField>}
      </div>
      {areasLoading && <p className="my-requests-hint" role="status">Cargando áreas disponibles…</p>}
      {areasError && !restricted && <FeedbackMessage tone="error" className="my-requests-catalog-error">{areasError.message}<Button variant="quiet" onClick={refreshAreas}>Volver a cargar áreas</Button></FeedbackMessage>}
      <form className="my-requests-search" onSubmit={submit} noValidate>
        <FormField label="Buscar por correlativo o título" htmlFor="requests-query" error={validation.query} className="my-requests-query">
          <div className="search-field"><Search size={18} aria-hidden="true" /><input ref={searchRef} id="requests-query" type="search" maxLength={200} value={draft}
            placeholder="Ejemplo: CONT-001 o contrato" disabled={restricted} onChange={(event) => { setDraft(event.target.value); setValidation({}); }} aria-invalid={Boolean(validation.query)} aria-describedby="requests-query-hint" /></div>
        </FormField>
        <div className="my-requests-search-actions">
          <Button type="submit" disabled={restricted}><Search size={17} aria-hidden="true" />Buscar</Button>
          <Button variant="quiet" onClick={clear} disabled={restricted || (!hasFilters && !draft)}><FilterX size={17} aria-hidden="true" />Limpiar filtros</Button>
        </div>
      </form>
      <p id="requests-query-hint" className="my-requests-hint">El texto se aplica al seleccionar Buscar o presionar Enter.</p>
      {pendingDraft && <p className="my-requests-hint" role="status">Hay cambios en el texto de búsqueda pendientes de aplicar.</p>}
    </Card>

    <Card className="my-requests-results" aria-labelledby="requests-results-title" aria-busy={busy}>
      <header className="card-header my-requests-results-header">
        <div><h3 id="requests-results-title">{tray === 'propias' ? 'Mis solicitudes' : 'Según mi acceso'}</h3>
          <p>{restricted ? 'Acceso no disponible' : !data ? loading ? 'Consultando solicitudes…' : 'Consulta no disponible' : `${total} ${total === 1 ? 'solicitud disponible' : 'solicitudes disponibles'}`}</p>
        </div>
        <div className="my-requests-consultation"><span>Últimas actualizaciones primero</span>
          {data && <span>Última consulta: <time dateTime={data.consultadoEn}>{consultationTime.format(new Date(data.consultadoEn))}</time></span>}
          <span>{refreshing ? 'Actualizando…' : stale ? 'La información no está actualizada' : 'Actualización automática mientras esta vista esté visible'}</span>
        </div>
      </header>
      <div className="visually-hidden" role="status" aria-live="polite" aria-atomic="true">{announcement}</div>
      {!restricted && applied.length > 0 && <ul className="my-requests-applied" aria-label="Filtros aplicados">{applied.map((label) => <li key={label}>{label}</li>)}</ul>}
      {stale && !restricted && <FeedbackMessage tone="error" className="my-requests-stale" title="La información no pudo actualizarse">{error.message} La tabla muestra la última consulta y la corrección está deshabilitada.<Button variant="quiet" onClick={update} disabled={refreshing}>Reintentar</Button></FeedbackMessage>}
      {restricted ? <EmptyState icon={ShieldAlert} title="Acceso no disponible" action={<Button variant="secondary" onClick={update} disabled={refreshing}>Actualizar acceso</Button>}>{error?.message || 'La consulta no está disponible con los permisos actuales.'}</EmptyState>
        : loading || correctingPage ? <EmptyState loading title="Consultando solicitudes…" role="status" />
          : pageUnavailable ? <EmptyState icon={SearchX} title="La consulta cambió de página" action={<Button variant="secondary" onClick={() => { pageAdjustment.current = false; setPage(0); }}>Volver a la primera página</Button>}>Actualiza la consulta desde la primera página para ver los resultados vigentes.</EmptyState>
            : error && !data ? <EmptyState icon={SearchX} title="No fue posible consultar las solicitudes" action={<Button variant="secondary" onClick={update}>Volver a intentar</Button>}>{error.message}</EmptyState>
              : !data?.contenido.length ? <EmptyState icon={SearchX} title={hasFilters ? 'No se encontraron solicitudes' : tray === 'propias' ? 'Aún no tienes solicitudes' : 'No hay solicitudes disponibles con tu acceso actual'}
                action={hasFilters ? <Button variant="secondary" onClick={clear}>Limpiar filtros</Button> : tray === 'propias' && can('SOLICITUD_CREAR') ? <Button as={Link} to="/nuevo-documento"><FilePlus2 size={17} aria-hidden="true" />Registrar documento</Button> : null}>
                {hasFilters ? 'Ninguna solicitud disponible coincide con los filtros aplicados.' : tray === 'propias' ? 'Las solicitudes que envíes aparecerán aquí para consultar su seguimiento.' : 'Aquí aparecen las solicitudes que puedes consultar según tus permisos.'}
              </EmptyState>
                : <div className="table-scroll"><DataTable className="table-stackable my-requests-table">
                  <caption className="visually-hidden">Solicitudes ordenadas por última actualización. Ver detalle permite consultar la información y el historial autorizado.</caption>
                  <thead><tr><th scope="col">Solicitud</th>{tray === 'autorizadas' && <th scope="col">Emisor</th>}<th scope="col">Etapa</th><th scope="col">Estado</th><th scope="col">Emitida</th><th scope="col">Actualizada</th><th scope="col"><span className="visually-hidden">Acciones</span></th></tr></thead>
                  <tbody>{data.contenido.map((request) => <tr key={request.id}>
                    <td data-label="Solicitud" className="cell-primary"><div className="cell-stack">
                      <span className={`correlative-tag${request.correlativo ? '' : ' correlative-tag--empty'}`}>{request.correlativo || 'Sin correlativo'}</span>
                      <strong>{request.titulo}</strong><span>Origen: {requestAreaLabel(request.areaOrigen)}</span><span>Flujo: {requestAreaLabel(request.areaFlujo, true)}</span>
                    </div></td>
                    {tray === 'autorizadas' && <td data-label="Emisor"><div className="cell-stack"><span>{request.emisorNombre}</span>{request.propia && <span>Solicitud propia</span>}</div></td>}
                    <td data-label="Etapa"><RequestStage request={request} /></td>
                    <td data-label="Estado"><StatusBadge status={request.estado} /></td>
                    <td data-label="Emitida"><DateTimeStack value={request.createdAt} timeZone="America/Santiago" /></td>
                    <td data-label="Actualizada"><DateTimeStack value={request.updatedAt} timeZone="America/Santiago" /></td>
                    <td data-label="Acciones" className="cell-actions"><div className="my-requests-row-actions">
                      <RequestDetailLink id={request.id} viewState={viewState} className="ui-button--compact" aria-label={`Ver detalle de ${request.correlativo || request.titulo}`}>Ver detalle</RequestDetailLink>
                      {can('SOLICITUD_REENVIAR') && request.accionesPermitidas.includes('REENVIAR') && <Button as={Link} to={`/corregir-documento?id=${request.id}`} state={{ requestOrigin: origin }}
                        onClick={markOrigin} disabled={stale || refreshing} variant="warning" className="ui-button--compact" aria-label={`Corregir ${request.correlativo || request.titulo}`}><FileEdit size={16} aria-hidden="true" />Corregir</Button>}
                    </div></td>
                  </tr>)}</tbody>
                </DataTable></div>}
      {data && !restricted && !pageUnavailable && !correctingPage && <footer className="my-requests-pagination">
        <p>{total ? `Mostrando ${page * REQUEST_PAGE_SIZE + 1}–${Math.min(page * REQUEST_PAGE_SIZE + data.contenido.length, total)} de ${total} solicitudes` : '0 solicitudes'}</p>
        <nav aria-label="Paginación de solicitudes">
          <Button variant="secondary" onClick={() => setPage((current) => Math.max(0, current - 1))} disabled={busy || data.primera}><ChevronLeft size={16} aria-hidden="true" />Anterior</Button>
          <span>{data.totalPaginas ? `Página ${page + 1} de ${data.totalPaginas}` : 'Sin páginas'}</span>
          <Button variant="secondary" onClick={() => setPage((current) => current + 1)} disabled={busy || data.ultima || page >= lastPage}>Siguiente<ChevronRight size={16} aria-hidden="true" /></Button>
        </nav>
      </footer>}
    </Card>
  </section>;
}
