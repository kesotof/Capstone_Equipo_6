import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Button } from '../ui';

/** Pantalla común para secciones aún no disponibles o que se gestionan fuera de la aplicación. */
export default function ComingSoon({ badge = 'En construcción', title, description, features = [], action }) {
  return (
    <section className="view-container coming-soon" aria-labelledby="coming-soon-title">
      <div className="coming-soon-card">
        <img className="coming-soon-illustration" src="/masterbase-automata.png" alt="" width="168" height="168" />
        <div className="coming-soon-content">
          <span className="coming-soon-badge">{badge}</span>
          <h2 id="coming-soon-title">{title}</h2>
          <p>{description}</p>
          {features.length > 0 && (
            <ul className="coming-soon-features" aria-label="Qué incluirá">
              {features.map((feature) => (
                <li key={feature}><CheckCircle2 size={16} aria-hidden="true" /><span>{feature}</span></li>
              ))}
            </ul>
          )}
          <div className="coming-soon-actions">
            {action}
            <Button as={Link} to="/dashboard" variant="secondary">
              <ArrowLeft size={16} aria-hidden="true" />
              <span>Volver al dashboard</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
