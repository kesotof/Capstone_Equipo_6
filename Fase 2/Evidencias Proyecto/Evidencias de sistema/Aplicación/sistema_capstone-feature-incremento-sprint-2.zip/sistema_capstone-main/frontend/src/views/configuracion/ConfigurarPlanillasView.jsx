import React from 'react';
import ComingSoon from '../../components/shell/ComingSoon';

export default function ConfigurarPlanillasView() {
  return (
    <ComingSoon
      title="Configurar planillas"
      description="Aquí se administrarán las plantillas dinámicas y formularios para la emisión estandarizada de documentos."
      features={[
        'Diseño de campos y secciones de cada plantilla',
        'Asociación de plantillas a flujos de aprobación',
        'Control de versiones y publicación de plantillas'
      ]}
    />
  );
}
