import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Edit2, LoaderCircle, LockKeyhole, Mail, Power, PowerOff, RefreshCw, Search, SearchX, ShieldAlert, ShieldCheck, Trash2, UserCheck, UserPlus, Users, X } from 'lucide-react';
import api from '../../services/api';
import { Button, Card, DataTable, EmptyState, FeedbackMessage, FormField, DropdownSelect, MOBILE_QUERY, MoreActions, PageHeader, StatusBadge, useMediaQuery } from '../../components/ui';

import { loadAssignableRoles } from '../../services/rbac';
import { loadAreaCatalog } from '../../services/areas';
import { useAccess } from '../../components/access/AccessContext';
import RoleManagement from './RoleManagement';
import UserAccessDialog from './UserAccessDialog';

const INITIAL_FORM = {
  email: '',
  rut: '',
  firstName: '',
  lastName: '',
  password: '',
  confirmPassword: '',
  roleIds: [],
  areaId: '',
  requirePasswordChange: true
};

const MANAGEMENT_TABS = [
  { id: 'usuarios', label: 'Usuarios', icon: Users },
  { id: 'roles', label: 'Roles y permisos', icon: ShieldCheck }
];

function formatDots(digits) {
  if (!digits) return '';
  let formatted = '';
  let count = 0;
  for (let i = digits.length - 1; i >= 0; i--) {
    formatted = digits[i] + formatted;
    count++;
    if (count === 3 && i > 0) {
      formatted = '.' + formatted;
      count = 0;
    }
  }
  return formatted;
}

function formatRutInput(raw) {
  if (!raw) return '';
  const clean = raw.replace(/[^0-9kK-]/g, '').toUpperCase();
  if (clean.length === 0) return '';

  let cuerpo = '';
  let dv = '';

  if (clean.includes('-')) {
    const parts = clean.split('-');
    cuerpo = parts[0].replace(/[^0-9]/g, '').slice(0, 8);
    dv = parts[1] ? parts[1].replace(/[^0-9K]/g, '').slice(0, 1) : '';
    const formattedCuerpo = formatDots(cuerpo);
    return dv ? `${formattedCuerpo}-${dv}` : (cuerpo ? `${formattedCuerpo}-` : '');
  }

  if (clean.includes('K')) {
    const withoutK = clean.replace(/K/g, '').slice(0, 8);
    return `${formatDots(withoutK)}-K`;
  }

  const digits = clean.replace(/[^0-9]/g, '');
  if (digits.length <= 8) {
    return formatDots(digits);
  }
  cuerpo = digits.slice(0, 8);
  dv = digits.slice(8, 9);
  return `${formatDots(cuerpo)}-${dv}`;
}

function validateRutAlgorithm(rutStr) {
  if (!rutStr) return false;
  const clean = rutStr.replace(/[^0-9kK]/g, '').toUpperCase();
  if (clean.length < 8 || clean.length > 9) return false;
  const cuerpo = clean.slice(0, -1);
  const dv = clean.slice(-1);
  let suma = 0;
  let multiplicador = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpo[i], 10) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }
  const resto = suma % 11;
  const esperadoNum = 11 - resto;
  let esperado = '';
  if (esperadoNum === 11) esperado = '0';
  else if (esperadoNum === 10) esperado = 'K';
  else esperado = String(esperadoNum);
  return dv === esperado;
}

function getErrorMessage(error) {
  const problem = error.response?.data;
  const fieldMessage = problem?.invalidFields ? Object.values(problem.invalidFields)[0] : null;
  return fieldMessage || problem?.detail || 'No fue posible completar la operación. Inténtalo nuevamente.';
}

export default function ConfigurarOrgUsuariosView() {
  const { refresh, revision } = useAccess();
  const isMobile = useMediaQuery(MOBILE_QUERY);
  const [activeTab, setActiveTab] = useState('usuarios');
  const tabRefs = useRef({});
  const [roles, setRoles] = useState([]);
  const [catalogReady, setCatalogReady] = useState(false);
  const [accessDialog, setAccessDialog] = useState(null);
  const [page, setPage] = useState(0);
  const loadRoles = useCallback(async () => {
    try { setRoles(await loadAssignableRoles()); setCatalogReady(true); }
    catch (err) { setCatalogReady(false); setError(getErrorMessage(err)); }
  }, []);
  const [form, setForm] = useState(INITIAL_FORM);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [togglingUserId, setTogglingUserId] = useState(null);
  const submittingRef = useRef(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  // Estados para Edición
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [editForm, setEditForm] = useState({
    firstName: '',
    lastName: '',
    newPassword: '',
    confirmPassword: '',
    requirePasswordChange: false
  });

  // Estados para Eliminación
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');
  const [areas, setAreas] = useState([]);

  const loadAreas = useCallback(async () => {
    try {
      setAreas((await loadAreaCatalog()).filter((area) => area.activo));
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }, []);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/api/users');
      setUsers(response.data);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUsers();
    loadAreas();
    loadRoles();
  }, [loadUsers, loadAreas, loadRoles, revision]);

  const updateField = (event) => {
    const { name, value, checked, type } = event.target;
    if (name === 'rut') {
      const formatted = formatRutInput(value);
      setForm((current) => ({ ...current, rut: formatted }));
      return;
    }
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const updateEditField = (event) => {
    const { name, value, checked, type } = event.target;
    setEditForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const toggleRole = (role) => {
    setForm((current) => {
      const selected = current.roleIds.includes(role);
      return {
        ...current,
        roleIds: selected
          ? current.roleIds.filter((currentRole) => currentRole !== role)
          : [...current.roleIds, role]
      };
    });
  };

  // 1. Crear usuario
  const createUser = async (event) => {
    event.preventDefault();
    if (submittingRef.current) return;
    setError('');
    setSuccess('');

    if (!catalogReady || form.roleIds.some((id) => !roles.some((role) => role.id === id))) {
      setError('La selección de roles ya no está disponible. Actualice el catálogo y vuelva a seleccionar las responsabilidades.');
      return;
    }

    if (form.password.length < 8) {
      setError('La contraseña debe contener al menos 8 caracteres.');
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError('Las contraseñas no coinciden. Por favor confirma la contraseña exactamente.');
      return;
    }

    if (!form.rut || !form.rut.trim()) {
      setError('El RUT es obligatorio.');
      return;
    }

    if (!validateRutAlgorithm(form.rut)) {
      setError('Dígito verificador inválido. El RUT ingresado no es válido.');
      return;
    }

    submittingRef.current = true;
    setSubmitting(true);
    try {
      const { confirmPassword, ...createPayload } = form;
      const payload = {
        ...createPayload,
        areaId: createPayload.areaId ? Number(createPayload.areaId) : null
      };
      const response = await api.post('/api/users', payload);
      setUsers((current) => [...current, response.data].sort((a, b) => a.email.localeCompare(b.email)));
      setSuccess(`La cuenta ${response.data.email} fue creada exitosamente.`);
      setForm(INITIAL_FORM);
      setIsCreateOpen(false);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  // 2. Modificar usuario (Nombre, Apellido y Contraseña opcional)
  const openEdit = (user) => {
    setError('');
    setSuccess('');
    setEditingUser(user);
    setEditForm({
      firstName: user.firstName,
      lastName: user.lastName,
      areaId: user.areaId != null ? String(user.areaId) : '',
      newPassword: '',
      confirmPassword: '',
      requirePasswordChange: false
    });
    setIsEditOpen(true);
  };

  const closeEdit = () => {
    if (submitting) return;
    setIsEditOpen(false);
    setEditingUser(null);
  };

  const saveEdit = async (event) => {
    event.preventDefault();
    if (!editingUser || submittingRef.current) return;
    setError('');
    setSuccess('');

    if (editForm.newPassword) {
      if (editForm.newPassword.length < 8) {
        setError('La nueva contraseña debe contener al menos 8 caracteres.');
        return;
      }
      if (editForm.newPassword !== editForm.confirmPassword) {
        setError('Las nuevas contraseñas no coinciden. Por favor confirma la nueva contraseña.');
        return;
      }
    }

    submittingRef.current = true;
    setSubmitting(true);
    try {
      const payload = {
        firstName: editForm.firstName.trim(),
        lastName: editForm.lastName.trim(),
        areaId: editForm.areaId ? Number(editForm.areaId) : null,
        ...(editForm.newPassword ? {
          newPassword: editForm.newPassword.trim(),
          requirePasswordChange: editForm.requirePasswordChange
        } : {})
      };

      const response = await api.put(`/api/users/${editingUser.id}`, payload);
      setUsers((current) =>
        current.map((u) => (u.id === editingUser.id ? response.data : u))
      );
      setSuccess(`Datos actualizados correctamente para ${response.data.email}.`);
      setIsEditOpen(false);
      setEditingUser(null);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  // 3. Desactivar / Activar usuario
  const toggleUserStatus = async (user) => {
    if (togglingUserId) return;
    setError('');
    setSuccess('');
    setTogglingUserId(user.id);
    const newEnabledState = !user.enabled;

    try {
      const response = await api.patch(`/api/users/${user.id}/status`, {
        enabled: newEnabledState
      });
      setUsers((current) =>
        current.map((u) => (u.id === user.id ? response.data : u))
      );
      setSuccess(
        newEnabledState
          ? `La cuenta ${user.email} ha sido activada.`
          : `La cuenta ${user.email} ha sido desactivada.`
      );
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setTogglingUserId(null);
    }
  };

  // 4. Eliminar usuario
  const openDelete = (user) => {
    setError('');
    setSuccess('');
    setUserToDelete(user);
    setIsDeleteOpen(true);
  };

  const closeDelete = () => {
    if (submitting) return;
    setIsDeleteOpen(false);
    setUserToDelete(null);
  };

  const confirmDelete = async () => {
    if (!userToDelete || submittingRef.current) return;
    setError('');
    setSuccess('');
    submittingRef.current = true;
    setSubmitting(true);

    try {
      await api.delete(`/api/users/${userToDelete.id}`);
      setUsers((current) => current.filter((u) => u.id !== userToDelete.id));
      setSuccess(`La cuenta ${userToDelete.email} ha sido eliminada del sistema.`);
      setIsDeleteOpen(false);
      setUserToDelete(null);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  const openCreateUser = () => {
    setError('');
    setSuccess('');
    setIsCreateOpen(true);
  };

  const closeCreateUser = () => {
    if (submitting) return;
    setError('');
    setForm(INITIAL_FORM);
    setIsCreateOpen(false);
  };

  const normalizedSearch = search.trim().toLowerCase();
  const visibleUsers = normalizedSearch
    ? users.filter((user) => `${user.firstName} ${user.lastName} ${user.email}`.toLowerCase().includes(normalizedSearch))
    : users;
  const activeCount = users.filter((user) => user.enabled).length;
  const adminCount = users.filter((user) => user.rolesFuncionales?.some((role) => role.codigo === 'ADMIN')).length;
  const totalPages = Math.max(1, Math.ceil(visibleUsers.length / 10));
  const currentPage = Math.min(page, totalPages - 1);
  const pagedUsers = visibleUsers.slice(currentPage * 10, (currentPage + 1) * 10);

  const handleTabKeyDown = (event, tabId) => {
    const index = MANAGEMENT_TABS.findIndex((tab) => tab.id === tabId);
    let nextIndex;
    if (event.key === 'ArrowRight') nextIndex = (index + 1) % MANAGEMENT_TABS.length;
    else if (event.key === 'ArrowLeft') nextIndex = (index - 1 + MANAGEMENT_TABS.length) % MANAGEMENT_TABS.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = MANAGEMENT_TABS.length - 1;
    else return;

    event.preventDefault();
    const nextTab = MANAGEMENT_TABS[nextIndex].id;
    setActiveTab(nextTab);
    tabRefs.current[nextTab]?.focus();
  };

  return (
    <section className="list-page" aria-labelledby="users-title">
      <PageHeader
        eyebrow="Configuración"
        title="Organización y usuarios"
        titleId="users-title"
        description={activeTab === 'usuarios'
          ? 'Administra las cuentas institucionales, sus datos, áreas y responsabilidades.'
          : 'Administra los roles de la organización y define sus permisos y alcances en la plataforma.'}
        icon={activeTab === 'usuarios' ? Users : ShieldCheck}
        actions={activeTab === 'usuarios' && (
          <Button className="add-user-button" onClick={openCreateUser} disabled={!catalogReady}>
            <UserPlus size={18} aria-hidden="true" />
            Agregar usuario
          </Button>
        )}
      />

      <div className="dashboard-tabs org-access-tabs" role="tablist" aria-label="Administración de usuarios y roles">
        {MANAGEMENT_TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            ref={(element) => { tabRefs.current[id] = element; }}
            type="button"
            role="tab"
            id={`org-tab-${id}`}
            aria-controls={`org-panel-${id}`}
            aria-selected={activeTab === id}
            tabIndex={activeTab === id ? 0 : -1}
            className={`dashboard-tab-btn ${activeTab === id ? 'active' : ''}`}
            onClick={() => setActiveTab(id)}
            onKeyDown={(event) => handleTabKeyDown(event, id)}
          >
            <Icon size={18} aria-hidden="true" />
            {label}
          </button>
        ))}
      </div>

      <div id="org-panel-usuarios" role="tabpanel" aria-labelledby="org-tab-usuarios" hidden={activeTab !== 'usuarios'} tabIndex={0}>
      {success && <FeedbackMessage tone="success" className="page-message">{success}</FeedbackMessage>}
      {!isCreateOpen && !isEditOpen && !isDeleteOpen && error && (
        <FeedbackMessage tone="error" className="page-message">{error}</FeedbackMessage>
      )}

      <Card className="list-card user-list-card">
        <div className="card-header">
          <div>
            <h3>Usuarios registrados</h3>
            <p className="user-summary">
              <span><strong>{users.length}</strong> {users.length === 1 ? 'cuenta' : 'cuentas'}</span>
              <span><strong>{activeCount}</strong> {activeCount === 1 ? 'activa' : 'activas'}</span>
              <span><strong>{users.length - activeCount}</strong> {users.length - activeCount === 1 ? 'inactiva' : 'inactivas'}</span>
              <span><strong>{adminCount}</strong> {adminCount === 1 ? 'administrador' : 'administradores'}</span>
            </p>
          </div>
          <div className="table-header-actions">
            <label className="search-field search-field--compact">
              <Search size={16} aria-hidden="true" />
              <input
                type="search"
                value={search}
                onChange={(event) => { setSearch(event.target.value); setPage(0); }}
                placeholder="Buscar por nombre o correo"
                aria-label="Buscar usuarios"
              />
            </label>
            <button className="icon-button" type="button" onClick={loadUsers} aria-label="Actualizar usuarios" title="Actualizar" disabled={loading}>
              <RefreshCw size={17} aria-hidden="true" />
            </button>
          </div>
        </div>

        {loading ? (
          <EmptyState loading title="Cargando usuarios…" />
        ) : users.length === 0 ? (
          <EmptyState icon={Users} title="No hay cuentas sincronizadas" action={<Button onClick={openCreateUser}>
              <UserPlus size={17} aria-hidden="true" />
              Agregar usuario
            </Button>}>
            Agrega una cuenta para comenzar a administrar usuarios.
          </EmptyState>
        ) : visibleUsers.length === 0 ? (
          <EmptyState icon={SearchX} title="Sin resultados" action={<Button variant="secondary" onClick={() => setSearch('')}>Limpiar búsqueda</Button>}>
            Ninguna cuenta coincide con “{search.trim()}”.
          </EmptyState>
        ) : (
          <div className="table-scroll">
            <DataTable className="table-stackable users-table">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>Área</th>
                  <th>Roles</th>
                  <th>Jefatura directa</th>
                  <th>Estado</th>
                  <th className="table-actions-cell text-right">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {pagedUsers.map((user) => (
                  <tr key={user.id} data-user-email={user.email}>
                    <td className="cell-primary">
                      <div className="cell-stack cell-person">
                        <strong>{user.firstName} {user.lastName}</strong>
                        <span>{user.email}</span>
                        {user.rut && <span className="cell-subtext">RUT: {user.rut}</span>}
                      </div>
                    </td>
                    <td data-label="Área">
                      {user.areaNombre ? (
                        <strong>{user.areaNombre}</strong>
                      ) : (
                        <span className="cell-empty">Sin área asignada</span>
                      )}
                    </td>
                    <td data-label="Rol">
                      <div className="role-badges">
                        {(user.rolesFuncionales || []).map((role) => (<span key={role.id} title={role.origen === 'AREA' ? 'Derivado de la administración del área' : 'Asignación explícita'}>{role.nombre}</span>))}
                        {!user.rolesFuncionales?.length && <span>Sin roles asignados</span>}
                      </div>
                    </td>
                    <td data-label="Jefatura directa">{user.jefaturaDirectaNombre || <span className="cell-empty">Sin jefatura asignada</span>}</td>
                    <td data-label="Estado">
                      <StatusBadge status={user.enabled ? 'ACTIVO' : 'INACTIVO'} />
                    </td>
                    <td className="table-actions-cell cell-actions cell-actions--corner">
                      {isMobile ? (
                        <MoreActions
                          title={`${user.firstName} ${user.lastName}`}
                          items={[
                            { label: 'Editar datos', icon: Edit2, onClick: () => openEdit(user) },
                            { label: 'Asignar roles', icon: ShieldCheck, onClick: () => setAccessDialog({ user, mode: 'roles' }), disabled: !catalogReady },
                            { label: 'Jefatura directa', icon: Users, onClick: () => setAccessDialog({ user, mode: 'manager' }) },
                            { label: user.enabled ? 'Desactivar usuario' : 'Activar usuario', icon: user.enabled ? PowerOff : Power, onClick: () => toggleUserStatus(user), disabled: togglingUserId === user.id },
                            { label: 'Eliminar usuario', icon: Trash2, onClick: () => openDelete(user), danger: true }
                          ]}
                        />
                      ) : (
                      <div className="table-actions">
                        <button type="button" className="action-btn" disabled={!catalogReady} title="Asignar roles" aria-label={`Asignar roles a ${user.email}`} onClick={() => setAccessDialog({ user, mode: 'roles' })}><ShieldCheck size={15} /></button>
                        <button type="button" className="action-btn" title="Jefatura directa" aria-label={`Gestionar jefatura de ${user.email}`} onClick={() => setAccessDialog({ user, mode: 'manager' })}><Users size={15} /></button>
                        <button
                          type="button"
                          className="action-btn"
                          title="Editar datos de usuario"
                          aria-label={`Editar ${user.email}`}
                          onClick={() => openEdit(user)}
                        >
                          <Edit2 size={15} aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          className={`action-btn ${user.enabled ? 'action-btn-toggle-active' : 'action-btn-toggle-inactive'}`}
                          title={user.enabled ? 'Desactivar usuario' : 'Activar usuario'}
                          aria-label={user.enabled ? `Desactivar ${user.email}` : `Activar ${user.email}`}
                          onClick={() => toggleUserStatus(user)}
                          disabled={togglingUserId === user.id}
                        >
                          {togglingUserId === user.id ? (
                            <LoaderCircle size={15} className="button-spinner" aria-hidden="true" />
                          ) : user.enabled ? (
                            <PowerOff size={15} aria-hidden="true" />
                          ) : (
                            <Power size={15} aria-hidden="true" />
                          )}
                        </button>
                        <button
                          type="button"
                          className="action-btn action-btn-danger"
                          title="Eliminar usuario"
                          aria-label={`Eliminar ${user.email}`}
                          onClick={() => openDelete(user)}
                        >
                          <Trash2 size={15} aria-hidden="true" />
                        </button>
                      </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </div>
        )}
        {!loading && visibleUsers.length > 0 && <div className="areas-pagination"><span>{visibleUsers.length} cuentas · 10 por página</span><nav aria-label="Paginación de usuarios"><Button variant="secondary" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}>Anterior</Button><span>Página {currentPage + 1} de {totalPages}</span><Button variant="secondary" disabled={currentPage + 1 >= totalPages} onClick={() => setPage(currentPage + 1)}>Siguiente</Button></nav></div>}
      </Card>
      </div>
      <div id="org-panel-roles" role="tabpanel" aria-labelledby="org-tab-roles" hidden={activeTab !== 'roles'} tabIndex={0}>
        <RoleManagement onChanged={loadRoles} />
      </div>
      {accessDialog && <UserAccessDialog {...accessDialog} users={users} roles={roles} onClose={() => setAccessDialog(null)} onSaved={async (updated) => { setUsers((items) => items.map((item) => item.id === updated.id ? updated : item)); setSuccess('Acceso de la cuenta actualizado correctamente.'); await refresh(); }} />}

      {/* Modal: Crear Usuario */}
      {isCreateOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeCreateUser}>
          <form
            className="management-card user-form user-form-modal"
            onSubmit={createUser}
            role="dialog"
            aria-modal="true"
            aria-labelledby="create-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <UserPlus size={20} aria-hidden="true" />
                <div>
                  <h3 id="create-user-title">Agregar usuario</h3>
                  <p>Registra una cuenta institucional y asigna sus responsabilidades.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeCreateUser} aria-label="Cerrar formulario" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="form-grid">
              <FormField label="Correo electrónico" className="field-wide">
                <span className="field-control-with-icon">
                  <Mail size={18} aria-hidden="true" />
                  <input type="email" name="email" value={form.email} onChange={updateField} placeholder="nombre@institucion.cl" autoComplete="off" autoFocus required />
                </span>
              </FormField>

              <FormField label="RUT" hint="Formato: 12.345.678-5 o 12.345.678-K">
                <input
                  type="text"
                  name="rut"
                  value={form.rut}
                  onChange={updateField}
                  placeholder="12.345.678-5"
                  autoComplete="off"
                  maxLength={12}
                />
              </FormField>

              <FormField label="Nombre">
                <input type="text" name="firstName" value={form.firstName} onChange={updateField} required />
              </FormField>

              <FormField label="Apellido">
                <input type="text" name="lastName" value={form.lastName} onChange={updateField} required />
              </FormField>

              <FormField label="Área corporativa" optional hint="Departamento o unidad de la empresa">
                <DropdownSelect id="create-user-area" value={form.areaId} onChange={(value) => setForm((current) => ({ ...current, areaId: value }))} options={[{ value: '', label: 'Sin área asignada' }, ...areas.map((area) => ({ value: String(area.id), label: area.nombre }))]} disabled={submitting} />
              </FormField>

              <FormField label="Contraseña inicial" hint="Mínimo 8 caracteres.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="password"
                    value={form.password}
                    onChange={updateField}
                    minLength={8}
                    autoComplete="new-password"
                    required
                  />
                </span>
              </FormField>

              <FormField label="Confirmar contraseña" hint="Debe coincidir con la contraseña inicial.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="confirmPassword"
                    value={form.confirmPassword}
                    onChange={updateField}
                    minLength={8}
                    autoComplete="new-password"
                    required
                  />
                </span>
              </FormField>
            </div>

            <fieldset className="role-selector">
              <legend>Roles funcionales</legend>
              {roles.map((role) => (
                <label key={role.id} className="role-option">
                  <input type="checkbox" checked={form.roleIds.includes(role.id)} onChange={() => toggleRole(role.id)} />
                  <ShieldCheck size={17} aria-hidden="true" />
                  <span>{role.nombre}</span>
                </label>
              ))}
            </fieldset>

            {!!form.roleIds.length && <Button variant="quiet" onClick={() => setForm((current) => ({ ...current, roleIds: [] }))} disabled={submitting}>Quitar roles seleccionados</Button>}
            <p className="area-helper">Sin roles funcionales, la cuenta solo podrá acceder a su sesión y notificaciones.</p>

            <label className="password-policy-option">
              <input type="checkbox" name="requirePasswordChange" checked={form.requirePasswordChange} onChange={updateField} />
              <span>Solicitar cambio de contraseña en el primer inicio de sesión</span>
            </label>

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeCreateUser} disabled={submitting}>Cancelar</Button>
              <Button type="submit" disabled={submitting}>
                <UserPlus size={18} aria-hidden="true" />
                {submitting ? 'Creando cuenta…' : 'Crear cuenta'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Editar Usuario (Solo Nombre y Apellido para Sprint 1) */}
      {isEditOpen && editingUser && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeEdit}>
          <form
            className="management-card user-form user-form-modal"
            onSubmit={saveEdit}
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <Edit2 size={20} aria-hidden="true" />
                <div>
                  <h3 id="edit-user-title">Editar usuario</h3>
                  <p>Modifica el nombre y apellido del usuario institucional.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeEdit} aria-label="Cerrar formulario" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="form-grid">
              <FormField label="Correo electrónico" className="field-wide">
                <span className="field-control-with-icon">
                  <Mail size={18} aria-hidden="true" />
                  <input type="email" value={editingUser.email} disabled />
                </span>
              </FormField>

              <FormField label="Nombre">
                <input
                  type="text"
                  name="firstName"
                  value={editForm.firstName}
                  onChange={updateEditField}
                  autoFocus
                  required
                />
              </FormField>

              <FormField label="Apellido">
                <input
                  type="text"
                  name="lastName"
                  value={editForm.lastName}
                  onChange={updateEditField}
                  required
                />
              </FormField>

              <FormField label="Área corporativa" optional hint="Departamento o unidad de la empresa">
                <DropdownSelect id="edit-user-area" value={editForm.areaId} onChange={(value) => setEditForm((current) => ({ ...current, areaId: value }))} options={[{ value: '', label: 'Sin área asignada' }, ...areas.map((area) => ({ value: String(area.id), label: area.nombre }))]} disabled={submitting} />
              </FormField>

              <FormField label="Nueva contraseña" optional hint="Mínimo 8 caracteres si se modifica.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="newPassword"
                    value={editForm.newPassword}
                    onChange={updateEditField}
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Dejar en blanco para conservar"
                  />
                </span>
              </FormField>

              <FormField label="Confirmar nueva contraseña" hint="Debe coincidir con la nueva contraseña.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="confirmPassword"
                    value={editForm.confirmPassword}
                    onChange={updateEditField}
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Repetir nueva contraseña"
                    disabled={!editForm.newPassword}
                    required={!!editForm.newPassword}
                  />
                </span>
              </FormField>
            </div>

            {editForm.newPassword && (
              <label className="password-policy-option" style={{ marginTop: '0.85rem' }}>
                <input
                  type="checkbox"
                  name="requirePasswordChange"
                  checked={editForm.requirePasswordChange}
                  onChange={updateEditField}
                />
                <span>Solicitar cambio de contraseña en el próximo inicio de sesión</span>
              </label>
            )}

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeEdit} disabled={submitting}>Cancelar</Button>
              <Button type="submit" disabled={submitting}>
                <UserCheck size={18} aria-hidden="true" />
                {submitting ? 'Guardando…' : 'Guardar cambios'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Confirmación Eliminar Usuario */}
      {isDeleteOpen && userToDelete && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeDelete}>
          <div
            className="management-card user-form user-form-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <ShieldAlert size={20} color="#dc2626" aria-hidden="true" />
                <div>
                  <h3 id="delete-user-title">Eliminar usuario</h3>
                  <p>Esta acción no se puede deshacer.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeDelete} aria-label="Cerrar diálogo" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="confirm-dialog-content">
              <p>
                ¿Estás seguro de que deseas eliminar permanentemente la cuenta de{' '}
                <strong>{userToDelete.firstName} {userToDelete.lastName}</strong> (<code>{userToDelete.email}</code>)?
              </p>
              <p style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)' }}>
                El usuario será removido del directorio de autenticación y de la base de datos del sistema.
              </p>
            </div>

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeDelete} disabled={submitting}>Cancelar</Button>
              <Button variant="danger" onClick={confirmDelete} disabled={submitting}>
                <Trash2 size={17} aria-hidden="true" />
                {submitting ? 'Eliminando…' : 'Eliminar usuario'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

