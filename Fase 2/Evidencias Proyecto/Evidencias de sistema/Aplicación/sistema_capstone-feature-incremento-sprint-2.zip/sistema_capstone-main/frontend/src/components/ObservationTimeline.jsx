import React from 'react';
import { CalendarDays, CheckCircle2, MessageSquareWarning, UserRound } from 'lucide-react';

function formatObservationDate(value) {
  if (!value) return 'Fecha no disponible';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Fecha no disponible';
  return new Intl.DateTimeFormat('es-CL', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  }).format(date);
}

export default function ObservationTimeline({ observations, compact = false, mode = 'correction', startIndex = 0, totalPending }) {
  const consultation = mode === 'consultation';
  const orderedObservations = [...observations].sort((a, b) =>
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime() || Number(a.id) - Number(b.id)
  );
  const pendingCount = totalPending ?? orderedObservations.filter((observation) => !observation.resuelta).length;

  return (
    <section className={`observations-box observation-panel${compact ? ' observation-panel-compact' : ''}`} data-testid="observations-box" aria-label="Observaciones del revisor">
      <div className="observation-panel-header">
        <span className="observation-panel-icon" aria-hidden="true"><MessageSquareWarning size={20} /></span>
        <div className="observation-panel-heading">
          <span className="observation-panel-eyebrow">Revisión del documento</span>
          <h4>{consultation ? 'Observaciones de revisión' : 'Indicaciones para corregir'}</h4>
          <p>{consultation ? 'Observaciones registradas en las etapas de la solicitud, incluidas las subsanadas.' : 'Lee cada observación antes de reenviar la solicitud.'}</p>
        </div>
        <span className="observation-panel-count">{pendingCount} pendiente{pendingCount === 1 ? '' : 's'}</span>
      </div>
      <ol className="observation-timeline">
        {orderedObservations.map((observation, index) => (
          <li className="observation-item" key={observation.id}>
            <span className="observation-step" aria-hidden="true">{startIndex + index + 1}</span>
            <div className="observation-entry">
              <div className="observation-entry-header">
                <div className="observation-author"><UserRound size={15} aria-hidden="true" /><strong>{observation.usuarioNombre || observation.usuarioEmail || 'Revisor'}</strong></div>
                <span className={`observation-state${observation.resuelta ? ' observation-state-resolved' : ''}`}>
                  {observation.resuelta && <CheckCircle2 size={14} aria-hidden="true" />}
                  {observation.resuelta ? 'Subsanada' : 'Por subsanar'}
                </span>
              </div>
              <span className="observation-date"><CalendarDays size={14} aria-hidden="true" /><time dateTime={observation.createdAt}>{formatObservationDate(observation.createdAt)}</time></span>
              {consultation && <span className="request-observation-stage">{observation.etapa ? `Etapa ${observation.etapa.orden}: ${observation.etapa.nombre}` : 'Etapa no registrada'}</span>}
              <span className="observation-instruction-label">{consultation ? 'Observación registrada' : 'Corrección solicitada'}</span>
              <p className="observation-text" data-testid="observation-item-text">{observation.contenido}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
