import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Edit2, Plus, Power, RefreshCw, ShieldCheck, X } from 'lucide-react';
import api from '../../services/api';
import { PERMISSION_LABELS, SCOPE_LABELS, problemMessage, isVersionConflict } from '../../services/rbac';
import { useAccess } from '../../components/access/AccessContext';
import AreaDialog from '../../components/areas/AreaDialog';
import { Button, Card, DataTable, DropdownSelect, EmptyState, FeedbackMessage, FormField, StatusBadge } from '../../components/ui';
import './AreaManagementPage.css';
import './RoleManagement.css';

export default function RoleManagement({ onChanged }) {
  const { refresh } = useAccess();
  const [page, setPage] = useState(0);
  const [q, setQ] = useState('');
  const [activo, setActivo] = useState('');
  const [result, setResult] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [dialog, setDialog] = useState(null);
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [modalError, setModalError] = useState('');
  const [stale, setStale] = useState(false);
  const request = useRef(0);
  const load = useCallback(async () => {
    const id = ++request.current;
    setLoading(true); setError('');
    try {
      const { data } = await api.get('/api/rbac/roles', { params: { page, size: 10, q: q.trim() || undefined, activo: activo === '' ? undefined : activo === 'true' } });
      if (id === request.current) {
        if (page > 0 && page >= data.totalPaginas) setPage(Math.max(0, data.totalPaginas - 1));
        else setResult(data);
      }
    } catch (err) { if (id === request.current) { setResult(null); setError(problemMessage(err)); } }
    finally { if (id === request.current) setLoading(false); }
  }, [page, q, activo]);
  useEffect(() => { const timer = setTimeout(load, 250); return () => { clearTimeout(timer); ++request.current; }; }, [load]);
  useEffect(() => {
    const controller = new AbortController();
    api.get('/api/rbac/permisos', { signal: controller.signal }).then(({ data }) => setCatalog(data))
      .catch((err) => { if (err.code !== 'ERR_CANCELED') setError(problemMessage(err)); });
    return () => controller.abort();
  }, []);
  const open = (role, mode = 'edit') => {
    setModalError(''); setStale(false);
    setDialog({ role, mode });
    setForm({ nombre: role?.nombre || '', descripcion: role?.descripcion || '', version: role?.version,
      permisos: (role?.permisos || []).map((grant) => ({ ...grant, alcances: [...grant.alcances] })) });
  };
  const close = () => { if (!busyRef.current) { setDialog(null); setForm(null); } };
  const protectedRole = ['ADMIN', 'AREA_ADMIN', 'APPROVER'].includes(dialog?.role?.codigo);
  const readonly = protectedRole || dialog?.mode === 'view';
  const toggleScope = (codigo, scope) => setForm((current) => {
    const grant = current.permisos.find((item) => item.codigo === codigo);
    const scopes = grant?.alcances.includes(scope) ? grant.alcances.filter((item) => item !== scope) : [...(grant?.alcances || []), scope];
    return { ...current, permisos: [...current.permisos.filter((item) => item.codigo !== codigo), ...(scopes.length ? [{ codigo, alcances: scopes }] : [])] };
  });
  const reload = async () => {
    if (busyRef.current || !dialog.role) return;
    busyRef.current = true; setBusy(true);
    try { open((await api.get(`/api/rbac/roles/${dialog.role.id}`)).data, dialog.mode); }
    catch (err) { setModalError(problemMessage(err)); }
    finally { busyRef.current = false; setBusy(false); }
  };
  const save = async (event) => {
    event.preventDefault();
    if (busyRef.current || readonly || stale) return;
    busyRef.current = true; setBusy(true); setModalError('');
    try {
      if (dialog.mode === 'status') await api.patch(`/api/rbac/roles/${dialog.role.id}/status`, { activo: !dialog.role.activo, version: form.version });
      else if (dialog.role) await api.put(`/api/rbac/roles/${dialog.role.id}`, { ...form, nombre: form.nombre.trim() });
      else await api.post('/api/rbac/roles', { ...form, nombre: form.nombre.trim(), codigo: `ROL_${crypto.randomUUID().replaceAll('-', '').toUpperCase()}` });
      setDialog(null); setForm(null); setNotice('El rol fue actualizado correctamente.');
      await load(); await onChanged?.(); await refresh();
    } catch (err) { setModalError(problemMessage(err)); setStale(isVersionConflict(err)); }
    finally { busyRef.current = false; setBusy(false); }
  };
  return <Card className="list-card rbac-card">
    <div className="card-header"><div><h3>Roles y permisos</h3><p>Define responsabilidades y su alcance dentro de la organización.</p></div>
      <Button onClick={() => open(null)} disabled={!catalog.length}><Plus size={17} />Crear rol</Button></div>
    {notice && <FeedbackMessage tone="success">{notice}</FeedbackMessage>}
    {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}
    <div className="areas-toolbar">
      <FormField label="Buscar roles"><input type="search" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} placeholder="Nombre del rol" /></FormField>
      <FormField label="Estado" htmlFor="role-state"><DropdownSelect id="role-state" value={activo} onChange={(value) => { setActivo(value); setPage(0); }} options={[{ value: '', label: 'Todos los estados' }, { value: 'true', label: 'Activos' }, { value: 'false', label: 'Inactivos' }]} /></FormField>
      <Button variant="secondary" onClick={load} disabled={loading}><RefreshCw size={16} />Actualizar</Button>
    </div>
    {loading ? <EmptyState loading title="Cargando roles…" /> : !result?.contenido.length ? <EmptyState icon={ShieldCheck} title="No hay roles para estos filtros" /> : <div className="table-scroll"><DataTable className="table-stackable">
      <thead><tr><th>Rol</th><th>Asignación</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{result.contenido.map((role) => <tr key={role.id}>
        <td className="cell-primary"><div className="cell-stack"><strong>{role.nombre}</strong><span>{role.descripcion || 'Sin descripción'}</span></div></td>
        <td data-label="Asignación">{role.asignacion === 'DERIVADA_AREA' ? 'Administración del área' : role.codigo === 'APPROVER' ? 'Uso del sistema' : 'Asignación a usuarios'}</td>
        <td data-label="Estado"><StatusBadge status={role.activo ? 'ACTIVO' : 'INACTIVO'} /></td>
        <td className="cell-actions"><div className="row-actions"><Button variant="secondary" onClick={() => open(role)}><Edit2 size={15} />{['ADMIN', 'AREA_ADMIN', 'APPROVER'].includes(role.codigo) ? 'Ver permisos' : 'Editar'}</Button>
          {!['ADMIN', 'AREA_ADMIN', 'APPROVER'].includes(role.codigo) && <Button variant="quiet" onClick={() => open(role, 'status')}><Power size={15} />{role.activo ? 'Desactivar' : 'Activar'}</Button>}</div></td>
      </tr>)}</tbody></DataTable></div>}
    {result && <div className="areas-pagination"><span>{result.totalElementos} roles · 10 por página</span><nav aria-label="Paginación de roles"><Button variant="secondary" onClick={() => setPage((v) => v - 1)} disabled={loading || page === 0}>Anterior</Button><span>Página {page + 1} de {Math.max(1, result.totalPaginas)}</span><Button variant="secondary" onClick={() => setPage((v) => v + 1)} disabled={loading || result.ultima}>Siguiente</Button></nav></div>}
    {dialog && form && <AreaDialog titleId="role-dialog-title" busy={busy} onClose={close}>
      <div className="area-dialog-header"><div><h3 id="role-dialog-title">{dialog.mode === 'status' ? `${dialog.role.activo ? 'Desactivar' : 'Activar'} rol` : readonly ? 'Permisos del rol' : dialog.role ? 'Editar rol' : 'Crear rol'}</h3><p>Los permisos se aplican con el alcance seleccionado.</p></div><Button variant="quiet" onClick={close} disabled={busy} aria-label="Cerrar diálogo"><X size={18} /></Button></div>
      <form className="area-form" onSubmit={save}><div className="area-dialog-body">
        {dialog.mode === 'status' ? <p>Confirme el cambio de estado de <strong>{dialog.role.nombre}</strong>. Un rol asignado a cuentas no puede desactivarse.</p> : <>
          <FormField label="Nombre del rol"><input data-autofocus value={form.nombre} maxLength={100} required disabled={readonly || busy} onChange={(e) => setForm({ ...form, nombre: e.target.value })} /></FormField>
          <FormField label="Descripción" optional><textarea value={form.descripcion} maxLength={1000} disabled={readonly || busy} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} /></FormField>
          {protectedRole && <FeedbackMessage>Este rol está protegido por la política del sistema. La administración de áreas se asigna desde Áreas corporativas.</FeedbackMessage>}
          <div className="rbac-permissions">{catalog.filter((permission) => !permission.reservado || dialog.role?.codigo === 'ADMIN').map((permission) => {
            const scopes = readonly ? form.permisos.find((grant) => grant.codigo === permission.codigo)?.alcances || [] : permission.alcancesPermitidos.filter((scope) => scope !== 'GLOBAL');
            return <fieldset key={permission.codigo} disabled={readonly || busy}><legend>{PERMISSION_LABELS[permission.codigo] || permission.nombre}</legend><p>Autoriza esta acción dentro de los alcances seleccionados.</p><div className="rbac-scope-options">{scopes.map((scope) => <label key={scope}><input type="checkbox" checked={form.permisos.some((grant) => grant.codigo === permission.codigo && grant.alcances.includes(scope))} onChange={() => toggleScope(permission.codigo, scope)} />{SCOPE_LABELS[scope] || scope}</label>)}</div></fieldset>;
          })}</div>
        </>}
        {modalError && <FeedbackMessage tone="error">{modalError}</FeedbackMessage>}
        {stale && <><p>El formulario conserva los cambios. Recargar reemplazará estos datos por la versión actual.</p><Button variant="secondary" onClick={reload} loading={busy}>Recargar datos actuales</Button></>}
      </div><div className="area-dialog-footer"><Button variant="secondary" onClick={close} disabled={busy}>{readonly ? 'Cerrar' : 'Cancelar'}</Button>{!readonly && <Button type="submit" loading={busy} disabled={stale || !catalog.length}>{dialog.mode === 'status' ? 'Confirmar cambio' : 'Guardar rol'}</Button>}</div></form>
    </AreaDialog>}
  </Card>;
}
