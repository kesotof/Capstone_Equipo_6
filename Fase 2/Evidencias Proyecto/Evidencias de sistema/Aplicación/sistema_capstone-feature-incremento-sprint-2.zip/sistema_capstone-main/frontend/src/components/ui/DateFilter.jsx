import React, { useEffect, useRef, useState } from 'react';
import { CalendarDays, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

const WEEK_DAYS = ['lu', 'ma', 'mi', 'ju', 'vi', 'sá', 'do'];
const CALENDAR_WIDTH = 288;

function toIsoDate(date) {
  return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function fromIsoDate(value) {
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value || '') || value.startsWith('0000-')) return null;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setFullYear(year, month - 1, day);
  return toIsoDate(date) === value ? date : null;
}

function getCalendarDays(monthDate) {
  const first = new Date(monthDate);
  first.setDate(1);
  const start = new Date(first);
  start.setDate(1 - (first.getDay() + 6) % 7);
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return date;
  });
}

function todayInChile() {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('es-CL', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'America/Santiago' })
    .formatToParts(new Date()).map(({ type, value }) => [type, value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

/** Calendario compartido con la apariencia de la bandeja de revisión. */
export default function DateFilter({ label, name, id = `${name}-date-filter`, value, min, max, onChange, disabled = false }) {
  const containerRef = useRef(null);
  const triggerRef = useRef(null);
  const calendarRef = useRef(null);
  const [open, setOpen] = useState(false);
  const [alignEnd, setAlignEnd] = useState(false);
  const [visibleMonth, setVisibleMonth] = useState(() => fromIsoDate(value) || fromIsoDate(todayInChile()));
  const selected = fromIsoDate(value);
  const today = todayInChile();
  const allowed = (iso) => /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(iso) && iso >= '0001-01-01' && iso <= '9999-12-31' && (!min || iso >= min) && (!max || iso <= max);
  const close = (restoreFocus = false) => {
    setOpen(false);
    if (restoreFocus) triggerRef.current?.focus();
  };
  const selectDate = (date) => {
    const iso = toIsoDate(date);
    if (!allowed(iso) || disabled) return;
    onChange(name, iso); close(true);
  };
  useEffect(() => {
    if (!open) return undefined;
    if (disabled) { setOpen(false); return undefined; }
    const dismiss = (event) => { if (!containerRef.current?.contains(event.target)) setOpen(false); };
    const escape = (event) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); setOpen(false); triggerRef.current?.focus(); }
    };
    const focusable = calendarRef.current?.querySelector('button.is-selected:not(:disabled), button.is-today:not(:disabled), button[data-value]:not(:disabled)');
    focusable?.focus();
    document.addEventListener('pointerdown', dismiss);
    containerRef.current?.addEventListener('keydown', escape);
    const container = containerRef.current;
    return () => { document.removeEventListener('pointerdown', dismiss); container?.removeEventListener('keydown', escape); };
  }, [open, disabled]);

  const toggle = () => {
    if (disabled) return;
    if (!open) {
      const initial = selected || fromIsoDate(min) || fromIsoDate(max) || fromIsoDate(today);
      setVisibleMonth(initial);
      const bounds = containerRef.current?.getBoundingClientRect();
      setAlignEnd(Boolean(bounds && bounds.left + CALENDAR_WIDTH > window.innerWidth - 12));
    }
    setOpen((current) => !current);
  };
  const changeMonth = (offset) => {
    setVisibleMonth((current) => {
      const next = new Date(current);
      next.setDate(1); next.setMonth(next.getMonth() + offset);
      return next.getFullYear() >= 1 && next.getFullYear() <= 9999 ? next : current;
    });
  };
  const rawMonthLabel = new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric' }).format(visibleMonth);
  const monthLabel = rawMonthLabel.charAt(0).toUpperCase() + rawMonthLabel.slice(1);

  return <div className="review-date-field">
    <label htmlFor={id}>{label}</label>
    <div className="review-picker" ref={containerRef} onBlur={(event) => {
      if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false);
    }}>
      <button ref={triggerRef} id={id} className="review-filter-trigger" type="button" onClick={toggle} aria-haspopup="dialog" aria-expanded={open && !disabled}
        aria-controls={open ? `${id}-calendar` : undefined} disabled={disabled} data-testid={`${name}-trigger`}>
        <CalendarDays size={16} aria-hidden="true" /><span className={selected ? '' : 'review-filter-placeholder'}>{selected ? new Intl.DateTimeFormat('es-CL').format(selected) : 'Seleccionar fecha'}</span>
        <ChevronDown className="review-filter-chevron" size={15} aria-hidden="true" />
      </button>
      {open && !disabled && <div ref={calendarRef} id={`${id}-calendar`} className={`review-calendar${alignEnd ? ' review-calendar--end' : ''}`} role="dialog" aria-label={`Seleccionar ${label.toLowerCase()}`}>
        <div className="review-calendar-header"><strong aria-live="polite">{monthLabel}</strong><div>
          <button type="button" onClick={() => changeMonth(-1)} disabled={visibleMonth.getFullYear() === 1 && visibleMonth.getMonth() === 0} aria-label="Mes anterior"><ChevronLeft size={17} aria-hidden="true" /></button>
          <button type="button" onClick={() => changeMonth(1)} disabled={visibleMonth.getFullYear() === 9999 && visibleMonth.getMonth() === 11} aria-label="Mes siguiente"><ChevronRight size={17} aria-hidden="true" /></button>
        </div></div>
        <div className="review-calendar-grid review-calendar-weekdays" aria-hidden="true">{WEEK_DAYS.map((day) => <span key={day}>{day}</span>)}</div>
        <div className="review-calendar-grid">{getCalendarDays(visibleMonth).map((date) => {
          const iso = toIsoDate(date);
          return <button key={iso} className={`${date.getMonth() !== visibleMonth.getMonth() ? 'is-outside' : ''} ${iso === value ? 'is-selected' : ''} ${iso === today ? 'is-today' : ''}`}
            type="button" onClick={() => selectDate(date)} disabled={!allowed(iso)} data-value={iso} aria-label={new Intl.DateTimeFormat('es-CL', { dateStyle: 'full' }).format(date)} aria-pressed={iso === value} aria-current={iso === today ? 'date' : undefined}>{date.getDate()}</button>;
        })}</div>
        <div className="review-calendar-footer">
          <button type="button" onClick={() => { onChange(name, ''); close(true); }} disabled={!value}>Borrar</button>
          <button type="button" onClick={() => selectDate(fromIsoDate(today))} disabled={!allowed(today)}>Hoy</button>
        </div>
      </div>}
    </div>
  </div>;
}
