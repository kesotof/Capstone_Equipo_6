import React, { useEffect, useRef, useState } from 'react';
import { Eye, FileText, LockKeyhole, X } from 'lucide-react';
import { Button, Card, DateTimeStack, EmptyState, FeedbackMessage, FileTypeIcon, StatusBadge, formatFileSize } from '../ui';
import { allowsAction } from '../../services/rbac';
import { documentError, getCurrentDocument } from '../../services/requestDetails';
import RequestPagination, { REQUEST_PAGE_SIZE } from './RequestPagination';
import DocumentDownloadButton from '../documents/DocumentDownloadButton';

export default function RequestDocuments({ detail, requestKey, page, onPageChange }) {
  const document = detail.documentoVigente;
  const permitted = allowsAction(detail, 'DESCARGAR') && Boolean(document?.descargaUrl);
  const identity = `${requestKey}:${detail.version}:${document?.id || ''}`;
  const currentIdentity = useRef(identity);
  currentIdentity.current = identity;
  const operation = useRef(null);
  const sequence = useRef(0);
  const urls = useRef(new Set());
  const previewButton = useRef(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    setBusy(''); setError(''); setPreview(null);
    return () => {
      ++sequence.current;
      operation.current?.abort(); operation.current = null;
      urls.current.forEach((url) => URL.revokeObjectURL(url)); urls.current.clear();
    };
  }, [identity]);

  const closePreview = () => {
    if (preview?.url) { URL.revokeObjectURL(preview.url); urls.current.delete(preview.url); }
    setPreview(null); previewButton.current?.focus();
  };

  const readFile = async (action) => {
    if (!permitted || operation.current || (action === 'preview' && !document.previsualizable)) return;
    const controller = new AbortController();
    operation.current = controller;
    const current = ++sequence.current;
    setBusy(action); setError('');
    try {
      const file = await getCurrentDocument(detail, controller.signal);
      let blob = file;
      if (action === 'preview') {
        const signature = await file.slice(0, 1024).text();
        if (!signature.includes('%PDF-')) {
          const invalidPdf = new Error('PDF no disponible');
          invalidPdf.previewMessage = 'No fue posible previsualizar este PDF. Puede descargar el archivo para revisarlo.';
          throw invalidPdf;
        }
        blob = new Blob([file], { type: 'application/pdf' });
      }
      if (controller.signal.aborted || current !== sequence.current || currentIdentity.current !== identity) return;
      const url = URL.createObjectURL(blob);
      urls.current.add(url);
      setPreview({ identity, url });
    } catch (fileError) {
      if (!controller.signal.aborted && current === sequence.current && currentIdentity.current === identity) {
        setError(fileError.previewMessage || documentError(fileError));
      }
    } finally {
      if (current === sequence.current && currentIdentity.current === identity) { operation.current = null; setBusy(''); }
    }
  };

  const previewUrl = preview?.identity === identity ? preview.url : null;
  const versions = detail.documentos.slice(page * REQUEST_PAGE_SIZE, (page + 1) * REQUEST_PAGE_SIZE);
  const sizeLabel = (file) => formatFileSize(file.sizeBytes) || (file.sizeBytes === 0 ? '0 B' : 'Tamaño no informado');

  return <div className="request-document-panels">
    <Card className="request-section-card" aria-labelledby="request-current-document">
      <header className="card-header"><div><h3 id="request-current-document">Documento vigente</h3><p>Archivo asociado a la versión actual de la solicitud.</p></div></header>
      <div className="request-card-body">
        {!document ? <EmptyState icon={FileText} title={detail.documentos.length ? 'Sin documento vigente' : 'Sin archivos adjuntos'}>{detail.documentos.length ? 'Las versiones registradas están disponibles como referencia en el listado inferior.' : 'Esta solicitud no tiene documentos registrados.'}</EmptyState> : <>
          <div className="request-attachment"><FileTypeIcon fileName={document.nombreArchivo} /><div><strong>{document.nombreArchivo}</strong><span>{sizeLabel(document)} · Versión {document.version}</span><DateTimeStack value={document.createdAt} /></div><StatusBadge status="ACTIVO" label="Vigente" /></div>
          {permitted ? <>
            <div className="row-actions request-file-actions">
              <DocumentDownloadButton documentId={document.id} solicitudId={detail.id} fileName={document.nombreArchivo}
                allowed={permitted} contextKey={identity} disabled={Boolean(busy)} />
              {document.previsualizable && <Button variant="secondary" onClick={(event) => { previewButton.current = event.currentTarget; if (previewUrl) closePreview(); else readFile('preview'); }} loading={busy === 'preview'} disabled={Boolean(busy)} aria-expanded={Boolean(previewUrl)} aria-controls="request-pdf-preview"><Eye size={16} aria-hidden="true" />{previewUrl ? 'Ocultar vista previa' : 'Previsualizar'}</Button>}
            </div>
            {!document.previsualizable && <p className="request-muted">Vista previa no disponible para este formato. Puede descargar el archivo para revisarlo.</p>}
          </> : <FeedbackMessage><LockKeyhole size={15} aria-hidden="true" /> No tiene permiso para descargar o previsualizar este archivo.</FeedbackMessage>}
          {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}
          {previewUrl && <section id="request-pdf-preview" className="request-preview" aria-label="Vista previa del documento vigente">
            <header><strong>Vista previa del documento</strong><Button variant="quiet" onClick={closePreview} aria-label="Cerrar vista previa"><X size={17} aria-hidden="true" />Cerrar</Button></header>
            <iframe src={`${previewUrl}#view=FitH&zoom=page-width`} title={`Vista previa PDF: ${document.nombreArchivo}`} />
            <p className="request-muted">Si el navegador no muestra el PDF, utilice Descargar para abrirlo en su equipo.</p>
          </section>}
        </>}
      </div>
    </Card>
    {detail.documentos.length > 0 && <Card className="request-section-card" aria-labelledby="request-document-versions">
      <header className="card-header"><div><h3 id="request-document-versions">Versiones documentales</h3><p>Versiones registradas, desde la más reciente. Descarga la versión que necesitas según tu acceso.</p></div></header>
      <ul className="request-version-list">{versions.map((file) => <li key={file.id}><FileTypeIcon fileName={file.nombreArchivo} /><div><strong>{file.nombreArchivo}</strong><span>{sizeLabel(file)} · Versión {file.version}</span><DateTimeStack value={file.createdAt} /></div><StatusBadge status={file.vigente ? 'ACTIVO' : 'INACTIVO'} label={file.vigente ? 'Vigente' : 'Versión anterior'} />
        <DocumentDownloadButton documentId={file.id} solicitudId={detail.id} fileName={file.nombreArchivo}
          allowed={allowsAction(detail, 'DESCARGAR') && file.descargaUrl === '/api/documents/' + file.id + '/download'}
          contextKey={identity} compact />
      </li>)}</ul>
      <RequestPagination total={detail.documentos.length} page={page} onChange={onPageChange} label="versiones documentales" />
    </Card>}
  </div>;
}
