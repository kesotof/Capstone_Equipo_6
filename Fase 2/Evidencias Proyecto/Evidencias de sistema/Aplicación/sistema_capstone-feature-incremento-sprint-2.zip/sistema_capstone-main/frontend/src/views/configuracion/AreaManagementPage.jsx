import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Building2, ChevronLeft, ChevronRight, Edit2, Plus, Power, PowerOff, RefreshCw, Search, SearchX, X } from 'lucide-react';
import AreaDialog from '../../components/areas/AreaDialog';
import { Button, Card, DataTable, DateTimeStack, DropdownSelect, EmptyState, FeedbackMessage, FormField, PageHeader, StatusBadge } from '../../components/ui';
import { changeAreaStatus, createArea, getAreaProblem, listAreas, loadAreaCatalog, updateArea } from '../../services/areas';
import api from '../../services/api';
import './AreaManagementPage.css';

const PAGE_SIZE = 10;
const stripSpaces = (value) => value.replace(/^ +| +$/g, '');
const lengthOf = (value) => Array.from(value).length;
const toForm = (area) => ({
  nombre: area?.nombre || '',
  descripcion: area?.descripcion || '',
  areaPadreId: area?.areaPadreId == null ? '' : String(area.areaPadreId),
  administradorId: area?.administradorId == null ? '' : String(area.administradorId)
});

function useAreaCatalog() {
  const [areas, setAreas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const controllerRef = useRef(null);
  const reload = useCallback(async () => {
    controllerRef.current?.abort();
    const controller = new AbortController();
    controllerRef.current = controller;
    setLoading(true);
    setError(null);
    try {
      const catalog = await loadAreaCatalog(controller.signal);
      if (controller.signal.aborted) return null;
      setAreas(catalog);
      return catalog;
    } catch (requestError) {
      if (!controller.signal.aborted) setError(getAreaProblem(requestError, 'No fue posible cargar las áreas superiores. Vuelva a intentar la carga.'));
      return null;
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, []);
  useEffect(() => {
    reload();
    return () => controllerRef.current?.abort();
  }, [reload]);
  return { areas, loading, error, reload };
}

function useMountedRef() {
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; };
  }, []);
  return mounted;
}

function DialogHeader({ title, description, titleId, descriptionId, busy, onClose }) {
  return <header className="area-dialog-header">
    <div><h3 id={titleId}>{title}</h3><p id={descriptionId}>{description}</p></div>
    <Button variant="quiet" className="area-close-button" onClick={onClose} disabled={busy} aria-label="Cerrar diálogo">
      <X size={20} aria-hidden="true" />
    </Button>
  </header>;
}

function AreaFormDialog({ area, onClose, onSaved }) {
  const [baseline, setBaseline] = useState(area);
  const [form, setForm] = useState(() => toForm(area));
  const [fieldErrors, setFieldErrors] = useState({});
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [reloadingCurrent, setReloadingCurrent] = useState(false);
  const submittingRef = useRef(false);
  const formRef = useRef(null);
  const mounted = useMountedRef();
  const catalog = useAreaCatalog();
  const editing = Boolean(baseline);

  const eligibleParents = useMemo(() => {
    const byId = new Map(catalog.areas.map((item) => [item.id, item]));
    return catalog.areas.filter((candidate) => {
      let current = candidate;
      const visited = new Set();
      while (current) {
        if (!current.activo || current.id === baseline?.id || visited.has(current.id)) return false;
        visited.add(current.id);
        if (current.areaPadreId == null) return true;
        current = byId.get(current.areaPadreId);
      }
      return false;
    });
  }, [catalog.areas, baseline?.id]);

  // Un área inactiva puede conservar su padre actual aunque ese padre esté inactivo.
  const retainedParent = baseline?.activo === false && baseline.areaPadreId != null
    && String(baseline.areaPadreId) === form.areaPadreId;
  const selectedParent = catalog.areas.find((item) => String(item.id) === form.areaPadreId);
  const selectedEligible = eligibleParents.some((item) => String(item.id) === form.areaPadreId);
  const parentOptions = [
    { value: '', label: 'Sin dependencia jerárquica' },
    ...(form.areaPadreId && !selectedEligible ? [{
      value: form.areaPadreId,
      label: `${selectedParent?.nombre || baseline?.areaPadreNombre || 'Área superior actual'} (${retainedParent ? 'asignación actual' : 'no disponible'})`,
      disabled: !retainedParent
    }] : []),
    ...eligibleParents.map((parent) => ({ value: String(parent.id), label: parent.nombre }))
  ];

  const [activeUsers, setActiveUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setLoadingUsers(true);
    api.get('/api/users')
      .then((res) => {
        if (isMounted) {
          setActiveUsers(res.data.filter((u) => u.enabled));
        }
      })
      .catch(() => {})
      .finally(() => {
        if (isMounted) setLoadingUsers(false);
      });
    return () => { isMounted = false; };
  }, []);

  const adminOptions = useMemo(() => {
    const options = [
      { value: '', label: 'Sin administrador asignado' },
      ...activeUsers.map((u) => ({
        value: String(u.id),
        label: `${u.firstName} ${u.lastName} (${u.email})`
      }))
    ];
    if (form.administradorId && !activeUsers.some((u) => String(u.id) === form.administradorId)) {
      options.push({
        value: form.administradorId,
        label: `${baseline?.administradorNombre || 'Administrador actual'} (${baseline?.administradorEmail || form.administradorId}) (no activo)`
      });
    }
    return options;
  }, [activeUsers, form.administradorId, baseline]);

  const needsRefresh = problem && (problem.status === 409 || problem.uncertain || problem.codigo === 'AREA_PADRE_NO_ENCONTRADA');
  const busy = submitting || reloadingCurrent;

  const changeField = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
    setFieldErrors((current) => ({ ...current, [field]: undefined }));
    setNotice('');
  };

  const refresh = async (replaceForm) => {
    if (replaceForm) setReloadingCurrent(true);
    try {
      const areas = await catalog.reload();
      if (!areas || !mounted.current) return;
      if (replaceForm && baseline) {
        const current = areas.find((item) => item.id === baseline.id);
        if (!current) {
          setProblem({ codigo: 'AREA_NO_ENCONTRADA', message: 'El área ya no está disponible. Cierre el diálogo y actualice el listado.' });
          return;
        }
        setBaseline(current);
        setForm(toForm(current));
        setFieldErrors({});
        setProblem(null);
        setNotice('Se cargaron los datos actuales del área. Revise la información antes de guardar.');
      } else {
        if (problem?.uncertain) setProblem(null);
        setNotice('El catálogo se actualizó. Los cambios se conservaron; revise el nombre y el área superior antes de guardar.');
      }
    } finally {
      if (mounted.current) setReloadingCurrent(false);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    if (submittingRef.current || catalog.loading || catalog.error || problem?.stale || problem?.uncertain || problem?.denied || problem?.codigo === 'AREA_NO_ENCONTRADA') return;
    const nombre = stripSpaces(form.nombre);
    const descripcion = stripSpaces(form.descripcion);
    const errors = {};
    if (!nombre) errors.nombre = 'Ingrese el nombre del área.';
    else if (lengthOf(nombre) > 100) errors.nombre = 'El nombre admite hasta 100 caracteres.';
    else if (/[\u0000-\u001f\u007f-\u009f]/.test(nombre)) errors.nombre = 'El nombre no admite saltos de línea ni caracteres de control.';
    if (lengthOf(descripcion) > 1000) errors.descripcion = 'La descripción admite hasta 1000 caracteres.';
    else if (descripcion.includes('\u0000')) errors.descripcion = 'La descripción contiene un carácter no válido.';
    if (form.areaPadreId && !selectedEligible && !retainedParent) errors.areaPadreId = 'Seleccione un área superior disponible o deje el área sin dependencia jerárquica.';
    setFieldErrors(errors);
    if (Object.keys(errors).length) {
      setProblem({ message: 'Revise los campos indicados antes de guardar.' });
      const firstField = Object.keys(errors)[0];
      formRef.current?.elements.namedItem(firstField)?.focus();
      return;
    }
    submittingRef.current = true;
    setSubmitting(true);
    setProblem(null);
    setNotice('');
    const payload = {
      nombre,
      descripcion: descripcion || null,
      areaPadreId: form.areaPadreId ? Number(form.areaPadreId) : null,
      administradorId: form.administradorId ? form.administradorId : null
    };
    try {
      const saved = editing
        ? await updateArea(baseline.id, { ...payload, version: baseline.version })
        : await createArea(payload);
      if (mounted.current) onSaved(saved, editing ? `Se guardaron los cambios de “${saved.nombre}”.` : `Se creó el área “${saved.nombre}” con estado activo.`);
    } catch (requestError) {
      if (!mounted.current) return;
      const failure = getAreaProblem(requestError, 'No fue posible confirmar el resultado. Actualice los datos antes de volver a guardar.');
      setProblem(failure);
      setFieldErrors(failure.fields);
      const firstField = Object.keys(failure.fields)[0];
      if (firstField) formRef.current?.elements.namedItem(firstField)?.focus();
    } finally {
      submittingRef.current = false;
      if (mounted.current) setSubmitting(false);
    }
  };

  const fieldProps = (field) => ({
    id: `area-${field}`, name: field,
    'aria-invalid': Boolean(fieldErrors[field]),
    'aria-describedby': `area-${field}-hint${fieldErrors[field] ? ` area-${field}-error` : ''}`,
    disabled: busy, value: form[field], onChange: (event) => changeField(field, event.target.value)
  });
  const fieldError = (field) => fieldErrors[field] && <span id={`area-${field}-error`}>{fieldErrors[field]}</span>;

  return <AreaDialog titleId="area-form-title" descriptionId="area-form-description" busy={busy} onClose={onClose}>
    <DialogHeader title={editing ? 'Editar área' : 'Crear área'}
      description={editing ? 'Actualice la información y la dependencia jerárquica del área.' : 'Registre un área corporativa. El estado inicial será activo.'}
      titleId="area-form-title" descriptionId="area-form-description" busy={busy} onClose={onClose} />
    <form ref={formRef} className="area-form" noValidate onSubmit={submit}>
      <div className="area-dialog-body">
        {baseline && <div className="area-current-status"><span>Estado actual</span><StatusBadge status={baseline.activo ? 'ACTIVO' : 'INACTIVO'} /></div>}
        {problem && <FeedbackMessage tone="error" title={problem.uncertain ? 'No se pudo confirmar el guardado' : 'No se guardaron los cambios'}>
          <p>{problem.message}</p>
          {needsRefresh && <div className="ui-feedback-actions">
            <Button variant="secondary" onClick={() => refresh(problem.stale || (problem.uncertain && editing))} disabled={submitting} loading={catalog.loading}>
              <RefreshCw size={16} aria-hidden="true" />{problem.stale || (problem.uncertain && editing) ? 'Recargar área y descartar mis cambios' : 'Actualizar catálogo'}
            </Button>
          </div>}
        </FeedbackMessage>}
        {notice && <FeedbackMessage>{notice}</FeedbackMessage>}
        <FormField label="Nombre del área" htmlFor="area-nombre" hint="Obligatorio. Hasta 100 caracteres; el nombre debe ser único, también entre áreas inactivas."
          hintId="area-nombre-hint" error={fieldError('nombre')}>
          <input {...fieldProps('nombre')} required data-autofocus autoComplete="off" />
        </FormField>
        <FormField label="Descripción" optional htmlFor="area-descripcion" hint={`${lengthOf(stripSpaces(form.descripcion))} de 1000 caracteres.`}
          hintId="area-descripcion-hint" error={fieldError('descripcion')}>
          <textarea {...fieldProps('descripcion')} rows={4} />
        </FormField>
        <FormField label="Área superior" optional htmlFor="area-areaPadreId"
          hint="Área de la que depende esta unidad. Sin dependencia jerárquica, se ubicará en el nivel principal de la organización."
          hintId="area-areaPadreId-hint" error={fieldError('areaPadreId')}>
          <DropdownSelect {...fieldProps('areaPadreId')} options={parentOptions}
            onChange={(value) => changeField('areaPadreId', value)} disabled={busy || catalog.loading || Boolean(catalog.error)} />
        </FormField>
        <FormField label="Administrador de área" optional htmlFor="area-administradorId"
          hint="Usuario activo responsable de la gestión y supervisión de las solicitudes de esta área."
          hintId="area-administradorId-hint" error={fieldError('administradorId')}>
          <DropdownSelect {...fieldProps('administradorId')} options={adminOptions}
            onChange={(value) => changeField('administradorId', value)} disabled={busy || loadingUsers} />
        </FormField>
        {catalog.loading && <p className="area-helper" role="status">Cargando áreas superiores disponibles…</p>}
        {catalog.error && <FeedbackMessage tone="error">
          <p>{catalog.error.message}</p><div className="ui-feedback-actions"><Button variant="secondary" onClick={() => refresh(false)} disabled={busy}>Reintentar carga</Button></div>
        </FeedbackMessage>}
      </div>
      <footer className="area-dialog-footer">
        <Button variant="secondary" onClick={onClose} disabled={busy}>Cancelar</Button>
        <Button type="submit" loading={submitting} disabled={catalog.loading || Boolean(catalog.error) || problem?.stale || problem?.uncertain || problem?.denied || problem?.codigo === 'AREA_NO_ENCONTRADA'}>
          {editing ? 'Guardar cambios' : 'Crear área'}
        </Button>
      </footer>
    </form>
  </AreaDialog>;
}

function AreaStatusDialog({ area, onClose, onSaved }) {
  const [current, setCurrent] = useState(area);
  const target = !area.activo;
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const requestRef = useRef(false);
  const mounted = useMountedRef();
  const refreshController = useRef(null);
  useEffect(() => () => refreshController.current?.abort(), []);

  const refresh = async () => {
    if (requestRef.current) return;
    requestRef.current = true;
    setBusy(true);
    const controller = new AbortController();
    refreshController.current = controller;
    try {
      const areas = await loadAreaCatalog(controller.signal);
      if (!mounted.current) return;
      const latest = areas.find((item) => item.id === current.id);
      if (!latest) {
        setProblem({ codigo: 'AREA_NO_ENCONTRADA', message: 'El área ya no está disponible. Cierre el diálogo y actualice el listado.' });
      } else {
        setCurrent(latest);
        setProblem(null);
        setNotice(latest.activo === target ? 'El área ya tiene el estado solicitado. Cierre el diálogo y actualice el listado.' : 'Se cargaron los datos actuales. Revise el área y confirme el cambio de estado.');
      }
    } catch (requestError) {
      if (mounted.current && !controller.signal.aborted) {
        const failure = getAreaProblem(requestError);
        // Una recarga fallida no habilita una escritura con la versión antigua.
        setProblem({ ...failure, stale: true });
      }
    } finally {
      requestRef.current = false;
      if (mounted.current) setBusy(false);
    }
  };

  const confirm = async () => {
    if (requestRef.current || problem?.stale || problem?.uncertain || problem?.denied || current.activo === target || problem?.codigo === 'AREA_NO_ENCONTRADA') return;
    requestRef.current = true;
    setBusy(true);
    setProblem(null);
    setNotice('');
    try {
      const saved = await changeAreaStatus(current.id, target, current.version);
      if (mounted.current) onSaved(saved, `Se ${target ? 'activó' : 'desactivó'} el área “${saved.nombre}”.`);
    } catch (requestError) {
      if (mounted.current) {
        const failure = getAreaProblem(requestError, 'No fue posible confirmar el resultado. Recargue el área antes de volver a intentarlo.');
        if (target && failure.codigo === 'AREA_PADRE_INACTIVA') {
          failure.message = 'Para activar esta área, active primero las áreas de las que depende o modifique su área superior desde Editar.';
        }
        setProblem(failure);
      }
    } finally {
      requestRef.current = false;
      if (mounted.current) setBusy(false);
    }
  };

  return <AreaDialog titleId="area-status-title" descriptionId="area-status-description" busy={busy} onClose={onClose}>
    <DialogHeader title={target ? 'Activar área' : 'Desactivar área'} description={target ? 'Confirme la activación del área seleccionada.' : 'Confirme la desactivación del área seleccionada.'}
      titleId="area-status-title" descriptionId="area-status-description" busy={busy} onClose={onClose} />
    <div className="area-dialog-body">
      <div className="area-status-summary"><strong>{current.nombre}</strong><StatusBadge status={current.activo ? 'ACTIVO' : 'INACTIVO'} /></div>
      <p>{target ? 'El área conservará su información. Las áreas subordinadas y los usuarios asociados no se activarán automáticamente. Las áreas de las que depende deben estar activas.'
        : 'El área conservará su información e historial y podrá reactivarse. La desactivación requiere que no existan áreas subordinadas activas, usuarios activos asociados ni asignaciones en flujos activos.'}</p>
      {problem && <FeedbackMessage tone="error" title={problem.uncertain ? 'No se pudo confirmar el cambio' : 'No se cambió el estado'}>
        <p>{problem.message}</p>
        {problem.dependencias && <ul className="area-dependencies">
          <li>Áreas subordinadas activas: <strong>{problem.dependencias.hijasActivas}</strong></li>
          <li>Usuarios activos: <strong>{problem.dependencias.usuariosActivos}</strong></li>
          <li>Asignaciones en flujos activos: <strong>{problem.dependencias.asignacionesEnFlujosActivos}</strong></li>
        </ul>}
      </FeedbackMessage>}
      {notice && <FeedbackMessage>{notice}</FeedbackMessage>}
      {problem && problem.codigo !== 'AREA_NO_ENCONTRADA' && <div><Button variant="secondary" onClick={refresh} loading={busy}>
        <RefreshCw size={16} aria-hidden="true" />Recargar área
      </Button></div>}
    </div>
    <footer className="area-dialog-footer">
      <Button variant="secondary" onClick={onClose} disabled={busy} data-autofocus>{current.activo === target ? 'Cerrar' : 'Cancelar'}</Button>
      <Button variant={target ? 'primary' : 'danger'} onClick={confirm} loading={busy} disabled={problem?.stale || problem?.uncertain || problem?.denied || current.activo === target || problem?.codigo === 'AREA_NO_ENCONTRADA'}>
        {target ? <Power size={17} aria-hidden="true" /> : <PowerOff size={17} aria-hidden="true" />}{target ? 'Activar área' : 'Desactivar área'}
      </Button>
    </footer>
  </AreaDialog>;
}

export default function AreaManagementPage() {
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(0);
  const [revision, setRevision] = useState(0);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [problem, setProblem] = useState(null);
  const [searchError, setSearchError] = useState('');
  const [success, setSuccess] = useState('');
  const [dialog, setDialog] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setProblem(null);
    setData(null);
    listAreas({ page, size: PAGE_SIZE, q: query, activo: filter === 'all' ? undefined : filter === 'active', signal: controller.signal })
      .then((result) => {
        if (controller.signal.aborted) return;
        if (page > 0 && page >= result.totalPaginas) {
          setPage(Math.max(0, result.totalPaginas - 1));
          return;
        }
        setData(result);
      })
      .catch((requestError) => {
        if (!controller.signal.aborted) setProblem(getAreaProblem(requestError, 'No fue posible cargar las áreas. Vuelva a intentar la carga.'));
      })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [page, query, filter, revision]);

  const applySearch = (event) => {
    event.preventDefault();
    const normalized = stripSpaces(search);
    if (lengthOf(normalized) > 100 || normalized.includes('\u0000')) {
      setSearchError('La búsqueda admite hasta 100 caracteres y no puede contener caracteres nulos.');
      return;
    }
    setSearchError('');
    setQuery(normalized);
    setPage(0);
    setRevision((current) => current + 1);
  };
  const clearFilters = () => {
    setSearch(''); setQuery(''); setFilter('all'); setPage(0); setSearchError('');
  };
  const openDialog = (type, area) => {
    setSuccess('');
    setDialog({ type, area });
  };
  const onSaved = (_area, message) => {
    setDialog(null);
    setSuccess(message);
    setRevision((current) => current + 1);
  };
  const filtered = Boolean(query) || filter !== 'all';
  const total = data?.totalElementos || 0;
  const first = total ? page * PAGE_SIZE + 1 : 0;
  const last = data ? page * PAGE_SIZE + data.contenido.length : 0;

  return <div className="page-container areas-page">
    <PageHeader title="Áreas corporativas" titleId="areas-page-title" eyebrow="Configuración" icon={Building2}
      description="Gestión de áreas corporativas, dependencias jerárquicas y estados."
      actions={<Button onClick={() => openDialog('form')} disabled={problem?.denied}><Plus size={18} aria-hidden="true" />Crear área</Button>} />
    {success && <FeedbackMessage tone="success">{success}</FeedbackMessage>}
    <Card className="areas-list" aria-labelledby="areas-list-title">
      <div className="card-header">
        <div><h3 id="areas-list-title">Catálogo de áreas</h3><p>Ordenado alfabéticamente por nombre.</p></div>
        <Button variant="secondary" onClick={() => setRevision((current) => current + 1)} disabled={loading}>
          <RefreshCw size={16} aria-hidden="true" />Actualizar
        </Button>
      </div>
      <form className="areas-toolbar" onSubmit={applySearch}>
        <div className="areas-search-group">
          <label className="area-filter-label" htmlFor="areas-search">Buscar por nombre</label>
          <div className="areas-search-controls">
            <div className="search-field"><Search size={18} aria-hidden="true" /><input type="search" id="areas-search" value={search}
              onChange={(event) => { setSearch(event.target.value); setSearchError(''); }} placeholder="Nombre del área"
              aria-invalid={Boolean(searchError)} aria-describedby={searchError ? 'areas-search-error' : undefined} /></div>
            <Button type="submit" variant="secondary">Buscar</Button>
          </div>
        </div>
        <FormField label="Estado" htmlFor="areas-state" className="areas-state-filter">
          <DropdownSelect id="areas-state" value={filter} options={[
            { value: 'all', label: 'Todos los estados' }, { value: 'active', label: 'Activas' }, { value: 'inactive', label: 'Inactivas' }
          ]} onChange={(value) => { setFilter(value); setPage(0); }} />
        </FormField>
        {(filtered || search) && <Button variant="quiet" onClick={clearFilters}>Limpiar filtros</Button>}
      </form>
      {searchError && <div className="areas-inline-message"><FeedbackMessage tone="error"><span id="areas-search-error">{searchError}</span></FeedbackMessage></div>}
      {query && <p className="areas-applied-filter">Resultados para “{query}”.</p>}
      <div aria-busy={loading}>
        {loading ? <EmptyState loading title="Cargando áreas…">Consultando el catálogo de la empresa.</EmptyState>
          : problem ? <EmptyState icon={Building2} title="No se pudieron cargar las áreas" tone="error"
            action={<Button variant="secondary" onClick={() => setRevision((current) => current + 1)}>Reintentar</Button>}>
            <span role="alert">{problem.message}</span>
          </EmptyState>
            : !data?.contenido.length ? <EmptyState icon={filtered ? SearchX : Building2} title={filtered ? 'No se encontraron áreas' : 'No hay áreas corporativas registradas'}
              action={filtered ? <Button variant="secondary" onClick={clearFilters}>Limpiar filtros</Button> : <Button onClick={() => openDialog('form')}><Plus size={17} aria-hidden="true" />Crear primera área</Button>}>
              {filtered ? 'Modifique el nombre de búsqueda o el filtro de estado.' : 'Registre la primera área del catálogo corporativo.'}
            </EmptyState>
              : <div className="table-scroll"><DataTable className="table-stackable areas-table" aria-label="Áreas corporativas">
                <thead><tr><th scope="col">Área</th><th scope="col">Área superior</th><th scope="col">Administrador</th><th scope="col">Estado</th><th scope="col">Última actualización</th><th scope="col" className="text-right">Acciones</th></tr></thead>
                <tbody>{data.contenido.map((area) => <tr key={area.id} data-area-name={area.nombre}>
                  <td className="cell-primary cell-wide" data-label="Área"><div className="cell-stack"><strong>{area.nombre}</strong><span className="area-description">{area.descripcion || 'Sin descripción'}</span></div></td>
                  <td data-label="Área superior">{area.areaPadreNombre || 'Nivel principal'}</td>
                  <td data-label="Administrador">
                    {area.administradorNombre ? (
                      <div className="cell-stack">
                        <strong>{area.administradorNombre}</strong>
                        <span className="area-admin-email">{area.administradorEmail}</span>
                      </div>
                    ) : (
                      <span className="cell-empty">Sin administrador</span>
                    )}
                  </td>
                  <td data-label="Estado"><StatusBadge status={area.activo ? 'ACTIVO' : 'INACTIVO'} /></td>
                  <td data-label="Última actualización"><DateTimeStack value={area.updatedAt} /></td>
                  <td className="cell-actions" data-label="Acciones"><div className="row-actions">
                    <Button variant="secondary" className="ui-button--compact" onClick={() => openDialog('form', area)} aria-label={`Editar área ${area.nombre}`}><Edit2 size={15} aria-hidden="true" />Editar</Button>
                    <Button variant={area.activo ? 'quiet' : 'secondary'} className={area.activo ? 'ui-button--compact area-deactivate-button' : 'ui-button--compact'} onClick={() => openDialog('status', area)}
                      aria-label={`${area.activo ? 'Desactivar' : 'Activar'} área ${area.nombre}`}>
                      {area.activo ? <PowerOff size={15} aria-hidden="true" /> : <Power size={15} aria-hidden="true" />}{area.activo ? 'Desactivar' : 'Activar'}
                    </Button>
                  </div></td>
                </tr>)}</tbody>
              </DataTable></div>}
      </div>
      {data && !loading && !problem && <footer className="areas-pagination">
        <p role="status">{total ? `${first}–${last} de ${total} áreas` : '0 áreas'}</p>
        <nav aria-label="Paginación de áreas">
          <Button variant="secondary" onClick={() => setPage((current) => current - 1)} disabled={data.primera || page === 0} aria-label="Página anterior"><ChevronLeft size={17} aria-hidden="true" /></Button>
          <span>{data.totalPaginas ? `Página ${page + 1} de ${data.totalPaginas}` : 'Sin páginas'}</span>
          <Button variant="secondary" onClick={() => setPage((current) => current + 1)} disabled={data.ultima || !data.totalPaginas} aria-label="Página siguiente"><ChevronRight size={17} aria-hidden="true" /></Button>
        </nav>
      </footer>}
    </Card>
    {dialog?.type === 'form' && <AreaFormDialog area={dialog.area} onClose={() => setDialog(null)} onSaved={onSaved} />}
    {dialog?.type === 'status' && <AreaStatusDialog area={dialog.area} onClose={() => { setDialog(null); setRevision((current) => current + 1); }} onSaved={onSaved} />}
  </div>;
}
