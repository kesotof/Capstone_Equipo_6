import api from './api';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function safeDownloadName(value, fallback = 'documento') {
  const name = String(value || '').split(/[\\/]/).pop()
    .replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\\/:*?"<>|]/g, '_')
    .trim().replace(/[. ]+$/, '');
  return name || fallback;
}

function responseFilename(disposition, fallback) {
  const extended = /(?:^|;)\s*filename\*\s*=\s*UTF-8'[^']*'([^;]+)/i.exec(disposition || '');
  if (extended) {
    try { return safeDownloadName(decodeURIComponent(extended[1].trim().replace(/^"|"$/g, '')), fallback); }
    catch { /* Se conserva la alternativa si el header está mal formado. */ }
  }
  const plain = /(?:^|;)\s*filename\s*=\s*(?:"((?:\\.|[^"])*)"|([^;]*))/i.exec(disposition || '');
  const value = plain && (plain[1] ?? plain[2]).replace(/\\(["\\])/g, '$1').trim();
  return value && !/^=\?.+\?=$/.test(value) ? safeDownloadName(value, fallback) : safeDownloadName(fallback);
}

async function decodeError(error) {
  const body = error.response?.data;
  if (body instanceof Blob && body.size <= 65536) {
    try { error.response.data = JSON.parse(await body.text()); } catch { /* Mensaje seguro por estado HTTP. */ }
  }
  return error;
}

export function downloadError(error) {
  const status = error.response?.status;
  const code = error.response?.data?.code || error.response?.data?.codigo;
  if (status === 401) return 'La sesión ha caducado. Vuelve a iniciar sesión para descargar el archivo.';
  if (status === 403) return 'Ya no tienes permiso para descargar este documento. Actualiza la vista o solicita la revisión de tu acceso.';
  if (status === 404) return 'El archivo no está disponible. Contacta a la administración.';
  if (status === 409) return 'La información del archivo requiere revisión. Actualiza la vista o contacta a la administración.';
  if (status === 503) return 'El almacenamiento no está disponible. Intenta descargar nuevamente en unos momentos.';
  if (code === 'DOCUMENT_DOWNLOAD_INCOMPLETE') return 'La descarga se interrumpió. Intenta nuevamente; el archivo incompleto no se guardó.';
  if (error.code === 'ECONNABORTED') return 'La descarga tardó demasiado. Comprueba tu conexión e intenta nuevamente.';
  if (status === 400) return 'La referencia del archivo no es válida. Actualiza la vista.';
  return 'No fue posible descargar el archivo. Comprueba tu conexión e intenta nuevamente.';
}

export async function getDocumentFile({ documentId, solicitudId, fileName }, signal, onProgress) {
  if (documentId != null && !UUID.test(documentId)) throw new Error('Referencia de documento inválida');
  const byDocument = UUID.test(documentId || '');
  if (!byDocument && !UUID.test(solicitudId || '')) throw new Error('Referencia de documento inválida');
  const url = byDocument ? '/api/documents/' + documentId + '/download'
    : '/api/solicitudes/' + solicitudId + '/documento/descargar';
  try {
    const response = await api.get(url, {
      signal, responseType: 'blob', timeout: 60000,
      onDownloadProgress: (event) => {
        if (event.total > 0) onProgress?.(Math.min(99, Math.floor(event.loaded / event.total * 100)));
      }
    });
    const blob = response.data;
    const disposition = response.headers['content-disposition'] || '';
    const type = response.headers['content-type'] || blob?.type || '';
    if (!(blob instanceof Blob) || /application\/problem\+json/i.test(type)
        || !/^\s*attachment(?:;|$)/i.test(disposition)) {
      const invalid = new Error('Respuesta de archivo no válida');
      invalid.response = response;
      throw await decodeError(invalid);
    }
    const length = response.headers['content-length'];
    if (length != null && (!/^\d+$/.test(String(length)) || !Number.isSafeInteger(Number(length)) || Number(length) !== blob.size)) {
      const incomplete = new Error('Transferencia incompleta');
      incomplete.response = { data: { code: 'DOCUMENT_DOWNLOAD_INCOMPLETE' } };
      throw incomplete;
    }
    return { blob, filename: responseFilename(disposition, safeDownloadName(fileName)) };
  } catch (error) {
    throw await decodeError(error);
  }
}

export function deliverDocument({ blob, filename }, onRelease) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  try {
    link.href = url; link.download = filename;
    document.body.appendChild(link); link.click();
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  } finally { link.remove(); }
  let active = true;
  const cleanup = () => {
    if (!active) return;
    active = false; window.clearTimeout(timer); URL.revokeObjectURL(url);
    onRelease?.();
  };
  const timer = window.setTimeout(cleanup, 30000);
  return cleanup;
}
