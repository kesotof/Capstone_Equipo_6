import React from 'react';
import { formatSlaDate, slaPresentation, validSlaDate } from '../../services/sla';

export default function SlaDeadline({ deadline, status, active = true, testIdPrefix = 'sla-badge' }) {
  const presentation = slaPresentation(deadline, status, active);
  return <div className="cell-stack sla-deadline">
    <span className={`badge badge-${presentation.tone}`} title={presentation.description}
      data-testid={`${testIdPrefix}-${presentation.key}`}>{presentation.label}</span>
    {deadline && <small className="sla-deadline-text">
      {active ? 'Vence: ' : 'Fecha límite: '}
      {validSlaDate(deadline) ? <time dateTime={deadline}>{formatSlaDate(deadline)}</time> : 'Fecha no disponible'}
    </small>}
  </div>;
}
