import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ClipboardList, FileEdit, FileText, History, Info, ListChecks, LockKeyhole, MessageSquare } from 'lucide-react';
import { Button, Card, EmptyState, FeedbackMessage, formatDateTime } from '../ui';
import ObservationTimeline from '../ObservationTimeline';
import { allowsAction } from '../../services/rbac';
import { requestAreaLabel } from '../../services/requestDetails';
import { stageLabel } from '../../services/workflowErrors';
import RequestDocuments from './RequestDocuments';
import RequestHistory from './RequestHistory';
import RequestPagination, { REQUEST_PAGE_SIZE } from './RequestPagination';
import SlaDeadline from './SlaDeadline';
import { formatSlaDate, slaContinuityMessage } from '../../services/sla';

const TABS = [
  { id: 'resumen', label: 'Resumen', icon: ClipboardList },
  { id: 'documentos', label: 'Documentos', icon: FileText },
  { id: 'observaciones', label: 'Observaciones', icon: MessageSquare },
  { id: 'historial', label: 'Historial', icon: History }
];

function RestrictedSection() {
  return <EmptyState icon={LockKeyhole} title="Sección restringida">No tiene permiso para consultar esta sección.</EmptyState>;
}

export default function RequestDetailPanel({ detail, loading, error, refresh, requestKey, reviewAllowed, returnTarget }) {
  const [tab, setTab] = useState('resumen');
  const [pages, setPages] = useState({ documentos: 0, observaciones: 0, historial: 0 });
  const tabRefs = useRef({});
  useEffect(() => {
    if (!detail) return;
    const totals = { documentos: detail.documentos.length, observaciones: detail.observaciones.elementos.length, historial: detail.historial.elementos.length };
    setPages((current) => Object.fromEntries(Object.entries(current).map(([section, page]) => [section, Math.min(page, Math.max(0, Math.ceil(totals[section] / REQUEST_PAGE_SIZE) - 1))])));
  }, [detail]);

  const selectTab = (value, focus = false) => { setTab(value); if (focus) tabRefs.current[value]?.focus(); };
  const handleTabKey = (event, value) => {
    const index = TABS.findIndex((item) => item.id === value);
    let next;
    if (event.key === 'ArrowRight') next = (index + 1) % TABS.length;
    if (event.key === 'ArrowLeft') next = (index + TABS.length - 1) % TABS.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = TABS.length - 1;
    if (next !== undefined) { event.preventDefault(); selectTab(TABS[next].id, true); }
  };
  const pageFor = (section, total) => Math.min(pages[section], Math.max(0, Math.ceil(total / REQUEST_PAGE_SIZE) - 1));
  const changePage = (section, page) => {
    setPages((current) => ({ ...current, [section]: page }));
    window.requestAnimationFrame(() => window.document.getElementById(`request-panel-${section}`)?.focus({ preventScroll: true }));
  };

  if (loading) return <Card className="request-section-card" aria-busy="true"><EmptyState loading title="Cargando información de la solicitud…" /></Card>;
  if (error) return <Card className="request-section-card"><EmptyState icon={Info} tone="error" title="Detalle no disponible" action={<Button variant="secondary" onClick={refresh}>Volver a intentar</Button>}>{error}</EmptyState></Card>;
  if (!detail) return null;

  const observations = detail.observaciones.elementos;
  const events = detail.historial.elementos;
  const observationPage = pageFor('observaciones', observations.length);
  const historyPage = pageFor('historial', events.length);
  const terminal = ['APROBADO', 'RECHAZADO'].includes(detail.estado);
  const slaLabel = detail.sla.enRevision ? 'Plazo de revisión' : detail.estado === 'CORRECCION_REQUERIDA' ? 'Plazo original de la solicitud' : 'Fecha límite registrada';
  const restoreReview = returnTarget.pathname === '/revisar-documento' ? returnTarget.state : null;

  return <>
    {detail.estado === 'CORRECCION_REQUERIDA' && <FeedbackMessage tone="warning" className="request-correction-notice" title="Esta solicitud requiere correcciones">Consulte las observaciones de revisión antes de reenviar el documento.<div className="ui-feedback-actions"><Button variant="secondary" className="ui-button--compact" onClick={() => selectTab('observaciones', true)}><MessageSquare size={15} aria-hidden="true" />Ver observaciones</Button>{allowsAction(detail, 'REENVIAR') && <Button as={Link} to={`/corregir-documento?id=${detail.id}`} state={{ requestOrigin: returnTarget }} variant="warning" className="ui-button--compact"><FileEdit size={15} aria-hidden="true" />Corregir documento</Button>}</div></FeedbackMessage>}
    <div className="dashboard-tabs request-detail-tabs" role="tablist" aria-label="Información de la solicitud">
      {TABS.map(({ id, label, icon: Icon }) => <button type="button" key={id} ref={(element) => { tabRefs.current[id] = element; }}
        role="tab" id={`request-tab-${id}`} aria-controls={`request-panel-${id}`} aria-selected={tab === id} tabIndex={tab === id ? 0 : -1}
        className={`dashboard-tab-btn${tab === id ? ' active' : ''}`} onClick={() => selectTab(id)} onKeyDown={(event) => handleTabKey(event, id)}>
        <Icon size={17} aria-hidden="true" />{label}
        {id === 'documentos' && <span className="request-tab-count">{detail.documentos.length}</span>}
        {id === 'observaciones' && detail.observaciones.accesible && <span className="request-tab-count">{observations.length}</span>}
        {id === 'historial' && detail.historial.accesible && <span className="request-tab-count">{events.length}</span>}
      </button>)}
    </div>

    <div id="request-panel-resumen" role="tabpanel" aria-labelledby="request-tab-resumen" hidden={tab !== 'resumen'} tabIndex={0}>
      <div className="request-summary-grid">
        <Card className="request-section-card"><header className="card-header"><h3>Datos de la solicitud</h3></header><div className="request-card-body">
          <dl className="request-metadata"><div><dt>Correlativo</dt><dd>{detail.correlativo || 'Sin correlativo'}</dd></div><div><dt>Emisor</dt><dd>{detail.emisorNombre}</dd></div>
            <div><dt>Área de origen</dt><dd>{requestAreaLabel(detail.areaOrigen)}</dd></div><div><dt>Área de flujo</dt><dd>{requestAreaLabel(detail.areaFlujo, true)}</dd></div>
            <div><dt>Fecha de emisión</dt><dd>{formatDateTime(detail.createdAt)}</dd></div><div><dt>Última actualización</dt><dd>{formatDateTime(detail.updatedAt)}</dd></div>
            <div><dt>Versión documental vigente</dt><dd>{detail.documentoVigente ? `Versión ${detail.documentoVigente.version}` : 'Sin documento vigente'}</dd></div></dl>
          <section className="request-description"><h4>Descripción</h4><p>{detail.descripcion?.trim() ? detail.descripcion : 'Sin descripción.'}</p></section>
        </div></Card>
        <Card className="request-section-card"><header className="card-header"><h3>Seguimiento</h3></header><div className="request-card-body">
          <dl className="request-metadata request-metadata-single"><div><dt>Flujo de aprobación</dt><dd>{detail.flujo?.nombre || 'Flujo no disponible'}</dd></div><div><dt>{terminal ? 'Última etapa' : 'Etapa actual'}</dt><dd>{stageLabel(detail.etapaActual)}</dd></div>
            <div><dt>{slaLabel}</dt><dd><SlaDeadline deadline={detail.sla.deadline} status={detail.sla.status} active={detail.sla.enRevision === true} testIdPrefix="request-sla-badge" /></dd></div>
          </dl>
          {detail.sla.deadline && !detail.sla.enRevision && <p className="request-muted">{slaContinuityMessage(detail.estado)}</p>}
          {detail.sla.enRevision && <p className="request-muted">Por vencer indica menos de 24 horas corridas. Las acciones de revisión siguen disponibles aunque venza el plazo.</p>}
          <p className="request-muted">Información del plazo evaluada el {formatSlaDate(detail.sla.evaluadoEn)}. Actualice el detalle para consultar su estado vigente.</p>
          <div className="row-actions request-operational-actions">
            {reviewAllowed && ['APROBAR', 'RECHAZAR', 'PEDIR_CORRECCION'].some((action) => allowsAction(detail, action)) && <Button as={Link} to={`/revisar-documento?id=${detail.id}`} state={restoreReview} variant="secondary"><ListChecks size={16} aria-hidden="true" />Revisar solicitud</Button>}
            {allowsAction(detail, 'REENVIAR') && <Button as={Link} to={`/corregir-documento?id=${detail.id}`} state={{ requestOrigin: returnTarget }} variant="warning"><FileEdit size={16} aria-hidden="true" />Corregir documento</Button>}
          </div>
        </div></Card>
      </div>
    </div>

    <div id="request-panel-documentos" role="tabpanel" aria-labelledby="request-tab-documentos" hidden={tab !== 'documentos'} tabIndex={0}>
      <RequestDocuments detail={detail} requestKey={requestKey} page={pageFor('documentos', detail.documentos.length)} onPageChange={(page) => changePage('documentos', page)} />
    </div>
    <div id="request-panel-observaciones" role="tabpanel" aria-labelledby="request-tab-observaciones" hidden={tab !== 'observaciones'} tabIndex={0}>
      {!detail.observaciones.accesible ? <Card className="request-section-card"><RestrictedSection /></Card> : !observations.length ? <Card className="request-section-card"><EmptyState icon={MessageSquare} title="Sin observaciones registradas">No hay observaciones de revisión asociadas a la solicitud.</EmptyState></Card> : <Card className="request-section-card request-observations-card">
        <ObservationTimeline observations={observations.slice(observationPage * REQUEST_PAGE_SIZE, (observationPage + 1) * REQUEST_PAGE_SIZE)} mode="consultation" startIndex={observationPage * REQUEST_PAGE_SIZE} totalPending={observations.filter((item) => !item.resuelta).length} />
        <RequestPagination total={observations.length} page={observationPage} onChange={(page) => changePage('observaciones', page)} label="observaciones" />
      </Card>}
    </div>
    <div id="request-panel-historial" role="tabpanel" aria-labelledby="request-tab-historial" hidden={tab !== 'historial'} tabIndex={0}>
      <Card className="request-section-card"><header className="card-header"><div><h3>Historial de la solicitud</h3><p>Eventos registrados en orden cronológico, desde el más antiguo.</p></div></header>
        {!detail.historial.accesible ? <RestrictedSection /> : !events.length ? <EmptyState icon={History} title="Sin eventos registrados">No hay eventos documentales asociados a la solicitud.</EmptyState> : <>
          <RequestHistory events={events.slice(historyPage * REQUEST_PAGE_SIZE, (historyPage + 1) * REQUEST_PAGE_SIZE)} />
          <RequestPagination total={events.length} page={historyPage} onChange={(page) => changePage('historial', page)} label="historial" showLatest />
        </>}
      </Card>
    </div>
  </>;
}
