import React, { useEffect, useId, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, CircleUserRound, KeyRound, LoaderCircle, LogOut } from 'lucide-react';

/** Menú de cuenta de la barra superior: visible cuando el sidebar no muestra la tarjeta de usuario. */
export default function UserMenu({ user, roleLabel, onLogout, loggingOut }) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  const buttonRef = useRef(null);
  const panelId = useId();

  useEffect(() => {
    if (!open) return undefined;
    const handlePointer = (event) => {
      if (!containerRef.current?.contains(event.target)) setOpen(false);
    };
    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setOpen(false);
        buttonRef.current?.focus();
      }
    };
    document.addEventListener('mousedown', handlePointer);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handlePointer);
      document.removeEventListener('keydown', handleKey);
    };
  }, [open]);

  return (
    <div className="user-menu" ref={containerRef}>
      <button
        ref={buttonRef}
        type="button"
        className="user-menu-btn"
        aria-expanded={open}
        aria-controls={panelId}
        aria-label={`Cuenta de ${user.name}`}
        onClick={() => setOpen((value) => !value)}
      >
        <CircleUserRound size={20} aria-hidden="true" />
        <ChevronDown className="user-menu-chevron" size={15} aria-hidden="true" />
      </button>

      {open && (
        <div id={panelId} className="user-menu-panel" role="region" aria-label="Cuenta">
          <div className="user-menu-header">
            <strong title={user.name}>{user.name}</strong>
            {user.email && <span title={user.email}>{user.email}</span>}
            <span className="user-role-badge">{roleLabel}</span>
          </div>
          <div className="user-menu-actions">
            <Link className="user-menu-item" to="/cambiar-contrasena" onClick={() => setOpen(false)}>
              <KeyRound size={17} aria-hidden="true" />
              <span>Cambiar contraseña</span>
            </Link>
            <button className="user-menu-item user-menu-item--danger" type="button" onClick={onLogout} disabled={loggingOut}>
              {loggingOut ? <LoaderCircle className="button-spinner" size={17} aria-hidden="true" /> : <LogOut size={17} aria-hidden="true" />}
              <span>{loggingOut ? 'Cerrando sesión…' : 'Cerrar sesión'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
