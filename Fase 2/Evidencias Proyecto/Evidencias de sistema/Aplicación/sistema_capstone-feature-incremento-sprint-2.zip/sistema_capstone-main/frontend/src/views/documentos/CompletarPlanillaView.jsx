import React from 'react';
import ComingSoon from '../../components/shell/ComingSoon';

export default function CompletarPlanillaView() {
  return (
    <ComingSoon
      title="Completar planilla"
      description="Pronto podrás generar documentos a partir de plantillas preconfiguradas por tu organización, sin tener que adjuntar un archivo."
      features={[
        'Formularios dinámicos según la plantilla seleccionada',
        'Validación de campos antes de enviar a revisión',
        'Generación automática del documento final'
      ]}
    />
  );
}
