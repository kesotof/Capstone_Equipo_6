// Una versión observada pertenece a su recurso: solicitud, definición o documento.
export function hasObservedVersion(resource) {
  return Number.isSafeInteger(resource?.version) && resource.version >= 0;
}

export function requiresWorkflowReload(error) {
  return !error.response || error.response.status === 409 || error.response.status >= 500;
}

export function workflowErrorMessage(error, fallback) {
  const detail = error.response?.data?.detail || error.response?.data?.message;
  if (!error.response || error.response.status >= 500) {
    return `${detail || fallback} No se pudo confirmar el resultado. Actualice el estado antes de realizar otra operación.`;
  }
  return detail || fallback;
}

export function stageLabel(stage) {
  return stage ? `Etapa ${stage.orden}: ${stage.nombre}` : 'Etapa no informada';
}
