import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { Button, FeedbackMessage, FormField } from '../ui';
import { MAX_SLA_DAYS, SLA_CALENDAR_HELP, SLA_FUTURE_HELP, slaErrorMessage, validateSlaForm } from '../../services/sla';

const FOCUSABLE = 'button:not(:disabled), input:not(:disabled), [tabindex="0"]';

export default function SlaRuleDialog({ mode, rule, onClose, onSave }) {
  const [form, setForm] = useState({ tipoDocumento: rule?.tipoDocumento || '', plazoDias: rule?.plazoDias ?? 5 });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [discardNotice, setDiscardNotice] = useState(false);
  const dirty = useRef(false);
  const busyRef = useRef(false);
  const dialogRef = useRef(null);
  const alive = useRef(true);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const creating = mode === 'create';
  const deleting = mode === 'delete';
  const prefix = creating ? 'sla' : 'edit-sla';
  const title = creating ? 'Nueva regla SLA' : deleting ? 'Eliminar regla SLA' : `Editar plazo SLA: ${rule.tipoDocumento}`;
  const change = (field, value) => { dirty.current = true; setDiscardNotice(false); setForm((previous) => ({ ...previous, [field]: value })); setErrors((previous) => ({ ...previous, [field]: undefined, general: undefined })); };

  useEffect(() => {
    alive.current = true;
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    (dialogRef.current?.querySelector(deleting ? '[data-sla-cancel]' : 'input') || dialogRef.current)?.focus();
    const keydown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        if (!busyRef.current) {
          if (!deleting && dirty.current) { setDiscardNotice(true); dialogRef.current?.querySelector('[data-sla-cancel]')?.focus(); }
          else closeRef.current();
        }
      }
      if (event.key !== 'Tab') return;
      const controls = dialogRef.current?.querySelectorAll(FOCUSABLE);
      if (!controls?.length) { event.preventDefault(); dialogRef.current?.focus(); return; }
      const first = controls[0]; const last = controls[controls.length - 1];
      if (!dialogRef.current.contains(document.activeElement) || document.activeElement === dialogRef.current
        || (event.shiftKey && document.activeElement === first) || (!event.shiftKey && document.activeElement === last)) {
        event.preventDefault(); (event.shiftKey ? last : first).focus();
      }
    };
    document.addEventListener('keydown', keydown);
    return () => {
      alive.current = false;
      document.removeEventListener('keydown', keydown);
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, [deleting]);

  useEffect(() => {
    if (Object.values(errors).some(Boolean)) {
      (dialogRef.current?.querySelector('[aria-invalid="true"]') || dialogRef.current?.querySelector('[data-sla-error]'))?.focus();
    }
  }, [errors]);

  const submit = async (event) => {
    event.preventDefault();
    if (busyRef.current) return;
    const validation = deleting ? { errors: {}, payload: undefined } : validateSlaForm(form, creating);
    setErrors(validation.errors);
    if (Object.keys(validation.errors).length) return;
    busyRef.current = true; setBusy(true);
    dialogRef.current?.focus();
    try {
      await onSave(mode, rule?.id, validation.payload);
    } catch (error) {
      if (alive.current) setErrors({ general: slaErrorMessage(error, true) });
    } finally {
      busyRef.current = false;
      if (alive.current) setBusy(false);
    }
  };

  return createPortal(<div className="modal-backdrop" role="presentation">
    <section ref={dialogRef} className="flow-modal-dialog sla-rule-dialog" role="dialog" aria-modal="true"
      aria-labelledby="sla-rule-title" aria-describedby="sla-rule-description" aria-busy={busy} tabIndex={-1}>
      <header className="flow-modal-header"><div><h3 id="sla-rule-title">{title}</h3>
        <p id="sla-rule-description">{deleting ? `Confirme la eliminación de la regla para ${rule.tipoDocumento}.` : 'Defina el plazo máximo para todo el proceso de revisión.'}</p>
      </div><button type="button" className="stage-icon-btn" aria-label="Cerrar diálogo" disabled={busy} onClick={onClose}><X size={18} aria-hidden="true" /></button></header>
      <form onSubmit={submit} noValidate>
        <div className="flow-modal-body">
          {discardNotice && <FeedbackMessage tone="warning">Hay cambios sin guardar. Para cerrar sin guardarlos, seleccione Cancelar.</FeedbackMessage>}
          {errors.general && <div tabIndex={-1} data-sla-error><FeedbackMessage tone="error">{errors.general}</FeedbackMessage></div>}
          {deleting ? <>
            <p>Las nuevas solicitudes usarán las reglas restantes: coincidencia del tipo o título, regla General y, si no existe una coincidencia, cinco días hábiles.</p>
            <FeedbackMessage tone="info">Las solicitudes ya emitidas conservan su fecha límite y su historial.</FeedbackMessage>
          </> : <>
            {creating ? <FormField label="Tipo de documento" htmlFor="sla-tipo" hint="Ej.: Contrato de Servicios u Orden de Compra; independiente del formato PDF o DOCX." hintId="sla-tipo-hint" error={errors.tipoDocumento}>
              <input id="sla-tipo" name="tipoDocumento" required maxLength={100} value={form.tipoDocumento}
                onChange={(event) => change('tipoDocumento', event.target.value)} disabled={busy}
                aria-invalid={Boolean(errors.tipoDocumento)} aria-describedby={`sla-tipo-hint${errors.tipoDocumento ? ' sla-tipo-error' : ''}`} data-testid="sla-tipo-input" />
              {errors.tipoDocumento && <span className="visually-hidden" id="sla-tipo-error">{errors.tipoDocumento}</span>}
            </FormField> : <p>Tipo de documento: <strong>{rule.tipoDocumento}</strong>. Se modifica únicamente el plazo.</p>}
            <FormField label="Plazo máximo en días hábiles" htmlFor={`${prefix}-plazo`} hint="Ingrese días enteros, mayores a cero." hintId={`${prefix}-plazo-hint`} error={errors.plazoDias}>
              <input id={`${prefix}-plazo`} name="plazoDias" type="number" inputMode="numeric" required min={1} max={MAX_SLA_DAYS} step={1}
                value={form.plazoDias} onChange={(event) => change('plazoDias', event.target.value)} disabled={busy}
                aria-invalid={Boolean(errors.plazoDias)} aria-describedby={`${prefix}-plazo-hint${errors.plazoDias ? ` ${prefix}-plazo-error` : ''}`} data-testid={`${prefix}-plazo-input`} />
              {errors.plazoDias && <span className="visually-hidden" id={`${prefix}-plazo-error`}>{errors.plazoDias}</span>}
            </FormField>
            <p className="text-muted">{SLA_CALENDAR_HELP}</p>
            <FeedbackMessage tone="info">{SLA_FUTURE_HELP}</FeedbackMessage>
          </>}
        </div>
        <footer className="flow-modal-footer">
          <Button variant="secondary" disabled={busy} onClick={onClose} data-sla-cancel data-testid={creating ? 'cancel-sla-btn' : deleting ? 'cancel-delete-sla-btn' : 'cancel-edit-sla-btn'}>Cancelar</Button>
          <Button type="submit" variant={deleting ? 'danger' : 'primary'} loading={busy}
            data-testid={creating ? 'submit-sla-btn' : deleting ? 'confirm-delete-sla-btn' : 'submit-edit-sla-btn'}>{busy ? (deleting ? 'Eliminando…' : 'Guardando…') : deleting ? 'Eliminar regla' : creating ? 'Guardar regla' : 'Guardar cambios'}</Button>
        </footer>
      </form>
    </section>
  </div>, document.body);
}
