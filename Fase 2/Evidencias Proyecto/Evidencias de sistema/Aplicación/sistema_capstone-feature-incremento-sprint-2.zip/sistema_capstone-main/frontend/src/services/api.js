import axios from 'axios';
import keycloak from './keycloak';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8081',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para inyectar token JWT de Keycloak en solicitudes salientes
api.interceptors.request.use(
  async (config) => {
    if (keycloak.authenticated && keycloak.token) {
      // Renovar token si expira en menos de 30 segundos
      try {
        await keycloak.updateToken(30);
      } catch (error) {
        if (config.credentialSubject) {
          const sessionError = new Error('La sesión de la cuenta ya no está disponible.');
          sessionError.code = 'ACCOUNT_SESSION_INVALID';
          throw sessionError;
        }
        console.warn('Error renovando token Keycloak', error);
      }
      config.headers.Authorization = `Bearer ${keycloak.token}`;
    }
    if (config.credentialSubject && (!keycloak.authenticated || keycloak.tokenParsed?.sub !== config.credentialSubject)) {
      const sessionError = new Error('La sesión de la cuenta cambió.');
      sessionError.code = 'ACCOUNT_SESSION_INVALID';
      throw sessionError;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use((response) => {
  if (['post', 'put', 'patch', 'delete'].includes(response.config.method)
      && /^\/api\/(solicitudes|requests)(\/|$)/.test(response.config.url)) {
    window.dispatchEvent(new Event('requests:changed'));
  }
  if (response.config.method !== 'get' && /^\/api\/(users|areas|rbac|flujos|workflows)(\/|$)/.test(response.config.url)) {
    if (response.config.url !== '/api/users/me/change-password') window.dispatchEvent(new Event('rbac:changed'));
  }
  return response;
}, (error) => {
  if ([401, 403].includes(error.response?.status) && !error.config?.accessRefresh) {
    window.dispatchEvent(new Event('rbac:denied'));
  }
  return Promise.reject(error);
});

if (typeof window !== 'undefined') {
  window.api = api;
}

export default api;
