import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { FileText } from 'lucide-react';
import { Button } from '../ui';

export default function RequestDetailLink({ id, viewState, children = 'Ver detalle completo', ...props }) {
  const location = useLocation();
  const navigate = useNavigate();
  const origin = {
    pathname: location.pathname,
    search: location.search,
    state: { ...location.state, requestDetailReturn: viewState }
  };
  return <Button as={Link} variant="secondary" {...props} to={`/solicitudes/${id}`}
    state={{ requestOrigin: origin }} onClick={(event) => {
      if (event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {
        navigate(`${origin.pathname}${origin.search}`, { replace: true, state: origin.state });
      }
    }}><FileText size={16} aria-hidden="true" />{children}</Button>;
}
