import { useCallback, useEffect, useRef, useState } from 'react';
import { useAccess } from '../components/access/AccessContext';
import { dashboardError } from '../services/dashboardSummary';

// Lecturas de resumen y bandejas con el mismo ciclo de acceso, cancelación e invalidación.
export default function useDashboardResource(load, selection, enabled, refreshVersion = 0) {
  const { context, revision, refresh: refreshAccess } = useAccess();
  const fingerprint = JSON.stringify(context);
  const key = fingerprint + ':' + selection;
  const [result, setResult] = useState(null);
  const controls = useRef(null);
  const sequence = useRef(0);
  const refresh = useCallback(() => controls.current?.run(), []);

  useEffect(() => {
    if (!enabled) { controls.current = null; return undefined; }
    let alive = true;
    let controller = null;
    let timer = null;
    let inFlight = false;
    let queued = false;
    let failures = 0;
    const cancel = () => {
      window.clearTimeout(timer);
      ++sequence.current;
      controller?.abort();
      controller = null;
      inFlight = false;
      queued = false;
    };
    const schedule = (delay) => {
      window.clearTimeout(timer);
      if (alive && !document.hidden) timer = window.setTimeout(run, delay);
    };
    const run = async () => {
      if (!alive || document.hidden) return;
      if (inFlight) { queued = true; return; }
      window.clearTimeout(timer);
      inFlight = true;
      const request = new AbortController();
      controller = request;
      const requestSequence = ++sequence.current;
      const current = () => alive && !request.signal.aborted && requestSequence === sequence.current;
      setResult((old) => ({ key, data: old?.key === key ? old.data : null,
        error: old?.key === key ? old.error : null, refreshing: true }));
      let retry = true;
      let delay = 30000;
      try {
        const access = await refreshAccess();
        if (!current() || !access || JSON.stringify(access) !== fingerprint) return;
        const data = await load(selection, request.signal);
        if (!current()) return;
        failures = 0;
        setResult({ key, data, error: null, refreshing: false });
      } catch (error) {
        if (!current()) return;
        const failure = dashboardError(error);
        retry = failure.retryable;
        failures += 1;
        delay = Math.min(120000, 30000 * 2 ** Math.min(failures, 2));
        setResult((old) => ({ key, data: !failure.restricted && old?.key === key ? old.data : null,
          error: failure, refreshing: false }));
      } finally {
        if (current()) {
          inFlight = false;
          controller = null;
          if (queued) { queued = false; schedule(0); }
          else if (retry) schedule(delay);
        }
      }
    };
    const visibility = () => {
      if (document.hidden) {
        cancel();
        setResult((old) => old?.key === key ? { ...old, refreshing: false } : old);
      } else run();
    };
    // Quitar agregados previos inmediatamente cuando otra operación revela acceso obsoleto.
    const denied = () => setResult((old) => old?.key === key ? { ...old, data: null } : old);
    const changed = () => {
      cancel();
      setResult(null);
      // AccessProvider renueva el contexto y revision; ese cambio inicia la siguiente lectura.
    };
    controls.current = { run };
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('requests:changed', run);
    window.addEventListener('rbac:denied', denied);
    window.addEventListener('rbac:changed', changed);
    run();
    return () => {
      alive = false;
      cancel();
      controls.current = null;
      document.removeEventListener('visibilitychange', visibility);
      window.removeEventListener('requests:changed', run);
      window.removeEventListener('rbac:denied', denied);
      window.removeEventListener('rbac:changed', changed);
    };
  }, [key, fingerprint, selection, revision, refreshAccess, load, enabled, refreshVersion]);

  const current = enabled && result?.key === key ? result : null;
  return { data: current?.data || null, error: current?.error || null,
    loading: enabled && (!current || (!current.data && !current.error)),
    refreshing: enabled && (current?.refreshing ?? true), stale: Boolean(current?.data && current.error), refresh };
}
