import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { ChevronDown, ChevronLeft, ChevronRight, FileSearch, FilterX, RefreshCw, Search, SearchX, ShieldAlert, SlidersHorizontal } from 'lucide-react';
import { useAccess } from '../../components/access/AccessContext';
import { Button, Card, DataTable, DateTimeStack, DropdownSelect, EmptyState, FeedbackMessage, FileTypeIcon, FormField, PageHeader, StatusBadge, formatFileSize, getStatusLabel } from '../../components/ui';
import DateFilter from '../../components/ui/DateFilter';
import RequestDetailLink from '../../components/requests/RequestDetailLink';
import DocumentDownloadButton from '../../components/documents/DocumentDownloadButton';
import useDocumentSearch from '../../hooks/useDocumentSearch';
import { DOCUMENT_PAGE_SIZE, DOCUMENT_SORT_OPTIONS, DOCUMENT_STATUSES, EMPTY_DOCUMENT_FILTERS, documentFilterErrors, documentFilters, restoreDocumentSearch } from '../../services/documentSearch';
import { requestAreaLabel } from '../../services/requestDetails';
import './DocumentSearchPage.css';

export default function DocumentSearchPage() {
  const location = useLocation();
  const { context } = useAccess();
  const restored = useRef(restoreDocumentSearch(location.state?.requestDetailReturn, context.usuarioId)).current;
  const [draft, setDraft] = useState(restored.draft);
  const [filters, setFilters] = useState(restored.filters);
  const [page, setPage] = useState(restored.page);
  const [sort, setSort] = useState(restored.sort);
  const [filtersOpen, setFiltersOpen] = useState(restored.filtersOpen);
  const [validation, setValidation] = useState({});
  const searchRef = useRef(null);
  const { data, loading, error, catalog, catalogLoading, catalogError, restricted, refresh, refreshCatalog } = useDocumentSearch(filters, page, sort);
  const lastPage = data ? Math.max(0, data.totalPaginas - 1) : page;
  const correctingPage = Boolean(data && page > lastPage);

  useEffect(() => { if (correctingPage) setPage(lastPage); }, [correctingPage, lastPage]);

  const update = (name, value) => {
    setDraft((current) => ({ ...current, [name]: value }));
    setValidation({});
  };
  const submit = (event) => {
    event.preventDefault();
    if (restricted) return;
    const next = documentFilters(draft);
    const errors = documentFilterErrors(next);
    setValidation(errors);
    if (Object.keys(errors).length) {
      if (errors.query) searchRef.current?.focus();
      else setFiltersOpen(true);
      return;
    }
    setDraft(next); setFilters(next); setPage(0);
    refresh();
  };
  const clear = () => {
    setDraft({ ...EMPTY_DOCUMENT_FILTERS }); setFilters({ ...EMPTY_DOCUMENT_FILTERS }); setValidation({}); setPage(0);
    refresh(); searchRef.current?.focus();
  };
  const hasFilters = Object.values(filters).some(Boolean);
  const draftCount = Object.entries(documentFilters(draft)).filter(([name, value]) => name !== 'query' && value).length;
  const pendingDraft = JSON.stringify(documentFilters(draft)) !== JSON.stringify(filters);
  const canClear = Object.values(draft).some(Boolean) || hasFilters;
  const selectedUnavailable = (options, value, label) => value && !options.some((option) => option.value === value)
    ? [...options, { value, label, disabled: true }] : options;
  const typeOptions = selectedUnavailable([{ value: '', label: 'Todos los formatos' }, ...(catalog?.documentTypes || []).map((type) => ({ value: type, label: type }))], draft.documentType, 'Formato seleccionado no disponible');
  const areaOptions = selectedUnavailable([{ value: '', label: 'Todas las áreas disponibles' }, ...(catalog?.areas || []).map((area) => ({ value: String(area.id), label: requestAreaLabel(area) }))], draft.areaId, 'Área seleccionada no disponible');
  const statuses = catalog?.statuses || DOCUMENT_STATUSES;
  const stateOptions = [{ value: '', label: 'Todos los estados' }, ...statuses.map((status) => ({ value: status, label: getStatusLabel(status) }))];
  const viewState = { userId: context.usuarioId, draft, filters, page, sort, filtersOpen };
  const busy = loading || correctingPage;
  const total = data?.totalElementos || 0;
  const applied = [
    filters.query && `Búsqueda: ${filters.query}`,
    filters.documentType && `Formato: ${filters.documentType}`,
    filters.status && getStatusLabel(filters.status),
    filters.areaId && `Área: ${catalog?.areas.some((area) => String(area.id) === filters.areaId) ? requestAreaLabel(catalog.areas.find((area) => String(area.id) === filters.areaId)) : 'selección actual'}`,
    filters.dateFrom && `Desde ${filters.dateFrom.split('-').reverse().join('/')}`,
    filters.dateTo && `Hasta ${filters.dateTo.split('-').reverse().join('/')}`
  ].filter(Boolean);

  return <section className="list-page document-search-page" aria-labelledby="document-search-title">
    <PageHeader eyebrow="Documentos" title="Consultar documentos" titleId="document-search-title" icon={FileSearch}
      description="Encuentra documentos según tu acceso y consulta su información y trazabilidad."
      actions={<Button variant="secondary" onClick={refresh} loading={busy || catalogLoading} disabled={busy || catalogLoading}><RefreshCw size={17} aria-hidden="true" />Actualizar</Button>} />

    <Card className="document-search-filters-card" aria-label="Búsqueda y filtros documentales">
      <form onSubmit={submit} noValidate>
        <div className="document-search-toolbar">
          <label className="search-field document-search-input" htmlFor="document-query">
            <Search size={18} aria-hidden="true" />
            <span className="visually-hidden">Buscar documentos</span>
            <input ref={searchRef} id="document-query" type="search" value={draft.query} onChange={(event) => update('query', event.target.value)} maxLength={200}
              placeholder="Buscar por título, correlativo o archivo" disabled={restricted} aria-describedby="document-query-hint" aria-invalid={Boolean(validation.query)} />
          </label>
          <div className="document-search-toolbar-actions">
            <Button variant="secondary" onClick={() => setFiltersOpen((open) => !open)} aria-expanded={filtersOpen} aria-controls="document-search-advanced" disabled={restricted}>
              <SlidersHorizontal size={17} aria-hidden="true" />Filtros{draftCount > 0 && <span className="filter-chip-count" aria-label={`${draftCount} seleccionados`}>{draftCount}</span>}
              <ChevronDown className={filtersOpen ? 'document-search-chevron-open' : ''} size={16} aria-hidden="true" />
            </Button>
            <Button type="submit" disabled={restricted}><Search size={17} aria-hidden="true" />Buscar</Button>
            <Button variant="quiet" onClick={clear} disabled={!canClear || restricted}><FilterX size={17} aria-hidden="true" />Limpiar filtros</Button>
          </div>
        </div>
        <p id="document-query-hint" className="document-search-hint">Busca por título, descripción, correlativo, nombre de archivo o emisor. Los filtros se aplican al buscar.</p>
        {validation.query && <FeedbackMessage tone="error">{validation.query}</FeedbackMessage>}
        <div id="document-search-advanced" hidden={!filtersOpen} className="document-search-advanced" role="region" aria-label="Filtros avanzados">
          {catalogError && !restricted && <FeedbackMessage tone="error" className="document-search-catalog-error">{catalogError.message}<Button variant="quiet" onClick={refreshCatalog} loading={catalogLoading}>Volver a cargar filtros</Button></FeedbackMessage>}
          {catalogLoading && <p className="document-search-hint" role="status">Cargando opciones de filtros…</p>}
          <div className="document-search-filter-grid">
            <FormField label="Formato de documento" htmlFor="document-type" error={validation.documentType}>
              <DropdownSelect id="document-type" name="documentType" value={draft.documentType} options={typeOptions} onChange={(value) => update('documentType', value)} disabled={!catalog || restricted} />
            </FormField>
            <FormField label="Área" htmlFor="document-area" error={validation.areaId}>
              <DropdownSelect id="document-area" name="areaId" value={draft.areaId} options={areaOptions} onChange={(value) => update('areaId', value)} disabled={!catalog || restricted} />
            </FormField>
            <FormField label="Estado" htmlFor="document-status" error={validation.status}>
              <DropdownSelect id="document-status" name="status" value={draft.status} options={stateOptions} onChange={(value) => update('status', value)} disabled={restricted} />
            </FormField>
          </div>
          <fieldset className="document-search-date-range" aria-describedby="document-date-hint">
            <legend>Fecha de emisión</legend>
            <div className="document-search-date-fields">
              <DateFilter label="Desde" name="dateFrom" id="document-date-from" value={draft.dateFrom} max={draft.dateTo || undefined} onChange={update} disabled={restricted} />
              <DateFilter label="Hasta" name="dateTo" id="document-date-to" value={draft.dateTo} min={draft.dateFrom || undefined} onChange={update} disabled={restricted} />
            </div>
            <p id="document-date-hint" className="document-search-hint">El rango incluye ambos días, según la hora de Chile.</p>
            {(validation.dateFrom || validation.dateTo) && <FeedbackMessage tone="error">{validation.dateFrom || validation.dateTo}</FeedbackMessage>}
          </fieldset>
        </div>
        {pendingDraft && <p className="document-search-pending" role="status">Hay cambios en los filtros. Selecciona Buscar para aplicarlos.</p>}
      </form>
    </Card>

    <Card className="document-search-results" aria-labelledby="document-results-title" aria-busy={busy}>
      <div className="card-header document-search-results-header">
        <div><h3 id="document-results-title">Resultados</h3><p role="status">{busy ? 'Consultando documentos…' : error ? 'Consulta no disponible' : `${total} ${total === 1 ? 'documento disponible' : 'documentos disponibles'}`}</p></div>
        <FormField label="Ordenar por" htmlFor="document-sort" className="document-search-sort">
          <DropdownSelect id="document-sort" value={sort} options={DOCUMENT_SORT_OPTIONS} onChange={(value) => { setSort(value); setPage(0); }} disabled={restricted} />
        </FormField>
      </div>
      {!restricted && applied.length > 0 && <ul className="document-search-applied" aria-label="Filtros de la consulta actual">{applied.map((label) => <li key={label}>{label}</li>)}</ul>}
      {restricted ? <EmptyState icon={ShieldAlert} title="Acceso no disponible" action={<Button variant="secondary" onClick={refresh}>Actualizar acceso</Button>}>{error?.message || 'La consulta documental no está disponible con los permisos actuales.'}</EmptyState>
        : busy ? <EmptyState loading title="Buscando documentos…" role="status" />
          : error ? <EmptyState icon={SearchX} title="No fue posible cargar los resultados" action={<Button variant="secondary" onClick={refresh}>Volver a intentar</Button>}>{error.message}</EmptyState>
            : !data?.contenido.length ? <EmptyState icon={SearchX} title={hasFilters ? 'Sin resultados' : 'No hay documentos disponibles'}
              action={hasFilters && <Button variant="secondary" onClick={clear}><FilterX size={16} aria-hidden="true" />Limpiar filtros</Button>}>
              {hasFilters ? 'Ningún documento disponible coincide con los criterios de búsqueda.' : 'Los documentos disponibles según tu acceso aparecerán en esta vista.'}
            </EmptyState>
              : <div className="table-scroll"><DataTable className="table-stackable document-search-table">
                <caption className="visually-hidden">Documentos disponibles según tu acceso. Selecciona Ver detalle para consultar una solicitud.</caption>
                <thead><tr><th scope="col">Documento</th><th scope="col">Emisor</th><th scope="col">Áreas</th><th scope="col">Estado</th><th scope="col">Emisión</th><th scope="col"><span className="visually-hidden">Acciones</span></th></tr></thead>
                <tbody>{data.contenido.map((document) => <tr key={document.id}>
                  <td className="cell-primary" data-label="Documento"><div className="cell-with-icon"><FileTypeIcon fileName={document.nombreArchivo} /><div className="cell-stack">
                    <span className={`correlative-tag${document.correlativo ? '' : ' correlative-tag--empty'}`}>{document.correlativo || 'Sin correlativo'}</span>
                    <strong>{document.titulo}</strong><span>{document.nombreArchivo}</span><span>{document.documentType} · Versión {document.version}{document.sizeBytes != null ? ` · ${document.sizeBytes === 0 ? '0 KB' : formatFileSize(document.sizeBytes)}` : ''}</span>
                  </div></div></td>
                  <td data-label="Emisor"><span className="document-search-person">{document.emisorNombre || 'Usuario no disponible'}</span></td>
                  <td data-label="Áreas"><dl className="document-search-areas"><div><dt>Origen</dt><dd>{requestAreaLabel(document.areaOrigen)}</dd></div><div><dt>Flujo</dt><dd>{requestAreaLabel(document.areaFlujo, true)}</dd></div></dl></td>
                  <td data-label="Estado"><StatusBadge status={document.estado} /></td>
                  <td data-label="Emisión"><DateTimeStack value={document.createdAt} timeZone="America/Santiago" /></td>
                  <td data-label="Acciones" className="cell-actions"><div className="row-actions"><RequestDetailLink id={document.solicitudId} viewState={viewState} className="ui-button--compact" aria-label={`Ver detalle de ${document.titulo}`}>Ver detalle</RequestDetailLink>
                    <DocumentDownloadButton documentId={document.id} solicitudId={document.solicitudId} fileName={document.nombreArchivo}
                      allowed={Boolean(document.descargaUrl)} compact />
                  </div></td>
                </tr>)}</tbody>
              </DataTable></div>}
      {!error && !restricted && <footer className="document-search-pagination">
        <p>{busy ? 'Actualizando resultados…' : total ? `${page * DOCUMENT_PAGE_SIZE + 1}–${Math.min(page * DOCUMENT_PAGE_SIZE + data.contenido.length, total)} de ${total} documentos` : '0 documentos'}</p>
        <nav aria-label="Paginación de documentos">
          <Button variant="secondary" onClick={() => setPage((current) => Math.max(0, current - 1))} disabled={busy || !data || data.primera || page === 0}><ChevronLeft size={16} aria-hidden="true" />Anterior</Button>
          <span>{busy ? 'Cargando página…' : data?.totalPaginas ? `Página ${page + 1} de ${data.totalPaginas}` : 'Sin páginas'}</span>
          <Button variant="secondary" onClick={() => setPage((current) => current + 1)} disabled={busy || !data || data.ultima || page >= lastPage}>Siguiente<ChevronRight size={16} aria-hidden="true" /></Button>
        </nav>
      </footer>}
    </Card>
  </section>;
}
