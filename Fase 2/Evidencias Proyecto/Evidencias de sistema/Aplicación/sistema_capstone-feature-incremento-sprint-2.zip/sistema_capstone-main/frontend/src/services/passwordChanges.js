import api from './api';
import keycloak from './keycloak';

const FIELD_NAMES = ['currentPassword', 'newPassword', 'confirmPassword'];
const MESSAGES = {
  CURRENT_PASSWORD_INVALID: 'La contraseña actual es incorrecta, inténtelo nuevamente.',
  PASSWORD_VALIDATION_FAILED: 'Revise los campos de contraseña.',
  PASSWORD_POLICY_REJECTED: 'La nueva contraseña no cumple la política de seguridad de la cuenta.',
  PASSWORD_CHANGE_BUSY: 'Ya hay un cambio de contraseña en curso. Espere a que termine.',
  PASSWORD_CHANGE_REAUTH_REQUIRED: 'La cuenta requiere completar una verificación adicional para cambiar la contraseña.',
  PASSWORD_ACCOUNT_LOCKED: 'La cuenta está bloqueada temporalmente por intentos fallidos. Inténtelo cuando finalice el bloqueo.',
  IDENTITY_PROVIDER_UNAVAILABLE: 'No fue posible verificar la seguridad de la cuenta. Inténtelo más tarde.',
  PASSWORD_CHANGE_UNCERTAIN: 'No fue posible confirmar el resultado del cambio. Compruebe su acceso con la nueva contraseña antes de volver a intentarlo.'
};

export async function getPasswordPolicy(signal, subject) {
  const { data } = await api.get('/api/auth/password-policy', { signal, timeout: 20000, credentialSubject: subject });
  const numbers = ['minLength', 'maxLength', 'minUppercase', 'minLowercase', 'minDigits', 'minSpecial'];
  const booleans = ['notUsername', 'notEmail', 'additionalRules'];
  if (!data || numbers.some((key) => !Number.isInteger(data[key]) || data[key] < 0 || data[key] > 1024)
      || booleans.some((key) => typeof data[key] !== 'boolean')
      || data.minLength < 8 || data.maxLength < data.minLength
      || typeof data.username !== 'string' || (data.email !== null && typeof data.email !== 'string')) {
    throw new Error('No fue posible cargar los requisitos de seguridad de la cuenta.');
  }
  if (keycloak.tokenParsed?.sub !== subject) throw new Error('La sesión de la cuenta cambió.');
  return data;
}

function safeChangeError(error) {
  const code = error.response?.data?.code;
  const status = error.response?.status;
  const sessionInvalid = error.code === 'ACCOUNT_SESSION_INVALID' || [401, 403].includes(status);
  const uncertain = !sessionInvalid && (code === 'PASSWORD_CHANGE_UNCERTAIN'
    || (status >= 500 && code !== 'IDENTITY_PROVIDER_UNAVAILABLE')
    || (!status && error.code !== 'ERR_CANCELED'));
  const message = sessionInvalid
    ? 'La sesión ya no está disponible. Inicie sesión nuevamente para continuar.'
    : uncertain ? MESSAGES.PASSWORD_CHANGE_UNCERTAIN
      : MESSAGES[code] || 'No fue posible cambiar la contraseña. Revise los campos e inténtelo más tarde.';
  const result = new Error(message);
  result.code = sessionInvalid ? 'ACCOUNT_SESSION_INVALID' : uncertain ? 'PASSWORD_CHANGE_UNCERTAIN' : code;
  result.cancelled = error.code === 'ERR_CANCELED';
  result.uncertain = uncertain;
  result.fields = {};
  const invalid = error.response?.data?.invalidFields;
  if (invalid && typeof invalid === 'object') {
    for (const key of FIELD_NAMES) {
      if (typeof invalid[key] === 'string' && invalid[key].length <= 250) result.fields[key] = invalid[key];
    }
  }
  if (code === 'CURRENT_PASSWORD_INVALID') result.fields.currentPassword = MESSAGES.CURRENT_PASSWORD_INVALID;
  return result;
}

export async function changeOwnPassword(fields, signal, subject) {
  const body = Object.fromEntries(FIELD_NAMES.map((key) => [key, fields[key]]));
  let response;
  try {
    response = await api.post('/api/auth/change-password', body, {
      signal, timeout: 90000, credentialSubject: subject
    });
    if (response.status !== 200 || response.data?.message !== 'Contraseña actualizada exitosamente') {
      const error = new Error(MESSAGES.PASSWORD_CHANGE_UNCERTAIN);
      error.code = 'PASSWORD_CHANGE_UNCERTAIN';
      error.uncertain = true;
      error.fields = {};
      throw error;
    }
    return { message: response.data.message };
  } catch (error) {
    const safe = error.uncertain ? error : safeChangeError(error);
    if (error.config) error.config.data = undefined;
    throw safe;
  } finally {
    for (const key of FIELD_NAMES) body[key] = '';
    if (response?.config) response.config.data = undefined;
  }
}

export function passwordRequirements(password, policy) {
  if (!policy) return [];
  const count = (expression) => password.split('').filter((character) => expression.test(character)).length;
  const rules = [
    { key: 'length', label: `Al menos ${policy.minLength} caracteres`, met: password.length >= policy.minLength },
    { key: 'maximum', label: `Hasta ${policy.maxLength} caracteres`, met: password.length > 0 && password.length <= policy.maxLength }
  ];
  for (const [key, min, expression, singular, plural] of [
    ['uppercase', policy.minUppercase, /\p{Uppercase}/u, 'mayúscula', 'mayúsculas'],
    ['lowercase', policy.minLowercase, /\p{Lowercase}/u, 'minúscula', 'minúsculas'],
    ['digits', policy.minDigits, /\p{Nd}/u, 'número', 'números'],
    ['special', policy.minSpecial, /[^\p{L}\p{Nd}]/u, 'carácter especial', 'caracteres especiales']
  ]) {
    if (min > 0) rules.push({ key, label: `Al menos ${min} ${min === 1 ? singular : plural}`, met: count(expression) >= min });
  }
  if (policy.notUsername) rules.push({ key: 'username', label: 'Diferente de su nombre de usuario', met: !!password && password !== policy.username });
  if (policy.notEmail) rules.push({ key: 'email', label: 'Diferente de su correo electrónico', met: !!password && password !== policy.email });
  return rules;
}

export function passwordStrength(password) {
  if (!password) return { score: 0, label: 'Sin evaluar' };
  const groups = [/\p{Lu}/u, /\p{Ll}/u, /\p{Nd}/u, /[^\p{L}\p{N}]/u].filter((pattern) => pattern.test(password)).length;
  let score = password.length < 8 ? 1 : Math.min(4, 1 + (password.length >= 12 ? 1 : 0) + (password.length >= 16 ? 1 : 0) + (groups >= 3 ? 1 : 0));
  if (new Set(password).size < 4) score = 1;
  return { score, label: ['Sin evaluar', 'Débil', 'Aceptable', 'Buena', 'Fuerte'][score] };
}

export function validatePasswordForm(fields, policy) {
  const errors = {};
  if (!fields.currentPassword.trim()) errors.currentPassword = 'La contraseña actual es obligatoria.';
  if (!fields.newPassword.trim()) errors.newPassword = 'La nueva contraseña es obligatoria.';
  else if (passwordRequirements(fields.newPassword, policy).some((rule) => !rule.met)) errors.newPassword = 'La nueva contraseña no cumple los requisitos de seguridad.';
  else if (fields.newPassword === fields.currentPassword) errors.newPassword = 'La nueva contraseña debe ser diferente de la actual.';
  if (!fields.confirmPassword.trim()) errors.confirmPassword = 'Confirme su nueva contraseña.';
  else if (fields.confirmPassword !== fields.newPassword) errors.confirmPassword = 'Las contraseñas no coinciden.';
  return errors;
}
