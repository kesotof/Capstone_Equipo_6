import {
  Activity, Building2, ClipboardList, FilePlus2, FileSearch, FolderOpen, KeyRound, LayoutDashboard,
  ListChecks, PanelsTopLeft, RotateCcw, Settings2, Users
} from 'lucide-react';

// Única fuente de la navegación: el sidebar, el breadcrumb y los permisos de cada enlace salen de aquí.
export const NAV_SECTIONS = [
  {
    title: 'Principal',
    items: [{ to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }]
  },
  {
    title: 'Documentos',
    items: [
      { to: '/nuevo-documento', label: 'Nuevo documento', icon: FilePlus2, permission: 'SOLICITUD_CREAR' },
      { to: '/mis-documentos', label: 'Mis documentos', icon: FolderOpen, permission: 'SOLICITUD_CONSULTAR' },
      { to: '/consultar-documentos', label: 'Consultar documentos', icon: FileSearch, permission: 'SOLICITUD_CONSULTAR' },
      { to: '/completar-planilla', label: 'Completar planilla', icon: ClipboardList, permission: 'SOLICITUD_CREAR', upcoming: true }
    ]
  },
  {
    title: 'Flujos de aprobación',
    items: [
      { to: '/revisar-documento', label: 'Revisar documento', icon: ListChecks, permission: 'REVISION_CONSULTAR' },
      { to: '/corregir-documento', label: 'Corregir documento', icon: RotateCcw, permission: 'SOLICITUD_REENVIAR' },
      { to: '/estado-solicitudes', label: 'Estado de solicitudes', icon: Activity, permission: 'SOLICITUD_CONSULTAR' }
    ]
  },
  {
    title: 'Configuración',
    items: [
      { to: '/configurar-org-usuarios', label: 'Organización y usuarios', icon: Users, permission: 'USUARIO_GESTIONAR' },
      { to: '/configurar-areas', label: 'Áreas corporativas', icon: Building2, permission: 'AREA_GESTIONAR' },
      { to: '/configurar-flujos', label: 'Configurar flujos', icon: Settings2, permission: 'FLUJO_GESTIONAR' },
      { to: '/configurar-planillas', label: 'Configurar planillas', icon: PanelsTopLeft, permission: 'FLUJO_GESTIONAR', upcoming: true }
    ]
  },
  {
    title: 'Cuenta',
    items: [{ to: '/cambiar-contrasena', label: 'Cambiar contraseña', icon: KeyRound }]
  }
];

const EXTRA_TITLES = {
  '/recuperar-password': ['Cuenta', 'Recuperar contraseña']
};

/** Devuelve [sección, página] para la ruta actual; por defecto, el dashboard. */
export function getRouteTitle(pathname) {
  if (pathname.startsWith('/solicitudes/')) return ['Flujos de aprobación', 'Detalle de solicitud'];
  if (EXTRA_TITLES[pathname]) return EXTRA_TITLES[pathname];
  for (const section of NAV_SECTIONS) {
    const item = section.items.find((entry) => entry.to === pathname);
    if (item) return [section.title, item.label];
  }
  return ['Principal', 'Dashboard'];
}
