import React from 'react';
import { Link } from 'react-router-dom';
import { KeyRound } from 'lucide-react';
import { Button } from '../../components/ui';
import ComingSoon from '../../components/shell/ComingSoon';

export default function RecuperarPasswordView() {
  return (
    <ComingSoon
      badge="Gestionado por el acceso"
      title="Recuperar contraseña"
      description="La recuperación de credenciales se gestiona a través del flujo de restablecimiento de contraseña de la pantalla de inicio de sesión. Si ya iniciaste sesión, puedes cambiarla directamente."
      action={(
        <Button as={Link} to="/cambiar-contrasena">
          <KeyRound size={16} aria-hidden="true" />
          <span>Cambiar contraseña</span>
        </Button>
      )}
    />
  );
}
