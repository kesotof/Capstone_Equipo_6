import React from 'react';
import { DropdownSelect, FeedbackMessage, FormField } from '../ui';

export const assignmentAvailable = (stage, options) => stage.tipoAsignacion === 'ROL_DEPARTAMENTAL'
  ? options.roles.some((role) => String(role.id) === stage.rolRevisorId && role.cantidadUsuarios > 0)
  : options.usuarios.some((user) => String(user.id) === stage.revisorId);

export const assignmentPayload = (stage) => ({
  tipoAsignacion: stage.tipoAsignacion || 'USUARIO',
  revisorId: stage.tipoAsignacion === 'ROL_DEPARTAMENTAL' ? null : stage.revisorId || null,
  rolRevisorId: stage.tipoAsignacion === 'ROL_DEPARTAMENTAL' && stage.rolRevisorId ? Number(stage.rolRevisorId) : null,
});

export const assignmentLabel = (stage) => stage.tipoAsignacion === 'ROL_DEPARTAMENTAL'
  ? `Rol departamental: ${stage.rolRevisorNombre || 'No disponible'}`
  : stage.revisorNombre || stage.revisorEmail || 'Sin responsable disponible';

export default function ReviewerSelector({ id, value, onChange, options, areaNombre, loading, disabled, catalogError }) {
  const departmental = value.tipoAsignacion === 'ROL_DEPARTAMENTAL';
  const selectedId = departmental ? value.rolRevisorId : value.revisorId;
  const available = assignmentAvailable(value, options);
  const selectedRole = options.roles.find((role) => String(role.id) === value.rolRevisorId);
  const entries = departmental ? options.roles : options.usuarios;
  const selectionOptions = entries.map((entry) => ({
    value: String(entry.id),
    label: departmental ? `${entry.nombre} · ${entry.cantidadUsuarios} ${entry.cantidadUsuarios === 1 ? 'revisor' : 'revisores'}`
      : entry.nombre && entry.email && entry.nombre !== entry.email ? `${entry.nombre} · ${entry.email}` : entry.nombre || entry.email,
  }));
  if (selectedId && !available) selectionOptions.push({
    value: selectedId, label: `${departmental ? value.rolRevisorNombre || 'Rol actual' : value.revisorNombre || 'Responsable actual'} · No disponible`, disabled: true,
  });
  const locked = disabled || loading || Boolean(catalogError);

  return <div className="reviewer-selector">
    <div className="reviewer-selector-fields">
      <FormField label="Asignar revisión a *" htmlFor={`${id}-type`}>
        <DropdownSelect id={`${id}-type`} value={value.tipoAsignacion || 'USUARIO'} disabled={locked}
          onChange={(type) => onChange({ ...value, tipoAsignacion: type, revisorId: '', rolRevisorId: '' })}
          options={[{ value: 'USUARIO', label: 'Usuario específico' }, { value: 'ROL_DEPARTAMENTAL', label: 'Rol departamental', disabled: !areaNombre }]} />
      </FormField>
      <FormField label={departmental ? 'Rol responsable *' : 'Usuario responsable *'} htmlFor={`${id}-assignee`}>
        <DropdownSelect id={`${id}-assignee`} value={selectedId || ''} disabled={locked} aria-describedby={`${id}-availability`}
          onChange={(selected) => onChange({ ...value, [departmental ? 'rolRevisorId' : 'revisorId']: selected })}
          options={[{ value: '', label: loading ? 'Cargando responsables…' : departmental ? 'Seleccione un rol' : 'Seleccione un usuario' }, ...selectionOptions]} />
      </FormField>
    </div>
    {!areaNombre && <p className="reviewer-selector-hint">La asignación por rol departamental requiere un flujo asociado a un área corporativa.</p>}
    <div id={`${id}-availability`} aria-live="polite">
      {loading ? <p className="reviewer-selector-hint">Comprobando responsables disponibles…</p> : catalogError
        ? <FeedbackMessage tone="error">No se puede comprobar la disponibilidad de responsables. Actualice el catálogo antes de guardar.</FeedbackMessage>
        : !available ? <FeedbackMessage tone={selectedId ? 'warning' : 'error'}>{selectedId
          ? 'La asignación actual no está disponible para esta etapa. Seleccione otra opción autorizada.'
          : departmental && !options.roles.length ? 'No hay roles con revisores disponibles en esta área. Seleccione un usuario disponible o revise los roles departamentales.'
            : 'Esta etapa no tiene responsable. Asigne un usuario o rol disponible para guardar y activar el flujo.'}</FeedbackMessage>
          : selectedRole ? <div className="reviewer-role-summary"><strong>{areaNombre} · {selectedRole.cantidadUsuarios} {selectedRole.cantidadUsuarios === 1 ? 'revisor disponible' : 'revisores disponibles'}</strong>
            <p>Cualquiera de los responsables autorizados puede atender la etapa. La primera decisión válida determina su avance.</p>
            <ul aria-label="Usuarios disponibles del rol">{selectedRole.usuarios.map((user) => <li key={user.id}>{user.nombre}</li>)}</ul>
          </div> : <p className="reviewer-selector-hint reviewer-selector-hint--available">Usuario disponible para revisar esta etapa.</p>}
    </div>
  </div>;
}
