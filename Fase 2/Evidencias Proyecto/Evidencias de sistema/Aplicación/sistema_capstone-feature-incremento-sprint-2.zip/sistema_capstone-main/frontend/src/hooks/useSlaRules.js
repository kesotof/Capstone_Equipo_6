import { useCallback, useEffect, useRef, useState } from 'react';
import { slaErrorMessage } from '../services/sla';

const INITIAL = { rules: [], loading: true, loaded: false, error: '' };

export default function useSlaRules(client, accessKey) {
  const [state, setState] = useState(INITIAL);
  const pending = useRef(null);
  const generation = useRef(0);
  const alive = useRef(false);
  const refresh = useCallback(async () => {
    pending.current?.abort();
    const controller = new AbortController();
    pending.current = controller;
    const ticket = ++generation.current;
    const current = () => alive.current && ticket === generation.current && !controller.signal.aborted;
    setState((previous) => ({ ...previous, loading: true, error: '' }));
    try {
      const rules = await client.list(controller.signal);
      if (current()) setState({ rules, loading: false, loaded: true, error: '' });
    } catch (error) {
      if (current()) setState((previous) => ({ ...previous, loading: false,
        ...( [401, 403].includes(error.response?.status) ? { rules: [], loaded: false } : {} ),
        error: slaErrorMessage(error) }));
    }
  }, [client]);

  useEffect(() => {
    alive.current = true;
    setState(INITIAL);
    void refresh();
    return () => { alive.current = false; generation.current += 1; pending.current?.abort(); };
  }, [accessKey, refresh]);

  return { ...state, refresh };
}
