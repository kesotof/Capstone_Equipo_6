import React, { useRef, useState } from 'react';
import { KeyRound, CheckCircle2, XCircle, ShieldCheck, Check, AlertCircle } from 'lucide-react';
import api from '../../services/api';
import { Button, FormField, PageHeader } from '../../components/ui';
import './CambiarPasswordView.css';

export default function CambiarPasswordView() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const submittingRef = useRef(false);

  // Reglas de complejidad para feedback visual
  const hasMinLength = newPassword.length >= 8;
  const hasUpperCase = /[A-Z]/.test(newPassword);
  const hasLowerCase = /[a-z]/.test(newPassword);
  const hasDigit = /[0-9]/.test(newPassword);
  const passwordsMatch = newPassword.length > 0 && newPassword === confirmPassword;

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (submittingRef.current || isSubmitting) return;

    setErrorMessage('');
    setSuccessMessage('');

    // CA 13.1: Validar que se ingrese contraseña actual
    if (!currentPassword) {
      setErrorMessage('El usuario debe ingresar su contraseña actual antes de realizar el cambio.');
      return;
    }

    // CA 13.2: Validar nueva contraseña y confirmación
    if (!newPassword || !confirmPassword) {
      setErrorMessage('Debe ingresar una nueva contraseña y confirmarla.');
      return;
    }

    // CA 13.5: Validar coincidencia de contraseñas nuevas
    if (newPassword !== confirmPassword) {
      setErrorMessage('Las contraseñas no coinciden.');
      return;
    }

    // CA 13.4: Requisitos mínimos de seguridad
    if (!hasMinLength || !hasUpperCase || !hasLowerCase || !hasDigit) {
      setErrorMessage('La nueva contraseña debe tener al menos 8 caracteres, incluyendo al menos una letra mayúscula, una minúscula y un número.');
      return;
    }

    submittingRef.current = true;
    setIsSubmitting(true);

    try {
      const response = await api.post('/api/users/me/change-password', {
        currentPassword,
        newPassword,
        confirmNewPassword: confirmPassword
      });

      setSuccessMessage(response.data?.message || 'Contraseña actualizada exitosamente.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      const detail = err.response?.data?.detail || err.response?.data?.message;
      if (detail) {
        setErrorMessage(detail);
      } else if (err.response?.status === 400) {
        setErrorMessage('La contraseña actual es incorrecta, inténtelo nuevamente.');
      } else {
        setErrorMessage('No fue posible cambiar la contraseña. Inténtelo nuevamente.');
      }
    } finally {
      submittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  return (
    <section className="view-container cambiar-password-view" aria-labelledby="change-password-title">
      <PageHeader
        eyebrow="Seguridad de la cuenta"
        title="Cambiar contraseña"
        titleId="change-password-title"
        icon={KeyRound}
        description="Actualiza tu clave de acceso. Recuerda que debe cumplir con los requisitos mínimos de seguridad establecidos por el sistema."
      />

      <div className="cambiar-password-layout">
        <div className="cambiar-password-card">
          <form onSubmit={handleSubmit} noValidate className="cambiar-password-form">
            {errorMessage && (
              <div className="form-message form-message-error" role="alert" data-testid="change-password-error">
                <XCircle size={18} aria-hidden="true" />
                <div className="ui-feedback-content">
                  <span>{errorMessage}</span>
                </div>
              </div>
            )}

            {successMessage && (
              <div className="form-message form-message-success" role="status" data-testid="change-password-success">
                <CheckCircle2 size={18} aria-hidden="true" />
                <div className="ui-feedback-content">
                  <span>{successMessage}</span>
                </div>
              </div>
            )}

            <div className="cambiar-password-fields">
              <FormField
                label="Contraseña actual"
                htmlFor="current-password"
                hint="Ingresa tu clave actual para verificar tu identidad."
              >
                <input
                  id="current-password"
                  name="currentPassword"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Tu contraseña actual"
                  autoComplete="current-password"
                  disabled={isSubmitting}
                  data-testid="current-password-input"
                />
              </FormField>

              <FormField
                label="Nueva contraseña"
                htmlFor="new-password"
                hint="Mínimo 8 caracteres, al menos 1 mayúscula, 1 minúscula y 1 número."
              >
                <input
                  id="new-password"
                  name="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Tu nueva contraseña"
                  autoComplete="new-password"
                  disabled={isSubmitting}
                  data-testid="new-password-input"
                />
              </FormField>

              <FormField
                label="Confirmar nueva contraseña"
                htmlFor="confirm-password"
                hint="Vuelve a ingresar la nueva contraseña para confirmar."
              >
                <input
                  id="confirm-password"
                  name="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repite la nueva contraseña"
                  autoComplete="new-password"
                  disabled={isSubmitting}
                  data-testid="confirm-password-input"
                />
              </FormField>
            </div>

            <div className="cambiar-password-actions">
              <Button
                type="submit"
                variant="primary"
                data-testid="change-password-submit"
                loading={isSubmitting}
                disabled={isSubmitting}
              >
                <ShieldCheck size={18} aria-hidden="true" />
                <span>{isSubmitting ? 'Cambiando contraseña…' : 'Cambiar contraseña'}</span>
              </Button>
            </div>
          </form>
        </div>

        <aside className="cambiar-password-aside" aria-label="Requisitos de seguridad">
          <div className="password-rules-card">
            <h3>Requisitos mínimos de seguridad</h3>
            <p>La nueva contraseña debe cumplir con los siguientes estándares de complejidad:</p>
            <ul className="password-rules-list">
              <li className={hasMinLength ? 'rule-met' : 'rule-unmet'}>
                {hasMinLength ? <Check size={16} aria-hidden="true" /> : <AlertCircle size={16} aria-hidden="true" />}
                <span>Al menos 8 caracteres</span>
              </li>
              <li className={hasUpperCase ? 'rule-met' : 'rule-unmet'}>
                {hasUpperCase ? <Check size={16} aria-hidden="true" /> : <AlertCircle size={16} aria-hidden="true" />}
                <span>Al menos una letra mayúscula (A-Z)</span>
              </li>
              <li className={hasLowerCase ? 'rule-met' : 'rule-unmet'}>
                {hasLowerCase ? <Check size={16} aria-hidden="true" /> : <AlertCircle size={16} aria-hidden="true" />}
                <span>Al menos una letra minúscula (a-z)</span>
              </li>
              <li className={hasDigit ? 'rule-met' : 'rule-unmet'}>
                {hasDigit ? <Check size={16} aria-hidden="true" /> : <AlertCircle size={16} aria-hidden="true" />}
                <span>Al menos un número (0-9)</span>
              </li>
              <li className={passwordsMatch ? 'rule-met' : 'rule-unmet'}>
                {passwordsMatch ? <Check size={16} aria-hidden="true" /> : <AlertCircle size={16} aria-hidden="true" />}
                <span>Las contraseñas coinciden</span>
              </li>
            </ul>
          </div>
        </aside>
      </div>
    </section>
  );
}
