import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import { initializeKeycloak } from './services/keycloak';
import api from './services/api';

window.api = api;

const root = ReactDOM.createRoot(document.getElementById('root'));

initializeKeycloak()
  .then(() => {
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  })
  .catch((error) => {
    console.error('No fue posible inicializar Keycloak', error);
    root.render(
      <div role="alert" style={{ padding: '24px', fontFamily: 'Segoe UI, sans-serif' }}>
        No fue posible conectar con el servicio de autenticación. Intenta nuevamente más tarde.
      </div>
    );
  });
