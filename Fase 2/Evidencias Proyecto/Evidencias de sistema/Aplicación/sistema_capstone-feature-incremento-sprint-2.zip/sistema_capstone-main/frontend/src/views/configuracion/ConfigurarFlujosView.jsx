import React, { useEffect, useRef, useState } from 'react';
import { Clock, Edit2, Layers, Plus, RefreshCw, Search, Settings2, Trash2 } from 'lucide-react';
import api from '../../services/api';
import keycloak from '../../services/keycloak';
import { Button, Card, DataTable, EmptyState, FeedbackMessage, PageHeader } from '../../components/ui';
import { useAccess } from '../../components/access/AccessContext';
import FlowDefinitionsPanel from '../../components/flows/FlowDefinitionsPanel';
import SlaRuleDialog from '../../components/flows/SlaRuleDialog';
import useSlaRules from '../../hooks/useSlaRules';
import { createSlaClient, formatSlaDate, SLA_CALENDAR_HELP, SLA_FUTURE_HELP } from '../../services/sla';
import './ConfigurarFlujosView.css';

const slaClient = createSlaClient(api);

// Un contexto nuevo monta una matriz nueva, retirando datos y operaciones anteriores.
export function SlaMatrix({ client = slaClient, accessKey, subject }) {
  const { rules, loading, loaded, error, refresh } = useSlaRules(client, accessKey);
  const [search, setSearch] = useState('');
  const [dialog, setDialog] = useState(null);
  const [notice, setNotice] = useState('');
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  const query = search.trim().toLocaleLowerCase('es-CL');
  const filtered = rules.filter((rule) => rule.tipoDocumento.toLocaleLowerCase('es-CL').includes(query));
  const unavailable = loading || Boolean(error) || !loaded;
  const save = async (mode, ruleId, payload) => {
    await client.save(mode, ruleId, payload, { credentialSubject: subject });
    if (!alive.current) return;
    setDialog(null);
    setNotice(mode === 'delete' ? 'Regla SLA eliminada. Las solicitudes existentes conservan su plazo.'
      : mode === 'edit' ? 'Plazo actualizado para nuevas solicitudes.' : 'Regla SLA creada para nuevas solicitudes.');
    void refresh();
  };
  return <>
    <PageHeader eyebrow="Configuración" title="Matriz de plazos SLA" icon={Clock}
      description="Defina los plazos máximos según el tipo de documento para todo su proceso de revisión."
      actions={<Button disabled={unavailable} onClick={() => setDialog({ mode: 'create' })} data-testid="create-sla-btn"><Plus size={16} aria-hidden="true" />Nueva regla SLA</Button>} />
    <FeedbackMessage tone="info" title="Cómo se aplican los plazos"><p>{SLA_CALENDAR_HELP}</p><p>{SLA_FUTURE_HELP}</p></FeedbackMessage>
    {notice && <FeedbackMessage tone="success">{notice}</FeedbackMessage>}
    {error && <FeedbackMessage tone="error" title={loaded ? 'La matriz no está actualizada' : 'Matriz no disponible'}>
      {error}{loaded && <p>Se muestran los últimos datos consultados. Actualice la matriz para volver a editar.</p>}
    </FeedbackMessage>}
    <Card id="sla-panel" role="tabpanel" aria-labelledby="sla-tab" className="flows-list-card" aria-busy={loading}>
      <div className="flows-toolbar"><div className="flows-filters"><div className="search-field flows-search-input">
        <Search size={16} aria-hidden="true" /><input type="search" placeholder="Buscar por tipo de documento…" value={search}
          onChange={(event) => setSearch(event.target.value)} aria-label="Buscar reglas SLA" data-testid="sla-search-input" />
      </div></div><Button variant="secondary" onClick={() => { setNotice(''); void refresh(); }} disabled={loading} title="Recargar reglas SLA">
        <RefreshCw size={16} aria-hidden="true" className={loading ? 'button-spinner' : ''} />Actualizar
      </Button></div>
      {!loaded && loading ? <EmptyState loading title="Cargando reglas SLA…" />
        : !loaded && error ? <EmptyState icon={Clock} tone="error" title="No se pudo consultar la matriz" action={<Button variant="secondary" onClick={refresh}>Volver a intentar</Button>}>La consulta falló; no es posible determinar si existen reglas.</EmptyState>
        : error && rules.length === 0 ? <EmptyState icon={Clock} title="Última consulta sin reglas">Actualice la matriz para comprobar su contenido actual.</EmptyState>
        : filtered.length === 0 ? <EmptyState icon={Clock} title={query ? 'Sin resultados para esta búsqueda' : 'Todavía no hay reglas SLA'}
          action={query ? <Button variant="secondary" onClick={() => setSearch('')}>Limpiar búsqueda</Button>
            : <Button disabled={unavailable} onClick={() => setDialog({ mode: 'create' })} data-testid="empty-create-sla-btn"><Plus size={16} aria-hidden="true" />Nueva regla SLA</Button>}>
          {query ? 'Pruebe con otro tipo de documento.' : 'Las nuevas solicitudes usarán cinco días hábiles hasta que configure una regla.'}
        </EmptyState> : <div className="table-scroll"><DataTable className="flows-table table-stackable sla-table" aria-label="Matriz de plazos SLA; fechas de Santiago de Chile">
          <thead><tr><th scope="col">Tipo de documento</th><th scope="col">Plazo máximo</th><th scope="col">Fecha de creación</th><th scope="col">Última actualización</th><th scope="col" className="text-right">Acciones</th></tr></thead>
          <tbody>{filtered.map((rule) => <tr key={rule.id} data-testid={`sla-row-${rule.id}`}>
            <td className="cell-primary" data-label="Tipo de documento"><strong className="flow-name" data-testid={`sla-tipo-${rule.id}`}>{rule.tipoDocumento}</strong></td>
            <td data-label="Plazo máximo"><span className="sla-days-badge" data-testid={`sla-plazo-${rule.id}`}><Clock size={13} aria-hidden="true" />{rule.plazoDias} {rule.plazoDias === 1 ? 'día hábil' : 'días hábiles'}</span></td>
            <td data-label="Fecha de creación"><small className="text-muted">{formatSlaDate(rule.createdAt)}</small></td>
            <td data-label="Última actualización"><small className="text-muted">{formatSlaDate(rule.updatedAt)}</small></td>
            <td className="cell-actions"><div className="row-actions">
              <Button variant="secondary" className="ui-button--compact" disabled={unavailable} onClick={() => setDialog({ mode: 'edit', rule })}
                aria-label={`Editar plazo de ${rule.tipoDocumento}`} data-testid={`edit-sla-btn-${rule.id}`}><Edit2 size={14} aria-hidden="true" />Editar plazo</Button>
              <Button variant="secondary" className="ui-button--compact" disabled={unavailable} onClick={() => setDialog({ mode: 'delete', rule })}
                aria-label={`Eliminar regla SLA de ${rule.tipoDocumento}`} data-testid={`delete-sla-btn-${rule.id}`}><Trash2 size={14} aria-hidden="true" /></Button>
            </div></td>
          </tr>)}</tbody>
        </DataTable></div>}
    </Card>
    {dialog && <SlaRuleDialog key={`${dialog.mode}-${dialog.rule?.id ?? 'new'}`} {...dialog} onClose={() => setDialog(null)} onSave={save} />}
  </>;
}

export default function ConfigurarFlujosView() {
  const { can, context } = useAccess();
  const canManageSla = context?.administradorGlobal === true && can('SLA_GESTIONAR');
  const accessKey = `${keycloak.tokenParsed?.sub ?? ''}:${JSON.stringify(context)}`;
  const [activeTab, setActiveTab] = useState('flujos');
  const tab = canManageSla ? activeTab : 'flujos';
  useEffect(() => { if (!canManageSla) setActiveTab('flujos'); }, [canManageSla]);
  const handleTabKey = (event) => {
    if (!canManageSla || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 'flujos' : event.key === 'End' ? 'sla' : tab === 'flujos' ? 'sla' : 'flujos';
    setActiveTab(next); document.getElementById(next === 'flujos' ? 'flows-tab' : 'sla-tab')?.focus();
  };
  return <div className="flows-page">
    {tab === 'flujos' && <PageHeader eyebrow="Configuración" title="Flujos de aprobación" description="Administre los flujos documentales, sus etapas secuenciales y los responsables de revisión por área corporativa." icon={Settings2} />}
    <div className="flows-tabs-nav" role="tablist" aria-label="Configuración documental" onKeyDown={handleTabKey}>
      <button id="flows-tab" type="button" role="tab" aria-selected={tab === 'flujos'} tabIndex={tab === 'flujos' ? 0 : -1} aria-controls="flows-panel" className={`flows-tab-btn ${tab === 'flujos' ? 'active' : ''}`} onClick={() => setActiveTab('flujos')} data-testid="tab-flujos"><Layers size={16} aria-hidden="true" />Flujos de aprobación</button>
      {canManageSla && <button id="sla-tab" type="button" role="tab" aria-selected={tab === 'sla'} tabIndex={tab === 'sla' ? 0 : -1} aria-controls="sla-panel" className={`flows-tab-btn ${tab === 'sla' ? 'active' : ''}`} onClick={() => setActiveTab('sla')} data-testid="tab-sla"><Clock size={16} aria-hidden="true" />Matriz de plazos SLA</button>}
    </div>
    <div id="flows-panel" role="tabpanel" aria-labelledby="flows-tab" hidden={tab !== 'flujos'}><FlowDefinitionsPanel /></div>
    {tab === 'sla' && canManageSla && <SlaMatrix key={accessKey} accessKey={accessKey} subject={keycloak.tokenParsed?.sub} />}
  </div>;
}
