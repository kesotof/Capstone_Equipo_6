import Keycloak from 'keycloak-js';

const keycloakConfig = {
  url: import.meta.env.VITE_KEYCLOAK_URL || 'http://localhost:8080',
  realm: import.meta.env.VITE_KEYCLOAK_REALM || 'capstone-realm',
  clientId: import.meta.env.VITE_KEYCLOAK_CLIENT_ID || 'capstone-client'
};

const keycloak = new Keycloak(keycloakConfig);

export async function registerLoginAudit() {
  if (!keycloak.token) {
    return;
  }

  const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8081';
  try {
    const response = await fetch(`${apiUrl}/api/audit/login`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${keycloak.token}`
      }
    });

    if (!response.ok) {
      console.warn(`La auditoría de inicio de sesión respondió HTTP ${response.status}`);
    }
  } catch (error) {
    console.warn('No fue posible registrar la auditoría de inicio de sesión', error);
  }
}

export function initializeKeycloak() {
  const path = window.location.pathname;
  const requestQuery = new URLSearchParams(window.location.search).getAll('id');
  const requestId = requestQuery.length === 1 && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(requestQuery[0]) ? requestQuery[0] : null;
  const destination = /^\/solicitudes\/[^/]+$/.test(path) || path === '/consultar-documentos' || path === '/estado-solicitudes' || path === '/cambiar-contrasena' || path === '/corregir-documento' || path === '/revisar-documento' || path === '/configurar-areas' || path === '/configurar-org-usuarios' ? path : '/dashboard';
  const query = (destination === '/estado-solicitudes' || destination === '/corregir-documento' || destination === '/revisar-documento') && requestId ? `?id=${encodeURIComponent(requestId)}` : '';
  return keycloak.init({
    onLoad: 'login-required',
    pkceMethod: 'S256',
    checkLoginIframe: false,
    redirectUri: `${window.location.origin}${destination}${query}`
  }).then(async (authenticated) => {
    if (authenticated) {
      await registerLoginAudit();
    }
    return authenticated;
  });
}

async function registerLogoutAudit() {
  if (!keycloak.token) {
    return;
  }

  const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8081';
  const response = await fetch(`${apiUrl}/api/audit/logout`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${keycloak.token}`
    }
  });

  if (!response.ok) {
    throw new Error(`La auditoría de cierre de sesión respondió HTTP ${response.status}`);
  }
}

export async function logout() {
  try {
    await keycloak.updateToken(30);
    await registerLogoutAudit();
  } catch (error) {
    // El cierre local y en Keycloak debe continuar incluso si la auditoría no está disponible.
    console.warn('No fue posible registrar la auditoría de cierre de sesión', error);
  }

  return keycloak.logout({
    redirectUri: `${window.location.origin}/login`
  });
}

export function hasRealmRole(role) {
  return keycloak.hasRealmRole(role);
}

export function getAuthenticatedUser() {
  const token = keycloak.tokenParsed;

  return {
    email: token?.email || token?.preferred_username || '',
    name: token?.name || token?.preferred_username || token?.email || 'Usuario'
  };
}

export default keycloak;
