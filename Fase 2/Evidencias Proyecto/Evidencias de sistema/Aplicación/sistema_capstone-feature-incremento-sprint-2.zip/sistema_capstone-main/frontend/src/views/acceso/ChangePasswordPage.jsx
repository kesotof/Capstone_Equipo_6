import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, CheckCircle2, Circle, Eye, EyeOff, KeyRound, RotateCw, ShieldCheck, X } from 'lucide-react';
import { Button, Card, EmptyState, FeedbackMessage, FormField, PageHeader } from '../../components/ui';
import { useAccess } from '../../components/access/AccessContext';
import keycloak from '../../services/keycloak';
import { changeOwnPassword, getPasswordPolicy, passwordRequirements, passwordStrength, validatePasswordForm } from '../../services/passwordChanges';
import './ChangePasswordPage.css';

const blank = () => ({ currentPassword: '', newPassword: '', confirmPassword: '' });
const FIELD_ORDER = ['currentPassword', 'newPassword', 'confirmPassword'];

function PasswordField({ name, label, value, error, hint, disabled, inputRef, onChange, describedBy }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { if (!value) setVisible(false); }, [value]);
  const inputId = `change-password-${name}`;
  return (
    <div className="change-password-field">
      <FormField htmlFor={inputId} label={label} hintId={`${inputId}-hint`} hint={hint}>
        <input id={inputId} ref={inputRef} name={name} type={visible ? 'text' : 'password'} value={value}
          onChange={onChange} disabled={disabled} required maxLength={1024}
          autoComplete={name === 'currentPassword' ? 'current-password' : 'new-password'}
          autoCapitalize="none" spellCheck={false} aria-invalid={!!error}
          aria-describedby={[hint ? `${inputId}-hint` : '', error ? `${inputId}-error` : '', describedBy].filter(Boolean).join(' ') || undefined} />
      </FormField>
      <Button variant="quiet" className="change-password-visibility" onClick={() => setVisible((old) => !old)}
        disabled={disabled} aria-controls={inputId} aria-pressed={visible}
        aria-label={`${visible ? 'Ocultar' : 'Mostrar'} ${label.toLocaleLowerCase('es')}`}>
        {visible ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}
      </Button>
      {error && <p className="change-password-field-error" id={`${inputId}-error`}>{error}</p>}
    </div>
  );
}

export default function ChangePasswordPage() {
  const { context } = useAccess();
  const subject = keycloak.tokenParsed?.sub;
  const [fields, setFields] = useState(blank);
  const [policy, setPolicy] = useState(null);
  const [policyError, setPolicyError] = useState('');
  const [loadingPolicy, setLoadingPolicy] = useState(true);
  const [reload, setReload] = useState(0);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('editing');
  const [errorCode, setErrorCode] = useState('');
  const [toast, setToast] = useState(false);
  const inputs = useRef({});
  const successHeading = useRef(null);
  const pending = useRef(null);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; pending.current?.abort(); };
  }, []);

  useEffect(() => {
    pending.current?.abort(); pending.current = null;
    setFields(blank()); setErrors({}); setMessage(''); setErrorCode(''); setToast(false); setStatus('editing');
  }, [subject, context.usuarioId]);

  useEffect(() => {
    const controller = new AbortController();
    setLoadingPolicy(true); setPolicy(null); setPolicyError('');
    getPasswordPolicy(controller.signal, subject).then((data) => {
      if (!controller.signal.aborted) setPolicy(data);
    }).catch(() => {
      if (!controller.signal.aborted) setPolicyError('No fue posible cargar los requisitos de seguridad de la cuenta. Vuelva a intentarlo.');
    }).finally(() => { if (!controller.signal.aborted) setLoadingPolicy(false); });
    return () => controller.abort();
  }, [subject, context.usuarioId, reload]);

  useEffect(() => {
    if (status !== 'saving') return undefined;
    const preventLeaving = (event) => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', preventLeaving);
    return () => window.removeEventListener('beforeunload', preventLeaving);
  }, [status]);

  useEffect(() => { if (status === 'success') successHeading.current?.focus(); }, [status]);

  const requirements = passwordRequirements(fields.newPassword, policy);
  const strength = passwordStrength(fields.newPassword);
  const saving = status === 'saving';
  const uncertain = status === 'uncertain';
  const blocked = saving || uncertain || !policy || loadingPolicy;

  function focusError(nextErrors) {
    const first = FIELD_ORDER.find((key) => nextErrors[key]);
    if (first) requestAnimationFrame(() => inputs.current[first]?.focus());
  }

  function changeField(name, value) {
    setFields((old) => ({ ...old, [name]: value }));
    setErrors((old) => {
      const next = { ...old }; delete next[name];
      if (name === 'newPassword') delete next.confirmPassword;
      return next;
    });
    setMessage(''); setErrorCode('');
  }

  async function submit(event) {
    event.preventDefault();
    if (pending.current || blocked) return;
    const nextErrors = validatePasswordForm(fields, policy);
    setErrors(nextErrors); setMessage(''); setToast(false);
    if (Object.keys(nextErrors).length) { focusError(nextErrors); return; }
    const controller = new AbortController();
    pending.current = controller;
    setStatus('saving'); setErrorCode('');
    try {
      await changeOwnPassword(fields, controller.signal, subject);
      if (!alive.current || controller.signal.aborted || keycloak.tokenParsed?.sub !== subject) return;
      setFields(blank()); setErrors({}); setStatus('success'); setToast(true);
    } catch (error) {
      if (!alive.current || controller.signal.aborted || error.cancelled) return;
      setStatus(error.uncertain ? 'uncertain' : 'editing');
      setFields((old) => error.uncertain ? blank() : { ...old, currentPassword: '' });
      setErrors(error.fields || {}); setMessage(error.message); setErrorCode(error.code || '');
      focusError(error.fields || {});
      if (error.code === 'PASSWORD_POLICY_REJECTED') setReload((old) => old + 1);
    } finally {
      if (pending.current === controller) pending.current = null;
    }
  }

  return (
    <section className="view-container change-password-page" aria-labelledby="change-password-title">
      <PageHeader eyebrow="Seguridad de la cuenta" title="Cambiar contraseña" titleId="change-password-title"
        icon={KeyRound} description="Actualice su contraseña para proteger el acceso a su cuenta." />
      {toast && <div className="review-feedback-toast page-message form-message-success" role="status" aria-live="polite">
        <span className="review-feedback-icon" aria-hidden="true"><CheckCircle2 size={21} /></span>
        <div><strong>Contraseña actualizada exitosamente</strong><p>Puede continuar utilizando la plataforma.</p></div>
        <button type="button" onClick={() => setToast(false)} aria-label="Cerrar notificación"><X size={17} aria-hidden="true" /></button>
      </div>}
      <Card className="change-password-card">
        <div className="change-password-card-header"><ShieldCheck size={22} aria-hidden="true" />
          <div><h3>Contraseña de acceso</h3><p>El cambio se aplicará únicamente a su cuenta.</p></div>
        </div>
        {status === 'success' ? <div className="change-password-success">
          <CheckCircle2 size={32} aria-hidden="true" />
          <h3 ref={successHeading} tabIndex={-1}>Su contraseña fue actualizada</h3>
          <p>Utilice la nueva contraseña en su próximo inicio de sesión.</p>
          <div className="change-password-actions">
            <Button as={Link} to="/dashboard">Continuar a la plataforma <ArrowRight size={17} aria-hidden="true" /></Button>
            <Button variant="secondary" onClick={() => { setStatus('editing'); setToast(false); setReload((old) => old + 1); }}>Cambiar nuevamente</Button>
          </div>
        </div> : <>
          {loadingPolicy && <EmptyState loading title="Cargando requisitos de seguridad…" />}
          {policyError && <div className="change-password-policy-error"><FeedbackMessage tone="error">{policyError}</FeedbackMessage>
            <Button variant="secondary" onClick={() => setReload((old) => old + 1)}><RotateCw size={16} aria-hidden="true" /> Volver a cargar</Button>
          </div>}
          {message && <FeedbackMessage tone="error" className="change-password-message">{message}
            {errorCode === 'PASSWORD_CHANGE_REAUTH_REQUIRED' && <Button variant="secondary" onClick={() => keycloak.accountManagement()}>Gestionar mi cuenta</Button>}
          </FeedbackMessage>}
          <form onSubmit={submit} noValidate aria-busy={saving} className="change-password-form">
            <PasswordField name="currentPassword" label="Contraseña actual" value={fields.currentPassword} error={errors.currentPassword}
              inputRef={(element) => { inputs.current.currentPassword = element; }} disabled={blocked}
              onChange={(event) => changeField('currentPassword', event.target.value)} />
            <PasswordField name="newPassword" label="Nueva contraseña" value={fields.newPassword} error={errors.newPassword}
              inputRef={(element) => { inputs.current.newPassword = element; }} disabled={blocked} describedBy="change-password-rules change-password-strength"
              onChange={(event) => changeField('newPassword', event.target.value)} />
            {policy && <div className="change-password-policy" id="change-password-rules">
              <div className="change-password-strength-heading" id="change-password-strength"><strong>Fortaleza orientativa</strong><span>{strength.label}</span></div>
              <div className="change-password-strength" data-strength={strength.score} role="meter" aria-label="Fortaleza orientativa de la nueva contraseña"
                aria-valuemin={0} aria-valuemax={4} aria-valuenow={strength.score} aria-valuetext={strength.label}>
                {[1, 2, 3, 4].map((part) => <span key={part} className={part <= strength.score ? 'filled' : ''} />)}
              </div>
              <p className="change-password-policy-intro">La contraseña debe cumplir estos requisitos:</p>
              <ul>{requirements.map((rule) => <li key={rule.key} className={rule.met ? 'met' : ''}>
                {rule.met ? <Check size={16} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />}
                <span className="visually-hidden">{rule.met ? 'Cumplido: ' : 'Pendiente: '}</span>{rule.label}
              </li>)}</ul>
              <p className="change-password-policy-note">Debe ser diferente de la contraseña actual. La fortaleza orientativa no sustituye los requisitos de seguridad.</p>
              {policy.additionalRules && <p className="change-password-policy-note">También se aplican las políticas adicionales de seguridad de su cuenta.</p>}
            </div>}
            <PasswordField name="confirmPassword" label="Confirmar nueva contraseña" value={fields.confirmPassword}
              error={errors.confirmPassword || (fields.confirmPassword && fields.confirmPassword !== fields.newPassword ? 'Las contraseñas no coinciden.' : '')}
              inputRef={(element) => { inputs.current.confirmPassword = element; }} disabled={blocked}
              onChange={(event) => changeField('confirmPassword', event.target.value)} />
            <div className="change-password-actions">
              <Button type="submit" loading={saving} disabled={blocked}><KeyRound size={17} aria-hidden="true" />{saving ? 'Actualizando contraseña…' : 'Actualizar contraseña'}</Button>
              <Button as={Link} to="/dashboard" variant="secondary" disabled={saving}>Volver al Dashboard</Button>
            </div>
          </form>
        </>}
      </Card>
    </section>
  );
}
