import { useEffect, useRef, useState } from 'react';
import { useAccess } from '../components/access/AccessContext';
import { deliverDocument, downloadError, getDocumentFile } from '../services/documentDownloads';

export default function useDocumentDownload(target, allowed, contextKey = '') {
  const { context, revision, can } = useAccess();
  const permitted = allowed && can('DOCUMENTO_DESCARGAR');
  const identity = [context?.usuarioId, revision, contextKey, target.documentId, target.solicitudId, permitted].join(':');
  const currentIdentity = useRef(identity);
  currentIdentity.current = identity;
  const pending = useRef(null);
  const sequence = useRef(0);
  const cleanups = useRef(new Set());
  const [state, setState] = useState({ identity, busy: false, percent: null, notice: null });
  useEffect(() => {
    setState({ identity, busy: false, percent: null, notice: null });
    return () => {
      ++sequence.current;
      pending.current?.abort(); pending.current = null;
      cleanups.current.forEach((cleanup) => cleanup()); cleanups.current.clear();
    };
  }, [identity]);

  const download = async () => {
    if (!permitted || pending.current) return;
    const controller = new AbortController();
    const seq = ++sequence.current;
    pending.current = controller;
    const active = () => !controller.signal.aborted && sequence.current === seq && currentIdentity.current === identity;
    setState({ identity, busy: true, percent: null, notice: null });
    try {
      const file = await getDocumentFile(target, controller.signal, (percent) => {
        if (active()) setState((current) => ({ ...current, percent }));
      });
      if (!active()) return;
      const cleanup = deliverDocument(file, () => cleanups.current.delete(cleanup));
      cleanups.current.add(cleanup);
      setState({ identity, busy: false, percent: 100, notice: { tone: 'success', message: 'Archivo preparado para descarga.' } });
    } catch (error) {
      if (active()) setState({ identity, busy: false, percent: null, notice: { tone: 'error', message: downloadError(error) } });
    } finally {
      if (active()) { pending.current = null; setState((current) => ({ ...current, busy: false })); }
    }
  };
  return {
    permitted, download,
    ...(state.identity === identity ? state : { busy: false, percent: null, notice: null }),
    dismiss: () => setState((current) => ({ ...current, notice: null }))
  };
}
