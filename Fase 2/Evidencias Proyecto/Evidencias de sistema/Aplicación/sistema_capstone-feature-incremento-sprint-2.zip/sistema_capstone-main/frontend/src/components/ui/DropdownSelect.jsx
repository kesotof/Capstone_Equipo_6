import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown } from 'lucide-react';
import './DropdownSelect.css';

// Conserva las clases del selector de Revisar documento para compartir su apariencia.
export default function DropdownSelect({ id, name, value, onChange, options, disabled = false, className = '', ...props }) {
  const triggerRef = useRef(null);
  const menuRef = useRef(null);
  const searchRef = useRef({ text: '', timer: null });
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [position, setPosition] = useState(null);
  const selectedIndex = options.findIndex((option) => option.value === value);
  const selected = options[selectedIndex];
  const enabled = options.map((option, index) => option.disabled ? -1 : index).filter((index) => index >= 0);
  const menuId = `${id}-options`;

  const openMenu = (fromEnd = false) => {
    if (disabled) return;
    setActiveIndex(selected && !selected.disabled ? selectedIndex : fromEnd ? enabled[enabled.length - 1] ?? -1 : enabled[0] ?? -1);
    setOpen(true);
  };
  const select = (index) => {
    if (disabled || !options[index] || options[index].disabled) return;
    onChange(options[index].value);
    setOpen(false);
    triggerRef.current?.focus();
  };

  useEffect(() => {
    if (disabled) setOpen(false);
  }, [disabled]);
  useEffect(() => () => window.clearTimeout(searchRef.current.timer), []);

  useLayoutEffect(() => {
    if (!open || disabled) return undefined;
    const updatePosition = () => {
      const rect = triggerRef.current.getBoundingClientRect();
      const below = window.innerHeight - rect.bottom - 14;
      const above = rect.top - 14;
      const upwards = below < 180 && above > below;
      const width = Math.min(Math.max(rect.width, 100), window.innerWidth - 24);
      setPosition({
        left: Math.max(12, Math.min(rect.left, window.innerWidth - width - 12)),
        width,
        maxHeight: Math.max(40, Math.min(280, upwards ? above : below)),
        top: upwards ? 'auto' : rect.bottom + 6,
        bottom: upwards ? window.innerHeight - rect.top + 6 : 'auto'
      });
    };
    updatePosition();
    const observer = new ResizeObserver(updatePosition);
    observer.observe(triggerRef.current);
    window.addEventListener('resize', updatePosition);
    const handleScroll = (event) => {
      if (!menuRef.current?.contains(event.target)) updatePosition();
    };
    window.addEventListener('scroll', handleScroll, true);
    const dismiss = (event) => {
      if (!triggerRef.current?.contains(event.target) && !menuRef.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('pointerdown', dismiss);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', handleScroll, true);
      document.removeEventListener('pointerdown', dismiss);
    };
  }, [open, disabled]);

  useLayoutEffect(() => {
    if (!open || !menuRef.current) return;
    const menu = menuRef.current;
    const option = menu.querySelector(`[data-option-index="${activeIndex}"]`);
    if (!option) return;
    if (option.offsetTop < menu.scrollTop) menu.scrollTop = option.offsetTop;
    else if (option.offsetTop + option.offsetHeight > menu.scrollTop + menu.clientHeight) {
      menu.scrollTop = option.offsetTop + option.offsetHeight - menu.clientHeight;
    }
  }, [open, activeIndex, position]);

  const handleKeyDown = (event) => {
    if (disabled) return;
    if (event.key === 'Escape' && open) {
      event.preventDefault();
      event.stopPropagation();
      setOpen(false);
      return;
    }
    if (event.key === 'Tab') { setOpen(false); return; }
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      if (!open) {
        if (event.key === 'Home' || event.key === 'End') {
          setActiveIndex((event.key === 'Home' ? enabled[0] : enabled[enabled.length - 1]) ?? -1);
          setOpen(true);
        } else openMenu(event.key === 'ArrowUp');
        return;
      }
      const current = enabled.indexOf(activeIndex);
      if (event.key === 'Home') setActiveIndex(enabled[0] ?? -1);
      else if (event.key === 'End') setActiveIndex(enabled[enabled.length - 1] ?? -1);
      else {
        const next = current + (event.key === 'ArrowDown' ? 1 : -1);
        setActiveIndex(enabled[Math.max(0, Math.min(enabled.length - 1, next))] ?? -1);
      }
      return;
    }
    if (event.key === 'Enter' || (event.key === ' ' && !searchRef.current.text)) {
      event.preventDefault();
      if (open) select(activeIndex);
      else openMenu();
      return;
    }
    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      const search = searchRef.current;
      window.clearTimeout(search.timer);
      search.text += event.key.toLocaleLowerCase('es');
      search.timer = window.setTimeout(() => { search.text = ''; }, 650);
      const match = enabled.find((index) => options[index].label.toLocaleLowerCase('es').startsWith(search.text));
      setOpen(true);
      if (match != null) setActiveIndex(match);
    }
  };

  // Dentro de un modal, el menú sigue perteneciendo a su diálogo accesible.
  // La posición fija evita recortarlo en el contenedor de tabla o formulario.
  const host = triggerRef.current?.closest('[role="dialog"]') || document.body;
  return <div className={`review-picker ui-select ${className}`.trim()}>
    <button {...props} ref={triggerRef} id={id} name={name} type="button" className="review-filter-trigger ui-select-trigger"
      role="combobox" aria-haspopup="listbox" aria-expanded={open && !disabled} aria-controls={open ? menuId : undefined}
      aria-activedescendant={open && activeIndex >= 0 ? `${menuId}-${activeIndex}` : undefined}
      disabled={disabled} onKeyDown={handleKeyDown} onBlur={() => setOpen(false)}
      onClick={() => open ? setOpen(false) : openMenu()}>
      <span title={selected?.label}>{selected?.label || 'Seleccionar'}</span>
      <ChevronDown className="review-filter-chevron" size={15} aria-hidden="true" />
    </button>
    {open && !disabled && position && createPortal(
      <div ref={menuRef} id={menuId} className="review-status-menu ui-select-menu" role="listbox"
        aria-labelledby={id} style={position}>
        {options.map((option, index) => <div key={option.value} id={`${menuId}-${index}`} data-option-index={index}
          role="option" aria-selected={option.value === value} aria-disabled={option.disabled || undefined}
          className={`ui-select-option${option.value === value ? ' is-selected' : ''}${index === activeIndex ? ' is-active' : ''}`}
          onPointerDown={(event) => event.preventDefault()} onMouseEnter={() => { if (!option.disabled) setActiveIndex(index); }}
          onClick={() => select(index)}>
          <span>{option.label}</span>{option.value === value && <Check size={16} aria-hidden="true" />}
        </div>)}
        {!options.length && <p className="ui-select-empty">No hay opciones disponibles.</p>}
      </div>, host
    )}
  </div>;
}
