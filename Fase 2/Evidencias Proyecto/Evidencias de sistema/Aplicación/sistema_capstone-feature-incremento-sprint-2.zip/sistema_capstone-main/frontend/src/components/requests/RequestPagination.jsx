import React from 'react';
import { ChevronLeft, ChevronRight, ChevronsRight } from 'lucide-react';
import { Button } from '../ui';

export const REQUEST_PAGE_SIZE = 10;

export default function RequestPagination({ total, page, onChange, label, showLatest = false }) {
  const pages = Math.max(1, Math.ceil(total / REQUEST_PAGE_SIZE));
  if (total <= REQUEST_PAGE_SIZE) return null;
  return <nav className="review-pagination request-pagination" aria-label={`Paginación de ${label}`}>
    <span>{page * REQUEST_PAGE_SIZE + 1}–{Math.min((page + 1) * REQUEST_PAGE_SIZE, total)} de {total} · Página {page + 1} de {pages}</span>
    <div>
      <Button variant="secondary" disabled={page === 0} onClick={() => onChange(page - 1)} aria-label={`Página anterior de ${label}`}><ChevronLeft size={16} aria-hidden="true" />Anterior</Button>
      <Button variant="secondary" disabled={page >= pages - 1} onClick={() => onChange(page + 1)} aria-label={`Página siguiente de ${label}`}>Siguiente<ChevronRight size={16} aria-hidden="true" /></Button>
      {showLatest && <Button variant="quiet" disabled={page >= pages - 1} onClick={() => onChange(pages - 1)}><ChevronsRight size={16} aria-hidden="true" />Últimos eventos</Button>}
    </div>
  </nav>;
}
