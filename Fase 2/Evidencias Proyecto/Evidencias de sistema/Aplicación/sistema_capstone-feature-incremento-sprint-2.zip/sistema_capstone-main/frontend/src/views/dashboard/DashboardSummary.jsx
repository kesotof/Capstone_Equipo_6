import React, { useState } from 'react';
import { BarChart3, CheckCircle2, Clock, FileEdit, Layers, RotateCw, XCircle } from 'lucide-react';
import { useAccess } from '../../components/access/AccessContext';
import { Button, Card, DropdownSelect, FeedbackMessage, FormField, Skeleton } from '../../components/ui';
import useDashboardResource from '../../hooks/useDashboardResource';
import { getDashboardSummary } from '../../services/dashboardSummary';
import './DashboardSummary.css';

const number = new Intl.NumberFormat('es-CL');
const states = [
  { key: 'pendientes', label: 'Pendientes de revisión', tone: 'warning', icon: Clock },
  { key: 'aprobadas', label: 'Aprobadas', tone: 'success', icon: CheckCircle2 },
  { key: 'rechazadas', label: 'Rechazadas', tone: 'error', icon: XCircle },
  { key: 'enCorreccion', label: 'En corrección', tone: 'info', icon: FileEdit }
];
const dateLabel = (date) => new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short', timeZone: 'UTC' }).format(new Date(date + 'T00:00:00Z'));
const weekdayLabel = (date) => new Intl.DateTimeFormat('es-CL', { weekday: 'short', timeZone: 'UTC' }).format(new Date(date + 'T00:00:00Z'));
const consulted = (date) => new Intl.DateTimeFormat('es-CL', { timeZone: 'America/Santiago', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(date));
const percent = (value, total) => (total ? value / total * 100 : 0);
const formatPercent = (value) => value.toFixed(1).replace('.', ',') + ' %';

function SummarySkeleton() {
  return (
    <div className="summary-skeleton" role="status" aria-live="polite">
      <span className="visually-hidden">Consultando el resumen autorizado…</span>
      <div className="page-skeleton-card summary-skeleton-context" aria-hidden="true">
        <Skeleton width={44} height={44} radius={12} />
        <div className="summary-skeleton-lines"><Skeleton width={180} height={18} /><Skeleton width={140} height={12} /></div>
        <Skeleton className="summary-skeleton-select" width={260} height={40} radius={8} />
      </div>
      <div className="summary-kpis" aria-hidden="true">
        {states.map(({ key }) => (
          <div className="page-skeleton-card" key={key}>
            <Skeleton width="65%" height={12} />
            <Skeleton width={64} height={32} />
            <Skeleton width="45%" height={10} />
          </div>
        ))}
      </div>
      <div className="summary-charts" aria-hidden="true">
        <div className="page-skeleton-card summary-skeleton-chart">
          <Skeleton width={180} height={14} />
          <Skeleton width="100%" height={14} radius={999} />
          {states.map(({ key }) => <Skeleton key={key} width="100%" height={10} />)}
        </div>
        <div className="page-skeleton-card summary-skeleton-chart">
          <Skeleton width={160} height={14} />
          <div className="summary-skeleton-bars">
            {[40, 65, 30, 80, 55, 25, 70].map((height, index) => <Skeleton key={index} width="100%" height={`${height}%`} radius={4} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function DashboardSummary({ refreshVersion }) {
  const { context, can } = useAccess();
  const fingerprint = JSON.stringify(context);
  const [view, setView] = useState({ fingerprint, selection: 'all', page: 0 });
  const selection = view.fingerprint === fingerprint ? view.selection : 'all';
  const page = view.fingerprint === fingerprint ? view.page : 0;
  const enabled = can('METRICAS_CONSULTAR') && can('SOLICITUD_CONSULTAR');
  const { data, error, loading, refreshing, stale, refresh } = useDashboardResource(getDashboardSummary, selection, enabled, refreshVersion);
  if (!enabled) return null;
  const pages = Math.max(1, Math.ceil((data?.porArea.length || 0) / 10));
  const currentPage = Math.min(page, pages - 1);
  const setPage = (next) => setView({ fingerprint, selection, page: next });
  const options = [
    { value: 'all', label: 'Todas las áreas' },
    ...(data?.catalogoAreas || []).map((area) => ({ value: String(area.id), label: area.nombre + (area.activa ? '' : ' · Inactiva') })),
    { value: 'unassigned', label: 'Sin área registrada' }
  ];
  const scopeLabel = selection === 'all' ? 'Conjunto autorizado completo' : selection === 'unassigned' ? 'Sin área registrada' : options.find((area) => area.value === selection)?.label;
  const distribution = data ? [...states, ...(data.totales.otros ? [{ key: 'otros', label: 'Otros estados', tone: 'neutral' }] : [])] : [];
  const maxDaily = data ? Math.max(1, ...data.tendencias.map((day) => day.emitidas)) : 1;
  const weekTotal = data ? data.tendencias.reduce((sum, day) => sum + day.emitidas, 0) : 0;
  const todayKey = data?.tendencias[data.tendencias.length - 1]?.fecha;

  return (
    <section className="dashboard-summary" aria-labelledby="summary-heading" aria-busy={refreshing}>
      <div className="dashboard-section-heading">
        <div>
          <h3 id="summary-heading"><BarChart3 size={18} aria-hidden="true" />Resumen general de solicitudes</h3>
          <p>Estados actuales de las solicitudes disponibles según su acceso.</p>
        </div>
        {data && (
          <p className={`summary-updated${stale ? ' is-stale' : ''}`} role="status">
            <span className="summary-updated-dot" aria-hidden="true" />
            <span>{refreshing ? 'Actualizando…' : stale ? 'Cifras desactualizadas' : 'Última consulta: ' + consulted(data.consultadoEn)}</span>
            <small>Hora de Santiago · Actualización automática</small>
          </p>
        )}
      </div>

      {error && (
        <FeedbackMessage tone="error">
          {error.message}{stale && ' Se muestran cifras anteriores; no están actualizadas.'}
          {!data && (
            <div className="row-actions">
              <Button variant="secondary" onClick={refresh} disabled={refreshing}><RotateCw size={16} aria-hidden="true" />Reintentar</Button>
              {selection !== 'all' && <Button variant="quiet" onClick={() => setView({ fingerprint, selection: 'all', page: 0 })}>Todas las áreas</Button>}
            </div>
          )}
        </FeedbackMessage>
      )}

      {loading && <SummarySkeleton />}

      {data && <>
        <Card className="summary-context">
          <div className="summary-scope">
            <span className="summary-scope-icon" aria-hidden="true"><Layers size={20} /></span>
            <div>
              <strong>{number.format(data.totales.total)} solicitudes</strong>
              <p>{scopeLabel}</p>
            </div>
          </div>
          {data.puedeFiltrarPorArea ? (
            <FormField label="Área corporativa" htmlFor="summary-area" className="summary-area-field" hint="Área de origen registrada; área del flujo cuando no existe origen.">
              <DropdownSelect id="summary-area" value={selection} options={options} onChange={(value) => setView({ fingerprint, selection: value, page: 0 })} />
            </FormField>
          ) : (
            <small className="summary-scope-note">Área de origen registrada; área del flujo cuando no existe origen.</small>
          )}
        </Card>

        {data.totales.total === 0 && <FeedbackMessage>No hay solicitudes disponibles para este alcance. Las cifras corresponden a una consulta sin resultados.</FeedbackMessage>}

        <div className="summary-kpis" role="list" aria-label="Solicitudes por estado">
          {states.map(({ key, label, tone, icon: Icon }) => {
            const share = percent(data.totales[key], data.totales.total);
            return (
              <Card key={key} className={'summary-kpi summary-tone-' + tone} role="listitem">
                <div className="summary-kpi-top">
                  <span className="summary-kpi-label">{label}</span>
                  <span className="summary-kpi-icon" aria-hidden="true"><Icon size={18} /></span>
                </div>
                <strong className="summary-kpi-value">{number.format(data.totales[key])}</strong>
                <small className="summary-kpi-share">{formatPercent(share)} del total</small>
                <span className="summary-kpi-meter" aria-hidden="true"><span style={{ width: share + '%' }} /></span>
              </Card>
            );
          })}
        </div>

        {data.totales.otros > 0 && <FeedbackMessage>Hay {number.format(data.totales.otros)} solicitudes con otros estados históricos, incluidas en el total y el desglose.</FeedbackMessage>}

        <div className="summary-charts">
          <Card className="summary-chart" as="section" aria-labelledby="summary-states-heading">
            <div className="summary-chart-head">
              <div>
                <h4 id="summary-states-heading">Distribución por estado</h4>
                <p>Proporción del total seleccionado.</p>
              </div>
            </div>
            <div className="summary-stack" aria-hidden="true">
              {data.totales.total > 0 && distribution.map(({ key, tone }) => data.totales[key] > 0 && (
                <span key={key} className={'summary-tone-' + tone} style={{ flexGrow: data.totales[key] }} />
              ))}
            </div>
            <ul className="summary-state-bars">
              {distribution.map(({ key, label, tone }) => {
                const share = percent(data.totales[key], data.totales.total);
                return (
                  <li key={key} className={'summary-tone-' + tone}>
                    <div>
                      <span><span className="summary-legend-dot" aria-hidden="true" />{label}</span>
                      <strong>{number.format(data.totales[key])} <small>({formatPercent(share)})</small></strong>
                    </div>
                    <div className="summary-bar-track" aria-hidden="true"><span style={{ width: share + '%' }} /></div>
                  </li>
                );
              })}
            </ul>
          </Card>

          <Card className="summary-chart" as="section" aria-labelledby="summary-trend-heading">
            <div className="summary-chart-head">
              <div>
                <h4 id="summary-trend-heading">Solicitudes emitidas</h4>
                <p>Últimos siete días · Hora de Santiago.</p>
              </div>
              <span className="summary-chart-total"><strong>{number.format(weekTotal)}</strong> en 7 días</span>
            </div>
            <div className="summary-trend-frame">
              <ol className="summary-trend">
                {data.tendencias.map((day) => {
                  const isToday = day.fecha === todayKey;
                  return (
                    <li key={day.fecha} className={`${isToday ? 'is-today' : ''}${day.emitidas === 0 ? ' is-zero' : ''}`.trim() || undefined}>
                      <strong>{number.format(day.emitidas)}</strong>
                      <div className="summary-trend-track" aria-hidden="true">
                        <span style={{ height: day.emitidas / maxDaily * 100 + '%' }} />
                      </div>
                      <time dateTime={day.fecha}>
                        <span className="summary-trend-weekday">{isToday ? 'Hoy' : weekdayLabel(day.fecha)}</span>
                        {dateLabel(day.fecha)}
                      </time>
                    </li>
                  );
                })}
              </ol>
              {weekTotal === 0 && <p className="summary-trend-empty">Sin solicitudes emitidas en este periodo.</p>}
            </div>
            <p className="summary-chart-footnote">Cada barra representa nuevas solicitudes del día.</p>
          </Card>
        </div>

        <Card className="summary-areas" as="section" aria-labelledby="summary-areas-heading">
          <div className="summary-area-heading">
            <h4 id="summary-areas-heading">Desglose por área corporativa</h4>
            <span>{number.format(data.porArea.length)} {data.porArea.length === 1 ? 'grupo' : 'grupos'}</span>
          </div>
          {data.porArea.length ? (
            <div className="table-responsive">
              <table className="dashboard-table table-stackable summary-area-table">
                <caption className="visually-hidden">Solicitudes por área de origen registrada. Página {currentPage + 1} de {pages}.</caption>
                <thead>
                  <tr>
                    <th>Área corporativa</th><th>Pendientes</th><th>Aprobadas</th><th>Rechazadas</th><th>En corrección</th>
                    {data.totales.otros > 0 && <th>Otros</th>}
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {data.porArea.slice(currentPage * 10, (currentPage + 1) * 10).map((area) => (
                    <tr key={area.areaId ?? 'unassigned'}>
                      <td className="cell-primary">
                        <strong className="summary-area-name">{area.nombre}</strong>
                        {area.activa === false && <small className="summary-area-status">Inactiva</small>}
                      </td>
                      <td data-label="Pendientes">{number.format(area.totales.pendientes)}</td>
                      <td data-label="Aprobadas">{number.format(area.totales.aprobadas)}</td>
                      <td data-label="Rechazadas">{number.format(area.totales.rechazadas)}</td>
                      <td data-label="En corrección">{number.format(area.totales.enCorreccion)}</td>
                      {data.totales.otros > 0 && <td data-label="Otros">{number.format(area.totales.otros)}</td>}
                      <td data-label="Total">
                        <div className="summary-area-total">
                          <strong>{number.format(area.totales.total)}</strong>
                          <span className="summary-area-share" aria-hidden="true"><span style={{ width: percent(area.totales.total, data.totales.total) + '%' }} /></span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p className="summary-empty">No hay áreas con solicitudes visibles.</p>}
          {pages > 1 && (
            <nav className="summary-pagination" aria-label="Paginación del desglose por área">
              <span>Página {currentPage + 1} de {pages} · 10 áreas por página</span>
              <div>
                <Button variant="secondary" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}>Anterior</Button>
                <Button variant="secondary" disabled={currentPage + 1 === pages} onClick={() => setPage(currentPage + 1)}>Siguiente</Button>
              </div>
            </nav>
          )}
        </Card>
      </>}
    </section>
  );
}
