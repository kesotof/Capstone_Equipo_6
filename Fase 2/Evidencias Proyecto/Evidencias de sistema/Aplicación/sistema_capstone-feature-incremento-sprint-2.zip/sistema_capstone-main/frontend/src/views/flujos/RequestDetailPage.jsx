import React from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, FileText, RefreshCw } from 'lucide-react';
import { Button, PageHeader, StatusBadge, formatDateTime } from '../../components/ui';
import { useAccess } from '../../components/access/AccessContext';
import RequestDetailPanel from '../../components/requests/RequestDetailPanel';
import useRequestDetail from '../../hooks/useRequestDetail';
import { requestAreaLabel, requestReturnTarget } from '../../services/requestDetails';
import './RequestDetailPage.css';

export default function RequestDetailPage() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { context, can } = useAccess();
  const { detail, loading, error, refresh, requestKey } = useRequestDetail(id);
  const returnTarget = requestReturnTarget(location.state?.requestOrigin);
  return <section className="list-page request-detail-page" aria-labelledby="request-page-title">
    <PageHeader eyebrow={detail ? detail.correlativo || 'Sin correlativo' : 'Flujos de aprobación'} title={detail?.titulo || 'Detalle de solicitud'} titleId="request-page-title" icon={FileText}
      description={detail ? undefined : 'Información y trazabilidad de la solicitud.'}
      actions={<><Button variant="secondary" onClick={() => navigate(`${returnTarget.pathname}${returnTarget.search}`, { state: returnTarget.state })}><ArrowLeft size={17} aria-hidden="true" />Volver</Button><Button variant="secondary" onClick={refresh} loading={loading} disabled={loading}><RefreshCw size={17} aria-hidden="true" />Actualizar</Button></>}>
      {detail && <><div className="request-header-status"><StatusBadge status={detail.estado} /></div><dl className="request-header-context"><div><dt>Área de origen</dt><dd>{requestAreaLabel(detail.areaOrigen)}</dd></div><div><dt>Área de flujo</dt><dd>{requestAreaLabel(detail.areaFlujo, true)}</dd></div><div><dt>Emisor</dt><dd>{detail.emisorNombre}</dd></div><div><dt>Fecha de emisión</dt><dd>{formatDateTime(detail.createdAt)}</dd></div></dl></>}
    </PageHeader>
    <RequestDetailPanel key={`${id}:${context.usuarioId}`} detail={detail} loading={loading} error={error} refresh={refresh} requestKey={requestKey} reviewAllowed={can('REVISION_CONSULTAR')} returnTarget={returnTarget} />
  </section>;
}
