import api from './api';

export async function listAreas({ page = 0, size = 20, activo, q, signal } = {}) {
  const response = await api.get('/api/areas', {
    params: { page, size, activo, q: q || undefined },
    signal
  });
  return response.data;
}

// El selector necesita también las áreas inactivas para reconocer todos los descendientes.
export async function loadAreaCatalog(signal) {
  const areas = new Map();
  let page = 0;
  let result;
  do {
    result = await listAreas({ page, size: 100, signal });
    result.contenido.forEach((area) => areas.set(area.id, area));
    page += 1;
  } while (page < result.totalPaginas);
  return [...areas.values()];
}

export async function createArea(data) {
  return (await api.post('/api/areas', data)).data;
}

export async function updateArea(id, data) {
  return (await api.put(`/api/areas/${id}`, data)).data;
}

export async function changeAreaStatus(id, activo, version) {
  return (await api.patch(`/api/areas/${id}/status`, { activo, version })).data;
}

export function getAreaProblem(error, fallback = 'No fue posible completar la operación. Vuelva a intentarlo.') {
  const problem = error.response?.data;
  const status = error.response?.status;
  const messages = {
    AREA_NOMBRE_DUPLICADO: 'Ya existe un área con ese nombre, incluso si está inactiva. Ingrese un nombre diferente.',
    AREA_PADRE_INACTIVA: 'El área superior o alguna de sus dependencias jerárquicas está inactiva. Actualice las opciones y seleccione un área disponible.',
    AREA_JERARQUIA_INVALIDA: 'El área superior no puede ser la propia unidad ni una de sus áreas subordinadas.',
    AREA_MODIFICADA: 'Otra persona modificó esta área. Recargue sus datos antes de continuar.',
    AREA_EN_USO: 'No se puede desactivar el área mientras tenga dependencias activas.',
    AREA_NO_ENCONTRADA: 'El área ya no está disponible. Actualice el listado.',
    AREA_PADRE_NO_ENCONTRADA: 'El área superior ya no está disponible. Actualice las opciones.'
  };
  const fields = { ...problem?.invalidFields };
  if (fields.areaPadreId) fields.areaPadreId = 'Revise el área superior seleccionada. Debe estar disponible y respetar la dependencia jerárquica.';
  return {
    status,
    codigo: problem?.codigo,
    message: status === 401
      ? 'La sesión no es válida o la cuenta está inactiva. Inicie sesión nuevamente para continuar.'
      : status === 403
        ? 'Solo los administradores pueden gestionar las áreas corporativas.'
        : messages[problem?.codigo] || problem?.detail || fallback,
    fields,
    dependencias: problem?.dependencias,
    uncertain: !error.response || status >= 500,
    stale: problem?.codigo === 'AREA_MODIFICADA',
    denied: status === 401 || status === 403
  };
}
