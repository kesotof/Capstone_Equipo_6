export const SLA_TIME_ZONE = 'America/Santiago';
export const MAX_SLA_DAYS = 2147483647;
export const SLA_CALENDAR_HELP = 'Días hábiles: lunes a viernes, sin contar el día de envío ni descontar feriados. Fechas y horas de Santiago de Chile.';
export const SLA_FUTURE_HELP = 'Los cambios se aplican a nuevas solicitudes. Las solicitudes ya emitidas conservan su fecha límite original.';

const dateFormatter = new Intl.DateTimeFormat('es-CL', {
  timeZone: SLA_TIME_ZONE, dateStyle: 'medium', timeStyle: 'short'
});
const STATES = {
  NORMAL: { label: 'A tiempo', tone: 'info', key: 'normal', description: 'Quedan al menos 24 horas para el plazo.' },
  POR_VENCER: { label: 'Por vencer', tone: 'warning', key: 'por-vencer', description: 'Quedan menos de 24 horas corridas para el plazo.' },
  VENCIDO: { label: 'Vencido', tone: 'error', key: 'vencido', description: 'La fecha límite ya pasó. Las acciones de revisión siguen disponibles según sus permisos.' }
};

export function validSlaDate(value) {
  return typeof value === 'string' && value.trim() !== '' && Number.isFinite(new Date(value).getTime());
}

export function formatSlaDate(value) {
  return validSlaDate(value) ? `${dateFormatter.format(new Date(value))} · Santiago` : 'Fecha no disponible';
}

// Los estados provienen del servidor: no se recalculan con el reloj del navegador.
export function slaPresentation(deadline, status, active = true) {
  if (!deadline) return { label: 'Sin plazo registrado', tone: 'neutral', key: 'sin-plazo' };
  if (!validSlaDate(deadline)) return { label: 'Fecha límite no disponible', tone: 'neutral', key: 'fecha-no-disponible' };
  if (!active) return { label: 'Plazo registrado', tone: 'neutral', key: 'historico' };
  return (typeof status === 'string' && Object.hasOwn(STATES, status) ? STATES[status] : null)
    || { label: 'Estado del plazo no disponible', tone: 'neutral', key: 'no-disponible' };
}

export function slaContinuityMessage(estado) {
  if (estado === 'CORRECCION_REQUERIDA') return 'Las correcciones no pausan ni reinician el plazo. Al reenviar se vuelve a evaluar esta misma fecha límite.';
  return 'Fecha límite histórica. Consulte el historial para ver si cada decisión se realizó dentro del plazo.';
}

export function validateSlaForm(form, creating = true) {
  const errors = {};
  const tipoDocumento = typeof form.tipoDocumento === 'string' ? form.tipoDocumento.trim() : '';
  if (creating && (!tipoDocumento || tipoDocumento.length > 100)) errors.tipoDocumento = 'Ingrese un tipo de documento de 1 a 100 caracteres.';
  const rawDays = String(form.plazoDias ?? '').trim();
  const plazoDias = Number(rawDays);
  if (!/^\d+$/.test(rawDays) || !Number.isSafeInteger(plazoDias) || plazoDias < 1 || plazoDias > MAX_SLA_DAYS) {
    errors.plazoDias = 'Ingrese un número entero de días mayor a cero.';
  }
  return { errors, payload: creating ? { tipoDocumento, plazoDias } : { plazoDias } };
}

export function slaErrorMessage(error, writing = false) {
  const status = error?.response?.status;
  if (status === 401) return 'La sesión ya no está disponible. Vuelva a iniciar sesión.';
  if (status === 403) return 'No tiene permiso para administrar los plazos SLA.';
  if (status === 404) return 'Esta regla ya no está disponible. Actualice la matriz antes de continuar.';
  if (status === 409) return 'Ya existe una regla para este tipo de documento. Actualice la matriz o edite la regla existente.';
  if (status === 400) {
    const detail = error.response?.data?.detail;
    return typeof detail === 'string' && detail.length <= 400 ? detail : 'Revise el tipo de documento y el número entero de días.';
  }
  return writing
    ? 'No se pudo confirmar el cambio. Actualice la matriz antes de volver a intentarlo.'
    : 'No fue posible cargar las reglas SLA. Vuelva a intentar la consulta.';
}

export function createSlaClient(api) {
  return {
    async list(signal) {
      const { data } = await api.get('/api/sla', { signal });
      if (!Array.isArray(data) || data.some((rule) => !Number.isSafeInteger(rule?.id) || rule.id < 1
        || typeof rule.tipoDocumento !== 'string' || !rule.tipoDocumento.trim()
        || !Number.isInteger(rule.plazoDias) || rule.plazoDias < 1 || rule.plazoDias > MAX_SLA_DAYS)
        || new Set(data.map((rule) => rule.id)).size !== data.length) {
        throw new Error('La respuesta de la matriz SLA no está disponible.');
      }
      return data;
    },
    save(mode, ruleId, payload, config) {
      if (mode === 'create') return api.post('/api/sla', payload, config);
      if (mode === 'edit') return api.put(`/api/sla/${ruleId}`, payload, config);
      if (mode === 'delete') return api.delete(`/api/sla/${ruleId}`, config);
      throw new Error('Operación SLA no disponible.');
    }
  };
}
