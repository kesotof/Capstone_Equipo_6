import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileCheck2,
  FileEdit,
  FolderOpen,
  Inbox,
  Plus,
  RotateCw
} from 'lucide-react';
import { useAccess } from '../../components/access/AccessContext';
import { getAuthenticatedUser } from '../../services/keycloak';
import useDashboardResource from '../../hooks/useDashboardResource';
import { getDashboardWork } from '../../services/dashboardSummary';
import DashboardSummary from './DashboardSummary';
import {
  Button,
  Card,
  DateTimeStack,
  FeedbackMessage,
  FileTypeIcon,
  PageHeader,
  Skeleton,
  SkeletonRows,
  StatusBadge,
  useToast
} from '../../components/ui';

function formatToday() {
  const label = new Intl.DateTimeFormat('es-CL', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
  return label.charAt(0).toUpperCase() + label.slice(1);
}

const plural = (count, singular, pluralForm) => `${count} ${count === 1 ? singular : pluralForm}`;

function WorkSkeleton() {
  return (
    <Card as="div" className="dashboard-table-card dashboard-work-skeleton" role="status" aria-live="polite">
      <span className="visually-hidden">Cargando tu panel…</span>
      <div className="dashboard-tabs" aria-hidden="true">
        <Skeleton width={180} height={14} />
        <Skeleton width={200} height={14} />
      </div>
      <div className="dashboard-work-skeleton-rows" aria-hidden="true"><SkeletonRows rows={3} /></div>
    </Card>
  );
}

export default function DashboardView() {
  const navigate = useNavigate();
  const user = getAuthenticatedUser();
  const { can, roleLabel } = useAccess();
  const { notify } = useToast();
  const workRef = useRef(null);

  const [activeTab, setActiveTab] = useState('acciones'); // 'acciones' | 'en_tramite'
  const [refreshVersion, setRefreshVersion] = useState(0);
  const { data, error, loading, refreshing, stale } = useDashboardResource(
    getDashboardWork, 'work', can('SOLICITUD_CONSULTAR'), refreshVersion
  );
  const accionesPendientes = data?.accionesPendientes || [];
  const misSolicitudesPendientes = data?.misSolicitudesPendientes || [];

  // Aviso al terminar una actualización pedida por el usuario (no en los refrescos automáticos).
  const manualRefresh = useRef({ requested: false, started: false });
  useEffect(() => {
    const state = manualRefresh.current;
    if (!state.requested) return;
    if (refreshing) {
      state.started = true;
      return;
    }
    if (!state.started) return;
    manualRefresh.current = { requested: false, started: false };
    if (error) notify({ tone: 'error', title: 'No fue posible actualizar', message: error.message });
    else notify({ tone: 'success', title: 'Dashboard actualizado', message: 'Las bandejas y cifras muestran la información más reciente.' });
  }, [refreshing, error, notify]);

  const requestRefresh = () => {
    manualRefresh.current = { requested: can('SOLICITUD_CONSULTAR'), started: false };
    setRefreshVersion((value) => value + 1);
  };

  const openTab = (tab) => {
    setActiveTab(tab);
    workRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section className="view-container dashboard-view" aria-labelledby="dashboard-heading">
      <PageHeader
        className="dashboard-hero"
        eyebrow={formatToday()}
        title="Dashboard"
        titleId="dashboard-heading"
        actions={(
          <>
            <Button
              variant="secondary"
              className="btn-refresh"
              onClick={requestRefresh}
              disabled={loading || refreshing}
              title="Actualizar datos"
            >
              <RotateCw size={16} className={refreshing ? 'spin-icon' : ''} aria-hidden="true" />
              <span>{refreshing ? 'Actualizando…' : 'Actualizar'}</span>
            </Button>
            <Button hidden={!can('SOLICITUD_CREAR')} as={Link} to="/nuevo-documento" className="btn-new-request">
              <Plus size={18} aria-hidden="true" />
              <span>Nueva solicitud</span>
            </Button>
          </>
        )}
      >
        <p className="dashboard-greeting">
          Bienvenido, <strong>{user.name}</strong>
          <span className="user-role-badge">{roleLabel}</span>
        </p>
        {data && (
          <div className="dashboard-highlights" aria-label="Resumen de tu bandeja">
            <button
              type="button"
              className={`dashboard-highlight ${accionesPendientes.length ? 'is-attention' : 'is-clear'}`}
              onClick={() => openTab('acciones')}
            >
              {accionesPendientes.length ? <AlertCircle size={16} aria-hidden="true" /> : <CheckCircle2 size={16} aria-hidden="true" />}
              <span>{accionesPendientes.length ? plural(accionesPendientes.length, 'acción pendiente', 'acciones pendientes') : 'Sin acciones pendientes'}</span>
            </button>
            <button type="button" className="dashboard-highlight" onClick={() => openTab('en_tramite')}>
              <Clock size={16} aria-hidden="true" />
              <span>{plural(misSolicitudesPendientes.length, 'solicitud en trámite', 'solicitudes en trámite')}</span>
            </button>
          </div>
        )}
      </PageHeader>

      {!can('SOLICITUD_CONSULTAR') && <FeedbackMessage>No tiene funciones documentales asignadas. Las secciones disponibles se muestran en el menú y sus notificaciones permanecen accesibles.</FeedbackMessage>}

      {can('SOLICITUD_CONSULTAR') && (
        <section className="dashboard-work" aria-labelledby="work-heading" ref={workRef}>
          <div className="dashboard-section-heading">
            <div>
              <h3 id="work-heading"><Inbox size={18} aria-hidden="true" />Bandeja de trabajo</h3>
              <p>Solicitudes que esperan tu decisión y documentos que emitiste.</p>
            </div>
          </div>

          {error && <FeedbackMessage tone="error" className="page-message">{error.message}{stale && ' Las bandejas muestran datos anteriores.'}</FeedbackMessage>}

          {loading ? <WorkSkeleton /> : !data ? null : (
            <Card as="div" className="dashboard-table-card">
              <div className="dashboard-tabs" role="tablist" aria-label="Bandejas del dashboard">
                <button
                  type="button"
                  role="tab"
                  id="tab-acciones"
                  aria-selected={activeTab === 'acciones'}
                  aria-controls="panel-acciones"
                  className={`dashboard-tab-btn ${activeTab === 'acciones' ? 'active' : ''}`}
                  onClick={() => setActiveTab('acciones')}
                >
                  <FileCheck2 size={17} aria-hidden="true" />
                  <span>Acciones pendientes</span>
                  <span className={`tab-counter-badge${accionesPendientes.length ? ' has-items' : ''}`}>{accionesPendientes.length}</span>
                </button>
                <button
                  type="button"
                  role="tab"
                  id="tab-en-tramite"
                  aria-selected={activeTab === 'en_tramite'}
                  aria-controls="panel-en-tramite"
                  className={`dashboard-tab-btn ${activeTab === 'en_tramite' ? 'active' : ''}`}
                  onClick={() => setActiveTab('en_tramite')}
                >
                  <Clock size={17} aria-hidden="true" />
                  <span>Mis solicitudes en trámite</span>
                  <span className="tab-counter-badge">{misSolicitudesPendientes.length}</span>
                </button>
              </div>

              {activeTab === 'acciones' && (
                <div className="dashboard-tab-content" role="tabpanel" id="panel-acciones" aria-labelledby="tab-acciones">
                  {accionesPendientes.length === 0 ? (
                    <div className="dashboard-empty-state">
                      <span className="empty-state-icon-wrapper" aria-hidden="true">
                        <CheckCircle2 size={28} />
                      </span>
                      <h3>¡Estás al día!</h3>
                      <p>
                        No tienes solicitudes pendientes de tu revisión ni documentos que requieran corrección en este momento.
                      </p>
                      <div className="empty-state-actions">
                        <Button hidden={!can('SOLICITUD_CREAR')} as={Link} variant="secondary" to="/nuevo-documento">
                          Crear nueva solicitud
                        </Button>
                        <Button hidden={!can('SOLICITUD_CONSULTAR')} as={Link} variant="quiet" to="/mis-documentos">
                          Ver mis documentos
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <table className="dashboard-table table-stackable">
                        <thead>
                          <tr>
                            <th>Documento</th>
                            <th>Emisor</th>
                            <th>Acción requerida</th>
                            <th>Fecha</th>
                            <th className="text-right"><span className="visually-hidden">Acción</span></th>
                          </tr>
                        </thead>
                        <tbody>
                          {accionesPendientes.map((item) => {
                            const isRevision = item.tipoAccion === 'REVISION';
                            return (
                              <tr key={item.solicitudId} className="dashboard-action-row">
                                <td className="cell-primary">
                                  <div className="cell-with-icon">
                                    <FileTypeIcon fileName={item.nombreArchivo} />
                                    <div className="cell-stack">
                                      <strong>{item.titulo}</strong>
                                      {item.nombreArchivo && <span>{item.nombreArchivo} · v{item.version}</span>}
                                    </div>
                                  </div>
                                </td>
                                <td className="cell-wide" data-label="Emisor">
                                  <div className="cell-stack cell-person">
                                    <strong>{item.emisorNombre}</strong>
                                    <span>{item.emisorEmail}</span>
                                  </div>
                                </td>
                                <td className="cell-wide" data-label="Acción requerida">
                                  <div className="action-cell">
                                    {isRevision ? (
                                      <span className="action-tag action-tag-revision">
                                        <FileCheck2 size={14} aria-hidden="true" />
                                        <span>Revisión Requerida</span>
                                      </span>
                                    ) : (
                                      <span className="action-tag action-tag-correction">
                                        <FileEdit size={14} aria-hidden="true" />
                                        <span>Subsanación Requerida</span>
                                      </span>
                                    )}
                                    {item.ultimaObservacion ? (
                                      <div className="obs-snippet" title={item.ultimaObservacion}>
                                        <AlertCircle size={14} className="obs-icon" aria-hidden="true" />
                                        <span>{item.ultimaObservacion}</span>
                                      </div>
                                    ) : (
                                      <span className="detail-muted">
                                        {item.descripcionAccion || 'Pendiente de decisión'}
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td data-label="Fecha"><DateTimeStack value={item.fecha} /></td>
                                <td className="text-right cell-actions">
                                  {isRevision ? (
                                    <Button
                                      variant="secondary"
                                      className="ui-button--compact btn-review"
                                      onClick={() => navigate(`/revisar-documento?id=${item.solicitudId}`)}
                                    >
                                      <span>Revisar</span>
                                      <ArrowRight size={14} aria-hidden="true" />
                                    </Button>
                                  ) : (
                                    <Button
                                      variant="secondary"
                                      className="ui-button--compact btn-correct"
                                      onClick={() => navigate(`/corregir-documento?id=${item.solicitudId}`)}
                                    >
                                      <span>Subsanar</span>
                                      <ArrowRight size={14} aria-hidden="true" />
                                    </Button>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'en_tramite' && (
                <div className="dashboard-tab-content" role="tabpanel" id="panel-en-tramite" aria-labelledby="tab-en-tramite">
                  {misSolicitudesPendientes.length === 0 ? (
                    <div className="dashboard-empty-state">
                      <span className="empty-state-icon-wrapper neutral" aria-hidden="true">
                        <Inbox size={28} />
                      </span>
                      <h3>Sin solicitudes en trámite</h3>
                      <p>
                        Actualmente no tienes documentos en proceso de revisión o subsanación emitidos por tu cuenta.
                      </p>
                      <div className="empty-state-actions">
                        <Button hidden={!can('SOLICITUD_CREAR')} as={Link} to="/nuevo-documento">
                          Registrar nuevo documento
                        </Button>
                        <Button hidden={!can('SOLICITUD_CONSULTAR')} as={Link} variant="quiet" to="/mis-documentos">
                          <FolderOpen size={16} aria-hidden="true" />
                          Ver mis documentos
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <table className="dashboard-table table-stackable">
                        <thead>
                          <tr>
                            <th>Documento</th>
                            <th>Fecha de envío</th>
                            <th>Estado</th>
                            <th className="text-right"><span className="visually-hidden">Seguimiento</span></th>
                          </tr>
                        </thead>
                        <tbody>
                          {misSolicitudesPendientes.map((sol) => (
                            <tr key={sol.id} className="dashboard-request-row">
                              <td className="cell-primary">
                                <div className="cell-with-icon">
                                  <FileTypeIcon fileName={sol.documentoVigente?.nombreArchivo} />
                                  <div className="cell-stack">
                                    <strong>{sol.titulo}</strong>
                                    <span>
                                      {sol.documentoVigente
                                        ? `${sol.documentoVigente.nombreArchivo} · v${sol.documentoVigente.version}`
                                        : 'Sin archivo adjunto'}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              <td data-label="Enviada"><DateTimeStack value={sol.createdAt} /></td>
                              <td data-label="Estado"><StatusBadge status={sol.estado} /></td>
                              <td className="text-right cell-actions">
                                <Button
                                  variant="secondary"
                                  className="ui-button--compact btn-track"
                                  onClick={() => navigate(`/estado-solicitudes?id=${sol.id}`)}
                                >
                                  <span>Ver estado</span>
                                  <ArrowRight size={14} aria-hidden="true" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </Card>
          )}
        </section>
      )}

      <DashboardSummary refreshVersion={refreshVersion} />
    </section>
  );
}
