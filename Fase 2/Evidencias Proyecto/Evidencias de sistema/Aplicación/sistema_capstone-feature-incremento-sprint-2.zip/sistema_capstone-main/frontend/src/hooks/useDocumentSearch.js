import { useCallback, useEffect, useRef, useState } from 'react';
import { useAccess } from '../components/access/AccessContext';
import { documentSearchCatalog, documentSearchError, documentSearchParams, searchDocuments } from '../services/documentSearch';

export default function useDocumentSearch(filters, page, sort) {
  const { context, revision } = useAccess();
  const [reload, setReload] = useState(0);
  const [catalogReload, setCatalogReload] = useState(0);
  const [result, setResult] = useState(null);
  const [catalogResult, setCatalogResult] = useState(null);
  const resultSequence = useRef(0);
  const catalogSequence = useRef(0);
  const scope = `${context.usuarioId}:${revision}`;
  const parameters = JSON.stringify(documentSearchParams(filters, page, sort));
  const resultKey = `${scope}:${parameters}:${reload}`;
  const catalogKey = `${scope}:${reload}:${catalogReload}`;

  useEffect(() => {
    const controller = new AbortController();
    const sequence = ++resultSequence.current;
    searchDocuments(JSON.parse(parameters), controller.signal)
      .then((data) => {
        if (!controller.signal.aborted && sequence === resultSequence.current) setResult({ key: resultKey, data, error: null });
      }).catch((error) => {
        if (!controller.signal.aborted && sequence === resultSequence.current) setResult({ key: resultKey, data: null, error: documentSearchError(error) });
      });
    return () => { ++resultSequence.current; controller.abort(); };
  }, [parameters, resultKey]);

  useEffect(() => {
    const controller = new AbortController();
    const sequence = ++catalogSequence.current;
    documentSearchCatalog(controller.signal)
      .then((data) => {
        if (!controller.signal.aborted && sequence === catalogSequence.current) setCatalogResult({ key: catalogKey, data, error: null });
      }).catch((error) => {
        if (!controller.signal.aborted && sequence === catalogSequence.current) setCatalogResult({ key: catalogKey, data: null, error: documentSearchError(error, true) });
      });
    return () => { ++catalogSequence.current; controller.abort(); };
  }, [catalogKey]);

  const current = result?.key === resultKey ? result : null;
  const currentCatalog = catalogResult?.key === catalogKey ? catalogResult : null;
  const restricted = Boolean(current?.error?.restricted || currentCatalog?.error?.restricted);
  return {
    data: restricted ? null : current?.data || null,
    error: current?.error || (restricted ? currentCatalog?.error : null),
    loading: !current,
    catalog: restricted ? null : currentCatalog?.data || null,
    catalogError: currentCatalog?.error || null,
    catalogLoading: !currentCatalog,
    restricted,
    refresh: useCallback(() => setReload((value) => value + 1), []),
    refreshCatalog: useCallback(() => setCatalogReload((value) => value + 1), [])
  };
}
