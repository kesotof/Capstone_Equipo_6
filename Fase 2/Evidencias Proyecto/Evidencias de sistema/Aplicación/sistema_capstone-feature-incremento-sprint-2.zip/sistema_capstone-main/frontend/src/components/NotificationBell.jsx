import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Check, CheckCircle2, ChevronRight, FileEdit, FileText, Inbox, LoaderCircle, RotateCcw, XCircle } from 'lucide-react';
import api from '../services/api';

const NOTIFICATION_TYPES = {
  APROBACION: { label: 'Aprobado', tone: 'success', icon: CheckCircle2 },
  RECHAZO: { label: 'Rechazado', tone: 'error', icon: XCircle },
  CORRECCION_REQUERIDA: { label: 'Corrección requerida', tone: 'warning', icon: FileEdit },
  REENVIO: { label: 'Reenviado', tone: 'info', icon: RotateCcw },
  NUEVA_SOLICITUD: { label: 'Nueva solicitud', tone: 'brand', icon: FileText }
};

function getNotificationPath(notification) {
  if (!notification.solicitudId) return null;
  const route = notification.tipo === 'NUEVA_SOLICITUD' || notification.tipo === 'REENVIO'
    ? '/revisar-documento'
    : notification.tipo === 'CORRECCION_REQUERIDA'
      ? '/corregir-documento'
      : '/estado-solicitudes';
  return `${route}?id=${encodeURIComponent(notification.solicitudId)}`;
}

export default function NotificationBell() {
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all');
  const [errorMessage, setErrorMessage] = useState('');
  const [markingAll, setMarkingAll] = useState(false);
  const dropdownRef = useRef(null);
  const bellButtonRef = useRef(null);
  const navigate = useNavigate();

  const fetchUnreadCount = async () => {
    try {
      const response = await api.get('/api/notificaciones/no-leidas/count');
      setUnreadCount(response.data?.count ?? 0);
    } catch (err) {
      console.warn('No fue posible cargar el conteo de notificaciones', err);
    }
  };

  const fetchNotifications = async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const response = await api.get('/api/notificaciones');
      const items = Array.isArray(response.data) ? response.data : [];
      setNotifications([...items].sort((a, b) => new Date(b.createdEn).getTime() - new Date(a.createdEn).getTime()));
    } catch (err) {
      console.warn('No fue posible cargar las notificaciones', err);
      setErrorMessage('No fue posible cargar las notificaciones. Inténtalo nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 30000);
    const refreshOnVisibility = () => {
      if (document.visibilityState === 'visible') fetchUnreadCount();
    };
    document.addEventListener('visibilitychange', refreshOnVisibility);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', refreshOnVisibility);
    };
  }, []);

  const handleToggle = () => {
    if (!isOpen) {
      void fetchNotifications();
      void fetchUnreadCount();
    }
    setIsOpen((current) => !current);
  };

  const handleMarkAllRead = async (e) => {
    e.stopPropagation();
    if (markingAll || unreadCount === 0) return;
    setMarkingAll(true);
    setErrorMessage('');
    try {
      await api.patch('/api/notificaciones/marcar-todas-leidas');
      setUnreadCount(0);
      setNotifications((prev) =>
        prev.map((n) => ({ ...n, leida: true, leidaEn: new Date().toISOString() }))
      );
    } catch (err) {
      console.error('Error al marcar todas como leídas', err);
      setErrorMessage('No fue posible marcar las notificaciones como leídas.');
    } finally {
      setMarkingAll(false);
    }
  };

  const handleNotificationClick = async (notif) => {
    if (!notif.leida) {
      try {
        await api.patch(`/api/notificaciones/${notif.id}/leer`);
        setUnreadCount((c) => Math.max(0, c - 1));
        setNotifications((prev) =>
          prev.map((n) => (n.id === notif.id ? { ...n, leida: true } : n))
        );
      } catch (err) {
        console.error('Error al marcar notificación como leída', err);
      }
    }
    setIsOpen(false);
    const destination = getNotificationPath(notif);
    if (destination) navigate(destination);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
        bellButtonRef.current?.focus();
      }
    };
    if (isOpen) document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const formatDate = (isoString) => {
    if (!isoString) return '';
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('es-CL', {
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return isoString;
    }
  };

  const visibleNotifications = filter === 'unread'
    ? notifications.filter((notification) => !notification.leida)
    : notifications;

  return (
    <div className="notification-container" ref={dropdownRef}>
      <button
        ref={bellButtonRef}
        className="notification-bell-btn"
        type="button"
        onClick={handleToggle}
        aria-label={`Notificaciones (${unreadCount} no leídas)`}
        aria-expanded={isOpen}
        aria-controls="notification-panel"
      >
        <Bell size={19} aria-hidden="true" />
        {unreadCount > 0 && (
          <span className="notification-badge" data-testid="notification-badge">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div id="notification-panel" className="notification-dropdown" role="region" aria-label="Bandeja de notificaciones">
          <header className="notification-dropdown-header">
            <span className="notification-eyebrow">Centro de actividad</span>
            <div><h4>Notificaciones</h4><span className="notification-header-count">{unreadCount} sin leer</span></div>
            <p>Sigue los cambios de tus solicitudes desde aquí.</p>
          </header>

          <div className="notification-toolbar">
            <div className="notification-filters" role="group" aria-label="Filtrar notificaciones">
              <button type="button" className={filter === 'all' ? 'is-active' : ''} onClick={() => setFilter('all')} aria-pressed={filter === 'all'}>Todas</button>
              <button type="button" className={filter === 'unread' ? 'is-active' : ''} onClick={() => setFilter('unread')} aria-pressed={filter === 'unread'}>No leídas</button>
            </div>
            {unreadCount > 0 && <button className="mark-all-btn" type="button" onClick={handleMarkAllRead} disabled={markingAll}><Check size={15} aria-hidden="true" />{markingAll ? 'Actualizando…' : 'Marcar todas leídas'}</button>}
          </div>

          {errorMessage && <div className="notification-error" role="alert"><span>{errorMessage}</span><button type="button" onClick={fetchNotifications}>Reintentar</button></div>}

          <div className="notification-list" aria-live="polite">
            {loading ? <div className="notification-empty"><LoaderCircle className="button-spinner" size={22} aria-hidden="true" /><strong>Cargando notificaciones…</strong></div>
              : visibleNotifications.length === 0 ? <div className="notification-empty"><Inbox size={28} aria-hidden="true" /><strong>{filter === 'unread' ? 'Todo al día' : 'Aún no hay notificaciones'}</strong><span>{filter === 'unread' ? 'No tienes notificaciones pendientes de lectura.' : 'Los cambios de tus solicitudes aparecerán aquí.'}</span></div>
              : <ul className="notification-items">{visibleNotifications.map((notif) => {
                const presentation = NOTIFICATION_TYPES[notif.tipo] || NOTIFICATION_TYPES.NUEVA_SOLICITUD;
                const TypeIcon = presentation.icon;
                return <li key={notif.id}><button className={`notification-item ${!notif.leida ? 'notification-item-unread' : ''}`} type="button" onClick={() => handleNotificationClick(notif)} aria-label={`${!notif.leida ? 'No leída. ' : ''}${presentation.label}: ${notif.titulo}. ${notif.solicitudId ? 'Abrir solicitud' : 'Marcar como leída'}`}>
                  <span className={`notification-type-icon notification-tone-${presentation.tone}`} aria-hidden="true"><TypeIcon size={18} /></span>
                  <span className="notification-item-content"><span className="notification-item-top"><span className="notification-kind">{presentation.label}</span><time dateTime={notif.createdEn}>{formatDate(notif.createdEn)}</time></span><strong className="notification-item-title">{notif.titulo}</strong><span className="notification-item-message">{notif.mensaje}</span><span className="notification-item-action">{notif.solicitudId ? 'Ver solicitud' : 'Marcar como leída'}<ChevronRight size={14} aria-hidden="true" /></span></span>
                  {!notif.leida && <span className="notification-unread-dot" aria-hidden="true" />}
                </button></li>;
              })}</ul>}
          </div>
          <footer className="notification-dropdown-footer">Selecciona una notificación para abrir su solicitud.</footer>
        </div>
      )}
    </div>
  );
}
