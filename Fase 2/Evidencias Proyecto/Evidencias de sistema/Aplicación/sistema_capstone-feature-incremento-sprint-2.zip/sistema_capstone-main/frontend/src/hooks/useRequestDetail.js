import { useEffect, useRef, useState } from 'react';
import { useAccess } from '../components/access/AccessContext';
import { getRequestDetail, requestDetailError } from '../services/requestDetails';

export default function useRequestDetail(id) {
  const { context, revision } = useAccess();
  const [reload, setReload] = useState(0);
  const [result, setResult] = useState(null);
  const sequence = useRef(0);
  const scope = `${context.usuarioId}:${revision}`;
  const key = `${id}:${scope}:${reload}`;

  useEffect(() => {
    const controller = new AbortController();
    const current = ++sequence.current;
    getRequestDetail(id, controller.signal)
      .then((data) => {
        if (!controller.signal.aborted && current === sequence.current) setResult({ key, data, error: '' });
      })
      .catch((error) => {
        if (!controller.signal.aborted && current === sequence.current) {
          setResult({ key, data: null, error: requestDetailError(error) });
        }
      });
    return () => { ++sequence.current; controller.abort(); };
  }, [id, scope, reload, key]);

  const current = result?.key === key ? result : null;
  return {
    detail: current?.data || null,
    error: current?.error || '',
    loading: !current,
    scope,
    requestKey: key,
    refresh: () => setReload((value) => value + 1)
  };
}
