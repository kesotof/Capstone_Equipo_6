import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Edit2, Layers, Plus, RefreshCw, Search, Trash2, X } from 'lucide-react';
import api from '../../services/api';
import { hasObservedVersion, requiresWorkflowReload, workflowErrorMessage } from '../../services/workflowErrors';
import { useAccess } from '../access/AccessContext';
import AreaDialog from '../areas/AreaDialog';
import ReviewerSelector, { assignmentAvailable, assignmentLabel, assignmentPayload } from './ReviewerSelector';
import { Button, Card, DataTable, DropdownSelect, EmptyState, FeedbackMessage, FormField, StatusBadge } from '../ui';
import '../../views/configuracion/AreaManagementPage.css';

const PAGE_SIZE = 10;
const validName = (name) => Boolean(name.trim()) && name.trim().length <= 150 && !/[\u0000-\u001f\u007f-\u009f]/.test(name);
const emptyOptions = () => ({ usuarios: [], roles: [] });
const draftStage = (stage = {}) => ({ ...stage, key: crypto.randomUUID(), nombre: stage.nombre || '', revisorId: stage.revisorId ? String(stage.revisorId) : '', rolRevisorId: stage.rolRevisorId ? String(stage.rolRevisorId) : '', tipoAsignacion: stage.tipoAsignacion || 'USUARIO', tipoAccion: 'REVISION' });

export default function FlowDefinitionsPanel() {
  const { context, revision } = useAccess();
  const globalAdmin = context.administradorGlobal;
  const managedIds = JSON.stringify((context.areasAdministradas || []).map((area) => area.id));
  const [flows, setFlows] = useState([]);
  const [areas, setAreas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState(null);
  const [query, setQuery] = useState('');
  const [areaFilter, setAreaFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(0);
  const [editor, setEditor] = useState(null);
  const [form, setForm] = useState({ nombre: '', descripcion: '', areaId: '' });
  const [stages, setStages] = useState([]);
  const [reviewers, setReviewers] = useState(emptyOptions);
  const [assignee, setAssignee] = useState(draftStage);
  const [reviewersLoading, setReviewersLoading] = useState(false);
  const [reviewersError, setReviewersError] = useState('');
  const [error, setError] = useState('');
  const [blocked, setBlocked] = useState(false);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const catalogSequence = useRef(0);
  const editorSequence = useRef(0);
  const reviewerSequence = useRef(0);
  const editorRef = useRef(null);
  editorRef.current = editor;
  const allowed = useCallback((flow) => globalAdmin || JSON.parse(managedIds).includes(flow.areaId), [globalAdmin, managedIds]);

  const loadCatalog = useCallback(async () => {
    const sequence = ++catalogSequence.current;
    setLoading(true);
    try {
      const [definitions, catalog] = await Promise.all([api.get('/api/flujos'), api.get('/api/rbac/catalogos/areas')]);
      if (sequence !== catalogSequence.current) return;
      setFlows((definitions.data || []).filter(allowed));
      setAreas((catalog.data || []).filter((area) => allowed({ areaId: area.id })));
    } catch (err) {
      if (sequence !== catalogSequence.current) return;
      setFlows([]); setAreas([]);
      setNotice({ tone: 'error', text: workflowErrorMessage(err, 'No fue posible cargar los flujos y áreas corporativas.') });
    } finally {
      if (sequence === catalogSequence.current) setLoading(false);
    }
  }, [allowed]);

  useEffect(() => { void loadCatalog(); }, [loadCatalog, revision]);
  useEffect(() => () => { ++catalogSequence.current; ++editorSequence.current; ++reviewerSequence.current; }, []);
  useEffect(() => { setPage(0); }, [query, areaFilter, statusFilter]);
  useEffect(() => {
    const current = editorRef.current;
    if (current?.flow && !allowed(current.flow)) {
      ++editorSequence.current; ++reviewerSequence.current;
      setEditor(null); setReviewers(emptyOptions());
      setNotice({ tone: 'error', text: 'El flujo ya no está disponible en su ámbito de administración.' });
    }
  }, [allowed]);

  const loadReviewers = async (flow, stepId) => {
    const sequence = ++reviewerSequence.current;
    setReviewersLoading(true); setReviewersError(''); setReviewers(emptyOptions());
    try {
      const response = await api.get(`/api/flujos/${flow.id}/${stepId ? `steps/${stepId}/` : ''}assignee-options`);
      if (sequence !== reviewerSequence.current) return;
      if (response.data.version !== flow.version) {
        setBlocked(true); setReviewersError('La configuración cambió al cargar los responsables. Cargue la versión vigente antes de guardar.');
        return;
      }
      setReviewers({ usuarios: response.data.usuarios || [], roles: response.data.roles || [] });
    } catch (err) {
      if (sequence === reviewerSequence.current) setReviewersError(workflowErrorMessage(err, 'No fue posible cargar los responsables autorizados.'));
    } finally {
      if (sequence === reviewerSequence.current) setReviewersLoading(false);
    }
  };

  useEffect(() => {
    const current = editorRef.current;
    if ((current?.mode === 'stages' && current.flow.estructuraEditable) || current?.mode === 'assignee') void loadReviewers(current.flow, current.stepId);
  }, [revision]);

  const fillEditor = (mode, flow, stepId) => {
    setForm({ nombre: flow.nombre || '', descripcion: flow.descripcion || '', areaId: flow.areaId == null ? '' : String(flow.areaId) });
    setStages((flow.etapas || []).map(draftStage));
    setEditor({ mode, flow, stepId });
    if (mode === 'assignee') setAssignee(draftStage(flow.etapas.find((stage) => stage.id === stepId)));
    setError(''); setBlocked(!hasObservedVersion(flow));
    if (!hasObservedVersion(flow)) setError('No se recibió la versión vigente del flujo. Actualice antes de guardar.');
    if ((mode === 'stages' && flow.estructuraEditable) || mode === 'assignee') void loadReviewers(flow, stepId);
  };

  const openExisting = async (mode, flow, stepId) => {
    if (busyRef.current) return;
    const sequence = ++editorSequence.current;
    busyRef.current = true; setBusy(true); setNotice(null);
    try {
      const response = await api.get(`/api/flujos/${flow.id}`);
      if (sequence !== editorSequence.current) return;
      if (!allowed(response.data)) throw new Error('El flujo no está disponible en su ámbito de administración.');
      if (mode === 'assignee' && !response.data.etapas.some((stage) => stage.id === stepId)) throw new Error('La etapa ya no pertenece al flujo.');
      fillEditor(mode, response.data, stepId);
    } catch (err) {
      setNotice({ tone: 'error', text: workflowErrorMessage(err, 'No fue posible abrir el flujo. Actualice el catálogo.') });
    } finally { busyRef.current = false; setBusy(false); }
  };

  const closeEditor = () => {
    if (busyRef.current) return;
    ++editorSequence.current; ++reviewerSequence.current;
    setEditor(null); setError(''); setBlocked(false); setReviewers(emptyOptions());
  };
  const createFlow = () => {
    if (busyRef.current) return;
    setForm({ nombre: '', descripcion: '', areaId: globalAdmin ? '' : String(areas[0]?.id || '') });
    setError(''); setBlocked(false); setEditor({ mode: 'create', flow: null });
  };
  const reloadEditor = async () => {
    if (busyRef.current) return;
    if (!editor.flow) {
      closeEditor();
      setNotice({ tone: 'info', text: 'Revise el catálogo para comprobar si el flujo se creó antes de registrar otro con los mismos datos.' });
      await loadCatalog();
      return;
    }
    await openExisting(editor.mode, editor.flow, editor.stepId);
    void loadCatalog();
  };

  const changeStage = (index, field, value) => setStages((current) => current.map((stage, i) => i === index ? { ...stage, [field]: value } : stage));
  const moveStage = (index, direction) => setStages((current) => {
    const next = [...current]; const target = index + direction;
    if (target < 0 || target >= next.length) return current;
    [next[index], next[target]] = [next[target], next[index]];
    return next;
  });
  const stagesValid = stages.length > 0 && stages.every((stage) => validName(stage.nombre) && assignmentAvailable(stage, reviewers));
  const readOnlyStages = editor?.mode === 'stages' && !editor.flow.estructuraEditable;

  const save = async (event) => {
    event?.preventDefault();
    if (!editor || busyRef.current || blocked || readOnlyStages) return;
    const { mode, flow } = editor;
    if (flow && !hasObservedVersion(flow)) { setBlocked(true); setError('Actualice la versión del flujo antes de guardar.'); return; }
    if (mode === 'create' || mode === 'edit') {
      if (!validName(form.nombre)) { setError('El nombre debe contener entre 1 y 150 caracteres y no admite caracteres de control.'); return; }
      if (form.descripcion.length > 2000 || form.descripcion.includes('\0')) { setError('La descripción admite hasta 2000 caracteres, sin el carácter nulo.'); return; }
      if ((form.areaId && !areas.some((area) => String(area.id) === form.areaId)) || (!globalAdmin && !form.areaId)) {
        setError('Seleccione un área corporativa disponible en su ámbito de administración.'); return;
      }
    }
    if (((mode === 'stages' && !stagesValid) || (mode === 'assignee' && !assignmentAvailable(assignee, reviewers))) || ((mode === 'stages' || mode === 'assignee') && (reviewersLoading || reviewersError))) {
      setError(mode === 'assignee' ? 'Seleccione un responsable disponible para esta etapa.' : 'Configure al menos una etapa, con nombre válido y un responsable autorizado en cada paso.'); return;
    }
    busyRef.current = true; setBusy(true); setError('');
    try {
      let message;
      if (mode === 'create' || mode === 'edit') {
        const payload = { nombre: form.nombre.trim(), descripcion: form.descripcion.trim() || null, areaId: form.areaId ? Number(form.areaId) : null };
        if (mode === 'edit') await api.put(`/api/flujos/${flow.id}`, { ...payload, version: flow.version });
        else await api.post('/api/flujos', payload);
        message = mode === 'create' ? 'Flujo creado como borrador inactivo. Configure sus etapas y actívelo cuando esté completo.' : 'Datos del flujo actualizados.';
      } else if (mode === 'stages') {
        await api.put(`/api/flujos/${flow.id}/etapas`, { version: flow.version, etapas: stages.map((stage, index) => ({ orden: index + 1, nombre: stage.nombre.trim(), ...assignmentPayload(stage), tipoAccion: 'REVISION' })) });
        message = flow.activo ? 'Etapas actualizadas. El flujo conserva su estado activo.' : 'Etapas guardadas. El flujo permanece inactivo hasta su activación.';
      } else if (mode === 'assignee') {
        const response = await api.put(`/api/workflows/${flow.id}/steps/${editor.stepId}/assignee`, { version: flow.version, ...assignmentPayload(assignee) });
        setFlows((current) => current.map((item) => item.id === flow.id ? response.data : item));
        message = 'Responsable actualizado. La secuencia, las solicitudes y su historial se conservan.';
      } else if (mode === 'status') {
        await api.patch(`/api/flujos/${flow.id}/status`, { activo: !flow.activo, version: flow.version });
        message = flow.activo ? 'Flujo desactivado. Las solicitudes existentes conservan su continuidad.' : 'Flujo activado y disponible para nuevas solicitudes autorizadas.';
      } else {
        await api.delete(`/api/flujos/${flow.id}`, { params: { version: flow.version } });
        message = 'Operación completada: el flujo se eliminó si no tenía solicitudes; en caso contrario, quedó desactivado conservando su historial.';
      }
      ++reviewerSequence.current; setEditor(null); setReviewers(emptyOptions());
      setNotice({ tone: 'success', text: message });
      await loadCatalog();
    } catch (err) {
      setError(workflowErrorMessage(err, 'No fue posible completar la operación.'));
      setBlocked(requiresWorkflowReload(err));
    } finally { busyRef.current = false; setBusy(false); }
  };

  const filtered = flows.filter((flow) => {
    const term = query.trim().toLocaleLowerCase('es');
    return (!term || `${flow.nombre} ${flow.descripcion || ''}`.toLocaleLowerCase('es').includes(term))
      && (!areaFilter || (areaFilter === 'GENERAL' ? flow.areaId == null : String(flow.areaId) === areaFilter))
      && (!statusFilter || (statusFilter === 'ACTIVO' ? flow.activo : statusFilter === 'INACTIVO' ? !flow.activo : !flow.completo));
  });
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount - 1);
  const visible = filtered.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);
  const flow = editor?.flow;
  const mode = editor?.mode;
  const title = mode === 'create' ? 'Crear flujo de aprobación' : mode === 'edit' ? 'Editar flujo de aprobación' : mode === 'stages' ? 'Secuencia de revisión' : mode === 'assignee' ? 'Cambiar responsable de revisión' : mode === 'status' ? `${flow?.activo ? 'Desactivar' : 'Activar'} flujo` : 'Eliminar flujo de aprobación';

  return <section className="flow-definitions" aria-label="Configuración de flujos por área">
    <div className="flows-section-header"><div><h3>Flujos por área corporativa</h3><p>Configure la secuencia de revisión y sus responsables antes de activar un flujo.</p></div><Button onClick={createFlow} disabled={loading || busy || (!globalAdmin && !areas.length)} data-testid="create-flow-btn"><Plus size={16} aria-hidden="true" />Crear flujo</Button></div>
    {notice && <FeedbackMessage tone={notice.tone}>{notice.text}</FeedbackMessage>}
    <Card className="flows-list-card">
      <div className="flows-toolbar"><div className="flows-filters">
        <div className="search-field flows-search-input"><Search size={16} aria-hidden="true" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar por nombre o descripción" aria-label="Buscar flujos" /></div>
        <DropdownSelect id="flow-area-filter" aria-label="Filtrar por área corporativa" value={areaFilter} onChange={setAreaFilter} options={[{ value: '', label: 'Todas las áreas' }, ...(globalAdmin ? [{ value: 'GENERAL', label: 'Ámbito general' }] : []), ...areas.map((area) => ({ value: String(area.id), label: area.nombre }))]} />
        <DropdownSelect id="flow-status-filter" aria-label="Filtrar por estado del flujo" value={statusFilter} onChange={setStatusFilter} options={[{ value: '', label: 'Todos los estados' }, { value: 'ACTIVO', label: 'Activos' }, { value: 'INACTIVO', label: 'Inactivos' }, { value: 'INCOMPLETO', label: 'Configuración incompleta' }]} />
      </div><Button variant="secondary" onClick={loadCatalog} disabled={loading || busy}><RefreshCw size={16} aria-hidden="true" />Actualizar</Button></div>
      {loading ? <EmptyState loading title="Cargando flujos…" /> : !filtered.length ? <EmptyState icon={Layers} title="No se encontraron flujos" action={query || areaFilter || statusFilter ? <Button variant="secondary" onClick={() => { setQuery(''); setAreaFilter(''); setStatusFilter(''); }}>Limpiar filtros</Button> : null}>Los flujos disponibles dependen de su ámbito de administración.</EmptyState> : <>
        <div className="table-scroll"><DataTable className="flows-table table-stackable flow-definitions-table" aria-label="Flujos de aprobación por área"><thead><tr><th scope="col">Flujo</th><th scope="col">Área corporativa</th><th scope="col">Etapas</th><th scope="col">Configuración</th><th scope="col">Estado</th><th scope="col">Acciones</th></tr></thead><tbody>{visible.map((item) => <tr key={item.id} data-testid={`flow-row-${item.id}`}>
          <td className="cell-primary" data-label="Flujo"><div className="cell-stack"><strong className="flow-name">{item.nombre}</strong>{item.descripcion && <span className="flow-desc flow-description">{item.descripcion}</span>}{item.id === 1 && <small className="flow-protected-tag">Flujo base protegido</small>}</div></td>
          <td data-label="Área corporativa">{item.areaNombre || 'Ámbito general'}</td><td data-label="Etapas"><span className="flow-stage-count">{item.etapas.length} {item.etapas.length === 1 ? 'etapa' : 'etapas'}</span></td><td data-label="Configuración"><StatusBadge status={item.completo ? 'ACTIVO' : 'CORRECCION_REQUERIDA'} label={item.completo ? 'Completa' : 'Incompleta'} /></td><td data-label="Estado"><StatusBadge status={item.activo ? 'ACTIVO' : 'INACTIVO'} /></td>
          <td className="cell-actions"><div className="row-actions"><Button variant="secondary" className="ui-button--compact" onClick={() => openExisting('stages', item)} disabled={busy} data-testid={`configure-stages-btn-${item.id}`}><Layers size={14} aria-hidden="true" />{item.estructuraEditable ? 'Configurar etapas' : 'Ver etapas'}</Button>
            <Button variant="secondary" className="ui-button--compact" onClick={() => openExisting('edit', item)} disabled={busy} aria-label={`Editar ${item.nombre}`} title="Editar flujo" data-testid={`edit-flow-btn-${item.id}`}><Edit2 size={14} aria-hidden="true" /></Button>
            <Button variant="secondary" className="ui-button--compact" onClick={() => openExisting('status', item)} disabled={busy || (!item.activo && !item.completo)} title={!item.activo && !item.completo ? 'Complete la configuración antes de activar' : undefined}>{item.activo ? 'Desactivar' : 'Activar'}</Button>
            {item.id !== 1 && <Button variant="secondary" className="ui-button--compact" onClick={() => openExisting('delete', item)} disabled={busy} aria-label={`Eliminar ${item.nombre}`} title="Eliminar flujo" data-testid={`delete-flow-btn-${item.id}`}><Trash2 size={14} aria-hidden="true" /></Button>}
          </div></td></tr>)}</tbody></DataTable></div>
        <footer className="areas-pagination"><span>{filtered.length} {filtered.length === 1 ? 'flujo' : 'flujos'} · 10 por página</span><nav aria-label="Paginación de flujos"><Button variant="secondary" onClick={() => setPage(currentPage - 1)} disabled={currentPage === 0} aria-label="Página anterior"><ChevronLeft size={16} /></Button><span aria-live="polite">Página {currentPage + 1} de {pageCount}</span><Button variant="secondary" onClick={() => setPage(currentPage + 1)} disabled={currentPage + 1 >= pageCount} aria-label="Página siguiente"><ChevronRight size={16} /></Button></nav></footer>
      </>}
    </Card>

    {editor && <AreaDialog key={`${mode}-${flow?.id || 'new'}-${editor.stepId || 'sequence'}`} className="flow-modal-dialog" titleId="flow-dialog-title" descriptionId="flow-dialog-description" busy={busy} onClose={closeEditor}>
      <header className="flow-modal-header"><div><h3 id="flow-dialog-title">{title}</h3><p id="flow-dialog-description">{flow?.nombre || 'El nuevo flujo quedará inactivo hasta completar sus etapas y activarlo.'}</p></div><Button variant="quiet" onClick={closeEditor} disabled={busy} aria-label="Cerrar diálogo"><X size={18} /></Button></header>
      <form className="flow-editor-form" onSubmit={save} noValidate>
        <div className="flow-modal-body">
          {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}
          {blocked && <FeedbackMessage>Se conservan los datos del formulario. {flow ? 'Cargar la versión vigente descartará los cambios del formulario; revise el estado actualizado antes de continuar.' : 'Revise el catálogo para comprobar el resultado antes de crear otro flujo.'}<Button variant="secondary" onClick={reloadEditor} disabled={busy}>{flow ? 'Cargar versión vigente y descartar cambios' : 'Cerrar y revisar catálogo'}</Button></FeedbackMessage>}
          {(mode === 'create' || mode === 'edit') && <>
            {flow && !flow.estructuraEditable && <FeedbackMessage>La estructura y el área se conservan para proteger las solicitudes existentes y el flujo base.</FeedbackMessage>}
            <FormField label="Nombre del flujo *" htmlFor="flow-name"><input id="flow-name" data-autofocus value={form.nombre} onChange={(event) => setForm({ ...form, nombre: event.target.value })} maxLength={150} disabled={busy || flow?.id === 1} /></FormField>
            <FormField label="Descripción" htmlFor="flow-description" optional><textarea id="flow-description" value={form.descripcion} onChange={(event) => setForm({ ...form, descripcion: event.target.value })} maxLength={2000} rows={3} disabled={busy} /></FormField>
            <FormField label="Área corporativa" htmlFor="flow-area" hint="Unidad responsable de administrar el flujo."><DropdownSelect id="flow-area" value={form.areaId} onChange={(value) => setForm({ ...form, areaId: value })} disabled={busy || (flow && !flow.estructuraEditable)} options={[...(globalAdmin ? [{ value: '', label: 'Ámbito general' }] : [{ value: '', label: 'Seleccione un área', disabled: true }]), ...areas.map((area) => ({ value: String(area.id), label: area.nombre })), ...(form.areaId && !areas.some((area) => String(area.id) === form.areaId) ? [{ value: form.areaId, label: flow?.areaNombre || 'Área no disponible', disabled: true }] : [])]} /></FormField>
          </>}
          {mode === 'stages' && <>
            <FeedbackMessage>{readOnlyStages ? 'La secuencia se conserva porque el flujo es base o tiene solicitudes vinculadas. Puede consultar sus etapas y cambiar responsables conservando la secuencia.' : 'Cada aprobación avanza al siguiente paso. La aprobación del último paso finaliza la solicitud. Guardar etapas no activa un borrador.'}</FeedbackMessage>
            {!readOnlyStages && reviewersError && <FeedbackMessage tone="error">{reviewersError}<Button variant="secondary" onClick={() => loadReviewers(flow)} disabled={reviewersLoading}>Actualizar responsables</Button></FeedbackMessage>}
            <div className="flow-sequence-marker">Inicio de la solicitud</div>
            <ol className="stages-builder flow-sequence" aria-label="Orden de revisión">{stages.map((stage, index) => <li key={stage.key} className="stage-item-card" data-testid={`stage-item-${index}`}>
              <div className="stage-header-row"><span className="stage-step-pill"><Layers size={13} aria-hidden="true" />Etapa {index + 1} · Revisión</span>{!readOnlyStages && <div className="stage-controls">
                <Button variant="secondary" className="ui-button--compact" onClick={() => moveStage(index, -1)} disabled={busy || index === 0} aria-label={`Subir etapa ${index + 1}`}><ArrowUp size={15} /></Button>
                <Button variant="secondary" className="ui-button--compact" onClick={() => moveStage(index, 1)} disabled={busy || index === stages.length - 1} aria-label={`Bajar etapa ${index + 1}`}><ArrowDown size={15} /></Button>
                <Button variant="secondary" className="ui-button--compact" onClick={() => setStages((current) => current.filter((_, i) => i !== index))} disabled={busy} aria-label={`Eliminar etapa ${index + 1}`}><Trash2 size={15} /></Button>
              </div>}</div>
              {readOnlyStages ? <div className="stage-assignment-summary"><div className="cell-stack"><strong>{stage.nombre}</strong>
                <span>{flow.id === 1 ? 'Revisor autorizado según los permisos de la solicitud' : assignmentLabel(stage)}</span>
                {stage.tipoAsignacion === 'ROL_DEPARTAMENTAL' && <small>{flow.areaNombre} · {stage.revisoresDisponibles || 0} revisores disponibles</small>}
                {flow.id !== 1 && !stage.responsableDisponible && <FeedbackMessage tone="warning">El responsable no está disponible. Reasigne esta etapa antes de activar el flujo.</FeedbackMessage>}
              </div>{flow.id !== 1 && <Button variant="secondary" className="ui-button--compact" onClick={() => openExisting('assignee', flow, stage.id)} disabled={busy}><Edit2 size={14} aria-hidden="true" />Cambiar responsable</Button>}</div> : <>
                <FormField label="Nombre de la etapa *" htmlFor={`stage-name-${index}`} error={!validName(stage.nombre) ? 'Ingrese un nombre válido (hasta 150 caracteres).' : undefined}><input id={`stage-name-${index}`} value={stage.nombre} onChange={(event) => changeStage(index, 'nombre', event.target.value)} maxLength={150} disabled={busy} /></FormField>
                <ReviewerSelector id={`stage-reviewer-${index}`} value={stage} onChange={(value) => setStages((current) => current.map((item, i) => i === index ? value : item))}
                  options={reviewers} areaNombre={flow.areaNombre} loading={reviewersLoading} catalogError={reviewersError} disabled={busy || blocked} />
              </>}

            </li>)}</ol>
            {!stages.length && <FeedbackMessage tone="error">Agregue al menos una etapa para completar el flujo.</FeedbackMessage>}
            {!readOnlyStages && <div className="add-stage-btn-row"><Button variant="secondary" onClick={() => setStages((current) => [...current, draftStage()])} disabled={busy}><Plus size={16} aria-hidden="true" />Agregar etapa</Button></div>}
            <div className="flow-sequence-marker">Aprobación final tras completar todas las etapas</div>
          </>}
          {mode === 'assignee' && <>
            <div className="stage-assignee-heading"><span className="stage-step-pill">Etapa {assignee.orden} · Revisión</span><h4>{assignee.nombre}</h4></div>
            <FeedbackMessage>El cambio se aplicará a las revisiones actuales y futuras de esta etapa. Las aprobaciones anteriores y los documentos conservan su historial.</FeedbackMessage>
            {reviewersError && <FeedbackMessage tone="error">{reviewersError}<Button variant="secondary" onClick={() => loadReviewers(flow, editor.stepId)} disabled={reviewersLoading || busy}>Actualizar responsables</Button></FeedbackMessage>}
            <ReviewerSelector id="step-assignee" value={assignee} onChange={setAssignee} options={reviewers} areaNombre={flow.areaNombre}
              loading={reviewersLoading} catalogError={reviewersError} disabled={busy || blocked} />
          </>}
          {mode === 'status' && <><div className="area-status-summary"><StatusBadge status={flow.activo ? 'ACTIVO' : 'INACTIVO'} /><span>→</span><StatusBadge status={flow.activo ? 'INACTIVO' : 'ACTIVO'} /></div><p>{flow.activo ? 'Se impedirá el uso del flujo en nuevas solicitudes. Las solicitudes existentes podrán continuar su revisión.' : 'El flujo estará disponible para nuevas solicitudes. Se comprobarán su configuración, el área y los responsables vigentes.'}</p>{!flow.activo && !flow.completo && <FeedbackMessage tone="error">Complete la configuración antes de activar este flujo.</FeedbackMessage>}</>}
          {mode === 'delete' && <><p>Confirme la eliminación de <strong>{flow.nombre}</strong>.</p><FeedbackMessage>Si tiene solicitudes vinculadas, se desactivará y conservará sus etapas e historial. Si no tiene solicitudes, se eliminará del catálogo.</FeedbackMessage></>}
        </div>
        <footer className="flow-modal-footer"><Button variant="secondary" onClick={closeEditor} disabled={busy}>{readOnlyStages ? 'Cerrar' : 'Cancelar'}</Button>{!readOnlyStages && <Button type="submit" variant={mode === 'delete' ? 'danger' : 'primary'} loading={busy} disabled={blocked || ((mode === 'stages' || mode === 'assignee') && (reviewersLoading || Boolean(reviewersError) || (mode === 'stages' ? !stagesValid : !assignmentAvailable(assignee, reviewers)))) || (mode === 'status' && !flow.activo && !flow.completo)}>{mode === 'create' ? 'Crear borrador' : mode === 'edit' ? 'Guardar cambios' : mode === 'stages' ? 'Guardar etapas' : mode === 'assignee' ? 'Guardar responsable' : mode === 'status' ? flow.activo ? 'Desactivar flujo' : 'Activar flujo' : 'Confirmar eliminación'}</Button>}</footer>
      </form>
    </AreaDialog>}
  </section>;
}
