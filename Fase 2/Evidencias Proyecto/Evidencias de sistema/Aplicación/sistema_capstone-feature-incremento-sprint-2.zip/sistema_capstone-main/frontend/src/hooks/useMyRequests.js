import { useCallback, useEffect, useRef, useState } from 'react';
import { useAccess } from '../components/access/AccessContext';
import { getMyRequests, myRequestsAreas, myRequestsError, myRequestsParams } from '../services/myRequests';

export default function useMyRequests(tray, filters, page) {
  const { context, revision, refresh: refreshAccess } = useAccess();
  const [result, setResult] = useState(null);
  const [catalogResult, setCatalogResult] = useState(null);
  const [catalogReload, setCatalogReload] = useState(0);
  const sequence = useRef(0);
  const controls = useRef(null);
  const previous = useRef(null);
  const fingerprint = JSON.stringify(context);
  const parameters = JSON.stringify(myRequestsParams(tray, filters, page));
  // La revisión provoca una lectura; conservar datos solo si identidad, política y consulta siguen iguales.
  const key = `${fingerprint}:${tray}:${parameters}`;
  const catalogKey = `${fingerprint}:${revision}:${catalogReload}`;

  useEffect(() => {
    let alive = true;
    let controller = null;
    let timer = null;
    let inFlight = false;
    let failures = 0;
    const cancel = () => {
      window.clearTimeout(timer);
      ++sequence.current;
      controller?.abort();
      controller = null;
      inFlight = false;
    };
    const schedule = (delay) => {
      window.clearTimeout(timer);
      if (alive && !document.hidden) timer = window.setTimeout(run, delay);
    };
    const run = async () => {
      if (!alive || document.hidden || inFlight) return;
      window.clearTimeout(timer);
      inFlight = true;
      controller = new AbortController();
      const currentController = controller;
      const currentSequence = ++sequence.current;
      const current = () => alive && !currentController.signal.aborted && sequence.current === currentSequence;
      setResult((old) => ({ key, data: old?.key === key ? old.data : null,
        error: old?.key === key ? old.error : null, refreshing: true, announcement: '' }));
      let delay = 30000;
      let retry = true;
      try {
        const access = await refreshAccess();
        if (!current() || !access || JSON.stringify(access) !== fingerprint) return;
        const data = await getMyRequests(tray, JSON.parse(parameters), currentController.signal);
        if (!current()) return;
        const contentFingerprint = JSON.stringify([data.contenido, data.totalElementos, data.pagina]);
        const changed = previous.current?.key === key && previous.current.content !== contentFingerprint;
        previous.current = { key, content: contentFingerprint };
        failures = 0;
        setResult({ key, data, error: null, refreshing: false,
          announcement: changed ? 'La consulta se actualizó. Hay cambios en las solicitudes disponibles.' : '' });
      } catch (error) {
        if (!current()) return;
        const failure = myRequestsError(error);
        retry = failure.retryable;
        failures += 1;
        delay = Math.min(120000, 30000 * (2 ** Math.min(failures, 2)));
        setResult((old) => ({ key, data: !failure.restricted && old?.key === key ? old.data : null,
          error: failure, refreshing: false, announcement: '' }));
      } finally {
        if (current()) {
          inFlight = false;
          controller = null;
          if (retry) schedule(delay);
        }
      }
    };
    const visibility = () => {
      if (document.hidden) {
        cancel();
        setResult((old) => old?.key === key ? { ...old, refreshing: false } : old);
      } else run();
    };
    controls.current = { refresh: run };
    document.addEventListener('visibilitychange', visibility);
    run();
    return () => {
      alive = false;
      cancel();
      controls.current = null;
      document.removeEventListener('visibilitychange', visibility);
    };
  }, [key, fingerprint, parameters, tray, revision, refreshAccess]);

  useEffect(() => {
    if (tray !== 'autorizadas') return undefined;
    let alive = true;
    let controller = null;
    const read = async () => {
      if (!alive || document.hidden || controller) return;
      const request = new AbortController();
      controller = request;
      try {
        const data = await myRequestsAreas(request.signal);
        if (alive && !request.signal.aborted) setCatalogResult({ key: catalogKey, scope: fingerprint, data, error: null });
      } catch (error) {
        if (alive && !request.signal.aborted) {
          const failure = myRequestsError(error, true);
          setCatalogResult({ key: catalogKey, scope: fingerprint, data: null, error: failure });
          if (failure.restricted) setResult((old) => old?.key === key ? { ...old, data: null, error: failure } : old);
        }
      } finally { if (controller === request) controller = null; }
    };
    const visibility = () => {
      if (document.hidden) { controller?.abort(); controller = null; }
      else read();
    };
    document.addEventListener('visibilitychange', visibility);
    read();
    return () => { alive = false; controller?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [tray, catalogKey, fingerprint, key]);

  const current = result?.key === key ? result : null;
  const catalog = tray === 'autorizadas' && catalogResult?.key === catalogKey ? catalogResult : null;
  const catalogRestriction = tray === 'autorizadas' && catalogResult?.scope === fingerprint && catalogResult.error?.restricted ? catalogResult.error : null;
  const restricted = Boolean(current?.error?.restricted || catalogRestriction);
  return {
    data: restricted ? null : current?.data || null,
    error: current?.error || catalogRestriction,
    loading: !current || (!current.data && !current.error),
    refreshing: current?.refreshing ?? true,
    stale: Boolean(current?.data && current.error),
    restricted,
    announcement: current?.announcement || '',
    areas: restricted ? null : catalog?.data || null,
    areasError: catalog?.error || null,
    areasLoading: tray === 'autorizadas' && !catalog,
    refresh: useCallback(() => { controls.current?.refresh(); setCatalogReload((value) => value + 1); }, []),
    refreshAreas: useCallback(() => setCatalogReload((value) => value + 1), [])
  };
}
