import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, AlertTriangle, CheckCircle2, FileText, Info, LoaderCircle, MoreVertical, RotateCw, X } from 'lucide-react';
export { default as DropdownSelect } from './DropdownSelect';

// Puntos de quiebre compartidos con App.css (las media queries CSS no admiten variables).
export const BREAKPOINTS = { desktop: 1280, tablet: 1024, mobile: 768, small: 480 };
export const MOBILE_QUERY = '(max-width: 767px)';
export const TABLET_QUERY = '(min-width: 768px) and (max-width: 1279px)';
// Debe coincidir con el punto de quiebre de .master-detail en styles/responsive.css.
export const SPLIT_VIEW_COMPACT_QUERY = '(max-width: 1023px)';

export function useMediaQuery(query) {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mediaQuery = window.matchMedia(query);
    const update = () => setMatches(window.matchMedia(query).matches);
    update();
    // 'resize' cubre los saltos de tamaño en los que algunos navegadores no emiten 'change'.
    mediaQuery.addEventListener('change', update);
    window.addEventListener('resize', update);
    return () => {
      mediaQuery.removeEventListener('change', update);
      window.removeEventListener('resize', update);
    };
  }, [query]);
  return matches;
}

const FOCUSABLE = 'button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])';

export function DetailModal({ open, onClose, labelledBy, children }) {
  const dialogRef = useRef(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return undefined;
    const previousFocus = document.activeElement;
    dialogRef.current?.focus();
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== 'Tab' || !dialogRef.current) return;
      const focusable = dialogRef.current.querySelectorAll(FOCUSABLE);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, [open]);

  if (!open) return null;
  return createPortal(
    <div className="sheet-backdrop" role="presentation" onMouseDown={() => onCloseRef.current()}>
      <section
        ref={dialogRef}
        className="sheet-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        tabIndex="-1"
        onMouseDown={(event) => event.stopPropagation()}
      >
        {children}
      </section>
    </div>,
    document.body
  );
}

const BUTTON_VARIANTS = new Set(['primary', 'secondary', 'success', 'warning', 'danger', 'info', 'quiet']);
// Las clases heredadas se conservan porque los tests E2E y algunas vistas las usan como selectores.
const BUTTON_CLASS_NAMES = {
  primary: 'primary-btn', secondary: 'secondary-btn', success: 'success-btn',
  warning: 'warning-btn', danger: 'danger-btn', info: '', quiet: ''
};

export function Button({ as: Component = 'button', variant = 'primary', loading = false, disabled = false, className = '', children, onClick, ...props }) {
  const tone = BUTTON_VARIANTS.has(variant) ? variant : 'primary';
  const isButton = Component === 'button';
  const isDisabled = disabled || loading;
  return (
    <Component
      {...props}
      {...(isButton ? { type: props.type || 'button', disabled: isDisabled } : isDisabled ? { tabIndex: -1 } : {})}
      className={`ui-button ui-button--${tone} ${BUTTON_CLASS_NAMES[tone]} ${className}`.trim()}
      aria-busy={loading || undefined}
      aria-disabled={!isButton && isDisabled ? true : undefined}
      onClick={(event) => {
        if (isDisabled) {
          event.preventDefault();
          return;
        }
        onClick?.(event);
      }}
    >
      {loading && <LoaderCircle className="button-spinner" size={17} aria-hidden="true" />}
      {children}
    </Component>
  );
}

export function PageHeader({ eyebrow, title, titleId, description, icon: Icon, actions, className = '', children }) {
  return (
    <header className={`page-header ${className}`.trim()}>
      <div className="page-header-main">
        {Icon && <span className="page-header-icon" aria-hidden="true"><Icon size={22} /></span>}
        <div className="page-header-text">
          {eyebrow && <p className="page-eyebrow">{eyebrow}</p>}
          <h2 id={titleId}>{title}</h2>
          {description && <p className="page-header-description">{description}</p>}
          {children}
        </div>
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </header>
  );
}

export function FormField({ label, htmlFor, optional = false, hint, hintId, error, className = '', children }) {
  return (
    <label className={`field ui-field ${error ? 'ui-field--error' : ''} ${className}`.trim()} htmlFor={htmlFor}>
      <span className="ui-field-label">{label}{optional && <span className="field-optional"> (opcional)</span>}</span>
      {children}
      {hint && <small id={hintId}>{hint}</small>}
      {error && <small className="ui-field-error">{error}</small>}
    </label>
  );
}

const STATUS_STYLES = {
  PENDIENTE_REVISION: ['pending', 'Pendiente de revisión'],
  CORRECCION_REQUERIDA: ['correction', 'Corrección requerida'],
  APROBADO: ['approved', 'Aprobado'],
  RECHAZADO: ['rejected', 'Rechazado'],
  ACTIVO: ['active', 'Activo'],
  INACTIVO: ['inactive', 'Inactivo']
};

export function getStatusLabel(status) {
  return STATUS_STYLES[status]?.[1] || status?.replaceAll('_', ' ') || 'Sin estado';
}

export function StatusBadge({ status, label, className = '' }) {
  const [tone] = STATUS_STYLES[status] || [''];
  return <span className={`status-badge ui-status-badge ${tone ? `status-badge-${tone}` : ''} ${className}`.trim()}>{label || getStatusLabel(status)}</span>;
}

const FEEDBACK_ICONS = { error: AlertCircle, success: CheckCircle2, info: Info, warning: AlertTriangle };

export function FeedbackMessage({ tone = 'info', title, children, className = '' }) {
  const Icon = FEEDBACK_ICONS[tone] || Info;
  const role = tone === 'error' ? 'alert' : 'status';
  return (
    <div className={`form-message form-message-${tone} ui-feedback ${className}`.trim()} role={role} aria-live={role === 'status' ? 'polite' : undefined}>
      <Icon size={18} aria-hidden="true" />
      <div className="ui-feedback-content">{title && <strong>{title}</strong>}{children && <div>{children}</div>}</div>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, children, action, loading = false, tone = 'neutral', className = '', ...props }) {
  // La carga se presenta como un esqueleto de filas; el título queda como leyenda breve y accesible.
  if (loading) {
    return (
      <div className={`loading-state ui-loading-state ${className}`.trim()} role="status" aria-live="polite" {...props}>
        <SkeletonRows rows={4} />
        {title && <span className="loading-state-caption"><LoaderCircle className="button-spinner" size={14} aria-hidden="true" />{title}</span>}
      </div>
    );
  }
  const StateIcon = Icon || (tone === 'error' ? AlertCircle : null);
  return (
    <div className={`empty-state ui-empty-state ui-empty-state--${tone} ${className}`.trim()} {...props}>
      {StateIcon && <span className="empty-state-icon" aria-hidden="true"><StateIcon size={24} /></span>}
      {title && <strong>{title}</strong>}
      {children && <span>{children}</span>}
      {action && <div className="empty-state-action">{action}</div>}
    </div>
  );
}

/** Estado de error recuperable con acción de reintento. */
export function ErrorState({ title = 'No fue posible cargar la información', children, onRetry, retryLabel = 'Reintentar', action, className = '' }) {
  return (
    <EmptyState
      tone="error"
      role="alert"
      title={title}
      className={className}
      action={(onRetry || action) && <>{onRetry && <Button variant="secondary" onClick={onRetry}><RotateCw size={16} aria-hidden="true" />{retryLabel}</Button>}{action}</>}
    >
      {children}
    </EmptyState>
  );
}

/* ---------- Esqueletos de carga ---------- */

export function Skeleton({ width, height, radius, className = '', style }) {
  return <span className={`skeleton ${className}`.trim()} style={{ width, height, borderRadius: radius, ...style }} aria-hidden="true" />;
}

export function SkeletonRows({ rows = 4 }) {
  return (
    <div className="skeleton-rows" aria-hidden="true">
      {Array.from({ length: rows }, (_, index) => (
        <div className="skeleton-row" key={index}>
          <Skeleton width={36} height={36} radius={8} />
          <div className="skeleton-row-text">
            <Skeleton width={`${62 - (index % 3) * 12}%`} height={12} />
            <Skeleton width={`${38 - (index % 2) * 10}%`} height={10} />
          </div>
          <Skeleton className="skeleton-row-pill" width={88} height={22} radius={999} />
        </div>
      ))}
    </div>
  );
}

/** Esqueleto de página completa para rutas diferidas (Suspense). */
export function PageSkeleton({ variant = 'table', label = 'Cargando contenido…' }) {
  return (
    <div className={`page-skeleton page-skeleton--${variant}`} role="status" aria-live="polite">
      <span className="visually-hidden">{label}</span>
      <div className="page-skeleton-header" aria-hidden="true">
        <Skeleton width={96} height={10} />
        <Skeleton width={260} height={26} />
        <Skeleton width="min(520px, 80%)" height={12} />
      </div>
      {variant === 'dashboard' && (
        <div className="page-skeleton-kpis" aria-hidden="true">
          {Array.from({ length: 4 }, (_, index) => (
            <div className="page-skeleton-card" key={index}>
              <Skeleton width="60%" height={12} />
              <Skeleton width={72} height={30} />
              <Skeleton width="40%" height={10} />
            </div>
          ))}
        </div>
      )}
      {variant === 'form' ? (
        <div className="page-skeleton-card page-skeleton-form" aria-hidden="true">
          {Array.from({ length: 4 }, (_, index) => (
            <div className="page-skeleton-field" key={index}>
              <Skeleton width={120} height={10} />
              <Skeleton width="100%" height={40} radius={8} />
            </div>
          ))}
          <Skeleton width={160} height={40} radius={8} />
        </div>
      ) : variant === 'detail' ? (
        <div className="page-skeleton-split" aria-hidden="true">
          <div className="page-skeleton-card"><SkeletonRows rows={3} /></div>
          <div className="page-skeleton-card"><SkeletonRows rows={5} /></div>
        </div>
      ) : (
        <div className="page-skeleton-card page-skeleton-table" aria-hidden="true">
          <div className="page-skeleton-toolbar">
            <Skeleton width={240} height={36} radius={8} />
            <Skeleton width={120} height={36} radius={8} />
          </div>
          <SkeletonRows rows={variant === 'dashboard' ? 3 : 6} />
        </div>
      )}
    </div>
  );
}

/** Pantalla de arranque con la forma del shell mientras se cargan los permisos de la cuenta. */
export function AppLoadingScreen({ label = 'Cargando acceso a la plataforma…' }) {
  return (
    <div className="app-loading" role="status" aria-live="polite">
      <span className="visually-hidden">{label}</span>
      <div className="app-loading-sidebar" aria-hidden="true">
        <img className="brand-wordmark" src="/masterbase-wordmark.png" alt="" width="132" height="18" />
        <div className="app-loading-nav">
          {Array.from({ length: 8 }, (_, index) => <span key={index} className="skeleton skeleton--dark" style={{ width: `${70 - (index % 3) * 12}%` }} />)}
        </div>
      </div>
      <div className="app-loading-main" aria-hidden="true">
        <div className="app-loading-topbar"><Skeleton width={180} height={14} /><Skeleton width={34} height={34} radius={999} /></div>
        <div className="app-loading-content"><PageSkeleton variant="dashboard" label={label} /></div>
      </div>
    </div>
  );
}

/* ---------- Más acciones (hoja de acciones móvil) ---------- */

/**
 * Agrupa las acciones de una fila en pantallas pequeñas: un botón "Más acciones" abre una hoja
 * inferior con cada acción rotulada. items: [{ label, icon, onClick, danger, disabled, hidden }].
 */
export function MoreActions({ title, items }) {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef(null);
  const sheetRef = useRef(null);
  const visibleItems = items.filter((item) => !item.hidden);

  useEffect(() => {
    if (!open) return undefined;
    sheetRef.current?.querySelector('button:not(:disabled)')?.focus();
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setOpen(false);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      if (triggerRef.current?.isConnected) triggerRef.current.focus();
    };
  }, [open]);

  if (!visibleItems.length) return null;
  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        className="action-btn more-actions-trigger"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={title ? `Más acciones para ${title}` : 'Más acciones'}
        title="Más acciones"
        onClick={(event) => { event.stopPropagation(); setOpen(true); }}
      >
        <MoreVertical size={18} aria-hidden="true" />
      </button>
      {open && createPortal(
        <div className="action-sheet-backdrop" role="presentation" onMouseDown={() => setOpen(false)}>
          <div ref={sheetRef} className="action-sheet" role="dialog" aria-modal="true" aria-label={title ? `Acciones para ${title}` : 'Acciones'} onMouseDown={(event) => event.stopPropagation()}>
            {title && <div className="action-sheet-header"><span>Acciones</span><strong>{title}</strong></div>}
            <ul className="action-sheet-list">
              {visibleItems.map(({ label, icon: Icon, onClick, danger, disabled }) => (
                <li key={label}>
                  <button type="button" className={`action-sheet-item${danger ? ' is-danger' : ''}`} disabled={disabled}
                    onClick={() => { setOpen(false); onClick(); }}>
                    {Icon && <Icon size={18} aria-hidden="true" />}
                    <span>{label}</span>
                  </button>
                </li>
              ))}
            </ul>
            <button type="button" className="action-sheet-cancel" onClick={() => setOpen(false)}>Cancelar</button>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* ---------- Avisos (toast) ---------- */

const ToastContext = createContext(null);
const TOAST_ICONS = { success: CheckCircle2, error: AlertCircle, info: Info, warning: AlertTriangle };
let toastSequence = 0;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const timers = useRef(new Map());

  const dismiss = useCallback((id) => {
    window.clearTimeout(timers.current.get(id));
    timers.current.delete(id);
    setToasts((list) => list.filter((toast) => toast.id !== id));
  }, []);

  const notify = useCallback(({ tone = 'success', title, message, duration = 5000 }) => {
    toastSequence += 1;
    const id = toastSequence;
    setToasts((list) => [...list.slice(-2), { id, tone, title, message }]);
    if (duration) timers.current.set(id, window.setTimeout(() => dismiss(id), duration));
    return id;
  }, [dismiss]);

  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((timer) => window.clearTimeout(timer));
  }, []);

  const value = useMemo(() => ({ notify, dismiss }), [notify, dismiss]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      {createPortal(
        <div className="toast-region" aria-live="polite" aria-label="Avisos">
          {toasts.map((toast) => {
            const Icon = TOAST_ICONS[toast.tone] || Info;
            return (
              <div key={toast.id} className={`toast toast--${toast.tone}`} role={toast.tone === 'error' ? 'alert' : undefined}>
                <Icon className="toast-icon" size={18} aria-hidden="true" />
                <div className="toast-content">
                  {toast.title && <strong>{toast.title}</strong>}
                  {toast.message && <span>{toast.message}</span>}
                </div>
                <button type="button" className="toast-close" onClick={() => dismiss(toast.id)} aria-label="Cerrar aviso">
                  <X size={16} aria-hidden="true" />
                </button>
              </div>
            );
          })}
        </div>,
        document.body
      )}
    </ToastContext.Provider>
  );
}

const NOOP_TOASTS = { notify: () => null, dismiss: () => {} };

/** Muestra avisos breves no bloqueantes: notify({ tone, title, message, duration }). */
export function useToast() {
  return useContext(ToastContext) || NOOP_TOASTS;
}

export function DataTable({ children, className = '', ...props }) {
  return <table className={`data-table ui-data-table ${className}`.trim()} {...props}>{children}</table>;
}

export function Card({ as: Component = 'section', className = '', children, ...props }) {
  return <Component className={`management-card ui-card ${className}`.trim()} {...props}>{children}</Component>;
}

const FILE_TYPES = {
  pdf: 'pdf', doc: 'word', docx: 'word', xls: 'sheet', xlsx: 'sheet', txt: 'text', xml: 'code'
};

export function FileTypeIcon({ fileName, className = '' }) {
  const extension = fileName?.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
  const tone = FILE_TYPES[extension] || 'generic';
  return (
    <span className={`ui-file-icon ui-file-icon--${tone} ${className}`.trim()} aria-hidden="true">
      {extension ? extension.slice(0, 4).toUpperCase() : <FileText size={17} />}
    </span>
  );
}

export function formatFileSize(bytes) {
  if (!bytes) return '';
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DateTimeStack({ value, timeZone }) {
  const date = value ? new Date(value) : null;
  if (!date || Number.isNaN(date.getTime())) return <span className="date-stack">—</span>;
  return (
    <time className="date-stack" dateTime={value}>
      <span>{new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short', year: 'numeric', timeZone }).format(date)}</span>
      <small>{new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit', timeZone }).format(date)}</small>
    </time>
  );
}

export function formatDateTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(date);
}
