import React from 'react';
import { CheckCircle2, Circle, FileEdit, FilePlus2, RotateCcw, UserRound, XCircle } from 'lucide-react';
import { formatDateTime, getStatusLabel } from '../ui';
import { stageLabel } from '../../services/workflowErrors';

const ACTIONS = {
  CREAR: ['Solicitud creada', 'brand', FilePlus2],
  APROBAR: ['Solicitud aprobada', 'success', CheckCircle2],
  RECHAZAR: ['Solicitud rechazada', 'error', XCircle],
  PEDIR_CORRECCION: ['Corrección solicitada', 'warning', FileEdit],
  REENVIAR: ['Solicitud reenviada', 'info', RotateCcw]
};

export default function RequestHistory({ events }) {
  return <ol className="timeline request-history" aria-label="Eventos de la solicitud, del más antiguo al más reciente">
    {events.map((event) => {
      const [label, tone, Icon] = ACTIONS[event.accion] || ['Evento registrado', 'neutral', Circle];
      return <li key={event.id} className={`timeline-item timeline-item--${tone}`}>
        <span className="timeline-dot" aria-hidden="true"><Icon size={15} /></span>
        <div className="timeline-content">
          <div className="timeline-head"><strong className="timeline-title">{event.accion === 'APROBAR' && event.estadoDestino === 'PENDIENTE_REVISION' ? 'Etapa aprobada' : label}</strong></div>
          <p className="timeline-transition">{event.estadoOrigen === 'INICIAL' ? 'Inicio' : getStatusLabel(event.estadoOrigen)} → {getStatusLabel(event.estadoDestino)}</p>
          {(event.etapaOrigen || event.etapaDestino) && <p className="timeline-transition">{event.etapaOrigen ? stageLabel(event.etapaOrigen) : 'Etapa de origen no registrada'} → {event.etapaDestino ? stageLabel(event.etapaDestino) : 'Etapa de destino no registrada'}</p>}
          <p className="timeline-meta"><UserRound size={14} aria-hidden="true" /><span>{event.usuarioNombre || 'Usuario no disponible'}</span><span aria-hidden="true">·</span><time dateTime={event.createdAt}>{formatDateTime(event.createdAt)}</time></p>
          <p className={`request-event-sla request-event-sla--${event.dentroSla === null ? 'none' : event.dentroSla ? 'ok' : 'late'}`}>{event.dentroSla === null ? 'Cumplimiento de plazo: no evaluado' : event.dentroSla ? 'Decisión dentro del plazo' : 'Decisión fuera del plazo'}</p>
          {event.comentarioVisible && event.comentario && <blockquote className="timeline-comment">{event.comentario}</blockquote>}
          {!event.comentarioVisible && <p className="request-restricted-comment">Comentario restringido por permisos.</p>}
        </div>
      </li>;
    })}
  </ol>;
}
