import api from './api';

export const SCOPE_LABELS = {
  PROPIAS: 'Solicitudes propias', AREA: 'Área del usuario', EQUIPO_DIRECTO: 'Equipo directo',
  ASIGNADAS: 'Revisiones asignadas', AREAS_ADMINISTRADAS: 'Áreas administradas',
  PARTICIPACION_AREA: 'Participación del área', GLOBAL: 'Toda la organización'
};
export const PERMISSION_LABELS = {
  ROL_GESTIONAR: 'Administrar roles y permisos', USUARIO_GESTIONAR: 'Administrar usuarios',
  AREA_GESTIONAR: 'Administrar áreas', AUDITORIA_CONSULTAR: 'Consultar auditoría', SLA_GESTIONAR: 'Administrar plazos SLA',
  FLUJO_GESTIONAR: 'Configurar flujos', SOLICITUD_CREAR: 'Crear solicitudes', SOLICITUD_REENVIAR: 'Reenviar correcciones',
  SOLICITUD_APROBAR: 'Aprobar solicitudes', SOLICITUD_RECHAZAR: 'Rechazar solicitudes',
  SOLICITUD_PEDIR_CORRECCION: 'Solicitar correcciones', REVISION_CONSULTAR: 'Consultar bandeja de revisión',
  SOLICITUD_CONSULTAR: 'Consultar solicitudes', DOCUMENTO_DESCARGAR: 'Descargar documentos',
  HISTORIAL_CONSULTAR: 'Consultar historial', OBSERVACION_CONSULTAR: 'Consultar observaciones',
  METRICAS_CONSULTAR: 'Consultar indicadores', IA_SOLICITAR: 'Solicitar análisis automático', IA_CONSULTAR: 'Consultar análisis automático'
};
export const allowsAction = (solicitud, action) => solicitud?.accionesPermitidas?.includes(action) === true;
export const problemMessage = (error) => Object.values(error.response?.data?.invalidFields || {})[0]
  || error.response?.data?.detail || 'No fue posible completar la operación. Vuelva a intentarlo.';
export const isVersionConflict = (error) => error.response?.data?.codigo === 'RBAC_VERSION_DESACTUALIZADA';

export async function loadAssignableRoles(signal) {
  const roles = [];
  let page = 0;
  let result;
  do {
    result = (await api.get('/api/rbac/roles', { params: { page, size: 100, activo: true }, signal })).data;
    roles.push(...result.contenido);
    page += 1;
  } while (page < result.totalPaginas);
  return roles.filter((role) => role.asignacion === 'EXPLICITA' && role.codigo !== 'APPROVER');
}
