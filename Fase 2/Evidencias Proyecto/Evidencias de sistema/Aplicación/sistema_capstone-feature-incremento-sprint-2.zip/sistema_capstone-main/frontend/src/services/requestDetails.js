import api from './api';
import { allowsAction } from './rbac';
import { downloadError, getDocumentFile } from './documentDownloads';

export async function getRequestDetail(id, signal) {
  const { data } = await api.get(`/api/requests/${encodeURIComponent(id)}/detail`, { signal });
  const sectionIsValid = (section) => typeof section?.accesible === 'boolean' && Array.isArray(section.elementos);
  if (data?.id?.toLowerCase() !== id.toLowerCase() || !data.estado || !data.sla
      || !Array.isArray(data.documentos) || !Array.isArray(data.accionesPermitidas)
      || !sectionIsValid(data.observaciones) || !sectionIsValid(data.historial)) {
    throw new Error('La respuesta del detalle no está disponible.');
  }
  return data;
}

export function requestDetailError(error) {
  const status = error.response?.status;
  if (status === 404) return 'La solicitud no está disponible con el acceso actual.';
  if (status === 403) return 'No tiene permiso para consultar esta solicitud.';
  if (status === 401) return 'La sesión ya no está disponible. Vuelva a iniciar sesión.';
  if (status === 400) return 'El identificador de la solicitud no es válido.';
  if (status === 409) return 'La información documental de la solicitud requiere revisión. Contacte a la administración.';
  return 'No fue posible cargar la información de la solicitud. Intente nuevamente.';
}

export const documentError = downloadError;

export async function getCurrentDocument(detail, signal) {
  const file = detail.documentoVigente;
  const expectedUrl = '/api/documents/' + file?.id + '/download';
  if (!allowsAction(detail, 'DESCARGAR') || file?.descargaUrl !== expectedUrl) {
    throw new Error('Descarga no disponible.');
  }
  const result = await getDocumentFile({ documentId: file.id, solicitudId: detail.id, fileName: file.nombreArchivo }, signal);
  return result.blob;
}
const RETURN_ROUTES = new Set(['/estado-solicitudes', '/revisar-documento', '/mis-documentos', '/consultar-documentos']);

export function requestReturnTarget(origin) {
  if (!RETURN_ROUTES.has(origin?.pathname)) return { pathname: '/estado-solicitudes', search: '', state: null };
  return {
    pathname: origin.pathname,
    search: typeof origin.search === 'string' && origin.search.startsWith('?') ? origin.search : '',
    state: origin.state && typeof origin.state === 'object' ? origin.state : null
  };
}

export function requestAreaLabel(area, general = false) {
  if (!area) return general ? 'Flujo general' : 'Sin área registrada';
  if (!area.nombre) return 'Área no disponible';
  return `${area.nombre}${area.activa === false ? ' (inactiva)' : ''}`;
}
