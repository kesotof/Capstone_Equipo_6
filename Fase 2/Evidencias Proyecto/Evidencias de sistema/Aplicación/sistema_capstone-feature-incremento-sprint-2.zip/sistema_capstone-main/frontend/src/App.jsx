import React, { Suspense, lazy, useEffect, useRef, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { ChevronRight, Menu, PanelLeftClose, PanelLeftOpen } from 'lucide-react';

// Acceso
import RecuperarPasswordView from './views/acceso/RecuperarPasswordView';

// Configuración del negocio
import ConfigurarFlujosView from './views/configuracion/ConfigurarFlujosView';
import ConfigurarOrgUsuariosView from './views/configuracion/ConfigurarOrgUsuariosView';
import AreaManagementPage from './views/configuracion/AreaManagementPage';
import ConfigurarPlanillasView from './views/configuracion/ConfigurarPlanillasView';

// Gestión Documentos
import NuevoDocumentoView from './views/documentos/NuevoDocumentoView';
import MisDocumentosView from './views/documentos/MisDocumentosView';
import CompletarPlanillaView from './views/documentos/CompletarPlanillaView';

// Gestión Flujos
import RevisarDocumentoView from './views/flujos/RevisarDocumentoView';
import CorregirDocumentoView from './views/flujos/CorregirDocumentoView';
import DashboardView from './views/dashboard/DashboardView';
import keycloak, { getAuthenticatedUser, logout } from './services/keycloak';

import { AccessProvider, AccessGate, useAccess } from './components/access/AccessContext';

import NotificationBell from './components/NotificationBell';
import Sidebar from './components/shell/Sidebar';
import UserMenu from './components/shell/UserMenu';
import { getRouteTitle } from './components/shell/navigation';
import { MOBILE_QUERY, PageSkeleton, TABLET_QUERY, ToastProvider, useMediaQuery } from './components/ui';

import './App.css';

const RequestDetailPage = lazy(() => import('./views/flujos/RequestDetailPage'));
const DocumentSearchPage = lazy(() => import('./views/documentos/DocumentSearchPage'));
const MyRequestsPage = lazy(() => import('./views/flujos/MyRequestsPage'));
const ChangePasswordPage = lazy(() => import('./views/acceso/ChangePasswordPage'));

const SIDEBAR_PREFERENCE_KEY = 'masterbase.sidebar.collapsed';

function readCollapsedPreference() {
  try {
    return window.localStorage.getItem(SIDEBAR_PREFERENCE_KEY) === 'true';
  } catch {
    return false;
  }
}

function writeCollapsedPreference(value) {
  try {
    window.localStorage.setItem(SIDEBAR_PREFERENCE_KEY, String(value));
  } catch {
    // Sin almacenamiento disponible la preferencia dura solo esta sesión.
  }
}

function Breadcrumb() {
  const { pathname } = useLocation();
  const [section, title] = getRouteTitle(pathname);
  return (
    <nav className="topbar-breadcrumb" aria-label="Ubicación actual">
      <span className="topbar-breadcrumb-section">{section}</span>
      <ChevronRight size={15} aria-hidden="true" />
      <span className="topbar-breadcrumb-page" aria-current="page">{title}</span>
    </nav>
  );
}

function AppShell() {
  const { pathname } = useLocation();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(readCollapsedPreference);
  const isMobile = useMediaQuery(MOBILE_QUERY);
  const isTablet = useMediaQuery(TABLET_QUERY);
  const menuButtonRef = useRef(null);
  const closeButtonRef = useRef(null);
  const sidebarRef = useRef(null);

  // Escritorio: sidebar completa o riel (preferencia del usuario). Tablet: riel que se expande sobre el contenido.
  // Móvil: panel lateral modal.
  const isOverlay = (isMobile || isTablet) && isNavOpen;
  const isRail = !isMobile && (isTablet ? !isNavOpen : isCollapsed);

  useEffect(() => {
    setIsNavOpen(false);
  }, [isMobile, isTablet]);

  useEffect(() => {
    setIsNavOpen(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    if (!isOverlay) return undefined;
    closeButtonRef.current?.focus();
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        setIsNavOpen(false);
        menuButtonRef.current?.focus();
      }
      if (event.key === 'Tab') {
        const focusable = sidebarRef.current?.querySelectorAll('button:not(:disabled), a[href]');
        if (!focusable?.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOverlay]);

  const user = getAuthenticatedUser();
  const { can, roleLabel, context } = useAccess();

  const closeMenu = () => {
    if (!isNavOpen) return;
    setIsNavOpen(false);
    menuButtonRef.current?.focus();
  };

  const toggleNavigation = () => {
    if (isMobile || isTablet) {
      setIsNavOpen((value) => !value);
      return;
    }
    setIsCollapsed((value) => {
      writeCollapsedPreference(!value);
      return !value;
    });
  };

  const handleLogout = async () => {
    if (isLoggingOut) {
      return;
    }

    setIsLoggingOut(true);
    try {
      await logout();
    } catch (error) {
      console.error('No fue posible cerrar la sesión', error);
      setIsLoggingOut(false);
    }
  };

  const isDesktop = !isMobile && !isTablet;
  const toggleLabel = isDesktop
    ? (isCollapsed ? 'Expandir menú lateral' : 'Contraer menú lateral')
    : (isNavOpen ? 'Cerrar menú de navegación' : 'Abrir menú de navegación');
  const ToggleIcon = isDesktop ? (isCollapsed ? PanelLeftOpen : PanelLeftClose) : Menu;
  const shellClassName = ['app-container', isRail && 'is-rail', isOverlay && 'is-nav-open'].filter(Boolean).join(' ');

  return (
    <div className={shellClassName}>
      {isOverlay && <button className="sidebar-scrim" type="button" onClick={closeMenu} aria-label="Cerrar menú de navegación" tabIndex={-1} />}
      {isTablet && isOverlay && <div className="sidebar-spacer" aria-hidden="true" />}
      <Sidebar
        ref={sidebarRef}
        can={can}
        rail={isRail}
        overlay={isOverlay}
        open={isOverlay}
        user={user}
        roleLabel={roleLabel}
        onNavigate={closeMenu}
        onClose={closeMenu}
        closeButtonRef={closeButtonRef}
        onLogout={handleLogout}
        loggingOut={isLoggingOut}
      />

      <main className="main-content">
        <header className="topbar">
          <button
            ref={menuButtonRef}
            className="nav-toggle-btn"
            type="button"
            onClick={toggleNavigation}
            aria-label={toggleLabel}
            title={toggleLabel}
            aria-controls="main-sidebar"
            aria-expanded={isDesktop ? !isCollapsed : isNavOpen}
          >
            <ToggleIcon size={20} aria-hidden="true" />
          </button>
          <Breadcrumb />
          <div className="user-area">
            <NotificationBell />
            {(isRail || isMobile) && <UserMenu user={user} roleLabel={roleLabel} onLogout={handleLogout} loggingOut={isLoggingOut} />}
          </div>
        </header>

        <div className="content-body">
          <Routes>
            {/* Acceso */}
            <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="/recuperar-password" element={<RecuperarPasswordView />} />
            <Route path="/cambiar-password" element={<Navigate to="/cambiar-contrasena" replace />} />
            <Route path="/cambiar-contrasena" element={<Suspense fallback={<PageSkeleton variant="form" />}><ChangePasswordPage key={context.usuarioId} /></Suspense>} />

            {/* Inicio */}
            <Route path="/dashboard" element={<DashboardView />} />

            {/* Configuración */}
            <Route path="/configurar-flujos" element={<AccessGate permission="FLUJO_GESTIONAR"><ConfigurarFlujosView /></AccessGate>} />
            <Route
              path="/configurar-org-usuarios"
              element={<AccessGate permission="USUARIO_GESTIONAR"><ConfigurarOrgUsuariosView /></AccessGate>}
            />
            <Route path="/configurar-planillas" element={<AccessGate permission="FLUJO_GESTIONAR"><ConfigurarPlanillasView /></AccessGate>} />
            <Route path="/configurar-areas" element={<AccessGate permission="AREA_GESTIONAR"><AreaManagementPage /></AccessGate>} />

            {/* Documentos */}
            <Route path="/nuevo-documento" element={<AccessGate permission="SOLICITUD_CREAR"><NuevoDocumentoView /></AccessGate>} />
            <Route path="/mis-documentos" element={<AccessGate permission="SOLICITUD_CONSULTAR"><MisDocumentosView /></AccessGate>} />
            <Route path="/consultar-documentos" element={<AccessGate permission="SOLICITUD_CONSULTAR"><Suspense fallback={<PageSkeleton variant="table" />}><DocumentSearchPage key={context.usuarioId} /></Suspense></AccessGate>} />
            <Route path="/completar-planilla" element={<AccessGate permission="SOLICITUD_CREAR"><CompletarPlanillaView /></AccessGate>} />

            {/* Flujos */}
            <Route path="/revisar-documento" element={<AccessGate permission="REVISION_CONSULTAR"><RevisarDocumentoView /></AccessGate>} />
            <Route path="/corregir-documento" element={<AccessGate permission="SOLICITUD_REENVIAR"><CorregirDocumentoView /></AccessGate>} />
            <Route path="/estado-solicitudes" element={<AccessGate permission="SOLICITUD_CONSULTAR"><Suspense fallback={<PageSkeleton variant="table" />}><MyRequestsPage key={context.usuarioId} /></Suspense></AccessGate>} />
            <Route path="/solicitudes/:id" element={<AccessGate permission="SOLICITUD_CONSULTAR"><Suspense fallback={<PageSkeleton variant="detail" />}><RequestDetailPage /></Suspense></AccessGate>} />

            <Route path="/logout" element={<Navigate to="/login" replace />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  if (!keycloak.authenticated) {
    return null;
  }

  return (
    <BrowserRouter>
      <ToastProvider>
        <AccessProvider><AppShell /></AccessProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
