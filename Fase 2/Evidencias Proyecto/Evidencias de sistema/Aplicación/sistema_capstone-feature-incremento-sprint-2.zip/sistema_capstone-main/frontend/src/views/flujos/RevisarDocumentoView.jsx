import DocumentDownloadButton from '../../components/documents/DocumentDownloadButton';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams, useLocation } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  FileCheck2,
  FileEdit,
  FileText,
  FileX2,
  FilterX,
  Info,
  ListChecks,
  LoaderCircle,
  RefreshCw,
  Search,
  SlidersHorizontal,
  UserRound,
  X
} from 'lucide-react';
import DateFilter from '../../components/ui/DateFilter';
import api from '../../services/api';
import { downloadError, getDocumentFile } from '../../services/documentDownloads';
import { hasObservedVersion, requiresWorkflowReload, stageLabel, workflowErrorMessage } from '../../services/workflowErrors';
import { useAccess } from '../../components/access/AccessContext';
import { allowsAction } from '../../services/rbac';
import RequestDetailLink from '../../components/requests/RequestDetailLink';
import SlaDeadline from '../../components/requests/SlaDeadline';
import { slaContinuityMessage } from '../../services/sla';
import { Button, DataTable, DateTimeStack, EmptyState, FeedbackMessage, FileTypeIcon, FormField, PageHeader, StatusBadge } from '../../components/ui';

const PAGE_SIZE = 10;
const INITIAL_FILTERS = { nombreArchivo: '', emisor: '', fechaDesde: '', fechaHasta: '', estado: 'PENDIENTE_REVISION' };
const EMPTY_RESULT = { contenido: [], pagina: 0, tamanio: PAGE_SIZE, totalElementos: 0, totalPaginas: 0, primera: true, ultima: true };
const STATUS_OPTIONS = [
  { value: 'PENDIENTE_REVISION', label: 'Pendiente de revisión' },
  { value: 'CORRECCION_REQUERIDA', label: 'Corrección requerida' },
  { value: 'APROBADO', label: 'Aprobado' },
  { value: 'RECHAZADO', label: 'Rechazado' }
];
function useDismissPopover(ref, open, onClose) {
  useEffect(() => {
    if (!open) return undefined;
    const handlePointerDown = (event) => {
      if (!ref.current?.contains(event.target)) onClose();
    };
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [open, onClose, ref]);
}

function StatusFilter({ value, onChange }) {
  const containerRef = useRef(null);
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  useDismissPopover(containerRef, open, close);
  const selected = STATUS_OPTIONS.find((option) => option.value === value) || STATUS_OPTIONS[0];

  return (
    <div className="review-filter-field">
      <span>Estado</span>
      <div className="review-picker" ref={containerRef}>
        <button className="review-filter-trigger" type="button" onClick={() => setOpen((current) => !current)} aria-haspopup="listbox" aria-expanded={open}>
          <span>{selected.label}</span>
          <ChevronDown className="review-filter-chevron" size={15} aria-hidden="true" />
        </button>
        {open && <div className="review-status-menu" role="listbox" aria-label="Estado de la solicitud">{STATUS_OPTIONS.map((option) => <button key={option.value} className={option.value === value ? 'is-selected' : ''} type="button" role="option" aria-selected={option.value === value} onClick={() => { onChange('estado', option.value); setOpen(false); }}><span>{option.label}</span>{option.value === value && <Check size={16} aria-hidden="true" />}</button>)}</div>}
      </div>
    </div>
  );
}

function getErrorMessage(error, fallback) {
  return error?.response?.data?.detail || error?.response?.data?.message || fallback;
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  return new Intl.DateTimeFormat('es-CL', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

function formatFileSize(bytes) {
  if (!bytes) return '';
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function canPreview(documento) {
  return ['pdf', 'txt', 'xml'].includes(documento?.nombreArchivo?.split('.').pop()?.toLowerCase());
}

export default function RevisarDocumentoView() {
  const { revision } = useAccess();
  const location = useLocation();
  const restored = useRef(location.state?.requestDetailReturn || {}).current;
  const initialFilters = useRef(Object.fromEntries(Object.entries(INITIAL_FILTERS).map(([key, value]) => [key, typeof restored.filters?.[key] === 'string' ? restored.filters[key] : value]))).current;
  const [searchParams] = useSearchParams();
  const queryId = searchParams.get('id');
  const [filters, setFilters] = useState(initialFilters);
  const [filtersOpen, setFiltersOpen] = useState(Boolean(restored.filtersOpen));
  const [debouncedFilters, setDebouncedFilters] = useState(initialFilters);
  const lastFilters = useRef(initialFilters);
  const [page, setPage] = useState(Number.isSafeInteger(restored.page) && restored.page >= 0 ? restored.page : 0);
  const [result, setResult] = useState(EMPTY_RESULT);
  const [loading, setLoading] = useState(true);
  const [inboxError, setInboxError] = useState('');
  const inboxRead = useRef(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState(null);
  const [selectedId, setSelectedId] = useState(typeof restored.selectedId === 'string' ? restored.selectedId : null);
  const [selectedSolicitud, setSelectedSolicitud] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailRead, setDetailRead] = useState(0);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [previewError, setPreviewError] = useState('');
  const previewOperation = useRef(null);
  const previewIdentity = [selectedId, revision, selectedSolicitud?.documentoVigente?.id].join(':');
  const latestPreviewIdentity = useRef(previewIdentity);
  latestPreviewIdentity.current = previewIdentity;
  const [activeModal, setActiveModal] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [modalError, setModalError] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const detailDialogRef = useRef(null);
  const lastFocusedElementRef = useRef(null);
  const activeModalRef = useRef(null);
  const actionDialogRef = useRef(null);
  const modalTriggerRef = useRef(null);
  const actionInFlightRef = useRef(false);
  const actionSnapshotRef = useRef(null);
  const [actionBlocked, setActionBlocked] = useState(false);
  const reviewTableRef = useRef(null);

  activeModalRef.current = activeModal;

  const fetchPendientes = useCallback(async () => {
    inboxRead.current?.abort();
    const controller = new AbortController();
    inboxRead.current = controller;
    setLoading(true);
    setInboxError('');
    setErrorMessage('');
    try {
      const response = await api.get('/api/solicitudes/pendientes-revision', {
        signal: controller.signal,
        params: {
          nombreArchivo: debouncedFilters.nombreArchivo || undefined,
          emisor: debouncedFilters.emisor || undefined,
          fechaDesde: debouncedFilters.fechaDesde ? `${debouncedFilters.fechaDesde}T00:00:00Z` : undefined,
          fechaHasta: debouncedFilters.fechaHasta ? `${debouncedFilters.fechaHasta}T23:59:59Z` : undefined,
          estado: debouncedFilters.estado || undefined,
          pagina: page,
          tamanio: PAGE_SIZE
        }
      });
      if (controller.signal.aborted) return;
      setResult(response.data);
      if (page > 0 && page >= response.data.totalPaginas) setPage(Math.max(0, response.data.totalPaginas - 1));
    } catch (error) {
      if (controller.signal.aborted) return;
      setResult(EMPTY_RESULT);
      setInboxError(getErrorMessage(error, 'No fue posible consultar los plazos y las solicitudes pendientes.'));
      setErrorMessage(getErrorMessage(error, 'No fue posible cargar las solicitudes pendientes.'));
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, [debouncedFilters, page]);

  useEffect(() => {
    const timeout = window.setTimeout(() => setDebouncedFilters(filters), 350);
    return () => window.clearTimeout(timeout);
  }, [filters]);

  useEffect(() => {
    if (lastFilters.current !== debouncedFilters) { lastFilters.current = debouncedFilters; setPage(0); }
  }, [debouncedFilters]);
  useEffect(() => { void fetchPendientes(); return () => inboxRead.current?.abort(); }, [fetchPendientes, revision]);
  useEffect(() => { if (queryId) setSelectedId(queryId); }, [queryId]);

  useEffect(() => {
    if (!selectedId || activeModalRef.current) return undefined;
    const controller = new AbortController();
    setSelectedSolicitud(null);
    setLoadingDetail(true);
    setPreviewError('');
    setPreviewUrl(null);
    api.get(`/api/solicitudes/${selectedId}`, { signal: controller.signal })
      .then((response) => { if (!controller.signal.aborted) setSelectedSolicitud(response.data); })
      .catch((error) => {
        if (!controller.signal.aborted && error.code !== 'ERR_CANCELED') {
          setErrorMessage(getErrorMessage(error, 'No fue posible cargar el detalle de la solicitud.'));
          setSelectedId(null);
        }
      })
      .finally(() => { if (!controller.signal.aborted) setLoadingDetail(false); });
    return () => controller.abort();
  }, [selectedId, revision, detailRead]);

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);
  useEffect(() => () => {
    previewOperation.current?.abort();
    previewOperation.current = null;
  }, [previewIdentity]);

  const updateFilter = (event) => setFilters((current) => ({ ...current, [event.target.name]: event.target.value }));
  const updateFilterValue = (name, value) => setFilters((current) => ({ ...current, [name]: value }));
  const openDetailModal = (solicitudId) => {
    lastFocusedElementRef.current = document.activeElement;
    setSelectedId(solicitudId);
  };
  const closeDetailModal = useCallback(() => {
    setSelectedId(null);
    setSelectedSolicitud(null);
    setPreviewError('');
    setPreviewUrl(null);
  }, []);

  useEffect(() => {
    if (!selectedId) return undefined;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const focusFrame = window.requestAnimationFrame(() => detailDialogRef.current?.focus());

    const handleKeyDown = (event) => {
      if (event.key === 'Escape' && !activeModalRef.current) {
        event.preventDefault();
        closeDetailModal();
        return;
      }

      if (event.key !== 'Tab' || activeModalRef.current || !detailDialogRef.current) return;
      const focusableElements = detailDialogRef.current.querySelectorAll(
        'button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
      );
      if (focusableElements.length === 0) return;
      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];

      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = previousOverflow;
      if (lastFocusedElementRef.current?.isConnected) {
        lastFocusedElementRef.current.focus();
      } else {
        reviewTableRef.current?.focus();
      }
    };
  }, [closeDetailModal, selectedId]);


  const handlePreview = async () => {
    if (!allowsAction(selectedSolicitud, 'DESCARGAR')) return;
    if (!selectedSolicitud?.documentoVigente) return;
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
      return;
    }
    if (previewOperation.current) return;
    const controller = new AbortController();
    previewOperation.current = controller;
    const identity = previewIdentity;
    try {
      setPreviewError('');
      const file = selectedSolicitud.documentoVigente;
      const result = await getDocumentFile({ documentId: file.id, solicitudId: selectedSolicitud.id, fileName: file.nombreArchivo }, controller.signal);
      const signature = await result.blob.slice(0, 1024).text();
      if (controller.signal.aborted || latestPreviewIdentity.current !== identity) return;
      if (!signature.includes('%PDF-')) {
        setPreviewError('La vista previa no está disponible. Descarga el archivo para revisarlo.');
        return;
      }
      setPreviewUrl(URL.createObjectURL(new Blob([result.blob], { type: 'application/pdf' })));
    } catch (error) {
      if (!controller.signal.aborted && latestPreviewIdentity.current === identity) setPreviewError(downloadError(error));
    } finally {
      if (previewOperation.current === controller) previewOperation.current = null;
    }
  };

  const openModal = async (type) => {
    if (actionInFlightRef.current || !allowsAction(selectedSolicitud, { aprobar: 'APROBAR', rechazar: 'RECHAZAR', corregir: 'PEDIR_CORRECCION' }[type])) return;
    modalTriggerRef.current = document.activeElement;
    setSuccessMessage(null);
    actionInFlightRef.current = true; setActionLoading(true);
    try {
      const { data } = await api.get(`/api/solicitudes/${selectedSolicitud.id}`);
      setSelectedSolicitud(data);
      if (!allowsAction(data, { aprobar: 'APROBAR', rechazar: 'RECHAZAR', corregir: 'PEDIR_CORRECCION' }[type])) {
        setErrorMessage('La acción ya no está disponible. Se actualizó el estado de la solicitud.'); return;
      }
      actionSnapshotRef.current = data;
      setActionBlocked(!hasObservedVersion(data));
      setCommentText(''); setModalError(''); setActiveModal(type);
    } catch (error) { setErrorMessage(getErrorMessage(error, 'No fue posible cargar el estado vigente para realizar la acción.')); }
    finally { actionInFlightRef.current = false; setActionLoading(false); }
  };
  const reloadAction = async () => {
    if (actionInFlightRef.current || !actionSnapshotRef.current) return;
    actionInFlightRef.current = true; setActionLoading(true);
    try {
      const { data } = await api.get(`/api/solicitudes/${actionSnapshotRef.current.id}`);
      actionSnapshotRef.current = data;
      setSelectedSolicitud(data);
      setActionBlocked(!hasObservedVersion(data));
      setModalError('Estado actualizado. Se conserva el comentario; revise la etapa y las acciones disponibles antes de confirmar.');
    } catch (error) {
      setActionBlocked(true);
      setModalError(getErrorMessage(error, 'No fue posible actualizar la solicitud.'));
    } finally { actionInFlightRef.current = false; setActionLoading(false); }
  };
  const resetActionModal = useCallback(() => {
    setActiveModal(null);
    setCommentText('');
    setModalError('');
  }, []);
  const closeModal = useCallback(() => {
    if (!actionInFlightRef.current) resetActionModal();
  }, [resetActionModal]);

  useEffect(() => {
    if (!activeModal) return undefined;
    const focusFrame = window.requestAnimationFrame(() => {
      const target = activeModal === 'aprobar'
        ? actionDialogRef.current?.querySelector('.review-action-cancel')
        : actionDialogRef.current?.querySelector('textarea');
      (target || actionDialogRef.current)?.focus();
    });
    const handleActionKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeModal();
        return;
      }
      if (event.key !== 'Tab' || !actionDialogRef.current) return;
      const focusable = actionDialogRef.current.querySelectorAll('button:not(:disabled), textarea:not(:disabled)');
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', handleActionKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.removeEventListener('keydown', handleActionKeyDown);
      modalTriggerRef.current?.focus?.();
    };
  }, [activeModal, closeModal]);

  const handleExecuteAction = async () => {
    if (!selectedSolicitud || !activeModal || actionInFlightRef.current || actionBlocked) return;
    const snapshot = actionSnapshotRef.current;
    if (!hasObservedVersion(snapshot)) { setActionBlocked(true); setModalError('Actualice el estado de la solicitud antes de confirmar.'); return; }
    if (!allowsAction(selectedSolicitud, { aprobar: 'APROBAR', rechazar: 'RECHAZAR', corregir: 'PEDIR_CORRECCION' }[activeModal])) { setModalError('La acción ya no está disponible para esta solicitud. Actualice el detalle.'); return; }
    if ((activeModal === 'rechazar' || activeModal === 'corregir') && !commentText.trim()) {
      setModalError(activeModal === 'rechazar' ? 'Es obligatorio indicar el motivo del rechazo.' : 'Es obligatorio indicar las observaciones para que el emisor pueda corregir.');
      return;
    }

    const actionConfig = {
      aprobar: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/aprobar`, payload: {}, title: 'Documento aprobado', detail: 'La solicitud completó todas sus etapas y quedó aprobada. La decisión quedó registrada en el historial.' },
      rechazar: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/rechazar`, payload: { motivo: commentText.trim(), notificarEmail: true }, status: 'RECHAZADO', title: 'Documento rechazado', detail: 'La solicitud fue rechazada exitosamente. La decisión y su motivo quedaron registrados.' },
      corregir: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/pedir-correccion`, payload: { observacion: commentText.trim(), notificarEmail: false }, status: 'CORRECCION_REQUERIDA', title: 'Corrección solicitada', detail: 'El emisor podrá consultar tus observaciones y reenviar el documento.' }
    }[activeModal];

    actionInFlightRef.current = true;
    setActionLoading(true);
    setModalError('');
    try {
      const { data } = await api.post(actionConfig.endpoint, { ...actionConfig.payload, version: snapshot.version });
      setSuccessMessage(activeModal === 'aprobar' && data.estado === 'PENDIENTE_REVISION'
        ? { title: 'Etapa aprobada', detail: `La solicitud continúa pendiente de revisión en ${stageLabel(data.etapaActual)}.` }
        : { title: actionConfig.title, detail: actionConfig.detail });
      resetActionModal();
      closeDetailModal();
      void fetchPendientes();
    } catch (error) {
      setModalError(workflowErrorMessage(error, 'Ocurrió un error al procesar la acción.'));
      setActionBlocked(requiresWorkflowReload(error));
    } finally {
      actionInFlightRef.current = false;
      setActionLoading(false);
    }
  };

  const activeFilterCount = Object.entries(filters).filter(([key, value]) => key === 'estado' ? value !== INITIAL_FILTERS.estado : Boolean(value)).length;
  const hasActiveFilters = activeFilterCount > 0;

  return (
    <section className="review-inbox-page" aria-labelledby="revisar-title">
      <PageHeader
        eyebrow="Flujos de aprobación"
        title="Revisar documentos"
        titleId="revisar-title"
        description="Filtra la bandeja, revisa el contenido de cada solicitud y registra tu decisión."
        icon={ListChecks}
        actions={<><div className="review-count" aria-live="polite"><FileCheck2 size={18} aria-hidden="true" /><span><strong>{result.totalElementos}</strong> {result.totalElementos === 1 ? 'resultado' : 'resultados'}</span></div><Button variant="secondary" disabled={loading} onClick={fetchPendientes}><RefreshCw size={16} aria-hidden="true" />Actualizar</Button></>}
      />

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}
      {successMessage && <div className="review-feedback-toast page-message form-message-success" role="status" aria-live="polite"><span className="review-feedback-icon" aria-hidden="true"><CheckCircle2 size={21} /></span><div><strong>{successMessage.title}</strong><p>{successMessage.detail}</p></div><button type="button" onClick={() => setSuccessMessage(null)} aria-label="Cerrar notificación"><X size={17} aria-hidden="true" /></button></div>}

      <button className="review-filter-toggle" type="button" onClick={() => setFiltersOpen((open) => !open)} aria-expanded={filtersOpen} aria-controls="review-filters">
        <SlidersHorizontal size={17} aria-hidden="true" />
        <span>Filtros</span>
        {activeFilterCount > 0 && <span className="filter-chip-count" aria-label={`${activeFilterCount} activos`}>{activeFilterCount}</span>}
        <ChevronDown className="review-filter-chevron" size={16} aria-hidden="true" />
      </button>

      <section id="review-filters" className={`review-filter-card${filtersOpen ? ' is-open' : ''}`} aria-label="Filtros de solicitudes">
        <div className="review-filter-fields">
          <label className="review-filter-field"><span>Nombre del archivo</span><div className="review-filter-input"><Search size={17} aria-hidden="true" /><input name="nombreArchivo" value={filters.nombreArchivo} onChange={updateFilter} placeholder="Ej. contrato" /></div></label>
          <label className="review-filter-field"><span>Emisor</span><div className="review-filter-input"><UserRound size={17} aria-hidden="true" /><input name="emisor" value={filters.emisor} onChange={updateFilter} placeholder="Nombre o correo" /></div></label>
          <DateFilter label="Desde" name="fechaDesde" value={filters.fechaDesde} max={filters.fechaHasta} onChange={updateFilterValue} />
          <DateFilter label="Hasta" name="fechaHasta" value={filters.fechaHasta} min={filters.fechaDesde} onChange={updateFilterValue} />
          <StatusFilter value={filters.estado} onChange={updateFilterValue} />
        </div>
        <Button variant="secondary" className="review-clear-filters" onClick={() => setFilters(INITIAL_FILTERS)} disabled={!hasActiveFilters}><FilterX size={17} aria-hidden="true" />Limpiar filtros</Button>
      </section>

      <section ref={reviewTableRef} className="review-table-card" aria-label="Resultados de solicitudes pendientes" tabIndex="-1">
        <div className="review-table-heading"><div><h3>Bandeja de revisión</h3><p>{loading ? 'Actualizando resultados…' : `${result.totalElementos} solicitud${result.totalElementos === 1 ? '' : 'es'} encontrada${result.totalElementos === 1 ? '' : 's'}`}</p></div>{loading && <LoaderCircle className="button-spinner" size={20} aria-label="Cargando solicitudes" />}</div>
        {loading && result.contenido.length === 0 ? <EmptyState loading title="Consultando solicitudes y plazos…" /> : inboxError ? <EmptyState icon={AlertCircle} tone="error" title="Bandeja no disponible" action={<Button variant="secondary" onClick={fetchPendientes}>Volver a intentar</Button>}>No fue posible consultar las solicitudes y sus plazos. Actualice la bandeja.</EmptyState> : !loading && result.contenido.length === 0 ? (
          <EmptyState icon={CheckCircle2} tone="success" title="Bandeja al día" data-testid="empty-pendientes">No hay solicitudes para los filtros seleccionados.</EmptyState>
        ) : (
          <div className="table-scroll"><DataTable className="review-data-table table-stackable"><thead><tr><th>Documento</th><th>Emisor</th><th>Fecha de envío</th><th>Plazo SLA</th><th>Estado</th><th><span className="visually-hidden">Acciones</span></th></tr></thead><tbody>
            {result.contenido.map((solicitud) => <tr key={solicitud.id} className="clickable-row" onClick={() => openDetailModal(solicitud.id)} data-testid={`solicitud-row-${solicitud.id}`}>
              <td className="cell-primary" data-label="Documento"><div className="cell-with-icon"><FileTypeIcon fileName={solicitud.nombreArchivo} /><div className="cell-stack">{solicitud.correlativo && <span className="correlative-tag">{solicitud.correlativo}</span>}<strong>{solicitud.titulo}</strong><span>{solicitud.nombreArchivo || 'Sin archivo'}</span></div></div></td>
              <td className="cell-wide" data-label="Emisor"><div className="cell-stack cell-person"><strong>{solicitud.emisorNombre}</strong><span>{solicitud.emisorEmail}</span></div></td>
              <td data-label="Fecha de envío"><DateTimeStack value={solicitud.fechaCreacion} /></td>
              <td data-label="Plazo SLA">
                <SlaDeadline deadline={solicitud.deadline} status={solicitud.slaStatus} active={solicitud.estado === 'PENDIENTE_REVISION'} />
              </td>
              <td data-label="Estado"><StatusBadge status={solicitud.estado} /></td>
              <td className="table-actions-cell cell-actions cell-actions--corner"><button className="action-btn review-open-detail" type="button" onClick={(event) => { event.stopPropagation(); openDetailModal(solicitud.id); }} aria-label={`Abrir detalle de ${solicitud.titulo}`}><Eye size={17} aria-hidden="true" /></button></td>
            </tr>)}
          </tbody></DataTable></div>
        )}
        <nav className="review-pagination" aria-label="Paginación de solicitudes"><span>Página {result.totalPaginas === 0 ? 0 : result.pagina + 1} de {result.totalPaginas}</span><div><Button variant="secondary" onClick={() => setPage((current) => current - 1)} disabled={loading || result.primera}><ChevronLeft size={17} aria-hidden="true" />Anterior</Button><Button variant="secondary" onClick={() => setPage((current) => current + 1)} disabled={loading || result.ultima}>Siguiente<ChevronRight size={17} aria-hidden="true" /></Button></div></nav>
      </section>

      {selectedId && <div className="review-detail-backdrop" role="presentation" onMouseDown={closeDetailModal}><section ref={detailDialogRef} className="review-detail-modal" role="dialog" aria-modal="true" aria-labelledby="review-detail-title" tabIndex="-1" onMouseDown={(event) => event.stopPropagation()}>
        <header className="review-detail-modal-header"><div><p className="page-eyebrow">Detalle y revisión</p><h3 id="review-detail-title">{selectedSolicitud?.correlativo ? `${selectedSolicitud.correlativo} - ${selectedSolicitud.titulo}` : selectedSolicitud?.titulo || 'Cargando solicitud…'}</h3></div><button className="action-btn" type="button" onClick={closeDetailModal} aria-label="Cerrar detalle"><X size={18} aria-hidden="true" /></button></header>
        <div className="review-detail-modal-content detail-card-body">
          {loadingDetail || !selectedSolicitud ? <EmptyState loading title="Cargando detalle…" /> : <>
            <div className="row-actions"><RequestDetailLink id={selectedSolicitud.id} viewState={{ filters, filtersOpen, page, selectedId: selectedSolicitud.id }} /><Button variant="secondary" disabled={loadingDetail || actionLoading} onClick={() => setDetailRead((value) => value + 1)}><RefreshCw size={16} aria-hidden="true" />Actualizar plazo y detalle</Button></div>
            <div className="review-summary-card">
              <div><span>Emisor</span><strong>{selectedSolicitud.emisorNombre}</strong><small>{selectedSolicitud.emisorEmail}</small></div>
              <div><span>Fecha</span><strong>{formatDate(selectedSolicitud.createdAt)}</strong></div>
              <div>
                <span>Plazo SLA</span>
                <SlaDeadline deadline={selectedSolicitud.deadline} status={selectedSolicitud.slaStatus} active={selectedSolicitud.estado === 'PENDIENTE_REVISION'} testIdPrefix="detail-sla-badge" />
              </div>
              <div><span>Estado</span><StatusBadge status={selectedSolicitud.estado} /></div>
            </div>
            {selectedSolicitud.deadline && selectedSolicitud.estado !== 'PENDIENTE_REVISION' && <p className="text-muted">{slaContinuityMessage(selectedSolicitud.estado)}</p>}
            <p className="text-muted">El estado del plazo corresponde a la última consulta. Por vencer indica menos de 24 horas corridas.</p>
            <section className="review-detail-section"><h4>Etapa actual</h4><p>{stageLabel(selectedSolicitud.etapaActual)}</p></section><section className="review-detail-section"><h4>Título</h4><p data-testid="detail-title">{selectedSolicitud.titulo}</p><h4>Descripción</h4><p>{selectedSolicitud.descripcion || 'Sin descripción informada por el emisor.'}</p></section>
            <section className="review-detail-section"><h4>Documento adjunto vigente</h4>{selectedSolicitud.documentoVigente ? <><div className="review-attachment-card"><FileTypeIcon fileName={selectedSolicitud.documentoVigente.nombreArchivo} /><div><strong title={selectedSolicitud.documentoVigente.nombreArchivo}>{selectedSolicitud.documentoVigente.nombreArchivo}</strong><span>{formatFileSize(selectedSolicitud.documentoVigente.sizeBytes)} · Versión {selectedSolicitud.documentoVigente.version}</span></div></div><div className="review-attachment-actions" hidden={!allowsAction(selectedSolicitud, 'DESCARGAR')}><DocumentDownloadButton documentId={selectedSolicitud.documentoVigente.id} solicitudId={selectedSolicitud.id}
fileName={selectedSolicitud.documentoVigente.nombreArchivo} allowed={allowsAction(selectedSolicitud, 'DESCARGAR')}
contextKey={selectedId} data-testid="btn-descargar" />{canPreview(selectedSolicitud.documentoVigente) && <Button variant="secondary" onClick={handlePreview} aria-pressed={Boolean(previewUrl)}><Eye size={16} aria-hidden="true" />{previewUrl ? 'Ocultar vista previa' : 'Previsualizar'}</Button>}</div>{previewError && <FeedbackMessage tone="error">{previewError}</FeedbackMessage>}{previewUrl && <div className="review-preview-shell"><iframe className="review-file-preview" title={`Previsualización de ${selectedSolicitud.documentoVigente.nombreArchivo}`} src={`${previewUrl}#view=FitH&zoom=page-width`} /></div>}</> : <p>La solicitud no tiene un archivo adjunto.</p>}</section>
          </>}
        </div>
        {selectedSolicitud?.estado === 'PENDIENTE_REVISION' && ['APROBAR', 'RECHAZAR', 'PEDIR_CORRECCION'].some((action) => allowsAction(selectedSolicitud, action)) && <footer className="review-detail-modal-footer"><span>Acciones de revisión</span><div className="detail-actions-bar">{allowsAction(selectedSolicitud, 'APROBAR') && <Button variant="success" onClick={() => openModal('aprobar')} data-testid="btn-aprobar"><FileCheck2 size={18} aria-hidden="true" />Aprobar</Button>}{allowsAction(selectedSolicitud, 'PEDIR_CORRECCION') && <Button variant="warning" onClick={() => openModal('corregir')} data-testid="btn-pedir-correccion"><FileEdit size={18} aria-hidden="true" />Pedir corrección</Button>}{allowsAction(selectedSolicitud, 'RECHAZAR') && <Button variant="danger" onClick={() => openModal('rechazar')} data-testid="btn-rechazar"><FileX2 size={18} aria-hidden="true" />Rechazar</Button>}</div></footer>}
      </section></div>}

      {activeModal && <div className="modal-backdrop" role="presentation"><section ref={actionDialogRef} className="management-card user-form-modal review-action-modal" role="dialog" aria-modal="true" aria-labelledby="review-action-title" aria-describedby="review-action-description" tabIndex="-1">
        <header className="review-action-header">
          <span className={`review-action-icon review-action-icon-${activeModal}`} aria-hidden="true">{activeModal === 'aprobar' ? <FileCheck2 size={24} /> : activeModal === 'corregir' ? <FileEdit size={24} /> : <FileX2 size={24} />}</span>
          <div><span className="review-action-eyebrow">Decisión sobre la solicitud</span><h3 id="review-action-title">{activeModal === 'aprobar' ? 'Aprobar etapa actual' : activeModal === 'corregir' ? 'Solicitar correcciones' : 'Rechazar documento'}</h3><p id="review-action-description">{activeModal === 'aprobar' ? 'La solicitud avanzará al siguiente paso o finalizará si esta es la última etapa.' : 'Tu mensaje quedará registrado y será visible para el emisor.'}</p></div>
          <button className="action-btn review-action-close" type="button" onClick={closeModal} disabled={actionLoading} aria-label="Cerrar confirmación"><X size={18} aria-hidden="true" /></button>
        </header>
        <div className="review-action-body">
          {modalError && <div className="form-message form-message-error review-action-error" role="alert"><AlertCircle size={18} aria-hidden="true" /><span>{modalError}</span></div>}
          {actionBlocked && <FeedbackMessage>Actualice el estado para comprobar el resultado antes de volver a confirmar.<Button variant="secondary" onClick={reloadAction} disabled={actionLoading}>Actualizar estado conservando comentario</Button></FeedbackMessage>}
          <p>{stageLabel(actionSnapshotRef.current?.etapaActual)}</p>
          <div className="review-action-document"><span aria-hidden="true"><FileText size={19} /></span><div><small>Solicitud seleccionada</small><strong>{selectedSolicitud?.titulo}</strong><span>{selectedSolicitud?.emisorNombre || selectedSolicitud?.emisorEmail}</span></div></div>
          {activeModal === 'aprobar' ? <>
            <div className="review-action-transition"><StatusBadge status="PENDIENTE_REVISION" /><ArrowRight size={18} aria-hidden="true" /><span>Siguiente etapa o aprobación final</span></div>
            <p className="review-action-note"><Info size={17} aria-hidden="true" />La decisión quedará en el historial. El flujo continuará con el siguiente responsable; la última aprobación cerrará la solicitud.</p>
          </> : <FormField label={activeModal === 'corregir' ? 'Observaciones de mejora *' : 'Motivo del rechazo *'} htmlFor="modal-comment" className="review-action-comment"><textarea id="modal-comment" data-testid="modal-comment-input" value={commentText} onChange={(event) => setCommentText(event.target.value)} disabled={actionLoading} maxLength="2000" rows="4" placeholder={activeModal === 'corregir' ? 'Indica qué debe corregir el emisor…' : 'Explica por qué se rechaza el documento…'} /></FormField>}
        </div>
        <footer className="review-action-footer"><Button variant="secondary" className="review-action-cancel" onClick={closeModal} disabled={actionLoading}>Cancelar</Button><Button variant={activeModal === 'aprobar' ? 'success' : activeModal === 'corregir' ? 'warning' : 'danger'} onClick={handleExecuteAction} disabled={actionLoading || actionBlocked || !allowsAction(selectedSolicitud, { aprobar: 'APROBAR', rechazar: 'RECHAZAR', corregir: 'PEDIR_CORRECCION' }[activeModal])} data-testid="modal-confirm-btn">{actionLoading ? <LoaderCircle className="button-spinner" size={18} aria-hidden="true" /> : activeModal === 'aprobar' ? <FileCheck2 size={18} aria-hidden="true" /> : null}{activeModal === 'aprobar' ? 'Confirmar aprobación' : activeModal === 'corregir' ? 'Enviar observaciones' : 'Confirmar rechazo'}</Button></footer>
      </section></div>}
    </section>
  );
}
