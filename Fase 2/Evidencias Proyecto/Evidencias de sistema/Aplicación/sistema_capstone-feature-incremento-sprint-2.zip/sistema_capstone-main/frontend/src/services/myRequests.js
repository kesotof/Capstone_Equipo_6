import api from './api';

export const REQUEST_PAGE_SIZE = 10;
export const REQUEST_STATUSES = ['PENDIENTE_REVISION', 'CORRECCION_REQUERIDA', 'APROBADO', 'RECHAZADO'];
export const EMPTY_REQUEST_FILTERS = { query: '', status: '', areaId: '' };
export const isRequestId = (value) => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
const MAX_PAGE = Math.floor(2147483647 / REQUEST_PAGE_SIZE);

export function requestFilters(values, tray = 'propias') {
  return {
    query: typeof values?.query === 'string' ? values.query.trim() : '',
    status: typeof values?.status === 'string' ? values.status.trim().toUpperCase() : '',
    areaId: tray === 'autorizadas' && typeof values?.areaId === 'string' ? values.areaId.trim() : ''
  };
}

export function requestFilterErrors(filters) {
  const errors = {};
  if (filters.query.length > 200 || /[\u0000-\u001f\u007f-\u009f]/.test(filters.query)) errors.query = 'Usa hasta 200 caracteres y evita caracteres de control.';
  if (filters.status && !REQUEST_STATUSES.includes(filters.status)) errors.status = 'Selecciona un estado válido.';
  if (filters.areaId && (!/^[0-9]{1,19}$/.test(filters.areaId) || BigInt(filters.areaId) < 1n || BigInt(filters.areaId) > 9223372036854775807n)) {
    errors.areaId = 'Selecciona un área válida.';
  }
  return errors;
}

export function restoreMyRequests(snapshot, userId) {
  const empty = { tray: 'propias', filters: { ...EMPTY_REQUEST_FILTERS }, draft: '', page: 0 };
  if (snapshot?.userId !== userId) return empty;
  const tray = snapshot.tray === 'autorizadas' ? 'autorizadas' : 'propias';
  const filters = requestFilters(snapshot.filters, tray);
  if (Object.keys(requestFilterErrors(filters)).length) return empty;
  return {
    tray, filters,
    draft: typeof snapshot.draft === 'string' && snapshot.draft.length <= 200 ? snapshot.draft : filters.query,
    page: Number.isSafeInteger(snapshot.page) && snapshot.page >= 0 && snapshot.page <= MAX_PAGE ? snapshot.page : 0
  };
}

export function myRequestsParams(tray, filters, page) {
  return { ...Object.fromEntries(Object.entries(requestFilters(filters, tray)).filter(([, value]) => value !== '')), page, size: REQUEST_PAGE_SIZE };
}

const validArea = (area) => area === null || (Number.isSafeInteger(area?.id) && area.id > 0
  && (area.nombre === null || typeof area.nombre === 'string') && (area.activa === null || typeof area.activa === 'boolean'));
const validInstant = (value) => typeof value === 'string' && /(Z|[+-]\d{2}:\d{2})$/.test(value) && !Number.isNaN(Date.parse(value));
const validStage = (stage) => stage === null || (Number.isSafeInteger(stage?.id) && stage.id > 0
  && Number.isSafeInteger(stage.orden) && stage.orden > 0 && typeof stage.nombre === 'string');
function invalidResponse() {
  const error = new Error('La respuesta de seguimiento no está disponible.');
  error.kind = 'contract';
  return error;
}

export async function getMyRequests(tray, params, signal) {
  const url = tray === 'autorizadas' ? '/api/requests/accessible' : '/api/requests/my-requests';
  const { data } = await api.get(url, { params, signal, timeout: 20000 });
  if (!Array.isArray(data?.contenido) || data.pagina !== params.page || data.tamanio !== REQUEST_PAGE_SIZE
      || !Number.isSafeInteger(data.totalElementos) || data.totalElementos < 0
      || data.totalPaginas !== Math.ceil(data.totalElementos / REQUEST_PAGE_SIZE)
      || data.primera !== (params.page === 0) || data.ultima !== (params.page + 1 >= data.totalPaginas)
      || data.orden !== 'updatedAt,desc' || !validInstant(data.consultadoEn)
      || data.contenido.length !== Math.max(0, Math.min(REQUEST_PAGE_SIZE, data.totalElementos - params.page * REQUEST_PAGE_SIZE))
      || data.contenido.some((request) => !isRequestId(request?.id) || typeof request.titulo !== 'string'
        || (request.correlativo !== null && typeof request.correlativo !== 'string')
        || typeof request.estado !== 'string' || !request.estado || typeof request.emisorNombre !== 'string'
        || typeof request.propia !== 'boolean' || (tray !== 'autorizadas' && !request.propia)
        || !Number.isSafeInteger(request.version) || request.version < 0
        || !validInstant(request.createdAt) || !validInstant(request.updatedAt) || !validStage(request.etapaActual)
        || !validArea(request.areaOrigen) || !validArea(request.areaFlujo)
        || !Array.isArray(request.accionesPermitidas) || request.accionesPermitidas.length > 1
        || request.accionesPermitidas.some((action) => action !== 'REENVIAR' || request.estado !== 'CORRECCION_REQUERIDA')
        || request.detalleUrl !== `/api/requests/${request.id}/detail`)
      || new Set(data.contenido.map((request) => request.id.toLowerCase())).size !== data.contenido.length) {
    throw invalidResponse();
  }
  return data;
}

export async function myRequestsAreas(signal) {
  const { data } = await api.get('/api/rbac/catalogos/areas', { signal, timeout: 20000 });
  if (!Array.isArray(data) || data.some((area) => !Number.isSafeInteger(area?.id) || area.id < 1 || typeof area.nombre !== 'string')
      || new Set(data.map((area) => area.id)).size !== data.length) throw invalidResponse();
  return data;
}

export function myRequestsError(error, catalog = false) {
  const status = error.response?.status;
  if (status === 401) return { message: 'La sesión ya no está disponible. Vuelve a iniciar sesión.', restricted: true, retryable: false };
  if (status === 403) return { message: 'La consulta no está disponible con los permisos actuales. Solicita la revisión de tu acceso.', restricted: true, retryable: false };
  if (status === 400) return { message: 'Revisa los filtros seleccionados antes de volver a consultar.', restricted: false, retryable: false };
  return {
    message: catalog ? 'No fue posible cargar las áreas disponibles. La consulta conserva el filtro aplicado.' : 'No fue posible actualizar las solicitudes. Intenta nuevamente.',
    restricted: false, retryable: error.kind !== 'contract'
  };
}
