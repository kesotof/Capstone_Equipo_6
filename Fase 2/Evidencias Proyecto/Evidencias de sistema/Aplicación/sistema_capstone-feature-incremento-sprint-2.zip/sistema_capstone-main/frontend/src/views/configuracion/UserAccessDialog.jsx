import React, { useRef, useState } from 'react';
import { X } from 'lucide-react';
import api from '../../services/api';
import { isVersionConflict, problemMessage } from '../../services/rbac';
import AreaDialog from '../../components/areas/AreaDialog';
import { Button, DropdownSelect, FeedbackMessage, FormField } from '../../components/ui';

export default function UserAccessDialog({ user, mode, users, roles, onClose, onSaved }) {
  const [current, setCurrent] = useState(user);
  const [selected, setSelected] = useState((user.rolesFuncionales || []).filter((role) => role.origen === 'EXPLICITO').map((role) => role.id));
  const [manager, setManager] = useState(user.jefaturaDirectaId || '');
  const [busy, setBusy] = useState(false);
  const guard = useRef(false);
  const [error, setError] = useState('');
  const [stale, setStale] = useState(false);
  const save = async (event) => {
    event.preventDefault();
    if (guard.current || stale) return;
    guard.current = true; setBusy(true); setError('');
    try {
      const payload = mode === 'roles' ? { roleIds: selected, versionAcceso: current.versionAcceso }
        : { jefaturaDirectaId: manager || null, versionAcceso: current.versionAcceso };
      const { data } = await api.put(`/api/users/${user.id}/${mode === 'roles' ? 'roles' : 'jefatura'}`, payload);
      await onSaved(data);
      onClose();
    } catch (err) { setError(problemMessage(err)); setStale(isVersionConflict(err)); }
    finally { guard.current = false; setBusy(false); }
  };
  const reload = async () => {
    if (guard.current) return;
    guard.current = true; setBusy(true);
    try {
      const { data } = await api.get('/api/users');
      const updated = data.find((item) => item.id === user.id);
      if (!updated) { setError('La cuenta ya no está disponible. Cierre el diálogo y actualice el listado.'); return; }
      setCurrent(updated); setSelected((updated.rolesFuncionales || []).filter((role) => role.origen === 'EXPLICITO').map((role) => role.id));
      setManager(updated.jefaturaDirectaId || ''); setStale(false); setError('');
    } catch (err) { setError(problemMessage(err)); }
    finally { guard.current = false; setBusy(false); }
  };
  const derived = current.rolesFuncionales?.filter((role) => role.origen === 'AREA') || [];
  const missingRoles = current.rolesFuncionales?.filter((role) => role.origen === 'EXPLICITO' && !roles.some((item) => item.id === role.id)) || [];
  const managerOptions = [{ value: '', label: 'Sin jefatura asignada' }, ...users.filter((item) => item.enabled && item.id !== user.id).map((item) => ({ value: item.id, label: `${item.firstName} ${item.lastName} · ${item.areaNombre || 'Sin área asignada'}` }))];
  if (manager && !managerOptions.some((option) => option.value === manager)) managerOptions.push({ value: manager, label: `${current.jefaturaDirectaNombre || 'Jefatura actual'} (no disponible)`, disabled: true });
  return <AreaDialog titleId="user-access-title" busy={busy} onClose={() => { if (!guard.current) onClose(); }}>
    <div className="area-dialog-header"><div><h3 id="user-access-title">{mode === 'roles' ? 'Asignar roles' : 'Jefatura directa'}</h3><p>{current.firstName} {current.lastName} · {current.email}</p></div><Button variant="quiet" aria-label="Cerrar diálogo" onClick={onClose} disabled={busy}><X size={18} /></Button></div>
    <form className="area-form" onSubmit={save}><div className="area-dialog-body">
      {mode === 'roles' ? <><fieldset className="rbac-role-options" disabled={busy}><legend>Roles funcionales</legend>{roles.map((role) => <label key={role.id}><input type="checkbox" checked={selected.includes(role.id)} onChange={() => setSelected((ids) => ids.includes(role.id) ? ids.filter((id) => id !== role.id) : [...ids, role.id])} />{role.nombre}</label>)}</fieldset>
        {missingRoles.map((role) => <label key={role.id}><input type="checkbox" disabled={busy} checked={selected.includes(role.id)} onChange={() => setSelected((ids) => ids.filter((id) => id !== role.id))} />{role.nombre} (no disponible; desmarque para retirar)</label>)}
        {!roles.length && <FeedbackMessage>No hay roles activos disponibles. Cree o active un rol antes de asignarlo.</FeedbackMessage>}
        <p>Una cuenta sin roles mantiene acceso a su sesión y notificaciones, sin funciones documentales.</p>
        {!!derived.length && <FeedbackMessage>Administración derivada de las áreas: {derived.map((role) => role.nombre).join(', ')}. Se modifica desde Áreas corporativas.</FeedbackMessage>}
      </> : <FormField label="Jefatura directa" htmlFor="user-manager" optional hint="La jefatura debe ser una cuenta activa. El sistema impide las dependencias circulares."><DropdownSelect id="user-manager" value={manager} onChange={setManager} options={managerOptions} disabled={busy} /></FormField>}
      {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}
      {stale && <><p>La cuenta cambió durante la edición. Recargar reemplazará las selecciones del formulario.</p><Button variant="secondary" onClick={reload} loading={busy}>Recargar datos actuales</Button></>}
    </div><div className="area-dialog-footer"><Button variant="secondary" onClick={onClose} disabled={busy}>Cancelar</Button><Button type="submit" loading={busy} disabled={stale}>Guardar cambios</Button></div></form>
  </AreaDialog>;
}
