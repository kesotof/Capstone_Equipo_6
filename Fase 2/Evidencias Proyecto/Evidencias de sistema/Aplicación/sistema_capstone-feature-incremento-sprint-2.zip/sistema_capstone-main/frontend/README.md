# Frontend (SPA usando React)

Aplicación web Single Page Application (SPA) para el Sistema de Gestión Documental y Flujos de Aprobación.

## Vistas Implementadas (según arquitectura)
- **Acceso**:
  - `Login`: Redirección y autenticación con Keycloak.
  - `Recuperar Contraseña`: Flujo de recuperación de credenciales.
- **Configuración del Negocio**:
  - `Configurar Flujos`: Configuración de etapas de aprobación y reglas.
  - `Configurar Organización y Usuarios`: Estructura jerárquica y asignación de roles.
  - `Configurar Planillas`: Plantillas dinámicas de documentos.
- **Gestión Documentos**:
  - `Nuevo Documento`: Carga de archivos (.docx, .pdf) hacia bucket S3 (MinIO).
  - `Mis Documentos`: Visualización y descarga de documentos propios.
  - `Completar Planilla`: Diligenciamiento de formularios de plantillas.
- **Gestión Flujos**:
  - `Revisar Documento`: Aprobación, rechazo u observaciones.
  - `Corregir Documento`: Subsanación de observaciones y reenvío.
  - `Estado Solicitudes`: Trazabilidad y seguimiento del estado.

## Ejecución Local
```bash
npm install
npm run dev
```
La aplicación correrá en `http://localhost:3000`.
