# Estructura del Proyecto y Catálogo Arquitectónico

> **Documento de Contexto Rápido para Agentes y Desarrolladores**  
> Este documento centraliza la arquitectura física, el catálogo exhaustivo de archivos y los flujos de integración del **Sistema de Gestión Documental y Flujos de Aprobación (Capstone)**. Permite a cualquier agente autónomo situarse de inmediato en el repositorio sin necesidad de escanear o leer todos los archivos individualmente.

---

## 1. Visión General de la Arquitectura

El sistema está diseñado bajo una arquitectura de microservicios desacoplados orientados a eventos, complementados por un frontend SPA en React y servicios base contenerizados:

```mermaid
graph TD
    User["Usuario / Navegador"] -->|HTTP / SPA :3000| Front["Frontend (React + Vite)"]
    Front -->|OIDC Login / Token JWT| KC["Keycloak SSO (:8080)"]
    Front -->|REST API + Bearer JWT :8081| SisPrin["Sistema Principal (:8081)\nSpring Boot 3.2"]

    SisPrin -->|Validación JWT Certs| KC
    SisPrin -->|Persistencia Metadatos :5432| PG_Sis[("PostgreSQL\nsistema_db")]
    KC -->|Persistencia Realm :5432| PG_KC[("PostgreSQL\nkeycloak_db")]
    SisPrin -->|Almacenamiento S3 :9000| MinIO[("MinIO S3\nBucket 'documentos'")]
    SisPrin -->|Eventos Topic :5672| RMQ{{"RabbitMQ Broker\ncapstone.exchange"}}

    RMQ -->|notifications.email\nnotifications.email.queue| SvcNotif["Service Notificaciones (:8082)\nSpring Boot 3.2"]
    RMQ -->|ai.analysis\nai.queue| SvcIA["Service Consultas IA (:8083)\nSpring Boot 3.2"]

    SvcNotif -->|REST API HTTPS| Resend["Resend API\n(Despacho Correos)"]
    SvcIA -->|REST API HTTPS| OpenRouter["OpenRouter API\n(Análisis Documental)"]
    SvcIA -->|Descarga S3| MinIO
    SvcIA -->|ai.results\nai.results.queue| RMQ
```

---

## 2. Catálogo de Archivos y Responsabilidades

### 2.1 Raíz del Repositorio

| Archivo / Carpeta | Propósito / Responsabilidad |
| :--- | :--- |
| [`AGENTS.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/AGENTS.md) | **Mapa y guía maestra** para agentes de codificación. Define el flujo de inicio, reglas operativas y referencias a este catálogo. |
| [`PROJECT_STRUCTURE.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/PROJECT_STRUCTURE.md) | Este documento: inventario técnico completo, arquitectura detallada y guía de contexto rápido. |
| [`claude-progress.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/claude-progress.md) | Bitácora de trabajo continuo (Sprint 2 activo): registra el último estado verificado, decisiones técnicas y el siguiente paso inmediato. |
| [`docs/progress/sprint-1-archive.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/progress/sprint-1-archive.md) | Archivo histórico de progreso (Sprint 1): registro exhaustivo de hitos 1 al 38 (infraestructura, Keycloak y flujos base). |
| [`docker-compose.yml`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docker-compose.yml) | Definición orquestada de todos los servicios: PostgreSQL, Keycloak, RabbitMQ, MinIO, más las 4 aplicaciones bajo el profile `apps`. |
| [`.env`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.env) / [`.env.example`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.env.example) | Parámetros de entorno centralizados: credenciales de base de datos, puertos, claves de APIs (Gemini, MasterBase) y endpoints. |
| [`init.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/init.ps1) | Script de arranque y diagnóstico para Windows PowerShell. |
| [`init.sh`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/init.sh) | Script de arranque y diagnóstico para Linux / Bash / WSL. |
| [`tests/e2e/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/) | **Suite de Pruebas E2E y Regresión**: Casos de prueba Playwright en contenedor oficial (`mcr.microsoft.com/playwright`), con soporte headless y servidor UI web interactivo. |
| [`scripts/run-e2e-tests.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.ps1) / [`.sh`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.sh) | Scripts unificados para ejecutar la suite de Playwright en Docker con verificación previa de servicios (admite flags `-Clean`, `-UI`, `-Build`, `-Spec`). |
| [`scripts/clean-test-db.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/clean-test-db.ps1) / [`.sh`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/clean-test-db.sh) | **Reseteo Seguro del Entorno de Pruebas**: Limpia tablas de `sistema_db`, restablece usuarios base y roles en Keycloak/Postgres, vacía S3 MinIO y purga colas RabbitMQ. |
| [`.agents/skills/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.agents/skills/) | **Habilidades y Conocimiento para Agentes**: Skills de buenas prácticas de Spring Boot 3 y recopilación Local-First de documentación oficial de Spring. |
| [`docs/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/) | **Gobernanza, Backlog y Contratos**: Contratos REST ([`docs/API_CONTRACTS.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/API_CONTRACTS.md)), Swagger UI (`http://localhost:8081/swagger-ui.html`), matriz de permisos/roles de artefactos en Google Drive ([`GOBERNANZA_DOCUMENTAL.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/GOBERNANZA_DOCUMENTAL.md)) y réplicas locales del Sprint Backlog ([`docs/sprint-backlog/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/sprint-backlog/)). |
| [`docs/PRODUCT_BACKLOG.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/PRODUCT_BACKLOG.md) | **Product Backlog Oficial Completo**: Consolidación integral de las 36 historias de usuario del backlog oficial de Trello (Sprint 1, Sprint 2 y Backlog Futuro), IDs únicos `US-01` a `US-36`, criterios de aceptación formales y matriz de trazabilidad para exportación a PDF. |
| [`README.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/README.md) | Documentación de presentación para humanos y descripción del proyecto académico Capstone. |


---

### 2.2 Frontend SPA (`frontend/`)

- **Tecnologías**: React 18, Vite 5, React Router DOM 6, Axios, Keycloak-js.
- **Puerto expuesto en Docker**: `3000` (Nginx Alpine reverse proxy a `index.html`).

```
frontend/
├── Dockerfile                  # Construcción multi-stage (Node 20 build -> Nginx Alpine runtime)
├── package.json                # Dependencias (react, react-router-dom, axios, keycloak-js)
├── DESIGN_SYSTEM.md            # Guía visual empresarial: tokens, patrones UI, accesibilidad y responsive
├── vite.config.js              # Configuración de compilación Vite y servidor dev (puerto 3000)
├── index.html                  # Plantilla HTML base (título "MasterBase · Gestión documental", favicon autómata)
├── public/
│   ├── masterbase-wordmark.png # Logotipo del sidebar (copia del usado en el tema de Keycloak)
│   └── masterbase-automata.png # Favicon
└── src/
    ├── main.jsx                # Inicializa la sesión Keycloak y monta la aplicación React
    ├── App.jsx                 # Shell responsive (sidebar completa ≥1280, riel 768–1279, panel modal <768), topbar con conmutador de menú, ruta actual, notificaciones y menú de cuenta; rutas según permisos
    ├── App.css                 # Punto de entrada de estilos: importa en orden los módulos de styles/ y documenta los puntos de quiebre
    ├── styles/
    │   ├── tokens.css          # Variables de color, radios, sombras, capas (z-index), anchos del shell y tipografía
    │   ├── base.css            # Reset, documento como contenedor de scroll y bloqueo de scroll con diálogos abiertos
    │   ├── shell.css           # Sidebar (completa/riel/superpuesta), topbar y menú de cuenta
    │   ├── layout.css          # Contenedores de página, cabeceras y pantalla En construcción
    │   ├── components.css      # Botones, campos, mensajes, badges, tarjetas, tablas, filtros, estados vacíos/error, diálogos, pestañas y objetivos táctiles
    │   ├── skeleton.css        # Esqueletos de carga (filas, página y arranque de la aplicación)
    │   ├── toast.css           # Avisos no bloqueantes
    │   ├── notifications.css   # Centro de notificaciones
    │   ├── responsive.css      # Ajustes por punto de quiebre de las vistas existentes
    │   ├── tables-stackable.css # Tablas que se apilan como tarjetas mediante container queries
    │   └── views/              # dashboard, document-upload, master-detail, users, review
    ├── services/
    │   ├── keycloak.js         # Cliente OIDC: login-required, PKCE S256, logout, roles y conservación de enlaces directos al detalle
    │   ├── api.js              # Cliente Axios con interceptor que inyecta Bearer JWT automáticamente
    │   ├── workflowErrors.js   # Versiones observadas, errores de escritura, recarga explícita y etiquetas de etapas
    │   ├── requestDetails.js   # GET unificado, errores seguros, descarga autenticada del vigente y regreso interno validado
    │   ├── documentSearch.js   # GET búsqueda/catálogo, validación de contratos y filtros, página fija de 10, orden y restauración para la misma cuenta
    │   ├── myRequests.js       # GET propia/autorizada y catálogo RBAC de áreas; validación de página/resumen, filtros, UUID y restauración por cuenta
    │   ├── passwordChanges.js  # HU-S2-13: política efectiva, POST autenticado, reglas/fortaleza, errores seguros y eliminación de referencias al payload
    │   ├── dashboardSummary.js # HU-S2-14: GET agregado y bandejas, validación de totales/áreas/tendencia, selección y errores seguros
    │   ├── sla.js              # HU-S2-08: formatos Santiago, estados defensivos, continuidad, validaciones y cliente de matriz
    │   └── areas.js            # Cuatro endpoints de áreas, catálogo completo paginado y errores de negocio
    ├── hooks/
    │   ├── useSlaRules.js      # Matriz SLA cancelable, respuestas tardías, error/vacío y retiro por acceso
    │   ├── useRequestDetail.js # Lectura cancelable con secuencia y clave de ID/sesión/revisión RBAC; recarga completa
    │   ├── useDocumentSearch.js # Búsqueda/catálogo cancelables, secuencia, claves de consulta/usuario/revisión RBAC y recarga independiente
    │   ├── useMyRequests.js    # Lectura/áreas cancelables, revisión RBAC, refresco visible 30 s, reintentos 60/120 s, retiro por contexto/denegación y datos desactualizados
    │   └── useDashboardResource.js # Resumen/bandejas cancelables, acceso vigente, refresco visible 30 s, invalidación local y reintentos 60/120 s
    ├── components/
    │   ├── NotificationBell.jsx    # Centro de actividad: tipos, filtros, lectura y enlaces contextuales
    │   ├── ObservationTimeline.jsx # Observaciones con autor, fecha y estado; modos de corrección y consulta integral
    │   ├── areas/AreaDialog.jsx    # Modal reutilizado en áreas/flujos: foco, teclado, fondo inerte y bloqueo durante escrituras
    │   ├── flows/FlowDefinitionsPanel.jsx # Catálogo de 10 filas, borradores, diseñador REVISION, cambio de responsables en etapas usadas y conflictos
    │   ├── flows/ReviewerSelector.jsx # Selector compartido usuario/rol departamental, candidatos autorizados y advertencias rojo/ámbar
    │   ├── flows/SlaRuleDialog.jsx # Alta/edición/eliminación SLA: valores, validación, confirmación, foco y bloqueo de doble envío
    │   ├── requests/
    │   │   ├── SlaDeadline.jsx # Fecha Santiago y alertas comunes en bandeja/modal/detalle, nulos/desconocidos/histórico neutros
    │   │   ├── RequestDetailPanel.jsx # Resumen/Documentos/Observaciones/Historial; pestañas con teclado y permisos por sección
    │   │   ├── RequestDocuments.jsx # Vigente y versiones con descarga por ID; visor PDF autenticado y limpieza de URLs Blob
    │   │   ├── RequestHistory.jsx   # Eventos cronológicos, estados/etapas, actor, comentarios autorizados y SLA
    │   │   ├── RequestPagination.jsx # 10 entradas por página y acceso a los últimos eventos
    │   │   └── RequestDetailLink.jsx # Enlaces con regreso a filtros/página/selección de la vista de origen
    │   ├── shell/
    │   │   ├── navigation.js     # Única fuente de la navegación: secciones, permisos y títulos del breadcrumb
    │   │   ├── Sidebar.jsx       # Modos completa/riel/superpuesta, tooltip en riel y tarjeta de usuario con cierre de sesión
    │   │   ├── UserMenu.jsx      # Menú de cuenta de la topbar (riel y móvil): cambiar contraseña y cerrar sesión
    │   │   └── ComingSoon.jsx    # Pantalla común para secciones en construcción o gestionadas fuera de la aplicación
    │   └── ui/
    │       ├── index.jsx          # Biblioteca compartida: Button, PageHeader, FormField, DropdownSelect, StatusBadge, FeedbackMessage, EmptyState (carga con esqueleto), ErrorState, Skeleton/SkeletonRows/PageSkeleton/AppLoadingScreen, ToastProvider/useToast, MoreActions (hoja de acciones móvil), DataTable, Card, FileTypeIcon, DateTimeStack, DetailModal, useMediaQuery y puntos de quiebre
    │       ├── DropdownSelect.jsx # Selector con apariencia de Revisar documento, teclado y menú ubicado dentro del diálogo cuando corresponda
    │       ├── DropdownSelect.css # Posición flotante, desplazamiento, selección y estados deshabilitados del selector
    │       └── DateFilter.jsx     # Calendario extraído de Revisar documento y compartido con consulta; límites, Hoy/Borrar, etiquetas y foco; estilos globales existentes
    └── views/
        ├── acceso/
        │   ├── ChangePasswordPage.jsx/.css # HU-S2-13: /cambiar-contrasena, menú Cuenta, tres claves, Mostrar/Ocultar, reglas/medidor y toast de éxito
        │   └── RecuperarPasswordView.jsx   # Instrucciones para recuperación de clave en Keycloak
        ├── configuracion/
        │   ├── ConfigurarFlujosView.jsx       # Pestañas de Flujos y SLA; diseñador delegado a FlowDefinitionsPanel
        │   ├── ConfigurarFlujosView.css       # Estilos responsivos, badges y constructor secuencial de etapas
        │   ├── ConfigurarOrgUsuariosView.jsx  # Administración de departamentos y asignación de roles
        │   ├── AreaManagementPage.jsx         # /configurar-areas (ADMIN): tabla de 10 áreas por página, filtros, alta/edición y confirmación de estado
        │   ├── AreaManagementPage.css         # Estilos acotados a la vista y modales de áreas; usa tokens compartidos
        │   ├── ConfigurarPlanillasView.jsx    # Diseñador de planillas y formularios dinámicos
        │   ├── CambiarPasswordView.jsx        # /cambiar-password: autogestión de contraseñas con validación de requisitos
        │   └── CambiarPasswordView.css        # Estilos de formulario y checklist de requisitos de seguridad
        ├── dashboard/
        │   ├── DashboardView.jsx              # Resumen general autorizado y bandejas de acciones/solicitudes en trámite
        │   └── DashboardSummary.jsx/.css       # KPI por estado, distribución, emisiones de siete días, filtro global y desglose de diez áreas por página
        ├── documentos/
        │   ├── NuevoDocumentoView.jsx      # Registro de solicitudes: formulario + panel "¿Cómo funciona?", drag-and-drop, validación (10 MB), progreso Axios y confirmación
        │   ├── MisDocumentosView.jsx       # Documentos con búsqueda/filtros, seguimiento, descarga y enlace al detalle integral
        │   ├── DocumentSearchPage.jsx      # /consultar-documentos: SOLICITUD_CONSULTAR, búsqueda de servidor, filtros colapsables, orden, páginas de 10 y detalle con regreso al contexto
        │   ├── DocumentSearchPage.css      # Estilos acotados, controles compartidos, tabla apilable por ancho del contenedor y responsive
        │   └── CompletarPlanillaView.jsx   # Llenado de campos para planillas estructuradas
        └── flujos/
            ├── RevisarDocumentoView.jsx    # Bandeja de revisión: filtros, paginación, modal, previsualización y confirmaciones; ?id= y enlace al detalle integral
            ├── CorregirDocumentoView.jsx   # Lista/detalle (modal bajo 1120 px), edición/reenvío; ID autorizado incluso para ADMIN de otro emisor y regreso al seguimiento
            ├── EstadoSolicitudesView.jsx   # Export de compatibilidad hacia MyRequestsPage; una sola implementación del seguimiento
            ├── MyRequestsPage.jsx          # /estado-solicitudes: dos bandejas, correlativo destacado, filtros, estado/etapa/fechas, diez filas, actualización, detalle/corrección y retorno
            ├── MyRequestsPage.css          # Tokens compartidos, filtros/tablas responsive y filas apiladas por ancho del contenedor
            ├── RequestDetailPage.jsx       # /solicitudes/:id: cabecera corporativa, consulta unificada, actualización y regreso a bandeja
            └── RequestDetailPage.css       # Estilos acotados, pestañas, metadatos, adjuntos y visor; responsive 1120/768 px
```

---

### 2.3 Backend: Sistema Principal (`backend/sistema-principal/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring Data JPA, Spring Security OAuth2 Resource Server, Spring AMQP (RabbitMQ), MinIO SDK 8.5.10, PostgreSQL Driver.
- **Puerto expuesto**: `8081`.
- **Base de Datos**: PostgreSQL (`sistema_db`).

```
backend/sistema-principal/
├── Dockerfile                  # Multi-stage: Maven 3.9 + Eclipse Temurin 21 -> Temurin 21 JRE
├── pom.xml                     # Web, Security, AMQP, JPA, MinIO, Actuator, Validation y Keycloak Admin Client
└── src/
    └── main/
        ├── java/com/capstone/sistema/
        │   ├── SistemaPrincipalApplication.java  # Clase principal Spring Boot
        │   ├── auth/
        │   │   ├── SecurityConfig.java           # OAuth2 Resource Server, CORS y seguridad por métodos
        │   │   └── KeycloakJwtAuthenticationConverter.java
        │   │                                     # Valida cuenta local activa por JWT sub y usa ADMIN local; política funcional en RbacAccessService
        │   ├── audit/                            # Auditoría de acciones de seguridad (log_evento)
        │   │   ├── controller/AuditController.java # POST /api/audit/login, POST /api/audit/logout, GET /api/audit/events (ADMIN)
        │   │   ├── dto/AuditEventResponse.java     # Contrato inmutable de respuesta
        │   │   ├── model/                          # LogEvento y TipoEvento JPA
        │   │   ├── repository/                     # LogEventoRepository y TipoEventoRepository
        │   │   └── service/AuditService.java       # Persistencia de auditoría (login, logout, gestión de usuarios con actor, IP y sanitización CWE-532)
        │   ├── doc/
        │   │   ├── DocController.java            # POST /api/doc/upload exclusivo ADMIN; descargas centralizadas en DocumentDownloadController
        │   │   ├── controller/DocumentSearchController.java # GET /api/documents/search y /filters; JWT y no-store
        │   │   ├── dto/                          # DocumentSearchCriteria (interno), DocumentSearchItemResponse, DocumentSearchPageResponse y DocumentSearchFiltersResponse; records inmutables
        │   │   ├── exception/                    # DocumentSearchException y advice acotado: parámetros 400, varios vigentes 409 y fallo seguro 500
        │   │   ├── model/                        # Documento y FormatoDocumento JPA
        │   │   ├── repository/                   # DocumentoRepository y FormatoDocumentoRepository
        │   │   │                                # DocumentSearchSpecification: EXISTS correlacionado y filtros sobre Solicitud; DocumentSearchCatalogRepository: proyección DISTINCT autorizada
        │   │   ├── service/                      # DocumentSearchService: readOnly REPEATABLE_READ, RBAC común, páginas y cargas por lote; DocumentSearchQueryNormalizer: fechas America/Santiago, parámetros y orden permitidos
        │   │   └── MinioStorageService.java      # Servicio wrapper S3: subida, descarga y verificación de bucket
        │   ├── flow/
        │   │   ├── config/                         # DefaultFlowCatalogInitializer (base ID 1 por seed atómico, sin renumerar flujos), FlowSchemaInitializer, SlaSchemaInitializer (DDL SLA tras Hibernate), SlaClockConfiguration (UTC/microsegundos), FlujoCatalogIntegrityInitializer (reconciliación legacy única)
        │   │   │                                  # MyRequestsWebConfig: filtro no-store antes de seguridad para las dos bandejas de seguimiento
        │   │   ├── controller/
        │   │   │   ├── CatalogoController.java     # REST API: GET /api/catalogos/tipos-documento (catálogo tipos/SLA) y GET /api/catalogos/areas (catálogo general de áreas activas)
        │   │   │   ├── SolicitudController.java    # REST API /api/solicitudes: registro, listados, detalle, transiciones, búsqueda y métricas (/metricas, /metricas/por-area)
        │   │   │   ├── RequestDetailController.java # GET /api/requests/{id}/detail y alias /api/solicitudes/{id}/detalle; RequestDetailResponse y Cache-Control no-store
        │   │   │   ├── MyRequestsController.java    # GET /api/requests/my-requests (propia estricta) y /accessible (RBAC); parámetros explícitos en OpenAPI
        │   │   │   ├── DashboardSummaryController.java # GET /api/dashboard/summary; estado/área y tendencia de emisiones autorizados
        │   │   │   ├── FlujoConfigController.java  # REST API /api/flujos y alias /api/workflows: POST/GET, GET/PUT/DELETE /{id}, PUT /{id}/etapas, PATCH /{id}/status, PUT /{id}/steps/{stepId}/assignee y alias español, GET assignee-options; escrituras versionadas
        │   │   │   ├── SlaController.java          # REST API /api/sla (solo ADMIN): GET, GET /{id}, POST, PUT /{id}, DELETE /{id} (matriz de días hábiles por tipoDocumento)
        │   │   │   └── NotificacionController.java # REST API: GET /api/notificaciones, /no-leidas/count, PATCH /{id}/leer
        │   │   ├── config/DashboardSummaryWebConfig.java # no-store/nosniff antes de seguridad en /api/dashboard/summary
        │   │   ├── dto/                            # Records Java 21: AreaSimpleResponse; MetricasResponse con desglose por área; versiones en FlujoResponse/SolicitudResponse; AsignarResponsableRequest y ResponsableOptionsResponse; EstadoFlujoRequest; EtapaSolicitudResponse para etapa actual e historial; Create/UpdateSlaConfigRequest con SlaDaysDeserializer (entero JSON estricto)
        │   │   │                                  # RequestDetailResponse y auxiliares: FlujoDetalleResponse, AreaDetalleResponse, DocumentoDetalleResponse, SlaDetalleResponse, SeccionDetalleResponse, ObservacionDetalleResponse, EventoDetalleResponse
        │   │   │                                  # MyRequestsCriteria, MyRequestsSummaryResponse (14 campos) y MyRequestsPageResponse (9); listas inmutables, orden updatedAt DESC/id ASC
        │   │   │                                  # DashboardSummaryCriteria y DashboardSummaryResponse: Totals/AreaSummary/AreaOption/DailyCount, selección y fecha de lectura
        │   │   ├── exception/                      # SolicitudNotFoundException, DocumentoNoDisponibleException, InvalidTransitionException, UnauthorizedActionException, FlujoNotFoundException, FlujoConflictException, SlaNotFoundException, FlowExceptionHandler
        │   │   │                                  # RequestDetailDocumentConflictException (409) y RequestDetailExceptionHandler acotado al detalle, con errores de entrada y composición seguros
        │   │   │                                  # MyRequestsException y MyRequestsExceptionHandler: parámetros 400, acceso 403 y fallo de lectura seguro 500
        │   │   │                                  # DashboardSummaryException/Handler: entrada 400 y fallo 500 seguro; RBAC conserva el advice común
        │   │   ├── service/
        │   │   │   ├── SolicitudService.java       # Motor de flujos: ciclo documental, correlativos secuenciales (CONT-001, etc.), SLA, aislamiento departamental y auditoría de descargas
        │   │   │   ├── MyRequestsService.java      # Lector readOnly REPEATABLE_READ; identidad, visibilidad, página, áreas y REENVIAR por lotes, sin documentos/MinIO
        │   │   │   ├── MyRequestsQueryNormalizer.java # Query/status/page/size y areaId solo en autorizada; números, rangos, parámetros repetidos/desconocidos y caracteres de control
        │   │   │   ├── DashboardSummaryService.java # REPEATABLE_READ, intersección de lectura/métricas, área capturada única, catálogo global y calendario Santiago
        │   │   │   ├── DashboardSummaryQueryNormalizer.java # areaId positivo o sinArea=true; parámetros estrictos y excluyentes
        │   │   │   ├── RequestDetailService.java   # Lectura readOnly REPEATABLE_READ; ID+RBAC antes de colecciones, áreas capturadas, versiones, secciones autorizadas y comentarios restringidos
        │   │   │   ├── FlujoConfigService.java     # Configuración de flujos corporativos, reemplazo atómico de etapas y asignación flexible de revisores transversales
        │   │   │   ├── FlujoIntegrityService.java  # Secuencia 1..N, base exacta, completitud vigente y responsabilidad realizable por solicitud/etapa
        │   │   │   ├── FlujoReviewerResolver.java  # Resolución común USUARIO/ROL_DEPARTAMENTAL/base por capacidades, área y solicitud concreta
        │   │   │   ├── FlujoResponsableService.java # Catálogos autorizados y reasignación sin reemplazar etapas; versiones, auditoría y avisos
        │   │   │   ├── FlujoConcurrencyService.java # Locks de definición/solicitud y comparación de versión observada, dentro de la transacción RBAC
        │   │   │   ├── SlaService.java             # Matriz global por tipo, coincidencia exacta/desempate estable, validación y conflictos concurrentes antes de auditoría
        │   │   │   └── NotificacionService.java    # Destinatarios autorizados del paso actual, cierre real al emisor y correo RabbitMQ tras commit
        │   │   ├── util/
        │   │   │   ├── SlaStatusCalculator.java    # Alertas de 24 horas corridas y cumplimiento nullable por decisión, sin escrituras
        │   │   │   └── BusinessDaysCalculator.java # Lunes a viernes en Santiago, hora local conservada/DST y salto de semanas en tiempo constante
        │   │   ├── model/                          # @Version en FlujoDefinicion/Solicitud, TipoAccionEtapa.REVISION; FlujoEtapa.tipoAsignacion/rolRevisor (TipoAsignacionRevisor); SolicitudTransicion con etapa origen/destino nullable e inmutable; modelos documentales/SLA existentes
        │   │   └── repository/                     # Repositorios JPA: SolicitudRepository, SlaConfigRepository, FlujoDefinicionRepository, FlujoEtapaRepository, etc.
        │   │                                      # MyRequestsSpecification: texto literal/estado/área/emisor y fetch de etapa solo en contenido; MyRequestsCapabilityRepository: IDs autorizados de la página
        │   │                                      # DashboardSummaryRepository: COUNT/GROUP BY área/estado y SUM(CASE) de siete intervalos diarios, con predicado RBAC
        │   ├── org/
        │   │   ├── OrgController.java            # Endpoints: GET /api/org/config, GET /api/org/users
        │   │   └── area/                         # Administración del catálogo de áreas (ADMIN)
        │   │       ├── controller/AreaController.java # POST/GET /api/areas, PUT /{id}, PATCH /{id}/status
        │   │       ├── dto/                      # CreateAreaRequest, UpdateAreaRequest, ToggleAreaStatusRequest, AreaResponse, PaginaAreasResponse
        │   │       ├── service/AreaService.java   # Normalización, jerarquía, asignación de administradores de área, auditoría
        │   │       ├── service/AreaCatalogLock.java # pg_advisory_xact_lock(41021, 1), antes de leer para escribir
        │   │       ├── service/AreaUsageChecker.java # Counts de hijas, usuarios y asignaciones a flujos activos
        │   │       └── exception/                # AreaException y advice acotado a AreaController (ProblemDetail)
        │   └── users/                            # Administración de cuentas y organización (usuario, area, rol_flujo)
        │       ├── controller/UserController.java # POST, GET, PUT /{id}, PATCH /{id}/status, DELETE /{id}, POST /me/change-password
        │       ├── controller/PasswordChangeController.java # HU-S2-13: GET /api/auth/password-policy y POST /api/auth/change-password; alias existente por UserController
        │       ├── password/PasswordChangeOperations.java # Comprobación Direct Grant por identidad, cierre de sesión temporal, escritura Admin API, exclusión local por cuenta y auditoría posterior
        │       ├── password/PasswordPolicyRules.java # Política vigente del realm y piso de 8 caracteres; comprobaciones previas y reglas para UI
        │       ├── config/PasswordChangeWebConfig.java # no-store/nosniff en política y ambas rutas POST, incluidos errores de autenticación
        │       ├── dto/                           # CreateUserRequest (con RUT chileno y área), UpdateUserRequest, ChangePasswordRequest (actual/nueva/confirmación), ChangePasswordResponse, PasswordPolicyResponse, UserResponse
        │       ├── exception/                     # RutInvalidoException, RutDuplicadoException, UserNotFoundException, UserExceptionHandler, PasswordChangeException
        │       ├── util/RutValidator.java         # Validador de RUT chileno con algoritmo Módulo 11 (Wikipedia)
        │       ├── model/                         # UserAccount (RUT único, área vinculada), Area (administrador_id), RolFlujo y SystemRole
        │       ├── repository/                    # UserAccountRepository, AreaRepository, RolFlujoRepository
        │       └── service/                       # UserManagementService (provisión, cambio de clave, auditoría)
        └── resources/
            ├── application.yml                   # DataSource, RabbitMQ, Keycloak, MinIO e inicialización SQL previa
            ├── db/sprint2-migration.sql          # Migración idempotente Sprint 2 (RUT, SLA, áreas, correlativos)
            ├── db/sla-schema.sql                 # DO atómico antes/después de Hibernate; unicidad normalizada, validación y semillas solo en tabla nueva; no cambia deadlines
            ├── db/base-flow-seed.sql             # Seed de Revisión Simple con ID fijo 1 solo si está libre; conserva flujos, referencias y secuencia
            └── schema-postgresql.sql             # DDL canónico PostgreSQL actualizado con 19 tablas, constraints, índices y semillas Sprint 2
└── src/test/java/com/capstone/sistema/
    ├── auth/KeycloakJwtAuthenticationConverterTest.java # Pruebas de roles y principal por correo
    ├── audit/controller/AuditControllerTest.java        # Pruebas HTTP 201 login/logout y 401 sin JWT
    ├── audit/service/AuditServiceTest.java              # Registro de login/logout con captura de IP
    ├── doc/DocControllerTest.java                       # Descarga/carga MinIO autenticada y auditoría
    ├── flow/DataModelEntitiesTest.java                  # Pruebas unitarias de todo el modelo relacional JPA Sprint 2
    ├── flow/controller/FlujoConfigControllerTest.java   # Pruebas MockMvc de creación y configuración de flujos
    ├── flow/controller/CatalogoControllerTest.java      # Pruebas MockMvc de catálogo de tipos de documento y SLA
    ├── flow/controller/SlaControllerTest.java           # Pruebas MockMvc de matriz SLA
    ├── flow/controller/SolicitudControllerTest.java     # Pruebas MockMvc de solicitudes, búsqueda y métricas
    ├── flow/service/FlujoConfigServiceTest.java         # Lógica de etapas y revisores transversales
    ├── flow/service/SlaServiceTest.java                 # Días hábiles y estados SLA
    ├── flow/config/SlaSchemaIntegrationTest.java        # PostgreSQL aislado explícito: migración, duplicados concurrentes, continuidad y scripts legacy
    ├── flow/service/RequestDetailSlaTest.java            # Clock/evaluadoEn, estados activos/históricos y lectura sin escrituras
    ├── flow/util/SlaStatusCalculatorTest.java           # NORMAL/POR_VENCER/VENCIDO, límites y cumplimiento nullable
    ├── flow/service/SolicitudServiceTipoDocumentoTest.java # Pruebas de tipoDocumento, deadline SLA exacto y correlativo
    ├── flow/service/SolicitudServiceTest.java           # Pruebas completas de ciclo documental, correlativos y aislamiento
    ├── flow/util/BusinessDaysCalculatorTest.java        # Cálculo matemático de días hábiles
    ├── org/area/controller/AreaControllerTest.java      # APIs de áreas y asignación de admin
    ├── org/area/service/AreaServiceTest.java            # Lógica y auditoría de áreas
    ├── users/controller/UserControllerTest.java         # Validación de RUT chileno, áreas y cambio de contraseña
    ├── users/service/UserManagementServiceTest.java     # Provisión Keycloak, unicidad de RUT y cambio de contraseña
    └── users/util/RutValidatorTest.java                 # 37 casos de prueba de Módulo 11 con 15 RUTs válidos provistos
```

---

### 2.4 Backend: Servicio Notificaciones (`backend/service-notificaciones/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring AMQP, Spring Web (`RestClient`).
- **Puerto expuesto**: `8082`.
- **Responsabilidad**: Consumidor asíncrono desacoplado para despacho de emails transaccionales a través de la API de MasterBase®.

```
backend/service-notificaciones/
├── Dockerfile
├── pom.xml
└── src/
    └── main/
        ├── java/com/capstone/notificaciones/
        │   ├── NotificacionesApplication.java
        │   ├── config/
        │   │   └── RabbitConfig.java               # Configuración de Jackson2JsonMessageConverter para RabbitMQ
        │   ├── consumer/
        │   │   └── NotificationQueueListener.java  # @RabbitListener en "notifications.email.queue", key "notifications.email"
        │   ├── template/
        │   │   └── EmailTemplateService.java       # Motor de plantillas HTML y texto plano para notificaciones transaccionales
        │   └── client/
        │       └── ResendEmailClient.java          # Cliente HTTP hacia Resend API (/emails) con soporte de simulación y timer
        └── resources/
            └── application.yml                     # Configuración RabbitMQ y parámetros Resend (Key, From, Simulación)
```

---

### 2.5 Backend: Servicio Consultas IA (`backend/service-ia/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring AMQP, MinIO S3 SDK, Apache Tika 2.9, Spring Web (`RestClient`).
- **Puerto expuesto**: `8083`.
- **Responsabilidad**: Worker asíncrono desacoplado para auditoría documental inteligente y evaluación contra reglas de negocio con OpenRouter API (modelos LLM como LLaMA 3.3 70B Instruct). Utiliza el Claim Check Pattern para descargar documentos desde MinIO S3 y Apache Tika para extracción universal de texto (.pdf, .docx, .doc, .xlsx, .xls, .xml, .txt).

```
backend/service-ia/
├── Dockerfile
├── pom.xml
└── src/
    └── main/
        ├── java/com/capstone/ia/
        │   ├── IaApplication.java
        │   ├── config/
        │   │   ├── MinioConfig.java            # Configuración de MinioClient
        │   │   └── RabbitConfig.java           # Jackson2JsonMessageConverter y RabbitTemplate
        │   ├── service/
        │   │   ├── MinioDocumentReader.java    # Descarga de stream desde bucket documentos
        │   │   └── DocumentTextExtractor.java  # Extracción universal de texto con Apache Tika y truncado
        │   ├── client/
        │   │   ├── dto/
        │   │   │   └── OpenRouterDto.java      # Records Java 21 para Chat Completions API
        │   │   └── OpenRouterApiClient.java    # Cliente HTTP OpenRouter con modo simulación y fallbacks
        │   └── consumer/
        │       └── AiTaskListener.java         # @RabbitListener en "ai.queue" (key "ai.analysis"), emite a "ai.results"
        └── resources/
            └── application.yml                 # RabbitMQ, MinIO S3, OpenRouter y límite de caracteres
```

---

### 2.6 Infraestructura y Provisionamiento Docker (`docker/`)

```
docker/
├── keycloak/
│   ├── Dockerfile              # Imagen Keycloak 24.0.5 + proveedor local y tema de mensajes
│   ├── capstone-realm.json     # Realm "capstone-realm": cliente, roles, login por correo y fuerza bruta
│   ├── configure-login-flow.sh # Provisiona de forma idempotente el flujo browser personalizado
│   ├── provider/               # JAR Maven: reemplaza solo el formulario usuario/contraseña
│   │   └── src/main/...        # Muestra el aviso explícito de bloqueo temporal (30 minutos) por fuerza bruta
│   └── themes/capstone/login/  # Acceso empresarial MasterBase con animación y recuperación
│       ├── template.ftl        # Layout compartido; mantiene formularios y sesión nativos de Keycloak 24
│       ├── mascot.svg          # Personaje vectorial editable, incluido inline por FreeMarker
│       ├── resources/css/capstone-login.css # Paneles intercambiables, responsive y movimiento reducido
│       └── resources/js/capstone-login.js   # Mirada, párpados y transición al enlace nativo de recuperación
├── minio/
│   └── create-buckets.sh       # Script para contenedor minio-init: conecta mc y crea bucket "documentos"
├── postgres/
│   └── init/
│       └── 01-init-databases.sh # Script ejecutado al primer inicio de PostgreSQL:
│                                # - Crea BD 'keycloak_db' y usuario 'keycloak_user'
│                                # - Crea BD 'sistema_db' y usuario 'sistema_user'
│                                # - Asigna privilegios sobre esquema public
└── mcp-gws/
    ├── README.md               # Guía del servidor MCP Google Workspace y Protocolo de Ediciones Seguras
    └── credentials/            # Credenciales Service Account / OAuth (ignoradas en git)
        ├── credentials.example.json
        └── client_secret.example.json
```

---

### 2.7 Habilidades y Base de Conocimiento de Agentes (`.agents/skills/`)

Skills de espacio de trabajo que dotan a los agentes autónomos de mejores prácticas y un mecanismo eficiente para investigar y consultar documentación oficial de Spring Boot:

```
.agents/skills/
├── spring-boot-best-practices/
│   ├── SKILL.md                # Guía de estándares: arquitectura de capas, inyección limpia,
│   │                           # DTO records, Spring Security 6, JPA, RabbitMQ y testing.
│   └── references/
│       ├── rest-api-standards.md        # Nomenclatura REST, códigos HTTP y ProblemDetail.
│       ├── jpa-performance-rules.md     # Prevención N+1, FetchType.LAZY y proyecciones.
│       └── security-rbac-guidelines.md  # Configuración RBAC @PreAuthorize con Keycloak.
│
└── spring-docs-research/
    ├── SKILL.md                # Protocolo Local-First: busca en local; si no existe, busca
    │                           # en docs.spring.io y persiste el conocimiento en Markdown.
    └── references/
        ├── INDEX.md            # Índice maestro de documentación técnica local.
        ├── security-oauth2-resource-server.md # Spring Security 6.2 Resource Server JWT.
        ├── amqp-rabbitmq-json.md              # Spring AMQP y serialización Jackson JSON.
        ├── minio-s3-integration.md            # MinIO Java SDK 8.5+ con Spring Boot.
        └── restclient-spring-boot-3.md        # API fluida RestClient (Spring Boot 3.2+).
```

---

### 2.8 Suite de Pruebas Automatizadas y de Regresión E2E (`tests/e2e/`)

Módulo contenerizado con la suite oficial de pruebas de extremo a extremo y regresión continua del sistema:

```
tests/e2e/
├── Dockerfile                  # Contenedor oficial mcr.microsoft.com/playwright con socat
├── docker-entrypoint.sh        # Enrutamiento de localhost hacia los contenedores de red Docker
├── package.json                # Dependencias (@playwright/test, typescript) y scripts npm
├── tsconfig.json               # Configuración de TypeScript
├── playwright.config.ts        # Configuración de Playwright (Chromium, reporter list/html, traces)
├── README.md                   # Manual de uso y guía de extensión para desarrolladores
├── SPRINT_1_E2E_SPECS.md       # Especificación y catálogo de suites ejecutadas del Sprint 1 (33/33 tests)
├── SPRINT_2_E2E_SPECS.md       # Planificación y catálogo de 7 suites E2E para el Sprint 2 (76 CAs cubiertos)
└── src/
    ├── pages/                  # Page Object Models (POM) reutilizables
    │   ├── LoginPage.ts        # Interacción con formulario OIDC Keycloak MasterBase
    │   ├── DashboardPage.ts    # Interacción con Dashboard y layout principal
    │   ├── UsersPage.ts        # Interacción con vista y modales de Organización y Usuarios
    │   ├── AreasPage.ts        # Interacción con vista y modales de Áreas Corporativas
    │   ├── FlowsPage.ts        # Interacción con vista y modales de Configuración de Flujos y Etapas
    │   └── ChangePasswordPage.ts # Interacción con vista de Cambio de Contraseña (HU-S2-13)
    └── specs/                  # Casos de prueba automatizados por módulo
        ├── auth/
        │   ├── login-flow.spec.ts          # Sprint 1: redirección OIDC, errores y login exitoso
        │   ├── user-management.spec.ts     # Sprint 1: Alta, edición, desactivación, reactivación y baja
        │   ├── rut-validation.spec.ts      # Sprint 2 (E2E-RUT-01): Autoformato, K/k, DV y unicidad de RUT
        │   └── change-password.spec.ts     # Sprint 2 (E2E-SEC-AUTH-01): Autogestión de contraseñas
        ├── org/
        │   └── corporate-areas.spec.ts     # Sprint 2 (E2E-ORG-01): Áreas, admins de área y vinculación
        ├── flow/
        │   ├── simple-request-flow.spec.ts # Sprint 1: Ciclo completo (creación, revisión, corrección, aprobación)
        │   ├── dashboard-flow.spec.ts      # Sprint 1: Acciones pendientes y deep-linking
        │   ├── flow-configuration.spec.ts  # Sprint 2 (E2E-FLOW-CONFIG-01): Pasos secuenciales y revisores
        │   ├── sla-matrix-alerts.spec.ts   # Sprint 2 (E2E-SLA-01): Matriz de días hábiles y alertas visuales
        │   └── dashboard-general-summary.spec.ts # Sprint 2 (E2E-DASH-METRICS-01): Métricas y desglose por área
        ├── doc/
        │   ├── registrar-documento-sin-planilla.spec.ts # Sprint 1: Validación MIME y carga S3
        │   ├── ver-observaciones-revisor.spec.ts        # Sprint 1: Inspección de observaciones
        │   └── document-search-isolation.spec.ts        # Sprint 2 (E2E-DOC-SEARCH-01): Búsqueda, correlativo, jerarquía y S3
        └── zz-security/
            └── brute-force-lockout.spec.ts # Bloqueo temporal por 30 min tras 4 intentos fallidos (ejecución final)
```

**Ejecución Rápida**:
- En Windows: `.\scripts\run-e2e-tests.ps1` (o con flag interactivo: `.\scripts\run-e2e-tests.ps1 -UI`)
- En Linux / Bash: `./scripts/run-e2e-tests.sh`
- Con Docker Compose: `docker compose run --rm playwright-tests`


---

## 3. Matriz de Servicios, Puertos y Credenciales

| Contenedor Docker | Servicio | Puerto Host | Credenciales por Defecto | Variables de Entorno Clave |
| :--- | :--- | :--- | :--- | :--- |
| `capstone-postgres` | PostgreSQL 16 | `5432` | `postgres` / `postgres_secure_pass`<br>`sistema_user` / `sistema_secure_pass`<br>`keycloak_user` / `keycloak_secure_pass` | `POSTGRES_PASSWORD`, `SISTEMA_DB_*`, `KEYCLOAK_DB_*` |
| `capstone-keycloak` | Keycloak 24.0.5 con extensión local de aviso de bloqueo | `8080` | Consola Admin: `admin` / `admin_secure_pass`<br>Usuarios Realm: ver catálogo `capstone-realm.json` | `KC_DB_URL`, `KEYCLOAK_ADMIN`, `KEYCLOAK_ADMIN_PASSWORD` |
| `capstone-keycloak-init` | Inicializador efímero del flujo de autenticación | — | Usa el administrador técnico de Keycloak | `KEYCLOAK_ADMIN`, `KEYCLOAK_ADMIN_PASSWORD`, `KEYCLOAK_REALM` |
| `capstone-rabbitmq` | RabbitMQ 3.13 | `5672` (AMQP)<br>`15672` (UI) | `guest` / `guest` | `RABBITMQ_DEFAULT_USER`, `RABBITMQ_DEFAULT_PASS` |
| `capstone-minio` | MinIO S3 API / UI | `9000` (API)<br>`9001` (UI) | `minioadmin` / `minioadmin_secure_pass` | `MINIO_ROOT_USER`, `MINIO_ROOT_PASSWORD` |
| `capstone-sistema-principal` | Spring Boot (App Principal) | `8081` | Requiere Token Bearer JWT (Keycloak) | `SPRING_DATASOURCE_URL`, `KEYCLOAK_AUTH_SERVER_URL` |
| `capstone-service-notificaciones` | Spring Boot (Notificaciones Resend) | `8082` | No expone endpoints de negocio | `RESEND_API_KEY`, `RESEND_FROM_ADDRESS`, `RESEND_SIMULATION_ENABLED` |
| `capstone-service-ia` | Spring Boot (IA OpenRouter) | `8083` | No expone endpoints de negocio | `OPENROUTER_API_KEY`, `OPENROUTER_MODEL`, `OPENROUTER_SIMULATION_ENABLED` |
| `capstone-frontend` | React SPA (Nginx) | `3000` | Acceso mediante Keycloak Login | `VITE_API_URL`, `VITE_KEYCLOAK_URL` |

---

### Backend RBAC departamental y jerárquico (HU-S2-07)

El módulo `backend/sistema-principal/src/main/java/com/capstone/sistema/rbac/` concentra la política del servicio documental y de flujos existente; no introduce nuevos microservicios.

| Componente | Responsabilidad |
| --- | --- |
| `rbac/model/Permiso.java`, `Alcance.java`, `AccessContext.java` | Catálogo técnico, alcances y contexto inmutable de la petición. |
| `rbac/service/RbacAccessService.java` | Cuenta local por JWT sub; roles explícitos y derivados; exclusión de superiores; especificaciones JPA por acción; autorización de recurso, flujos y responsables. |
| `rbac/service/RbacManagementService.java` | Catálogo de roles/permisos, membresías y jefatura; lock de áreas y fila RBAC; versiones; último ADMIN; dependencias operativas; auditoría antes/después. |
| `rbac/service/RbacCatalogService.java` | Proyecciones mínimas de áreas y revisores para consumidores autorizados. |
| `rbac/controller/RbacController.java`, `rbac/dto/RbacDtos.java` | Contratos HTTP de `/api/rbac` y asignaciones de roles/jefatura de `/api/users`; DTOs y validación. |
| `rbac/exception/` | Errores RFC 7807 y validaciones de payload/parámetros; recurso invisible e inexistente comparten 404. |
| `src/main/resources/db/rbac-schema.sql`, `rbac/config/RbacSchemaInitializer.java` | Migración aditiva registrada en application.yml, semillas con versión, expansión única de APPROVER y restricciones tras Hibernate. |
| `rbac/config/RbacBootstrapInitializer.java` | Conserva el ADMIN local existente; instalación inicial por `RBAC_BOOTSTRAP_ADMIN_SUB` explícito, sin elevar identidades importadas automáticamente. |

`SolicitudService`, `SolicitudSpecifications`, `FlujoConfigService`, `AiAnalysisService` y `DocController` consumen esta política. Las consultas paginadas aplican visibilidad antes del offset/count; los conteos SLA usan la misma selección documental. `Solicitud.areaOrigenId/areaFlujoId` se capturan al emitir y no se reconstruyen para registros históricos. `usuario.jefaturaDirecta` y `versionAcceso` completan el contexto organizacional.

Backend y frontend están activados juntos en el stack local. La validación funcional/E2E y visual permanece pendiente en HU-S2-07.

### Frontend RBAC (HU-S2-07)

| Componente | Responsabilidad |
| --- | --- |
| `frontend/src/components/access/AccessContext.jsx` | Provider de /api/rbac/me, permisos locales, actualización al navegar/foco/mutaciones/errores y protección de rutas. |
| `frontend/src/services/rbac.js` | Catálogo paginado de roles asignables, etiquetas empresariales de permisos/alcances, errores y capacidades por solicitud. |
| `frontend/src/views/configuracion/ConfigurarOrgUsuariosView.jsx` | Organización y usuarios con pestañas independientes Usuarios y Roles y permisos; navegación por teclado, acciones por sección y conservación de filtros/página al alternar. |
| `frontend/src/views/configuracion/RoleManagement.jsx`, `RoleManagement.css` | Pestaña Roles y permisos dentro de Organización y usuarios; alta, edición, consulta protegida, estado y paginación de 10 filas. |
| `frontend/src/views/configuracion/UserAccessDialog.jsx` | Asignación de roles y Jefatura directa con versiones, conflictos y recarga explícita, sobre AreaDialog. |
| `App.jsx`, `services/api.js` | Shell/rutas por permiso; JWT para autenticación; notificación de mutaciones y 401/403 al provider. |
| Vistas de documentos, revisión, corrección, estado y dashboard | Acciones por recurso, trazabilidad/indicadores por permiso y consulta propia/según acceso; diseño compartido y badges SLA conservados. |
| `ConfigurarFlujosView.jsx`, `components/flows/FlowDefinitionsPanel.jsx` | Pestañas de Flujos/SLA y diseñador secuencial por área; borradores, activación explícita, ReviewerSelector para usuario/rol departamental y reasignación de etapas usadas, 10 filas, estructura protegida y versiones. |
| `services/workflowErrors.js` y vistas de revisión/corrección/estado/emisión | Versiones observadas por recurso, formularios conservados ante conflicto/resultado incierto, etapa actual, aprobación intermedia, reenvío e historial de etapas. |
| `src/main/resources/db/flow-schema.sql` | Compatibilidad de catálogos anteriores: agrega completo con FALSE antes de Hibernate y conserva etapas/solicitudes. |

## 4. Flujos de Datos Transaccionales

### 4.1 Flujo de Autenticación y Autorización (OIDC / JWT)
1. **Frontend**: Al abrir la aplicación, `keycloak.js` exige autenticación y redirige automáticamente a Keycloak (`capstone-client`) mediante Authorization Code + PKCE S256, sin formulario intermedio en React.
2. **Keycloak**: Autentica por correo o nombre de usuario mediante Authorization Code + PKCE y entrega el JWT. Los roles del realm conservan compatibilidad de identidad; los permisos funcionales se resuelven por cuenta local y PostgreSQL.
3. **Frontend Interceptor**: [`api.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/api.js) adjunta automáticamente el header `Authorization: Bearer <token>` y renueva el token cuando expira.
4. **Backend Security**: [`SecurityConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/auth/SecurityConfig.java) valida el token contra los certificados públicos de Keycloak (`jwk-set-uri`); luego `KeycloakJwtAuthenticationConverter` exige que el `sub` exista en `usuario.keycloak_id` y que la cuenta esté activa antes de otorgar la autoridad ADMIN local; los servicios aplican la política RBAC vigente. React consume /api/rbac/me y las acciones autorizadas del recurso. Una cuenta ausente o inactiva recibe HTTP 401 incluso con JWT vigente.

### 4.2 Flujo de Administración de Usuarios
1. Un usuario con rol `ADMIN` completa el formulario de “Organización y Usuarios”; el frontend envía `POST /api/users` con correo, datos personales, contraseña inicial y roles.
2. `UserManagementService` verifica duplicados, crea la identidad en Keycloak y configura su contraseña. La autorización funcional se asigna al catálogo local.
3. La cuenta se vincula en PostgreSQL mediante `usuario` y `usuario_rol`. Si falla un paso posterior a la creación remota, se elimina la identidad de Keycloak para evitar estados parciales.
4. `GET /api/users` entrega el listado persistido únicamente a administradores; otros roles reciben HTTP 403.
5. Al iniciar el backend, `ExistingKeycloakUsersSynchronizer` incorpora identidades nuevas de forma idempotente, sin copiar privilegios del realm ni restaurar permisos revocados. El primer ADMIN de una instalación nueva requiere configuración explícita de bootstrap; los ADMIN locales existentes se conservan.

### 4.3 Flujo de Cierre de Sesión Auditado
1. El usuario selecciona “Cerrar sesión” en React y el cliente renueva el JWT si corresponde.
2. React invoca `POST /api/audit/logout` con el Bearer JWT; `AuditController` exige autenticación y `AuditService` guarda el evento `LOGOUT`, correo, identificador de Keycloak y hora en `audit_events`.
3. El cliente invoca el endpoint de logout OIDC de Keycloak, que finaliza la sesión centralizada y devuelve al navegador a `/login`.
4. Una solicitud posterior sin JWT recibe HTTP 401 desde Spring Security; al cargar React, `login-required` redirige de nuevo al formulario de Keycloak.

### 4.4 Flujo de Carga y Descarga de Documentos
1. **Registro y Upload**: `NuevoDocumentoView` valida título, extensiones `.doc`/`.docx`/`.pdf`/`.xml`/`.txt` y máximo 10 MB; luego envía `titulo`, `descripcion` opcional y `file` como `multipart/form-data` a `POST /api/solicitudes`, mostrando el progreso reportado por Axios.
2. **Catálogo y persistencia**: `DefaultFlowCatalogInitializer` garantiza al arrancar los estados, acciones, formatos y flujo base requeridos. Luego `SolicitudService` almacena el binario mediante `MinioStorageService`, crea `documento` y una `solicitud` en `PENDIENTE_REVISION`, y notifica a los revisores.
3. **Confirmación y descarga**: La respuesta de creación habilita la confirmación visual; `GET /api/solicitudes/{id}/documento/descargar` recupera el archivo vigente.

### 4.5 Flujo Asíncrono de Flujos de Aprobación
1. **Envío de Solicitud**: Usuario o aprobador invoca `POST /api/flow/submit`.
2. **Broker RabbitMQ**: [`FlowController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/FlowController.java) publica el mensaje en el exchange `capstone.exchange` (tipo `topic`):
   - Con routing key `notifications.routingKey` hacia `notifications.queue`.
   - Con routing key `ai.routingKey` hacia `ai.queue`.
3. **Consumo Desacoplado**:
   - [`NotificationQueueListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/consumer/NotificationQueueListener.java) recibe el mensaje y procesa el envío de correos vía Resend API.
   - [`AiTaskListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/consumer/AiTaskListener.java) recibe el mensaje, descarga el documento desde MinIO y consulta a OpenRouter API para auditoría documental.

---

## 5. Guía Rápida para Agentes: Dónde Tocar según la Tarea

| Si tu tarea es... | Archivos directos a modificar / consultar |
| :--- | :--- |
| **Control de roles RBAC / Seguridad JWT** | [`SecurityConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/auth/SecurityConfig.java), [`capstone-realm.json`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docker/keycloak/capstone-realm.json). |
| **Creación y listado administrativo de usuarios** | `backend/sistema-principal/src/main/java/com/capstone/sistema/users/`, `frontend/src/views/configuracion/ConfigurarOrgUsuariosView.jsx`. |
| **Cambio de contraseña (HU-S2-13)** | `users/password`, `PasswordChangeController`, `UserManagementService`, `ChangePasswordRequest` y `KeycloakAdminProperties.passwordClientId`; API §8.4, `services/passwordChanges.js` y `views/acceso/ChangePasswordPage`. Menú Cuenta, sin permiso documental; la sesión de comprobación se elimina antes de escribir. El rechazo OAuth HTTP 400/401 con invalid_grant se lee antes de cerrar el verificador HTTP. Regresión focalizada: `backend/sistema-principal/src/test/java/com/capstone/sistema/users/password/PasswordChangeOperationsTest.java` (nueve casos con proveedor HTTP simulado). `KEYCLOAK_PASSWORD_CLIENT_ID` identifica el cliente público ya habilitado para Direct Grant. |
| **Áreas corporativas (Sprint 2)** | `org/area/` implementa los cuatro endpoints ADMIN; reutiliza `users/model/Area.java` y `users/repository/AreaRepository.java`. Esquema en `resources/db/area-schema.sql` y DDL de referencia `schema-postgresql.sql`; contratos en `docs/API_CONTRACTS.md` §7. Las futuras escrituras de referencias a áreas deben usar `AreaCatalogLock` antes de consultar/persistir. |
| **Administración frontend de áreas (Sprint 2)** | `frontend/src/views/configuracion/AreaManagementPage.jsx` y `.css`, `services/areas.js`, `components/areas/AreaDialog.jsx`. Menú y ruta ADMIN `/configurar-areas` en `App.jsx`; listado en servidor y catálogo de todas las páginas para jerarquía. PUT/PATCH conservan la versión leída y los conflictos requieren recarga explícita. No modifica gestión de usuarios/RUT. |
| **Selectores visuales de áreas** | `frontend/src/components/ui/DropdownSelect.jsx` y `.css`, exportados desde `ui/index.jsx`. Reutilizan la apariencia del selector de Revisar documento en Estado y Área superior. `areaPadreId` se presenta al usuario como Área superior. La tabla usa `PAGE_SIZE = 10` y navegación entre páginas. |
| **Persistencia de entidades de Base de Datos** | `backend/sistema-principal/src/main/java/com/capstone/sistema/` (crear paquetes `entity` y `repository`), [`application.yml`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/resources/application.yml). |
| **Lógica de negocio y estados de Flujos** | [`FlowController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/FlowController.java), [`RabbitConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/RabbitConfig.java). |
| **Gestor de Documentos o buckets S3** | [`DocController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/doc/DocController.java), [`MinioStorageService.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/doc/MinioStorageService.java). |
| **Detalle integral de solicitud (HU-S2-09)** | Backend: `flow/controller/RequestDetailController.java`, `flow/service/RequestDetailService.java`, `flow/dto/RequestDetailResponse.java` y auxiliares; proyecciones ordenadas y versiones documentales. Frontend: `views/flujos/RequestDetailPage.jsx`, `components/requests/`, `hooks/useRequestDetail.js`, `services/requestDetails.js` e integración en Estado/Revisar/Mis documentos. Contrato API §10. Lectura autorizada sin cambios al motor documental; validación del equipo pendiente. |
| **Búsqueda documental (HU-S2-10)** | Backend: `doc/controller/DocumentSearchController.java`, `doc/service/DocumentSearchService.java`, `DocumentSearchQueryNormalizer`, `doc/repository/DocumentSearchSpecification.java` y `DocumentSearchCatalogRepository.java`; visibilidad RBAC, página y lotes. Frontend: `views/documentos/DocumentSearchPage.jsx/.css`, `services/documentSearch.js`, `hooks/useDocumentSearch.js`, calendario `components/ui/DateFilter.jsx`, App y regreso de RequestDetailLink. Contrato API §11; implementación local completa, validación del equipo pendiente. |
| **Consumo de Notificaciones o Resend** | [`NotificationQueueListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/consumer/NotificationQueueListener.java), [`ResendEmailClient.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/client/ResendEmailClient.java). |
| **Consumo de IA o OpenRouter API** | [`AiTaskListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/consumer/AiTaskListener.java), [`OpenRouterApiClient.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/client/OpenRouterApiClient.java). |
| **Vistas y UI del usuario** | `frontend/src/views/` (subcarpetas `acceso`, `configuracion`, `documentos`, `flujos`), [`App.jsx`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/App.jsx). |
| **Seguimiento de solicitudes del emisor (HU-S2-11)** | Contratos API §12. Backend en flow: MyRequestsController/Service/QueryNormalizer, DTOs, Specification/CapabilityRepository y no-store. Frontend: views/flujos/MyRequestsPage.jsx/.css, services/myRequests.js y hooks/useMyRequests.js; App monta por cuenta en /estado-solicitudes, EstadoSolicitudesView delega. Tabla de diez, estado/etapa/correlativo, filtros, refresco, contexto/revisión RBAC y cancelación; RequestDetailLink/RequestDetailPage reutilizados. keycloak.js conserva enlaces válidos; CorregirDocumentoView/RequestDetailPanel conservan el regreso. Implementación disponible localmente; validación del equipo pendiente. |
| **Descarga segura de documentos (HU-S2-12)** | API sección 13. Backend doc: controller/DocumentDownloadController, service/DocumentDownloadResolver y DocumentDownloadWriter, dto/DocumentDownloadTarget, repository/DocumentDownloadRepository y DocumentDownloadCapabilityRepository, exception/DocumentDownloadException y DocumentDownloadExceptionHandler, config/DocumentDownloadWebConfig. MinioStorageService.openDownload entrega GetObjectResponse; SecurityConfig expone headers CORS. Cuatro rutas autenticadas, autorización por solicitud antes de MinIO, versión exacta, copia 64 KiB y auditoría de inicio. Frontend services/documentDownloads.js, hooks/useDocumentDownload.js y components/documents/DocumentDownloadButton.jsx/.css; integrados en DocumentSearchPage, MisDocumentosView, RequestDocuments y RevisarDocumentoView. RequestDetailService publica enlaces de todas las versiones; DocumentSearchService añade descargaUrl autorizada por lote. Docker actualizado; validación del equipo pendiente. |
| **Resumen general de solicitudes (HU-S2-14)** | API §14. Backend flow: DashboardSummaryController/Service/QueryNormalizer/Repository, DashboardSummaryResponse/Criteria, Exception/Handler y config/DashboardSummaryWebConfig. Intersección RBAC de métricas/lectura antes de agregación, área capturada única y calendario Santiago. Frontend views/dashboard/DashboardSummary.jsx/.css, services/dashboardSummary.js y hooks/useDashboardResource.js; DashboardView integra resumen y bandejas cancelables. api.js emite requests:changed tras mutaciones exitosas. Cuatro KPI, distribución, emisiones, filtro global y tabla de diez áreas; refresco visible 30 s. Rutas legacy compatibles: `/api/solicitudes/metricas/por-area`, `/api/catalogos/areas`. |
| **Clientes API frontend / Tokens** | [`api.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/api.js), [`keycloak.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/keycloak.js). |
| **Pruebas automatizadas y regresión E2E** | [`tests/e2e/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/), [`run-e2e-tests.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.ps1), [`playwright.config.ts`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/playwright.config.ts). |


### Responsables configurables por etapa (HU-S2-06, 03-10-2026)

`FlujoReviewerResolver` es la resolución compartida para configuración, ejecución, notificaciones y protección de mutaciones RBAC. `FlujoResponsableService` ofrece catálogos por flujo/etapa y PUT assignee, conservando los IDs y el historial de etapas usadas. Rol departamental usa miembros efectivos elegibles del área activa del flujo; las decisiones siguen la autorización local por solicitud. `RbacManagementService` comprueba etapas actuales/futuras de solicitudes abiertas incluso con flujo inactivo.

Migración aditiva en `db/flow-schema.sql`: tipo_asignacion USUARIO por defecto, rol_revisor_id restrictivo, índice y check de referencias excluyentes. El catálogo base exige modo USUARIO sin referencias explícitas. Reasignación incrementa versión de flujo y de solicitudes en el paso actual, audita antes/después y notifica nuevos destinatarios pendientes sin agregar transiciones documentales. Contratos en API_CONTRACTS.md §8.1.10. `ReviewerSelector` conserva los componentes corporativos y muestra disponibilidad; FlowDefinitionsPanel protege la estructura y permite cambiar responsable por etapa usada.

Entrega implementada y disponible en Docker; validación funcional/E2E y aprobación visual pendientes. Datos de negocio e historial conservados.
