package com.capstone.ia.client;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import static org.junit.jupiter.api.Assertions.*;

class OpenRouterApiClientTest {

    @Test
    @DisplayName("Debe activar el modo simulación si simulationEnabled es true o API key es dummy")
    void shouldActivateSimulationMode() {
        RestClient.Builder builder = RestClient.builder();
        OpenRouterApiClient client = new OpenRouterApiClient(
                builder,
                "https://openrouter.ai/api/v1",
                "your_openrouter_api_key_here",
                "meta-llama/llama-3.3-70b-instruct:free",
                true,
                50
        );

        assertTrue(client.isSimulationMode());
    }

    @Test
    @DisplayName("Debe generar respuesta estructurada JSON simulada en modo simulación")
    void shouldReturnStructuredJsonInSimulationMode() {
        RestClient.Builder builder = RestClient.builder();
        OpenRouterApiClient client = new OpenRouterApiClient(
                builder,
                "https://openrouter.ai/api/v1",
                "dummy_key",
                "meta-llama/llama-3.3-70b-instruct:free",
                true,
                10
        );

        String result = client.analyzeDocument(
                "Contrato de Servicios",
                "Contrato de prestación de servicios profesionales",
                "Verificar vigencia y firmas",
                "Contenido del documento legal..."
        );

        assertNotNull(result);
        assertTrue(result.contains("\"valido\": true"));
        assertTrue(result.contains("\"puntaje\":"));
        assertTrue(result.contains("\"observaciones\":"));
        assertTrue(result.contains("\"recomendaciones\":"));
    }
}
