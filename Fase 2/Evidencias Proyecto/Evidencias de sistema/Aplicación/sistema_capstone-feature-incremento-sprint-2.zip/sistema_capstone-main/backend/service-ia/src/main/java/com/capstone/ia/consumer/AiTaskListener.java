package com.capstone.ia.consumer;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Component
public class AiTaskListener {

    private static final Logger log = LoggerFactory.getLogger(AiTaskListener.class);

    private final MinioDocumentReader documentReader;
    private final DocumentTextExtractor textExtractor;
    private final OpenRouterApiClient openRouterClient;
    private final RabbitTemplate rabbitTemplate;

    public AiTaskListener(
            MinioDocumentReader documentReader,
            DocumentTextExtractor textExtractor,
            OpenRouterApiClient openRouterClient,
            RabbitTemplate rabbitTemplate
    ) {
        this.documentReader = documentReader;
        this.textExtractor = textExtractor;
        this.openRouterClient = openRouterClient;
        this.rabbitTemplate = rabbitTemplate;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.tasks.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = "ai.analysis"
    ))
    public void processAiTask(Map<String, Object> taskMessage) {
        if (taskMessage == null || !taskMessage.containsKey("analysisId") || taskMessage.containsKey("status")) {
            log.debug("Mensaje descartado en AiTaskListener (no es una tarea de análisis válida): {}", taskMessage);
            return;
        }
        log.info("Tarea de IA recibida desde RabbitMQ: {}", taskMessage);

        String analysisId = String.valueOf(taskMessage.get("analysisId"));
        String solicitudId = String.valueOf(taskMessage.get("solicitudId"));
        String storageKey = (String) taskMessage.get("storageKey");
        String nombreArchivo = (String) taskMessage.getOrDefault("nombreArchivo", "documento");
        String titulo = (String) taskMessage.getOrDefault("titulo", "Sin título");
        String descripcion = (String) taskMessage.getOrDefault("descripcion", "");
        String customPrompt = (String) taskMessage.get("prompt");

        try {
            String documentText = "";
            if (storageKey != null && !storageKey.isBlank()) {
                try (InputStream stream = documentReader.getDocumentStream(storageKey)) {
                    documentText = textExtractor.extractText(stream, nombreArchivo);
                }
            } else {
                log.warn("Tarea de análisis {} no especificó storageKey, evaluando solo con metadatos", analysisId);
            }

            String analysisResult = openRouterClient.analyzeDocument(titulo, descripcion, customPrompt, documentText);

            Map<String, Object> resultMap = new HashMap<>();
            resultMap.put("analysisId", analysisId);
            resultMap.put("solicitudId", solicitudId);
            resultMap.put("status", "COMPLETADO");
            resultMap.put("resultado", analysisResult);
            resultMap.put("modeloUsado", openRouterClient.getPrimaryModel());
            resultMap.put("timestamp", Instant.now().toString());

            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_RESULTS_ROUTING_KEY, resultMap);
            log.info("Resultado de análisis {} publicado exitosamente a RabbitMQ ({})", analysisId, RabbitConfig.AI_RESULTS_ROUTING_KEY);

        } catch (Exception e) {
            log.error("Error al procesar tarea de IA para análisis {}: {}", analysisId, e.getMessage(), e);

            String errorResult = """
                    {
                      "valido": false,
                      "puntaje": 0,
                      "observaciones": "Error al procesar el archivo adjunto: %s",
                      "recomendaciones": [
                        "Verificar que el archivo adjunto sea válido y legible",
                        "Reintentar el análisis del documento"
                      ]
                    }
                    """.formatted(e.getMessage() != null ? e.getMessage().replace("\"", "'") : "Error desconocido");

            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put("analysisId", analysisId);
            errorMap.put("solicitudId", solicitudId);
            errorMap.put("status", "ERROR");
            errorMap.put("resultado", errorResult);
            errorMap.put("modeloUsado", openRouterClient.getPrimaryModel());
            errorMap.put("timestamp", Instant.now().toString());

            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_RESULTS_ROUTING_KEY, errorMap);
        }
    }
}
