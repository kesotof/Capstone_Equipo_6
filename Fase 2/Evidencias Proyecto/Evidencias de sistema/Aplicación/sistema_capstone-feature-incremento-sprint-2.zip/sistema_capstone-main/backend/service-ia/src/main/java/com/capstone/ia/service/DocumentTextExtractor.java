package com.capstone.ia.service;

import org.apache.tika.Tika;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;

@Service
public class DocumentTextExtractor {

    private static final Logger log = LoggerFactory.getLogger(DocumentTextExtractor.class);

    private final Tika tika;
    private final int maxChars;

    public DocumentTextExtractor(@Value("${ai.document.max-chars:15000}") int maxChars) {
        this.tika = new Tika();
        this.maxChars = maxChars;
    }

    public String extractText(InputStream inputStream, String filename) throws Exception {
        log.info("Extrayendo texto del archivo '{}' con Apache Tika...", filename);
        String text = tika.parseToString(inputStream);
        if (text == null) {
            return "";
        }
        text = text.trim();
        if (text.length() > maxChars) {
            log.info("Texto del documento ({} caracteres) excede el límite máximo ({} caracteres). Truncando...",
                    text.length(), maxChars);
            text = text.substring(0, maxChars) + "\n... [Contenido truncado por límite de caracteres para análisis de IA]";
        }
        return text;
    }
}
