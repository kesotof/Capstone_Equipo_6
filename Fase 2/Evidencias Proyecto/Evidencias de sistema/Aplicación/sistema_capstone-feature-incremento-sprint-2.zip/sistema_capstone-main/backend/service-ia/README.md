# Service Consultas IA (Spring Boot)

Microservicio para análisis documental inteligente asistido por Inteligencia Artificial.

## Arquitectura
- **Entrada**: Consume tareas y solicitudes de revisión desde RabbitMQ (`ai.queue` vinculada a `capstone.exchange`).
- **Salida**: Se comunica con la API de Google Gemini (`gemini-1.5-flash`) para evaluar texto, coherencia, completitud o extracción de información sobre documentos en trámite.

## Configuración
- `RABBITMQ_HOST`: Host del broker RabbitMQ.
- `GEMINI_API_KEY`: API Key de Google AI Studio / Gemini API.
