package com.capstone.ia.client;

import com.capstone.ia.client.dto.OpenRouterDto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;

@Component
public class OpenRouterApiClient {

    private static final Logger log = LoggerFactory.getLogger(OpenRouterApiClient.class);

    private final RestClient restClient;
    private final String primaryModel;
    private final String apiKey;
    private final boolean simulationEnabled;
    private final long simulationDelayMs;

    public OpenRouterApiClient(
            RestClient.Builder builder,
            @Value("${openrouter.api.url:https://openrouter.ai/api/v1}") String apiUrl,
            @Value("${openrouter.api.key:}") String apiKey,
            @Value("${openrouter.api.model:openrouter/free}") String primaryModel,
            @Value("${openrouter.simulation.enabled:true}") boolean simulationEnabled,
            @Value("${openrouter.simulation.delay-ms:1500}") long simulationDelayMs
    ) {
        this.apiKey = apiKey;
        this.primaryModel = primaryModel;
        this.simulationEnabled = simulationEnabled;
        this.simulationDelayMs = simulationDelayMs;
        this.restClient = builder
                .baseUrl(apiUrl)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("HTTP-Referer", "http://localhost:3000")
                .defaultHeader("X-Title", "Sistema Capstone Gestion Documental")
                .defaultHeader("X-OpenRouter-App-Visibility", "hidden")
                .build();
    }

    public boolean isSimulationMode() {
        return simulationEnabled || apiKey == null || apiKey.isBlank() || apiKey.startsWith("your_") || apiKey.equals("dummy_key");
    }

    public String analyzeDocument(String titulo, String descripcion, String customPrompt, String documentText) {
        if (isSimulationMode()) {
            log.info("[SIMULACIÓN] Modo simulación de OpenRouter activo. Emulando latencia de {} ms...", simulationDelayMs);
            try {
                Thread.sleep(simulationDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            log.info("[SIMULACIÓN] Análisis generado exitosamente en modo simulación para '{}'", titulo);
            return """
                    {
                      "valido": true,
                      "puntaje": 88,
                      "observaciones": "El documento cumple con los estándares generales de formato y coherencia respecto a la solicitud '%s'.",
                      "recomendaciones": [
                        "Validar consistencia de fechas en las cláusulas principales",
                        "Confirmar la firma digital de los intervinientes"
                      ]
                    }
                    """.formatted(titulo != null ? titulo : "Solicitud");
        }

        log.info("Consultando OpenRouter API con modelo primario: {}", primaryModel);

        String systemContent = "Eres un auditor y evaluador documental experto. Tu tarea es analizar el documento adjunto y verificar si cumple con las directrices o reglas de negocio señaladas por el usuario, evaluando su coherencia y completitud. Responde ÚNICAMENTE un objeto JSON válido con la siguiente estructura exacta: {\"valido\": boolean, \"puntaje\": integer (1-100), \"observaciones\": string, \"recomendaciones\": [string, ...]}";

        String userContent = """
                Título de la solicitud: %s
                Descripción: %s
                
                Reglas de negocio / Instrucciones específicas de auditoría:
                %s
                
                Contenido del documento extraído:
                %s
                """.formatted(
                titulo != null ? titulo : "Sin título",
                descripcion != null ? descripcion : "Sin descripción",
                customPrompt != null && !customPrompt.isBlank() ? customPrompt : "Validar coherencia general, datos completos y ausencia de errores evidentes.",
                documentText != null && !documentText.isBlank() ? documentText : "[Documento sin contenido textual identificable]"
        );

        ChatRequest request = new ChatRequest(
                primaryModel,
                List.of(
                        "openrouter/free",
                        "qwen/qwen3.8-27b:free",
                        "deepseek/deepseek-v4-flash-0731:free"
                ),
                List.of(
                        new Message("system", systemContent),
                        new Message("user", userContent)
                ),
                new ResponseFormat("json_object"),
                0.2,
                2048,
                new ProviderConfig(true, true),
                false
        );

        try {
            ChatResponse response = restClient.post()
                    .uri("/chat/completions")
                    .body(request)
                    .retrieve()
                    .body(ChatResponse.class);

            if (response != null && response.choices() != null && !response.choices().isEmpty()) {
                String content = response.choices().get(0).message().content();
                log.info("Respuesta de análisis recibida desde OpenRouter (Modelo: {}, Provider: {})",
                        response.model(), response.provider());
                return content;
            }
            return """
                    {
                      "valido": false,
                      "puntaje": 0,
                      "observaciones": "El proveedor LLM retornó una respuesta vacía.",
                      "recomendaciones": ["Reintentar el análisis"]
                    }
                    """;
        } catch (Exception e) {
            log.warn("Error o timeout al consultar OpenRouter API (activando modo contingencia local): {}", e.getMessage());
            return """
                    {
                      "valido": true,
                      "puntaje": 80,
                      "observaciones": "Análisis preliminar generado en modo contingencia local (OpenRouter temporalmente no disponible: %s).",
                      "recomendaciones": [
                        "Verificar conectividad con OpenRouter",
                        "Realizar revisión manual preliminar"
                      ]
                    }
                    """.formatted(e.getMessage() != null ? e.getMessage().replace("\"", "'") : "Error desconocido");
        }
    }

    public String getPrimaryModel() {
        return primaryModel;
    }
}
