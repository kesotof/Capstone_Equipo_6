package com.capstone.ia.client.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class OpenRouterDto {

    public record Message(
            String role,
            String content
    ) {}

    public record ResponseFormat(
            String type
    ) {}

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ProviderConfig(
            Boolean allow_fallbacks,
            Boolean require_parameters
    ) {}

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ChatRequest(
            String model,
            List<String> models,
            List<Message> messages,
            @JsonProperty("response_format") ResponseFormat responseFormat,
            Double temperature,
            @JsonProperty("max_tokens") Integer maxTokens,
            ProviderConfig provider,
            Boolean stream
    ) {}

    public record Choice(
            int index,
            Message message,
            @JsonProperty("finish_reason") String finishReason
    ) {}

    public record Usage(
            @JsonProperty("prompt_tokens") int promptTokens,
            @JsonProperty("completion_tokens") int completionTokens,
            @JsonProperty("total_tokens") int totalTokens
    ) {}

    public record ChatResponse(
            String id,
            String model,
            String provider,
            List<Choice> choices,
            Usage usage
    ) {}
}
