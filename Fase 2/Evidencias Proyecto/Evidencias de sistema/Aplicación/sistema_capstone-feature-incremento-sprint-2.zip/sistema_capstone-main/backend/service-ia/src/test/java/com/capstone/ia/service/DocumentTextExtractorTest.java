package com.capstone.ia.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class DocumentTextExtractorTest {

    @Test
    @DisplayName("Debe extraer texto correctamente desde un stream de texto")
    void shouldExtractTextCorrectly() throws Exception {
        DocumentTextExtractor extractor = new DocumentTextExtractor(5000);
        String sampleText = "Este es un documento de prueba para auditoría y evaluación.";
        ByteArrayInputStream stream = new ByteArrayInputStream(sampleText.getBytes(StandardCharsets.UTF_8));

        String extracted = extractor.extractText(stream, "prueba.txt");

        assertNotNull(extracted);
        assertTrue(extracted.contains("documento de prueba"));
    }

    @Test
    @DisplayName("Debe truncar el texto si supera el límite máximo de caracteres configurado")
    void shouldTruncateTextWhenExceedsLimit() throws Exception {
        int maxChars = 50;
        DocumentTextExtractor extractor = new DocumentTextExtractor(maxChars);
        String longText = "Texto muy largo que definitivamente superará el límite de cincuenta caracteres establecido para esta prueba unitaria.";
        ByteArrayInputStream stream = new ByteArrayInputStream(longText.getBytes(StandardCharsets.UTF_8));

        String extracted = extractor.extractText(stream, "largo.txt");

        assertNotNull(extracted);
        assertTrue(extracted.contains("... [Contenido truncado por límite de caracteres"));
    }
}
