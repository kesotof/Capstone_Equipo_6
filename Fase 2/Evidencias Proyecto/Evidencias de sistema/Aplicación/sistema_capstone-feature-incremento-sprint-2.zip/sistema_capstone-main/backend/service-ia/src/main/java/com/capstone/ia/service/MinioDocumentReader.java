package com.capstone.ia.service;

import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;

@Service
public class MinioDocumentReader {

    private static final Logger log = LoggerFactory.getLogger(MinioDocumentReader.class);

    private final MinioClient minioClient;
    private final String bucketName;

    public MinioDocumentReader(
            MinioClient minioClient,
            @Value("${minio.bucket}") String bucketName
    ) {
        this.minioClient = minioClient;
        this.bucketName = bucketName;
    }

    public InputStream getDocumentStream(String storageKey) throws Exception {
        log.info("Descargando documento desde MinIO: bucket={}, key={}", bucketName, storageKey);
        return minioClient.getObject(
                GetObjectArgs.builder()
                        .bucket(bucketName)
                        .object(storageKey)
                        .build()
        );
    }
}
