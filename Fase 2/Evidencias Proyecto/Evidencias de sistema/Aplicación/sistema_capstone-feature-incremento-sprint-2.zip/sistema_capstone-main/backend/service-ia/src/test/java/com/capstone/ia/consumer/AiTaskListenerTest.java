package com.capstone.ia.consumer;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AiTaskListenerTest {

    @Mock
    private MinioDocumentReader documentReader;

    @Mock
    private DocumentTextExtractor textExtractor;

    @Mock
    private OpenRouterApiClient openRouterClient;

    @Mock
    private RabbitTemplate rabbitTemplate;

    private AiTaskListener listener;

    @BeforeEach
    void setUp() {
        listener = new AiTaskListener(documentReader, textExtractor, openRouterClient, rabbitTemplate);
    }

    @Test
    @DisplayName("Debe procesar la tarea de IA exitosamente y publicar el resultado en ai.results")
    void shouldProcessAiTaskSuccessfully() throws Exception {
        InputStream dummyStream = new ByteArrayInputStream("prueba".getBytes());
        when(documentReader.getDocumentStream("docs/uuid_test.pdf")).thenReturn(dummyStream);
        when(textExtractor.extractText(any(InputStream.class), eq("test.pdf"))).thenReturn("Texto extraido");
        when(openRouterClient.analyzeDocument(eq("Titulo"), eq("Desc"), eq("Prompt"), eq("Texto extraido")))
                .thenReturn("{\"valido\": true, \"puntaje\": 95}");
        when(openRouterClient.getPrimaryModel()).thenReturn("meta-llama/llama-3.3-70b-instruct:free");

        Map<String, Object> taskMessage = Map.of(
                "analysisId", "analysis-123",
                "solicitudId", "solicitud-456",
                "storageKey", "docs/uuid_test.pdf",
                "nombreArchivo", "test.pdf",
                "titulo", "Titulo",
                "descripcion", "Desc",
                "prompt", "Prompt"
        );

        listener.processAiTask(taskMessage);

        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass(Map.class);
        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.AI_RESULTS_ROUTING_KEY),
                captor.capture()
        );

        Map<String, Object> sentMessage = captor.getValue();
        assertEquals("analysis-123", sentMessage.get("analysisId"));
        assertEquals("solicitud-456", sentMessage.get("solicitudId"));
        assertEquals("COMPLETADO", sentMessage.get("status"));
        assertTrue(String.valueOf(sentMessage.get("resultado")).contains("\"puntaje\": 95"));
    }

    @Test
    @DisplayName("Debe capturar errores y emitir mensaje con status ERROR a ai.results si MinIO falla")
    void shouldHandleFailureAndPublishErrorStatus() throws Exception {
        when(documentReader.getDocumentStream("docs/error.pdf")).thenThrow(new RuntimeException("MinIO Connection Refused"));
        when(openRouterClient.getPrimaryModel()).thenReturn("meta-llama/llama-3.3-70b-instruct:free");

        Map<String, Object> taskMessage = Map.of(
                "analysisId", "analysis-error",
                "solicitudId", "solicitud-789",
                "storageKey", "docs/error.pdf",
                "nombreArchivo", "error.pdf"
        );

        listener.processAiTask(taskMessage);

        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass(Map.class);
        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.AI_RESULTS_ROUTING_KEY),
                captor.capture()
        );

        Map<String, Object> sentMessage = captor.getValue();
        assertEquals("analysis-error", sentMessage.get("analysisId"));
        assertEquals("ERROR", sentMessage.get("status"));
        assertTrue(String.valueOf(sentMessage.get("resultado")).contains("MinIO Connection Refused"));
    }
}
