package com.capstone.notificaciones.consumer;

import com.capstone.notificaciones.client.ResendEmailClient;
import com.capstone.notificaciones.template.EmailTemplateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class NotificationQueueListener {

    private static final Logger log = LoggerFactory.getLogger(NotificationQueueListener.class);

    private final ResendEmailClient resendEmailClient;
    private final EmailTemplateService emailTemplateService;

    public NotificationQueueListener(
            ResendEmailClient resendEmailClient,
            EmailTemplateService emailTemplateService
    ) {
        this.resendEmailClient = resendEmailClient;
        this.emailTemplateService = emailTemplateService;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "notifications.email.queue", durable = "true"),
            exchange = @Exchange(value = "capstone.exchange", type = "topic"),
            key = "notifications.email"
    ))
    public void handleNotificationMessage(Map<String, Object> message) {
        log.info("Mensaje de notificación recibido desde RabbitMQ: {}", message);

        String recipientEmail = (String) message.getOrDefault("recipientEmail", "destinatario@ejemplo.cl");
        String recipientName = (String) message.getOrDefault("recipientName", "Usuario");
        String notificationType = (String) message.getOrDefault("notificationType", "GENERAL");
        String subject = (String) message.getOrDefault("subject", "Notificación de Sistema Capstone");
        String body = (String) message.getOrDefault("body", "Hay una actualización en tu solicitud.");
        String solicitudId = (String) message.getOrDefault("solicitudId", "");
        String solicitudTitulo = (String) message.getOrDefault("solicitudTitulo", "");
        String actorName = (String) message.getOrDefault("actorName", "El Sistema");

        EmailTemplateService.EmailContent content = emailTemplateService.render(
                notificationType,
                recipientName,
                body,
                solicitudTitulo,
                actorName
        );

        String idempotencyKey = "notif_" + solicitudId + "_" + notificationType + "_" + System.currentTimeMillis();

        try {
            String emailId = resendEmailClient.sendEmail(
                    recipientEmail,
                    subject,
                    content.html(),
                    content.text(),
                    idempotencyKey
            );
            log.info("Procesamiento de email completado exitosamente para {} (id: {})", recipientEmail, emailId);
        } catch (Exception e) {
            log.error("Fallo al procesar y despachar email hacia {}: {}", recipientEmail, e.getMessage(), e);
        }
    }
}
