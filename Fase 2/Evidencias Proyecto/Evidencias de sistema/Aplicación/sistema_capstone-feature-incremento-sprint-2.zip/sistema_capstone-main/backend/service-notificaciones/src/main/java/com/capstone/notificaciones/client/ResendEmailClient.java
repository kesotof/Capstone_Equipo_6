package com.capstone.notificaciones.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.UUID;

@Component
public class ResendEmailClient {

    private static final Logger log = LoggerFactory.getLogger(ResendEmailClient.class);

    private final RestClient restClient;
    private final String apiKey;
    private final String fromAddress;
    private final boolean simulationEnabled;
    private final long simulationDelayMs;

    public ResendEmailClient(
            @Value("${resend.api-key:your_resend_api_key_here}") String apiKey,
            @Value("${resend.from-address:Capstone Sistema <onboarding@resend.dev>}") String fromAddress,
            @Value("${resend.simulation-enabled:true}") boolean simulationEnabled,
            @Value("${resend.simulation-delay-ms:300}") long simulationDelayMs
    ) {
        this.apiKey = apiKey != null ? apiKey.trim() : "";
        this.fromAddress = fromAddress;
        this.simulationEnabled = simulationEnabled;
        this.simulationDelayMs = simulationDelayMs;

        this.restClient = RestClient.builder()
                .baseUrl("https://api.resend.com")
                .defaultHeader("Authorization", "Bearer " + this.apiKey)
                .defaultHeader("User-Agent", "CapstoneDocumentSystem/1.0")
                .defaultHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    public record SendEmailRequest(
            String from,
            String to,
            String subject,
            String html,
            String text
    ) {}

    public record SendEmailResponse(String id) {}

    public String sendEmail(String to, String subject, String html, String text, String idempotencyKey) {
        if (shouldSimulate()) {
            return simulateSend(to, subject);
        }

        log.info("Invocando Resend API para enviar correo a: {} - Asunto: '{}'", to, subject);
        try {
            SendEmailRequest request = new SendEmailRequest(fromAddress, to, subject, html, text);

            var spec = restClient.post()
                    .uri("/emails")
                    .body(request);

            if (idempotencyKey != null && !idempotencyKey.isBlank()) {
                spec = spec.header("Idempotency-Key", idempotencyKey);
            }

            SendEmailResponse response = spec.retrieve().body(SendEmailResponse.class);
            String emailId = response != null ? response.id() : "unknown";
            log.info("Correo enviado exitosamente vía Resend API a {}. ID: {}", to, emailId);
            return emailId;
        } catch (Exception e) {
            log.error("Error al enviar correo vía Resend API a {}: {}", to, e.getMessage(), e);
            throw new RuntimeException("Fallo en envío de correo vía Resend: " + e.getMessage(), e);
        }
    }

    private boolean shouldSimulate() {
        if (simulationEnabled) {
            return true;
        }
        return apiKey.isEmpty() || apiKey.contains("your_resend_api_key_here") || apiKey.equals("dummy_key") || apiKey.equals("re_test_key");
    }

    private String simulateSend(String to, String subject) {
        if (simulationDelayMs > 0) {
            try {
                Thread.sleep(simulationDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        String simId = "sim_" + UUID.randomUUID();
        log.info("[SIMULACIÓN] Correo simulado exitosamente hacia: {} - Asunto: '{}' - ID: {} (Simulación activa)",
                to, subject, simId);
        return simId;
    }
}
