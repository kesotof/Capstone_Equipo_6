package com.capstone.notificaciones.client;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ResendEmailClientTest {

    @Test
    void sendEmail_WithSimulationEnabled_ReturnsSimulatedId() {
        ResendEmailClient client = new ResendEmailClient(
                "re_123456789",
                "Test <onboarding@resend.dev>",
                true,
                10 // delay corto para test
        );

        String id = client.sendEmail(
                "user@capstone.local",
                "Asunto Test",
                "<p>HTML</p>",
                "TEXT",
                "idem-123"
        );

        assertThat(id).isNotNull();
        assertThat(id).startsWith("sim_");
    }

    @Test
    void sendEmail_WithDummyKey_ActivatesSimulationEvenIfDisabled() {
        ResendEmailClient client = new ResendEmailClient(
                "your_resend_api_key_here",
                "Test <onboarding@resend.dev>",
                false,
                10
        );

        String id = client.sendEmail(
                "user@capstone.local",
                "Asunto Dummy",
                "<p>HTML</p>",
                "TEXT",
                "idem-456"
        );

        assertThat(id).isNotNull();
        assertThat(id).startsWith("sim_");
    }
}
