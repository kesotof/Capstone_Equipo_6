package com.capstone.notificaciones.template;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class EmailTemplateServiceTest {

    private final EmailTemplateService templateService = new EmailTemplateService();

    @Test
    void render_Aprobacion_GeneratesValidHtmlAndText() {
        EmailTemplateService.EmailContent content = templateService.render(
                "APROBACION",
                "Carlos Mendoza",
                "Tu solicitud ha sido aprobada.",
                "Balance Trimestral 2026",
                "Ana Gómez"
        );

        assertThat(content).isNotNull();
        assertThat(content.html()).contains("Carlos Mendoza");
        assertThat(content.html()).contains("Balance Trimestral 2026");
        assertThat(content.html()).contains("Ana Gómez");
        assertThat(content.html()).contains("Solicitud Aprobada");

        assertThat(content.text()).contains("Carlos Mendoza");
        assertThat(content.text()).contains("Balance Trimestral 2026");
        assertThat(content.text()).contains("Solicitud Aprobada");
    }

    @Test
    void render_Rechazo_ContainsRejectionNotice() {
        EmailTemplateService.EmailContent content = templateService.render(
                "RECHAZO",
                "Juan Pérez",
                "Motivo: Documento ilegible",
                "Contrato Q3",
                "Revisor Legal"
        );

        assertThat(content.html()).contains("Solicitud Rechazada");
        assertThat(content.html()).contains("Documento ilegible");
        assertThat(content.text()).contains("Solicitud Rechazada");
    }
}
