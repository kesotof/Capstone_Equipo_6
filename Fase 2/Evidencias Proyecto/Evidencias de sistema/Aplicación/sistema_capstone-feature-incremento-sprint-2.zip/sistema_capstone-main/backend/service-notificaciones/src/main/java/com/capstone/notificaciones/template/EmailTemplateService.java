package com.capstone.notificaciones.template;

import org.springframework.stereotype.Service;

@Service
public class EmailTemplateService {

    public record EmailContent(String html, String text) {}

    public EmailContent render(
            String notificationType,
            String recipientName,
            String body,
            String solicitudTitulo,
            String actorName
    ) {
        String safeRecipient = (recipientName != null && !recipientName.isBlank()) ? recipientName : "Usuario";
        String safeTitulo = (solicitudTitulo != null && !solicitudTitulo.isBlank()) ? solicitudTitulo : "Documento del Sistema";
        String safeBody = (body != null && !body.isBlank()) ? body : "";
        String safeActor = (actorName != null && !actorName.isBlank()) ? actorName : "El Sistema";

        String badgeColor = switch (notificationType != null ? notificationType : "") {
            case "APROBACION" -> "#10B981"; // verde
            case "RECHAZO" -> "#EF4444"; // rojo
            case "CORRECCION_REQUERIDA" -> "#F59E0B"; // naranja
            case "REENVIO" -> "#3B82F6"; // azul
            default -> "#6366F1"; // índigo
        };

        String actionLabel = switch (notificationType != null ? notificationType : "") {
            case "APROBACION" -> "Solicitud Aprobada";
            case "RECHAZO" -> "Solicitud Rechazada";
            case "CORRECCION_REQUERIDA" -> "Corrección Solicitada";
            case "REENVIO" -> "Solicitud Reenviada";
            default -> "Nueva Solicitud Registrada";
        };

        String html = """
                <!DOCTYPE html>
                <html lang="es">
                <head>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <title>%s</title>
                  <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #F3F4F6; margin: 0; padding: 24px; color: #1F2937; }
                    .card { max-width: 600px; margin: 0 auto; background: #FFFFFF; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
                    .header { background: #1E293B; color: #FFFFFF; padding: 24px; text-align: center; }
                    .badge { display: inline-block; background: %s; color: #FFFFFF; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 600; text-transform: uppercase; margin-bottom: 8px; }
                    .content { padding: 32px 24px; line-height: 1.6; }
                    .solicitud-box { background: #F9FAFB; border-left: 4px solid %s; padding: 16px; margin: 20px 0; border-radius: 4px; }
                    .footer { background: #F9FAFB; padding: 16px 24px; text-align: center; font-size: 12px; color: #6B7280; border-top: 1px solid #E5E7EB; }
                  </style>
                </head>
                <body>
                  <div class="card">
                    <div class="header">
                      <div class="badge">%s</div>
                      <h2 style="margin: 0; font-size: 20px;">Sistema de Gestión Documental</h2>
                    </div>
                    <div class="content">
                      <p>Hola <strong>%s</strong>,</p>
                      <p>%s</p>
                      <div class="solicitud-box">
                        <p style="margin: 0; font-size: 14px; color: #6B7280;">Documento / Solicitud:</p>
                        <p style="margin: 4px 0 0 0; font-size: 16px; font-weight: 600; color: #111827;">%s</p>
                        <p style="margin: 8px 0 0 0; font-size: 13px; color: #4B5563;">Acción realizada por: <strong>%s</strong></p>
                      </div>
                      <p style="font-size: 14px; color: #4B5563;">Puedes ingresar a la plataforma para revisar los detalles completos y dar seguimiento.</p>
                    </div>
                    <div class="footer">
                      <p style="margin: 0;">Este es un mensaje automático emitido por el Sistema Capstone.</p>
                      <p style="margin: 4px 0 0 0;">Por favor no respondas a este correo.</p>
                    </div>
                  </div>
                </body>
                </html>
                """.formatted(
                actionLabel,
                badgeColor,
                badgeColor,
                actionLabel,
                safeRecipient,
                safeBody,
                safeTitulo,
                safeActor
        );

        String text = """
                Sistema de Gestión Documental y Flujos de Aprobación
                [%s]
                
                Hola %s,
                
                %s
                
                Detalles:
                - Documento: %s
                - Por: %s
                
                Ingresa al sistema para revisar los detalles y continuar el flujo.
                """.formatted(
                actionLabel,
                safeRecipient,
                safeBody,
                safeTitulo,
                safeActor
        );

        return new EmailContent(html, text);
    }
}
