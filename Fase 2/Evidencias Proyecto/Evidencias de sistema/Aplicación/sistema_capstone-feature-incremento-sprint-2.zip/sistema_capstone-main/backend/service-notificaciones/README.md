# Service Notificaciones Mail (Spring Boot)

Microservicio desacoplado responsable del despacho de correos transaccionales y notificaciones de flujo.

## Arquitectura
- **Entrada**: Consume eventos asincrónicos desde RabbitMQ (`notifications.queue` vinculada a `capstone.exchange`).
- **Salida**: Realiza peticiones HTTPS a la API externa de MasterBase® para el envío confiable de correos electrónicos.

## Configuración
- `RABBITMQ_HOST`: Host del broker RabbitMQ.
- `MASTERBASE_API_URL`: URL base de la API MasterBase.
- `MASTERBASE_API_KEY`: Clave de autenticación API MasterBase.
