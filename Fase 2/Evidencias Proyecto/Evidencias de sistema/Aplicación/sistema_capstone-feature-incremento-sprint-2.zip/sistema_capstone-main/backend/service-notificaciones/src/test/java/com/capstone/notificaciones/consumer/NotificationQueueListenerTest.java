package com.capstone.notificaciones.consumer;

import com.capstone.notificaciones.client.ResendEmailClient;
import com.capstone.notificaciones.template.EmailTemplateService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationQueueListenerTest {

    @Mock
    private ResendEmailClient resendEmailClient;

    @Mock
    private EmailTemplateService emailTemplateService;

    @InjectMocks
    private NotificationQueueListener listener;

    @Test
    void handleNotificationMessage_RendersAndSendsEmail() {
        when(emailTemplateService.render(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new EmailTemplateService.EmailContent("<p>Html</p>", "Text"));

        when(resendEmailClient.sendEmail(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn("sim_9999");

        Map<String, Object> message = Map.of(
                "recipientEmail", "juan@capstone.local",
                "recipientName", "Juan",
                "notificationType", "APROBACION",
                "subject", "Solicitud Aprobada",
                "body", "Tu informe fue aprobado",
                "solicitudId", "123e4567-e89b-12d3-a456-426614174000",
                "solicitudTitulo", "Informe Q3",
                "actorName", "Admin"
        );

        listener.handleNotificationMessage(message);

        verify(emailTemplateService).render(
                eq("APROBACION"),
                eq("Juan"),
                eq("Tu informe fue aprobado"),
                eq("Informe Q3"),
                eq("Admin")
        );

        verify(resendEmailClient).sendEmail(
                eq("juan@capstone.local"),
                eq("Solicitud Aprobada"),
                eq("<p>Html</p>"),
                eq("Text"),
                startsWith("notif_123e4567-e89b-12d3-a456-426614174000_APROBACION_")
        );
    }
}
