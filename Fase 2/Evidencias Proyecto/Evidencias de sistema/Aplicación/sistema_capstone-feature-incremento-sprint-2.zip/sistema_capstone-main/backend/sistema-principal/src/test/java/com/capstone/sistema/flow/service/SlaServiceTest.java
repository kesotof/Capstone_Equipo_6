package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.CreateSlaConfigRequest;
import com.capstone.sistema.flow.dto.SlaConfigResponse;
import com.capstone.sistema.flow.dto.UpdateSlaConfigRequest;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.model.SlaConfig;
import com.capstone.sistema.flow.repository.SlaConfigRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.Clock;
import java.time.ZoneOffset;
import java.sql.SQLException;
import org.springframework.dao.DataIntegrityViolationException;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SlaServiceTest {

    @Mock
    private SlaConfigRepository slaConfigRepository;

    @Mock
    private AuditService auditService;

    private SlaService slaService;

    @BeforeEach
    void setUp() {
        slaService = new SlaService(slaConfigRepository, auditService,
                Clock.fixed(Instant.parse("2026-09-28T10:00:00Z"), ZoneOffset.UTC));
    }

    @Test
    @DisplayName("Admin crea regla SLA para nuevo tipo de documento y se audita el evento")
    void create_tipoValido_retornaCreadoYAudita() {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("Contrato de Arriendo", 7);
        when(slaConfigRepository.existsByTipoDocumentoIgnoreCase("Contrato de Arriendo")).thenReturn(false);

        when(slaConfigRepository.saveAndFlush(any(SlaConfig.class))).thenAnswer(invocation -> {
            SlaConfig c = invocation.getArgument(0);
            return c;
        });

        SlaConfigResponse response = slaService.create(request);

        assertThat(response.tipoDocumento()).isEqualTo("Contrato de Arriendo");
        assertThat(response.plazoDias()).isEqualTo(7);

        verify(auditService).registerUserManagementEvent(eq("CONFIGURAR_SLA"), contains("Contrato de Arriendo"));
    }

    @Test
    @DisplayName("Crear regla SLA con tipo de documento existente lanza FlujoConflictException")
    void create_tipoDuplicado_lanzaFlujoConflict() {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("Factura", 3);
        when(slaConfigRepository.existsByTipoDocumentoIgnoreCase("Factura")).thenReturn(true);

        assertThatThrownBy(() -> slaService.create(request))
                .isInstanceOf(FlujoConflictException.class)
                .hasMessageContaining("Ya existe una regla SLA");
    }

    @Test
    @DisplayName("Actualizar plazo en regla SLA modifica plazo y audita evento")
    void update_modificaPlazoDiasYAudita() {
        SlaConfig existente = new SlaConfig("Factura", 3);
        when(slaConfigRepository.findById(1L)).thenReturn(Optional.of(existente));
        when(slaConfigRepository.saveAndFlush(any(SlaConfig.class))).thenAnswer(invocation -> invocation.getArgument(0));

        UpdateSlaConfigRequest request = new UpdateSlaConfigRequest(5);
        SlaConfigResponse response = slaService.update(1L, request);

        assertThat(response.plazoDias()).isEqualTo(5);
        verify(auditService).registerUserManagementEvent(eq("CONFIGURAR_SLA"), contains("plazo modificado a 5"));
    }

    @Test
    @DisplayName("Eliminar regla SLA borra registro y audita evento")
    void delete_eliminaRegistroYAudita() {
        SlaConfig existente = new SlaConfig("Temporal", 2);
        when(slaConfigRepository.findById(5L)).thenReturn(Optional.of(existente));

        slaService.delete(5L);

        verify(slaConfigRepository).delete(existente);
        verify(auditService).registerUserManagementEvent(eq("CONFIGURAR_SLA"), contains("eliminada"));
    }

    @Test
    @DisplayName("Listar todas las reglas retorna lista ordenada por tipo de documento")
    void listAll_retornaListaOrdenada() {
        SlaConfig c1 = new SlaConfig("Memorándum", 2);
        SlaConfig c2 = new SlaConfig("Contrato", 5);
        when(slaConfigRepository.findAll()).thenReturn(List.of(c1, c2));

        List<SlaConfigResponse> list = slaService.listAll();

        assertThat(list).hasSize(2);
        assertThat(list.get(0).tipoDocumento()).isEqualTo("Contrato");
        assertThat(list.get(1).tipoDocumento()).isEqualTo("Memorándum");
    }

    @Test
    @DisplayName("Cálculo de deadline para Contrato toma el plazo configurado de 5 días hábiles")
    void calculateDeadline_contrato_utilizaPlazoConfigurado() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Contrato de Prestación"))
                .thenReturn(Optional.empty());
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Contrato"))
                .thenReturn(Optional.of(new SlaConfig("Contrato", 5)));

        Instant start = Instant.parse("2026-09-28T10:00:00Z"); // Lunes
        Instant deadline = slaService.calculateDeadline("Contrato de Prestación", start);

        assertThat(deadline).isAfter(start);
    }

    @Test
    @DisplayName("Cálculo de deadline para regla personalizada por subcadena toma el plazo de dicha regla")
    void calculateDeadline_reglaPersonalizadaSubcadena_utilizaPlazoConfigurado() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Contrato de Servicios para Proveedores"))
                .thenReturn(Optional.empty());
        SlaConfig reglaCustom = new SlaConfig("Contrato de Servicios", 4);
        when(slaConfigRepository.findAll()).thenReturn(List.of(reglaCustom));

        Instant start = Instant.parse("2026-09-28T10:00:00Z"); // Lunes
        Instant deadline = slaService.calculateDeadline("Contrato de Servicios para Proveedores", start);

        assertThat(deadline).isAfter(start);
    }

    @Test
    @DisplayName("Listar tipos de documento retorna catalogo con plazos")
    void listTiposDocumento_retornaCatalogo() {
        SlaConfig c1 = new SlaConfig("Factura", 3);
        SlaConfig c2 = new SlaConfig("Contrato", 5);
        when(slaConfigRepository.findAll()).thenReturn(List.of(c1, c2));

        var list = slaService.listTiposDocumento();

        assertThat(list).hasSize(2);
        assertThat(list.get(0).tipo()).isEqualTo("Contrato");
        assertThat(list.get(0).plazoDias()).isEqualTo(5);
        assertThat(list.get(1).tipo()).isEqualTo("Factura");
        assertThat(list.get(1).plazoDias()).isEqualTo(3);
    }

    @Test
    @DisplayName("Cálculo de deadline con tipoDocumento exacto toma la regla directa sin consultar titulo")
    void calculateDeadline_tipoDocumentoExacto_priorizaTipo() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Informe"))
                .thenReturn(Optional.of(new SlaConfig("Informe", 7)));

        Instant start = Instant.parse("2026-09-28T10:00:00Z"); // Lunes
        Instant deadline = slaService.calculateDeadline("Informe", "Titulo Arbitrario de Contrato", start);

        assertThat(deadline).isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 7));
    }

    @Test
    @DisplayName("Cálculo de deadline con tipoDocumento vacio usa fallback a titulo")
    void calculateDeadline_tipoVacio_usaFallbackTitulo() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Factura de Compra"))
                .thenReturn(Optional.empty());
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Factura"))
                .thenReturn(Optional.of(new SlaConfig("Factura", 3)));

        Instant start = Instant.parse("2026-09-28T10:00:00Z"); // Lunes
        Instant deadline = slaService.calculateDeadline("", "Factura de Compra", start);

        assertThat(deadline).isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 3));
    }

    @Test
    @DisplayName("Cálculo de deadline sin coincidencia en tipo ni titulo aplica default de 5 dias habiles")
    void calculateDeadline_sinCoincidencia_aplicaDefault5Dias() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Otro"))
                .thenReturn(Optional.empty());
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("Documento X"))
                .thenReturn(Optional.empty());
        when(slaConfigRepository.findAll()).thenReturn(List.of());
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("General"))
                .thenReturn(Optional.of(new SlaConfig("General", 5)));

        Instant start = Instant.parse("2026-09-28T10:00:00Z"); // Lunes
        Instant deadline = slaService.calculateDeadline("Otro", "Documento X", start);

        assertThat(deadline).isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 5));
    }

    @Test
    void create_conflictoConcurrente_retornaConflictoSinAuditar() {
        when(slaConfigRepository.saveAndFlush(any(SlaConfig.class))).thenThrow(
                new DataIntegrityViolationException("duplicate", new SQLException("duplicate", "23505")));
        assertThatThrownBy(() -> slaService.create(new CreateSlaConfigRequest("Contrato", 4)))
                .isInstanceOf(FlujoConflictException.class);
        verifyNoInteractions(auditService);
    }

    @Test
    void create_errorDistintoDeUnicidad_noOcultaFallo() {
        when(slaConfigRepository.saveAndFlush(any(SlaConfig.class))).thenThrow(
                new DataIntegrityViolationException("storage failure", new SQLException("failure", "23514")));
        assertThatThrownBy(() -> slaService.create(new CreateSlaConfigRequest("Contrato", 4)))
                .isInstanceOf(DataIntegrityViolationException.class);
        verifyNoInteractions(auditService);
    }

    @Test
    void create_invalido_noPersiste() {
        for (CreateSlaConfigRequest invalid : List.of(new CreateSlaConfigRequest("  ", 1),
                new CreateSlaConfigRequest("x".repeat(101), 1), new CreateSlaConfigRequest("Contrato", 0),
                new CreateSlaConfigRequest("Contrato", Integer.MAX_VALUE))) {
            assertThatThrownBy(() -> slaService.create(invalid)).isInstanceOf(IllegalArgumentException.class);
        }
        verifyNoInteractions(slaConfigRepository, auditService);
    }

    @Test
    void calculateDeadline_generalExplicito_ganaSobreTitulo() {
        when(slaConfigRepository.findByTipoDocumentoIgnoreCase("General"))
                .thenReturn(Optional.of(new SlaConfig("General", 5)));
        Instant start = Instant.parse("2026-09-28T10:00:00Z");
        assertThat(slaService.calculateDeadline("General", "Contrato de Servicios", start))
                .isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 5));
        verify(slaConfigRepository, never()).findAll();
    }

    @Test
    void calculateDeadline_empate_esEstableIndependientementeDelOrden() {
        SlaConfig a = new SlaConfig("ABC", 2);
        SlaConfig b = new SlaConfig("XYZ", 4);
        when(slaConfigRepository.findAll()).thenReturn(List.of(b, a), List.of(a, b));
        Instant start = Instant.parse("2026-09-28T10:00:00Z");
        Instant expected = com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 2);
        assertThat(slaService.calculateDeadline("sin regla", "ABC XYZ", start)).isEqualTo(expected);
        assertThat(slaService.calculateDeadline("sin regla", "ABC XYZ", start)).isEqualTo(expected);
    }

    @Test
    void calculateDeadline_subcadenaMasLarga_gana() {
        when(slaConfigRepository.findAll()).thenReturn(List.of(new SlaConfig("Contrato", 5),
                new SlaConfig("Contrato de Servicios", 4)));
        Instant start = Instant.parse("2026-09-28T10:00:00Z");
        assertThat(slaService.calculateDeadline("otro", "Contrato de Servicios anual", start))
                .isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(start, 4));
    }

    @Test
    void calculateDeadline_sinInicio_usaRelojInyectado() {
        assertThat(slaService.calculateDeadline((com.capstone.sistema.flow.model.Solicitud) null, null))
                .isEqualTo(com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(
                        Instant.parse("2026-09-28T10:00:00Z"), 5));
    }
}
