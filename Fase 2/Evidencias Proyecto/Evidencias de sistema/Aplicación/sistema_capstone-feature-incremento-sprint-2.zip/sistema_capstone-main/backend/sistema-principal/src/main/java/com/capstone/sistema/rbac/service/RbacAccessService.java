package com.capstone.sistema.rbac.service;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.*;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class RbacAccessService {
    private static final String CACHE = RbacAccessService.class.getName();
    private final CurrentUserResolver resolver;
    private final JdbcTemplate jdbc;
    private final SolicitudRepository solicitudes;

    public RbacAccessService(CurrentUserResolver resolver, JdbcTemplate jdbc, SolicitudRepository solicitudes) {
        this.resolver = resolver; this.jdbc = jdbc; this.solicitudes = solicitudes;
    }

    public AccessContext context() {
        var attrs = RequestContextHolder.getRequestAttributes();
        if (attrs instanceof ServletRequestAttributes web) {
            Object existing = web.getRequest().getAttribute(CACHE);
            if (existing instanceof AccessContext context) return context;
            AccessContext context = forUser(resolver.resolveCurrentUser().orElseThrow(RbacException::denied));
            web.getRequest().setAttribute(CACHE, context);
            return context;
        }
        return forUser(resolver.resolveCurrentUser().orElseThrow(RbacException::denied));
    }

    public void clearContext() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes web) {
            web.getRequest().removeAttribute(CACHE);
        }
    }

    public AccessContext forUser(UserAccount user) {
        var identity = jdbc.queryForMap("select u.activo,u.jefatura_directa_id,u.version_acceso,a.id area_id from usuario u left join area a on a.id=u.area_id and a.activo=true where u.id=?", user.getId());
        Long area = (Long) identity.get("area_id");
        UUID manager = (UUID) identity.get("jefatura_directa_id");
        List<AreaItem> managed = jdbc.query("select id,nombre from area where administrador_id=? and activo=true order by id",
                (rs,n) -> new AreaItem(rs.getLong("id"),rs.getString("nombre")), user.getId());
        List<ContextRole> roles = new ArrayList<>(jdbc.query(
                "select r.id,r.nombre,r.nombre_visible from rol_flujo r join usuario_rol ur on ur.rol_id=r.id where ur.usuario_id=? and r.activo=true and r.nombre not in ('APPROVER','AREA_ADMIN') order by r.id",
                (rs,n) -> new ContextRole(rs.getLong("id"),rs.getString("nombre"),rs.getString("nombre_visible"),"EXPLICITO"), user.getId()));
        if (!managed.isEmpty()) roles.addAll(jdbc.query(
                "select id,nombre,nombre_visible from rol_flujo where nombre='AREA_ADMIN' and activo=true",
                (rs,n) -> new ContextRole(rs.getLong("id"),rs.getString("nombre"),rs.getString("nombre_visible"),"AREA")));
        Map<Permiso,Set<Alcance>> grants = new EnumMap<>(Permiso.class);
        for (ContextRole role : roles) {
            jdbc.query("select p.codigo,rp.alcance from rol_permiso rp join permiso p on p.id=rp.permiso_id where rp.rol_id=?",
                    rs -> { grants.computeIfAbsent(Permiso.valueOf(rs.getString("codigo")), k -> EnumSet.noneOf(Alcance.class))
                        .add(Alcance.valueOf(rs.getString("alcance"))); }, role.id());
        }
        boolean enabled = user.isEnabled() && Boolean.TRUE.equals(identity.get("activo"));
        boolean admin = enabled && roles.stream().anyMatch(r -> r.codigo().equals("ADMIN") && r.origen().equals("EXPLICITO"));
        if (!enabled) grants.clear();
        Set<UUID> ancestors = new HashSet<>();
        UUID parent = manager;
        boolean valid = true;
        while (parent != null) {
            if (parent.equals(user.getId()) || !ancestors.add(parent)) { valid = false; break; }
            List<UUID> next = jdbc.query("select jefatura_directa_id from usuario where id=?", (rs,n)->(UUID)rs.getObject(1),parent);
            if (next.isEmpty()) { valid = false; break; }
            parent = next.get(0);
        }
        Map<Permiso,Set<Alcance>> immutable = new EnumMap<>(Permiso.class);
        grants.forEach((p,s)->immutable.put(p,Set.copyOf(s)));
        return new AccessContext(user.getId(),area,manager,admin,Set.copyOf(ancestors),valid,List.copyOf(roles),
                List.copyOf(managed),Map.copyOf(immutable), ((Number)identity.get("version_acceso")).longValue(),
                jdbc.queryForObject("select version_politica from rbac_control where id=1",Long.class));
    }

    public Me me() {
        AccessContext c = context();
        return new Me(c.usuarioId(),c.areaId(),c.jefaturaDirectaId(),c.admin(),c.roles(),c.areasAdministradas(),
                c.permisos().entrySet().stream().sorted(Map.Entry.comparingByKey()).map(e->new Grant(e.getKey().name(),e.getValue().stream().sorted().toList())).toList(),
                c.versionAcceso(),c.versionPolitica());
    }

    public void require(Permiso permission) { if (!context().has(permission)) throw RbacException.denied(); }

    public Specification<Solicitud> visible(Permiso permission) { return visible(context(),permission); }
    public Specification<Solicitud> visible(AccessContext c, Permiso permission) {
        return visible(c, permission, null);
    }

    private Specification<Solicitud> visible(AccessContext c, Permiso permission, FlujoEtapa targetStage) {
        return (root,query,b) -> {
            Set<Alcance> scopes = c.scopes(permission);
            if (c.admin() && scopes.contains(Alcance.GLOBAL)) return b.conjunction();
            if (!c.jerarquiaValida() || scopes.isEmpty()) return b.disjunction();
            List<Predicate> permitted = new ArrayList<>();
            for (Alcance scope : scopes) {
                switch (scope) {
                    case PROPIAS -> permitted.add(b.equal(root.get("emisor").get("id"),c.usuarioId()));
                    case AREA -> { if (c.areaId()!=null) permitted.add(inAreas(root,b,Set.of(c.areaId()))); }
                    case EQUIPO_DIRECTO -> {
                        Set<Long> areas = new HashSet<>(c.managedAreas());
                        if (c.areaId()!=null) areas.add(c.areaId());
                        if (!areas.isEmpty()) permitted.add(b.and(inAreas(root,b,areas),
                                b.equal(root.join("emisor",JoinType.INNER).join("jefaturaDirecta",JoinType.LEFT).get("id"),c.usuarioId())));
                    }
                    case AREAS_ADMINISTRADAS -> { if (!c.managedAreas().isEmpty()) permitted.add(inAreas(root,b,c.managedAreas())); }
                    case ASIGNADAS -> {
                        var stage = query.subquery(Long.class);
                        var e = stage.from(FlujoEtapa.class);
                        stage.select(e.get("id")).where(b.equal(e.get("flujoDefinicion").get("id"),root.get("flujoDefinicion").get("id")),
                                assignedStage(e,b,c));
                        Predicate assigned = b.exists(stage);
                        if (targetStage!=null && assignedStage(targetStage,c)) assigned=b.or(assigned,
                                b.equal(root.get("flujoDefinicion").get("id"),targetStage.getFlujoDefinicion().getId()));
                        // La única excepción a la asignación explícita es el flujo base de una etapa.
                        if (c.areaId()!=null) assigned = b.or(assigned,baseReview(root,b,c.areaId()));
                        permitted.add(assigned);
                    }
                    case PARTICIPACION_AREA -> {
                        if (!c.managedAreas().isEmpty()) {
                            var stage = query.subquery(Long.class);
                            var e = stage.from(FlujoEtapa.class);
                            var reviewer = e.join("revisor",JoinType.LEFT);
                            var area = reviewer.join("area",JoinType.LEFT);
                            var department = e.join("flujoDefinicion").join("area",JoinType.LEFT);
                            var role = e.join("rolRevisor",JoinType.LEFT);
                            stage.select(e.get("id")).where(b.equal(e.get("flujoDefinicion").get("id"),root.get("flujoDefinicion").get("id")),
                                    b.or(b.and(b.equal(e.get("tipoAsignacion"),TipoAsignacionRevisor.USUARIO),
                                            b.isTrue(reviewer.get("enabled")),b.isTrue(area.get("activo")),area.get("id").in(c.managedAreas())),
                                         b.and(b.equal(e.get("tipoAsignacion"),TipoAsignacionRevisor.ROL_DEPARTAMENTAL),
                                            b.isTrue(role.get("activo")),b.isTrue(department.get("activo")),department.get("id").in(c.managedAreas()))));
                            permitted.add(b.exists(stage));
                        }
                    }
                    case GLOBAL -> { /* GLOBAL nunca autoriza a un rol distinto de ADMIN. */ }
                }
            }
            Predicate granted = permitted.isEmpty()? b.disjunction():b.or(permitted.toArray(Predicate[]::new));
            if (!c.superiores().isEmpty()) granted = b.and(granted,b.not(root.get("emisor").get("id").in(c.superiores())));
            if (isDecision(permission)) {
                Predicate current;
                if (targetStage == null) {
                    current = assignedStage(root.join("flujoEtapa",JoinType.INNER),b,c);
                    if (c.areaId()!=null) current=b.or(current,baseReview(root,b,c.areaId()));
                } else {
                    current = assignedStage(targetStage,c)
                            ? b.equal(root.get("flujoDefinicion").get("id"),targetStage.getFlujoDefinicion().getId())
                            : b.disjunction();
                    if (com.capstone.sistema.flow.service.FlujoReviewerResolver.isDynamicBase(targetStage) && c.areaId()!=null) current = baseReview(root,b,c.areaId());
                }
                granted=b.and(granted,current,b.notEqual(root.get("emisor").get("id"),c.usuarioId()));
            }
            return granted;
        };
    }
    private static Predicate assignedStage(From<?,FlujoEtapa> stage, CriteriaBuilder b, AccessContext c) {
        var user=stage.join("revisor",JoinType.LEFT);
        var role=stage.join("rolRevisor",JoinType.LEFT);
        var area=stage.join("flujoDefinicion").join("area",JoinType.LEFT);
        Predicate direct=b.and(b.equal(stage.get("tipoAsignacion"),TipoAsignacionRevisor.USUARIO),
                b.equal(user.get("id"),c.usuarioId()),b.isTrue(user.get("enabled")));
        var roleIds=c.roles().stream().map(ContextRole::id).toList();
        Predicate departmental=c.areaId()==null || roleIds.isEmpty()?b.disjunction():b.and(
                b.equal(stage.get("tipoAsignacion"),TipoAsignacionRevisor.ROL_DEPARTAMENTAL),
                b.isTrue(role.get("activo")),role.get("id").in(roleIds),b.isTrue(area.get("activo")),b.equal(area.get("id"),c.areaId()));
        return b.or(direct,departmental);
    }
    private static boolean assignedStage(FlujoEtapa stage, AccessContext c) {
        if (stage.getTipoAsignacion()==TipoAsignacionRevisor.USUARIO) return stage.getRevisor()!=null
                && stage.getRevisor().isEnabled() && stage.getRevisor().getId().equals(c.usuarioId());
        return stage.getRolRevisor()!=null && stage.getFlujoDefinicion().getArea()!=null
                && Objects.equals(c.areaId(),stage.getFlujoDefinicion().getArea().getId())
                && c.roles().stream().anyMatch(r->r.id().equals(stage.getRolRevisor().getId()));
    }
    private static Predicate inAreas(Root<Solicitud> root, CriteriaBuilder b, Set<Long> ids) {
        return b.or(root.get("areaOrigenId").in(ids),root.get("areaFlujoId").in(ids));
    }
    private static Predicate baseReview(Root<Solicitud> root, CriteriaBuilder b, Long area) {
        var stage = root.join("flujoEtapa",JoinType.INNER);
        return b.and(b.equal(root.get("flujoDefinicion").get("id"),1L),
                b.equal(root.get("flujoDefinicion").get("nombre"),"Revisión Simple"),
                b.isNull(root.get("flujoDefinicion").get("area")),b.equal(stage.get("orden"),1),
                b.equal(stage.get("tipoAsignacion"),TipoAsignacionRevisor.USUARIO),b.isNull(stage.get("rolRevisor")),
                b.isNull(stage.get("revisor")), b.equal(root.get("areaOrigenId"),area));
    }
    public static boolean isDecision(Permiso p) {
        return p==Permiso.SOLICITUD_APROBAR || p==Permiso.SOLICITUD_RECHAZAR || p==Permiso.SOLICITUD_PEDIR_CORRECCION;
    }
    public boolean can(UUID id, Permiso permission) {
        return solicitudes.count(visible(permission).and(visible(Permiso.SOLICITUD_CONSULTAR))
                .and((r,q,b)->b.equal(r.get("id"),id)))>0;
    }
    public Solicitud readable(UUID id) {
        return solicitudes.findOne(visible(Permiso.SOLICITUD_CONSULTAR).and((r,q,b)->b.equal(r.get("id"),id)))
                .orElseThrow(RbacException::missing);
    }
    public Solicitud authorize(UUID id, Permiso permission) {
        Solicitud request=readable(id);
        if (!can(id,permission)) throw RbacException.denied();
        return request;
    }
    public void manageFlow(Long areaId) {
        AccessContext c = context();
        if (!c.has(Permiso.FLUJO_GESTIONAR) || !(c.admin() || (areaId!=null && c.managedAreas().contains(areaId)
                && c.scopes(Permiso.FLUJO_GESTIONAR).contains(Alcance.AREAS_ADMINISTRADAS)))) throw RbacException.denied();
    }
    public boolean canManageFlow(Long areaId) {
        try { manageFlow(areaId); return true; } catch (RbacException e) { return false; }
    }
    public boolean canEmitFlow(FlujoDefinicion flow) {
        AccessContext c=context();
        if (!c.has(Permiso.SOLICITUD_CREAR)) return false;
        if (c.admin()) return flow.isActivo();
        if (c.areaId()==null || !flow.isActivo()) return false;
        if (flow.getId()==1L && "Revisión Simple".equals(flow.getNombre()) && flow.getArea()==null) return true;
        return flow.isCompleto() && flow.getArea()!=null && flow.getArea().isActivo() && c.areaId().equals(flow.getArea().getId());
    }
    public boolean eligibleReviewer(UserAccount user) {
        if (!user.isEnabled()) return false;
        AccessContext c=forUser(user);
        Set<Alcance> readScopes=c.scopes(Permiso.SOLICITUD_CONSULTAR);
        return c.jerarquiaValida() && (readScopes.contains(Alcance.ASIGNADAS) || (c.admin() && readScopes.contains(Alcance.GLOBAL))) && c.has(Permiso.REVISION_CONSULTAR)
                && c.has(Permiso.SOLICITUD_APROBAR) && c.has(Permiso.SOLICITUD_RECHAZAR) && c.has(Permiso.SOLICITUD_PEDIR_CORRECCION);
    }

    public void requireFlowEmissionScope(FlujoDefinicion flow) {
        AccessContext c=context();
        if (!c.has(Permiso.SOLICITUD_CREAR)) throw RbacException.denied();
        if (c.admin()) return;
        if (c.areaId()==null) throw RbacException.denied();
        boolean base=Long.valueOf(1).equals(flow.getId()) && "Revisión Simple".equals(flow.getNombre()) && flow.getArea()==null;
        if (!base && (flow.getArea()==null || !c.areaId().equals(flow.getArea().getId()))) throw RbacException.denied();
    }

    /** Evalúa una responsabilidad futura sin modificar la etapa activa de la solicitud. */
    public boolean canOperateAtStage(UserAccount user, Solicitud request, FlujoEtapa stage) {
        if (!user.isEnabled() || !request.getFlujoDefinicion().getId().equals(stage.getFlujoDefinicion().getId())) return false;
        AccessContext c = forUser(user);
        for (Permiso permission : List.of(Permiso.REVISION_CONSULTAR, Permiso.SOLICITUD_APROBAR,
                Permiso.SOLICITUD_RECHAZAR, Permiso.SOLICITUD_PEDIR_CORRECCION)) {
            if (solicitudes.count(visible(c, permission, stage).and(visible(c, Permiso.SOLICITUD_CONSULTAR, stage))
                    .and((r,q,b)->b.equal(r.get("id"),request.getId()))) == 0) return false;
        }
        return true;
    }

    public boolean canRead(UserAccount user, UUID requestId) {
        return user.isEnabled() && solicitudes.count(visible(forUser(user),Permiso.SOLICITUD_CONSULTAR)
                .and((r,q,b)->b.equal(r.get("id"),requestId)))>0;
    }
}

