package com.capstone.sistema.users.password;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.ChangePasswordRequest;
import com.capstone.sistema.users.exception.PasswordChangeException;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.capstone.sistema.users.service.KeycloakLockStatusClient;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.ClientsResource;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class PasswordChangeOperationsTest {
    private static final String KEYCLOAK_USER_ID = "test-keycloak-user";
    private static final ChangePasswordRequest REQUEST =
            new ChangePasswordRequest("incorrect-test-password", "NewTestPassword2026!");

    private HttpServer provider;
    private volatile int providerStatus = 401;
    private volatile String providerBody = "{\"error\":\"invalid_grant\",\"error_description\":\"Invalid user credentials\"}";
    private PasswordChangeOperations operations;
    private KeycloakLockStatusClient lockStatus;
    private UserResource remoteAccount;
    private AuditService audit;

    @BeforeEach
    void setUp() throws IOException {
        // Exercise the real Keycloak/JAX-RS client and streamed error body, not a pre-buffered mock Response.
        provider = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        provider.createContext("/realms/test-realm/protocol/openid-connect/token", exchange -> {
            try {
                exchange.getRequestBody().close();
                byte[] body = providerBody.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(providerStatus, body.length);
                exchange.getResponseBody().write(body);
            } finally {
                exchange.close();
            }
        });
        provider.start();

        Keycloak admin = mock(Keycloak.class);
        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);
        ClientsResource clients = mock(ClientsResource.class);
        remoteAccount = mock(UserResource.class);
        CurrentUserResolver identity = mock(CurrentUserResolver.class);
        lockStatus = mock(KeycloakLockStatusClient.class);
        audit = mock(AuditService.class);
        UserAccountRepository accounts = mock(UserAccountRepository.class);
        UserAccount account = mock(UserAccount.class);
        when(account.getId()).thenReturn(UUID.randomUUID());
        when(account.getKeycloakUserId()).thenReturn(KEYCLOAK_USER_ID);
        when(identity.resolveCurrentUser()).thenReturn(Optional.of(account));
        when(admin.realm("test-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.get(KEYCLOAK_USER_ID)).thenReturn(remoteAccount);
        UserRepresentation remote = new UserRepresentation();
        remote.setId(KEYCLOAK_USER_ID);
        remote.setEnabled(true);
        remote.setUsername("test-user");
        when(remoteAccount.toRepresentation()).thenReturn(remote);
        when(realm.toRepresentation()).thenReturn(new RealmRepresentation());
        when(realm.clients()).thenReturn(clients);
        ClientRepresentation client = new ClientRepresentation();
        client.setEnabled(true);
        client.setPublicClient(true);
        client.setDirectAccessGrantsEnabled(true);
        when(clients.findByClientId("test-client")).thenReturn(List.of(client));
        KeycloakAdminProperties properties = new KeycloakAdminProperties(
                "http://127.0.0.1:" + provider.getAddress().getPort(), "master", "test-realm",
                "admin-cli", "unused-test-admin", "unused-test-secret", "test-client");
        operations = new PasswordChangeOperations(admin, properties, identity, lockStatus, audit, accounts);
    }

    @AfterEach
    void tearDown() {
        if (provider != null) provider.stop(0);
    }

    @ParameterizedTest
    @ValueSource(ints = {400, 401})
    void incorrectCurrentPasswordPreservesProviderRejectionBeforeClientCloses(int status) {
        providerStatus = status;
        PasswordChangeException failure = assertThrows(PasswordChangeException.class, () -> operations.change(REQUEST));

        assertThat(failure.status()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(failure.code()).isEqualTo("CURRENT_PASSWORD_INVALID");
        assertThat(failure.getMessage()).isEqualTo("La contraseña actual es incorrecta, inténtelo nuevamente.");
        assertThat(failure.invalidFields()).isEqualTo(Map.of("currentPassword", failure.getMessage()));
        assertNoPasswordWrite(failure);

        // A rejection must also release the in-flight guard for the same account.
        PasswordChangeException repeated = assertThrows(PasswordChangeException.class, () -> operations.change(REQUEST));
        assertThat(repeated.code()).isEqualTo("CURRENT_PASSWORD_INVALID");
    }

    @Test
    void accountLockedDuringCredentialVerificationRemainsRateLimited() {
        when(lockStatus.isTemporarilyLocked(KEYCLOAK_USER_ID)).thenReturn(false, true);

        PasswordChangeException failure = assertThrows(PasswordChangeException.class, () -> operations.change(REQUEST));

        assertThat(failure.status()).isEqualTo(HttpStatus.TOO_MANY_REQUESTS);
        assertThat(failure.code()).isEqualTo("PASSWORD_ACCOUNT_LOCKED");
        assertNoPasswordWrite(failure);
    }

    @Test
    void incompleteAccountRemainsAnAdditionalVerificationRequirement() {
        providerBody = "{\"error\":\"invalid_grant\",\"error_description\":\"Account is not fully set up\"}";

        PasswordChangeException failure = assertThrows(PasswordChangeException.class, () -> operations.change(REQUEST));

        assertThat(failure.status()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(failure.code()).isEqualTo("PASSWORD_CHANGE_REAUTH_REQUIRED");
        assertNoPasswordWrite(failure);
    }

    @ParameterizedTest
    @MethodSource("unavailableProviderResponses")
    void otherProviderErrorsAreNotClassifiedAsIncorrectPassword(int status, String body) {
        providerStatus = status;
        providerBody = body;

        PasswordChangeException failure = assertThrows(PasswordChangeException.class, () -> operations.change(REQUEST));

        assertThat(failure.status()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(failure.code()).isEqualTo("IDENTITY_PROVIDER_UNAVAILABLE");
        assertNoPasswordWrite(failure);
    }

    static Stream<Arguments> unavailableProviderResponses() {
        return Stream.of(
                Arguments.of(400, "{\"error\":\"invalid_client\"}"),
                Arguments.of(400, "malformed-json"),
                Arguments.of(400, "null"),
                Arguments.of(401, "{\"error\":\"invalid_client\"}"),
                Arguments.of(500, "{\"error\":\"server_error\"}"));
    }

    private void assertNoPasswordWrite(PasswordChangeException failure) {
        verify(remoteAccount, never()).resetPassword(any(CredentialRepresentation.class));
        verifyNoInteractions(audit);
        assertThat(failure.getMessage()).doesNotContain(REQUEST.currentPassword(), REQUEST.newPassword());
    }
}
