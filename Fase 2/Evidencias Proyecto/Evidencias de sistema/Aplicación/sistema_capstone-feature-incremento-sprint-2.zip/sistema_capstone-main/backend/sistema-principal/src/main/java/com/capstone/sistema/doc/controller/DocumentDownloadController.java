package com.capstone.sistema.doc.controller;

import com.capstone.sistema.doc.service.DocumentDownloadResolver;
import com.capstone.sistema.doc.service.DocumentDownloadWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.UUID;

@RestController
@PreAuthorize("isAuthenticated()")
public class DocumentDownloadController {
    private final DocumentDownloadResolver resolver;
    private final DocumentDownloadWriter writer;

    public DocumentDownloadController(DocumentDownloadResolver resolver, DocumentDownloadWriter writer) {
        this.resolver = resolver;
        this.writer = writer;
    }

    @GetMapping({"/api/documents/{id}/download", "/api/docs/{id}/download"})
    public void download(@PathVariable UUID id, HttpServletResponse response) throws IOException {
        writer.write(resolver.byId(id), response);
    }

    @GetMapping("/api/solicitudes/{id}/documento/descargar")
    public void current(@PathVariable UUID id, HttpServletResponse response) throws IOException {
        writer.write(resolver.current(id), response);
    }

    @GetMapping("/api/doc/download/{filename}")
    public void legacy(@PathVariable String filename, HttpServletResponse response) throws IOException {
        writer.write(resolver.byKey(filename), response);
    }
}
