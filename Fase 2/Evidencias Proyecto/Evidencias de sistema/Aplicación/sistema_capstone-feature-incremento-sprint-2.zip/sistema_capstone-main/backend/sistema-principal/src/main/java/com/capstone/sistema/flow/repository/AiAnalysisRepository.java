package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.AiAnalysis;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AiAnalysisRepository extends JpaRepository<AiAnalysis, UUID> {

    Optional<AiAnalysis> findFirstBySolicitud_IdOrderByCreatedAtDesc(UUID solicitudId);

    Optional<AiAnalysis> findFirstBySolicitud_IdAndDocumento_IdOrderByCreatedAtDesc(UUID solicitudId, UUID documentoId);

    List<AiAnalysis> findAllBySolicitud_IdOrderByCreatedAtDesc(UUID solicitudId);
}
