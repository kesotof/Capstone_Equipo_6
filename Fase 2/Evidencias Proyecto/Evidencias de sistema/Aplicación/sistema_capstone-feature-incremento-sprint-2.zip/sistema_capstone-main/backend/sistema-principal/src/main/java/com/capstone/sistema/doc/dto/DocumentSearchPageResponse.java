package com.capstone.sistema.doc.dto;

import java.util.List;

public record DocumentSearchPageResponse(List<DocumentSearchItemResponse> contenido, int pagina, int tamanio,
                                         long totalElementos, int totalPaginas, boolean primera, boolean ultima,
                                         String orden) {
    public DocumentSearchPageResponse {
        contenido = List.copyOf(contenido);
    }
}
