package com.capstone.sistema.doc.dto;

import java.util.UUID;

/** Metadata interna autorizada; nunca se serializa hacia el cliente. */
public record DocumentDownloadTarget(UUID id, UUID solicitudId, String nombreArchivo, String contentType,
                                     String storageKey, Long sizeBytes, int version) {
}
