package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public record DashboardSummaryResponse(Totals totales, List<AreaSummary> porArea,
        List<AreaOption> catalogoAreas, boolean puedeFiltrarPorArea, Long areaId, boolean sinArea,
        List<DailyCount> tendencias, String zonaHoraria, Instant consultadoEn) {
    public record Totals(long pendientes, long aprobadas, long rechazadas, long enCorreccion, long otros, long total) {}
    public record AreaSummary(Long areaId, String nombre, Boolean activa, Totals totales) {}
    public record AreaOption(Long id, String nombre, boolean activa) {}
    public record DailyCount(LocalDate fecha, long emitidas) {}
}
