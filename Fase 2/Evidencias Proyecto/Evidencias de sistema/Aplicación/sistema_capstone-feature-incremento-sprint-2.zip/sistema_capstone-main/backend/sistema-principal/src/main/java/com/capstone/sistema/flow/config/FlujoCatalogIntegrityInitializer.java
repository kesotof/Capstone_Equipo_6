package com.capstone.sistema.flow.config;

import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.service.FlujoIntegrityService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/** Reconcilia una sola vez configuraciones legacy; conserva solicitudes e historial. */
@Component
@Order(10)
public class FlujoCatalogIntegrityInitializer implements ApplicationRunner {
    private static final Logger log=LoggerFactory.getLogger(FlujoCatalogIntegrityInitializer.class);
    private final FlujoDefinicionRepository definitions;
    private final FlujoIntegrityService integrity;
    private final RbacManagementService security;
    private final JdbcTemplate jdbc;

    public FlujoCatalogIntegrityInitializer(FlujoDefinicionRepository definitions, FlujoIntegrityService integrity,
                                           RbacManagementService security, JdbcTemplate jdbc) {
        this.definitions=definitions; this.integrity=integrity; this.security=security; this.jdbc=jdbc;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        security.lockPolicy();
        Integer version=jdbc.queryForObject("select version_migracion from flow_control where id=1 for update",Integer.class);
        if (version!=null && version>=1) return;
        for (FlujoDefinicion flow:definitions.findAll()) {
            boolean complete=integrity.complete(flow);
            flow.setCompleto(complete);
            boolean activeArea=flow.getArea()==null || flow.getArea().isActivo();
            if ((!complete || !activeArea) && flow.isActivo()) {
                flow.setActivo(false);
                log.warn("Flujo legacy {} desactivado por configuración o área inválida; etapas y solicitudes conservadas.",flow.getId());
            }
        }
        definitions.flush();
        jdbc.update("update flow_control set version_migracion=1 where id=1");
        log.info("Catálogo de flujos reconciliado para ejecución secuencial; eventos históricos sin reconstrucción.");
    }
}
