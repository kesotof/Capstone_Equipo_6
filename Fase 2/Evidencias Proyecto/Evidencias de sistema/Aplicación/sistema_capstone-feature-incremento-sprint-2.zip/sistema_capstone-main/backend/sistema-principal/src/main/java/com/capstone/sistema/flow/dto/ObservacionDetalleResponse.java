package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record ObservacionDetalleResponse(
        Long id,
        String contenido,
        boolean resuelta,
        String usuarioNombre,
        Instant createdAt,
        Long transicionId,
        EtapaSolicitudResponse etapa
) {
}
