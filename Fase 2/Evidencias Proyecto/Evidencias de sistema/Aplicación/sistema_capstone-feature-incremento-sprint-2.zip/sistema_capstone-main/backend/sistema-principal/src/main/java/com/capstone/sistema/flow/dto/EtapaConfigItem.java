package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.TipoAccionEtapa;
import com.capstone.sistema.flow.model.TipoAsignacionRevisor;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public record EtapaConfigItem(
        @NotNull(message = "El orden de la etapa es obligatorio")
        @Min(value = 1, message = "El orden debe ser mayor o igual a 1")
        Integer orden,

        @NotBlank(message = "El nombre de la etapa es obligatorio")
        @Size(max = 150, message = "El nombre no puede exceder los 150 caracteres")
        String nombre,

        UUID revisorId,
        TipoAccionEtapa tipoAccion,
        TipoAsignacionRevisor tipoAsignacion,
        Long rolRevisorId
) {
    public EtapaConfigItem {
        if (tipoAccion == null) tipoAccion = TipoAccionEtapa.REVISION;
        if (tipoAsignacion == null) tipoAsignacion = TipoAsignacionRevisor.USUARIO;
    }
    public EtapaConfigItem(Integer orden, String nombre, UUID revisorId, TipoAccionEtapa tipoAccion) {
        this(orden, nombre, revisorId, tipoAccion, TipoAsignacionRevisor.USUARIO, null);
    }
    public EtapaConfigItem(Integer orden, String nombre, UUID revisorId) {
        this(orden, nombre, revisorId, TipoAccionEtapa.REVISION);
    }
}
