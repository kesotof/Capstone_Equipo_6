package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.service.FlujoConfigService;
import com.capstone.sistema.users.repository.AreaRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(FlujoConfigController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class FlujoConfigControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private FlujoConfigService flujoConfigService;

    @MockBean
    private AreaRepository areaRepository;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("POST /api/flujos crea flujo y responde 201 Created")
    void crearFlujo_valido_retorna201Created() throws Exception {
        CrearFlujoRequest request = new CrearFlujoRequest("Flujo Facturación", "Aprobación de facturas", 1L);
        FlujoResponse response = new FlujoResponse(
                5L, "Flujo Facturación", "Aprobación de facturas", 1L, "Finanzas",
                true, false, List.of(), Instant.now(), Instant.now()
        );

        when(flujoConfigService.crearFlujo(any(CrearFlujoRequest.class))).thenReturn(response);

        mockMvc.perform(post("/api/flujos")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", "/api/flujos/5"))
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.nombre").value("Flujo Facturación"))
                .andExpect(jsonPath("$.areaId").value(1))
                .andExpect(jsonPath("$.areaNombre").value("Finanzas"))
                .andExpect(jsonPath("$.completo").value(false));

        verify(flujoConfigService).crearFlujo(any(CrearFlujoRequest.class));
    }

    @Test
    @DisplayName("GET /api/flujos retorna lista de flujos y 200 OK")
    void listarFlujos_retornaLista200Ok() throws Exception {
        FlujoResponse response = new FlujoResponse(
                1L, "Flujo Compras", "Compras generales", null, null,
                true, true, List.of(), Instant.now(), Instant.now()
        );

        when(flujoConfigService.listarFlujos(eq(null), eq(null))).thenReturn(List.of(response));

        mockMvc.perform(get("/api/flujos")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Flujo Compras"))
                .andExpect(jsonPath("$[0].completo").value(true));
    }

    @Test
    @DisplayName("GET /api/flujos/{id} retorna detalle con etapas y 200 OK")
    void obtenerFlujo_retornaDetalleConEtapas200Ok() throws Exception {
        UUID revId = UUID.randomUUID();
        FlujoEtapaResponse etapa = new FlujoEtapaResponse(
                10L, 1, "Revisión 1", revId, "Juan Revisor", "juan@capstone.local"
        );
        FlujoResponse response = new FlujoResponse(
                1L, "Flujo Compras", "Compras", 2L, "Operaciones",
                true, true, List.of(etapa), Instant.now(), Instant.now()
        );

        when(flujoConfigService.obtenerFlujo(1L)).thenReturn(response);

        mockMvc.perform(get("/api/flujos/1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.etapas[0].orden").value(1))
                .andExpect(jsonPath("$.etapas[0].revisorEmail").value("juan@capstone.local"));
    }

    @Test
    @DisplayName("PUT /api/flujos/{id}/etapas configura etapas atómicamente y responde 200 OK")
    void configurarEtapas_valido_retorna200Ok() throws Exception {
        UUID revId = UUID.randomUUID();
        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Etapa Inicial", revId)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        FlujoEtapaResponse etapa = new FlujoEtapaResponse(
                10L, 1, "Etapa Inicial", revId, "Juan Revisor", "juan@capstone.local"
        );
        FlujoResponse response = new FlujoResponse(
                1L, "Flujo Modificado", "Desc", null, null,
                true, true, List.of(etapa), Instant.now(), Instant.now()
        );

        when(flujoConfigService.configurarEtapas(eq(1L), any(ConfigurarEtapasRequest.class))).thenReturn(response);

        mockMvc.perform(put("/api/flujos/1/etapas")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.completo").value(true))
                .andExpect(jsonPath("$.etapas[0].nombre").value("Etapa Inicial"));

        verify(flujoConfigService).configurarEtapas(eq(1L), any(ConfigurarEtapasRequest.class));
    }

    @Test
    @DisplayName("DELETE /api/flujos/{id} responde 204 No Content")
    void eliminarFlujo_retorna204NoContent() throws Exception {
        mockMvc.perform(delete("/api/flujos/1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isNoContent());

        verify(flujoConfigService).eliminarFlujo(1L);
    }

    @Test
    @DisplayName("POST /api/flujos con nombre en blanco responde 400 Bad Request")
    void crearFlujo_conNombreEnBlanco_retorna400BadRequest() throws Exception {
        CrearFlujoRequest request = new CrearFlujoRequest("", "Descripción", 1L);

        mockMvc.perform(post("/api/flujos")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"))
                .andExpect(jsonPath("$.invalidFields.nombre").exists());
    }

    @Test
    @DisplayName("POST /api/flujos con JSON malformado responde 400 Bad Request (no 500)")
    void crearFlujo_conJsonMalformado_retorna400BadRequest() throws Exception {
        String jsonMalformado = "{\"nombre\": \"Flujo\", \"areaId\": \"invalido\"}";

        mockMvc.perform(post("/api/flujos")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonMalformado))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Cuerpo de solicitud inválido"));
    }

    @Test
    @DisplayName("PUT /api/flujos/{id}/etapas con lista vacía responde 400 Bad Request")
    void configurarEtapas_conListaVacia_retorna400BadRequest() throws Exception {
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(List.of());

        mockMvc.perform(put("/api/flujos/1/etapas")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"))
                .andExpect(jsonPath("$.invalidFields.etapas").exists());
    }

    @Test
    @DisplayName("PUT /api/flujos/{id}/etapas con orden inválido (<= 0) responde 400 Bad Request")
    void configurarEtapas_conOrdenInvalido_retorna400BadRequest() throws Exception {
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(List.of(
                new EtapaConfigItem(0, "Etapa 0", null)
        ));

        mockMvc.perform(put("/api/flujos/1/etapas")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"));
    }

    @Test
    @DisplayName("GET /api/flujos/{id} con id no numérico responde 400 Bad Request (no 500)")
    void obtenerFlujo_conIdInvalido_retorna400BadRequest() throws Exception {
        mockMvc.perform(get("/api/flujos/not-a-number")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Parámetro inválido"));
    }

    @Test
    @DisplayName("GET /api/flujos/{id} inexistente responde 404 Not Found")
    void obtenerFlujo_inexistente_retorna404NotFound() throws Exception {
        when(flujoConfigService.obtenerFlujo(999L))
                .thenThrow(new com.capstone.sistema.flow.exception.FlujoNotFoundException("Flujo no encontrado"));

        mockMvc.perform(get("/api/flujos/999")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.title").value("Flujo No Encontrado"));
    }
}
