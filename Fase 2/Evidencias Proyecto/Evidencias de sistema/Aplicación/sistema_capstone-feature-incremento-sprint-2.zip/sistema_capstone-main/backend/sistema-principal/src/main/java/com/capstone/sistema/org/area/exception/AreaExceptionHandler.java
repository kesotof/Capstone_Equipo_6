package com.capstone.sistema.org.area.exception;

import com.capstone.sistema.org.area.controller.AreaController;
import com.capstone.sistema.users.repository.AreaRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.net.URI;
import java.time.Instant;
import java.util.Map;
import java.util.LinkedHashMap;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(assignableTypes = AreaController.class)
public class AreaExceptionHandler {

    private final AreaRepository areaRepository;

    public AreaExceptionHandler(@org.springframework.beans.factory.annotation.Autowired(required = false) AreaRepository areaRepository) {
        this.areaRepository = areaRepository;
    }

    @ExceptionHandler(AreaException.class)
    public ProblemDetail handleArea(AreaException exception, HttpServletRequest request) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(exception.getStatus(), exception.getMessage());
        problem.setTitle(exception.getTitle());
        problem.setProperty("codigo", exception.getCodigo());
        exception.getProperties().forEach(problem::setProperty);
        problem.setInstance(URI.create(request.getRequestURI()));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleParameter(MethodArgumentTypeMismatchException exception,
                                         HttpServletRequest request) {
        return handleArea(AreaException.invalidField(exception.getName(),
                "El parámetro tiene un formato inválido."), request);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(MethodArgumentNotValidException exception,
                                         HttpServletRequest request) {
        Map<String, String> fields = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error ->
                fields.putIfAbsent(error.getField(), error.getDefaultMessage()));
        return handleArea(new AreaException(HttpStatus.BAD_REQUEST, "AREA_DATOS_INVALIDOS",
                "Datos de área inválidos", "Revisa los campos enviados e inténtalo nuevamente.",
                Map.of("invalidFields", fields)), request);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ProblemDetail handleBody(HttpMessageNotReadableException exception, HttpServletRequest request) {
        return handleArea(new AreaException(HttpStatus.BAD_REQUEST, "AREA_DATOS_INVALIDOS",
                "Datos de área inválidos", "Envía un cuerpo JSON válido con los tipos de datos indicados.",
                Map.of()), request);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ProblemDetail handleIntegrity(DataIntegrityViolationException exception, HttpServletRequest request) {
        for (Throwable cause = exception; cause != null; cause = cause.getCause()) {
            if (cause instanceof ConstraintViolationException violation
                    && "uq_area_nombre_normalizado".equals(violation.getConstraintName())) {
                return handleArea(AreaException.duplicateName(), request);
            }
        }
        // Las demás restricciones requieren diagnóstico; no son necesariamente nombres duplicados.
        throw exception;
    }

    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
    public ProblemDetail handleConcurrentWrite(ObjectOptimisticLockingFailureException exception,
                                              HttpServletRequest request) {
        Map<String, Object> properties = new LinkedHashMap<>();
        // La transacción fallida ya fue revertida antes de entrar al advice.
        if (areaRepository != null && exception.getIdentifier() instanceof Long id) {
            areaRepository.findById(id).ifPresent(area -> properties.put("versionActual", area.getVersion()));
        }
        return handleArea(new AreaException(HttpStatus.CONFLICT, "AREA_MODIFICADA", "Área modificada",
                "El área cambió durante la operación. Recarga sus datos antes de editarla.", properties), request);
    }
}
