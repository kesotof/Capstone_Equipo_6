package com.capstone.sistema.flow.config;

import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.model.AccionUsuario;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Transicion;
import com.capstone.sistema.flow.repository.AccionUsuarioRepository;
import com.capstone.sistema.flow.repository.EstadoSolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.TransicionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.core.annotation.Order;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import javax.sql.DataSource;

/** Garantiza los catálogos mínimos para operar el flujo documental base. */
@Component
@Order(0)
public class DefaultFlowCatalogInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DefaultFlowCatalogInitializer.class);
    private static final String FLOW_NAME = "Revisión Simple";

    private final FlujoDefinicionRepository flujoDefinicionRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final EstadoSolicitudRepository estadoSolicitudRepository;
    private final AccionUsuarioRepository accionUsuarioRepository;
    private final TransicionRepository transicionRepository;
    private final FormatoDocumentoRepository formatoDocumentoRepository;
    private final DataSource dataSource;

    public DefaultFlowCatalogInitializer(
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionUsuarioRepository accionUsuarioRepository,
            TransicionRepository transicionRepository,
            FormatoDocumentoRepository formatoDocumentoRepository,
            DataSource dataSource
    ) {
        this.flujoDefinicionRepository = flujoDefinicionRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.estadoSolicitudRepository = estadoSolicitudRepository;
        this.accionUsuarioRepository = accionUsuarioRepository;
        this.transicionRepository = transicionRepository;
        this.formatoDocumentoRepository = formatoDocumentoRepository;
        this.dataSource = dataSource;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        EstadoSolicitud pendienteRevision = getOrCreateEstado("PENDIENTE_REVISION");
        EstadoSolicitud correccionRequerida = getOrCreateEstado("CORRECCION_REQUERIDA");
        EstadoSolicitud aprobado = getOrCreateEstado("APROBADO");
        EstadoSolicitud rechazado = getOrCreateEstado("RECHAZADO");

        AccionUsuario crear = getOrCreateAccion("CREAR");
        AccionUsuario aprobar = getOrCreateAccion("APROBAR");
        AccionUsuario rechazar = getOrCreateAccion("RECHAZAR");
        AccionUsuario pedirCorreccion = getOrCreateAccion("PEDIR_CORRECCION");
        AccionUsuario reenviar = getOrCreateAccion("REENVIAR");

        for (String formato : new String[]{"pdf", "docx", "doc", "xml", "txt"}) {
            formatoDocumentoRepository.findByTipoIgnoreCase(formato)
                    .orElseGet(() -> formatoDocumentoRepository.save(new FormatoDocumento(formato)));
        }

        var baseSeed = new ResourceDatabasePopulator(new ClassPathResource("db/base-flow-seed.sql"));
        baseSeed.setSeparator("^^^ END OF SCRIPT ^^^");
        baseSeed.execute(dataSource);
        FlujoDefinicion flujo = flujoDefinicionRepository.findByNombreIgnoreCase(FLOW_NAME)
                .orElseThrow(() -> new IllegalStateException(
                        "Catálogo base inconsistente: ID 1 ocupado por otro flujo. No se modificaron sus referencias."));

        if (!Long.valueOf(1).equals(flujo.getId()) || !FLOW_NAME.equals(flujo.getNombre()) || flujo.getArea()!=null) {
            throw new IllegalStateException("Catálogo base inconsistente: Revisión Simple debe tener ID 1 y área general. Corregir el catálogo sin reasignar solicitudes históricas.");
        }

        flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(flujo.getId(), 1)
                .orElseGet(() -> flujoEtapaRepository.save(new FlujoEtapa(flujo, 1, "Revisión")));

        var stages=flujoEtapaRepository.findByFlujoDefinicion_IdOrderByOrdenAsc(flujo.getId());
        if (stages.size()!=1 || stages.get(0).getRevisor()!=null
                || stages.get(0).getRolRevisor()!=null
                || stages.get(0).getTipoAsignacion()!=com.capstone.sistema.flow.model.TipoAsignacionRevisor.USUARIO
                || stages.get(0).getTipoAccion()!=com.capstone.sistema.flow.model.TipoAccionEtapa.REVISION) {
            throw new IllegalStateException("Catálogo base inconsistente: Revisión Simple debe conservar una etapa de revisión sin responsable explícito.");
        }

        ensureInitialTransition(flujo, pendienteRevision, crear);
        ensureTransition(flujo, pendienteRevision, aprobado, aprobar);
        ensureTransition(flujo, pendienteRevision, rechazado, rechazar);
        ensureTransition(flujo, pendienteRevision, correccionRequerida, pedirCorreccion);
        ensureTransition(flujo, correccionRequerida, pendienteRevision, reenviar);

        log.info("Catálogo base del flujo documental verificado para '{}'.", FLOW_NAME);
    }

    private EstadoSolicitud getOrCreateEstado(String codigo) {
        return estadoSolicitudRepository.findByCodigoIgnoreCase(codigo)
                .orElseGet(() -> estadoSolicitudRepository.save(new EstadoSolicitud(codigo)));
    }

    private AccionUsuario getOrCreateAccion(String accion) {
        return accionUsuarioRepository.findByAccionIgnoreCase(accion)
                .orElseGet(() -> accionUsuarioRepository.save(new AccionUsuario(accion)));
    }

    private void ensureInitialTransition(FlujoDefinicion flujo, EstadoSolicitud destino, AccionUsuario accion) {
        if (transicionRepository.findInitialTransition(flujo.getId(), accion.getAccion()).isEmpty()) {
            transicionRepository.save(new Transicion(flujo, null, destino, accion));
        }
    }

    private void ensureTransition(FlujoDefinicion flujo, EstadoSolicitud origen, EstadoSolicitud destino, AccionUsuario accion) {
        if (transicionRepository.findByFlujoAndEstadoOrigenAndAccion(
                flujo.getId(), origen.getCodigo(), accion.getAccion()).isEmpty()) {
            transicionRepository.save(new Transicion(flujo, origen, destino, accion));
        }
    }
}
