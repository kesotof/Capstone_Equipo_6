package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.DashboardSummaryCriteria;
import com.capstone.sistema.flow.exception.DashboardSummaryException;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public class DashboardSummaryQueryNormalizer {
    public DashboardSummaryCriteria normalize(Map<String, List<String>> parameters) {
        if (!Set.of("areaId", "sinArea").containsAll(parameters.keySet())) {
            throw invalid();
        }
        String area = single(parameters, "areaId");
        String unassigned = single(parameters, "sinArea");
        if (area != null && unassigned != null) throw invalid();
        Long areaId = null;
        if (area != null) {
            if (!area.matches("[1-9][0-9]{0,18}")) throw invalid();
            try { areaId = Long.parseLong(area); } catch (NumberFormatException ex) { throw invalid(); }
        }
        if (unassigned != null && !"true".equals(unassigned)) throw invalid();
        return new DashboardSummaryCriteria(areaId, unassigned != null);
    }

    private String single(Map<String, List<String>> parameters, String key) {
        List<String> values = parameters.get(key);
        if (values == null) return null;
        if (values.size() != 1 || values.get(0) == null || values.get(0).isEmpty()) throw invalid();
        return values.get(0);
    }
    private DashboardSummaryException invalid() {
        return new DashboardSummaryException("Use un área válida o sinArea=true, sin parámetros adicionales.");
    }
}
