package com.capstone.sistema.audit.repository;

import com.capstone.sistema.audit.model.LogEvento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface LogEventoRepository extends JpaRepository<LogEvento, Long> {

    List<LogEvento> findByTipoEvento_TipoIgnoreCaseOrderByCreatedAtDesc(String tipo);

    List<LogEvento> findByUsuario_IdOrderByCreatedAtDesc(UUID usuarioId);

    List<LogEvento> findAllByOrderByCreatedAtDesc();
}
