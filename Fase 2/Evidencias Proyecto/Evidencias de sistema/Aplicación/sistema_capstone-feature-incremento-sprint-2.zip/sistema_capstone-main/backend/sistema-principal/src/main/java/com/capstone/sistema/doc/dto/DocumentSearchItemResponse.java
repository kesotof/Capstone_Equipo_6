package com.capstone.sistema.doc.dto;

import com.capstone.sistema.flow.dto.AreaDetalleResponse;

import java.time.Instant;
import java.util.UUID;

public record DocumentSearchItemResponse(UUID id, UUID solicitudId, String correlativo, String titulo,
                                         String nombreArchivo, String documentType, String contentType,
                                         Long sizeBytes, int version, String estado, String emisorNombre,
                                         AreaDetalleResponse areaOrigen, AreaDetalleResponse areaFlujo,
                                         Instant createdAt, Instant updatedAt, Instant documentoCreatedAt,
                                         String detalleUrl, String descargaUrl) {
}
