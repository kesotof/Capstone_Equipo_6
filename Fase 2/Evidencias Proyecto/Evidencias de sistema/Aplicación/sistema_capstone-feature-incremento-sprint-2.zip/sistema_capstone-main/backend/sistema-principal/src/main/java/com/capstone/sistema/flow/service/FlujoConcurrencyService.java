package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.exception.FlujoNotFoundException;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import jakarta.persistence.EntityManager;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/** Todos los locks pertenecen a la transacción del servicio que ejecuta la escritura. */
@Service
@Transactional(propagation = Propagation.MANDATORY)
public class FlujoConcurrencyService {
    private final JdbcTemplate jdbc;
    private final EntityManager entityManager;
    private final FlujoDefinicionRepository definitions;
    private final RbacAccessService access;
    private final RbacManagementService security;

    public FlujoConcurrencyService(JdbcTemplate jdbc, EntityManager entityManager, FlujoDefinicionRepository definitions,
                                   RbacAccessService access, RbacManagementService security) {
        this.jdbc=jdbc; this.entityManager=entityManager; this.definitions=definitions;
        this.access=access; this.security=security;
    }

    /** Requiere haber adquirido previamente catálogo de áreas y control RBAC. */
    public FlujoDefinicion lockDefinition(Long id) {
        if (jdbc.query("select id from flujo_definicion where id=? for update", (rs,n)->rs.getLong(1),id).isEmpty()) {
            throw new FlujoNotFoundException("Flujo con id " + id + " no encontrado");
        }
        FlujoDefinicion flow=definitions.findById(id).orElseThrow(RbacException::missing);
        entityManager.refresh(flow);
        return flow;
    }

    public Solicitud lockRequest(UUID id, Long version) {
        security.lockPolicy();
        access.readable(id);
        Long flowId=jdbc.queryForObject("select flujo_definicion_id from solicitud where id=?",Long.class,id);
        lockDefinition(flowId);
        jdbc.queryForObject("select id from solicitud where id=? for update",UUID.class,id);
        Solicitud request=access.readable(id);
        entityManager.refresh(request);
        checkVersion(request.getVersion(),version,"SOLICITUD_VERSION_CONFLICTO");
        return request;
    }

    public void checkVersion(Long current, Long requested, String code) {
        if (requested == null || requested < 0) throw new IllegalArgumentException("Envíe la versión no negativa observada al consultar el recurso.");
        if (!requested.equals(current)) throw RbacException.conflict(code,"Los datos cambiaron. Recargue antes de volver a guardar.");
    }
}
