package com.capstone.sistema.flow.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record EstadoFlujoRequest(@NotNull Boolean activo, @NotNull @PositiveOrZero Long version) {}
