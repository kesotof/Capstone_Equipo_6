package com.capstone.sistema.flow.exception;

import com.capstone.sistema.flow.controller.MyRequestsController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice(assignableTypes = MyRequestsController.class)
@Order(Ordered.HIGHEST_PRECEDENCE + 50)
public class MyRequestsExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(MyRequestsExceptionHandler.class);

    @ExceptionHandler(MyRequestsException.class)
    public ResponseEntity<ProblemDetail> invalidParameters(MyRequestsException ex) {
        return error(HttpStatus.BAD_REQUEST, "Parámetros de consulta inválidos", ex.getMessage(),
                "MY_REQUESTS_INVALID_PARAMETERS");
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> accessDenied(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Control de acceso", "No tiene permiso para realizar esta acción.",
                "RBAC_ACCION_DENEGADA");
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ProblemDetail> unavailable(RuntimeException ex) {
        // No registrar valores de filtros, SQL, datos de cuenta ni contenido de solicitudes.
        log.error("Consulta de seguimiento no disponible: {}", ex.getClass().getSimpleName());
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Consulta no disponible",
                "No fue posible consultar las solicitudes. Intente nuevamente.", "MY_REQUESTS_UNAVAILABLE");
    }

    private ResponseEntity<ProblemDetail> error(HttpStatus status, String title, String detail, String code) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setProperty("code", code);
        return ResponseEntity.status(status).contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .cacheControl(CacheControl.noStore()).body(problem);
    }
}
