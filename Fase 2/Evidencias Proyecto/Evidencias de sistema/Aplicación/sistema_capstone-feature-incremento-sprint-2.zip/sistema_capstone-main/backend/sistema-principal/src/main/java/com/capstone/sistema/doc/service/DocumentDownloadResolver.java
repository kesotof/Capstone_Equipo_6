package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import com.capstone.sistema.doc.exception.DocumentDownloadException;
import com.capstone.sistema.doc.repository.DocumentDownloadRepository;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
public class DocumentDownloadResolver {
    private final DocumentDownloadRepository documents;
    private final RbacAccessService access;

    public DocumentDownloadResolver(DocumentDownloadRepository documents, RbacAccessService access) {
        this.documents = documents;
        this.access = access;
    }

    public DocumentDownloadTarget byId(UUID id) {
        access.clearContext();
        return authorized(documents.byId(id));
    }

    public DocumentDownloadTarget current(UUID solicitudId) {
        access.clearContext();
        // La solicitud se autoriza también cuando no tiene adjunto vigente.
        access.authorize(solicitudId, Permiso.DOCUMENTO_DESCARGAR);
        return unique(documents.current(solicitudId));
    }

    public DocumentDownloadTarget byKey(String key) {
        access.clearContext();
        return authorized(documents.byKey(key));
    }

    private DocumentDownloadTarget authorized(List<DocumentDownloadTarget> matches) {
        if (matches.isEmpty()) throw DocumentDownloadException.missing();
        for (DocumentDownloadTarget target : matches) {
            access.authorize(target.solicitudId(), Permiso.DOCUMENTO_DESCARGAR);
        }
        return unique(matches);
    }

    private DocumentDownloadTarget unique(List<DocumentDownloadTarget> matches) {
        if (matches.isEmpty()) throw DocumentDownloadException.missing();
        if (matches.size() != 1) throw DocumentDownloadException.inconsistent();
        DocumentDownloadTarget target = matches.getFirst();
        if (target.storageKey() == null || target.storageKey().isBlank()) throw DocumentDownloadException.missing();
        return target;
    }
}
