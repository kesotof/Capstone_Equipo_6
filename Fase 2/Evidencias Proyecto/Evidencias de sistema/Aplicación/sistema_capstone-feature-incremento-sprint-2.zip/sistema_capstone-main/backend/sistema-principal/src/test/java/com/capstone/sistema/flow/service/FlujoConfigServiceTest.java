package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.exception.FlujoNotFoundException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlujoConfigServiceTest {

    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;

    @Mock
    private FlujoEtapaRepository flujoEtapaRepository;

    @Mock
    private SolicitudRepository solicitudRepository;

    @Mock
    private AreaRepository areaRepository;

    @Mock
    private UserAccountRepository userAccountRepository;

    @Mock
    private AuditService auditService;

    @Mock
    private CurrentUserResolver currentUserResolver;

    @InjectMocks
    private FlujoConfigService flujoConfigService;

    private Area finanzas;
    private UserAccount adminUser;
    private UserAccount revisorUser;

    @BeforeEach
    void setUp() {
        adminUser = new UserAccount("kc-admin", "admin@empresa.cl", "Admin", "General", true, Set.of());
        revisorUser = new UserAccount("kc-rev", "revisor@otra-area.cl", "Revisor", "Uno", true, Set.of());
        finanzas = new Area(1L, "Finanzas", true);
    }

    @Test
    @DisplayName("Admin crea flujo asociado a un área exitosamente con estado completo=false")
    void crearFlujo_conArea_retornaCreadoIncompleto() {
        CrearFlujoRequest request = new CrearFlujoRequest("Aprobación Gastos", "Flujo para gastos", 1L);

        when(flujoDefinicionRepository.existsByNombreIgnoreCase("Aprobación Gastos")).thenReturn(false);
        when(areaRepository.findById(1L)).thenReturn(Optional.of(finanzas));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);

        when(flujoDefinicionRepository.save(any(FlujoDefinicion.class))).thenAnswer(invocation -> {
            FlujoDefinicion f = invocation.getArgument(0);
            return f;
        });

        FlujoResponse response = flujoConfigService.crearFlujo(request);

        assertThat(response.nombre()).isEqualTo("Aprobación Gastos");
        assertThat(response.areaId()).isEqualTo(1L);
        assertThat(response.areaNombre()).isEqualTo("Finanzas");
        assertThat(response.activo()).isTrue();
        assertThat(response.completo()).isFalse();

        verify(auditService).registerUserManagementEvent(eq("CREAR_FLUJO"), contains("Aprobación Gastos"));
    }

    @Test
    @DisplayName("Rechaza crear flujo con nombre duplicado")
    void crearFlujo_nombreDuplicado_lanzaConflicto() {
        CrearFlujoRequest request = new CrearFlujoRequest("Flujo Existente", "Desc", null);
        when(flujoDefinicionRepository.existsByNombreIgnoreCase("Flujo Existente")).thenReturn(true);

        assertThatThrownBy(() -> flujoConfigService.crearFlujo(request))
                .isInstanceOf(FlujoConflictException.class)
                .hasMessageContaining("Ya existe un flujo");
    }

    @Test
    @DisplayName("Configurar etapas atómicamente con revisores marca flujo como completo=true")
    void configurarEtapas_conRevisores_marcaCompletoTrue() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Flujo Legal", finanzas);

        UUID revId = UUID.randomUUID();
        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(userAccountRepository.findById(revId)).thenReturn(Optional.of(revisorUser));
        when(flujoDefinicionRepository.save(any(FlujoDefinicion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Revisión Jefatura", revId),
                new EtapaConfigItem(2, "Visado Final", revId)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        FlujoResponse response = flujoConfigService.configurarEtapas(flujoId, req);

        assertThat(response.completo()).isTrue();
        assertThat(response.etapas()).hasSize(2);
        assertThat(response.etapas().get(0).orden()).isEqualTo(1);
        assertThat(response.etapas().get(0).revisorEmail()).isEqualTo("revisor@otra-area.cl");
        assertThat(response.etapas().get(1).orden()).isEqualTo(2);

        verify(auditService).registerUserManagementEvent(eq("CONFIGURAR_ETAPAS_FLUJO"), contains("Contratos"));
    }

    @Test
    @DisplayName("Configurar etapas donde una no tiene revisor asignado marca completo=false")
    void configurarEtapas_revisorPendiente_marcaCompletoFalse() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Flujo Legal", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(flujoDefinicionRepository.save(any(FlujoDefinicion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Revisión Preliminar", null)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        FlujoResponse response = flujoConfigService.configurarEtapas(flujoId, req);

        assertThat(response.completo()).isFalse();
        assertThat(response.etapas().get(0).revisorId()).isNull();
    }

    @Test
    @DisplayName("Configurar etapas con orden no correlativo lanza excepción")
    void configurarEtapas_ordenInvalido_lanzaIllegalArgument() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Etapa 1", null),
                new EtapaConfigItem(3, "Etapa 3", null)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        assertThatThrownBy(() -> flujoConfigService.configurarEtapas(flujoId, req))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("consecutivos");
    }

    @Test
    @DisplayName("Revisor inactivo en etapa lanza excepción")
    void configurarEtapas_revisorInactivo_lanzaIllegalArgument() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);
        UUID revId = UUID.randomUUID();
        UserAccount inactiveUser = new UserAccount("kc-inact", "inactivo@empresa.cl", "Inact", "User", false, Set.of());

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(userAccountRepository.findById(revId)).thenReturn(Optional.of(inactiveUser));

        List<EtapaConfigItem> items = List.of(new EtapaConfigItem(1, "Etapa 1", revId));
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        assertThatThrownBy(() -> flujoConfigService.configurarEtapas(flujoId, req))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("inactivo");
    }

    @Test
    @DisplayName("Usuario sin rol admin ni administrador del área recibe UnauthorizedActionException")
    void gestionarFlujo_usuarioSinPermisos_lanzaUnauthorizedAction() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);
        UserAccount regularUser = new UserAccount("kc-reg", "regular@empresa.cl", "Reg", "User", true, Set.of());

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(regularUser));
        when(areaRepository.findById(1L)).thenReturn(Optional.of(finanzas));

        ActualizarFlujoRequest request = new ActualizarFlujoRequest("Nuevo Nombre", "Desc", 1L, true);

        assertThatThrownBy(() -> flujoConfigService.actualizarFlujo(flujoId, request))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("No tiene permisos de administrador");
    }

    @Test
    @DisplayName("Eliminar flujo con solicitudes activas lo desactiva en vez de borrar físicamente")
    void eliminarFlujo_conSolicitudes_desactivaFlujo() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);
        flujo.setActivo(true);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(solicitudRepository.countByFlujoDefinicion_Id(flujoId)).thenReturn(5L);

        flujoConfigService.eliminarFlujo(flujoId);

        assertThat(flujo.isActivo()).isFalse();
        verify(flujoDefinicionRepository).save(flujo);
        verify(flujoDefinicionRepository, never()).delete(any());
        verify(auditService).registerUserManagementEvent(eq("DESACTIVAR_FLUJO"), contains("desactivado por tener solicitudes"));
    }

    @Test
    @DisplayName("Eliminar flujo sin solicitudes lo elimina permanentemente")
    void eliminarFlujo_sinSolicitudes_eliminaPermanente() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("SinUso", "Desc", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(solicitudRepository.countByFlujoDefinicion_Id(flujoId)).thenReturn(0L);

        flujoConfigService.eliminarFlujo(flujoId);

        verify(flujoDefinicionRepository).delete(flujo);
        verify(auditService).registerUserManagementEvent(eq("DESACTIVAR_FLUJO"), contains("eliminado"));
    }
}
