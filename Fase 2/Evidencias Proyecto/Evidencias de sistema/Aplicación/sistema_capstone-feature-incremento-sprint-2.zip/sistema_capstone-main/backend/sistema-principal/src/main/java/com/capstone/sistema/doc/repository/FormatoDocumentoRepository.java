package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.FormatoDocumento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FormatoDocumentoRepository extends JpaRepository<FormatoDocumento, Long> {

    Optional<FormatoDocumento> findByTipoIgnoreCase(String tipo);
}
