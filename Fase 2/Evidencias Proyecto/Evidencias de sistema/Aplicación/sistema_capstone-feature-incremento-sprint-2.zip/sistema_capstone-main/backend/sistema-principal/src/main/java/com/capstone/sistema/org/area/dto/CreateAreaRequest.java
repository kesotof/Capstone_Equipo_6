package com.capstone.sistema.org.area.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.util.UUID;

public record CreateAreaRequest(
        @NotNull(message = "El nombre es obligatorio.") String nombre,
        String descripcion,
        @Positive(message = "El ID del padre debe ser positivo.") Long areaPadreId,
        UUID administradorId
) {
    public CreateAreaRequest(String nombre, String descripcion, Long areaPadreId) {
        this(nombre, descripcion, areaPadreId, null);
    }
}
