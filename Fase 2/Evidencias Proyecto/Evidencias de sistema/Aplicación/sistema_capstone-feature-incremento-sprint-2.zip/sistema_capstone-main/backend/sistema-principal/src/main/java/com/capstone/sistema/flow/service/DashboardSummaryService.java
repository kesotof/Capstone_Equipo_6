package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.DashboardSummaryResponse;
import com.capstone.sistema.flow.dto.DashboardSummaryResponse.*;
import com.capstone.sistema.flow.exception.DashboardSummaryException;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.DashboardSummaryRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Alcance;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class DashboardSummaryService {
    private static final ZoneId ZONE = ZoneId.of("America/Santiago");
    private final DashboardSummaryRepository aggregates;
    private final AreaRepository areas;
    private final DashboardSummaryQueryNormalizer normalizer;
    private final RbacAccessService rbac;

    public DashboardSummaryService(DashboardSummaryRepository aggregates, AreaRepository areas,
            DashboardSummaryQueryNormalizer normalizer, RbacAccessService rbac) {
        this.aggregates = aggregates;
        this.areas = areas;
        this.normalizer = normalizer;
        this.rbac = rbac;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public DashboardSummaryResponse summary(Map<String, List<String>> parameters) {
        rbac.clearContext();
        rbac.require(Permiso.METRICAS_CONSULTAR);
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        var context = rbac.context();
        var filter = normalizer.normalize(parameters);
        boolean global = context.admin() && context.scopes(Permiso.METRICAS_CONSULTAR).contains(Alcance.GLOBAL)
                && context.scopes(Permiso.SOLICITUD_CONSULTAR).contains(Alcance.GLOBAL);
        if (filter.filtered() && !global) throw RbacException.denied();
        Map<Long, Area> catalog = global ? areas.findAll().stream()
                .collect(Collectors.toMap(Area::getId, Function.identity())) : new HashMap<>();
        if (filter.areaId() != null && !catalog.containsKey(filter.areaId())) {
            throw new DashboardSummaryException("El área seleccionada no está disponible en el catálogo.");
        }

        Specification<Solicitud> visible = rbac.visible(context, Permiso.METRICAS_CONSULTAR)
                .and(rbac.visible(context, Permiso.SOLICITUD_CONSULTAR));
        if (filter.filtered()) {
            visible = visible.and((root, query, cb) -> {
                var area = cb.coalesce(root.<Long>get("areaOrigenId"), root.<Long>get("areaFlujoId"));
                return filter.sinArea() ? cb.isNull(area) : cb.equal(area, filter.areaId());
            });
        }
        var rows = aggregates.states(visible);
        Set<Long> ids = rows.stream().map(DashboardSummaryRepository.StateCount::areaId)
                .filter(Objects::nonNull).collect(Collectors.toSet());
        ids.removeAll(catalog.keySet());
        if (!ids.isEmpty()) areas.findAllById(ids).forEach(area -> catalog.put(area.getId(), area));

        Map<Long, long[]> grouped = new HashMap<>();
        if (global) {
            if (filter.sinArea()) grouped.put(null, new long[5]);
            else if (filter.areaId() != null) grouped.put(filter.areaId(), new long[5]);
            else catalog.keySet().forEach(id -> grouped.put(id, new long[5]));
        }
        long[] total = new long[5];
        for (var row : rows) {
            int index = stateIndex(row.state());
            grouped.computeIfAbsent(row.areaId(), ignored -> new long[5])[index] += row.count();
            total[index] += row.count();
        }
        List<AreaSummary> breakdown = grouped.entrySet().stream().map(entry -> {
            Area area = catalog.get(entry.getKey());
            String name = entry.getKey() == null ? "Sin área registrada" : area == null ? "Área no disponible" : area.getNombre();
            return new AreaSummary(entry.getKey(), name, area == null ? null : area.isActivo(), totals(entry.getValue()));
        }).sorted(Comparator.comparing(AreaSummary::nombre, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AreaSummary::areaId, Comparator.nullsLast(Comparator.naturalOrder()))).toList();
        // El catálogo de selección contiene exclusivamente IDs existentes; los IDs históricos no amplían el selector.
        List<AreaOption> options = global ? catalog.values().stream()
                .map(area -> new AreaOption(area.getId(), area.getNombre(), area.isActivo()))
                .sorted(Comparator.comparing(AreaOption::nombre, String.CASE_INSENSITIVE_ORDER).thenComparing(AreaOption::id))
                .toList() : List.of();

        Instant now = Instant.now();
        LocalDate first = now.atZone(ZONE).toLocalDate().minusDays(6);
        List<Instant> boundaries = IntStream.rangeClosed(0, 7)
                .mapToObj(day -> first.plusDays(day).atStartOfDay(ZONE).toInstant()).toList();
        long[] daily = new long[7];
        for (var day : aggregates.emissions(visible, boundaries)) daily[day.day()] = day.count();
        List<DailyCount> trend = IntStream.range(0, 7)
                .mapToObj(day -> new DailyCount(first.plusDays(day), daily[day])).toList();
        return new DashboardSummaryResponse(totals(total), breakdown, options, global, filter.areaId(),
                filter.sinArea(), trend, ZONE.getId(), now);
    }

    private int stateIndex(String code) {
        if (code == null) return 4;
        return switch (code) {
            case "PENDIENTE_REVISION" -> 0;
            case "APROBADO" -> 1;
            case "RECHAZADO" -> 2;
            case "CORRECCION_REQUERIDA" -> 3;
            default -> 4;
        };
    }
    private Totals totals(long[] counts) {
        return new Totals(counts[0], counts[1], counts[2], counts[3], counts[4], Arrays.stream(counts).sum());
    }
}
