package com.capstone.sistema.users.model;

public enum SystemRole {
    ADMIN,
    APPROVER
}
