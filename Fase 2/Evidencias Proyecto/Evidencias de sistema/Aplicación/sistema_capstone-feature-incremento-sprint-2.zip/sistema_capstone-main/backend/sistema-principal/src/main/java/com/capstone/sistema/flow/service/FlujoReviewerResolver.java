package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.RolFlujoRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Una sola resolución para configuración, ejecución, notificaciones y protección RBAC. */
@Service
@Transactional(readOnly = true)
public class FlujoReviewerResolver {
    private final RbacAccessService access;
    private final UserAccountRepository users;
    private final RolFlujoRepository roles;
    private final JdbcTemplate jdbc;

    public FlujoReviewerResolver(RbacAccessService access, UserAccountRepository users,
                                 RolFlujoRepository roles, JdbcTemplate jdbc) {
        this.access=access; this.users=users; this.roles=roles; this.jdbc=jdbc;
    }

    public List<UserAccount> eligibleUsers() {
        return users.findAllByOrderByEmailAsc().stream().filter(access::eligibleReviewer).toList();
    }

    public List<UserAccount> candidates(FlujoEtapa stage) {
        if (isDynamicBase(stage)) return users.findAllByOrderByEmailAsc().stream().filter(UserAccount::isEnabled).toList();
        if (stage.getTipoAsignacion()==TipoAsignacionRevisor.USUARIO) {
            UserAccount user=stage.getRevisor();
            return stage.getRolRevisor()==null && user!=null && access.eligibleReviewer(user) ? List.of(user) : List.of();
        }
        var role=stage.getRolRevisor();
        var area=stage.getFlujoDefinicion().getArea();
        if (stage.getRevisor()!=null || role==null || area==null
                || !Boolean.TRUE.equals(jdbc.queryForObject("select activo from rol_flujo where id=?",Boolean.class,role.getId()))
                || !Boolean.TRUE.equals(jdbc.queryForObject("select activo from area where id=?",Boolean.class,area.getId()))) return List.of();
        return eligibleUsers().stream().filter(user->{
            var context=access.forUser(user);
            return Objects.equals(context.areaId(),area.getId()) && context.roles().stream().anyMatch(r->r.id().equals(role.getId()));
        }).toList();
    }

    public List<UserAccount> forRequest(Solicitud request, FlujoEtapa stage) {
        return candidates(stage).stream().filter(user->access.canOperateAtStage(user,request,stage)).toList();
    }

    public void requireAvailable(FlujoEtapa stage) {
        if (candidates(stage).isEmpty()) throw orphan("La etapa '"+stage.getNombre()+"' necesita un usuario disponible o un rol con revisores en el área del flujo.");
    }

    public void requireForRequest(Solicitud request, FlujoEtapa stage) {
        if (forRequest(request,stage).isEmpty()) throw orphan("La etapa '"+stage.getNombre()+"' no tiene responsables autorizados para la solicitud "+request.getCorrelativo()+".");
    }

    public void assign(FlujoEtapa stage, TipoAsignacionRevisor type, UUID userId, Long roleId) {
        if (type==null) throw RbacException.invalid("El tipo de asignación es obligatorio.");
        if (type==TipoAsignacionRevisor.USUARIO) {
            if (roleId!=null) throw RbacException.invalid("La asignación por usuario no admite un rol revisor.");
            if (userId==null) throw orphan("Seleccione un usuario responsable de la revisión.");
            stage.asignarUsuario(users.findById(userId).orElseThrow(()->RbacException.invalid("El usuario indicado no existe.")));
        } else {
            if (userId!=null || (roleId!=null && roleId<=0)) throw RbacException.invalid("La asignación por rol requiere un ID positivo y no admite un usuario específico.");
            if (roleId==null) throw orphan("Seleccione un rol departamental responsable de la revisión.");
            stage.asignarRol(roles.findById(roleId).orElseThrow(()->RbacException.invalid("El rol indicado no existe.")));
        }
        requireAvailable(stage);
    }

    public static boolean isDynamicBase(FlujoEtapa stage) {
        FlujoDefinicion flow=stage.getFlujoDefinicion();
        return Long.valueOf(1).equals(flow.getId()) && FlujoIntegrityService.BASE_NAME.equals(flow.getNombre())
                && flow.getArea()==null && flow.getEtapas().size()==1 && stage.getOrden()==1
                && stage.getTipoAccion()==TipoAccionEtapa.REVISION && stage.getTipoAsignacion()==TipoAsignacionRevisor.USUARIO
                && stage.getRevisor()==null && stage.getRolRevisor()==null;
    }

    public static RbacException orphan(String detail) {
        return new RbacException(HttpStatus.UNPROCESSABLE_ENTITY,"FLUJO_ETAPA_HUERFANA",detail);
    }
}
