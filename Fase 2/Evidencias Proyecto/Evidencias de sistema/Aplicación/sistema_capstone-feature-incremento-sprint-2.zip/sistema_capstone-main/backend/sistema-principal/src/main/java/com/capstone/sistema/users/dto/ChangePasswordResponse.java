package com.capstone.sistema.users.dto;

public record ChangePasswordResponse(String message) {
    public static ChangePasswordResponse success() {
        return new ChangePasswordResponse("Contraseña actualizada exitosamente");
    }
}
