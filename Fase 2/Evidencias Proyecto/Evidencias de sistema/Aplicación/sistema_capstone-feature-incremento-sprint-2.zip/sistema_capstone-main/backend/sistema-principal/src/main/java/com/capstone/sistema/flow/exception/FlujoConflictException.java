package com.capstone.sistema.flow.exception;

public class FlujoConflictException extends RuntimeException {
    public FlujoConflictException(String message) {
        super(message);
    }
}
