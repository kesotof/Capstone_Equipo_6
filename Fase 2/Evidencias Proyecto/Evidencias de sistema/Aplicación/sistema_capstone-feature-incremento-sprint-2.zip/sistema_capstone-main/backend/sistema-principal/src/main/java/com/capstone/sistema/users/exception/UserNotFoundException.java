package com.capstone.sistema.users.exception;

import java.util.UUID;

public class UserNotFoundException extends RuntimeException {

    public UserNotFoundException(UUID id) {
        super("No se encontro el usuario con identificador " + id);
    }

    public UserNotFoundException(String message) {
        super(message);
    }
}
