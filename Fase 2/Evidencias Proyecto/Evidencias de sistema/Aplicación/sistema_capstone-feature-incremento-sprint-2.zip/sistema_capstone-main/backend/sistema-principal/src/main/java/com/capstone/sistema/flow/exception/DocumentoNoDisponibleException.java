package com.capstone.sistema.flow.exception;

public class DocumentoNoDisponibleException extends RuntimeException {

    public DocumentoNoDisponibleException(String message) {
        super(message);
    }

    public DocumentoNoDisponibleException(String message, Throwable cause) {
        super(message, cause);
    }
}
