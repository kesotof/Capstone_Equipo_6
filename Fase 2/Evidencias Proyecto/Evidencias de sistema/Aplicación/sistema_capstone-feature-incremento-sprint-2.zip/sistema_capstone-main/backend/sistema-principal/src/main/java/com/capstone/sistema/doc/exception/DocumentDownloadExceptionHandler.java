package com.capstone.sistema.doc.exception;

import com.capstone.sistema.doc.controller.DocumentDownloadController;
import com.capstone.sistema.rbac.exception.RbacException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice(assignableTypes = DocumentDownloadController.class)
@Order(Ordered.HIGHEST_PRECEDENCE + 40)
public class DocumentDownloadExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(DocumentDownloadExceptionHandler.class);

    @ExceptionHandler(DocumentDownloadException.class)
    public ResponseEntity<ProblemDetail> downloadError(DocumentDownloadException ex) {
        return error(ex.status(), ex.getMessage(), ex.code());
    }

    @ExceptionHandler(RbacException.class)
    public ResponseEntity<ProblemDetail> rbac(RbacException ex) {
        return error(ex.status(), ex.getMessage(), ex.codigo());
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> denied(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "No tiene permiso para descargar este documento.", "RBAC_ACCION_DENEGADA");
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ProblemDetail> invalidId(MethodArgumentTypeMismatchException ex) {
        return error(HttpStatus.BAD_REQUEST, "El identificador del documento o solicitud no es válido.", "DOCUMENT_DOWNLOAD_INVALID_ID");
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ProblemDetail> failure(RuntimeException ex) {
        log.error("Descarga documental no disponible; tipo={}", ex.getClass().getSimpleName());
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "No fue posible obtener el archivo. Intente nuevamente.", "DOCUMENT_DOWNLOAD_UNAVAILABLE");
    }

    private ResponseEntity<ProblemDetail> error(HttpStatus status, String message, String code) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, message);
        problem.setTitle("Descarga de documentos");
        problem.setProperty("code", code);
        return ResponseEntity.status(status).body(problem);
    }
}
