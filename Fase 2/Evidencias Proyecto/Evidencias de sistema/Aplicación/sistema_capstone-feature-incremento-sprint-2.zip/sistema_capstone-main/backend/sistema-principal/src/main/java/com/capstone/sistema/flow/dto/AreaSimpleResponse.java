package com.capstone.sistema.flow.dto;

public record AreaSimpleResponse(
        Long id,
        String nombre
) {}
