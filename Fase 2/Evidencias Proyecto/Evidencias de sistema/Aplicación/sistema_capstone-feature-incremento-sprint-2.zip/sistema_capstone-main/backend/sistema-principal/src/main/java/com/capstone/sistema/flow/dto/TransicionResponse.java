package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record TransicionResponse(
        Long id,
        String estadoOrigen,
        String estadoDestino,
        String accion,
        String usuarioEmail,
        String usuarioNombre,
        String comentario,
        Boolean dentroSla,
        Instant createdAt,
        EtapaSolicitudResponse etapaOrigen,
        EtapaSolicitudResponse etapaDestino
) {
    public TransicionResponse(Long id,String estadoOrigen,String estadoDestino,String accion,String usuarioEmail,
                              String usuarioNombre,String comentario,Boolean dentroSla,Instant createdAt) {
        this(id,estadoOrigen,estadoDestino,accion,usuarioEmail,usuarioNombre,comentario,dentroSla,createdAt,null,null);
    }
    public TransicionResponse(
            Long id,
            String estadoOrigen,
            String estadoDestino,
            String accion,
            String usuarioEmail,
            String usuarioNombre,
            String comentario,
            Instant createdAt
    ) {
        this(id, estadoOrigen, estadoDestino, accion, usuarioEmail, usuarioNombre, comentario, null, createdAt);
    }
}
