package com.capstone.sistema.org.area.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

import java.util.UUID;

public record UpdateAreaRequest(
        @NotNull(message = "El nombre es obligatorio.") String nombre,
        String descripcion,
        @Positive(message = "El ID del padre debe ser positivo.") Long areaPadreId,
        UUID administradorId,
        @NotNull(message = "La versión es obligatoria.")
        @PositiveOrZero(message = "La versión no puede ser negativa.") Long version
) {
    public UpdateAreaRequest(String nombre, String descripcion, Long areaPadreId, Long version) {
        this(nombre, descripcion, areaPadreId, null, version);
    }
}
