package com.capstone.sistema.users.repository;

import com.capstone.sistema.users.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface AreaRepository extends JpaRepository<Area, Long> {

    Optional<Area> findByNombreIgnoreCase(String nombre);

    java.util.List<Area> findAllByAdministrador_Id(java.util.UUID userId);

    @Query(value = """
            select a from Area a left join fetch a.areaPadre
            where (:activo is null or a.activo = :activo)
              and lower(a.nombre) like lower(:patron) escape '!'
            order by lower(a.nombre), a.id
            """, countQuery = """
            select count(a) from Area a
            where (:activo is null or a.activo = :activo)
              and lower(a.nombre) like lower(:patron) escape '!'
            """)
    Page<Area> findCatalogPage(@Param("activo") Boolean activo,
                             @Param("patron") String patron, Pageable pageable);

    @Query("""
            select count(a) from Area a
            where (:activo is null or a.activo = :activo)
              and lower(a.nombre) like lower(:patron) escape '!'
            """)
    long countCatalog(@Param("activo") Boolean activo, @Param("patron") String patron);

    @Query(value = """
            select exists(select 1 from area where lower(btrim(nombre)) = lower(btrim(:nombre)))
            """, nativeQuery = true)
    boolean existsNombreNormalizado(@Param("nombre") String nombre);

    @Query(value = """
            select exists(select 1 from area
                          where lower(btrim(nombre)) = lower(btrim(:nombre)) and id <> :id)
            """, nativeQuery = true)
    boolean existsNombreNormalizadoExcluding(@Param("nombre") String nombre, @Param("id") Long id);
}
