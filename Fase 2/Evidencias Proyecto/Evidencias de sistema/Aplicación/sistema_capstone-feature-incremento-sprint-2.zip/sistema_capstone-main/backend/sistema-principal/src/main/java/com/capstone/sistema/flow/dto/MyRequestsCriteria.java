package com.capstone.sistema.flow.dto;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

/** Parámetros normalizados del lector; la bandeja la decide el método de servicio. */
public record MyRequestsCriteria(String query, String status, Long areaId, int page, int size) {
    public static final String ORDER = "updatedAt,desc";

    public Pageable pageable() {
        return PageRequest.of(page, size, Sort.by(
                Sort.Order.desc("updatedAt"), Sort.Order.asc("id")));
    }
}
