package com.capstone.sistema.users.exception;

public class RutInvalidoException extends RuntimeException {

    public RutInvalidoException(String message) {
        super(message);
    }
}
