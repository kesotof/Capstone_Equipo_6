package com.capstone.sistema.flow.exception;

import com.capstone.sistema.flow.controller.DashboardSummaryController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice(assignableTypes = DashboardSummaryController.class)
@Order(Ordered.HIGHEST_PRECEDENCE + 45)
public class DashboardSummaryExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(DashboardSummaryExceptionHandler.class);
    @ExceptionHandler(DashboardSummaryException.class)
    public ResponseEntity<ProblemDetail> invalid(DashboardSummaryException ex) {
        return error(HttpStatus.BAD_REQUEST, "Parámetros inválidos", ex.getMessage(), "DASHBOARD_INVALID_PARAMETERS");
    }
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> denied(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Control de acceso", "No tiene permiso para consultar este resumen.", "RBAC_ACCION_DENEGADA");
    }
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ProblemDetail> unavailable(RuntimeException ex) {
        log.error("Resumen general no disponible: {}", ex.getClass().getSimpleName());
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Resumen no disponible",
                "No fue posible consultar el resumen. Intente nuevamente.", "DASHBOARD_UNAVAILABLE");
    }
    private ResponseEntity<ProblemDetail> error(HttpStatus status, String title, String detail, String code) {
        var problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setProperty("code", code);
        return ResponseEntity.status(status).contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .cacheControl(CacheControl.noStore()).body(problem);
    }
}
