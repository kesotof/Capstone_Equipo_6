package com.capstone.sistema.flow.exception;

import com.capstone.sistema.flow.controller.RequestDetailController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice(assignableTypes = RequestDetailController.class)
@Order(Ordered.HIGHEST_PRECEDENCE + 50)
public class RequestDetailExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(RequestDetailExceptionHandler.class);

    @ExceptionHandler(RequestDetailDocumentConflictException.class)
    public ResponseEntity<ProblemDetail> documentosInconsistentes(RequestDetailDocumentConflictException ex) {
        return error(HttpStatus.CONFLICT, "Información documental inconsistente", ex.getMessage(),
                "SOLICITUD_DOCUMENTO_INCONSISTENTE");
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ProblemDetail> identificadorInvalido(MethodArgumentTypeMismatchException ex) {
        return error(HttpStatus.BAD_REQUEST, "Identificador inválido", "El identificador de solicitud debe ser un UUID válido.",
                "SOLICITUD_ID_INVALIDO");
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> accesoDenegado(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Control de acceso", "No tiene permiso para realizar esta acción.",
                "RBAC_ACCION_DENEGADA");
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ProblemDetail> detalleNoDisponible(RuntimeException ex) {
        log.error("No fue posible consultar el detalle integral de la solicitud", ex);
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Detalle no disponible",
                "No fue posible cargar la información de la solicitud. Intente nuevamente.",
                "DETALLE_SOLICITUD_NO_DISPONIBLE");
    }

    private ResponseEntity<ProblemDetail> error(HttpStatus status, String title, String detail, String code) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setProperty("code", code);
        return ResponseEntity.status(status).cacheControl(CacheControl.noStore()).body(problem);
    }
}
