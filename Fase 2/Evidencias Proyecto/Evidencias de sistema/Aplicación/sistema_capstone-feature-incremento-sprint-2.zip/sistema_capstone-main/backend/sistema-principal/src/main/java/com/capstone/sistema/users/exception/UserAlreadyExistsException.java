package com.capstone.sistema.users.exception;

public class UserAlreadyExistsException extends RuntimeException {

    public UserAlreadyExistsException(String email) {
        super("Ya existe una cuenta registrada con el correo " + email);
    }
}
