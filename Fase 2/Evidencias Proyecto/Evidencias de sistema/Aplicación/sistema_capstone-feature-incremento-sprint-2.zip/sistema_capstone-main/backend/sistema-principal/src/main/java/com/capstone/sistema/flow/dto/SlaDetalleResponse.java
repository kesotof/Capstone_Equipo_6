package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record SlaDetalleResponse(Instant deadline, String status, Instant evaluadoEn, boolean enRevision) {
}
