package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.DocumentoNoDisponibleException;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.SolicitudNotFoundException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.flow.util.SlaStatusCalculator;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import com.capstone.sistema.rbac.dto.RbacDtos;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class SolicitudService {

    private static final Logger log = LoggerFactory.getLogger(SolicitudService.class);
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("pdf", "docx", "doc", "xml", "txt", "xlsx", "xls");

    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final FormatoDocumentoRepository formatoDocumentoRepository;
    private final FlujoDefinicionRepository flujoDefinicionRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final EstadoSolicitudRepository estadoSolicitudRepository;
    private final AccionUsuarioRepository accionUsuarioRepository;
    private final SolicitudTransicionRepository solicitudTransicionRepository;
    private final ObservacionRepository observacionRepository;
    private final MinioStorageService storageService;
    private final NotificacionService notificacionService;
    private final AuditService auditService;
    private final CurrentUserResolver currentUserResolver;
    private final SlaService slaService;
    private final AreaRepository areaRepository;
    private final RbacAccessService rbac;
    private final com.capstone.sistema.rbac.service.RbacManagementService rbacManagement;
    private final FlujoConcurrencyService concurrency;
    private final FlujoIntegrityService integrity;
    private final Clock clock;

    @org.springframework.beans.factory.annotation.Autowired
    public SolicitudService(
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            FormatoDocumentoRepository formatoDocumentoRepository,
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionUsuarioRepository accionUsuarioRepository,
            SolicitudTransicionRepository solicitudTransicionRepository,
            ObservacionRepository observacionRepository,
            MinioStorageService storageService,
            NotificacionService notificacionService,
            AuditService auditService,
            CurrentUserResolver currentUserResolver,
            @org.springframework.beans.factory.annotation.Autowired(required = false) SlaService slaService,
            @org.springframework.beans.factory.annotation.Autowired(required = false) AreaRepository areaRepository,
            RbacAccessService rbac,
            com.capstone.sistema.rbac.service.RbacManagementService rbacManagement,
            FlujoConcurrencyService concurrency,
            FlujoIntegrityService integrity,
            Clock clock
    ) {
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.formatoDocumentoRepository = formatoDocumentoRepository;
        this.flujoDefinicionRepository = flujoDefinicionRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.estadoSolicitudRepository = estadoSolicitudRepository;
        this.accionUsuarioRepository = accionUsuarioRepository;
        this.solicitudTransicionRepository = solicitudTransicionRepository;
        this.observacionRepository = observacionRepository;
        this.storageService = storageService;
        this.notificacionService = notificacionService;
        this.auditService = auditService;
        this.currentUserResolver = currentUserResolver;
        this.slaService = slaService;
        this.areaRepository = areaRepository;
        this.rbac = rbac;
        this.rbacManagement = rbacManagement;
        this.concurrency = concurrency;
        this.integrity = integrity;
        this.clock = clock;
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file) {
        return crearSolicitud(titulo, descripcion, file, false, null, "General");
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file, boolean notificarEmail) {
        return crearSolicitud(titulo, descripcion, file, notificarEmail, null, "General");
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file, boolean notificarEmail, String tipoDocumento) {
        return crearSolicitud(titulo, descripcion, file, notificarEmail, null, tipoDocumento);
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file, boolean notificarEmail, Long flujoId) {
        return crearSolicitud(titulo, descripcion, file, notificarEmail, flujoId, "General");
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file, boolean notificarEmail, Long flujoId, String tipoDocumento) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("El título del documento es obligatorio");
        }
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("El archivo del documento es obligatorio");
        }

        validarArchivo(file);

        rbacManagement.lockPolicy();
        rbac.require(Permiso.SOLICITUD_CREAR);
        UserAccount emisor = getAuthenticatedUser();
        String extension = extraerExtension(file.getOriginalFilename());
        FormatoDocumento formato = getOrCreateFormato(extension);

        FlujoDefinicion flujo;
        try {
            flujo = concurrency.lockDefinition(flujoId != null ? flujoId : 1L);
        } catch (com.capstone.sistema.flow.exception.FlujoNotFoundException ex) {
            if (flujoId != null) throw ex;
            throw RbacException.conflict("FLUJO_CATALOGO_INCONSISTENTE", "El flujo base no está disponible en el catálogo.");
        }
        if (flujoId == null && !integrity.isBase(flujo)) throw RbacException.conflict(
                "FLUJO_CATALOGO_INCONSISTENTE", "La identidad o estructura del flujo base es inconsistente.");
        rbac.requireFlowEmissionScope(flujo);
        integrity.requireExecutable(flujo, true);
        FlujoEtapa etapa = integrity.orderedStages(flujo).get(0);

        EstadoSolicitud estadoPendiente = getEstado("PENDIENTE_REVISION");
        AccionUsuario accionCrear = getAccion("CREAR");

        String resolvedTipo = (tipoDocumento != null && !tipoDocumento.trim().isEmpty())
                ? tipoDocumento.trim()
                : "General";
        if (resolvedTipo.length() > 100) {
            throw new IllegalArgumentException("El tipo de documento admite hasta 100 caracteres");
        }

        String correlativo = generarCorrelativo(titulo, resolvedTipo);
        Instant registeredAt = clock.instant();
        Instant deadline = slaService != null
                ? slaService.calculateDeadline(resolvedTipo, titulo, registeredAt)
                : com.capstone.sistema.flow.util.BusinessDaysCalculator.calculateDeadline(registeredAt, 5);

        Solicitud solicitud = new Solicitud(
                flujo,
                emisor,
                titulo.trim(),
                descripcion != null ? descripcion.trim() : "",
                estadoPendiente,
                etapa
        );
        solicitud.captureRegistration(registeredAt);
        solicitud.setTipoDocumento(resolvedTipo);
        solicitud.captureAreas(emisor.getArea() != null && emisor.getArea().isActivo() ? emisor.getArea().getId() : null,
                flujo.getArea() != null ? flujo.getArea().getId() : null);
        solicitud.setCorrelativo(correlativo);
        solicitud.setDeadline(deadline);
        solicitud = solicitudRepository.saveAndFlush(solicitud);
        for (FlujoEtapa step : integrity.orderedStages(flujo)) integrity.requireResponsibility(solicitud, step);

        String storageKey;
        try {
            storageKey = storageService.uploadFile(file);
            registrarEliminacionEnRollback(storageKey);
        } catch (Exception e) {
            log.error("Error al almacenar archivo en MinIO: {}", e.getMessage(), e);
            throw new RuntimeException("Error al almacenar el archivo adjunto: " + e.getMessage(), e);
        }

        Documento documento = new Documento(
                solicitud,
                formato,
                file.getOriginalFilename(),
                file.getContentType() != null ? file.getContentType() : "application/octet-stream",
                storageKey,
                file.getSize(),
                1,
                true
        );
        documento = documentoRepository.save(documento);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                null,
                estadoPendiente,
                accionCrear,
                emisor,
                "Registro inicial de solicitud y carga de documento",
                "{}"
        );
        transicion.captureEtapas(null, etapa);
        transicion.captureTimestamp(registeredAt);
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarNuevaSolicitud(solicitud, transicion, notificarEmail);
        auditService.registerUserManagementEvent("CREAR_SOLICITUD", emisor,
                "Registro de solicitud '" + solicitud.getTitulo() + "' con archivo: " + documento.getNombreArchivo());

        log.info("Solicitud creada exitosamente: id={}, emisor={}, archivo={}, email={}",
                solicitud.getId(), emisor.getEmail(), documento.getNombreArchivo(), notificarEmail);

        return new CrearSolicitudResponse(
                solicitud.getId(),
                documento.getId(),
                estadoPendiente.getCodigo(),
                "Documento registrado correctamente y solicitud enviada a revisión",
                solicitud.getCorrelativo(),
                solicitud.getDeadline()
        );
    }

    @Transactional
    public SolicitudResponse aprobar(UUID solicitudId) {
        return aprobar(solicitudId, false);
    }

    @Transactional
    public SolicitudResponse aprobar(UUID solicitudId, boolean notificarEmail) {
        return aprobar(solicitudId, notificarEmail, null);
    }

    @Transactional
    public SolicitudResponse aprobar(UUID solicitudId, boolean notificarEmail, Long version) {
        Solicitud solicitud = concurrency.lockRequest(solicitudId, version);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "aprobar");
        rbac.authorize(solicitudId, Permiso.SOLICITUD_APROBAR);
        integrity.requireCurrentStage(solicitud);
        UserAccount currentUser = getAuthenticatedUser();
        FlujoEtapa origen = solicitud.getFlujoEtapa();
        List<FlujoEtapa> etapas = integrity.orderedStages(solicitud.getFlujoDefinicion());
        FlujoEtapa siguiente = origen.getOrden() < etapas.size() ? etapas.get(origen.getOrden()) : null;
        if (siguiente != null) integrity.requireResponsibility(solicitud, siguiente);
        Instant decisionAt = clock.instant();
        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        EstadoSolicitud destino = siguiente == null ? getEstado("APROBADO") : getEstado("PENDIENTE_REVISION");
        solicitud.setEstadoSolicitud(destino);
        if (siguiente != null) solicitud.setFlujoEtapa(siguiente);
        solicitudRepository.saveAndFlush(solicitud);
        SolicitudTransicion transicion = new SolicitudTransicion(solicitud, null, estadoOrigen, destino,
                getAccion("APROBAR"), currentUser, "Etapa '" + origen.getNombre() + "' aprobada por " + getNombreCompleto(currentUser), "{}");
        transicion.captureEtapas(origen, solicitud.getFlujoEtapa());
        captureDecision(transicion, decisionAt);
        solicitudTransicionRepository.save(transicion);
        if (siguiente == null) notificacionService.notificarAprobacion(solicitud, transicion, currentUser, notificarEmail);
        else notificacionService.notificarSiguienteEtapa(solicitud, transicion, currentUser, notificarEmail);
        auditService.registerUserManagementEvent("APROBAR_SOLICITUD", currentUser,
                "Solicitud " + solicitudId + ": etapa " + origen.getOrden() + " → " + solicitud.getFlujoEtapa().getOrden()
                        + ", estado=" + destino.getCodigo() + ", versión=" + solicitud.getVersion());
        log.info("Solicitud {}: etapa {} aprobada; destino={}, etapa={}", solicitudId, origen.getOrden(), destino.getCodigo(), solicitud.getFlujoEtapa().getOrden());
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse rechazar(UUID solicitudId, String motivo) {
        return rechazar(solicitudId, motivo, false);
    }

    @Transactional
    public SolicitudResponse rechazar(UUID solicitudId, String motivo, boolean notificarEmail) {
        return rechazar(solicitudId, motivo, notificarEmail, null);
    }

    @Transactional
    public SolicitudResponse rechazar(UUID solicitudId, String motivo, boolean notificarEmail, Long version) {
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new IllegalArgumentException("El motivo del rechazo es obligatorio");
        }

        String motivoNormalizado = motivo.trim();

        Solicitud solicitud = concurrency.lockRequest(solicitudId, version);
        rbac.authorize(solicitudId, Permiso.SOLICITUD_RECHAZAR);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "rechazar");
        integrity.requireCurrentStage(solicitud);

        UserAccount currentUser = getAuthenticatedUser();

        EstadoSolicitud estadoRechazado = getEstado("RECHAZADO");
        AccionUsuario accionRechazar = getAccion("RECHAZAR");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoRechazado);
        Instant decisionAt = clock.instant();
        solicitudRepository.saveAndFlush(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoRechazado,
                accionRechazar,
                currentUser,
                motivoNormalizado,
                "{}"
        );
        captureDecision(transicion, decisionAt);
        transicion.captureEtapas(solicitud.getFlujoEtapa(), solicitud.getFlujoEtapa());
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarRechazo(solicitud, transicion, currentUser, motivoNormalizado, notificarEmail);
        auditService.registerUserManagementEvent("RECHAZAR_SOLICITUD", currentUser,
                "Rechazo de solicitud '" + solicitud.getTitulo() + "'. Motivo: " + motivoNormalizado);

        log.info("Solicitud {} rechazada por {}: motivo={} (email={})", solicitudId, currentUser.getEmail(), motivoNormalizado, notificarEmail);
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse pedirCorreccion(UUID solicitudId, String observacion) {
        return pedirCorreccion(solicitudId, observacion, false);
    }

    @Transactional
    public SolicitudResponse pedirCorreccion(UUID solicitudId, String observacion, boolean notificarEmail) {
        return pedirCorreccion(solicitudId, observacion, notificarEmail, null);
    }

    @Transactional
    public SolicitudResponse pedirCorreccion(UUID solicitudId, String observacion, boolean notificarEmail, Long version) {
        if (observacion == null || observacion.trim().isEmpty()) {
            throw new IllegalArgumentException("La observación es obligatoria para solicitar correcciones");
        }

        Solicitud solicitud = concurrency.lockRequest(solicitudId, version);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "pedir corrección sobre");

        UserAccount currentUser = getAuthenticatedUser();
        rbac.authorize(solicitudId, Permiso.SOLICITUD_PEDIR_CORRECCION);
        integrity.requireCurrentStage(solicitud);

        EstadoSolicitud estadoCorreccion = getEstado("CORRECCION_REQUERIDA");
        AccionUsuario accionCorreccion = getAccion("PEDIR_CORRECCION");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoCorreccion);
        Instant decisionAt = clock.instant();
        solicitudRepository.saveAndFlush(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoCorreccion,
                accionCorreccion,
                currentUser,
                observacion.trim(),
                "{}"
        );
        captureDecision(transicion, decisionAt);
        transicion.captureEtapas(solicitud.getFlujoEtapa(), solicitud.getFlujoEtapa());
        transicion = solicitudTransicionRepository.save(transicion);

        Observacion obs = new Observacion(
                solicitud,
                transicion,
                currentUser,
                observacion.trim()
        );
        observacionRepository.save(obs);

        notificacionService.notificarCorreccionRequerida(solicitud, transicion, currentUser, observacion.trim(), notificarEmail);
        auditService.registerUserManagementEvent("PEDIR_CORRECCION", currentUser,
                "Solicitud de corrección para '" + solicitud.getTitulo() + "'. Observación: " + observacion.trim());

        log.info("Corrección requerida para solicitud {} por {}: observacion={} (email={})",
                solicitudId, currentUser.getEmail(), observacion.trim(), notificarEmail);
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse reenviar(UUID solicitudId, String titulo, String descripcion, MultipartFile nuevoArchivo) {
        return reenviar(solicitudId, titulo, descripcion, nuevoArchivo, false);
    }

    @Transactional
    public SolicitudResponse reenviar(UUID solicitudId, String titulo, String descripcion, MultipartFile nuevoArchivo, boolean notificarEmail) {
        return reenviar(solicitudId, titulo, descripcion, nuevoArchivo, notificarEmail, null);
    }

    @Transactional
    public SolicitudResponse reenviar(UUID solicitudId, String titulo, String descripcion, MultipartFile nuevoArchivo, boolean notificarEmail, Long version) {
        Solicitud solicitud = concurrency.lockRequest(solicitudId, version);
        rbac.authorize(solicitudId, Permiso.SOLICITUD_REENVIAR);
        validarEstadoActual(solicitud, "CORRECCION_REQUERIDA", "reenviar");
        integrity.requireCurrentStage(solicitud);

        UserAccount currentUser = getAuthenticatedUser();
        boolean isAdmin = rbac.context().admin();
        if (!solicitud.getEmisor().getId().equals(currentUser.getId()) && !isAdmin) {
            throw new UnauthorizedActionException("Solo el emisor original puede reenviar la solicitud corregida");
        }

        if (titulo != null && titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("El título del documento es obligatorio");
        }
        if (titulo != null) {
            solicitud.setTitulo(titulo.trim());
        }
        if (descripcion != null) {
            solicitud.setDescripcion(descripcion.trim());
        }

        if (nuevoArchivo != null && !nuevoArchivo.isEmpty()) {
            validarArchivo(nuevoArchivo);
            String extension = extraerExtension(nuevoArchivo.getOriginalFilename());
            FormatoDocumento formato = getOrCreateFormato(extension);

            Documento documentoPrevio = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId).orElse(null);
            int nuevaVersion = documentoPrevio != null ? documentoPrevio.getVersion() + 1 : 1;

            String storageKey;
            try {
                storageKey = storageService.uploadFile(nuevoArchivo);
                registrarEliminacionEnRollback(storageKey);
            } catch (Exception e) {
                log.error("Error al almacenar archivo corregido en MinIO: {}", e.getMessage(), e);
                throw new RuntimeException("Error al almacenar el nuevo archivo adjunto: " + e.getMessage(), e);
            }

            if (documentoPrevio != null) {
                documentoPrevio.setVigente(false);
                documentoRepository.save(documentoPrevio);
            }

            Documento nuevoDocumento = new Documento(
                    solicitud,
                    formato,
                    nuevoArchivo.getOriginalFilename(),
                    nuevoArchivo.getContentType() != null ? nuevoArchivo.getContentType() : "application/octet-stream",
                    storageKey,
                    nuevoArchivo.getSize(),
                    nuevaVersion,
                    true
            );
            documentoRepository.save(nuevoDocumento);
        }

        List<Observacion> observaciones = observacionRepository.findBySolicitud_IdAndResueltaFalse(solicitudId);
        for (Observacion obs : observaciones) {
            obs.setResuelta(true);
            observacionRepository.save(obs);
        }

        EstadoSolicitud estadoPendiente = getEstado("PENDIENTE_REVISION");
        AccionUsuario accionReenviar = getAccion("REENVIAR");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoPendiente);
        solicitudRepository.saveAndFlush(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoPendiente,
                accionReenviar,
                currentUser,
                "Solicitud subsanada y reenviada para nueva revisión",
                "{}"
        );
        transicion.captureTimestamp(clock.instant());
        transicion.captureEtapas(solicitud.getFlujoEtapa(), solicitud.getFlujoEtapa());
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarReenvio(solicitud, transicion, notificarEmail);
        auditService.registerUserManagementEvent("REENVIAR_SOLICITUD", currentUser,
                "Reenvío de solicitud corregida '" + solicitud.getTitulo() + "'");

        log.info("Solicitud {} reenviada a revisión por {} (email={})", solicitudId, currentUser.getEmail(), notificarEmail);
        return toDto(solicitud);
    }

    private void registrarEliminacionEnRollback(String storageKey) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            log.warn("No existe una transacción activa para registrar la compensación del archivo {}", storageKey);
            return;
        }

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status != TransactionSynchronization.STATUS_ROLLED_BACK) {
                    return;
                }

                try {
                    storageService.deleteFile(storageKey);
                    log.info("Archivo {} eliminado de MinIO después del rollback del reenvío", storageKey);
                } catch (Exception ex) {
                    log.error("No fue posible compensar el archivo {} en MinIO después del rollback", storageKey, ex);
                }
            }
        });
    }

    @Transactional(readOnly = true)
    public SolicitudResponse obtenerDetalle(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        UserAccount currentUser = getAuthenticatedUser();
        validarAccesoSolicitud(solicitud, currentUser);
        return toDto(solicitud);
    }

    @Transactional(readOnly = true)
    public List<SolicitudResponse> listarMisSolicitudes() {
        UserAccount currentUser = getAuthenticatedUser();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        return solicitudRepository.findAll(rbac.visible(Permiso.SOLICITUD_CONSULTAR)
                .and((r,q,b)->b.equal(r.get("emisor").get("id"),currentUser.getId())),Sort.by(Sort.Direction.DESC,"createdAt","id"))
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public PaginaSolicitudesPendientesResponse listarRevisionesPendientes(
            String nombreArchivo,
            String emisor,
            Instant fechaDesde,
            Instant fechaHasta,
            String estado,
            int pagina,
            int tamanio
    ) {
        UserAccount currentUser = getAuthenticatedUser();
        rbac.require(Permiso.REVISION_CONSULTAR);

        String estadoEfectivo = estado == null || estado.isBlank() ? "PENDIENTE_REVISION" : estado;

        Specification<Solicitud> specification = Specification
                .where(SolicitudSpecifications.conEstado(estadoEfectivo))
                .and(SolicitudSpecifications.conNombreArchivo(nombreArchivo))
                .and(SolicitudSpecifications.emitidaPor(emisor))
                .and(rbac.visible(Permiso.REVISION_CONSULTAR)).and(rbac.visible(Permiso.SOLICITUD_CONSULTAR))
                .and(SolicitudSpecifications.creadaDesde(fechaDesde))
                .and(SolicitudSpecifications.creadaHasta(fechaHasta));

        Pageable pageable = PageRequest.of(pagina, tamanio, Sort.by(Sort.Direction.DESC, "createdAt", "id"));
        Page<Solicitud> solicitudes = solicitudRepository.findAll(specification, pageable);
        Map<UUID, Documento> documentosVigentes = documentosVigentesPorSolicitud(solicitudes.getContent());

        Instant evaluatedAt = clock.instant();
        List<SolicitudPendienteResponse> contenido = solicitudes.getContent().stream()
                .map(solicitud -> toPendienteDto(solicitud, documentosVigentes.get(solicitud.getId()), evaluatedAt))
                .toList();

        return new PaginaSolicitudesPendientesResponse(
                contenido,
                solicitudes.getNumber(),
                solicitudes.getSize(),
                solicitudes.getTotalElements(),
                solicitudes.getTotalPages(),
                solicitudes.isFirst(),
                solicitudes.isLast()
        );
    }

    @Transactional(readOnly = true)
    public DashboardResponse obtenerResumenDashboard() {
        UserAccount currentUser = getAuthenticatedUser();

        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        List<Solicitud> pendientesRevision = solicitudRepository.findAll(
                rbac.visible(Permiso.SOLICITUD_CONSULTAR).and(rbac.visible(Permiso.REVISION_CONSULTAR))
                .and(SolicitudSpecifications.conEstado("PENDIENTE_REVISION"))
                .and(rbac.visible(Permiso.SOLICITUD_APROBAR)), Sort.by(Sort.Direction.DESC,"createdAt","id"));
        List<Solicitud> misSolicitudes = solicitudRepository.findAll(rbac.visible(Permiso.SOLICITUD_CONSULTAR)
                .and((r,q,b)->b.equal(r.get("emisor").get("id"),currentUser.getId())),Sort.by(Sort.Direction.DESC,"createdAt","id"));
        // Filtrar las que requieren corrección por parte del usuario
        List<Solicitud> misCorreccionesRequeridas = misSolicitudes.stream()
                .filter(s -> "CORRECCION_REQUERIDA".equalsIgnoreCase(s.getEstadoSolicitud().getCodigo()) && rbac.can(s.getId(),Permiso.SOLICITUD_REENVIAR))
                .toList();

        // Filtrar solicitudes emitidas que siguen en trámite (PENDIENTE_REVISION o CORRECCION_REQUERIDA)
        List<SolicitudResponse> misSolicitudesPendientes = misSolicitudes.stream()
                .filter(s -> {
                    String codigo = s.getEstadoSolicitud().getCodigo();
                    return "PENDIENTE_REVISION".equalsIgnoreCase(codigo) || "CORRECCION_REQUERIDA".equalsIgnoreCase(codigo);
                })
                .map(this::toDto)
                .toList();

        // 3. Construir lista unificada de acciones pendientes
        List<AccionPendienteResponse> accionesPendientes = new ArrayList<>();

        // Agregar revisiones pendientes
        for (Solicitud s : pendientesRevision) {
            Documento vigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
            accionesPendientes.add(new AccionPendienteResponse(
                    s.getId(),
                    s.getTitulo(),
                    "REVISION",
                    "Requiere tu revisión y decisión",
                    s.getEstadoSolicitud().getCodigo(),
                    getNombreCompleto(s.getEmisor()),
                    s.getEmisor().getEmail(),
                    vigente != null ? vigente.getNombreArchivo() : "",
                    vigente != null ? vigente.getVersion() : 1,
                    s.getCreatedAt(),
                    null
            ));
        }

        // Agregar correcciones pendientes del usuario
        for (Solicitud s : misCorreccionesRequeridas) {
            Documento vigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
            List<Observacion> observaciones = observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(s.getId());
            String ultimaObsTexto = null;
            if (!observaciones.isEmpty()) {
                ultimaObsTexto = observaciones.stream()
                        .filter(o -> !o.isResuelta())
                        .reduce((first, second) -> second)
                        .map(Observacion::getContenido)
                        .orElse(observaciones.get(observaciones.size() - 1).getContenido());
            }

            accionesPendientes.add(new AccionPendienteResponse(
                    s.getId(),
                    s.getTitulo(),
                    "CORRECCION",
                    "Requiere subsanación de observaciones",
                    s.getEstadoSolicitud().getCodigo(),
                    getNombreCompleto(s.getEmisor()),
                    s.getEmisor().getEmail(),
                    vigente != null ? vigente.getNombreArchivo() : "",
                    vigente != null ? vigente.getVersion() : 1,
                    s.getUpdatedAt() != null ? s.getUpdatedAt() : s.getCreatedAt(),
                    ultimaObsTexto
            ));
        }

        // Ordenar las acciones por fecha descendente
        accionesPendientes.sort((a, b) -> {
            if (a.fecha() == null && b.fecha() == null) return 0;
            if (a.fecha() == null) return 1;
            if (b.fecha() == null) return -1;
            return b.fecha().compareTo(a.fecha());
        });

        MetricasResponse metricas = null;
        try {
            Long defaultAreaId = (currentUser.getArea() != null) ? currentUser.getArea().getId() : null;
            metricas = obtenerMetricas(defaultAreaId);
        } catch (Exception e) {
            log.warn("No se pudieron cargar métricas para dashboard: {}", e.getMessage());
        }

        return new DashboardResponse(accionesPendientes, misSolicitudesPendientes, metricas);
    }

    @Transactional(readOnly = true)
    public List<TransicionResponse> obtenerHistorial(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId); // Valida que exista
        rbac.authorize(solicitudId,Permiso.HISTORIAL_CONSULTAR);

        return solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAscIdAsc(solicitudId)
                .stream()
                .map(t -> new TransicionResponse(
                        t.getId(),
                        t.getEstadoOrigen() != null ? t.getEstadoOrigen().getCodigo() : "INICIAL",
                        t.getEstadoDestino().getCodigo(),
                        t.getAccionUsuario().getAccion(),
                        t.getUsuario().getEmail(),
                        getNombreCompleto(t.getUsuario()),
                        t.getComentario(),
                        t.getDentroSla(),
                        t.getCreatedAt(),
                        EtapaSolicitudResponse.from(t.getEtapaOrigen()),
                        EtapaSolicitudResponse.from(t.getEtapaDestino())
                ))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<ObservacionResponse> obtenerObservaciones(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        UserAccount currentUser = getAuthenticatedUser();
        rbac.authorize(solicitudId,Permiso.OBSERVACION_CONSULTAR);
        return observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solicitudId)
                .stream()
                .map(o -> new ObservacionResponse(
                        o.getId(),
                        o.getContenido(),
                        o.isResuelta(),
                        o.getUsuario().getEmail(),
                        getNombreCompleto(o.getUsuario()),
                        o.getCreatedAt()
                ))
                .toList();
    }

    @Transactional
    public InputStream descargarDocumento(UUID solicitudId) throws Exception {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        UserAccount currentUser = getAuthenticatedUser();
        rbac.authorize(solicitudId,Permiso.DOCUMENTO_DESCARGAR);

        Documento documento = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new SolicitudNotFoundException("No se encontró un documento vigente para la solicitud " + solicitudId));

        if (documento == null || documento.getStorageKey() == null || documento.getStorageKey().isBlank()) {
            throw new DocumentoNoDisponibleException("El archivo no está disponible.");
        }

        auditService.registerUserManagementEvent("DESCARGAR_DOCUMENTO", currentUser,
                "Descarga de documento: " + documento.getNombreArchivo() + " (Solicitud: " + solicitudId + ")");

        try {
            return storageService.downloadFile(documento.getStorageKey());
        } catch (io.minio.errors.MinioException | java.io.FileNotFoundException e) {
            throw new DocumentoNoDisponibleException("El archivo no está disponible.", e);
        } catch (Exception e) {
            if (e instanceof DocumentoNoDisponibleException de) {
                throw de;
            }
            throw new DocumentoNoDisponibleException("El archivo no está disponible.", e);
        }
    }

    @Transactional(readOnly = true)
    public Documento obtenerDocumentoVigente(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        UserAccount currentUser = getAuthenticatedUser();
        rbac.authorize(solicitudId,Permiso.DOCUMENTO_DESCARGAR);

        return documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new SolicitudNotFoundException("No se encontró un documento vigente para la solicitud " + solicitudId));
    }

    private void validarArchivo(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidDocumentFormatException("Es obligatorio adjuntar un archivo de documento");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new InvalidDocumentFormatException("El archivo excede el tamaño máximo permitido de 10 MB");
        }
        String filename = file.getOriginalFilename();
        if (filename == null || !filename.contains(".")) {
            throw new InvalidDocumentFormatException("El archivo debe tener una extensión válida (.pdf, .docx, .doc, .xml, .txt, .xlsx, .xls)");
        }
        String extension = extraerExtension(filename);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new InvalidDocumentFormatException(
                    "Formato de archivo no permitido (." + extension + "). Formatos aceptados: .doc, .docx, .pdf, .xml, .txt, .xlsx, .xls"
            );
        }
    }

    private String extraerExtension(String filename) {
        if (filename == null) return "";
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == filename.length() - 1) return "";
        return filename.substring(dotIndex + 1).toLowerCase(Locale.ROOT);
    }

    private void validarEstadoActual(Solicitud solicitud, String estadoEsperado, String accionNombre) {
        String estadoActual = solicitud.getEstadoSolicitud().getCodigo();
        if (!estadoActual.equalsIgnoreCase(estadoEsperado)) {
            throw new InvalidTransitionException(
                    "No se puede " + accionNombre + " la solicitud porque su estado actual es '" +
                    estadoActual + "' (se requiere '" + estadoEsperado + "')"
            );
        }
    }

    private Solicitud getSolicitudEntity(UUID id) {
        return rbac.readable(id);
    }

    private UserAccount getAuthenticatedUser() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new UnauthorizedActionException("Usuario no autenticado o no encontrado en el sistema"));
    }

    private EstadoSolicitud getEstado(String codigo) {
        return estadoSolicitudRepository.findByCodigoIgnoreCase(codigo)
                .orElseThrow(() -> new IllegalStateException("Estado no configurado en el sistema: " + codigo));
    }

    private AccionUsuario getAccion(String accion) {
        return accionUsuarioRepository.findByAccionIgnoreCase(accion)
                .orElseThrow(() -> new IllegalStateException("Acción no configurada en el sistema: " + accion));
    }

    private FormatoDocumento getOrCreateFormato(String extension) {
        return formatoDocumentoRepository.findByTipoIgnoreCase(extension)
                .orElseGet(() -> formatoDocumentoRepository.save(new FormatoDocumento(extension)));
    }

    private SolicitudResponse toDto(Solicitud s) {
        Documento docVigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
        DocumentoResponse docDto = docVigente != null ? new DocumentoResponse(
                docVigente.getId(),
                docVigente.getNombreArchivo(),
                docVigente.getContentType(),
                docVigente.getSizeBytes(),
                docVigente.getVersion(),
                docVigente.isVigente(),
                docVigente.getCreatedAt()
        ) : null;

        return new SolicitudResponse(
                s.getId(),
                s.getCorrelativo(),
                s.getTitulo(),
                s.getTipoDocumento(),
                s.getDescripcion(),
                s.getEstadoSolicitud().getCodigo(),
                s.getEmisor().getId(),
                getNombreCompleto(s.getEmisor()),
                s.getEmisor().getEmail(),
                docDto,
                s.getDeadline(),
                calculateSlaStatus(s.getDeadline()),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                allowedActions(s),
                s.getVersion(),
                EtapaSolicitudResponse.from(s.getFlujoEtapa())
        );
    }

    private Map<UUID, Documento> documentosVigentesPorSolicitud(List<Solicitud> solicitudes) {
        if (solicitudes.isEmpty()) {
            return Map.of();
        }

        List<UUID> solicitudIds = solicitudes.stream().map(Solicitud::getId).toList();
        return documentoRepository.findBySolicitud_IdInAndVigenteTrue(solicitudIds).stream()
                .collect(Collectors.toMap(
                        documento -> documento.getSolicitud().getId(),
                        Function.identity(),
                        (primero, ignorado) -> primero
                ));
    }

    private SolicitudPendienteResponse toPendienteDto(Solicitud solicitud, Documento documentoVigente, Instant evaluatedAt) {
        return new SolicitudPendienteResponse(
                solicitud.getId(),
                solicitud.getCorrelativo(),
                solicitud.getTitulo(),
                documentoVigente != null ? documentoVigente.getNombreArchivo() : null,
                getNombreCompleto(solicitud.getEmisor()),
                solicitud.getEmisor().getEmail(),
                solicitud.getCreatedAt(),
                solicitud.getDeadline(),
                calculateSlaStatus(solicitud.getDeadline(), evaluatedAt),
                solicitud.getEstadoSolicitud().getCodigo()
        );
    }

    public String generarCorrelativo(String titulo) {
        return generarCorrelativo(titulo, null);
    }

    public String generarCorrelativo(String titulo, String tipoDocumento) {
        String prefix = "DOC";
        String candidateBase = (tipoDocumento != null && !tipoDocumento.isBlank()) ? tipoDocumento : titulo;
        if (candidateBase != null) {
            String lower = candidateBase.toLowerCase();
            if (lower.contains("contrat")) {
                prefix = "CONT";
            } else if (lower.contains("factur")) {
                prefix = "FAC";
            } else if (lower.contains("memorand") || lower.contains("memoránd")) {
                prefix = "MEM";
            } else if (lower.contains("inform")) {
                prefix = "INF";
            }
        }
        long sequence = solicitudRepository.count() + 1;
        String candidate = String.format("%s-%03d", prefix, sequence);
        while (solicitudRepository.existsByCorrelativo(candidate)) {
            sequence++;
            candidate = String.format("%s-%03d", prefix, sequence);
        }
        return candidate;
    }

    public String calculateSlaStatus(Instant deadline) {
        return calculateSlaStatus(deadline, clock.instant());
    }

    public String calculateSlaStatus(Instant deadline, Instant evaluadoEn) {
        return SlaStatusCalculator.status(deadline, evaluadoEn);
    }

    private void captureDecision(SolicitudTransicion transition, Instant decisionAt) {
        transition.captureTimestamp(decisionAt);
        transition.setDentroSla(SlaStatusCalculator.withinDeadline(transition.getSolicitud().getDeadline(), decisionAt));
    }

    private String getNombreCompleto(UserAccount u) {
        if (u == null) return "";
        String f = u.getFirstName() != null ? u.getFirstName() : "";
        String l = u.getLastName() != null ? u.getLastName() : "";
        String full = (f + " " + l).trim();
        return full.isEmpty() ? u.getEmail() : full;
    }

    @Transactional(readOnly = true)
    public PaginaSolicitudesPendientesResponse consultarSolicitudes(
            String q,
            String correlativo,
            String solicitante,
            Long areaId,
            String estado,
            Instant fechaDesde,
            Instant fechaHasta,
            int pagina,
            int tamanio
    ) {
        UserAccount currentUser = getAuthenticatedUser();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);

        Specification<Solicitud> spec = Specification
                .where(SolicitudSpecifications.conEstado(estado))
                .and(SolicitudSpecifications.conCorrelativo(correlativo))
                .and(SolicitudSpecifications.emitidaPor(solicitante))
                .and(rbac.visible(Permiso.SOLICITUD_CONSULTAR)).and(SolicitudSpecifications.conArea(areaId))
                .and(SolicitudSpecifications.conBusquedaTexto(q))
                .and(SolicitudSpecifications.creadaDesde(fechaDesde))
                .and(SolicitudSpecifications.creadaHasta(fechaHasta));

        Pageable pageable = PageRequest.of(pagina, tamanio, Sort.by(Sort.Direction.DESC, "createdAt", "id"));
        Page<Solicitud> solicitudes = solicitudRepository.findAll(spec, pageable);
        Map<UUID, Documento> documentosVigentes = documentosVigentesPorSolicitud(solicitudes.getContent());

        Instant evaluatedAt = clock.instant();
        List<SolicitudPendienteResponse> contenido = solicitudes.getContent().stream()
                .map(solicitud -> toPendienteDto(solicitud, documentosVigentes.get(solicitud.getId()), evaluatedAt))
                .toList();

        return new PaginaSolicitudesPendientesResponse(
                contenido,
                solicitudes.getNumber(),
                solicitudes.getSize(),
                solicitudes.getTotalElements(),
                solicitudes.getTotalPages(),
                solicitudes.isFirst(),
                solicitudes.isLast()
        );
    }

    @Transactional(readOnly = true)
    public MetricasResponse obtenerMetricas(Long areaId) {
        UserAccount currentUser = getAuthenticatedUser();
        rbac.require(Permiso.METRICAS_CONSULTAR);
        Long areaEfectiva = areaId;
        String areaNombre = null;
        if (areaId != null && areaRepository != null) {
            areaNombre = areaRepository.findById(areaId).map(Area::getNombre).orElse(null);
        }
        if (areaNombre == null && areaId != null) {
            if (currentUser.getArea() != null && areaId.equals(currentUser.getArea().getId())) {
                areaNombre = currentUser.getArea().getNombre();
            } else if (rbac.context() != null && rbac.context().areasAdministradas() != null) {
                areaNombre = rbac.context().areasAdministradas().stream()
                        .filter(a -> areaId.equals(a.id()))
                        .map(RbacDtos.AreaItem::nombre)
                        .findFirst()
                        .orElse(null);
            }
        }
        Specification<Solicitud> baseSpec = rbac.visible(Permiso.METRICAS_CONSULTAR)
                .and(rbac.visible(Permiso.SOLICITUD_CONSULTAR)).and(SolicitudSpecifications.conArea(areaId));
        long totalGeneral = solicitudRepository.count(baseSpec);
        long pendientes = solicitudRepository.count(baseSpec.and(SolicitudSpecifications.conEstado("PENDIENTE_REVISION")));
        long aprobadas = solicitudRepository.count(baseSpec.and(SolicitudSpecifications.conEstado("APROBADO")));
        long rechazadas = solicitudRepository.count(baseSpec.and(SolicitudSpecifications.conEstado("RECHAZADO")));
        long correccion = solicitudRepository.count(baseSpec.and(SolicitudSpecifications.conEstado("CORRECCION_REQUERIDA")));

        long dentroSla = countSla(baseSpec, true);
        long fueraSla = countSla(baseSpec, false);

        return new MetricasResponse(
                pendientes,
                aprobadas,
                rechazadas,
                correccion,
                totalGeneral,
                dentroSla,
                fueraSla,
                areaEfectiva,
                areaNombre
        );
    }

    @Transactional(readOnly = true)
    public List<MetricasResponse> obtenerMetricasPorArea() {
        UserAccount currentUser = getAuthenticatedUser();
        rbac.require(Permiso.METRICAS_CONSULTAR);

        List<Long> areaIds;
        if (rbac.context().admin()) {
            if (areaRepository != null) {
                areaIds = areaRepository.findAll().stream()
                        .filter(Area::isActivo)
                        .sorted(Comparator.comparing(Area::getNombre, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)))
                        .map(Area::getId)
                        .toList();
            } else {
                areaIds = List.of();
            }
        } else {
            List<Long> ids = new ArrayList<>();
            if (rbac.context().areasAdministradas() != null && !rbac.context().areasAdministradas().isEmpty()) {
                rbac.context().areasAdministradas().stream()
                        .sorted(Comparator.comparing(RbacDtos.AreaItem::nombre, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)))
                        .forEach(item -> {
                            if (!ids.contains(item.id())) {
                                ids.add(item.id());
                            }
                        });
            } else if (currentUser.getArea() != null) {
                ids.add(currentUser.getArea().getId());
            }
            areaIds = ids;
        }

        return areaIds.stream()
                .map(this::obtenerMetricas)
                .toList();
    }

    public void validarAccesoSolicitud(Solicitud solicitud, UserAccount currentUser) {
        rbac.authorize(solicitud.getId(),Permiso.SOLICITUD_CONSULTAR);
    }

    private long countSla(Specification<Solicitud> requests, boolean within) {
        return solicitudTransicionRepository.count((root, query, builder) -> {
            var request = query.from(Solicitud.class);
            var predicate = requests.toPredicate(request, query, builder);
            return builder.and(predicate, builder.equal(request.get("id"),root.get("solicitud").get("id")),
                    builder.equal(root.get("dentroSla"),within));
        });
    }

    public List<String> allowedActions(Solicitud request) {
        var result = new ArrayList<String>();
        String state = request.getEstadoSolicitud().getCodigo();
        for (Permiso p : List.of(Permiso.SOLICITUD_APROBAR,Permiso.SOLICITUD_RECHAZAR,Permiso.SOLICITUD_PEDIR_CORRECCION,
                Permiso.SOLICITUD_REENVIAR,Permiso.DOCUMENTO_DESCARGAR,Permiso.IA_CONSULTAR,Permiso.IA_SOLICITAR)) {
            if (RbacAccessService.isDecision(p) && !"PENDIENTE_REVISION".equalsIgnoreCase(state)) continue;
            if (p==Permiso.SOLICITUD_REENVIAR && !"CORRECCION_REQUERIDA".equalsIgnoreCase(state)) continue;
            if (rbac.can(request.getId(),p)) result.add(switch(p) {
                case SOLICITUD_APROBAR -> "APROBAR"; case SOLICITUD_RECHAZAR -> "RECHAZAR";
                case SOLICITUD_PEDIR_CORRECCION -> "PEDIR_CORRECCION"; case SOLICITUD_REENVIAR -> "REENVIAR";
                case DOCUMENTO_DESCARGAR -> "DESCARGAR"; case IA_CONSULTAR -> "CONSULTAR_IA";
                case IA_SOLICITAR -> "SOLICITAR_IA"; default -> p.name();
            });
        }
        return List.copyOf(result);
    }
}
