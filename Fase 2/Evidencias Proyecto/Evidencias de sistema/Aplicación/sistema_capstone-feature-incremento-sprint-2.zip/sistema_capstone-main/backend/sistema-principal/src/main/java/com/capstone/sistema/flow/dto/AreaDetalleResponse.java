package com.capstone.sistema.flow.dto;

public record AreaDetalleResponse(Long id, String nombre, Boolean activa) {
}
