package com.capstone.sistema.rbac.exception;

import com.capstone.sistema.rbac.controller.RbacController;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.bind.MissingServletRequestParameterException;

@RestControllerAdvice(assignableTypes=RbacController.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RbacValidationHandler {
    @ExceptionHandler({MethodArgumentNotValidException.class,HttpMessageNotReadableException.class,
            MethodArgumentTypeMismatchException.class,MissingServletRequestParameterException.class})
    public ResponseEntity<ProblemDetail> invalid(Exception exception) {
        var detail=ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,"Revise los campos y parámetros de la solicitud.");
        detail.setTitle("Datos de control de acceso inválidos");
        detail.setProperty("codigo","RBAC_DATOS_INVALIDOS");
        if(exception instanceof MethodArgumentNotValidException validation) {
            java.util.Map<String,String> fields=new java.util.LinkedHashMap<>();
            validation.getBindingResult().getFieldErrors().forEach(e->fields.putIfAbsent(e.getField(),e.getDefaultMessage()));
            detail.setProperty("invalidFields",fields);
        }
        return ResponseEntity.badRequest().body(detail);
    }
}

