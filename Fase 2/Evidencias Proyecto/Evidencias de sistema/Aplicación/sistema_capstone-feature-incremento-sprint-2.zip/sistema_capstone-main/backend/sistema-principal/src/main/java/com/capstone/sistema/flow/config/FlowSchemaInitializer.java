package com.capstone.sistema.flow.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
@Order(-90)
public class FlowSchemaInitializer implements ApplicationRunner {
    private final DataSource dataSource;
    public FlowSchemaInitializer(DataSource dataSource) { this.dataSource=dataSource; }
    @Override
    public void run(ApplicationArguments args) {
        var script=new ResourceDatabasePopulator(new ClassPathResource("db/flow-schema.sql"));
        script.setSeparator("^^^ END OF SCRIPT ^^^");
        script.execute(dataSource);
    }
}
