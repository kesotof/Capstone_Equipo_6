package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Consulta escalar de capacidades limitada a los IDs de una página autorizada. */
@Repository
public class MyRequestsCapabilityRepository {
    private final EntityManager entityManager;

    public MyRequestsCapabilityRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Set<UUID> findAuthorizedIds(List<UUID> pageIds, Specification<Solicitud> permission) {
        if (pageIds.isEmpty()) {
            return Set.of();
        }
        var builder = entityManager.getCriteriaBuilder();
        var query = builder.createQuery(UUID.class);
        var request = query.from(Solicitud.class);
        query.select(request.get("id")).distinct(true).where(
                request.get("id").in(pageIds), permission.toPredicate(request, query, builder));
        return Set.copyOf(entityManager.createQuery(query).getResultList());
    }
}
