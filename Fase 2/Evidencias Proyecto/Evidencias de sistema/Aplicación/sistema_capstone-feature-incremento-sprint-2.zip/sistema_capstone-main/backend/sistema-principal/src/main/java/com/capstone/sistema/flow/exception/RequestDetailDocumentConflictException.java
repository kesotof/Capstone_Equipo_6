package com.capstone.sistema.flow.exception;

public class RequestDetailDocumentConflictException extends RuntimeException {
    public RequestDetailDocumentConflictException() {
        super("La solicitud tiene más de un documento vigente. Su información documental requiere revisión.");
    }
}
