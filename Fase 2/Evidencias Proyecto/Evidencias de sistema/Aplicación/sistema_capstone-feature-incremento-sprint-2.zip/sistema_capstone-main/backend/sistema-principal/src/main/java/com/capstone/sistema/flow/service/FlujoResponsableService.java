package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.RolFlujoRepository;
import jakarta.persistence.EntityManager;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class FlujoResponsableService {
    private final FlujoDefinicionRepository definitions;
    private final SolicitudRepository requests;
    private final RolFlujoRepository roles;
    private final FlujoReviewerResolver reviewers;
    private final FlujoIntegrityService integrity;
    private final FlujoConcurrencyService concurrency;
    private final FlujoConfigService config;
    private final RbacAccessService access;
    private final RbacManagementService security;
    private final NotificacionService notifications;
    private final JdbcTemplate jdbc;
    private final EntityManager entityManager;

    public FlujoResponsableService(FlujoDefinicionRepository definitions, SolicitudRepository requests,
            RolFlujoRepository roles, FlujoReviewerResolver reviewers, FlujoIntegrityService integrity,
            FlujoConcurrencyService concurrency, FlujoConfigService config, RbacAccessService access,
            RbacManagementService security, NotificacionService notifications, JdbcTemplate jdbc, EntityManager entityManager) {
        this.definitions=definitions; this.requests=requests; this.roles=roles; this.reviewers=reviewers;
        this.integrity=integrity; this.concurrency=concurrency; this.config=config; this.access=access;
        this.security=security; this.notifications=notifications; this.jdbc=jdbc; this.entityManager=entityManager;
    }

    public ResponsableOptionsResponse options(Long flowId, Long stepId) {
        FlujoDefinicion flow=definitions.findById(flowId).orElseThrow(RbacException::missing);
        access.manageFlow(areaId(flow));
        protectedBase(flow);
        FlujoEtapa current=stepId==null?null:step(flow,stepId);
        List<Solicitud> affected=current==null?List.of():affected(flow,current);
        List<UserAccount> eligible=reviewers.eligibleUsers();
        List<ResponsableOptionsResponse.Usuario> users=eligible.stream().filter(user->{
            FlujoEtapa proposal=new FlujoEtapa(flow,current==null?1:current.getOrden(),"Revisión",user);
            return affected.stream().allMatch(request->access.canOperateAtStage(user,request,proposal));
        }).map(FlujoResponsableService::userOption).toList();
        List<ResponsableOptionsResponse.Rol> roleOptions=new ArrayList<>();
        if (flow.getArea()!=null && flow.getArea().isActivo()) {
            for (var role:roles.findAll()) {
                FlujoEtapa proposal=new FlujoEtapa(flow,current==null?1:current.getOrden(),"Revisión");
                proposal.asignarRol(role);
                List<UserAccount> pool=reviewers.candidates(proposal);
                if (pool.isEmpty() || affected.stream().anyMatch(request->pool.stream()
                        .noneMatch(user->access.canOperateAtStage(user,request,proposal)))) continue;
                roleOptions.add(new ResponsableOptionsResponse.Rol(role.getId(),role.getNombreVisible(),pool.size(),
                        pool.stream().map(FlujoResponsableService::userOption).toList()));
            }
        }
        roleOptions.sort(Comparator.comparing(ResponsableOptionsResponse.Rol::nombre,String.CASE_INSENSITIVE_ORDER));
        return new ResponsableOptionsResponse(users,List.copyOf(roleOptions),flow.getVersion());
    }

    @Transactional
    public FlujoResponse assign(Long flowId, Long stepId, AsignarResponsableRequest request) {
        Set<String> dependencies=security.prepareMutation();
        FlujoDefinicion flow=concurrency.lockDefinition(flowId);
        access.manageFlow(areaId(flow));
        concurrency.checkVersion(flow.getVersion(),request.version(),"FLUJO_VERSION_CONFLICTO");
        protectedBase(flow);
        FlujoEtapa stage=step(flow,stepId);
        Assignment previous=assignment(stage);
        List<Solicitud> affected=affected(flow,stage);
        for (Solicitud pending:affected) {
            jdbc.queryForObject("select id from solicitud where id=? for update",UUID.class,pending.getId());
            entityManager.refresh(pending);
        }
        Assignment proposed=new Assignment(request.tipoAsignacion(),request.revisorId(),request.rolRevisorId());
        if (previous.equals(proposed)) {
            reviewers.requireAvailable(stage);
            affected.forEach(pending->reviewers.requireForRequest(pending,stage));
            return config.toResponse(flow);
        }
        Map<UUID,Set<UUID>> previousRecipients=new HashMap<>();
        for (Solicitud pending:affected) {
            if (pending.getFlujoEtapa().getId().equals(stepId)) previousRecipients.put(pending.getId(),
                    new HashSet<>(reviewers.forRequest(pending,stage).stream().map(UserAccount::getId).toList()));
        }
        reviewers.assign(stage,request.tipoAsignacion(),request.revisorId(),request.rolRevisorId());
        entityManager.flush();
        affected.forEach(pending->reviewers.requireForRequest(pending,stage));
        long current=0;
        for (Solicitud pending:affected) {
            if (!pending.getFlujoEtapa().getId().equals(stepId)) continue;
            pending.touch();
            requests.saveAndFlush(pending);
            current++;
            if ("PENDIENTE_REVISION".equalsIgnoreCase(pending.getEstadoSolicitud().getCodigo()))
                notifications.notificarReasignacion(pending,previousRecipients.getOrDefault(pending.getId(),Set.of()));
        }
        flow.setCompleto(integrity.complete(flow));
        flow.touch();
        definitions.saveAndFlush(flow);
        security.finishMutation(dependencies);
        security.auditChange("ASIGNAR_RESPONSABLE_ETAPA",flowId,Map.of("etapaId",stepId,"asignacion",previous),
                Map.of("etapaId",stepId,"asignacion",assignment(stage),"solicitudesActuales",current,"version",flow.getVersion()));
        return config.toResponse(flow);
    }

    private List<Solicitud> affected(FlujoDefinicion flow, FlujoEtapa stage) {
        return requests.findOpenByFlow(flow.getId()).stream()
                .filter(request->request.getFlujoEtapa()!=null && request.getFlujoEtapa().getOrden()<=stage.getOrden()).toList();
    }
    private static FlujoEtapa step(FlujoDefinicion flow, Long id) {
        return flow.getEtapas().stream().filter(stage->Objects.equals(stage.getId(),id)).findFirst().orElseThrow(RbacException::missing);
    }
    private static void protectedBase(FlujoDefinicion flow) {
        if (Long.valueOf(1).equals(flow.getId())) throw RbacException.conflict("FLUJO_BASE_PROTEGIDO","El flujo base conserva su resolución de responsables y no admite reasignación explícita.");
    }
    private static Long areaId(FlujoDefinicion flow) { return flow.getArea()==null?null:flow.getArea().getId(); }
    private record Assignment(TipoAsignacionRevisor tipoAsignacion, UUID revisorId, Long rolRevisorId) {}
    private static Assignment assignment(FlujoEtapa stage) {
        return new Assignment(stage.getTipoAsignacion(),stage.getRevisor()==null?null:stage.getRevisor().getId(),
                stage.getRolRevisor()==null?null:stage.getRolRevisor().getId());
    }
    private static ResponsableOptionsResponse.Usuario userOption(UserAccount user) {
        String name=(Objects.toString(user.getFirstName(),"")+" "+Objects.toString(user.getLastName(),"")).trim();
        return new ResponsableOptionsResponse.Usuario(user.getId(),name.isEmpty()?user.getEmail():name,user.getEmail(),
                user.getArea()==null?null:user.getArea().getNombre());
    }
}
