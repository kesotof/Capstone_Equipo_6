package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

    List<Notificacion> findByDestinatario_IdOrderByCreatedEnDesc(UUID destinatarioId);

    List<Notificacion> findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(UUID destinatarioId);

    long countByDestinatario_IdAndLeidaFalse(UUID destinatarioId);
}
