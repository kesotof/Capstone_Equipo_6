package com.capstone.sistema.flow.dto;

import java.util.List;

public record DashboardResponse(
        List<AccionPendienteResponse> accionesPendientes,
        List<SolicitudResponse> misSolicitudesPendientes,
        MetricasResponse metricas
) {
    public DashboardResponse(
            List<AccionPendienteResponse> accionesPendientes,
            List<SolicitudResponse> misSolicitudesPendientes
    ) {
        this(accionesPendientes, misSolicitudesPendientes, null);
    }
}
