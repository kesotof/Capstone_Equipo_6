package com.capstone.sistema.flow.model;

public enum TipoAccionEtapa {
    REVISION
}
