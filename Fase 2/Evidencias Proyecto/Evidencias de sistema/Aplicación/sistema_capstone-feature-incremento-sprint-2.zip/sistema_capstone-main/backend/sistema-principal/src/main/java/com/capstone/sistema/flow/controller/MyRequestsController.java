package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.MyRequestsPageResponse;
import com.capstone.sistema.flow.service.MyRequestsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/requests", produces = MediaType.APPLICATION_JSON_VALUE)
@PreAuthorize("isAuthenticated()")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Seguimiento de solicitudes", description = "Bandejas propia y autorizada con estado y etapa actuales")
public class MyRequestsController {
    private final MyRequestsService requests;

    public MyRequestsController(MyRequestsService requests) {
        this.requests = requests;
    }

    @Operation(summary = "Consultar mis solicitudes",
            description = "Solicitudes emitidas por la cuenta local del JWT sub, intersectadas con SOLICITUD_CONSULTAR. "
                    + "Orden fijo updatedAt descendente e id ascendente, también para ADMIN. No acepta emisor ni área.")
    @Parameters({
            @Parameter(name = "query", in = ParameterIn.QUERY, description = "Título o correlativo parcial literal", schema = @Schema(type = "string", maxLength = 200)),
            @Parameter(name = "status", in = ParameterIn.QUERY, schema = @Schema(type = "string", allowableValues = {"PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO"})),
            @Parameter(name = "page", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "0", minimum = "0")),
            @Parameter(name = "size", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "10", minimum = "1", maximum = "100"))
    })
    @GetMapping("/my-requests")
    public ResponseEntity<MyRequestsPageResponse> own(@Parameter(hidden = true) @RequestParam MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(requests.own(parameters));
    }

    @Operation(summary = "Consultar solicitudes según mi acceso",
            description = "Conjunto visible por RBAC, incluidas las propias cuando corresponda. "
                    + "Área registrada y demás filtros se intersectan con la autorización antes de contar y paginar.")
    @Parameters({
            @Parameter(name = "query", in = ParameterIn.QUERY, description = "Título o correlativo parcial literal", schema = @Schema(type = "string", maxLength = 200)),
            @Parameter(name = "status", in = ParameterIn.QUERY, schema = @Schema(type = "string", allowableValues = {"PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO"})),
            @Parameter(name = "areaId", in = ParameterIn.QUERY, description = "Área de origen o flujo capturada", schema = @Schema(type = "integer", format = "int64", minimum = "1")),
            @Parameter(name = "page", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "0", minimum = "0")),
            @Parameter(name = "size", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "10", minimum = "1", maximum = "100"))
    })
    @GetMapping("/accessible")
    public ResponseEntity<MyRequestsPageResponse> accessible(@Parameter(hidden = true) @RequestParam MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(requests.accessible(parameters));
    }
}
