package com.capstone.sistema.flow.consumer;

import com.capstone.sistema.flow.service.AiAnalysisService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AiResultListenerTest {

    @Mock
    private AiAnalysisService aiAnalysisService;

    @InjectMocks
    private AiResultListener listener;

    @Test
    @DisplayName("Debe delegar el resultado de IA recibido desde RabbitMQ al servicio")
    void shouldDelegateAiResultToService() {
        Map<String, Object> payload = Map.of(
                "analysisId", "analysis-123",
                "status", "COMPLETADO",
                "resultado", "{}"
        );

        listener.onAiResult(payload);

        verify(aiAnalysisService).procesarResultado(payload);
    }
}
