package com.capstone.sistema.flow.service;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.exception.AiAnalysisNotFoundException;
import com.capstone.sistema.flow.exception.SolicitudNotFoundException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.AiAnalysisRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AiAnalysisServiceTest {

    @Mock
    private SolicitudRepository solicitudRepository;

    @Mock
    private DocumentoRepository documentoRepository;

    @Mock
    private AiAnalysisRepository aiAnalysisRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private CurrentUserResolver currentUserResolver;

    private ObjectMapper objectMapper;
    private AiAnalysisService service;

    private UUID solicitudId;
    private Solicitud solicitud;
    private Documento documento;
    private UserAccount usuario;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        service = new AiAnalysisService(
                solicitudRepository,
                documentoRepository,
                aiAnalysisRepository,
                rabbitTemplate,
                currentUserResolver,
                objectMapper
        );

        solicitudId = UUID.randomUUID();
        usuario = new UserAccount("kc-operador", "operador@capstone.local", "Juan", "Perez", true, Set.of(new com.capstone.sistema.users.model.RolFlujo("APPROVER")));
        FlujoDefinicion flujo = new FlujoDefinicion("Revision Simple", "Flujo basico");
        EstadoSolicitud estado = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");

        solicitud = new Solicitud(flujo, usuario, "Contrato Servicios", "Descripcion contrato", estado, etapa);

        FormatoDocumento formato = new FormatoDocumento("PDF");
        documento = new Documento(solicitud, formato, "contrato.pdf", "application/pdf", "storage/contrato.pdf", 1024L, 1, true);
        org.springframework.test.util.ReflectionTestUtils.setField(documento, "id", UUID.randomUUID());
    }

    @Test
    @DisplayName("Debe crear un análisis PENDIENTE y publicar evento a RabbitMQ si no hay caché previa")
    void shouldCreatePendingAnalysisAndPublishToRabbitMQ() {
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)).thenReturn(Optional.of(documento));
        when(aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId)).thenReturn(Optional.empty());
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuario));

        when(aiAnalysisRepository.save(any(AiAnalysis.class))).thenAnswer(invocation -> {
            AiAnalysis entity = invocation.getArgument(0);
            org.springframework.test.util.ReflectionTestUtils.setField(entity, "id", UUID.randomUUID());
            return entity;
        });

        AiAnalysisResponse response = service.solicitarAnalisis(solicitudId, "Regla personalizada", false);

        assertNotNull(response);
        assertEquals(EstadoAnalisis.PENDIENTE, response.estado());
        assertFalse(response.cached());

        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.AI_ANALYSIS_ROUTING_KEY),
                any(Map.class)
        );
    }

    @Test
    @DisplayName("Debe retornar resultado en caché (cached=true) sin llamar a RabbitMQ si el documento y prompt no cambiaron")
    void shouldReturnCachedAnalysisWhenDocumentAndPromptAreIdentical() {
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)).thenReturn(Optional.of(documento));

        AiAnalysis cachedAnalysis = new AiAnalysis(solicitud, documento, "Mismo Prompt", usuario);
        org.springframework.test.util.ReflectionTestUtils.setField(cachedAnalysis, "id", UUID.randomUUID());
        cachedAnalysis.setEstado(EstadoAnalisis.COMPLETADO);
        cachedAnalysis.setPuntaje(92);
        cachedAnalysis.setValido(true);
        cachedAnalysis.setObservaciones("Documento perfecto");
        cachedAnalysis.setRecomendacionesJson("[\"Sin observaciones\"]");

        when(aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId))
                .thenReturn(Optional.of(cachedAnalysis));

        AiAnalysisResponse response = service.solicitarAnalisis(solicitudId, "Mismo Prompt", false);

        assertNotNull(response);
        assertTrue(response.cached());
        assertEquals(EstadoAnalisis.COMPLETADO, response.estado());
        assertEquals(92, response.puntaje());
        assertEquals(List.of("Sin observaciones"), response.recomendaciones());

        verify(rabbitTemplate, never()).convertAndSend(anyString(), anyString(), any(Object.class));
    }

    @Test
    @DisplayName("Debe forzar nuevo análisis si se envía force=true aunque exista caché")
    void shouldForceNewAnalysisWhenForceIsTrue() {
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)).thenReturn(Optional.of(documento));

        AiAnalysis cachedAnalysis = new AiAnalysis(solicitud, documento, "Prompt", usuario);
        org.springframework.test.util.ReflectionTestUtils.setField(cachedAnalysis, "id", UUID.randomUUID());
        cachedAnalysis.setEstado(EstadoAnalisis.COMPLETADO);
        when(aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId))
                .thenReturn(Optional.of(cachedAnalysis));

        when(aiAnalysisRepository.save(any(AiAnalysis.class))).thenAnswer(invocation -> {
            AiAnalysis entity = invocation.getArgument(0);
            org.springframework.test.util.ReflectionTestUtils.setField(entity, "id", UUID.randomUUID());
            return entity;
        });

        AiAnalysisResponse response = service.solicitarAnalisis(solicitudId, "Prompt", true);

        assertNotNull(response);
        assertFalse(response.cached());
        verify(rabbitTemplate).convertAndSend(eq(RabbitConfig.EXCHANGE_NAME), eq(RabbitConfig.AI_ANALYSIS_ROUTING_KEY), any(Map.class));
    }

    @Test
    @DisplayName("Debe lanzar SolicitudNotFoundException si la solicitud no existe")
    void shouldThrowWhenSolicitudNotFound() {
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.empty());

        assertThrows(SolicitudNotFoundException.class, () ->
                service.solicitarAnalisis(solicitudId, null, false)
        );
    }

    @Test
    @DisplayName("Debe procesar el resultado de RabbitMQ y actualizar la entidad a COMPLETADO")
    void shouldProcessAiResultAndUpdateEntity() {
        UUID analysisId = UUID.randomUUID();
        AiAnalysis analysis = new AiAnalysis(solicitud, documento, "prompt", usuario);
        when(aiAnalysisRepository.findById(analysisId)).thenReturn(Optional.of(analysis));

        Map<String, Object> payload = Map.of(
                "analysisId", analysisId.toString(),
                "solicitudId", solicitudId.toString(),
                "status", "COMPLETADO",
                "resultado", "{\"valido\": true, \"puntaje\": 88, \"observaciones\": \"Correcto\", \"recomendaciones\": [\"Aclarar fecha\"]}",
                "modeloUsado", "meta-llama/llama-3.3-70b-instruct:free"
        );

        service.procesarResultado(payload);

        assertEquals(EstadoAnalisis.COMPLETADO, analysis.getEstado());
        assertEquals(88, analysis.getPuntaje());
        assertTrue(analysis.getValido());
        assertEquals("Correcto", analysis.getObservaciones());
        assertTrue(analysis.getRecomendacionesJson().contains("Aclarar fecha"));
        assertEquals("meta-llama/llama-3.3-70b-instruct:free", analysis.getModeloUsado());
        assertNotNull(analysis.getCompletedAt());

        verify(aiAnalysisRepository).save(analysis);
    }

    @Test
    @DisplayName("Debe obtener el último análisis correctamente o lanzar AiAnalysisNotFoundException si no existe")
    void shouldGetLatestAnalysisOrThrow() {
        when(solicitudRepository.existsById(solicitudId)).thenReturn(true);

        AiAnalysis analysis = new AiAnalysis(solicitud, documento, "prompt", usuario);
        analysis.setEstado(EstadoAnalisis.COMPLETADO);
        analysis.setPuntaje(90);
        when(aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId))
                .thenReturn(Optional.of(analysis));

        AiAnalysisResponse response = service.obtenerUltimoAnalisis(solicitudId);
        assertNotNull(response);
        assertEquals(90, response.puntaje());

        when(aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId))
                .thenReturn(Optional.empty());

        assertThrows(AiAnalysisNotFoundException.class, () -> service.obtenerUltimoAnalisis(solicitudId));
    }
}
