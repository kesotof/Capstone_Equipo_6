package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.dto.DocumentSearchFiltersResponse;
import com.capstone.sistema.doc.dto.DocumentSearchItemResponse;
import com.capstone.sistema.doc.dto.DocumentSearchPageResponse;
import com.capstone.sistema.doc.exception.DocumentSearchException;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentSearchCatalogRepository;
import com.capstone.sistema.doc.repository.DocumentSearchSpecification;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.DocumentDownloadCapabilityRepository;
import com.capstone.sistema.flow.dto.AreaDetalleResponse;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DocumentSearchService {
    private final SolicitudRepository solicitudes;
    private final DocumentoRepository documentos;
    private final AreaRepository areas;
    private final DocumentSearchCatalogRepository catalogo;
    private final DocumentSearchQueryNormalizer normalizer;
    private final RbacAccessService rbac;
    private final DocumentDownloadCapabilityRepository downloadCapabilities;

    public DocumentSearchService(SolicitudRepository solicitudes, DocumentoRepository documentos, AreaRepository areas,
                                 DocumentSearchCatalogRepository catalogo, DocumentSearchQueryNormalizer normalizer,
                                 RbacAccessService rbac, DocumentDownloadCapabilityRepository downloadCapabilities) {
        this.solicitudes = solicitudes;
        this.documentos = documentos;
        this.areas = areas;
        this.catalogo = catalogo;
        this.normalizer = normalizer;
        this.rbac = rbac;
        this.downloadCapabilities = downloadCapabilities;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public DocumentSearchPageResponse search(Map<String, List<String>> parameters) {
        rbac.clearContext();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        var filters = normalizer.normalize(parameters);
        var page = solicitudes.findAll(rbac.visible(Permiso.SOLICITUD_CONSULTAR)
                .and(new DocumentSearchSpecification(filters)), filters.pageable());
        List<UUID> ids = page.getContent().stream().map(Solicitud::getId).toList();
        Set<UUID> downloadable = downloadCapabilities.authorizedIds(ids, rbac.visible(Permiso.DOCUMENTO_DESCARGAR));
        Map<UUID, Documento> current = new HashMap<>();
        if (!ids.isEmpty()) {
            for (Documento document : documentos.findBySolicitud_IdInAndVigenteTrue(ids)) {
                if (current.putIfAbsent(document.getSolicitud().getId(), document) != null) {
                    throw DocumentSearchException.inconsistentDocument();
                }
            }
        }
        Set<Long> areaIds = new HashSet<>();
        page.forEach(request -> addAreas(areaIds, request.getAreaOrigenId(), request.getAreaFlujoId()));
        Map<Long, Area> registeredAreas = findAreas(areaIds);
        List<DocumentSearchItemResponse> content = page.getContent().stream().map(request -> {
            Documento document = current.get(request.getId());
            if (document == null) throw new IllegalStateException("No se encontró el documento vigente del resultado.");
            return item(request, document, registeredAreas, downloadable.contains(request.getId()));
        }).toList();
        return new DocumentSearchPageResponse(content, page.getNumber(), page.getSize(), page.getTotalElements(),
                page.getTotalPages(), page.isFirst(), page.isLast(), filters.order());
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public DocumentSearchFiltersResponse filters(Map<String, List<String>> parameters) {
        rbac.clearContext();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        if (!parameters.isEmpty()) throw DocumentSearchException.invalid("El catálogo de filtros no admite parámetros.");
        var entries = catalogo.findVisible(rbac.visible(Permiso.SOLICITUD_CONSULTAR));
        Set<Long> areaIds = new HashSet<>();
        entries.forEach(entry -> addAreas(areaIds, entry.areaOrigenId(), entry.areaFlujoId()));
        Map<Long, Area> registeredAreas = findAreas(areaIds);
        List<AreaDetalleResponse> areaOptions = areaIds.stream().map(id -> area(id, registeredAreas))
                .sorted(Comparator.comparing(AreaDetalleResponse::nombre, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))
                        .thenComparing(AreaDetalleResponse::id)).toList();
        List<String> types = entries.stream().map(DocumentSearchCatalogRepository.CatalogEntry::documentType)
                .distinct().sorted().toList();
        return new DocumentSearchFiltersResponse(types, areaOptions, DocumentSearchQueryNormalizer.STATUSES);
    }

    private DocumentSearchItemResponse item(Solicitud request, Documento document, Map<Long, Area> registeredAreas, boolean downloadable) {
        String name = ((request.getEmisor().getFirstName() == null ? "" : request.getEmisor().getFirstName()) + " "
                + (request.getEmisor().getLastName() == null ? "" : request.getEmisor().getLastName())).trim();
        return new DocumentSearchItemResponse(document.getId(), request.getId(), request.getCorrelativo(), request.getTitulo(),
                document.getNombreArchivo(), document.getFormatoDocumento().getTipo().toUpperCase(Locale.ROOT),
                document.getContentType(), document.getSizeBytes(), document.getVersion(), request.getEstadoSolicitud().getCodigo(),
                name.isEmpty() ? "Usuario no disponible" : name, area(request.getAreaOrigenId(), registeredAreas),
                area(request.getAreaFlujoId(), registeredAreas), request.getCreatedAt(), request.getUpdatedAt(),
                document.getCreatedAt(), "/api/requests/" + request.getId() + "/detail",
                downloadable ? "/api/documents/" + document.getId() + "/download" : null);
    }

    private void addAreas(Set<Long> ids, Long origin, Long flow) {
        if (origin != null) ids.add(origin);
        if (flow != null) ids.add(flow);
    }

    private Map<Long, Area> findAreas(Set<Long> ids) {
        return ids.isEmpty() ? Map.of() : areas.findAllById(ids).stream()
                .collect(Collectors.toMap(Area::getId, Function.identity()));
    }

    private AreaDetalleResponse area(Long id, Map<Long, Area> registeredAreas) {
        if (id == null) return null;
        Area area = registeredAreas.get(id);
        return new AreaDetalleResponse(id, area == null ? null : area.getNombre(), area == null ? null : area.isActivo());
    }
}
