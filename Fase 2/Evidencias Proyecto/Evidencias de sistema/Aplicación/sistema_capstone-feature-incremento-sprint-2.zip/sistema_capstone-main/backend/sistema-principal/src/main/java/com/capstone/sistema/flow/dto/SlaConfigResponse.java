package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record SlaConfigResponse(
        Long id,
        String tipoDocumento,
        int plazoDias,
        Instant createdAt,
        Instant updatedAt
) {}
