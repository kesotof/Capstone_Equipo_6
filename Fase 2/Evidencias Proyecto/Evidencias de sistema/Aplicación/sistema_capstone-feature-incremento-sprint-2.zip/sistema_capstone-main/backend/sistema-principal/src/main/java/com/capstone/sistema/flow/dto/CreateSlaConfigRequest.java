package com.capstone.sistema.flow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public record CreateSlaConfigRequest(
        @NotBlank(message = "El tipo de documento es obligatorio")
        @Size(max = 100, message = "El tipo de documento no puede exceder los 100 caracteres")
        String tipoDocumento,

        @Min(value = 1, message = "El plazo en días hábiles debe ser mayor o igual a 1")
        @JsonDeserialize(using = SlaDaysDeserializer.class)
        int plazoDias
) {}
