package com.capstone.sistema.flow.repository;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.data.jpa.domain.Specification;

import java.time.Instant;
import java.util.UUID;

/** Especificaciones componibles para consultar la bandeja de revisión. */
public final class SolicitudSpecifications {

    private SolicitudSpecifications() {
    }

    public static Specification<Solicitud> conEstado(String estado) {
        return (root, query, builder) -> estado == null || estado.isBlank()
                ? builder.conjunction()
                : builder.equal(
                        builder.lower(root.get("estadoSolicitud").get("codigo")),
                        estado.trim().toLowerCase()
                );
    }

    public static Specification<Solicitud> emitidaPor(String emisor) {
        return (root, query, builder) -> {
            if (emisor == null || emisor.isBlank()) {
                return builder.conjunction();
            }

            String filtro = "%" + emisor.trim().toLowerCase() + "%";
            Join<Solicitud, UserAccount> usuario = root.join("emisor", JoinType.INNER);
            Expression<String> nombreCompleto = builder.lower(
                    builder.concat(builder.concat(usuario.get("firstName"), " "), usuario.get("lastName"))
            );

            return builder.or(
                    builder.like(builder.lower(usuario.get("email")), filtro),
                    builder.like(builder.lower(usuario.get("firstName")), filtro),
                    builder.like(builder.lower(usuario.get("lastName")), filtro),
                    builder.like(nombreCompleto, filtro)
            );
        };
    }

    public static Specification<Solicitud> conNombreArchivo(String nombreArchivo) {
        return (root, query, builder) -> {
            if (nombreArchivo == null || nombreArchivo.isBlank()) {
                return builder.conjunction();
            }

            Subquery<UUID> documentoVigente = query.subquery(UUID.class);
            Root<Documento> documento = documentoVigente.from(Documento.class);
            documentoVigente.select(documento.get("id"));
            documentoVigente.where(
                    builder.equal(documento.get("solicitud").get("id"), root.get("id")),
                    builder.isTrue(documento.get("vigente")),
                    builder.like(
                            builder.lower(documento.get("nombreArchivo")),
                            "%" + nombreArchivo.trim().toLowerCase() + "%"
                    )
            );
            return builder.exists(documentoVigente);
        };
    }

    public static Specification<Solicitud> creadaDesde(Instant fechaDesde) {
        return (root, query, builder) -> fechaDesde == null
                ? builder.conjunction()
                : builder.greaterThanOrEqualTo(root.get("createdAt"), fechaDesde);
    }

    public static Specification<Solicitud> creadaHasta(Instant fechaHasta) {
        return (root, query, builder) -> fechaHasta == null
                ? builder.conjunction()
                : builder.lessThanOrEqualTo(root.get("createdAt"), fechaHasta);
    }

    public static Specification<Solicitud> sinEmisor(UUID emisorId) {
        return (root, query, builder) -> emisorId == null
                ? builder.conjunction()
                : builder.notEqual(root.get("emisor").get("id"), emisorId);
    }

    public static Specification<Solicitud> conArea(Long areaId) {
        return (root, query, builder) -> {
            if (areaId == null) {
                return builder.conjunction();
            }
            return builder.or(builder.equal(root.get("areaOrigenId"),areaId),
                    builder.equal(root.get("areaFlujoId"),areaId));
        };
    }

    public static Specification<Solicitud> conCorrelativo(String correlativo) {
        return (root, query, builder) -> correlativo == null || correlativo.isBlank()
                ? builder.conjunction()
                : builder.equal(builder.lower(root.get("correlativo")), correlativo.trim().toLowerCase());
    }

    public static Specification<Solicitud> conBusquedaTexto(String q) {
        return (root, query, builder) -> {
            if (q == null || q.isBlank()) {
                return builder.conjunction();
            }
            String pattern = "%" + q.trim().toLowerCase() + "%";
            return builder.or(
                    builder.like(builder.lower(root.get("titulo")), pattern),
                    builder.like(builder.lower(root.get("descripcion")), pattern),
                    builder.like(builder.lower(root.get("correlativo")), pattern)
            );
        };
    }
}
