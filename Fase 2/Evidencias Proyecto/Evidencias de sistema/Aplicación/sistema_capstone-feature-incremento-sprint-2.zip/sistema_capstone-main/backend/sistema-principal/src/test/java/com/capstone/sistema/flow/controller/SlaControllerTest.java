package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.CreateSlaConfigRequest;
import com.capstone.sistema.flow.dto.SlaConfigResponse;
import com.capstone.sistema.flow.dto.UpdateSlaConfigRequest;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.service.SlaService;
import com.capstone.sistema.users.repository.AreaRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SlaController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class SlaControllerTest {

    @ParameterizedTest
    @ValueSource(strings = {"3.5", "\"4\"", "true", "2147483648", "null", "0", "-1"})
    void plazosInvalidosSeRechazanSinTruncarlos(String value) throws Exception {
        var admin = jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"));
        mockMvc.perform(post("/api/sla").with(admin).contentType(MediaType.APPLICATION_JSON)
                .content("{\"tipoDocumento\":\"Contrato\",\"plazoDias\":" + value + "}"))
                .andExpect(status().isBadRequest());
        mockMvc.perform(put("/api/sla/1").with(admin).contentType(MediaType.APPLICATION_JSON)
                .content("{\"plazoDias\":" + value + "}"))
                .andExpect(status().isBadRequest());
        org.mockito.Mockito.verifyNoInteractions(slaService);
    }

    @ParameterizedTest
    @ValueSource(strings = {"ROLE_APPROVER", "ROLE_EMISOR", "ROLE_AREA_ADMIN"})
    void todosLosEndpointsRequierenAdministrador(String authority) throws Exception {
        var user = jwt().authorities(new SimpleGrantedAuthority(authority));
        mockMvc.perform(get("/api/sla").with(user)).andExpect(status().isForbidden());
        mockMvc.perform(get("/api/sla/1").with(user)).andExpect(status().isForbidden());
        mockMvc.perform(post("/api/sla").with(user).contentType(MediaType.APPLICATION_JSON)
                .content("{\"tipoDocumento\":\"Contrato\",\"plazoDias\":4}")).andExpect(status().isForbidden());
        mockMvc.perform(put("/api/sla/1").with(user).contentType(MediaType.APPLICATION_JSON)
                .content("{\"plazoDias\":4}")).andExpect(status().isForbidden());
        mockMvc.perform(delete("/api/sla/1").with(user)).andExpect(status().isForbidden());
    }

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private SlaService slaService;

    @MockBean
    private AreaRepository areaRepository;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("GET /api/sla retorna lista de reglas y 200 OK")
    void listAll_retornaLista200Ok() throws Exception {
        SlaConfigResponse r1 = new SlaConfigResponse(1L, "Contrato", 5, Instant.now(), Instant.now());
        SlaConfigResponse r2 = new SlaConfigResponse(2L, "Factura", 3, Instant.now(), Instant.now());

        when(slaService.listAll()).thenReturn(List.of(r1, r2));

        mockMvc.perform(get("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].tipoDocumento").value("Contrato"))
                .andExpect(jsonPath("$[0].plazoDias").value(5))
                .andExpect(jsonPath("$[1].tipoDocumento").value("Factura"))
                .andExpect(jsonPath("$[1].plazoDias").value(3));
    }

    @Test
    @DisplayName("POST /api/sla con rol ADMIN crea regla y responde 201 Created")
    void create_conRolAdmin_retorna201Created() throws Exception {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("Informe Técnico", 4);
        SlaConfigResponse response = new SlaConfigResponse(3L, "Informe Técnico", 4, Instant.now(), Instant.now());

        when(slaService.create(any(CreateSlaConfigRequest.class))).thenReturn(response);

        mockMvc.perform(post("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.tipoDocumento").value("Informe Técnico"))
                .andExpect(jsonPath("$.plazoDias").value(4));

        verify(slaService).create(any(CreateSlaConfigRequest.class));
    }

    @Test
    @DisplayName("POST /api/sla sin rol ADMIN responde 403 Forbidden")
    void create_sinRolAdmin_retorna403Forbidden() throws Exception {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("Informe Técnico", 4);

        mockMvc.perform(post("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("PUT /api/sla/{id} con rol ADMIN actualiza plazo y responde 200 OK")
    void update_conRolAdmin_retorna200Ok() throws Exception {
        UpdateSlaConfigRequest request = new UpdateSlaConfigRequest(6);
        SlaConfigResponse response = new SlaConfigResponse(1L, "Contrato", 6, Instant.now(), Instant.now());

        when(slaService.update(eq(1L), any(UpdateSlaConfigRequest.class))).thenReturn(response);

        mockMvc.perform(put("/api/sla/1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.plazoDias").value(6));

        verify(slaService).update(eq(1L), any(UpdateSlaConfigRequest.class));
    }

    @Test
    @DisplayName("DELETE /api/sla/{id} con rol ADMIN elimina regla y responde 204 No Content")
    void delete_conRolAdmin_retorna204NoContent() throws Exception {
        mockMvc.perform(delete("/api/sla/1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isNoContent());

        verify(slaService).delete(1L);
    }

    @Test
    @DisplayName("POST /api/sla con tipo de documento en blanco responde 400 Bad Request")
    void create_conTipoDocumentoVacio_retorna400BadRequest() throws Exception {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("", 5);

        mockMvc.perform(post("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"))
                .andExpect(jsonPath("$.invalidFields.tipoDocumento").exists());
    }

    @Test
    @DisplayName("POST /api/sla con plazoDias <= 0 responde 400 Bad Request")
    void create_conPlazoDiasInvalido_retorna400BadRequest() throws Exception {
        CreateSlaConfigRequest request = new CreateSlaConfigRequest("Contrato", 0);

        mockMvc.perform(post("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"))
                .andExpect(jsonPath("$.invalidFields.plazoDias").exists());
    }

    @Test
    @DisplayName("POST /api/sla con JSON malformado responde 400 Bad Request (no 500)")
    void create_conJsonMalformado_retorna400BadRequest() throws Exception {
        String jsonMalformado = "{\"tipoDocumento\": \"Contrato\", \"plazoDias\": \"invalido\"}";

        mockMvc.perform(post("/api/sla")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonMalformado))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Cuerpo de solicitud inválido"));
    }

    @Test
    @DisplayName("GET /api/sla/{id} con id que no es número responde 400 Bad Request (no 500)")
    void getById_conIdInvalido_retorna400BadRequest() throws Exception {
        mockMvc.perform(get("/api/sla/not-a-number")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Parámetro inválido"));
    }

    @Test
    @DisplayName("GET /api/sla/{id} inexistente responde 404 Not Found (no 500)")
    void getById_inexistente_retorna404NotFound() throws Exception {
        when(slaService.getById(999L)).thenThrow(new com.capstone.sistema.flow.exception.SlaNotFoundException("Configuración SLA con id 999 no encontrada"));

        mockMvc.perform(get("/api/sla/999")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.title").value("Regla SLA No Encontrada"));
    }
}
