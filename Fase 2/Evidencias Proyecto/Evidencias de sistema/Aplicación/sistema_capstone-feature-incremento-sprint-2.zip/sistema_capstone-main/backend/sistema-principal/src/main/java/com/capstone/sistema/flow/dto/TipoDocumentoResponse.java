package com.capstone.sistema.flow.dto;

public record TipoDocumentoResponse(
        String tipo,
        int plazoDias
) {}
