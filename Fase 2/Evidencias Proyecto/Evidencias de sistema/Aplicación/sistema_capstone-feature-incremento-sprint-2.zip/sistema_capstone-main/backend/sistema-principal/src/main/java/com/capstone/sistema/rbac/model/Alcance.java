package com.capstone.sistema.rbac.model;

public enum Alcance {
    PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA, GLOBAL
}

