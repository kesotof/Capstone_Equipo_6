package com.capstone.sistema.flow.model;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "ai_analysis", indexes = {
        @Index(name = "idx_ai_analysis_solicitud", columnList = "solicitud_id"),
        @Index(name = "idx_ai_analysis_documento", columnList = "documento_id")
})
public class AiAnalysis {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "documento_id")
    private Documento documento;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private EstadoAnalisis estado = EstadoAnalisis.PENDIENTE;

    @Column(name = "prompt_utilizado", columnDefinition = "TEXT")
    private String promptUtilizado;

    private Integer puntaje;

    private Boolean valido;

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @Column(name = "recomendaciones_json", columnDefinition = "TEXT")
    private String recomendacionesJson;

    @Column(name = "resultado_raw", columnDefinition = "TEXT")
    private String resultadoRaw;

    @Column(name = "modelo_usado", length = 100)
    private String modeloUsado;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitado_por_id")
    private UserAccount solicitadoPor;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    protected AiAnalysis() {
    }

    public AiAnalysis(
            Solicitud solicitud,
            Documento documento,
            String promptUtilizado,
            UserAccount solicitadoPor
    ) {
        this.solicitud = solicitud;
        this.documento = documento;
        this.promptUtilizado = promptUtilizado;
        this.solicitadoPor = solicitadoPor;
        this.estado = EstadoAnalisis.PENDIENTE;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public Documento getDocumento() {
        return documento;
    }

    public void setDocumento(Documento documento) {
        this.documento = documento;
    }

    public EstadoAnalisis getEstado() {
        return estado;
    }

    public void setEstado(EstadoAnalisis estado) {
        this.estado = estado;
    }

    public String getPromptUtilizado() {
        return promptUtilizado;
    }

    public void setPromptUtilizado(String promptUtilizado) {
        this.promptUtilizado = promptUtilizado;
    }

    public Integer getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Integer puntaje) {
        this.puntaje = puntaje;
    }

    public Boolean getValido() {
        return valido;
    }

    public void setValido(Boolean valido) {
        this.valido = valido;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getRecomendacionesJson() {
        return recomendacionesJson;
    }

    public void setRecomendacionesJson(String recomendacionesJson) {
        this.recomendacionesJson = recomendacionesJson;
    }

    public String getResultadoRaw() {
        return resultadoRaw;
    }

    public void setResultadoRaw(String resultadoRaw) {
        this.resultadoRaw = resultadoRaw;
    }

    public String getModeloUsado() {
        return modeloUsado;
    }

    public void setModeloUsado(String modeloUsado) {
        this.modeloUsado = modeloUsado;
    }

    public UserAccount getSolicitadoPor() {
        return solicitadoPor;
    }

    public void setSolicitadoPor(UserAccount solicitadoPor) {
        this.solicitadoPor = solicitadoPor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }
}
