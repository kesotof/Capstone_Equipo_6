package com.capstone.sistema.flow.dto;

import java.util.List;
import java.util.UUID;

public record ResponsableOptionsResponse(List<Usuario> usuarios, List<Rol> roles, Long version) {
    public record Usuario(UUID id, String nombre, String email, String areaNombre) {}
    public record Rol(Long id, String nombre, int cantidadUsuarios, List<Usuario> usuarios) {}
}
