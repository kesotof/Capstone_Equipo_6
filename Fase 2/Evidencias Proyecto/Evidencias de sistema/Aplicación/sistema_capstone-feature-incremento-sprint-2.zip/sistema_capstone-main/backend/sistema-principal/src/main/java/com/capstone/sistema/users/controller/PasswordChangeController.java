package com.capstone.sistema.users.controller;

import com.capstone.sistema.users.dto.ChangePasswordRequest;
import com.capstone.sistema.users.dto.ChangePasswordResponse;
import com.capstone.sistema.users.dto.PasswordPolicyResponse;
import com.capstone.sistema.users.service.UserManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Seguridad de la cuenta", description = "Autogestión de credenciales por su titular")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/auth")
@PreAuthorize("isAuthenticated()")
public class PasswordChangeController {
    private final UserManagementService users;

    public PasswordChangeController(UserManagementService users) { this.users = users; }

    @Operation(summary = "Consultar la política efectiva de contraseña")
    @GetMapping("/password-policy")
    public PasswordPolicyResponse policy() { return users.passwordPolicy(); }

    @Operation(summary = "Cambiar la contraseña de la cuenta autenticada", description = "Verifica la contraseña actual, coincidencia y política vigente sin seleccionar otras cuentas.")
    @PostMapping("/change-password")
    public ChangePasswordResponse change(@Valid @RequestBody ChangePasswordRequest request) {
        users.changePassword(request);
        return ChangePasswordResponse.success();
    }
}
