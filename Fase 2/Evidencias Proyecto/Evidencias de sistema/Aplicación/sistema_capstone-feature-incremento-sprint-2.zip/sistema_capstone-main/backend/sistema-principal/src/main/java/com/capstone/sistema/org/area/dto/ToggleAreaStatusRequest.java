package com.capstone.sistema.org.area.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record ToggleAreaStatusRequest(
        @NotNull(message = "El estado activo es obligatorio.") Boolean activo,
        @NotNull(message = "La versión es obligatoria.")
        @PositiveOrZero(message = "La versión no puede ser negativa.") Long version
) {
}
