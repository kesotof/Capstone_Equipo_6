package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.DashboardSummaryResponse;
import com.capstone.sistema.flow.service.DashboardSummaryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("isAuthenticated()")
@SecurityRequirement(name = "bearerAuth")
public class DashboardSummaryController {
    private final DashboardSummaryService dashboard;
    public DashboardSummaryController(DashboardSummaryService dashboard) { this.dashboard = dashboard; }

    @GetMapping(value = "/summary", produces = "application/json")
    @Operation(summary = "Resumen general autorizado por estado y área",
            description = "Intersección de METRICAS_CONSULTAR y SOLICITUD_CONSULTAR. "
                    + "Área de origen capturada con respaldo del área del flujo. Tendencia de emisiones de siete días en Santiago.")
    @Parameters({
            @Parameter(name = "areaId", in = ParameterIn.QUERY, description = "Solo administrador global; excluye sinArea",
                    schema = @Schema(type = "integer", format = "int64", minimum = "1")),
            @Parameter(name = "sinArea", in = ParameterIn.QUERY, description = "Solo administrador global; excluye areaId",
                    schema = @Schema(type = "boolean", allowableValues = {"true"}))
    })
    public ResponseEntity<DashboardSummaryResponse> summary(
            @Parameter(hidden = true) @RequestParam MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(dashboard.summary(parameters));
    }
}
