package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "observacion", indexes = {
        @Index(name = "idx_observacion_solicitud", columnList = "solicitud_id")
})
public class Observacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitud_transicion_id")
    private SolicitudTransicion solicitudTransicion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount usuario;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String contenido;

    @Column(nullable = false)
    private boolean resuelta = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected Observacion() {
    }

    public Observacion(Solicitud solicitud, SolicitudTransicion solicitudTransicion, UserAccount usuario, String contenido) {
        this.solicitud = solicitud;
        this.solicitudTransicion = solicitudTransicion;
        this.usuario = usuario;
        this.contenido = contenido;
        this.resuelta = false;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public SolicitudTransicion getSolicitudTransicion() {
        return solicitudTransicion;
    }

    public void setSolicitudTransicion(SolicitudTransicion solicitudTransicion) {
        this.solicitudTransicion = solicitudTransicion;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public boolean isResuelta() {
        return resuelta;
    }

    public void setResuelta(boolean resuelta) {
        this.resuelta = resuelta;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
