package com.capstone.sistema.flow;

import com.capstone.sistema.audit.model.LogEvento;
import com.capstone.sistema.audit.model.TipoEvento;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.flow.model.AccionUsuario;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.FlujoEtapaRoles;
import com.capstone.sistema.flow.model.Notificacion;
import com.capstone.sistema.flow.model.Observacion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.model.SolicitudTransicion;
import com.capstone.sistema.flow.model.TipoNotificacion;
import com.capstone.sistema.flow.model.Transicion;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class DataModelEntitiesTest {

    @Test
    @DisplayName("Debe instanciar y relacionar correctamente entidades de Organización y Usuario")
    void testOrganizacionYUsuario() {
        Area area = new Area(1L, "Finanzas", true);
        RolFlujo rolAdmin = new RolFlujo(1L, "ADMIN");
        RolFlujo rolApprover = new RolFlujo(2L, "APPROVER");

        UserAccount usuario = new UserAccount(
                "kc-uuid-1",
                "juan.perez@capstone.local",
                "Juan",
                "Perez",
                area,
                true,
                Set.of(rolAdmin, rolApprover)
        );

        assertThat(usuario.getEmail()).isEqualTo("juan.perez@capstone.local");
        assertThat(usuario.getArea().getNombre()).isEqualTo("Finanzas");
        assertThat(usuario.getRoles()).containsExactlyInAnyOrder(SystemRole.ADMIN, SystemRole.APPROVER);
        assertThat(usuario.getRolEntities()).hasSize(2);
    }

    @Test
    @DisplayName("Debe validar máquina de estados: Flujo, Etapas, Transición y Solicitud")
    void testFlujoYSolicitud() {
        Area area = new Area(1L, "Finanzas", true);
        RolFlujo rol = new RolFlujo(2L, "APPROVER");
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@capstone.local", "Emisor", "Doc", area, true, Set.of());
        UserAccount revisor = new UserAccount("kc-revisor", "revisor@capstone.local", "Revisor", "Doc", area, true, Set.of(rol));

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Compras", "Aprobación de compras", area);
        flujo.setCompleto(true);
        FlujoEtapa etapa1 = new FlujoEtapa(flujo, 1, "Revisión Jefatura", revisor);
        flujo.addEtapa(etapa1);

        FlujoEtapaRoles etapaRol = new FlujoEtapaRoles(etapa1, revisor, area, rol);
        etapa1.addRol(etapaRol);

        EstadoSolicitud estadoPendiente = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        EstadoSolicitud estadoAprobado = new EstadoSolicitud(3L, "APROBADO");
        AccionUsuario accionAprobar = new AccionUsuario(2L, "APROBAR");

        Transicion transicion = new Transicion(flujo, estadoPendiente, estadoAprobado, accionAprobar);

        Solicitud solicitud = new Solicitud(
                flujo,
                emisor,
                "Solicitud de Factura #101",
                "Compra de suministros",
                estadoPendiente,
                etapa1
        );

        SolicitudTransicion histTransicion = new SolicitudTransicion(
                solicitud,
                transicion,
                estadoPendiente,
                estadoAprobado,
                accionAprobar,
                revisor,
                "Aprobado conforme",
                "{}"
        );

        assertThat(flujo.getArea().getNombre()).isEqualTo("Finanzas");
        assertThat(flujo.isCompleto()).isTrue();
        assertThat(etapa1.getRevisor().getEmail()).isEqualTo("revisor@capstone.local");
        assertThat(solicitud.getTitulo()).isEqualTo("Solicitud de Factura #101");
        assertThat(solicitud.getEstadoSolicitud().getCodigo()).isEqualTo("PENDIENTE_REVISION");
        assertThat(histTransicion.getAccionUsuario().getAccion()).isEqualTo("APROBAR");
        assertThat(histTransicion.getEstadoDestino().getCodigo()).isEqualTo("APROBADO");
        assertThat(histTransicion.getComentario()).isEqualTo("Aprobado conforme");
    }

    @Test
    @DisplayName("Debe instanciar Documento, Observación y Notificación vinculados a Solicitud")
    void testDocumentoObservacionYNotificacion() {
        FormatoDocumento formatoPdf = new FormatoDocumento(1L, "pdf");
        TipoNotificacion tipoNotif = new TipoNotificacion(1L, "APROBACION");

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Base", "Flujo Base");
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        EstadoSolicitud estado = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        UserAccount usuario = new UserAccount("kc-1", "test@capstone.local", "Test", "User", true, Set.of());

        Solicitud solicitud = new Solicitud(flujo, usuario, "Doc 1", "Desc", estado, etapa);

        Documento doc = new Documento(
                solicitud,
                formatoPdf,
                "documento.pdf",
                "application/pdf",
                "documentos/uuid/v1/documento.pdf",
                1024L,
                1,
                true
        );

        Observacion obs = new Observacion(solicitud, null, usuario, "Corregir firma digital");
        Notificacion notif = new Notificacion(usuario, solicitud, null, tipoNotif, "Aprobado", "Tu documento ha sido aprobado");

        assertThat(doc.getFormatoDocumento().getTipo()).isEqualTo("pdf");
        assertThat(doc.isVigente()).isTrue();
        assertThat(obs.getContenido()).isEqualTo("Corregir firma digital");
        assertThat(obs.isResuelta()).isFalse();
        assertThat(notif.getTipoNotificacion().getTipo()).isEqualTo("APROBACION");
        assertThat(notif.isLeida()).isFalse();
    }

    @Test
    @DisplayName("Debe instanciar y validar LogEvento de Auditoría con TipoEvento")
    void testLogEvento() {
        TipoEvento tipoLogin = new TipoEvento(1L, "LOGIN");
        TipoEvento tipoLogout = new TipoEvento(2L, "LOGOUT");
        UserAccount usuario = new UserAccount("kc-1", "admin@capstone.local", "Admin", "User", true, Set.of());

        LogEvento loginEvent = new LogEvento(tipoLogin, usuario, "192.168.1.100", "Inicio de sesión de admin@capstone.local");
        LogEvento logoutEvent = new LogEvento(tipoLogout, usuario, "192.168.1.100", "Cierre de sesión de admin@capstone.local");

        assertThat(loginEvent.getTipoEvento().getTipo()).isEqualTo("LOGIN");
        assertThat(loginEvent.getIpAddress()).isEqualTo("192.168.1.100");
        assertThat(loginEvent.getDetalle()).contains("Inicio de sesión");

        assertThat(logoutEvent.getTipoEvento().getTipo()).isEqualTo("LOGOUT");
        assertThat(logoutEvent.getDetalle()).contains("Cierre de sesión");
    }
}
