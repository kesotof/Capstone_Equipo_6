package com.capstone.sistema.org.area.controller;

import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.CreateAreaRequest;
import com.capstone.sistema.org.area.dto.PaginaAreasResponse;
import com.capstone.sistema.org.area.dto.ToggleAreaStatusRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.service.AreaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/areas")
@PreAuthorize("hasRole('ADMIN')")
public class AreaController {

    private final AreaService areaService;

    public AreaController(AreaService areaService) {
        this.areaService = areaService;
    }

    @PostMapping
    public ResponseEntity<AreaResponse> create(@Valid @RequestBody CreateAreaRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(areaService.create(request));
    }

    @GetMapping
    public PaginaAreasResponse list(@RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "20") int size,
                                    @RequestParam(required = false) Boolean activo,
                                    @RequestParam(required = false) String q) {
        return areaService.list(page, size, activo, q);
    }

    @PutMapping("/{id}")
    public AreaResponse update(@PathVariable Long id, @Valid @RequestBody UpdateAreaRequest request) {
        return areaService.update(id, request);
    }

    @PatchMapping("/{id}/status")
    public AreaResponse changeStatus(@PathVariable Long id,
                                     @Valid @RequestBody ToggleAreaStatusRequest request) {
        return areaService.changeStatus(id, request);
    }
}
