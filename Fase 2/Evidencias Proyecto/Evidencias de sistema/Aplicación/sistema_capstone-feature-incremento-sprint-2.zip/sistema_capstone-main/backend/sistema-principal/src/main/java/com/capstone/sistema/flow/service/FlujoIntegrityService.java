package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.rbac.exception.RbacException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class FlujoIntegrityService {
    public static final String BASE_NAME = "Revisión Simple";
    private final FlujoReviewerResolver reviewers;

    public FlujoIntegrityService(FlujoReviewerResolver reviewers) { this.reviewers=reviewers; }

    public boolean isBaseIdentity(FlujoDefinicion flow) {
        return Long.valueOf(1).equals(flow.getId()) && BASE_NAME.equals(flow.getNombre()) && flow.getArea()==null;
    }

    public boolean isBase(FlujoDefinicion flow) {
        return isBaseIdentity(flow) && flow.getEtapas().size()==1 && flow.getEtapas().get(0).getOrden()==1
                && FlujoReviewerResolver.isDynamicBase(flow.getEtapas().get(0)) && validStage(flow.getEtapas().get(0));
    }

    public List<FlujoEtapa> orderedStages(FlujoDefinicion flow) {
        if (!validName(flow.getNombre())) throw incomplete("El flujo debe conservar un nombre válido.");
        List<FlujoEtapa> stages=flow.getEtapas().stream().sorted(Comparator.comparingInt(FlujoEtapa::getOrden)).toList();
        if (stages.isEmpty()) throw incomplete("El flujo debe tener al menos una etapa.");
        for (int i=0;i<stages.size();i++) {
            if (stages.get(i).getOrden()!=i+1 || !validStage(stages.get(i))
                    || !flow.getId().equals(stages.get(i).getFlujoDefinicion().getId())) {
                throw incomplete("Las etapas deben tener nombres válidos, tipo REVISION y orden consecutivo desde 1.");
            }
        }
        if ((Long.valueOf(1).equals(flow.getId()) || BASE_NAME.equalsIgnoreCase(flow.getNombre())) && !isBase(flow)) {
            throw RbacException.conflict("FLUJO_CATALOGO_INCONSISTENTE","La identidad o estructura del flujo base es inconsistente.");
        }
        return stages;
    }

    public boolean complete(FlujoDefinicion flow) {
        try {
            List<FlujoEtapa> stages=orderedStages(flow);
            return isBase(flow) || stages.stream().allMatch(s->!reviewers.candidates(s).isEmpty());
        } catch (RbacException e) { return false; }
    }

    public void requireExecutable(FlujoDefinicion flow, boolean newRequest) {
        orderedStages(flow);
        if (!isBase(flow)) orderedStages(flow).forEach(reviewers::requireAvailable);
        if (newRequest && (!flow.isActivo() || (flow.getArea()!=null && !flow.getArea().isActivo()))) {
            throw RbacException.conflict("FLUJO_INACTIVO","El flujo y su área deben estar activos para recibir solicitudes.");
        }
    }

    public void requireResponsibility(Solicitud request, FlujoEtapa stage) {
        reviewers.requireForRequest(request,stage);
    }

    public void requireCurrentStage(Solicitud request) {
        List<FlujoEtapa> stages=orderedStages(request.getFlujoDefinicion());
        FlujoEtapa current=request.getFlujoEtapa();
        if (current==null || stages.stream().noneMatch(s->s.getId().equals(current.getId()))) {
            throw RbacException.conflict("FLUJO_CATALOGO_INCONSISTENTE","La etapa actual no pertenece a la secuencia de la solicitud.");
        }
        requireResponsibility(request,current);
    }

    private static boolean validStage(FlujoEtapa stage) {
        return validName(stage.getNombre()) && stage.getTipoAccion()==TipoAccionEtapa.REVISION;
    }

    private static boolean validName(String value) {
        return value!=null && !value.isBlank() && value.length()<=150 && value.codePoints().noneMatch(Character::isISOControl);
    }

    public static RbacException incomplete(String detail) { return RbacException.conflict("FLUJO_INCOMPLETO",detail); }
}
