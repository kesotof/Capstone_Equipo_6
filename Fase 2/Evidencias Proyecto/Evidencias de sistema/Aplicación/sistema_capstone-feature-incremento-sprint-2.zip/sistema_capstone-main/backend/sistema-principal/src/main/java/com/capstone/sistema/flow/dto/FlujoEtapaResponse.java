package com.capstone.sistema.flow.dto;

import java.util.UUID;
import com.capstone.sistema.flow.model.TipoAccionEtapa;
import com.capstone.sistema.flow.model.TipoAsignacionRevisor;

public record FlujoEtapaResponse(
        Long id,
        int orden,
        String nombre,
        UUID revisorId,
        String revisorNombre,
        String revisorEmail,
        TipoAccionEtapa tipoAccion,
        TipoAsignacionRevisor tipoAsignacion,
        Long rolRevisorId,
        String rolRevisorNombre,
        boolean responsableDisponible,
        Integer revisoresDisponibles
) {
    public FlujoEtapaResponse(Long id,int orden,String nombre,UUID revisorId,String revisorNombre,String revisorEmail,TipoAccionEtapa tipoAccion) {
        this(id,orden,nombre,revisorId,revisorNombre,revisorEmail,tipoAccion,TipoAsignacionRevisor.USUARIO,null,null,revisorId!=null,null);
    }
    public FlujoEtapaResponse(Long id,int orden,String nombre,UUID revisorId,String revisorNombre,String revisorEmail) {
        this(id,orden,nombre,revisorId,revisorNombre,revisorEmail,TipoAccionEtapa.REVISION);
    }
}
