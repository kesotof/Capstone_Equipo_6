# Sistema Principal (Spring Boot)

Núcleo de servicios del Sistema de Gestión Documental y Flujos de Aprobación.

## Módulos y Control de Acceso (RBAC)
- **`auth`**: Integración con Keycloak para validación de tokens JWT y roles.
- **`flow`**: Motor de flujos de trabajo, transiciones de estados y emisión de eventos asincrónicos a RabbitMQ.
- **`doc`**: Gestor de carga, almacenamiento y descarga de archivos (.docx, .pdf) hacia el bucket S3 en MinIO.
- **`org`**: Administración de organización, configuración del negocio y catálogo de usuarios/roles.

## Conexiones de Infraestructura
- **PostgreSQL**: `sistema_db`
- **Keycloak**: Validación de JWT en `http://localhost:8080/realms/capstone-realm`
- **MinIO**: Almacenamiento S3 en `http://localhost:9000`
- **RabbitMQ**: Broker de eventos en `amqp://localhost:5672`
