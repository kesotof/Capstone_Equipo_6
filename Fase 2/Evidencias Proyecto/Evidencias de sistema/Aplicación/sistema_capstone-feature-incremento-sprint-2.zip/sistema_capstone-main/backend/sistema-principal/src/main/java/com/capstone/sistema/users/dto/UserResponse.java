package com.capstone.sistema.users.dto;

import com.capstone.sistema.users.model.SystemRole;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

public record UserResponse(
        UUID id,
        String keycloakUserId,
        String email,
        String rut,
        String firstName,
        String lastName,
        Long areaId,
        String areaNombre,
        boolean enabled,
        boolean temporarilyLocked,
        Set<SystemRole> roles,
        Instant createdAt,
        java.util.List<com.capstone.sistema.rbac.dto.RbacDtos.ContextRole> rolesFuncionales,
        UUID jefaturaDirectaId,
        String jefaturaDirectaNombre,
        long versionAcceso
) {
    public UserResponse(UUID id,String keycloakUserId,String email,String rut,String firstName,String lastName,
                        Long areaId,String areaNombre,boolean enabled,boolean temporarilyLocked,Set<SystemRole> roles,Instant createdAt) {
        this(id,keycloakUserId,email,rut,firstName,lastName,areaId,areaNombre,enabled,temporarilyLocked,roles,createdAt,java.util.List.of(),null,null,0);
    }
}
