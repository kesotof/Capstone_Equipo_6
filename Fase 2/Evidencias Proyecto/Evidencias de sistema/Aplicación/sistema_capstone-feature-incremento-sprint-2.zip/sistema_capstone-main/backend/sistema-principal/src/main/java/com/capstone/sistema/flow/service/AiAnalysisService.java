package com.capstone.sistema.flow.service;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.exception.AiAnalysisNotFoundException;
import com.capstone.sistema.flow.exception.SolicitudNotFoundException;
import com.capstone.sistema.flow.model.AiAnalysis;
import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.AiAnalysisRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
public class AiAnalysisService {

    private static final Logger log = LoggerFactory.getLogger(AiAnalysisService.class);

    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final AiAnalysisRepository aiAnalysisRepository;
    private final RabbitTemplate rabbitTemplate;
    private final CurrentUserResolver currentUserResolver;
    private final ObjectMapper objectMapper;
    private final com.capstone.sistema.rbac.service.RbacAccessService rbac;

    public AiAnalysisService(
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            AiAnalysisRepository aiAnalysisRepository,
            RabbitTemplate rabbitTemplate,
            CurrentUserResolver currentUserResolver,
            ObjectMapper objectMapper,
            com.capstone.sistema.rbac.service.RbacAccessService rbac
    ) {
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.aiAnalysisRepository = aiAnalysisRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.currentUserResolver = currentUserResolver;
        this.objectMapper = objectMapper;
        this.rbac = rbac;
    }

    @Transactional
    public AiAnalysisResponse solicitarAnalisis(UUID solicitudId, String customPrompt, boolean force) {
        Solicitud solicitud = rbac.authorize(solicitudId,com.capstone.sistema.rbac.model.Permiso.IA_SOLICITAR);

        Documento documento = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new IllegalStateException("La solicitud no posee un documento vigente para analizar"));

        String promptNormalized = customPrompt != null ? customPrompt.trim() : null;

        // Comprobar si existe análisis previo completado para este documento y prompt
        Optional<AiAnalysis> latestOpt = aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId);
        if (latestOpt.isPresent()) {
            AiAnalysis latest = latestOpt.get();
            boolean isSameDocument = latest.getDocumento() != null
                    && latest.getDocumento().getId() != null
                    && documento.getId() != null
                    && latest.getDocumento().getId().equals(documento.getId());
            boolean isSamePrompt = Objects.equals(latest.getPromptUtilizado(), promptNormalized);
            boolean isCompleted = latest.getEstado() == EstadoAnalisis.COMPLETADO;

            if (isSameDocument && isSamePrompt && isCompleted && !force) {
                log.info("Análisis de IA en caché encontrado para la solicitud {}. Retornando resultado previo...", solicitudId);
                return AiAnalysisResponse.fromEntity(latest, true, parseRecomendaciones(latest.getRecomendacionesJson()));
            }
        }

        UserAccount solicitante = currentUserResolver.resolveCurrentUser().orElse(null);

        AiAnalysis nuevoAnalisis = new AiAnalysis(solicitud, documento, promptNormalized, solicitante);
        nuevoAnalisis = aiAnalysisRepository.save(nuevoAnalisis);

        Map<String, Object> eventPayload = new HashMap<>();
        eventPayload.put("analysisId", nuevoAnalisis.getId().toString());
        eventPayload.put("solicitudId", solicitudId.toString());
        eventPayload.put("storageKey", documento.getStorageKey());
        eventPayload.put("nombreArchivo", documento.getNombreArchivo());
        eventPayload.put("contentType", documento.getContentType());
        eventPayload.put("titulo", solicitud.getTitulo());
        eventPayload.put("descripcion", solicitud.getDescripcion());
        if (promptNormalized != null && !promptNormalized.isBlank()) {
            eventPayload.put("prompt", promptNormalized);
        }

        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_ANALYSIS_ROUTING_KEY, eventPayload);
        log.info("Tarea de análisis de IA {} emitida hacia RabbitMQ ({}) para solicitud {}",
                nuevoAnalisis.getId(), RabbitConfig.AI_ANALYSIS_ROUTING_KEY, solicitudId);

        return AiAnalysisResponse.fromEntity(nuevoAnalisis, false, List.of());
    }

    @Transactional(readOnly = true)
    public AiAnalysisResponse obtenerUltimoAnalisis(UUID solicitudId) {
        rbac.authorize(solicitudId,com.capstone.sistema.rbac.model.Permiso.IA_CONSULTAR);

        AiAnalysis analysis = aiAnalysisRepository.findFirstBySolicitud_IdOrderByCreatedAtDesc(solicitudId)
                .orElseThrow(() -> new AiAnalysisNotFoundException(solicitudId));

        return AiAnalysisResponse.fromEntity(analysis, false, parseRecomendaciones(analysis.getRecomendacionesJson()));
    }

    @Transactional
    public void procesarResultado(Map<String, Object> payload) {
        log.info("Procesando resultado de análisis de IA recibido: {}", payload);

        String analysisIdStr = (String) payload.get("analysisId");
        if (analysisIdStr == null) {
            log.error("El mensaje de resultado de IA no contiene analysisId: {}", payload);
            return;
        }

        UUID analysisId;
        try {
            analysisId = UUID.fromString(analysisIdStr);
        } catch (IllegalArgumentException e) {
            log.error("Identificador de análisis inválido: {}", analysisIdStr);
            return;
        }

        AiAnalysis analysis = aiAnalysisRepository.findById(analysisId).orElse(null);
        if (analysis == null) {
            log.warn("Análisis de IA {} no encontrado en base de datos al procesar resultado", analysisId);
            return;
        }

        String statusStr = (String) payload.get("status");
        EstadoAnalisis estado = "COMPLETADO".equalsIgnoreCase(statusStr) ? EstadoAnalisis.COMPLETADO : EstadoAnalisis.ERROR;
        analysis.setEstado(estado);

        String modeloUsado = (String) payload.get("modeloUsado");
        analysis.setModeloUsado(modeloUsado);

        String resultadoRaw = (String) payload.get("resultado");
        analysis.setResultadoRaw(resultadoRaw);
        analysis.setCompletedAt(Instant.now());

        if (resultadoRaw != null && !resultadoRaw.isBlank()) {
            try {
                JsonNode root = objectMapper.readTree(resultadoRaw);
                if (root.has("puntaje")) {
                    analysis.setPuntaje(root.get("puntaje").asInt());
                }
                if (root.has("valido")) {
                    analysis.setValido(root.get("valido").asBoolean());
                }
                if (root.has("observaciones")) {
                    analysis.setObservaciones(root.get("observaciones").asText());
                }
                if (root.has("recomendaciones") && root.get("recomendaciones").isArray()) {
                    analysis.setRecomendacionesJson(root.get("recomendaciones").toString());
                }
            } catch (Exception e) {
                log.warn("No se pudo parsear el resultado JSON estructurado de IA: {}", e.getMessage());
                analysis.setObservaciones(resultadoRaw);
            }
        }

        aiAnalysisRepository.save(analysis);
        log.info("Análisis de IA {} actualizado exitosamente a estado {}", analysisId, estado);
    }

    private List<String> parseRecomendaciones(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return List.of(json);
        }
    }
}
