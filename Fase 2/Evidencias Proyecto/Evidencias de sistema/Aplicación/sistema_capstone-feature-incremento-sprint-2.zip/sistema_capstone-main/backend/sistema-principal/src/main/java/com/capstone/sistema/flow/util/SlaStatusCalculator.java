package com.capstone.sistema.flow.util;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;

public final class SlaStatusCalculator {
    private static final Duration WARNING_WINDOW = Duration.ofHours(24);

    private SlaStatusCalculator() {
    }

    public static String status(Instant deadline, Instant evaluatedAt) {
        if (deadline == null) return null;
        Objects.requireNonNull(evaluatedAt, "El instante de evaluación es obligatorio");
        if (evaluatedAt.isAfter(deadline)) return "VENCIDO";
        return Duration.between(evaluatedAt, deadline).compareTo(WARNING_WINDOW) < 0
                ? "POR_VENCER" : "NORMAL";
    }

    public static Boolean withinDeadline(Instant deadline, Instant decisionAt) {
        if (deadline == null) return null;
        return !Objects.requireNonNull(decisionAt, "El instante de decisión es obligatorio").isAfter(deadline);
    }
}
