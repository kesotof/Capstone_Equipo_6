package com.capstone.sistema.users.repository;

import com.capstone.sistema.users.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserAccountRepository extends JpaRepository<UserAccount, UUID> {

    boolean existsByEmailIgnoreCase(String email);

    boolean existsByRut(String rut);

    boolean existsByKeycloakUserId(String keycloakUserId);

    boolean existsByIdAndKeycloakUserIdAndEnabledTrue(UUID id, String keycloakUserId);

    Optional<UserAccount> findByEmailIgnoreCase(String email);

    Optional<UserAccount> findByRut(String rut);

    Optional<UserAccount> findByKeycloakUserId(String keycloakUserId);

    List<UserAccount> findAllByOrderByEmailAsc();
}
