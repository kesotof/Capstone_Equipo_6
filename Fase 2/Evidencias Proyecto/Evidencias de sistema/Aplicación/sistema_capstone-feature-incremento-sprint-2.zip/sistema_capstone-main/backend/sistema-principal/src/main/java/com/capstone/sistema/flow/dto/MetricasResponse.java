package com.capstone.sistema.flow.dto;

public record MetricasResponse(
        long totalPendientes,
        long totalAprobadas,
        long totalRechazadas,
        long totalCorreccion,
        long totalGeneral,
        long totalDentroSla,
        long totalFueraSla,
        Long areaId,
        String areaNombre
) {
    public MetricasResponse(
            long totalPendientes,
            long totalAprobadas,
            long totalRechazadas,
            long totalCorreccion,
            long totalGeneral,
            Long areaId,
            String areaNombre
    ) {
        this(totalPendientes, totalAprobadas, totalRechazadas, totalCorreccion, totalGeneral, 0L, 0L, areaId, areaNombre);
    }
}
