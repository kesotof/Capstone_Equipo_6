package com.capstone.sistema.flow.exception;

public class DashboardSummaryException extends RuntimeException {
    public DashboardSummaryException(String message) { super(message); }
}
