package com.capstone.sistema.users.mapper;

import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.model.UserAccount;

public final class UserMapper {

    private UserMapper() {
    }

    public static UserResponse toResponse(UserAccount user, boolean temporarilyLocked) {
        Long areaId = user.getArea() != null ? user.getArea().getId() : null;
        String areaNombre = user.getArea() != null ? user.getArea().getNombre() : null;

        return new UserResponse(
                user.getId(),
                user.getKeycloakUserId(),
                user.getEmail(),
                user.getRut(),
                user.getFirstName(),
                user.getLastName(),
                areaId,
                areaNombre,
                user.isEnabled(),
                temporarilyLocked,
                user.getRoles(),
                user.getCreatedAt(),
                user.getRolEntities().stream().filter(com.capstone.sistema.users.model.RolFlujo::isActivo)
                        .filter(r->!r.getNombre().equals("APPROVER") && !r.getNombre().equals("AREA_ADMIN"))
                        .map(r->new com.capstone.sistema.rbac.dto.RbacDtos.ContextRole(r.getId(),r.getNombre(),r.getNombreVisible(),"EXPLICITO"))
                        .toList(),
                user.getJefaturaDirecta()!=null?user.getJefaturaDirecta().getId():null,
                user.getJefaturaDirecta()!=null?(user.getJefaturaDirecta().getFirstName()+" "+user.getJefaturaDirecta().getLastName()).trim():null,
                user.getVersionAcceso()
        );
    }

    public static UserResponse toResponse(UserAccount user,boolean locked,
                                         java.util.List<com.capstone.sistema.rbac.dto.RbacDtos.ContextRole> roles) {
        var response=toResponse(user,locked);
        return new UserResponse(response.id(),response.keycloakUserId(),response.email(),response.rut(),response.firstName(),
                response.lastName(),response.areaId(),response.areaNombre(),response.enabled(),response.temporarilyLocked(),
                response.roles(),response.createdAt(),roles,response.jefaturaDirectaId(),response.jefaturaDirectaNombre(),response.versionAcceso());
    }
}
