package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.dto.NotificacionResponse;
import com.capstone.sistema.flow.service.NotificacionService;
import com.capstone.sistema.users.model.UserAccount;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "Notificaciones", description = "Bandeja de notificaciones in-app y marcado de lectura")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/notificaciones")
@PreAuthorize("isAuthenticated()")
public class NotificacionController {

    private final NotificacionService notificacionService;
    private final CurrentUserResolver currentUserResolver;

    public NotificacionController(
            NotificacionService notificacionService,
            CurrentUserResolver currentUserResolver
    ) {
        this.notificacionService = notificacionService;
        this.currentUserResolver = currentUserResolver;
    }

    @GetMapping
    public ResponseEntity<List<NotificacionResponse>> listarMisNotificaciones() {
        UserAccount user = getAuthenticatedUser();
        return ResponseEntity.ok(notificacionService.listarMisNotificaciones(user));
    }

    @GetMapping("/no-leidas/count")
    public ResponseEntity<Map<String, Long>> contarNoLeidas() {
        UserAccount user = getAuthenticatedUser();
        long count = notificacionService.contarNoLeidas(user);
        return ResponseEntity.ok(Map.of("count", count));
    }

    @PatchMapping("/{id}/leer")
    public ResponseEntity<NotificacionResponse> marcarComoLeida(@PathVariable Long id) {
        UserAccount user = getAuthenticatedUser();
        return ResponseEntity.ok(notificacionService.marcarComoLeida(id, user));
    }

    @PatchMapping("/marcar-todas-leidas")
    public ResponseEntity<Map<String, Object>> marcarTodasComoLeidas() {
        UserAccount user = getAuthenticatedUser();
        int count = notificacionService.marcarTodasComoLeidas(user);
        return ResponseEntity.ok(Map.of("actualizadas", count));
    }

    private UserAccount getAuthenticatedUser() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new org.springframework.security.access.AccessDeniedException("Usuario no autenticado"));
    }
}
