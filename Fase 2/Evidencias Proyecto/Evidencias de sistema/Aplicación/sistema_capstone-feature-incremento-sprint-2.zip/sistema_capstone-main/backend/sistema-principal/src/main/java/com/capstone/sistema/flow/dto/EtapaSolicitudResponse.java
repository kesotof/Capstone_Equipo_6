package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.FlujoEtapa;

public record EtapaSolicitudResponse(Long id, int orden, String nombre) {
    public static EtapaSolicitudResponse from(FlujoEtapa etapa) {
        return etapa == null ? null : new EtapaSolicitudResponse(etapa.getId(), etapa.getOrden(), etapa.getNombre());
    }
}
