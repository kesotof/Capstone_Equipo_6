package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.ActualizarFlujoRequest;
import com.capstone.sistema.flow.dto.ConfigurarEtapasRequest;
import com.capstone.sistema.flow.dto.CrearFlujoRequest;
import com.capstone.sistema.flow.dto.FlujoResponse;
import com.capstone.sistema.flow.dto.EstadoFlujoRequest;
import com.capstone.sistema.flow.service.FlujoConfigService;
import com.capstone.sistema.flow.service.FlujoResponsableService;
import com.capstone.sistema.flow.dto.AsignarResponsableRequest;
import com.capstone.sistema.flow.dto.ResponsableOptionsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@Tag(name = "Flujos", description = "Gestión de definiciones de flujos de aprobación y asignación de etapas/revisores")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping({"/api/flujos", "/api/workflows"})
@PreAuthorize("isAuthenticated()")
public class FlujoConfigController {

    private final FlujoConfigService flujoConfigService;
    private final FlujoResponsableService responsables;

    public FlujoConfigController(FlujoConfigService flujoConfigService, FlujoResponsableService responsables) {
        this.flujoConfigService = flujoConfigService;
        this.responsables = responsables;
    }

    @Operation(summary = "Crear nuevo flujo de aprobación")
    @PostMapping
    public ResponseEntity<FlujoResponse> crearFlujo(@Valid @RequestBody CrearFlujoRequest request) {
        FlujoResponse response = flujoConfigService.crearFlujo(request);
        return ResponseEntity.created(URI.create("/api/flujos/" + response.id())).body(response);
    }

    @Operation(summary = "Listar flujos de aprobación disponibles")
    @GetMapping
    public ResponseEntity<List<FlujoResponse>> listarFlujos(
            @RequestParam(required = false) Long areaId,
            @RequestParam(required = false) Boolean activo,
            @RequestParam(required = false) Boolean completo
    ) {
        List<FlujoResponse> response = (completo != null)
                ? flujoConfigService.listarFlujos(areaId, activo, completo)
                : flujoConfigService.listarFlujos(areaId, activo);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Obtener detalle de un flujo por ID")
    @GetMapping("/{id}")
    public ResponseEntity<FlujoResponse> obtenerFlujo(@PathVariable Long id) {
        return ResponseEntity.ok(flujoConfigService.obtenerFlujo(id));
    }

    @Operation(summary = "Actualizar metadatos o estado de un flujo")
    @PutMapping("/{id}")
    public ResponseEntity<FlujoResponse> actualizarFlujo(
            @PathVariable Long id,
            @Valid @RequestBody ActualizarFlujoRequest request
    ) {
        return ResponseEntity.ok(flujoConfigService.actualizarFlujo(id, request));
    }

    @Operation(summary = "Configurar etapas y revisores secuenciales de forma atómica")
    @PutMapping("/{id}/etapas")
    public ResponseEntity<FlujoResponse> configurarEtapas(
            @PathVariable Long id,
            @Valid @RequestBody ConfigurarEtapasRequest request
    ) {
        return ResponseEntity.ok(flujoConfigService.configurarEtapas(id, request));
    }

    @Operation(summary = "Desactivar o eliminar un flujo")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarFlujo(@PathVariable Long id, @RequestParam Long version) {
        flujoConfigService.eliminarFlujo(id, version);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Activar una configuración consistente o desactivar el flujo")
    @PatchMapping("/{id}/status")
    public ResponseEntity<FlujoResponse> cambiarEstado(@PathVariable Long id, @Valid @RequestBody EstadoFlujoRequest request) {
        return ResponseEntity.ok(flujoConfigService.cambiarEstado(id, request));
    }

    @Operation(summary = "Asignar un usuario o rol departamental sin reemplazar la etapa")
    @PutMapping({"/{id}/steps/{stepId}/assignee", "/{id}/etapas/{stepId}/responsable"})
    public FlujoResponse asignarResponsable(@PathVariable Long id, @PathVariable Long stepId,
                                          @Valid @RequestBody AsignarResponsableRequest request) {
        return responsables.assign(id,stepId,request);
    }

    @Operation(summary = "Opciones de responsables disponibles para configurar etapas")
    @GetMapping("/{id}/assignee-options")
    public ResponsableOptionsResponse opcionesResponsables(@PathVariable Long id) {
        return responsables.options(id,null);
    }

    @Operation(summary = "Opciones de responsables compatibles con las solicitudes abiertas de la etapa")
    @GetMapping("/{id}/steps/{stepId}/assignee-options")
    public ResponsableOptionsResponse opcionesResponsablesEtapa(@PathVariable Long id, @PathVariable Long stepId) {
        return responsables.options(id,stepId);
    }
}
