package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "notificacion", indexes = {
        @Index(name = "idx_notificacion_destinatario", columnList = "usuario_id")
})
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount destinatario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitud_id")
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitud_transicion_id")
    private SolicitudTransicion solicitudTransicion;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "tipo_notificacion_id", nullable = false)
    private TipoNotificacion tipoNotificacion;

    @Column(nullable = false, length = 255)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String mensaje;

    @Column(nullable = false)
    private boolean leida = false;

    @Column(name = "created_en", nullable = false, updatable = false)
    private Instant createdEn;

    @Column(name = "leida_en")
    private Instant leidaEn;

    protected Notificacion() {
    }

    public Notificacion(
            UserAccount destinatario,
            Solicitud solicitud,
            SolicitudTransicion solicitudTransicion,
            TipoNotificacion tipoNotificacion,
            String titulo,
            String mensaje
    ) {
        this.destinatario = destinatario;
        this.solicitud = solicitud;
        this.solicitudTransicion = solicitudTransicion;
        this.tipoNotificacion = tipoNotificacion;
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.leida = false;
    }

    @PrePersist
    void onPrePersist() {
        if (createdEn == null) {
            createdEn = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public UserAccount getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(UserAccount destinatario) {
        this.destinatario = destinatario;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public SolicitudTransicion getSolicitudTransicion() {
        return solicitudTransicion;
    }

    public void setSolicitudTransicion(SolicitudTransicion solicitudTransicion) {
        this.solicitudTransicion = solicitudTransicion;
    }

    public TipoNotificacion getTipoNotificacion() {
        return tipoNotificacion;
    }

    public void setTipoNotificacion(TipoNotificacion tipoNotificacion) {
        this.tipoNotificacion = tipoNotificacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public boolean isLeida() {
        return leida;
    }

    public void setLeida(boolean leida) {
        this.leida = leida;
        if (leida && leidaEn == null) {
            this.leidaEn = Instant.now();
        }
    }

    public Instant getCreatedEn() {
        return createdEn;
    }

    public Instant getLeidaEn() {
        return leidaEn;
    }
}
