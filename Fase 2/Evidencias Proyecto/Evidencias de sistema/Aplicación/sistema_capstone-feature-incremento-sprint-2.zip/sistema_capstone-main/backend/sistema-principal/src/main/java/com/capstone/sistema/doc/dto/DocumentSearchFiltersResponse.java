package com.capstone.sistema.doc.dto;

import com.capstone.sistema.flow.dto.AreaDetalleResponse;

import java.util.List;

public record DocumentSearchFiltersResponse(List<String> documentTypes, List<AreaDetalleResponse> areas,
                                            List<String> statuses) {
    public DocumentSearchFiltersResponse {
        documentTypes = List.copyOf(documentTypes);
        areas = List.copyOf(areas);
        statuses = List.copyOf(statuses);
    }
}
