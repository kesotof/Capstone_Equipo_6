package com.capstone.sistema.doc.controller;

import com.capstone.sistema.doc.dto.DocumentSearchFiltersResponse;
import com.capstone.sistema.doc.dto.DocumentSearchPageResponse;
import com.capstone.sistema.doc.service.DocumentSearchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/documents/search", produces = MediaType.APPLICATION_JSON_VALUE)
@PreAuthorize("isAuthenticated()")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Documentos", description = "Consulta de documentos vigentes con alcance departamental y jerárquico")
public class DocumentSearchController {
    private final DocumentSearchService search;

    public DocumentSearchController(DocumentSearchService search) { this.search = search; }

    @Operation(summary = "Buscar documentos vigentes",
            description = "Filtros combinados con AND y alcance SOLICITUD_CONSULTAR. Una fila por solicitud; "
                    + "fechas de emisión y desempate por id. Los formatos proceden de FormatoDocumento.tipo.")
    @Parameters({
            @Parameter(name = "query", in = ParameterIn.QUERY, description = "Texto parcial literal, máximo 200 caracteres", schema = @Schema(type = "string", maxLength = 200)),
            @Parameter(name = "documentType", in = ParameterIn.QUERY, description = "Código de formato persistido, por ejemplo PDF", schema = @Schema(type = "string", maxLength = 36)),
            @Parameter(name = "status", in = ParameterIn.QUERY, schema = @Schema(type = "string", allowableValues = {"PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO"})),
            @Parameter(name = "areaId", in = ParameterIn.QUERY, description = "Área de origen o flujo registrada en la solicitud", schema = @Schema(type = "integer", format = "int64", minimum = "1")),
            @Parameter(name = "dateFrom", in = ParameterIn.QUERY, description = "Emisión desde: yyyy-MM-dd en America/Santiago o ISO 8601 con offset, inclusivo", schema = @Schema(type = "string")),
            @Parameter(name = "dateTo", in = ParameterIn.QUERY, description = "Emisión hasta: día completo en America/Santiago o instante ISO 8601 inclusivo", schema = @Schema(type = "string")),
            @Parameter(name = "page", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "0", minimum = "0")),
            @Parameter(name = "size", in = ParameterIn.QUERY, schema = @Schema(type = "integer", defaultValue = "10", minimum = "1", maximum = "100")),
            @Parameter(name = "sort", in = ParameterIn.QUERY, description = "createdAt, updatedAt, titulo o correlativo; asc o desc", schema = @Schema(type = "string", defaultValue = "createdAt,desc"))
    })
    @GetMapping
    public ResponseEntity<DocumentSearchPageResponse> search(@Parameter(hidden = true) @RequestParam MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(search.search(parameters));
    }

    @Operation(summary = "Obtener opciones de búsqueda visibles",
            description = "Formatos y áreas de solicitudes autorizadas con documento vigente, más estados del ciclo de vida. No acepta parámetros.")
    @GetMapping("/filters")
    public ResponseEntity<DocumentSearchFiltersResponse> filters(@Parameter(hidden = true) @RequestParam MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(search.filters(parameters));
    }
}
