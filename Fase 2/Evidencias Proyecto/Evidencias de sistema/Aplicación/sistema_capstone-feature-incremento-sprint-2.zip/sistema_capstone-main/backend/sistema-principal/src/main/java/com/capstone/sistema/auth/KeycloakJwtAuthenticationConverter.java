package com.capstone.sistema.auth;

import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.InvalidBearerTokenException;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Collection;



@Component
public class KeycloakJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final UserAccountRepository userAccountRepository;

    public KeycloakJwtAuthenticationConverter(UserAccountRepository userAccountRepository) {
        this.userAccountRepository = userAccountRepository;
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        validateActiveLocalUser(jwt);
        var localUser = userAccountRepository.findByKeycloakUserId(jwt.getSubject()).orElseThrow(
                () -> new InvalidBearerTokenException("La cuenta no existe o no está habilitada"));
        Collection<GrantedAuthority> authorities = new java.util.ArrayList<>();
        localUser.getRolEntities().stream().filter(com.capstone.sistema.users.model.RolFlujo::isActivo)
                .filter(r -> !"APPROVER".equals(r.getNombre()) && !"AREA_ADMIN".equals(r.getNombre()))
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r.getNombre())).forEach(authorities::add);
        localUser.getRoles().stream().map(r -> new SimpleGrantedAuthority("ROLE_" + r.name())).forEach(authorities::add);
        String principalName = jwt.getClaimAsString("email");

        if (principalName == null || principalName.isBlank()) {
            principalName = jwt.getClaimAsString("preferred_username");
        }

        return new JwtAuthenticationToken(jwt, authorities, principalName);
    }

    private void validateActiveLocalUser(Jwt jwt) {
        String keycloakUserId = jwt.getSubject();
        if (keycloakUserId == null || keycloakUserId.isBlank()) {
            throw new InvalidBearerTokenException("El token no contiene un identificador de usuario válido");
        }

        boolean activeUser = userAccountRepository.findByKeycloakUserId(keycloakUserId)
                .map(user -> user.isEnabled())
                .orElse(false);
        if (!activeUser) {
            throw new InvalidBearerTokenException("La cuenta no existe o no está habilitada");
        }
    }

}
