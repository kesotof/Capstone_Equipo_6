package com.capstone.sistema.flow.dto;

public record AiAnalysisRequest(
        String prompt
) {}
