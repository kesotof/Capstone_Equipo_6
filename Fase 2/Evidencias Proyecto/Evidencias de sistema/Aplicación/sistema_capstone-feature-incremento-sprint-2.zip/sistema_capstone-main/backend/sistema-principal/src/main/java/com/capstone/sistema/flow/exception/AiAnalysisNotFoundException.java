package com.capstone.sistema.flow.exception;

import java.util.UUID;

public class AiAnalysisNotFoundException extends RuntimeException {

    public AiAnalysisNotFoundException(UUID solicitudId) {
        super("No se encontró un análisis de IA para la solicitud con ID: " + solicitudId);
    }

    public AiAnalysisNotFoundException(String message) {
        super(message);
    }
}
