package com.capstone.sistema.doc.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Configuration
public class DocumentDownloadWebConfig {
    @Bean
    public FilterRegistrationBean<OncePerRequestFilter> documentDownloadHeadersFilter() {
        var registration = new FilterRegistrationBean<OncePerRequestFilter>();
        registration.setFilter(new OncePerRequestFilter() {
            @Override
            protected boolean shouldNotFilter(HttpServletRequest request) {
                String path = request.getRequestURI().substring(request.getContextPath().length());
                return !(path.matches("/api/(documents|docs)/[^/]+/download")
                        || path.matches("/api/solicitudes/[^/]+/documento/descargar")
                        || path.matches("/api/doc/download/[^/]+"));
            }

            @Override
            protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                    throws ServletException, IOException {
                response.setHeader(HttpHeaders.CACHE_CONTROL, "no-store, no-transform");
                response.setHeader("X-Content-Type-Options", "nosniff");
                chain.doFilter(request, response);
            }
        });
        registration.setName("documentDownloadHeaders");
        registration.setUrlPatterns(List.of("/api/*"));
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 21);
        return registration;
    }
}
