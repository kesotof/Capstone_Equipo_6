package com.capstone.sistema.flow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record ActualizarFlujoRequest(
        @NotBlank(message = "El nombre del flujo es obligatorio")
        @Size(max = 150, message = "El nombre no puede exceder los 150 caracteres")
        String nombre,

        @Size(max = 2000, message = "La descripción no puede exceder los 2000 caracteres")
        String descripcion,

        Long areaId,

        Boolean activo,

        @NotNull @PositiveOrZero Long version
) {
    public ActualizarFlujoRequest(String nombre, String descripcion, Long areaId, Boolean activo) {
        this(nombre, descripcion, areaId, activo, null);
    }
}
