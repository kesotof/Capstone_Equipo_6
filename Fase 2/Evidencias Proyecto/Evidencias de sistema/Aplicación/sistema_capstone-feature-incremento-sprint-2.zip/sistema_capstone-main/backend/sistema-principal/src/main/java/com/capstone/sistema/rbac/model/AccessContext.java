package com.capstone.sistema.rbac.model;

import java.util.*;
import com.capstone.sistema.rbac.dto.RbacDtos;

public record AccessContext(UUID usuarioId, Long areaId, UUID jefaturaDirectaId, boolean admin,
                            Set<UUID> superiores, boolean jerarquiaValida, List<RbacDtos.ContextRole> roles,
                            List<RbacDtos.AreaItem> areasAdministradas, Map<Permiso, Set<Alcance>> permisos,
                            long versionAcceso, long versionPolitica) {
    public Set<Alcance> scopes(Permiso permiso) { return permisos.getOrDefault(permiso, Set.of()); }
    public boolean has(Permiso permiso) { return !scopes(permiso).isEmpty(); }
    public Set<Long> managedAreas() {
        return areasAdministradas.stream().map(RbacDtos.AreaItem::id).collect(java.util.stream.Collectors.toUnmodifiableSet());
    }
}

