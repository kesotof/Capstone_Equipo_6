package com.capstone.sistema.flow.exception;

public class MyRequestsException extends RuntimeException {
    private MyRequestsException(String message) {
        super(message);
    }

    public static MyRequestsException invalid(String message) {
        return new MyRequestsException(message);
    }
}
