package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.AreaDetalleResponse;
import com.capstone.sistema.flow.dto.EtapaSolicitudResponse;
import com.capstone.sistema.flow.dto.MyRequestsCriteria;
import com.capstone.sistema.flow.dto.MyRequestsPageResponse;
import com.capstone.sistema.flow.dto.MyRequestsSummaryResponse;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.MyRequestsCapabilityRepository;
import com.capstone.sistema.flow.repository.MyRequestsSpecification;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.model.AccessContext;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class MyRequestsService {
    private final SolicitudRepository solicitudes;
    private final AreaRepository areas;
    private final MyRequestsCapabilityRepository capabilities;
    private final MyRequestsQueryNormalizer normalizer;
    private final RbacAccessService rbac;

    public MyRequestsService(SolicitudRepository solicitudes, AreaRepository areas,
                             MyRequestsCapabilityRepository capabilities, MyRequestsQueryNormalizer normalizer,
                             RbacAccessService rbac) {
        this.solicitudes = solicitudes;
        this.areas = areas;
        this.capabilities = capabilities;
        this.normalizer = normalizer;
        this.rbac = rbac;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public MyRequestsPageResponse own(Map<String, List<String>> parameters) {
        return read(parameters, true);
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public MyRequestsPageResponse accessible(Map<String, List<String>> parameters) {
        return read(parameters, false);
    }

    private MyRequestsPageResponse read(Map<String, List<String>> parameters, boolean ownOnly) {
        rbac.clearContext();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        AccessContext context = rbac.context();
        MyRequestsCriteria filters = normalizer.normalize(parameters, ownOnly);
        Specification<Solicitud> visibility = rbac.visible(context, Permiso.SOLICITUD_CONSULTAR);
        if (ownOnly) {
            // El UUID local procede de JWT sub -> keycloakUserId; GLOBAL no omite esta igualdad.
            visibility = visibility.and(MyRequestsSpecification.emittedBy(context.usuarioId()));
        }
        var page = solicitudes.findAll(visibility.and(new MyRequestsSpecification(filters))
                .and(MyRequestsSpecification.withCurrentStage()), filters.pageable());

        Map<Long, Area> registeredAreas = findAreas(page.getContent());
        Set<UUID> resendIds = findResendIds(page.getContent(), context);
        List<MyRequestsSummaryResponse> content = page.getContent().stream()
                .map(request -> summary(request, context.usuarioId(), registeredAreas, resendIds)).toList();
        return new MyRequestsPageResponse(content, page.getNumber(), page.getSize(), page.getTotalElements(),
                page.getTotalPages(), page.isFirst(), page.isLast(), MyRequestsCriteria.ORDER, Instant.now());
    }

    private Set<UUID> findResendIds(List<Solicitud> requests, AccessContext context) {
        if (requests.isEmpty() || !context.has(Permiso.SOLICITUD_REENVIAR)) {
            return Set.of();
        }
        Specification<Solicitud> permission = rbac.visible(context, Permiso.SOLICITUD_CONSULTAR)
                .and(rbac.visible(context, Permiso.SOLICITUD_REENVIAR))
                .and((root, query, builder) -> builder.equal(
                        builder.upper(root.get("estadoSolicitud").get("codigo")), "CORRECCION_REQUERIDA"));
        if (!context.admin()) {
            // Misma restricción de identidad que SolicitudService.reenviar.
            permission = permission.and(MyRequestsSpecification.emittedBy(context.usuarioId()));
        }
        return capabilities.findAuthorizedIds(requests.stream().map(Solicitud::getId).toList(), permission);
    }

    private Map<Long, Area> findAreas(List<Solicitud> requests) {
        Set<Long> ids = new HashSet<>();
        for (Solicitud request : requests) {
            if (request.getAreaOrigenId() != null) {
                ids.add(request.getAreaOrigenId());
            }
            if (request.getAreaFlujoId() != null) {
                ids.add(request.getAreaFlujoId());
            }
        }
        return ids.isEmpty() ? Map.of() : areas.findAllById(ids).stream()
                .collect(Collectors.toMap(Area::getId, Function.identity()));
    }

    private MyRequestsSummaryResponse summary(Solicitud request, UUID userId, Map<Long, Area> registeredAreas,
                                               Set<UUID> resendIds) {
        String firstName = request.getEmisor().getFirstName();
        String lastName = request.getEmisor().getLastName();
        String name = ((firstName == null ? "" : firstName) + " " + (lastName == null ? "" : lastName)).trim();
        return new MyRequestsSummaryResponse(request.getId(), request.getCorrelativo(), request.getTitulo(),
                request.getEstadoSolicitud().getCodigo(), request.getCreatedAt(), request.getUpdatedAt(), request.getVersion(),
                EtapaSolicitudResponse.from(request.getFlujoEtapa()), name.isEmpty() ? "Usuario" : name,
                request.getEmisor().getId().equals(userId), area(request.getAreaOrigenId(), registeredAreas),
                area(request.getAreaFlujoId(), registeredAreas), resendIds.contains(request.getId()) ? List.of("REENVIAR") : List.of(),
                "/api/requests/" + request.getId() + "/detail");
    }

    private AreaDetalleResponse area(Long id, Map<Long, Area> registeredAreas) {
        if (id == null) {
            return null;
        }
        Area area = registeredAreas.get(id);
        return new AreaDetalleResponse(id, area == null ? null : area.getNombre(), area == null ? null : area.isActivo());
    }
}
