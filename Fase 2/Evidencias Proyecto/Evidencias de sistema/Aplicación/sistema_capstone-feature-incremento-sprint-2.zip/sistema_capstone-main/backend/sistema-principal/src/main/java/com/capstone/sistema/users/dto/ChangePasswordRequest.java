package com.capstone.sistema.users.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ChangePasswordRequest(
        @NotBlank(message = "La contraseña actual es obligatoria")
        @Size(max = 1024, message = "La contraseña actual no puede superar 1024 caracteres")
        String currentPassword,

        @NotBlank(message = "La nueva contraseña es obligatoria")
        @Size(min = 8, max = 1024, message = "La nueva contraseña debe tener entre 8 y 1024 caracteres")
        String newPassword,

        @NotBlank(message = "La confirmación de contraseña es obligatoria")
        @Size(max = 1024, message = "La confirmación no puede superar 1024 caracteres")
        String confirmPassword
) {
    public ChangePasswordRequest(String currentPassword, String newPassword) {
        this(currentPassword, newPassword, newPassword);
    }

    @Override
    public String toString() {
        return "ChangePasswordRequest[credentials=REDACTED]";
    }
}
