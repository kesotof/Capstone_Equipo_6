package com.capstone.sistema.users.password;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.ChangePasswordRequest;
import com.capstone.sistema.users.dto.PasswordPolicyResponse;
import com.capstone.sistema.users.exception.PasswordChangeException;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.capstone.sistema.users.service.KeycloakLockStatusClient;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.core.Response;
import org.keycloak.OAuth2Constants;
import org.keycloak.TokenVerifier;
import org.keycloak.admin.client.JacksonProvider;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.AccessTokenResponse;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/** Internal collaborator of UserManagementService; all shared dependencies are supplied by its constructor. */
public final class PasswordChangeOperations {
    private static final Logger log = LoggerFactory.getLogger(PasswordChangeOperations.class);
    private final Keycloak admin;
    private final KeycloakAdminProperties properties;
    private final CurrentUserResolver identity;
    private final KeycloakLockStatusClient lockStatus;
    private final AuditService audit;
    private final UserAccountRepository accounts;
    private final Set<UUID> inFlight = ConcurrentHashMap.newKeySet();

    public PasswordChangeOperations(Keycloak admin, KeycloakAdminProperties properties,
                                    CurrentUserResolver identity, KeycloakLockStatusClient lockStatus, AuditService audit,
                                    UserAccountRepository accounts) {
        this.admin = admin;
        this.properties = properties;
        this.identity = identity;
        this.lockStatus = lockStatus;
        this.audit = audit;
        this.accounts = accounts;
    }

    public PasswordPolicyResponse policy() {
        UserAccount account = identity.resolveCurrentUser().orElseThrow(RbacException::denied);
        try {
            RealmResource realm = admin.realm(properties.targetRealm());
            UserRepresentation remote = remoteUser(realm, account);
            return PasswordPolicyRules.from(realm.toRepresentation().getPasswordPolicy(), remote);
        } catch (PasswordChangeException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            throw PasswordChangeException.unavailable();
        }
    }

    public void change(ChangePasswordRequest request) {
        validateRequest(request);
        UserAccount account = identity.resolveCurrentUser().orElseThrow(RbacException::denied);
        if (!inFlight.add(account.getId())) {
            throw new PasswordChangeException(HttpStatus.CONFLICT, "PASSWORD_CHANGE_BUSY",
                    "Ya hay un cambio de contraseña en curso. Espere a que termine.");
        }
        try {
            RealmResource realm = admin.realm(properties.targetRealm());
            UserRepresentation remote;
            try {
                remote = remoteUser(realm, account);
                var clients = realm.clients().findByClientId(properties.passwordClientId());
                if (clients.size() != 1 || !Boolean.TRUE.equals(clients.getFirst().isEnabled())
                        || !Boolean.TRUE.equals(clients.getFirst().isPublicClient())
                        || !Boolean.TRUE.equals(clients.getFirst().isDirectAccessGrantsEnabled())) {
                    throw PasswordChangeException.unavailable();
                }
                PasswordPolicyRules.validate(request.newPassword(),
                        PasswordPolicyRules.from(realm.toRepresentation().getPasswordPolicy(), remote));
            } catch (PasswordChangeException exception) {
                throw exception;
            } catch (RuntimeException exception) {
                throw PasswordChangeException.unavailable();
            }
            if (Boolean.TRUE.equals(remote.isTotp()) || (remote.getRequiredActions() != null && !remote.getRequiredActions().isEmpty())) {
                throw reauthenticationRequired();
            }
            if (lockStatus.isTemporarilyLocked(account.getKeycloakUserId())) throw locked();
            verifyCurrentPassword(realm, account, remote.getUsername(), request.currentPassword());
            // A scalar query sees persisted activation instead of reusing a managed entity from the first-level cache.
            if (!accounts.existsByIdAndKeycloakUserIdAndEnabledTrue(account.getId(), account.getKeycloakUserId())) {
                throw RbacException.denied();
            }
            CredentialRepresentation credential = new CredentialRepresentation();
            credential.setType(CredentialRepresentation.PASSWORD);
            credential.setValue(request.newPassword());
            credential.setTemporary(false);
            try {
                realm.users().get(account.getKeycloakUserId()).resetPassword(credential);
            } catch (WebApplicationException exception) {
                int status = exception.getResponse().getStatus();
                exception.getResponse().close();
                if (status == 400) {
                    throw new PasswordChangeException(HttpStatus.BAD_REQUEST, "PASSWORD_POLICY_REJECTED",
                            "La nueva contraseña no cumple la política de seguridad de la cuenta.",
                            Map.of("newPassword", "La nueva contraseña no cumple la política de seguridad de la cuenta."));
                }
                if (status >= 400 && status < 500) throw PasswordChangeException.unavailable();
                throw uncertain();
            } catch (RuntimeException exception) {
                throw uncertain();
            } finally {
                credential.setValue(null);
            }
            log.info("Cambio de contraseña confirmado para la cuenta local {}", account.getId());
            try {
                audit.registerUserManagementEvent("CAMBIAR_PASSWORD", account, "Contraseña modificada por el titular de la cuenta");
            } catch (RuntimeException exception) {
                // A remote write cannot be rolled back by an audit failure in the local database.
                log.error("Contraseña actualizada; auditoría local pendiente para cuenta {} (tipo={})",
                        account.getId(), exception.getClass().getSimpleName());
            }
        } finally {
            inFlight.remove(account.getId());
        }
    }

    private UserRepresentation remoteUser(RealmResource realm, UserAccount account) {
        UserRepresentation remote = realm.users().get(account.getKeycloakUserId()).toRepresentation();
        if (remote == null || !account.getKeycloakUserId().equals(remote.getId())
                || !Boolean.TRUE.equals(remote.isEnabled()) || remote.getUsername() == null || remote.getUsername().isBlank()) {
            throw PasswordChangeException.unavailable();
        }
        return remote;
    }

    private void verifyCurrentPassword(RealmResource realm, UserAccount account, String username, String password) {
        AccessTokenResponse response;
        // This client is per request because its credentials belong to the current user, not the admin bean.
        try (Client http = ClientBuilder.newBuilder().connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS).register(JacksonProvider.class).build();
             Keycloak verifier = KeycloakBuilder.builder().serverUrl(properties.serverUrl())
                     .realm(properties.targetRealm()).clientId(properties.passwordClientId())
                     .grantType(OAuth2Constants.PASSWORD).scope("openid")
                     .username(username).password(password).resteasyClient(http).build()) {
            try {
                response = verifier.tokenManager().getAccessToken();
            } catch (WebApplicationException exception) {
                // Consume the provider response while the verifier's HTTP client is still open.
                throw currentPasswordFailure(exception, account.getKeycloakUserId());
            }
        } catch (PasswordChangeException exception) {
            throw exception;
        } catch (ProcessingException exception) {
            throw PasswordChangeException.unavailable();
        } catch (RuntimeException exception) {
            throw PasswordChangeException.unavailable();
        }
        if (response == null || response.getToken() == null || response.getSessionState() == null) {
            throw PasswordChangeException.unavailable();
        }
        String temporarySession = response.getSessionState();
        Jwt original = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (temporarySession.equals(original.getClaimAsString("sid"))
                || temporarySession.equals(original.getClaimAsString("session_state"))) {
            throw PasswordChangeException.unavailable();
        }
        try {
            AccessToken verified = TokenVerifier.create(response.getToken(), AccessToken.class).getToken();
            if (!account.getKeycloakUserId().equals(verified.getSubject())) throw PasswordChangeException.unavailable();
        } catch (org.keycloak.common.VerificationException exception) {
            throw PasswordChangeException.unavailable();
        } finally {
            response.setToken(null);
            response.setRefreshToken(null);
            response.setIdToken(null);
            try {
                realm.deleteSession(temporarySession, false);
            } catch (RuntimeException exception) {
                throw PasswordChangeException.unavailable();
            }
        }
    }

    private PasswordChangeException currentPasswordFailure(WebApplicationException exception, String keycloakUserId) {
        Map<?, ?> error = Map.of();
        int status;
        try (Response failure = exception.getResponse()) {
            if (failure == null) return PasswordChangeException.unavailable();
            status = failure.getStatus();
            try {
                if (status == 400 || status == 401) {
                    Map<?, ?> body = failure.readEntity(Map.class);
                    if (body != null) error = body;
                }
            } catch (RuntimeException ignored) {
                // An unreadable provider response cannot establish that credentials were rejected.
            }
        }
        // Keycloak also returns HTTP 401 for a rejected Direct Grant password.
        if ((status == 400 || status == 401) && "invalid_grant".equals(error.get("error"))) {
            if ("Account is not fully set up".equals(error.get("error_description"))) return reauthenticationRequired();
            if (lockStatus.isTemporarilyLocked(keycloakUserId)) return locked();
            return new PasswordChangeException(HttpStatus.BAD_REQUEST, "CURRENT_PASSWORD_INVALID",
                    "La contraseña actual es incorrecta, inténtelo nuevamente.",
                    Map.of("currentPassword", "La contraseña actual es incorrecta, inténtelo nuevamente."));
        }
        return PasswordChangeException.unavailable();
    }

    private void validateRequest(ChangePasswordRequest request) {
        Map<String, String> fields = new LinkedHashMap<>();
        if (request == null) throw new PasswordChangeException(HttpStatus.BAD_REQUEST, "PASSWORD_VALIDATION_FAILED", "Complete los tres campos de contraseña.");
        if (request.currentPassword() == null || request.currentPassword().isBlank() || request.currentPassword().length() > 1024) fields.put("currentPassword", "Ingrese su contraseña actual (máximo 1024 caracteres).");
        if (request.newPassword() == null || request.newPassword().isBlank() || request.newPassword().length() < 8 || request.newPassword().length() > 1024) fields.put("newPassword", "La nueva contraseña debe tener entre 8 y 1024 caracteres.");
        if (request.confirmPassword() == null || request.confirmPassword().isBlank() || request.confirmPassword().length() > 1024) fields.put("confirmPassword", "Confirme su nueva contraseña.");
        else if (!request.confirmPassword().equals(request.newPassword())) fields.put("confirmPassword", "Las contraseñas no coinciden.");
        if (request.newPassword() != null && request.newPassword().equals(request.currentPassword())) fields.put("newPassword", "La nueva contraseña debe ser diferente de la actual.");
        if (!fields.isEmpty()) throw new PasswordChangeException(HttpStatus.BAD_REQUEST, "PASSWORD_VALIDATION_FAILED", "Revise los campos de contraseña.", fields);
    }

    private PasswordChangeException locked() {
        return new PasswordChangeException(HttpStatus.TOO_MANY_REQUESTS, "PASSWORD_ACCOUNT_LOCKED",
                "La cuenta está bloqueada temporalmente por intentos fallidos. Inténtelo cuando finalice el bloqueo.");
    }

    private PasswordChangeException reauthenticationRequired() {
        return new PasswordChangeException(HttpStatus.CONFLICT, "PASSWORD_CHANGE_REAUTH_REQUIRED",
                "La cuenta requiere completar una verificación adicional. Acceda a la gestión de su cuenta para cambiar la contraseña.");
    }

    private PasswordChangeException uncertain() {
        return new PasswordChangeException(HttpStatus.BAD_GATEWAY, "PASSWORD_CHANGE_UNCERTAIN",
                "No fue posible confirmar el resultado del cambio. Compruebe su acceso con la nueva contraseña antes de volver a intentarlo.");
    }
}
