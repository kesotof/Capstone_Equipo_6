package com.capstone.sistema.rbac.dto;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import com.capstone.sistema.rbac.model.Alcance;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public final class RbacDtos {
    private RbacDtos() {}
    public record Grant(@NotBlank String codigo, @NotEmpty List<@NotNull Alcance> alcances) {}
    public record RoleCreate(@NotBlank @Pattern(regexp = "^[A-Z][A-Z0-9_]{2,49}$") String codigo,
                             @NotBlank String nombre, String descripcion,
                             @NotNull List<@NotNull @Valid Grant> permisos) {}
    public record RoleUpdate(@NotBlank String nombre, String descripcion,
                             @NotNull List<@NotNull @Valid Grant> permisos, @NotNull @PositiveOrZero Long version) {}
    public record Status(@NotNull Boolean activo, @NotNull @PositiveOrZero Long version) {}
    public record Membership(@NotNull List<@NotNull @Positive Long> roleIds, @NotNull @PositiveOrZero Long versionAcceso) {}
    public record Manager(UUID jefaturaDirectaId, @NotNull @PositiveOrZero Long versionAcceso) {}
    public record Role(Long id, String codigo, String nombre, String descripcion, boolean activo, boolean sistema,
                       String asignacion, long version, List<Grant> permisos, Instant createdAt, Instant updatedAt) {}
    public record Permission(String codigo, String nombre, String descripcion, boolean reservado, Set<Alcance> alcancesPermitidos) {}
    public record AreaItem(Long id, String nombre) {}
    public record Reviewer(UUID id, String nombre, Long areaId, String areaNombre) {}
    public record ContextRole(Long id, String codigo, String nombre, String origen) {}
    public record Me(UUID usuarioId, Long areaId, UUID jefaturaDirectaId, boolean administradorGlobal,
                     List<ContextRole> roles, List<AreaItem> areasAdministradas, List<Grant> permisos,
                     long versionAcceso, long versionPolitica) {}
    public record Page<T>(List<T> contenido, int pagina, int tamanio, long totalElementos, long totalPaginas,
                          boolean primera, boolean ultima) {}
}

