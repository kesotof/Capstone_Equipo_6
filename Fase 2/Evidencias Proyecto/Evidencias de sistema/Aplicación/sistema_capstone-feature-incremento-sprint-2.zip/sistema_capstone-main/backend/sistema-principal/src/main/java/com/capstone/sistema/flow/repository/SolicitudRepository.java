package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Solicitud;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.UUID;

public interface SolicitudRepository extends JpaRepository<Solicitud, UUID>, JpaSpecificationExecutor<Solicitud> {

    @Override
    @EntityGraph(attributePaths = {"emisor", "estadoSolicitud"})
    Page<Solicitud> findAll(Specification<Solicitud> specification, Pageable pageable);

    List<Solicitud> findByEmisor_IdOrderByCreatedAtDesc(UUID emisorId);

    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc(String codigo);

    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseAndEmisor_IdNotOrderByCreatedAtDesc(String codigo, UUID emisorId);

    @org.springframework.data.jpa.repository.Query("select s from Solicitud s where (:flowId is null or s.flujoDefinicion.id=:flowId) and upper(s.estadoSolicitud.codigo) not in ('APROBADO','RECHAZADO') order by s.id")
    List<Solicitud> findOpenByFlow(@org.springframework.data.repository.query.Param("flowId") Long flowId);

    long countByFlujoDefinicion_Id(Long flujoDefinicionId);

    boolean existsByFlujoDefinicion_Id(Long flujoDefinicionId);

    boolean existsByCorrelativo(String correlativo);

    java.util.Optional<Solicitud> findByCorrelativoIgnoreCase(String correlativo);
}
