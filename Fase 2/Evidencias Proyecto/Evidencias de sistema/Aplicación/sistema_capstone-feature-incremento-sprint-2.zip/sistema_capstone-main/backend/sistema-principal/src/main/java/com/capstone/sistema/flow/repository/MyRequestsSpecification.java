package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.dto.MyRequestsCriteria;
import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Filtros de seguimiento componibles con el predicado RBAC de Solicitud. */
public class MyRequestsSpecification implements Specification<Solicitud> {
    private final MyRequestsCriteria filters;

    public MyRequestsSpecification(MyRequestsCriteria filters) {
        this.filters = filters;
    }

    @Override
    public Predicate toPredicate(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        List<Predicate> predicates = new ArrayList<>();
        if (filters.query() != null) {
            String pattern = literalPattern(filters.query());
            predicates.add(builder.or(
                    builder.like(builder.lower(root.get("titulo")), pattern, '\\'),
                    builder.like(builder.lower(root.get("correlativo")), pattern, '\\')));
        }
        if (filters.status() != null) {
            predicates.add(builder.equal(builder.upper(root.get("estadoSolicitud").get("codigo")), filters.status()));
        }
        if (filters.areaId() != null) {
            predicates.add(builder.or(builder.equal(root.get("areaOrigenId"), filters.areaId()),
                    builder.equal(root.get("areaFlujoId"), filters.areaId())));
        }
        return builder.and(predicates.toArray(Predicate[]::new));
    }

    public static Specification<Solicitud> emittedBy(UUID userId) {
        return (root, query, builder) -> builder.equal(root.get("emisor").get("id"), userId);
    }

    public static Specification<Solicitud> withCurrentStage() {
        return (root, query, builder) -> {
            // El count y las proyecciones escalares no admiten un fetch de entidad.
            if (query != null && Solicitud.class.equals(query.getResultType())) {
                root.fetch("flujoEtapa", JoinType.LEFT);
            }
            return builder.conjunction();
        };
    }

    private String literalPattern(String value) {
        return "%" + value.toLowerCase(Locale.ROOT).replace("\\", "\\\\")
                .replace("%", "\\%").replace("_", "\\_") + "%";
    }
}
