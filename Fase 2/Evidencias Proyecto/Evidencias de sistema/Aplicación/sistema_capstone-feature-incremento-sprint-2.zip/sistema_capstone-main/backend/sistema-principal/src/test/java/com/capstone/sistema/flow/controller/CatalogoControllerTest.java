package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.TipoDocumentoResponse;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.service.SlaService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CatalogoController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class CatalogoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SlaService slaService;

    @MockBean
    private AreaRepository areaRepository;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("Petición sin autenticación retorna 401 Unauthorized")
    void listarTiposDocumento_SinAutenticacion_Retorna401() throws Exception {
        mockMvc.perform(get("/api/catalogos/tipos-documento"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Usuario autenticado obtiene lista de tipos de documento y plazos en días hábiles")
    void listarTiposDocumento_Autenticado_Retorna200YLista() throws Exception {
        List<TipoDocumentoResponse> mockList = List.of(
                new TipoDocumentoResponse("Contrato", 5),
                new TipoDocumentoResponse("Factura", 3),
                new TipoDocumentoResponse("General", 5),
                new TipoDocumentoResponse("Informe", 7),
                new TipoDocumentoResponse("Memorando", 2)
        );
        when(slaService.listTiposDocumento()).thenReturn(mockList);

        mockMvc.perform(get("/api/catalogos/tipos-documento")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(5))
                .andExpect(jsonPath("$[0].tipo").value("Contrato"))
                .andExpect(jsonPath("$[0].plazoDias").value(5))
                .andExpect(jsonPath("$[1].tipo").value("Factura"))
                .andExpect(jsonPath("$[1].plazoDias").value(3))
                .andExpect(jsonPath("$[2].tipo").value("General"))
                .andExpect(jsonPath("$[2].plazoDias").value(5))
                .andExpect(jsonPath("$[3].tipo").value("Informe"))
                .andExpect(jsonPath("$[3].plazoDias").value(7))
                .andExpect(jsonPath("$[4].tipo").value("Memorando"))
                .andExpect(jsonPath("$[4].plazoDias").value(2));
    }

    @Test
    @DisplayName("Petición a /areas sin autenticación retorna 401 Unauthorized")
    void listarAreas_SinAutenticacion_Retorna401() throws Exception {
        mockMvc.perform(get("/api/catalogos/areas"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Usuario autenticado obtiene lista de áreas activas ordenadas alfabéticamente")
    void listarAreas_success_returns200Ok() throws Exception {
        List<Area> mockAreas = List.of(
                new Area(2L, "Administración", true),
                new Area(1L, "Finanzas", true),
                new Area(4L, "Legal", false), // inactiva, debe ser filtrada
                new Area(3L, "Operaciones", true)
        );
        when(areaRepository.findAll()).thenReturn(mockAreas);

        mockMvc.perform(get("/api/catalogos/areas")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(3))
                .andExpect(jsonPath("$[0].id").value(2))
                .andExpect(jsonPath("$[0].nombre").value("Administración"))
                .andExpect(jsonPath("$[1].id").value(1))
                .andExpect(jsonPath("$[1].nombre").value("Finanzas"))
                .andExpect(jsonPath("$[2].id").value(3))
                .andExpect(jsonPath("$[2].nombre").value("Operaciones"));
    }
}
