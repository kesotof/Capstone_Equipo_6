package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.SlaConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface SlaConfigRepository extends JpaRepository<SlaConfig, Long> {

    @Query("select c from SlaConfig c where lower(trim(c.tipoDocumento)) = lower(trim(:tipoDocumento))")
    Optional<SlaConfig> findByTipoDocumentoIgnoreCase(@Param("tipoDocumento") String tipoDocumento);

    @Query("select (count(c) > 0) from SlaConfig c where lower(trim(c.tipoDocumento)) = lower(trim(:tipoDocumento))")
    boolean existsByTipoDocumentoIgnoreCase(@Param("tipoDocumento") String tipoDocumento);

    boolean existsByTipoDocumentoIgnoreCaseAndIdNot(String tipoDocumento, Long id);
}
