package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.CreateSlaConfigRequest;
import com.capstone.sistema.flow.dto.SlaConfigResponse;
import com.capstone.sistema.flow.dto.TipoDocumentoResponse;
import com.capstone.sistema.flow.dto.UpdateSlaConfigRequest;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.model.SlaConfig;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SlaConfigRepository;
import com.capstone.sistema.flow.util.BusinessDaysCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Service
public class SlaService {

    private static final Logger log = LoggerFactory.getLogger(SlaService.class);
    private static final int DEFAULT_SLA_DAYS = 5;

    private final SlaConfigRepository slaConfigRepository;
    private final AuditService auditService;
    private final Clock clock;

    public SlaService(SlaConfigRepository slaConfigRepository, AuditService auditService, Clock clock) {
        this.slaConfigRepository = slaConfigRepository;
        this.auditService = auditService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<SlaConfigResponse> listAll() {
        return slaConfigRepository.findAll().stream()
                .sorted(Comparator.comparing(SlaConfig::getTipoDocumento, String.CASE_INSENSITIVE_ORDER))
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TipoDocumentoResponse> listTiposDocumento() {
        return slaConfigRepository.findAll().stream()
                .sorted(Comparator.comparing(SlaConfig::getTipoDocumento, String.CASE_INSENSITIVE_ORDER))
                .map(c -> new TipoDocumentoResponse(c.getTipoDocumento(), c.getPlazoDias()))
                .toList();
    }

    @Transactional(readOnly = true)
    public SlaConfigResponse getById(Long id) {
        SlaConfig config = slaConfigRepository.findById(id)
                .orElseThrow(() -> new com.capstone.sistema.flow.exception.SlaNotFoundException("Configuración SLA con id " + id + " no encontrada"));
        return toResponse(config);
    }

    @Transactional
    public SlaConfigResponse create(CreateSlaConfigRequest request) {
        if (request == null || request.tipoDocumento() == null || request.tipoDocumento().trim().isBlank()
                || request.tipoDocumento().length() > 100) {
            throw new IllegalArgumentException("El tipo de documento es obligatorio y admite hasta 100 caracteres");
        }
        validateDays(request.plazoDias());
        String tipo = request.tipoDocumento().trim();
        if (slaConfigRepository.existsByTipoDocumentoIgnoreCase(tipo)) {
            throw new FlujoConflictException("Ya existe una regla SLA para el tipo de documento '" + tipo + "'");
        }

        SlaConfig entity = new SlaConfig(tipo, request.plazoDias());
        SlaConfig saved;
        try {
            // Detectar conflictos antes de devolver 201 o registrar una auditoría de éxito.
            saved = slaConfigRepository.saveAndFlush(entity);
        } catch (DataIntegrityViolationException ex) {
            if (isUniqueViolation(ex)) {
                throw new FlujoConflictException("Ya existe una regla SLA para el tipo de documento '" + tipo + "'");
            }
            throw ex;
        }

        log.info("Regla SLA creada: id={}, tipo={}, plazoDias={}", saved.getId(), saved.getTipoDocumento(), saved.getPlazoDias());
        auditService.registerUserManagementEvent(
                "CONFIGURAR_SLA",
                "Regla SLA creada: " + saved.getTipoDocumento() + " con plazo de " + saved.getPlazoDias() + " días hábiles"
        );

        return toResponse(saved);
    }

    @Transactional
    public SlaConfigResponse update(Long id, UpdateSlaConfigRequest request) {
        if (request == null) throw new IllegalArgumentException("El plazo es obligatorio");
        validateDays(request.plazoDias());
        SlaConfig config = slaConfigRepository.findById(id)
                .orElseThrow(() -> new com.capstone.sistema.flow.exception.SlaNotFoundException("Configuración SLA con id " + id + " no encontrada"));

        int plazoAnterior = config.getPlazoDias();
        config.setPlazoDias(request.plazoDias());
        SlaConfig updated = slaConfigRepository.saveAndFlush(config);

        log.info("Regla SLA id={} actualizada de {} a {} días hábiles", id, plazoAnterior, updated.getPlazoDias());
        auditService.registerUserManagementEvent(
                "CONFIGURAR_SLA",
                "Regla SLA actualizada para " + updated.getTipoDocumento() + ": plazo modificado a " + updated.getPlazoDias() + " días hábiles"
        );

        return toResponse(updated);
    }

    @Transactional
    public void delete(Long id) {
        SlaConfig config = slaConfigRepository.findById(id)
                .orElseThrow(() -> new com.capstone.sistema.flow.exception.SlaNotFoundException("Configuración SLA con id " + id + " no encontrada"));

        slaConfigRepository.delete(config);
        log.info("Regla SLA id={} eliminada para {}", id, config.getTipoDocumento());
        auditService.registerUserManagementEvent(
                "CONFIGURAR_SLA",
                "Regla SLA eliminada para tipo de documento: " + config.getTipoDocumento()
        );
    }

    @Transactional(readOnly = true)
    public Instant calculateDeadline(Solicitud solicitud, Instant startTime) {
        if (solicitud == null) {
            return BusinessDaysCalculator.calculateDeadline(startTime != null ? startTime : clock.instant(), DEFAULT_SLA_DAYS);
        }
        return calculateDeadline(solicitud.getTipoDocumento(), solicitud.getTitulo(), startTime);
    }

    @Transactional(readOnly = true)
    public Instant calculateDeadline(String tipoDocumento, Instant startTime) {
        return calculateDeadline(tipoDocumento, tipoDocumento, startTime);
    }

    @Transactional(readOnly = true)
    public Instant calculateDeadline(String tipoDocumento, String titulo, Instant startTime) {
        Integer plazoDias = null;

        // 1. Si tipoDocumento no está en blanco, buscar regla exacta en sla_config primero
        if (tipoDocumento != null && !tipoDocumento.isBlank()) {
            var opt = slaConfigRepository.findByTipoDocumentoIgnoreCase(tipoDocumento.trim());
            if (opt.isPresent()) {
                plazoDias = opt.get().getPlazoDias();
            }
        }

        // 2. Si no se encontró o estaba vacío, fallback a coincidencia por subcadena en titulo
        if (plazoDias == null && titulo != null && !titulo.isBlank()) {
            String trimmedTitulo = titulo.trim();
            String lower = normalize(trimmedTitulo);

            var exactTitulo = slaConfigRepository.findByTipoDocumentoIgnoreCase(trimmedTitulo);
            if (exactTitulo.isPresent()) {
                plazoDias = exactTitulo.get().getPlazoDias();
            } else {
                List<SlaConfig> allConfigs = slaConfigRepository.findAll();
                var matchingConfig = allConfigs.stream()
                        .filter(c -> c.getTipoDocumento() != null && lower.contains(normalize(c.getTipoDocumento())))
                        .sorted(Comparator.<SlaConfig>comparingInt(c -> c.getTipoDocumento().trim().length())
                                .reversed().thenComparing(c -> normalize(c.getTipoDocumento())))
                        .findFirst();

                if (matchingConfig.isPresent()) {
                    plazoDias = matchingConfig.get().getPlazoDias();
                } else {
                    if (lower.contains("contrat")) {
                        plazoDias = findPlazoOrDefault("Contrato", 5);
                    } else if (lower.contains("factur")) {
                        plazoDias = findPlazoOrDefault("Factura", 3);
                    } else if (lower.contains("memorand") || lower.contains("memoránd")) {
                        plazoDias = findPlazoOrDefault("Memorando", findPlazoOrDefault("Memorándum", 2));
                    } else if (lower.contains("inform")) {
                        plazoDias = findPlazoOrDefault("Informe", 7);
                    } else {
                        plazoDias = findPlazoOrDefault("General", DEFAULT_SLA_DAYS);
                    }
                }
            }
        }

        // 3. Si aún no se encontró, default a 5 días hábiles
        if (plazoDias == null) {
            plazoDias = findPlazoOrDefault("General", DEFAULT_SLA_DAYS);
        }

        return BusinessDaysCalculator.calculateDeadline(startTime != null ? startTime : clock.instant(), plazoDias);
    }

    private void validateDays(int days) {
        if (days < 1) throw new IllegalArgumentException("El plazo debe ser un entero positivo");
        BusinessDaysCalculator.calculateDeadline(clock.instant(), days);
    }

    private static String normalize(String text) {
        return text.trim().toLowerCase(Locale.ROOT);
    }

    private static boolean isUniqueViolation(Throwable error) {
        for (Throwable cause = error; cause != null; cause = cause.getCause()) {
            if (cause instanceof SQLException sql && "23505".equals(sql.getSQLState())) return true;
        }
        return false;
    }

    private int findPlazoOrDefault(String tipo, int def) {
        return slaConfigRepository.findByTipoDocumentoIgnoreCase(tipo)
                .map(SlaConfig::getPlazoDias)
                .orElse(def);
    }

    private SlaConfigResponse toResponse(SlaConfig entity) {
        return new SlaConfigResponse(
                entity.getId(),
                entity.getTipoDocumento(),
                entity.getPlazoDias(),
                entity.getCreatedAt(),
                entity.getUpdatedAt()
        );
    }
}
