package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/** Resumen de seguimiento; no contiene documentos, historia ni datos de autenticación. */
public record MyRequestsSummaryResponse(
        UUID id,
        String correlativo,
        String titulo,
        String estado,
        Instant createdAt,
        Instant updatedAt,
        Long version,
        EtapaSolicitudResponse etapaActual,
        String emisorNombre,
        boolean propia,
        AreaDetalleResponse areaOrigen,
        AreaDetalleResponse areaFlujo,
        List<String> accionesPermitidas,
        String detalleUrl
) {
    public MyRequestsSummaryResponse {
        accionesPermitidas = List.copyOf(accionesPermitidas);
    }
}
