package com.capstone.sistema.users.exception;

public class InvalidCurrentPasswordException extends RuntimeException {

    public InvalidCurrentPasswordException() {
        super("La contraseña actual es incorrecta, inténtelo nuevamente.");
    }

    public InvalidCurrentPasswordException(String message) {
        super(message);
    }
}
