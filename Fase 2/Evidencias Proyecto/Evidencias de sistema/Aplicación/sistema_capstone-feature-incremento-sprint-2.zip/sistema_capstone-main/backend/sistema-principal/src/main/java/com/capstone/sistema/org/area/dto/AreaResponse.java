package com.capstone.sistema.org.area.dto;

import java.time.Instant;
import java.util.UUID;

public record AreaResponse(
        Long id,
        String nombre,
        String descripcion,
        boolean activo,
        Long areaPadreId,
        String areaPadreNombre,
        UUID administradorId,
        String administradorNombre,
        String administradorEmail,
        Instant createdAt,
        Instant updatedAt,
        long version
) {
}
