package com.capstone.sistema.audit.repository;

import com.capstone.sistema.audit.model.TipoEvento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TipoEventoRepository extends JpaRepository<TipoEvento, Long> {

    Optional<TipoEvento> findByTipoIgnoreCase(String tipo);
}
