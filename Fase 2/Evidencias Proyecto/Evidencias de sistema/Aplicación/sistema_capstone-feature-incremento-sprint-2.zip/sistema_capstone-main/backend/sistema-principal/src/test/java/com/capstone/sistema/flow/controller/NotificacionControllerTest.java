package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.NotificacionResponse;
import com.capstone.sistema.flow.service.NotificacionService;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NotificacionController.class)
@Import(SecurityConfig.class)
class NotificacionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NotificacionService notificacionService;

    @MockBean
    private CurrentUserResolver currentUserResolver;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    private UserAccount testUser;

    @BeforeEach
    void setUp() {
        testUser = new UserAccount("kc-1", "usuario@test.local", "Juan", "Perez", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(testUser, "id", UUID.randomUUID());
    }

    @Test
    void rejectsUnauthenticated() throws Exception {
        mockMvc.perform(get("/api/notificaciones"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void listarMisNotificaciones_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.listarMisNotificaciones(testUser)).thenReturn(List.of(
                new NotificacionResponse(1L, "Nueva Solicitud", "Hay un documento", "NUEVA_SOLICITUD",
                        UUID.randomUUID(), false, Instant.now(), null)
        ));

        mockMvc.perform(get("/api/notificaciones")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Nueva Solicitud"))
                .andExpect(jsonPath("$[0].leida").value(false));
    }

    @Test
    void contarNoLeidas_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.contarNoLeidas(testUser)).thenReturn(5L);

        mockMvc.perform(get("/api/notificaciones/no-leidas/count")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.count").value(5));
    }

    @Test
    void marcarComoLeida_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarComoLeida(10L, testUser)).thenReturn(
                new NotificacionResponse(10L, "Aprobada", "Mensaje", "APROBACION",
                        UUID.randomUUID(), true, Instant.now(), Instant.now())
        );

        mockMvc.perform(patch("/api/notificaciones/10/leer")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.leida").value(true));
    }

    @Test
    void marcarTodasComoLeidas_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarTodasComoLeidas(testUser)).thenReturn(3);

        mockMvc.perform(patch("/api/notificaciones/marcar-todas-leidas")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.actualizadas").value(3));
    }

    @Test
    void marcarComoLeida_UsuarioNoEsDestinatario_Retorna403Forbidden() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarComoLeida(99L, testUser))
                .thenThrow(new org.springframework.security.access.AccessDeniedException("No tienes permiso para marcar esta notificación"));

        mockMvc.perform(patch("/api/notificaciones/99/leer")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isForbidden());
    }

    @Test
    void listarMisNotificaciones_DistincionEstadoLeidaYNoLeida_YRedireccionPrecisa() throws Exception {
        UUID solId = UUID.randomUUID();
        Instant leidaTimestamp = Instant.now();
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.listarMisNotificaciones(testUser)).thenReturn(List.of(
                new NotificacionResponse(1L, "Nueva Solicitud", "Hay un documento", "NUEVA_SOLICITUD",
                        solId, false, Instant.now(), null),
                new NotificacionResponse(2L, "Solicitud Aprobada", "Tu solicitud fue aprobada", "APROBACION",
                        solId, true, Instant.now().minusSeconds(3600), leidaTimestamp)
        ));

        mockMvc.perform(get("/api/notificaciones")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].leida").value(false))
                .andExpect(jsonPath("$[0].leidaEn").doesNotExist())
                .andExpect(jsonPath("$[0].solicitudId").value(solId.toString()))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].leida").value(true))
                .andExpect(jsonPath("$[1].leidaEn").exists())
                .andExpect(jsonPath("$[1].solicitudId").value(solId.toString()));
    }
}
