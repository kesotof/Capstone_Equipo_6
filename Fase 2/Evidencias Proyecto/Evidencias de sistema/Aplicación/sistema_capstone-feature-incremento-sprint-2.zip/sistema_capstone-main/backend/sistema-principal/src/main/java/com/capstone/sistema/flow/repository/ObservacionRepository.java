package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Observacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface ObservacionRepository extends JpaRepository<Observacion, Long> {

    List<Observacion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId);

    List<Observacion> findBySolicitud_IdAndResueltaFalse(UUID solicitudId);

    @Query("""
            select o.id as id, o.contenido as contenido, o.resuelta as resuelta,
                   u.firstName as usuarioNombre, u.lastName as usuarioApellido,
                   o.createdAt as createdAt, t.id as transicionId,
                   e.id as etapaId, e.orden as etapaOrden, e.nombre as etapaNombre
            from Observacion o
            join o.usuario u
            left join o.solicitudTransicion t
            left join t.etapaOrigen e
            where o.solicitud.id = :solicitudId
            order by o.createdAt asc, o.id asc
            """)
    List<Detalle> consultarDetalle(@Param("solicitudId") UUID solicitudId);

    interface Detalle {
        Long getId();
        String getContenido();
        boolean getResuelta();
        String getUsuarioNombre();
        String getUsuarioApellido();
        Instant getCreatedAt();
        Long getTransicionId();
        Long getEtapaId();
        Integer getEtapaOrden();
        String getEtapaNombre();
    }
}
