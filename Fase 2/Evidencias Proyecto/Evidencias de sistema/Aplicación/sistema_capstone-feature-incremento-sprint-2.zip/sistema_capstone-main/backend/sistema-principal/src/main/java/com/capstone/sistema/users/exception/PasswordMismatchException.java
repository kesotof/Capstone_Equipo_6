package com.capstone.sistema.users.exception;

public class PasswordMismatchException extends RuntimeException {

    public PasswordMismatchException() {
        super("Las contraseñas no coinciden.");
    }

    public PasswordMismatchException(String message) {
        super(message);
    }
}
