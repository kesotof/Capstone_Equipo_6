package com.capstone.sistema.users.dto;

public record PasswordPolicyResponse(
        int minLength,
        int maxLength,
        int minUppercase,
        int minLowercase,
        int minDigits,
        int minSpecial,
        boolean notUsername,
        boolean notEmail,
        String username,
        String email,
        boolean additionalRules
) {
}
