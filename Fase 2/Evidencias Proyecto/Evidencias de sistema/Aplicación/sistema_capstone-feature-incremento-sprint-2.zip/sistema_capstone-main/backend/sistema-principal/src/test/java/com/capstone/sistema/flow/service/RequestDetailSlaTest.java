package com.capstone.sistema.flow.service;

import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.flow.util.SlaStatusCalculator;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RequestDetailSlaTest {
    @Mock private SolicitudRepository requests;
    @Mock private DocumentoRepository documents;
    @Mock private ObservacionRepository observations;
    @Mock private SolicitudTransicionRepository history;
    @Mock private AreaRepository areas;
    @Mock private RbacAccessService rbac;
    @Mock private SolicitudService requestService;
    private RequestDetailService service;
    private static final Instant NOW = Instant.parse("2026-10-09T13:00:00Z");

    @BeforeEach
    void setUp() {
        service = new RequestDetailService(requests, documents, observations, history, areas, rbac,
                requestService, Clock.fixed(NOW, ZoneOffset.UTC));
        when(rbac.visible(any())).thenReturn((root, query, builder) -> builder.conjunction());
        when(documents.findBySolicitud_IdOrderByVersionDescCreatedAtDescIdAsc(any())).thenReturn(List.of());
    }

    @ParameterizedTest
    @CsvSource({"PENDIENTE_REVISION,86400,NORMAL,true", "PENDIENTE_REVISION,86399,POR_VENCER,true",
            "PENDIENTE_REVISION,-1,VENCIDO,true", "CORRECCION_REQUERIDA,-1,VENCIDO,false",
            "APROBADO,-1,VENCIDO,false", "RECHAZADO,-1,VENCIDO,false"})
    void sla_seEvaluaUnaVezYSoloSePresentaActivoEnRevision(String state, long seconds, String status, boolean active) {
        Solicitud request = request(state, NOW.plusSeconds(seconds));
        var detail = service.consultar(request.getId());
        assertThat(detail.sla().evaluadoEn()).isEqualTo(NOW);
        assertThat(detail.sla().deadline()).isEqualTo(request.getDeadline());
        assertThat(detail.sla().status()).isEqualTo(status);
        assertThat(detail.sla().enRevision()).isEqualTo(active);
        verify(requestService).calculateSlaStatus(request.getDeadline(), NOW);
        verify(requests, never()).save(any());
        verify(history, never()).save(any());
    }

    @Test
    void historicoSinPlazoNoTieneAlertaActiva() {
        Solicitud request = request("PENDIENTE_REVISION", null);
        var detail = service.consultar(request.getId());
        assertThat(detail.sla().deadline()).isNull();
        assertThat(detail.sla().status()).isNull();
        assertThat(detail.sla().enRevision()).isFalse();
        verify(requests, never()).save(any());
    }

    private Solicitud request(String state, Instant deadline) {
        FlujoDefinicion flow = new FlujoDefinicion("SLA", "Prueba aislada");
        ReflectionTestUtils.setField(flow, "id", 1L);
        UserAccount issuer = new UserAccount("issuer", "issuer@test.local", "Usuario", "Prueba", true, Set.of());
        ReflectionTestUtils.setField(issuer, "id", UUID.randomUUID());
        Solicitud request = new Solicitud(flow, issuer, "Documento", "Antecedentes",
                new EstadoSolicitud(1L, state), new FlujoEtapa(flow, 1, "Revisión"));
        ReflectionTestUtils.setField(request, "id", UUID.randomUUID());
        request.setDeadline(deadline);
        when(requests.findOne(any(Specification.class))).thenReturn(Optional.of(request));
        when(requestService.allowedActions(request)).thenReturn(List.of());
        when(requestService.calculateSlaStatus(deadline, NOW)).thenReturn(SlaStatusCalculator.status(deadline, NOW));
        return request;
    }
}
