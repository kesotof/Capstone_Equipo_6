package com.capstone.sistema.users.util;

import com.capstone.sistema.users.exception.RutInvalidoException;

import java.util.Locale;

/**
 * Validador y normalizador de RUT chileno basado en el algoritmo oficial de Módulo 11.
 * Referencia: https://es.wikipedia.org/wiki/Rol_%C3%9Anico_Tributario
 */
public final class RutValidator {

    private RutValidator() {
    }

    /**
     * Valida un RUT chileno con o sin puntos y con o sin guion.
     * Retorna true si el formato y el dígito verificador son válidos.
     */
    public static boolean esValido(String rut) {
        if (rut == null || rut.isBlank()) {
            return false;
        }

        String limpio = limpiar(rut);
        if (limpio.length() < 7 || limpio.length() > 9) {
            return false;
        }

        String cuerpo = limpio.substring(0, limpio.length() - 1);
        char dvIngresado = Character.toUpperCase(limpio.charAt(limpio.length() - 1));

        if (!cuerpo.chars().allMatch(Character::isDigit)) {
            return false;
        }

        if (!Character.isDigit(dvIngresado) && dvIngresado != 'K') {
            return false;
        }

        char dvCalculado = calcularDigitoVerificador(cuerpo);
        return dvIngresado == dvCalculado;
    }

    /**
     * Valida y normaliza el RUT al formato canónico XXXXXXXX-X (sin puntos, guion antes del DV en mayúscula).
     * Lanza RutInvalidoException si el RUT no es válido.
     */
    public static String normalizar(String rut) {
        if (!esValido(rut)) {
            throw new RutInvalidoException("El RUT ingresado no es válido o tiene un dígito verificador incorrecto");
        }
        String limpio = limpiar(rut);
        String cuerpo = limpio.substring(0, limpio.length() - 1);
        char dv = Character.toUpperCase(limpio.charAt(limpio.length() - 1));
        return cuerpo + "-" + dv;
    }

    /**
     * Calcula el dígito verificador para el cuerpo numérico según el algoritmo Módulo 11 chileno.
     */
    public static char calcularDigitoVerificador(String cuerpoNumerico) {
        int suma = 0;
        int multiplicador = 2;

        for (int i = cuerpoNumerico.length() - 1; i >= 0; i--) {
            int digito = cuerpoNumerico.charAt(i) - '0';
            suma += digito * multiplicador;
            multiplicador = (multiplicador == 7) ? 2 : multiplicador + 1;
        }

        int resto = suma % 11;
        int resultado = 11 - resto;

        if (resultado == 11) {
            return '0';
        } else if (resultado == 10) {
            return 'K';
        } else {
            return (char) ('0' + resultado);
        }
    }

    /**
     * Remueve espacios, puntos y guiones del RUT.
     */
    public static String limpiar(String rut) {
        if (rut == null) {
            return "";
        }
        return rut.replace(".", "")
                .replace("-", "")
                .trim()
                .toUpperCase(Locale.ROOT);
    }
}
