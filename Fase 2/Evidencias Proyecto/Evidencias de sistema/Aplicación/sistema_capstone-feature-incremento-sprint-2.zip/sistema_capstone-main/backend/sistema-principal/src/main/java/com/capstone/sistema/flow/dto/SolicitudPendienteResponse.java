package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

/** Proyección reducida para la tabla de revisiones con correlativo, deadline y estado SLA. */
public record SolicitudPendienteResponse(
        UUID id,
        String correlativo,
        String titulo,
        String nombreArchivo,
        String emisorNombre,
        String emisorEmail,
        Instant fechaCreacion,
        Instant deadline,
        String slaStatus,
        String estado
) {
    public SolicitudPendienteResponse(
            UUID id,
            String titulo,
            String nombreArchivo,
            String emisorNombre,
            String emisorEmail,
            Instant fechaCreacion,
            String estado
    ) {
        this(id, null, titulo, nombreArchivo, emisorNombre, emisorEmail, fechaCreacion, null, null, estado);
    }
}
