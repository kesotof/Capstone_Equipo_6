package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.exception.AiAnalysisNotFoundException;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.flow.service.AiAnalysisService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AiAnalysisController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class AiAnalysisControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AiAnalysisService aiAnalysisService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("Debe rechazar solicitudes no autenticadas con 401 Unauthorized")
    void shouldRejectUnauthenticatedRequests() throws Exception {
        UUID id = UUID.randomUUID();
        mockMvc.perform(get("/api/solicitudes/" + id + "/ai-analysis"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Debe responder 202 Accepted cuando se crea una nueva tarea de análisis")
    void shouldReturn202AcceptedWhenNewAnalysisIsCreated() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID analysisId = UUID.randomUUID();
        AiAnalysisResponse response = new AiAnalysisResponse(
                analysisId, solId, UUID.randomUUID(), EstadoAnalisis.PENDIENTE,
                null, null, null, List.of(), null, "prompt test", false,
                Instant.now(), null
        );

        when(aiAnalysisService.solicitarAnalisis(eq(solId), any(), anyBoolean())).thenReturn(response);

        mockMvc.perform(post("/api/solicitudes/" + solId + "/ai-analysis")
                        .with(jwt().jwt(j -> j.claim("preferred_username", "operador@capstone.local")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"prompt\": \"Verificar coherencia\"}"))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.id").value(analysisId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.cached").value(false));
    }

    @Test
    @DisplayName("Debe responder 200 OK cuando el análisis proviene de caché (cached=true)")
    void shouldReturn200OkWhenAnalysisIsCached() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID analysisId = UUID.randomUUID();
        AiAnalysisResponse response = new AiAnalysisResponse(
                analysisId, solId, UUID.randomUUID(), EstadoAnalisis.COMPLETADO,
                92, true, "Todo en orden", List.of("Aclarar firma"), "meta-llama/llama-3.3-70b-instruct:free",
                "prompt test", true, Instant.now(), Instant.now()
        );

        when(aiAnalysisService.solicitarAnalisis(eq(solId), any(), anyBoolean())).thenReturn(response);

        mockMvc.perform(post("/api/solicitudes/" + solId + "/ai-analysis")
                        .with(jwt().jwt(j -> j.claim("preferred_username", "operador@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(analysisId.toString()))
                .andExpect(jsonPath("$.estado").value("COMPLETADO"))
                .andExpect(jsonPath("$.cached").value(true))
                .andExpect(jsonPath("$.puntaje").value(92));
    }

    @Test
    @DisplayName("Debe responder 200 OK en GET si el análisis existe")
    void shouldReturn200OkOnGetIfAnalysisExists() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID analysisId = UUID.randomUUID();
        AiAnalysisResponse response = new AiAnalysisResponse(
                analysisId, solId, UUID.randomUUID(), EstadoAnalisis.COMPLETADO,
                85, true, "Documento revisado", List.of(), "meta-llama", null,
                false, Instant.now(), Instant.now()
        );

        when(aiAnalysisService.obtenerUltimoAnalisis(solId)).thenReturn(response);

        mockMvc.perform(get("/api/solicitudes/" + solId + "/ai-analysis")
                        .with(jwt().jwt(j -> j.claim("preferred_username", "operador@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(analysisId.toString()))
                .andExpect(jsonPath("$.puntaje").value(85));
    }

    @Test
    @DisplayName("Debe responder 404 Not Found si no existe análisis para la solicitud")
    void shouldReturn404IfAnalysisNotFound() throws Exception {
        UUID solId = UUID.randomUUID();
        when(aiAnalysisService.obtenerUltimoAnalisis(solId)).thenThrow(new AiAnalysisNotFoundException(solId));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/ai-analysis")
                        .with(jwt().jwt(j -> j.claim("preferred_username", "operador@capstone.local"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.title").value("Análisis de IA No Encontrado"));
    }
}
