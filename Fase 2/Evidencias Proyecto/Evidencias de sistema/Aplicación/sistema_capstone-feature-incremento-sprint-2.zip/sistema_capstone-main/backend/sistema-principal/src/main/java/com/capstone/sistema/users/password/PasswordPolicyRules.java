package com.capstone.sistema.users.password;

import com.capstone.sistema.users.dto.PasswordPolicyResponse;
import com.capstone.sistema.users.exception.PasswordChangeException;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.IntPredicate;
import java.util.regex.Pattern;

public final class PasswordPolicyRules {
    private static final Pattern RULE = Pattern.compile("^([A-Za-z][A-Za-z0-9]*)(?:\\((.*)\\))?$");
    private static final Set<String> PRESENTED = Set.of("length", "maxLength", "upperCase", "lowerCase", "digits", "specialChars", "notUsername", "notEmail");
    private static final Set<String> METADATA = Set.of("hashAlgorithm", "hashIterations", "forceExpiredPasswordChange", "maxAuthAge");

    private PasswordPolicyRules() { }

    public static PasswordPolicyResponse from(String expression, UserRepresentation user) {
        Map<String, String> values = new HashMap<>();
        boolean additional = false;
        if (expression != null && !expression.isBlank()) {
            for (String part : expression.split("\\s+and\\s+")) {
                var matcher = RULE.matcher(part.trim());
                if (!matcher.matches()) { additional = true; continue; }
                String name = matcher.group(1);
                values.put(name, matcher.group(2));
                if (!PRESENTED.contains(name) && !METADATA.contains(name)) additional = true;
            }
        }
        int min = Math.max(8, number(values, "length", 8));
        int max = Math.min(1024, number(values, "maxLength", 1024));
        if (min > max) throw PasswordChangeException.unavailable();
        return new PasswordPolicyResponse(min, max,
                number(values, "upperCase", 0), number(values, "lowerCase", 0),
                number(values, "digits", 0), number(values, "specialChars", 0),
                enabled(values, "notUsername"), enabled(values, "notEmail"),
                user.getUsername(), user.getEmail(), additional);
    }

    private static int number(Map<String, String> values, String name, int fallback) {
        if (!values.containsKey(name)) return fallback;
        String raw = values.get(name);
        try {
            int value = raw == null || raw.isBlank() ? (fallback == 0 ? 1 : fallback) : Integer.parseInt(raw);
            if (value < 0 || value > 1024) throw PasswordChangeException.unavailable();
            return value;
        } catch (NumberFormatException exception) {
            throw PasswordChangeException.unavailable();
        }
    }

    private static boolean enabled(Map<String, String> values, String name) {
        if (!values.containsKey(name)) return false;
        String raw = values.get(name);
        if (raw == null || raw.isBlank() || "true".equalsIgnoreCase(raw)) return true;
        if ("false".equalsIgnoreCase(raw)) return false;
        throw PasswordChangeException.unavailable();
    }

    public static void validate(String password, PasswordPolicyResponse policy) {
        boolean valid = password.length() >= policy.minLength() && password.length() <= policy.maxLength()
                && count(password, Character::isUpperCase) >= policy.minUppercase()
                && count(password, Character::isLowerCase) >= policy.minLowercase()
                && count(password, Character::isDigit) >= policy.minDigits()
                && count(password, character -> !Character.isLetterOrDigit(character)) >= policy.minSpecial()
                && !(policy.notUsername() && password.equals(policy.username()))
                && !(policy.notEmail() && password.equals(policy.email()));
        if (!valid) {
            throw new PasswordChangeException(HttpStatus.BAD_REQUEST, "PASSWORD_VALIDATION_FAILED",
                    "La nueva contraseña no cumple los requisitos de seguridad.",
                    Map.of("newPassword", "La nueva contraseña no cumple los requisitos de seguridad."));
        }
    }

    private static long count(String password, IntPredicate predicate) {
        return password.chars().filter(predicate).count();
    }
}
