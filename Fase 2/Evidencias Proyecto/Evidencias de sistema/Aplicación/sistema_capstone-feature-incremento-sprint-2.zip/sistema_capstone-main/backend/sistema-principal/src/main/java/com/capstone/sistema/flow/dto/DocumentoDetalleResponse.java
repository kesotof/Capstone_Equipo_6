package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record DocumentoDetalleResponse(
        UUID id,
        String nombreArchivo,
        String contentType,
        Long sizeBytes,
        int version,
        boolean vigente,
        Instant createdAt,
        String descargaUrl,
        boolean previsualizable
) {
}
