package com.capstone.sistema.flow.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.net.URI;
import java.time.Instant;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Order(Ordered.HIGHEST_PRECEDENCE + 100)
@RestControllerAdvice
public class FlowExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(FlowExceptionHandler.class);

    @ExceptionHandler(org.springframework.orm.ObjectOptimisticLockingFailureException.class)
    public ProblemDetail handleVersionConflict(org.springframework.orm.ObjectOptimisticLockingFailureException ex) {
        ProblemDetail problem=ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT,"El recurso cambió. Recargue antes de volver a guardar.");
        problem.setTitle("Conflicto de versión");
        problem.setProperty("code", "VERSION_CONFLICTO");
        problem.setProperty("timestamp",Instant.now());
        return problem;
    }

    @ExceptionHandler(FlujoNotFoundException.class)
    public ProblemDetail handleFlujoNotFound(FlujoNotFoundException ex) {
        log.warn("Flujo no encontrado: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Flujo No Encontrado");
        problem.setType(URI.create("https://capstone.local/errors/flujo-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(FlujoConflictException.class)
    public ProblemDetail handleFlujoConflict(FlujoConflictException ex) {
        log.warn("Conflicto en flujo: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problem.setTitle("Conflicto en Definición de Flujo");
        problem.setType(URI.create("https://capstone.local/errors/flujo-conflict"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(SolicitudNotFoundException.class)
    public ProblemDetail handleSolicitudNotFound(SolicitudNotFoundException ex) {
        log.warn("Solicitud no encontrada: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Solicitud No Encontrada");
        problem.setType(URI.create("https://capstone.local/errors/solicitud-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(DocumentoNoDisponibleException.class)
    public ProblemDetail handleDocumentoNoDisponible(DocumentoNoDisponibleException ex) {
        log.warn("Documento no disponible: {}", ex.getMessage());
        String detail = (ex.getMessage() != null && !ex.getMessage().isBlank())
                ? ex.getMessage()
                : "El archivo no está disponible.";
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, detail);
        problem.setTitle("Documento No Disponible");
        problem.setType(URI.create("https://capstone.local/errors/documento-no-disponible"));
        problem.setProperty("code", "DOCUMENTO_NO_DISPONIBLE");
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(InvalidTransitionException.class)
    public ProblemDetail handleInvalidTransition(InvalidTransitionException ex) {
        log.warn("Transición inválida: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problem.setTitle("Transición de Estado Inválida");
        problem.setType(URI.create("https://capstone.local/errors/invalid-transition"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(UnauthorizedActionException.class)
    public ProblemDetail handleUnauthorizedAction(UnauthorizedActionException ex) {
        log.warn("Acción no autorizada en flujo: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, ex.getMessage());
        problem.setTitle("Acción No Autorizada");
        problem.setType(URI.create("https://capstone.local/errors/unauthorized-action"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(InvalidDocumentFormatException.class)
    public ProblemDetail handleInvalidDocumentFormat(InvalidDocumentFormatException ex) {
        log.warn("Documento inválido: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Documento Inválido");
        problem.setType(URI.create("https://capstone.local/errors/invalid-document"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ProblemDetail handleIllegalArgument(IllegalArgumentException ex) {
        log.warn("Solicitud inválida: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Solicitud Inválida");
        problem.setType(URI.create("https://capstone.local/errors/invalid-request"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(AiAnalysisNotFoundException.class)
    public ProblemDetail handleAiAnalysisNotFound(AiAnalysisNotFoundException ex) {
        log.warn("Análisis de IA no encontrado: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Análisis de IA No Encontrado");
        problem.setType(URI.create("https://capstone.local/errors/ai-analysis-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(SlaNotFoundException.class)
    public ProblemDetail handleSlaNotFound(SlaNotFoundException ex) {
        log.warn("Configuración SLA no encontrada: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Regla SLA No Encontrada");
        problem.setType(URI.create("https://capstone.local/errors/sla-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(org.springframework.web.bind.MethodArgumentNotValidException ex) {
        log.warn("Error de validación en parámetros de entrada: {}", ex.getMessage());
        java.util.Map<String, String> invalidFields = new java.util.LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                invalidFields.putIfAbsent(error.getField(), error.getDefaultMessage())
        );
        ProblemDetail problem = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problem.setTitle("Error de validación");
        problem.setDetail("Revisa los campos enviados e inténtalo nuevamente.");
        problem.setType(URI.create("https://capstone.local/errors/validation-error"));
        problem.setProperty("invalidFields", invalidFields);
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.http.converter.HttpMessageNotReadableException.class)
    public ProblemDetail handleHttpMessageNotReadable(org.springframework.http.converter.HttpMessageNotReadableException ex) {
        log.warn("Cuerpo de petición malformado o ilegible: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                "El cuerpo de la solicitud no es un JSON válido o contiene tipos de datos incorrectos."
        );
        problem.setTitle("Cuerpo de solicitud inválido");
        problem.setType(URI.create("https://capstone.local/errors/invalid-body"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleTypeMismatch(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException ex) {
        log.warn("Tipo de dato de parámetro incompatible: {} = {}", ex.getName(), ex.getValue());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                String.format("El parámetro '%s' tiene un formato o tipo inválido: '%s'", ex.getName(), ex.getValue())
        );
        problem.setTitle("Parámetro inválido");
        problem.setType(URI.create("https://capstone.local/errors/invalid-parameter"));
        problem.setProperty("parametro", ex.getName());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(jakarta.validation.ConstraintViolationException.class)
    public ProblemDetail handleConstraintViolation(jakarta.validation.ConstraintViolationException ex) {
        log.warn("Violación de restricciones en parámetros: {}", ex.getMessage());
        java.util.Map<String, String> violations = new java.util.LinkedHashMap<>();
        ex.getConstraintViolations().forEach(v -> {
            String property = v.getPropertyPath() != null ? v.getPropertyPath().toString() : "param";
            violations.putIfAbsent(property, v.getMessage());
        });
        ProblemDetail problem = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problem.setTitle("Restricción de parámetro violada");
        problem.setDetail("Uno o más parámetros no cumplen las restricciones requeridas.");
        problem.setType(URI.create("https://capstone.local/errors/constraint-violation"));
        problem.setProperty("violations", violations);
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.bind.MissingServletRequestParameterException.class)
    public ProblemDetail handleMissingServletRequestParameter(org.springframework.web.bind.MissingServletRequestParameterException ex) {
        log.warn("Parámetro requerido ausente: {}", ex.getParameterName());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                String.format("El parámetro obligatorio '%s' no fue proporcionado en la solicitud.", ex.getParameterName())
        );
        problem.setTitle("Parámetro requerido ausente");
        problem.setType(URI.create("https://capstone.local/errors/missing-parameter"));
        problem.setProperty("parametro", ex.getParameterName());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.multipart.support.MissingServletRequestPartException.class)
    public ProblemDetail handleMissingServletRequestPart(org.springframework.web.multipart.support.MissingServletRequestPartException ex) {
        log.warn("Parte multipart requerida ausente: {}", ex.getRequestPartName());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                String.format("La parte requerida '%s' no fue proporcionada en la solicitud multipart.", ex.getRequestPartName())
        );
        problem.setTitle("Parte requerida ausente");
        problem.setType(URI.create("https://capstone.local/errors/missing-part"));
        problem.setProperty("parte", ex.getRequestPartName());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ProblemDetail handleMaxUploadSize(MaxUploadSizeExceededException ex) {
        log.warn("Tamaño de archivo excedido: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                "El tamaño del archivo excede el límite máximo permitido (10 MB)"
        );
        problem.setTitle("Tamaño de Archivo Excedido");
        problem.setType(URI.create("https://capstone.local/errors/max-upload-size"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }
}
