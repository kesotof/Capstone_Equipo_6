package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "solicitud", indexes = {
        @Index(name = "idx_solicitud_emisor", columnList = "usuario_id"),
        @Index(name = "idx_solicitud_estado", columnList = "estado_solicitud_id"),
        @Index(name = "idx_solicitud_tipo_documento", columnList = "tipo_documento")
})
public class Solicitud {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Version
    @Column(nullable = false)
    private Long version;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_definicion_id", nullable = false)
    private FlujoDefinicion flujoDefinicion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount emisor;

    @Column(name = "area_origen_id", updatable = false)
    private Long areaOrigenId;
    @Column(name = "area_flujo_id", updatable = false)
    private Long areaFlujoId;
    public Long getAreaOrigenId() { return areaOrigenId; }
    public Long getAreaFlujoId() { return areaFlujoId; }
    public void captureAreas(Long origen, Long flujo) { this.areaOrigenId=origen; this.areaFlujoId=flujo; }

    @Column(nullable = false, length = 255)
    private String titulo;

    @Column(name = "tipo_documento", length = 100)
    private String tipoDocumento;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "estado_solicitud_id", nullable = false)
    private EstadoSolicitud estadoSolicitud;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_etapa_id", nullable = false)
    private FlujoEtapa flujoEtapa;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(length = 25, unique = true)
    private String correlativo;

    @Column
    private Instant deadline;

    protected Solicitud() {
    }

    public Solicitud(
            FlujoDefinicion flujoDefinicion,
            UserAccount emisor,
            String titulo,
            String descripcion,
            EstadoSolicitud estadoSolicitud,
            FlujoEtapa flujoEtapa
    ) {
        this.flujoDefinicion = flujoDefinicion;
        this.emisor = emisor;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.estadoSolicitud = estadoSolicitud;
        this.flujoEtapa = flujoEtapa;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (updatedAt == null) {
            updatedAt = createdAt;
        }
    }

    public void captureRegistration(Instant registeredAt) {
        if (id != null || createdAt != null) {
            throw new IllegalStateException("La fecha de registro de la solicitud es inmutable");
        }
        createdAt = java.util.Objects.requireNonNull(registeredAt);
        updatedAt = registeredAt;
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public Long getVersion() { return version; }
    public void touch() { updatedAt = Instant.now(); }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public UserAccount getEmisor() {
        return emisor;
    }

    public void setEmisor(UserAccount emisor) {
        this.emisor = emisor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public EstadoSolicitud getEstadoSolicitud() {
        return estadoSolicitud;
    }

    public void setEstadoSolicitud(EstadoSolicitud estadoSolicitud) {
        this.estadoSolicitud = estadoSolicitud;
    }

    public FlujoEtapa getFlujoEtapa() {
        return flujoEtapa;
    }

    public void setFlujoEtapa(FlujoEtapa flujoEtapa) {
        this.flujoEtapa = flujoEtapa;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public String getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(String correlativo) {
        this.correlativo = correlativo;
    }

    public Instant getDeadline() {
        return deadline;
    }

    public void setDeadline(Instant deadline) {
        this.deadline = deadline;
    }
}
