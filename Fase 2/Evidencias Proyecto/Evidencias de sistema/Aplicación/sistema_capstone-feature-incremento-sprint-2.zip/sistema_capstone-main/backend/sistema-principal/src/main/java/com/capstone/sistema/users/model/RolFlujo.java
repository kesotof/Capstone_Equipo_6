package com.capstone.sistema.users.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "rol_flujo")
public class RolFlujo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String nombre;

    @Column(name = "nombre_visible", nullable = false, length = 100)
    private String nombreVisible;
    @Column(length = 1000)
    private String descripcion;
    @Column(nullable = false)
    private boolean activo = true;
    @Column(nullable = false)
    private boolean sistema;
    @jakarta.persistence.Version
    @Column(nullable = false)
    private long version;
    @Column(name = "created_at", nullable = false, updatable = false)
    private java.time.Instant createdAt;
    @Column(name = "updated_at", nullable = false)
    private java.time.Instant updatedAt;

    public boolean isActivo() { return activo; }
    public boolean isSistema() { return sistema; }
    public String getNombreVisible() { return nombreVisible; }
    public String getDescripcion() { return descripcion; }
    public long getVersion() { return version; }
    @jakarta.persistence.PrePersist
    void initialize() {
        if (nombreVisible==null) nombreVisible=nombre;
        createdAt=java.time.Instant.now(); updatedAt=createdAt;
    }
    @jakarta.persistence.PreUpdate
    void updateTimestamp() { updatedAt=java.time.Instant.now(); }

    protected RolFlujo() {
    }

    public RolFlujo(String nombre) {
        this.nombre = nombre;
        this.nombreVisible = nombre;
    }

    public RolFlujo(Long id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.nombreVisible = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolFlujo rolFlujo = (RolFlujo) o;
        return Objects.equals(nombre, rolFlujo.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
}
