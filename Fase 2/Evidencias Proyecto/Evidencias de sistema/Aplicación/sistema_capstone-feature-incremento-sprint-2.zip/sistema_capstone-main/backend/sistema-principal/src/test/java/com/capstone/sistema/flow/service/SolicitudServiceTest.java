package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.DocumentoNoDisponibleException;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.rbac.dto.RbacDtos;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.exception.RbacException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.time.Clock;
import java.time.ZoneOffset;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@org.mockito.junit.jupiter.MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
class SolicitudServiceTest {

    @Mock
    private SolicitudRepository solicitudRepository;
    @Mock
    private DocumentoRepository documentoRepository;
    @Mock
    private FormatoDocumentoRepository formatoDocumentoRepository;
    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;
    @Mock
    private FlujoEtapaRepository flujoEtapaRepository;
    @Mock
    private EstadoSolicitudRepository estadoSolicitudRepository;
    @Mock
    private AccionUsuarioRepository accionUsuarioRepository;
    @Mock
    private SolicitudTransicionRepository solicitudTransicionRepository;
    @Mock
    private ObservacionRepository observacionRepository;
    @Mock
    private MinioStorageService storageService;
    @Mock
    private NotificacionService notificacionService;
    @Mock
    private AuditService auditService;
    @Mock
    private CurrentUserResolver currentUserResolver;
    @Mock
    private AreaRepository areaRepository;
    @Mock
    private RbacAccessService rbacAccessService;
    @Mock
    private RbacManagementService rbacManagementService;
    @Mock
    private FlujoConcurrencyService concurrency;
    @Mock
    private FlujoIntegrityService integrity;

    private SolicitudService solicitudService;
    private static final Instant SLA_NOW = Instant.parse("2026-10-09T13:00:00Z");

    private UserAccount emisor;
    private UserAccount revisor;
    private UserAccount admin;
    private FlujoDefinicion flujoDef;
    private FlujoEtapa etapa;
    private EstadoSolicitud estadoPendiente;
    private EstadoSolicitud estadoAprobado;
    private EstadoSolicitud estadoRechazado;
    private EstadoSolicitud estadoCorreccion;
    private AccionUsuario accionCrear;
    private AccionUsuario accionAprobar;
    private AccionUsuario accionRechazar;
    private AccionUsuario accionCorreccion;
    private AccionUsuario accionReenviar;

    @BeforeEach
    void setUp() {
        solicitudService = new SolicitudService(
                solicitudRepository,
                documentoRepository,
                formatoDocumentoRepository,
                flujoDefinicionRepository,
                flujoEtapaRepository,
                estadoSolicitudRepository,
                accionUsuarioRepository,
                solicitudTransicionRepository,
                observacionRepository,
                storageService,
                notificacionService,
                auditService,
                currentUserResolver,
                null,
                areaRepository,
                rbacAccessService,
                rbacManagementService,
                concurrency,
                integrity,
                Clock.fixed(SLA_NOW, ZoneOffset.UTC)
        );

        emisor = new UserAccount("kc-emisor", "emisor@test.local", "Juan", "Emisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(emisor, "id", UUID.randomUUID());

        revisor = new UserAccount("kc-revisor", "revisor@test.local", "Carlos", "Revisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(revisor, "id", UUID.randomUUID());

        admin = new UserAccount("kc-admin", "admin@test.local", "Super", "Admin", true, Set.of(new RolFlujo("ADMIN")));
        ReflectionTestUtils.setField(admin, "id", UUID.randomUUID());

        flujoDef = new FlujoDefinicion("Revisión Simple", "Flujo base");
        ReflectionTestUtils.setField(flujoDef, "id", 1L);

        etapa = new FlujoEtapa(flujoDef, 1, "Revisión");
        ReflectionTestUtils.setField(etapa, "id", 1L);

        estadoPendiente = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        estadoCorreccion = new EstadoSolicitud(2L, "CORRECCION_REQUERIDA");
        estadoAprobado = new EstadoSolicitud(3L, "APROBADO");
        estadoRechazado = new EstadoSolicitud(4L, "RECHAZADO");

        accionCrear = new AccionUsuario(1L, "CREAR");
        accionAprobar = new AccionUsuario(2L, "APROBAR");
        accionRechazar = new AccionUsuario(3L, "RECHAZAR");
        accionCorreccion = new AccionUsuario(4L, "PEDIR_CORRECCION");
        accionReenviar = new AccionUsuario(5L, "REENVIAR");

        when(rbacAccessService.readable(any(UUID.class))).thenAnswer(i -> {
            UUID id = i.getArgument(0);
            return solicitudRepository.findById(id).orElse(null);
        });
        when(concurrency.lockDefinition(anyLong())).thenReturn(flujoDef);
        when(concurrency.lockRequest(any(), any())).thenAnswer(i -> {
            UUID id = i.getArgument(0);
            return solicitudRepository.findById(id).orElse(null);
        });
        when(integrity.isBase(any())).thenReturn(true);
        when(integrity.orderedStages(any())).thenReturn(List.of(etapa));
        when(rbacAccessService.context()).thenReturn(new com.capstone.sistema.rbac.model.AccessContext(
                admin.getId(), null, null, true, Set.of(), true, List.of(), List.of(),
                java.util.Map.of(), 1L, 1L
        ));
        when(rbacAccessService.visible(any())).thenReturn((root, query, cb) -> cb.conjunction());
        when(solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAscIdAsc(any())).thenAnswer(i -> {
            UUID id = i.getArgument(0);
            return solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(id);
        });
        when(estadoSolicitudRepository.findByCodigoIgnoreCase(anyString())).thenAnswer(i -> {
            String code = i.getArgument(0);
            return switch (code.toUpperCase()) {
                case "PENDIENTE_REVISION" -> Optional.of(estadoPendiente);
                case "CORRECCION_REQUERIDA" -> Optional.of(estadoCorreccion);
                case "APROBADO" -> Optional.of(estadoAprobado);
                case "RECHAZADO" -> Optional.of(estadoRechazado);
                default -> Optional.of(new EstadoSolicitud(99L, code));
            };
        });
        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(i -> {
            Solicitud s = i.getArgument(0);
            if (s.getId() == null) ReflectionTestUtils.setField(s, "id", UUID.randomUUID());
            return s;
        });
        when(solicitudRepository.saveAndFlush(any(Solicitud.class))).thenAnswer(i -> {
            Solicitud s = i.getArgument(0);
            if (s.getId() == null) ReflectionTestUtils.setField(s, "id", UUID.randomUUID());
            return s;
        });
        when(accionUsuarioRepository.findByAccionIgnoreCase(anyString())).thenAnswer(i -> {
            String act = i.getArgument(0);
            return switch (act.toUpperCase()) {
                case "CREAR" -> Optional.of(accionCrear);
                case "APROBAR" -> Optional.of(accionAprobar);
                case "RECHAZAR" -> Optional.of(accionRechazar);
                case "PEDIR_CORRECCION" -> Optional.of(accionCorreccion);
                case "REENVIAR" -> Optional.of(accionReenviar);
                default -> Optional.of(new AccionUsuario(99L, act));
            };
        });
    }

    @Test
    void testCrearSolicitud_Success() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "informe_financiero.pdf", "application/pdf", "Contenido del PDF".getBytes()
        );

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(formatoDocumentoRepository.findByTipoIgnoreCase("pdf")).thenReturn(Optional.of(new FormatoDocumento(1L, "pdf")));
        when(flujoDefinicionRepository.findById(1L)).thenReturn(Optional.of(flujoDef));
        when(flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(1L, 1)).thenReturn(Optional.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("CREAR")).thenReturn(Optional.of(accionCrear));
        when(storageService.uploadFile(file)).thenReturn("informe_financiero_key.pdf");

        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(i -> {
            Solicitud s = i.getArgument(0);
            ReflectionTestUtils.setField(s, "id", UUID.randomUUID());
            return s;
        });
        when(documentoRepository.save(any(Documento.class))).thenAnswer(i -> {
            Documento d = i.getArgument(0);
            ReflectionTestUtils.setField(d, "id", UUID.randomUUID());
            return d;
        });

        CrearSolicitudResponse response = solicitudService.crearSolicitud("Informe Financiero", "Descripción", file);

        assertThat(response).isNotNull();
        assertThat(response.solicitudId()).isNotNull();
        assertThat(response.documentoId()).isNotNull();
        assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");

        verify(notificacionService).notificarNuevaSolicitud(any(Solicitud.class), any(SolicitudTransicion.class), eq(false));
        verify(auditService).registerUserManagementEvent(eq("CREAR_SOLICITUD"), eq(emisor), contains("informe_financiero.pdf"));
    }

    @Test
    void testCrearSolicitud_InvalidFormat_ThrowsInvalidDocumentFormat() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "script.exe", "application/octet-stream", "codigo binario".getBytes()
        );

        assertThatThrownBy(() -> solicitudService.crearSolicitud("Titulo", "Desc", file))
                .isInstanceOf(InvalidDocumentFormatException.class)
                .hasMessageContaining("Formato de archivo no permitido (.exe)");
    }

    @Test
    void testCrearSolicitud_AcceptsXmlAndTxtFormats() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(flujoDefinicionRepository.findById(1L)).thenReturn(Optional.of(flujoDef));
        when(flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(1L, 1)).thenReturn(Optional.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("CREAR")).thenReturn(Optional.of(accionCrear));
        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(invocation -> {
            Solicitud solicitud = invocation.getArgument(0);
            ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());
            return solicitud;
        });
        when(documentoRepository.save(any(Documento.class))).thenAnswer(invocation -> {
            Documento documento = invocation.getArgument(0);
            ReflectionTestUtils.setField(documento, "id", UUID.randomUUID());
            return documento;
        });

        for (String extension : List.of("xml", "txt", "xlsx", "xls")) {
            String mimeType;
            if (extension.equals("xml")) mimeType = "application/xml";
            else if (extension.equals("txt")) mimeType = "text/plain";
            else if (extension.equals("xlsx")) mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            else mimeType = "application/vnd.ms-excel";

            MockMultipartFile file = new MockMultipartFile(
                    "file", "archivo." + extension,
                    mimeType,
                    "contenido válido".getBytes()
            );
            when(formatoDocumentoRepository.findByTipoIgnoreCase(extension))
                    .thenReturn(Optional.of(new FormatoDocumento(extension)));
            when(storageService.uploadFile(file)).thenReturn("documentos/archivo." + extension);

            CrearSolicitudResponse response = solicitudService.crearSolicitud("Documento " + extension, "", file);

            assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");
        }
    }

    @Test
    void testCrearSolicitud_EmptyTitle_ThrowsIllegalArgument() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "documento.pdf", "application/pdf", "Contenido".getBytes()
        );

        assertThatThrownBy(() -> solicitudService.crearSolicitud("", "Desc", file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("título del documento es obligatorio");
    }

    @Test
    void testAprobar_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento A", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("APROBADO")).thenReturn(Optional.of(estadoAprobado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("APROBAR")).thenReturn(Optional.of(accionAprobar));

        SolicitudResponse response = solicitudService.aprobar(solId);

        assertThat(response.estado()).isEqualTo("APROBADO");
        assertThat(solicitud.getEstadoSolicitud().getCodigo()).isEqualTo("APROBADO");

        verify(notificacionService).notificarAprobacion(eq(solicitud), any(SolicitudTransicion.class), eq(revisor), eq(false));
        verify(auditService).registerUserManagementEvent(eq("APROBAR_SOLICITUD"), eq(revisor), contains("APROBADO"));
    }

    @Test
    void testAprobar_EmisorCannotApprove_ThrowsUnauthorized() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento A", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        doThrow(new UnauthorizedActionException("El emisor no puede aprobar su propio documento"))
                .when(rbacAccessService).authorize(solId, Permiso.SOLICITUD_APROBAR);

        assertThatThrownBy(() -> solicitudService.aprobar(solId))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("no puede aprobar su propio documento");
    }

    @Test
    void testAprobar_AdminCanApproveOwnDocument() {
        // Solicitud emitida por admin
        Solicitud solicitud = new Solicitud(flujoDef, admin, "Documento Admin", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(admin));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("APROBADO")).thenReturn(Optional.of(estadoAprobado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("APROBAR")).thenReturn(Optional.of(accionAprobar));

        SolicitudResponse response = solicitudService.aprobar(solId);

        assertThat(response.estado()).isEqualTo("APROBADO");
        verify(notificacionService).notificarAprobacion(eq(solicitud), any(SolicitudTransicion.class), eq(admin), eq(false));
    }

    @Test
    void testAprobar_InvalidState_ThrowsInvalidTransition() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoAprobado, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));

        assertThatThrownBy(() -> solicitudService.aprobar(solId))
                .isInstanceOf(InvalidTransitionException.class)
                .hasMessageContaining("No se puede aprobar la solicitud");
    }

    @Test
    void testRechazar_FlujoSinRolesPermiteAlEmisorYNotifica() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento B", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("RECHAZADO")).thenReturn(Optional.of(estadoRechazado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("RECHAZAR")).thenReturn(Optional.of(accionRechazar));

        SolicitudResponse response = solicitudService.rechazar(solId, "No cumple con las normas contables");

        assertThat(response.estado()).isEqualTo("RECHAZADO");
        verify(notificacionService).notificarRechazo(eq(solicitud), any(SolicitudTransicion.class), eq(emisor), eq("No cumple con las normas contables"), eq(false));
        verify(auditService).registerUserManagementEvent(eq("RECHAZAR_SOLICITUD"), eq(emisor), contains("No cumple con las normas contables"));
    }

    @Test
    void testRechazar_EmptyMotivo_ThrowsIllegalArgument() {
        UUID solId = UUID.randomUUID();

        assertThatThrownBy(() -> solicitudService.rechazar(solId, "   "))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("motivo del rechazo es obligatorio");
    }

    @Test
    void testPedirCorreccion_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento C", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("CORRECCION_REQUERIDA")).thenReturn(Optional.of(estadoCorreccion));
        when(accionUsuarioRepository.findByAccionIgnoreCase("PEDIR_CORRECCION")).thenReturn(Optional.of(accionCorreccion));
        when(solicitudTransicionRepository.save(any(SolicitudTransicion.class))).thenAnswer(i -> i.getArgument(0));

        SolicitudResponse response = solicitudService.pedirCorreccion(solId, "Falta firma en página 3");

        assertThat(response.estado()).isEqualTo("CORRECCION_REQUERIDA");
        verify(observacionRepository).save(any(Observacion.class));
        verify(notificacionService).notificarCorreccionRequerida(eq(solicitud), any(SolicitudTransicion.class), eq(revisor), eq("Falta firma en página 3"), eq(false));
    }

    @Test
    void testReenviar_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento D", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("REENVIAR")).thenReturn(Optional.of(accionReenviar));
        when(observacionRepository.findBySolicitud_IdAndResueltaFalse(solId)).thenReturn(List.of());

        SolicitudResponse response = solicitudService.reenviar(solId, "Documento D Corregido", "Nueva desc", null);

        assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");
        verify(notificacionService).notificarReenvio(eq(solicitud), any(SolicitudTransicion.class), eq(false));
        verify(auditService).registerUserManagementEvent(eq("REENVIAR_SOLICITUD"), eq(emisor), contains("Documento D Corregido"));
    }

    @Test
    void testReenviar_NonEmisor_ThrowsUnauthorized() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(rbacAccessService.context()).thenReturn(new com.capstone.sistema.rbac.model.AccessContext(
                revisor.getId(), null, null, false, Set.of(), false, List.of(), List.of(),
                java.util.Map.of(), 1L, 1L
        ));

        assertThatThrownBy(() -> solicitudService.reenviar(solId, "Titulo", "Desc", null))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("Solo el emisor original puede reenviar");
    }

    @Test
    void testReenviar_EstadoInvalido_LanzaInvalidTransitionException() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc Pendiente", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));

        assertThatThrownBy(() -> solicitudService.reenviar(solId, "Titulo Subsanado", "Desc", null))
                .isInstanceOf(InvalidTransitionException.class)
                .hasMessageContaining("No se puede reenviar la solicitud")
                .hasMessageContaining("se requiere 'CORRECCION_REQUERIDA'");
    }

    @Test
    void testReenviar_TituloVacio_LanzaIllegalArgumentException() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc Observado", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);

        assertThatThrownBy(() -> solicitudService.reenviar(solId, "   ", "Desc", null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("El título del documento es obligatorio");
    }

    @Test
    void testReenviar_ConNuevoArchivo_ActualizaVersionYResuelveObservaciones() throws Exception {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc con Observaciones", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        FormatoDocumento formato = new FormatoDocumento("pdf");
        Documento docPrevio = new Documento(solicitud, formato, "anexo_v1.pdf", "application/pdf", "storage/v1", 1024L, 1, true);
        Observacion obsPendiente = new Observacion(solicitud, null, revisor, "Corregir cláusula quinta");

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(accionUsuarioRepository.findByAccionIgnoreCase("REENVIAR")).thenReturn(Optional.of(accionReenviar));
        when(observacionRepository.findBySolicitud_IdAndResueltaFalse(solId)).thenReturn(List.of(obsPendiente));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solId)).thenReturn(Optional.of(docPrevio));
        when(formatoDocumentoRepository.findByTipoIgnoreCase("pdf")).thenReturn(Optional.of(formato));
        when(storageService.uploadFile(any())).thenReturn("storage/v2");

        MockMultipartFile nuevoArchivo = new MockMultipartFile(
                "file", "anexo_v2.pdf", "application/pdf", "%PDF-1.4 Nuevo contenido".getBytes()
        );

        SolicitudResponse response = solicitudService.reenviar(solId, "Doc Subsanado Final", "Notas subsanación", nuevoArchivo);

        assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");
        assertThat(obsPendiente.isResuelta()).isTrue();
        assertThat(docPrevio.isVigente()).isFalse();
        verify(documentoRepository, times(2)).save(any(Documento.class));
        verify(solicitudTransicionRepository).save(any(SolicitudTransicion.class));
        verify(notificacionService).notificarReenvio(eq(solicitud), any(SolicitudTransicion.class), eq(false));
    }

    @Test
    void testObtenerHistorial_ReturnsTransitionsInOrder() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        SolicitudTransicion t1 = new SolicitudTransicion(solicitud, null, null, estadoPendiente, accionCrear, emisor, "Crear", "{}");
        ReflectionTestUtils.setField(t1, "id", 1L);
        SolicitudTransicion t2 = new SolicitudTransicion(solicitud, null, estadoPendiente, estadoAprobado, accionAprobar, revisor, "Aprobado", "{}");
        ReflectionTestUtils.setField(t2, "id", 2L);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solId)).thenReturn(List.of(t1, t2));

        List<TransicionResponse> historial = solicitudService.obtenerHistorial(solId);

        assertThat(historial).hasSize(2);
        assertThat(historial.get(0).accion()).isEqualTo("CREAR");
        assertThat(historial.get(1).accion()).isEqualTo("APROBAR");
    }

    @Test
    void listarRevisionesPendientes_AplicaPaginacionYDevuelveProyeccion() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Contrato marco", "Desc", estadoPendiente, etapa);
        UUID solicitudId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solicitudId);
        ReflectionTestUtils.setField(solicitud, "createdAt", Instant.parse("2026-09-20T12:00:00Z"));

        Documento documento = new Documento(
                solicitud, new FormatoDocumento("pdf"), "contrato-marco.pdf", "application/pdf",
                "documentos/contrato-marco.pdf", 1024L, 1, true
        );

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(solicitudRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(
                List.of(solicitud), PageRequest.of(0, 10), 11
        ));
        when(documentoRepository.findBySolicitud_IdInAndVigenteTrue(List.of(solicitudId)))
                .thenReturn(List.of(documento));

        PaginaSolicitudesPendientesResponse response = solicitudService.listarRevisionesPendientes(
                "contrato", "Juan", Instant.parse("2026-09-01T00:00:00Z"),
                Instant.parse("2026-09-30T23:59:59Z"), "PENDIENTE_REVISION", 0, 10
        );

        assertThat(response.totalElementos()).isEqualTo(11);
        assertThat(response.totalPaginas()).isEqualTo(2);
        assertThat(response.contenido()).singleElement().satisfies(item -> {
            assertThat(item.id()).isEqualTo(solicitudId);
            assertThat(item.nombreArchivo()).isEqualTo("contrato-marco.pdf");
            assertThat(item.emisorEmail()).isEqualTo("emisor@test.local");
        });
        verify(documentoRepository).findBySolicitud_IdInAndVigenteTrue(List.of(solicitudId));
    }

    @Test
    void testObtenerResumenDashboard_Approver() {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));

        // Solicitud pendiente de revisión emitida por otro usuario
        Solicitud solParaRevisar = new Solicitud(flujoDef, emisor, "Doc de Emisor", "Desc", estadoPendiente, etapa);
        UUID solRevisarId = UUID.randomUUID();
        ReflectionTestUtils.setField(solParaRevisar, "id", solRevisarId);

        when(solicitudRepository.findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc("PENDIENTE_REVISION"))
                .thenReturn(List.of(solParaRevisar));

        // Solicitud propia del revisor que requiere corrección
        Solicitud solPropiaCorreccion = new Solicitud(flujoDef, revisor, "Mi Doc Observado", "Desc", estadoCorreccion, etapa);
        UUID solCorreccionId = UUID.randomUUID();
        ReflectionTestUtils.setField(solPropiaCorreccion, "id", solCorreccionId);

        when(rbacAccessService.can(solCorreccionId, Permiso.SOLICITUD_REENVIAR)).thenReturn(true);
        when(solicitudRepository.findAll(any(Specification.class), any(org.springframework.data.domain.Sort.class)))
                .thenReturn(List.of(solParaRevisar))
                .thenReturn(List.of(solPropiaCorreccion));

        Observacion obs = new Observacion(solPropiaCorreccion, null, admin, "Falta la firma digital");
        when(observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solCorreccionId)).thenReturn(List.of(obs));

        DashboardResponse dashboard = solicitudService.obtenerResumenDashboard();

        assertThat(dashboard).isNotNull();
        assertThat(dashboard.accionesPendientes()).hasSize(2);
        assertThat(dashboard.misSolicitudesPendientes()).hasSize(1);

        boolean tieneRevision = dashboard.accionesPendientes().stream()
                .anyMatch(a -> "REVISION".equals(a.tipoAccion()) && a.solicitudId().equals(solRevisarId));
        boolean tieneCorreccion = dashboard.accionesPendientes().stream()
                .anyMatch(a -> "CORRECCION".equals(a.tipoAccion()) && a.solicitudId().equals(solCorreccionId)
                        && "Falta la firma digital".equals(a.ultimaObservacion()));

        assertThat(tieneRevision).isTrue();
        assertThat(tieneCorreccion).isTrue();
    }

    @Test
    void validarAccesoSolicitud_differentArea_throwsUnauthorizedActionException() {
        Area finanzas = new Area(1L, "Finanzas", true);
        Area rrhh = new Area(2L, "RRHH", true);

        UserAccount emisorFinanzas = new UserAccount("kc-fin", "emisor@finanzas.local", "Juan", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(emisorFinanzas, "id", UUID.randomUUID());
        emisorFinanzas.setArea(finanzas);

        UserAccount usuarioRrhh = new UserAccount("kc-rrhh", "usuario@rrhh.local", "Ana", "RRHH", true, Set.of());
        ReflectionTestUtils.setField(usuarioRrhh, "id", UUID.randomUUID());
        usuarioRrhh.setArea(rrhh);

        Solicitud solicitud = new Solicitud(flujoDef, emisorFinanzas, "Doc Finanzas", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        doThrow(new UnauthorizedActionException("No tiene permisos para acceder a esta solicitud o documento de otra área corporativa"))
                .when(rbacAccessService).authorize(solId, Permiso.SOLICITUD_CONSULTAR);

        assertThatThrownBy(() -> solicitudService.validarAccesoSolicitud(solicitud, usuarioRrhh))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("No tiene permisos para acceder a esta solicitud o documento de otra área corporativa");
    }

    @Test
    void validarAccesoSolicitud_sameArea_accessAllowed() {
        Area finanzas = new Area(1L, "Finanzas", true);

        UserAccount emisorFinanzas = new UserAccount("kc-fin", "emisor@finanzas.local", "Juan", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(emisorFinanzas, "id", UUID.randomUUID());
        emisorFinanzas.setArea(finanzas);

        UserAccount companeroFinanzas = new UserAccount("kc-fin2", "companero@finanzas.local", "Pedro", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(companeroFinanzas, "id", UUID.randomUUID());
        companeroFinanzas.setArea(finanzas);

        Solicitud solicitud = new Solicitud(flujoDef, emisorFinanzas, "Doc Finanzas", "Desc", estadoPendiente, etapa);

        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);

        // Does not throw exception
        solicitudService.validarAccesoSolicitud(solicitud, companeroFinanzas);
    }

    @Test
    void validarAccesoSolicitud_crossAreaReviewer_accessAllowed() {
        Area finanzas = new Area(1L, "Finanzas", true);
        Area auditoria = new Area(3L, "Auditoría", true);

        UserAccount emisorFinanzas = new UserAccount("kc-fin", "emisor@finanzas.local", "Juan", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(emisorFinanzas, "id", UUID.randomUUID());
        emisorFinanzas.setArea(finanzas);

        UserAccount revisorAuditoria = new UserAccount("kc-audit", "auditor@auditoria.local", "Lucia", "Auditora", true, Set.of());
        ReflectionTestUtils.setField(revisorAuditoria, "id", UUID.randomUUID());
        revisorAuditoria.setArea(auditoria);

        FlujoEtapa etapaConRevisor = new FlujoEtapa(flujoDef, 1, "Revisión Auditoría");
        etapaConRevisor.setRevisor(revisorAuditoria);

        Solicitud solicitud = new Solicitud(flujoDef, emisorFinanzas, "Doc Finanzas", "Desc", estadoPendiente, etapaConRevisor);

        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);

        // Cross-area reviewer has access
        solicitudService.validarAccesoSolicitud(solicitud, revisorAuditoria);
    }

    @Test
    void validarAccesoSolicitud_adminMaestro_accessAllowed() {
        Area finanzas = new Area(1L, "Finanzas", true);

        UserAccount emisorFinanzas = new UserAccount("kc-fin", "emisor@finanzas.local", "Juan", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(emisorFinanzas, "id", UUID.randomUUID());
        emisorFinanzas.setArea(finanzas);

        Solicitud solicitud = new Solicitud(flujoDef, emisorFinanzas, "Doc Finanzas", "Desc", estadoPendiente, etapa);

        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);

        // Admin Maestro has transversal access
        solicitudService.validarAccesoSolicitud(solicitud, admin);
    }

    @Test
    void descargarDocumento_differentArea_throwsUnauthorizedActionException() {
        Area finanzas = new Area(1L, "Finanzas", true);
        Area rrhh = new Area(2L, "RRHH", true);

        UserAccount emisorFinanzas = new UserAccount("kc-fin", "emisor@finanzas.local", "Juan", "Finanzas", true, Set.of());
        ReflectionTestUtils.setField(emisorFinanzas, "id", UUID.randomUUID());
        emisorFinanzas.setArea(finanzas);

        UserAccount usuarioRrhh = new UserAccount("kc-rrhh", "usuario@rrhh.local", "Ana", "RRHH", true, Set.of());
        ReflectionTestUtils.setField(usuarioRrhh, "id", UUID.randomUUID());
        usuarioRrhh.setArea(rrhh);

        Solicitud solicitud = new Solicitud(flujoDef, emisorFinanzas, "Doc Finanzas", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuarioRrhh));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        doThrow(new UnauthorizedActionException("No tiene permisos para acceder a las solicitudes de esta área"))
                .when(rbacAccessService).authorize(solId, Permiso.DOCUMENTO_DESCARGAR);

        assertThatThrownBy(() -> solicitudService.descargarDocumento(solId))
                .isInstanceOf(UnauthorizedActionException.class);
    }

    @Test
    void descargarDocumento_success_registersAuditEvent() throws Exception {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc Emisor", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        Documento doc = new Documento(
                solicitud, new FormatoDocumento("pdf"), "informe.pdf", "application/pdf",
                "docs/informe.pdf", 2048L, 1, true
        );

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solId)).thenReturn(Optional.of(doc));
        when(storageService.downloadFile("docs/informe.pdf")).thenReturn(new java.io.ByteArrayInputStream("bytes".getBytes()));

        java.io.InputStream result = solicitudService.descargarDocumento(solId);

        assertThat(result).isNotNull();
        verify(auditService).registerUserManagementEvent(eq("DESCARGAR_DOCUMENTO"), eq(emisor), contains("informe.pdf"));
    }

    @Test
    void descargarDocumento_storageThrowsException_throwsDocumentoNoDisponibleException() throws Exception {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc Emisor", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        Documento doc = new Documento(
                solicitud, new FormatoDocumento("pdf"), "informe.pdf", "application/pdf",
                "docs/informe.pdf", 2048L, 1, true
        );

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solId)).thenReturn(Optional.of(doc));
        when(storageService.downloadFile("docs/informe.pdf")).thenThrow(new java.io.FileNotFoundException("File missing"));

        assertThatThrownBy(() -> solicitudService.descargarDocumento(solId))
                .isInstanceOf(DocumentoNoDisponibleException.class)
                .hasMessage("El archivo no está disponible.");
    }

    @Test
    void descargarDocumento_storageKeyBlank_throwsDocumentoNoDisponibleException() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc Emisor", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        Documento doc = new Documento(
                solicitud, new FormatoDocumento("pdf"), "informe.pdf", "application/pdf",
                "   ", 2048L, 1, true
        );

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solId)).thenReturn(Optional.of(doc));

        assertThatThrownBy(() -> solicitudService.descargarDocumento(solId))
                .isInstanceOf(DocumentoNoDisponibleException.class)
                .hasMessage("El archivo no está disponible.");
    }

    @Test
    void consultarSolicitudes_asAreaAdmin_filtersByArea() {
        Area operaciones = new Area(5L, "Operaciones", true);

        UserAccount adminOperaciones = new UserAccount("kc-op", "admin@operaciones.local", "Mario", "Jefe", true, Set.of());
        ReflectionTestUtils.setField(adminOperaciones, "id", UUID.randomUUID());
        adminOperaciones.setArea(operaciones);

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(adminOperaciones));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(areaRepository.findAllByAdministrador_Id(adminOperaciones.getId())).thenReturn(List.of(operaciones));

        Solicitud solicitud = new Solicitud(flujoDef, adminOperaciones, "Procedimiento OP", "Desc", estadoPendiente, etapa);
        ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());

        when(solicitudRepository.findAll(any(Specification.class), any(Pageable.class)))
                .thenReturn(new PageImpl<>(List.of(solicitud)));

        PaginaSolicitudesPendientesResponse response = solicitudService.consultarSolicitudes(
                "Procedimiento", null, null, null, null, null, null, 0, 20
        );

        assertThat(response.totalElementos()).isEqualTo(1);
        assertThat(response.contenido()).hasSize(1);
    }

    @Test
    void obtenerMetricas_calculatesTotalsAndSla() {
        Area finanzas = new Area(1L, "Finanzas", true);
        ReflectionTestUtils.setField(finanzas, "id", 1L);

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(admin));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(areaRepository.findById(1L)).thenReturn(Optional.of(finanzas));

        when(solicitudRepository.count(any(Specification.class))).thenReturn(100L, 20L, 60L, 15L, 5L);
        when(solicitudTransicionRepository.count(any(Specification.class))).thenReturn(70L, 10L);

        MetricasResponse metricas = solicitudService.obtenerMetricas(1L);

        assertThat(metricas.totalGeneral()).isEqualTo(100L);
        assertThat(metricas.totalPendientes()).isEqualTo(20L);
        assertThat(metricas.totalAprobadas()).isEqualTo(60L);
        assertThat(metricas.totalRechazadas()).isEqualTo(15L);
        assertThat(metricas.totalCorreccion()).isEqualTo(5L);
        assertThat(metricas.totalDentroSla()).isEqualTo(70L);
        assertThat(metricas.totalFueraSla()).isEqualTo(10L);
        assertThat(metricas.areaId()).isEqualTo(1L);
        assertThat(metricas.areaNombre()).isEqualTo("Finanzas");
    }

    @Test
    void obtenerMetricasPorArea_asAdmin_returnsMetricsForAllActiveAreasSortedByName() {
        Area finanzas = new Area(1L, "Finanzas", true);
        Area operaciones = new Area(2L, "Operaciones", true);
        Area rrhh = new Area(3L, "RRHH", false); // inactiva

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(admin));
        when(rbacAccessService.context()).thenReturn(new com.capstone.sistema.rbac.model.AccessContext(
                admin.getId(), null, null, true, Set.of(), true, List.of(), List.of(),
                java.util.Map.of(), 1L, 1L
        ));
        when(areaRepository.findAll()).thenReturn(List.of(operaciones, finanzas, rrhh));
        when(areaRepository.findById(1L)).thenReturn(Optional.of(finanzas));
        when(areaRepository.findById(2L)).thenReturn(Optional.of(operaciones));

        when(solicitudRepository.count(any(Specification.class))).thenReturn(50L, 10L, 30L, 8L, 2L, 40L, 5L, 25L, 7L, 3L);
        when(solicitudTransicionRepository.count(any(Specification.class))).thenReturn(35L, 5L, 28L, 4L);

        List<MetricasResponse> metricas = solicitudService.obtenerMetricasPorArea();

        assertThat(metricas).hasSize(2);
        assertThat(metricas.get(0).areaId()).isEqualTo(1L);
        assertThat(metricas.get(0).areaNombre()).isEqualTo("Finanzas");
        assertThat(metricas.get(1).areaId()).isEqualTo(2L);
        assertThat(metricas.get(1).areaNombre()).isEqualTo("Operaciones");
    }

    @Test
    void obtenerMetricasPorArea_asNonAdminWithManagedAreas_returnsMetricsForManagedAreas() {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(rbacAccessService.context()).thenReturn(new com.capstone.sistema.rbac.model.AccessContext(
                revisor.getId(), null, null, false, Set.of(), true, List.of(),
                List.of(new RbacDtos.AreaItem(5L, "Logística")),
                java.util.Map.of(), 1L, 1L
        ));
        Area logistica = new Area(5L, "Logística", true);
        when(areaRepository.findById(5L)).thenReturn(Optional.of(logistica));

        when(solicitudRepository.count(any(Specification.class))).thenReturn(20L, 4L, 12L, 3L, 1L);
        when(solicitudTransicionRepository.count(any(Specification.class))).thenReturn(15L, 2L);

        List<MetricasResponse> metricas = solicitudService.obtenerMetricasPorArea();

        assertThat(metricas).hasSize(1);
        assertThat(metricas.get(0).areaId()).isEqualTo(5L);
        assertThat(metricas.get(0).areaNombre()).isEqualTo("Logística");
    }

    @Test
    void obtenerMetricasPorArea_asNonAdminWithAssignedArea_returnsMetricsForAssignedArea() {
        Area ventas = new Area(10L, "Ventas", true);
        revisor.setArea(ventas);

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(rbacAccessService.context()).thenReturn(new com.capstone.sistema.rbac.model.AccessContext(
                revisor.getId(), 10L, null, false, Set.of(), true, List.of(),
                List.of(),
                java.util.Map.of(), 1L, 1L
        ));
        when(areaRepository.findById(10L)).thenReturn(Optional.of(ventas));

        when(solicitudRepository.count(any(Specification.class))).thenReturn(15L, 2L, 10L, 2L, 1L);
        when(solicitudTransicionRepository.count(any(Specification.class))).thenReturn(10L, 1L);

        List<MetricasResponse> metricas = solicitudService.obtenerMetricasPorArea();

        assertThat(metricas).hasSize(1);
        assertThat(metricas.get(0).areaId()).isEqualTo(10L);
        assertThat(metricas.get(0).areaNombre()).isEqualTo("Ventas");
    }

    @ParameterizedTest
    @CsvSource({"APROBAR,-1,true", "APROBAR,0,true", "APROBAR,1,false",
            "RECHAZAR,-1,true", "RECHAZAR,0,true", "RECHAZAR,1,false",
            "PEDIR_CORRECCION,-1,true", "PEDIR_CORRECCION,0,true", "PEDIR_CORRECCION,1,false"})
    void sla_decisionesCompartenFechaYCumplimiento(String action, int decisionOffset, boolean expected) {
        Solicitud request = slaPending(SLA_NOW.minusNanos(decisionOffset));
        switch (action) {
            case "APROBAR" -> solicitudService.aprobar(request.getId());
            case "RECHAZAR" -> solicitudService.rechazar(request.getId(), "Antecedentes incompletos");
            case "PEDIR_CORRECCION" -> solicitudService.pedirCorreccion(request.getId(), "Adjuntar antecedentes");
            default -> throw new AssertionError(action);
        }
        ArgumentCaptor<SolicitudTransicion> captor = ArgumentCaptor.forClass(SolicitudTransicion.class);
        verify(solicitudTransicionRepository).save(captor.capture());
        assertThat(captor.getValue().getCreatedAt()).isEqualTo(SLA_NOW);
        assertThat(captor.getValue().getDentroSla()).isEqualTo(expected);
        assertThat(request.getDeadline()).isEqualTo(SLA_NOW.minusNanos(decisionOffset));
    }

    @Test
    void sla_historicoSinPlazo_permaneceSinCumplimiento() {
        Solicitud request = slaPending(null);
        solicitudService.rechazar(request.getId(), "Antecedentes incompletos");
        ArgumentCaptor<SolicitudTransicion> captor = ArgumentCaptor.forClass(SolicitudTransicion.class);
        verify(solicitudTransicionRepository).save(captor.capture());
        assertThat(captor.getValue().getDentroSla()).isNull();
        assertThat(captor.getValue().getCreatedAt()).isEqualTo(SLA_NOW);
    }

    @Test
    void sla_etapaIntermedia_conservaPlazoYEstadoPendiente() {
        Instant deadline = SLA_NOW.minusSeconds(10);
        Solicitud request = slaPending(deadline);
        FlujoEtapa next = new FlujoEtapa(flujoDef, 2, "Validación final");
        ReflectionTestUtils.setField(next, "id", 2L);
        when(integrity.orderedStages(flujoDef)).thenReturn(List.of(etapa, next));
        solicitudService.aprobar(request.getId());
        assertThat(request.getFlujoEtapa()).isSameAs(next);
        assertThat(request.getEstadoSolicitud().getCodigo()).isEqualTo("PENDIENTE_REVISION");
        assertThat(request.getDeadline()).isEqualTo(deadline);
        ArgumentCaptor<SolicitudTransicion> captor = ArgumentCaptor.forClass(SolicitudTransicion.class);
        verify(solicitudTransicionRepository).save(captor.capture());
        assertThat(captor.getValue().getDentroSla()).isFalse();
    }

    @Test
    void sla_correccionYReenvio_noReinicianPlazo() {
        Instant deadline = SLA_NOW.minusSeconds(1);
        Solicitud request = slaPending(deadline);
        solicitudService.pedirCorreccion(request.getId(), "Adjuntar comprobante");
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        solicitudService.reenviar(request.getId(), "Documento corregido", "Antecedentes completos", null);
        assertThat(request.getDeadline()).isEqualTo(deadline);
        assertThat(request.getEstadoSolicitud().getCodigo()).isEqualTo("PENDIENTE_REVISION");
        ArgumentCaptor<SolicitudTransicion> captor = ArgumentCaptor.forClass(SolicitudTransicion.class);
        verify(solicitudTransicionRepository, times(2)).save(captor.capture());
        assertThat(captor.getAllValues().get(0).getDentroSla()).isFalse();
        assertThat(captor.getAllValues().get(1).getDentroSla()).isNull();
        assertThat(solicitudService.calculateSlaStatus(request.getDeadline())).isEqualTo("VENCIDO");
    }

    private Solicitud slaPending(Instant deadline) {
        Solicitud request = new Solicitud(flujoDef, emisor, "Documento SLA", "Antecedentes", estadoPendiente, etapa);
        ReflectionTestUtils.setField(request, "id", UUID.randomUUID());
        request.setDeadline(deadline);
        when(solicitudRepository.findById(request.getId())).thenReturn(Optional.of(request));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        return request;
    }
}
