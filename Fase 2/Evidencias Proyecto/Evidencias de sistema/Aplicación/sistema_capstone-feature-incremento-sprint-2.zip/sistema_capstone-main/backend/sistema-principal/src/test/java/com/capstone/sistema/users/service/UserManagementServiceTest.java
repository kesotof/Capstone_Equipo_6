package com.capstone.sistema.users.service;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.exception.UserAlreadyExistsException;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.RolFlujoRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RoleMappingResource;
import org.keycloak.admin.client.resource.RoleResource;
import org.keycloak.admin.client.resource.RoleScopeResource;
import org.keycloak.admin.client.resource.RolesResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserManagementServiceTest {

    @Mock
    private UserAccountRepository repository;
    @Mock
    private RolFlujoRepository rolFlujoRepository;
    @Mock
    private AreaRepository areaRepository;
    @Mock
    private KeycloakLockStatusClient keycloakLockStatusClient;
    @Mock
    private Keycloak keycloak;
    @Mock
    private RealmResource realm;
    @Mock
    private UsersResource users;
    @Mock
    private UserResource userResource;
    @Mock
    private RolesResource rolesResource;
    @Mock
    private RoleResource roleResource;
    @Mock
    private RoleMappingResource roleMappingResource;
    @Mock
    private RoleScopeResource roleScopeResource;
    @Mock
    private com.capstone.sistema.audit.service.AuditService auditService;
    @Mock
    private com.capstone.sistema.rbac.service.RbacManagementService rbac;
    @Mock
    private com.capstone.sistema.auth.CurrentUserResolver currentUserResolver;
    @Mock
    private jakarta.persistence.EntityManager entityManager;
    private UserManagementService service;

    @BeforeEach
    void setUp() {
        KeycloakAdminProperties properties = new KeycloakAdminProperties(
                "http://keycloak:8080",
                "master",
                "capstone-realm",
                "admin-cli",
                "admin",
                "secret",
                "capstone-client"
        );
        service = new UserManagementService(
                repository,
                rolFlujoRepository,
                areaRepository,
                keycloakLockStatusClient,
                keycloak,
                properties,
                auditService,
                rbac,
                currentUserResolver,
                entityManager
        );

        RolFlujo rolEmisor = new RolFlujo(1L, "EMISOR");
        RolFlujo rolRevisor = new RolFlujo(2L, "REVISOR");
        org.mockito.Mockito.lenient().when(rolFlujoRepository.findByNombreIgnoreCase("EMISOR")).thenReturn(Optional.of(rolEmisor));
        org.mockito.Mockito.lenient().when(rolFlujoRepository.findByNombreIgnoreCase("REVISOR")).thenReturn(Optional.of(rolRevisor));
        org.mockito.Mockito.lenient().when(rbac.response(any(), org.mockito.ArgumentMatchers.anyBoolean())).thenAnswer(invocation -> {
            UserAccount acc = invocation.getArgument(0);
            return new UserResponse(
                    acc.getId(),
                    acc.getKeycloakUserId(),
                    acc.getEmail(),
                    acc.getRut(),
                    acc.getFirstName(),
                    acc.getLastName(),
                    null,
                    null,
                    acc.isEnabled(),
                    false,
                    acc.getRoles(),
                    java.time.Instant.now()
            );
        });
    }

    @Test
    void rejectsEmailAlreadyPersistedBeforeCallingKeycloak() {
        CreateUserRequest request = request(" EXISTE@CAPSTONE.LOCAL ");
        when(repository.existsByEmailIgnoreCase("existe@capstone.local")).thenReturn(true);

        assertThatThrownBy(() -> service.createUser(request))
                .isInstanceOf(UserAlreadyExistsException.class)
                .hasMessageContaining("existe@capstone.local");

        verify(keycloak, never()).realm(any());
    }

    @Test
    void rejectsInvalidRutDvBeforeCallingKeycloak() {
        // RUT con DV alterado de la lista oficial del usuario
        CreateUserRequest request = new CreateUserRequest(
                "nuevo@capstone.local",
                "22459056-4", // inválido (correcto es 3)
                "Nombre",
                "Prueba",
                "Password123",
                Set.of(SystemRole.APPROVER),
                null,
                false
        );

        assertThatThrownBy(() -> service.createUser(request))
                .isInstanceOf(com.capstone.sistema.users.exception.RutInvalidoException.class)
                .hasMessageContaining("El RUT ingresado no es válido");

        verify(keycloak, never()).realm(any());
    }

    @Test
    void rejectsDuplicateRutBeforeCallingKeycloak() {
        CreateUserRequest request = request("nuevo@capstone.local");
        when(repository.existsByRut("22459056-3")).thenReturn(true);

        assertThatThrownBy(() -> service.createUser(request))
                .isInstanceOf(com.capstone.sistema.users.exception.RutDuplicadoException.class)
                .hasMessageContaining("22459056-3");

        verify(keycloak, never()).realm(any());
    }

    @Test
    void createsAccountInKeycloakAndPostgresql() {
        CreateUserRequest request = request("nuevo@capstone.local");
        when(repository.existsByEmailIgnoreCase("nuevo@capstone.local")).thenReturn(false);
        when(keycloak.realm("capstone-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.searchByEmail("nuevo@capstone.local", true)).thenReturn(List.of());
        when(users.create(any())).thenReturn(Response.created(
                URI.create("http://keycloak:8080/admin/realms/capstone-realm/users/kc-123")
        ).build());
        when(users.get("kc-123")).thenReturn(userResource);
        when(repository.saveAndFlush(any(UserAccount.class))).thenAnswer(invocation -> invocation.getArgument(0));

        UserResponse created = service.createUser(request);

        assertThat(created.email()).isEqualTo("nuevo@capstone.local");
        assertThat(created.roles()).containsExactly(SystemRole.APPROVER);

        ArgumentCaptor<CredentialRepresentation> credential = ArgumentCaptor.forClass(CredentialRepresentation.class);
        verify(userResource).resetPassword(credential.capture());
        assertThat(credential.getValue().getValue()).isEqualTo("Password123");
        assertThat(credential.getValue().isTemporary()).isFalse();
        verify(repository).saveAndFlush(any(UserAccount.class));
        verify(auditService).registerUserManagementEvent(eq("CREAR_USUARIO"), any(), any());
    }

    @org.junit.jupiter.api.Test
    void updatesUserSuccessfully() {
        java.util.UUID id = java.util.UUID.randomUUID();
        UserAccount account = new UserAccount("kc-123", "user@capstone.local", "Juan", "Perez", true, Set.of());
        when(repository.findById(id)).thenReturn(Optional.of(account));
        when(keycloak.realm("capstone-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.get("kc-123")).thenReturn(userResource);
        UserRepresentation rep = new UserRepresentation();
        when(userResource.toRepresentation()).thenReturn(rep);
        when(repository.saveAndFlush(any(UserAccount.class))).thenAnswer(invocation -> invocation.getArgument(0));

        com.capstone.sistema.users.dto.UpdateUserRequest updateReq = new com.capstone.sistema.users.dto.UpdateUserRequest("Juan Carlos", "Perez Gomez");
        UserResponse response = service.updateUser(id, updateReq);

        assertThat(response.firstName()).isEqualTo("Juan Carlos");
        assertThat(response.lastName()).isEqualTo("Perez Gomez");
        verify(userResource).update(rep);
        verify(auditService).registerUserManagementEvent(eq("ACTUALIZAR_USUARIO"), any(), any());
    }

    @org.junit.jupiter.api.Test
    void updatesUserPasswordSuccessfully() {
        java.util.UUID id = java.util.UUID.randomUUID();
        UserAccount account = new UserAccount("kc-123", "user@capstone.local", "Juan", "Perez", true, Set.of());
        when(repository.findById(id)).thenReturn(Optional.of(account));
        when(keycloak.realm("capstone-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.get("kc-123")).thenReturn(userResource);
        UserRepresentation rep = new UserRepresentation();
        when(userResource.toRepresentation()).thenReturn(rep);
        when(repository.saveAndFlush(any(UserAccount.class))).thenAnswer(invocation -> invocation.getArgument(0));

        com.capstone.sistema.users.dto.UpdateUserRequest updateReq = new com.capstone.sistema.users.dto.UpdateUserRequest(
                "Juan",
                "Perez",
                "NuevaClave123",
                true
        );
        UserResponse response = service.updateUser(id, updateReq);

        assertThat(response).isNotNull();
        ArgumentCaptor<CredentialRepresentation> captor = ArgumentCaptor.forClass(CredentialRepresentation.class);
        verify(userResource).resetPassword(captor.capture());
        assertThat(captor.getValue().getValue()).isEqualTo("NuevaClave123");
        assertThat(captor.getValue().isTemporary()).isTrue();
    }

    @org.junit.jupiter.api.Test
    void togglesUserStatusSuccessfully() {
        java.util.UUID id = java.util.UUID.randomUUID();
        UserAccount account = new UserAccount("kc-123", "user@capstone.local", "Juan", "Perez", true, Set.of());
        when(repository.findById(id)).thenReturn(Optional.of(account));
        when(keycloak.realm("capstone-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.get("kc-123")).thenReturn(userResource);
        UserRepresentation rep = new UserRepresentation();
        rep.setEnabled(true);
        when(userResource.toRepresentation()).thenReturn(rep);
        when(repository.saveAndFlush(any(UserAccount.class))).thenAnswer(invocation -> invocation.getArgument(0));

        UserResponse response = service.toggleUserStatus(id, false);

        assertThat(response.enabled()).isFalse();
        assertThat(rep.isEnabled()).isFalse();
        verify(userResource).update(rep);
        verify(auditService).registerUserManagementEvent(eq("DESACTIVAR_USUARIO"), any(), any());
    }

    @org.junit.jupiter.api.Test
    void deletesUserSuccessfully() {
        java.util.UUID id = java.util.UUID.randomUUID();
        UserAccount account = new UserAccount("kc-123", "user@capstone.local", "Juan", "Perez", true, Set.of());
        when(repository.findById(id)).thenReturn(Optional.of(account));
        when(keycloak.realm("capstone-realm")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(users.delete("kc-123")).thenReturn(Response.noContent().build());

        service.deleteUser(id);

        verify(auditService).registerUserManagementEvent(eq("ELIMINAR_USUARIO"), any(), any());
        verify(repository).delete(account);
        verify(users).delete("kc-123");
    }

    private CreateUserRequest request(String email) {
        return new CreateUserRequest(
                email,
                "22459056-3",
                "Nombre",
                "Prueba",
                "Password123",
                Set.of(SystemRole.APPROVER),
                null,
                false
        );
    }
}
