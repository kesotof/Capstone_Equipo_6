-- Migración aditiva anterior a Hibernate y repetible tras crear un catálogo nuevo.
-- Los eventos históricos conservan etapas NULL; no se reconstruyen decisiones pasadas.
DO $flow_schema$
DECLARE
    duplicated TEXT;
BEGIN
    PERFORM pg_advisory_xact_lock(41021, 3);
    CREATE TABLE IF NOT EXISTS flow_control (id INTEGER PRIMARY KEY CHECK (id=1), version_migracion INTEGER NOT NULL DEFAULT 0);
    INSERT INTO flow_control(id) VALUES (1) ON CONFLICT DO NOTHING;
    IF to_regclass('flujo_definicion') IS NOT NULL THEN
        ALTER TABLE flujo_definicion ADD COLUMN IF NOT EXISTS completo BOOLEAN NOT NULL DEFAULT FALSE;
        UPDATE flujo_definicion SET completo=FALSE WHERE completo IS NULL;
        ALTER TABLE flujo_definicion ALTER COLUMN completo SET DEFAULT FALSE;
        ALTER TABLE flujo_definicion ALTER COLUMN completo SET NOT NULL;
        ALTER TABLE flujo_definicion ADD COLUMN IF NOT EXISTS version BIGINT NOT NULL DEFAULT 0;
        UPDATE flujo_definicion SET version=0 WHERE version IS NULL;
        ALTER TABLE flujo_definicion ALTER COLUMN version SET DEFAULT 0;
        ALTER TABLE flujo_definicion ALTER COLUMN version SET NOT NULL;
        SELECT string_agg(ids, '; ') INTO duplicated FROM (
            SELECT string_agg(id::text, ',' ORDER BY id) AS ids
            FROM flujo_definicion GROUP BY lower(btrim(nombre)) HAVING count(*)>1
        ) conflicts;
        IF duplicated IS NOT NULL THEN
            RAISE EXCEPTION 'Nombres de flujos duplicados tras normalizar. Corregir IDs [%] antes de continuar; no se modificaron nombres.', duplicated;
        END IF;
        CREATE UNIQUE INDEX IF NOT EXISTS uq_flujo_nombre_normalizado ON flujo_definicion(lower(btrim(nombre)));
    END IF;
    IF to_regclass('flujo_etapa') IS NOT NULL THEN
        ALTER TABLE flujo_etapa ADD COLUMN IF NOT EXISTS tipo_accion VARCHAR(30) NOT NULL DEFAULT 'REVISION';
        UPDATE flujo_etapa SET tipo_accion='REVISION' WHERE tipo_accion IS NULL;
        ALTER TABLE flujo_etapa ALTER COLUMN tipo_accion SET DEFAULT 'REVISION';
        ALTER TABLE flujo_etapa ALTER COLUMN tipo_accion SET NOT NULL;
        ALTER TABLE flujo_etapa ADD COLUMN IF NOT EXISTS tipo_asignacion VARCHAR(30) NOT NULL DEFAULT 'USUARIO';
        ALTER TABLE flujo_etapa ADD COLUMN IF NOT EXISTS rol_revisor_id BIGINT;
        ALTER TABLE flujo_etapa ADD COLUMN IF NOT EXISTS revisor_id UUID;
        IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='flujo_etapa'::regclass AND conname='ck_etapa_responsable') THEN
            ALTER TABLE flujo_etapa ADD CONSTRAINT ck_etapa_responsable CHECK (
                (tipo_asignacion='USUARIO' AND rol_revisor_id IS NULL) OR
                (tipo_asignacion='ROL_DEPARTAMENTAL' AND revisor_id IS NULL AND rol_revisor_id IS NOT NULL)
            );
        END IF;
        IF to_regclass('rol_flujo') IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM pg_constraint WHERE conrelid='flujo_etapa'::regclass AND conname='fk_etapa_rol_revisor') THEN
            ALTER TABLE flujo_etapa ADD CONSTRAINT fk_etapa_rol_revisor FOREIGN KEY (rol_revisor_id) REFERENCES rol_flujo(id) ON DELETE RESTRICT;
        END IF;
        CREATE INDEX IF NOT EXISTS idx_etapa_rol_revisor ON flujo_etapa(rol_revisor_id);
    END IF;
    IF to_regclass('solicitud') IS NOT NULL THEN
        ALTER TABLE solicitud ADD COLUMN IF NOT EXISTS version BIGINT NOT NULL DEFAULT 0;
        UPDATE solicitud SET version=0 WHERE version IS NULL;
        ALTER TABLE solicitud ALTER COLUMN version SET DEFAULT 0;
        ALTER TABLE solicitud ALTER COLUMN version SET NOT NULL;
        ALTER TABLE solicitud ADD COLUMN IF NOT EXISTS tipo_documento VARCHAR(100);
        CREATE INDEX IF NOT EXISTS idx_solicitud_tipo_documento ON solicitud (tipo_documento);
    END IF;
    IF to_regclass('solicitud_transicion') IS NOT NULL THEN
        ALTER TABLE solicitud_transicion ADD COLUMN IF NOT EXISTS etapa_origen_id BIGINT;
        ALTER TABLE solicitud_transicion ADD COLUMN IF NOT EXISTS etapa_destino_id BIGINT;
        IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='solicitud_transicion'::regclass AND conname='fk_evento_etapa_origen') THEN
            ALTER TABLE solicitud_transicion ADD CONSTRAINT fk_evento_etapa_origen FOREIGN KEY (etapa_origen_id) REFERENCES flujo_etapa(id) ON DELETE RESTRICT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='solicitud_transicion'::regclass AND conname='fk_evento_etapa_destino') THEN
            ALTER TABLE solicitud_transicion ADD CONSTRAINT fk_evento_etapa_destino FOREIGN KEY (etapa_destino_id) REFERENCES flujo_etapa(id) ON DELETE RESTRICT;
        END IF;
        CREATE INDEX IF NOT EXISTS idx_evento_etapa_origen ON solicitud_transicion(etapa_origen_id);
        CREATE INDEX IF NOT EXISTS idx_evento_etapa_destino ON solicitud_transicion(etapa_destino_id);
    END IF;
END
$flow_schema$;
