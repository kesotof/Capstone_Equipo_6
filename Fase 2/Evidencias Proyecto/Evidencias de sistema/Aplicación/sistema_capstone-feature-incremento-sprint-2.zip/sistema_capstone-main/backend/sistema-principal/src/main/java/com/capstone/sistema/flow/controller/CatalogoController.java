package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.AreaSimpleResponse;
import com.capstone.sistema.flow.dto.TipoDocumentoResponse;
import com.capstone.sistema.flow.service.SlaService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Comparator;
import java.util.List;

@Tag(name = "Catálogos", description = "Consultas de catálogos generales del sistema")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/catalogos")
@PreAuthorize("isAuthenticated()")
public class CatalogoController {

    private final SlaService slaService;
    private final AreaRepository areaRepository;

    public CatalogoController(SlaService slaService, AreaRepository areaRepository) {
        this.slaService = slaService;
        this.areaRepository = areaRepository;
    }

    @Operation(summary = "Listar tipos de documento disponibles con sus plazos SLA", description = "Retorna el catálogo de tipos de documento y sus plazos en días hábiles.")
    @GetMapping("/tipos-documento")
    public ResponseEntity<List<TipoDocumentoResponse>> listarTiposDocumento() {
        return ResponseEntity.ok(slaService.listTiposDocumento());
    }

    @Operation(summary = "Listar áreas activas", description = "Retorna el catálogo simplificado de áreas activas ordenadas alfabéticamente.")
    @GetMapping("/areas")
    public ResponseEntity<List<AreaSimpleResponse>> listarAreas() {
        List<AreaSimpleResponse> areas = areaRepository.findAll().stream()
                .filter(Area::isActivo)
                .sorted(Comparator.comparing(Area::getNombre, String.CASE_INSENSITIVE_ORDER))
                .map(a -> new AreaSimpleResponse(a.getId(), a.getNombre()))
                .toList();
        return ResponseEntity.ok(areas);
    }
}
