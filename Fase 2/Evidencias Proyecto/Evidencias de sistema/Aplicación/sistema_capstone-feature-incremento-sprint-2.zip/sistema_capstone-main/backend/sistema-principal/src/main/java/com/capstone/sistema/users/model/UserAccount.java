package com.capstone.sistema.users.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Entity
@Table(name = "usuario")
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "keycloak_id", unique = true, length = 255)
    private String keycloakUserId;

    @Column(nullable = false, unique = true, length = 255)
    private String email;

    @Column(name = "rut", unique = true, length = 12)
    private String rut;

    @Column(name = "nombre", nullable = false, length = 100)
    private String firstName;

    @Column(name = "apellido", nullable = false, length = 100)
    private String lastName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "jefatura_directa_id")
    private UserAccount jefaturaDirecta;

    @Column(name = "version_acceso", nullable = false)
    private long versionAcceso;

    public UserAccount getJefaturaDirecta() { return jefaturaDirecta; }
    public void setJefaturaDirecta(UserAccount value) { this.jefaturaDirecta=value; }
    public long getVersionAcceso() { return versionAcceso; }
    public void incrementVersionAcceso() { versionAcceso++; }

    @Column(name = "activo", nullable = false)
    private boolean enabled = true;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "usuario_rol",
            joinColumns = @JoinColumn(name = "usuario_id"),
            inverseJoinColumns = @JoinColumn(name = "rol_id")
    )
    private Set<RolFlujo> roles = new LinkedHashSet<>();

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected UserAccount() {
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String firstName,
            String lastName,
            boolean enabled,
            Set<RolFlujo> roles
    ) {
        this.keycloakUserId = keycloakUserId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.enabled = enabled;
        this.roles = roles != null ? new LinkedHashSet<>(roles) : new LinkedHashSet<>();
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String firstName,
            String lastName,
            Area area,
            boolean enabled,
            Set<RolFlujo> roles
    ) {
        this(keycloakUserId, email, firstName, lastName, enabled, roles);
        this.area = area;
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String rut,
            String firstName,
            String lastName,
            Area area,
            boolean enabled,
            Set<RolFlujo> roles
    ) {
        this(keycloakUserId, email, firstName, lastName, area, enabled, roles);
        this.rut = rut;
    }

    public UserAccount(
            UUID id,
            String keycloakUserId,
            String email,
            String rut,
            String firstName,
            String lastName,
            Area area,
            boolean enabled,
            Set<RolFlujo> roles
    ) {
        this(keycloakUserId, email, rut, firstName, lastName, area, enabled, roles);
        this.id = id;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (updatedAt == null) {
            updatedAt = createdAt;
        }
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public String getKeycloakUserId() {
        return keycloakUserId;
    }

    public void setKeycloakUserId(String keycloakUserId) {
        this.keycloakUserId = keycloakUserId;
    }

    public String getEmail() {
        return email;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isActivo() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Set<RolFlujo> getRolEntities() {
        return Collections.unmodifiableSet(roles);
    }

    public void setRolEntities(Set<RolFlujo> roles) {
        this.roles = roles != null ? new LinkedHashSet<>(roles) : new LinkedHashSet<>();
    }

    public Set<SystemRole> getRoles() {
        Set<String> codes = roles.stream().filter(RolFlujo::isActivo).map(RolFlujo::getNombre).collect(Collectors.toSet());
        Set<SystemRole> legacy = new LinkedHashSet<>();
        if (codes.contains("ADMIN")) legacy.add(SystemRole.ADMIN);
        if (codes.contains("EMISOR") && codes.contains("REVISOR")) legacy.add(SystemRole.APPROVER);
        return Collections.unmodifiableSet(legacy);
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
