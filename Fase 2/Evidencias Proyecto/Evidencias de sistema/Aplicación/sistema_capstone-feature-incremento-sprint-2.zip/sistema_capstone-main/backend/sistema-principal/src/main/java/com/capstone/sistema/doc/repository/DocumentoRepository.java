package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.Documento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DocumentoRepository extends JpaRepository<Documento, UUID> {

    Optional<Documento> findFirstByStorageKeyOrderByCreatedAtDesc(String storageKey);

    List<Documento> findBySolicitud_IdOrderByVersionDesc(UUID solicitudId);

    @EntityGraph(attributePaths = "formatoDocumento")
    List<Documento> findBySolicitud_IdOrderByVersionDescCreatedAtDescIdAsc(UUID solicitudId);

    Optional<Documento> findBySolicitud_IdAndVigenteTrue(UUID solicitudId);

    @EntityGraph(attributePaths = "formatoDocumento")
    List<Documento> findBySolicitud_IdInAndVigenteTrue(List<UUID> solicitudIds);
}
