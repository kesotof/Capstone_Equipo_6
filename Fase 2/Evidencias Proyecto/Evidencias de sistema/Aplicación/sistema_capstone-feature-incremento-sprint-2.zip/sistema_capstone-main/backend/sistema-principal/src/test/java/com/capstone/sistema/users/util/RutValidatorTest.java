package com.capstone.sistema.users.util;

import com.capstone.sistema.users.exception.RutInvalidoException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RutValidatorTest {

    // Lista oficial de RUTs válidos provista por el usuario
    @ParameterizedTest
    @ValueSource(strings = {
            "22459056-3",
            "5761313-0",
            "5246001-8",
            "23330610-k",
            "18148597-3",
            "17643210-1",
            "21946364-2",
            "9149965-7",
            "6917696-8",
            "10793996-2",
            "18125587-0",
            "5852733-5",
            "5966242-2",
            "5634566-3",
            "21989577-1"
    })
    @DisplayName("Debe validar exitosamente todos los RUTs válidos provistos")
    void validaRutsValidos(String rut) {
        assertThat(RutValidator.esValido(rut))
                .as("RUT %s debe ser válido", rut)
                .isTrue();
    }

    // RUTs inválidos creados alterando el dígito verificador de los válidos
    @ParameterizedTest
    @ValueSource(strings = {
            "22459056-4",
            "5761313-9",
            "5246001-1",
            "23330610-0",
            "18148597-K",
            "17643210-2",
            "21946364-8",
            "9149965-3",
            "6917696-1",
            "10793996-5",
            "18125587-8",
            "5852733-2",
            "5966242-7",
            "5634566-0",
            "21989577-4"
    })
    @DisplayName("Debe rechazar RUTs con dígito verificador alterado")
    void rechazaRutsConDvInvalido(String rut) {
        assertThat(RutValidator.esValido(rut))
                .as("RUT %s debe ser inválido", rut)
                .isFalse();
    }

    @Test
    @DisplayName("Normaliza RUT convirtiendo 'k' a 'K' mayúscula y limpiando puntos")
    void normalizaRutCorrectamente() {
        assertThat(RutValidator.normalizar("23.330.610-k")).isEqualTo("23330610-K");
        assertThat(RutValidator.normalizar("22.459.056-3")).isEqualTo("22459056-3");
        assertThat(RutValidator.normalizar("5761313-0")).isEqualTo("5761313-0");
    }

    @Test
    @DisplayName("Lanza RutInvalidoException al normalizar un RUT con DV inválido")
    void lanzaExcepcionAnteRutInvalido() {
        assertThatThrownBy(() -> RutValidator.normalizar("22459056-9"))
                .isInstanceOf(RutInvalidoException.class)
                .hasMessageContaining("El RUT ingresado no es válido");
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "abc", "123", "12.345.678-Z"})
    @DisplayName("Rechaza entradas vacías, malformadas o con caracteres extraños")
    void rechazaEntradasMalformadas(String input) {
        assertThat(RutValidator.esValido(input)).isFalse();
    }
}
