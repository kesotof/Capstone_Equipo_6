package com.capstone.sistema.flow.dto;

import java.util.List;

/** Respuesta paginada estable para la bandeja de revisiones pendientes. */
public record PaginaSolicitudesPendientesResponse(
        List<SolicitudPendienteResponse> contenido,
        int pagina,
        int tamanio,
        long totalElementos,
        int totalPaginas,
        boolean primera,
        boolean ultima
) {
}
