package com.capstone.sistema.doc.exception;

import org.springframework.http.HttpStatus;

public class DocumentDownloadException extends RuntimeException {
    private final HttpStatus status;
    private final String code;

    private DocumentDownloadException(HttpStatus status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public HttpStatus status() { return status; }
    public String code() { return code; }

    public static DocumentDownloadException missing() {
        return new DocumentDownloadException(HttpStatus.NOT_FOUND, "DOCUMENT_NOT_AVAILABLE",
                "El archivo no está disponible. Contacte a la administración.");
    }

    public static DocumentDownloadException inconsistent() {
        return new DocumentDownloadException(HttpStatus.CONFLICT, "DOCUMENT_DOWNLOAD_CONFLICT",
                "La información del archivo requiere revisión. Contacte a la administración.");
    }

    public static DocumentDownloadException unavailable() {
        return new DocumentDownloadException(HttpStatus.SERVICE_UNAVAILABLE, "DOCUMENT_STORAGE_UNAVAILABLE",
                "El almacenamiento no está disponible. Intente nuevamente.");
    }
}
