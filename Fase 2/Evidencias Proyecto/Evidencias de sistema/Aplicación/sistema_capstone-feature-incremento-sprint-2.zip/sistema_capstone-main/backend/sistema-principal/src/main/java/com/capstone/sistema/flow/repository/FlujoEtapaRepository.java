package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.FlujoEtapa;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FlujoEtapaRepository extends JpaRepository<FlujoEtapa, Long> {

    Optional<FlujoEtapa> findByFlujoDefinicion_IdAndOrden(Long flujoDefinicionId, int orden);

    List<FlujoEtapa> findByFlujoDefinicion_IdOrderByOrdenAsc(Long flujoDefinicionId);

    void deleteByFlujoDefinicion_Id(Long flujoDefinicionId);
}
