package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record ObservacionResponse(
        Long id,
        String contenido,
        boolean resuelta,
        String usuarioEmail,
        String usuarioNombre,
        Instant createdAt
) {
}
