package com.capstone.sistema.flow.model;

public enum TipoAsignacionRevisor {
    USUARIO, ROL_DEPARTAMENTAL
}
