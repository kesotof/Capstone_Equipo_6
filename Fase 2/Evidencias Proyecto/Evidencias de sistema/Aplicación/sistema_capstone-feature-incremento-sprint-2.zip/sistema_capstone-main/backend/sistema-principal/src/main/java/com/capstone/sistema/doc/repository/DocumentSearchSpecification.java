package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** La raíz es Solicitud para componer directamente la política RBAC vigente. */
public class DocumentSearchSpecification implements Specification<Solicitud> {
    private final DocumentSearchCriteria filters;

    public DocumentSearchSpecification(DocumentSearchCriteria filters) {
        this.filters = filters;
    }

    @Override
    public Predicate toPredicate(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        List<Predicate> predicates = new ArrayList<>();
        var current = query.subquery(Integer.class);
        Root<Documento> document = current.from(Documento.class);
        List<Predicate> currentFilters = new ArrayList<>();
        currentFilters.add(builder.equal(document.get("solicitud").get("id"), root.get("id")));
        currentFilters.add(builder.isTrue(document.get("vigente")));
        if (filters.documentType() != null) {
            currentFilters.add(builder.equal(builder.upper(document.get("formatoDocumento").get("tipo")), filters.documentType()));
        }
        if (filters.query() != null) {
            String pattern = literalPattern(filters.query());
            var emisor = root.join("emisor");
            var name = builder.concat(builder.concat(builder.coalesce(emisor.get("firstName"), ""), " "),
                    builder.coalesce(emisor.get("lastName"), ""));
            currentFilters.add(builder.or(
                    builder.like(builder.lower(root.get("titulo")), pattern, '\\'),
                    builder.like(builder.lower(root.get("descripcion")), pattern, '\\'),
                    builder.like(builder.lower(root.get("correlativo")), pattern, '\\'),
                    builder.like(builder.lower(name), pattern, '\\'),
                    builder.like(builder.lower(document.get("nombreArchivo")), pattern, '\\')));
        }
        current.select(builder.literal(1)).where(currentFilters.toArray(Predicate[]::new));
        predicates.add(builder.exists(current));
        if (filters.status() != null) {
            predicates.add(builder.equal(builder.upper(root.get("estadoSolicitud").get("codigo")), filters.status()));
        }
        if (filters.areaId() != null) {
            predicates.add(builder.or(builder.equal(root.get("areaOrigenId"), filters.areaId()),
                    builder.equal(root.get("areaFlujoId"), filters.areaId())));
        }
        if (filters.dateFrom() != null) {
            predicates.add(builder.greaterThanOrEqualTo(root.get("createdAt"), filters.dateFrom()));
        }
        if (filters.dateTo() != null) {
            predicates.add(filters.dateToExclusive()
                    ? builder.lessThan(root.get("createdAt"), filters.dateTo())
                    : builder.lessThanOrEqualTo(root.get("createdAt"), filters.dateTo()));
        }
        return builder.and(predicates.toArray(Predicate[]::new));
    }

    private String literalPattern(String value) {
        return "%" + value.toLowerCase(Locale.ROOT).replace("\\", "\\\\")
                .replace("%", "\\%").replace("_", "\\_") + "%";
    }
}
