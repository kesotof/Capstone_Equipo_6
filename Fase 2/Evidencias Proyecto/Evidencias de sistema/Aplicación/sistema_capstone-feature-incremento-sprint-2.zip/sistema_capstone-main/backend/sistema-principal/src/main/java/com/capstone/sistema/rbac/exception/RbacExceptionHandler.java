package com.capstone.sistema.rbac.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RbacExceptionHandler {
    @ExceptionHandler(RbacException.class)
    public ResponseEntity<ProblemDetail> handle(RbacException e) {
        ProblemDetail detail = ProblemDetail.forStatusAndDetail(e.status(), e.getMessage());
        detail.setTitle("Control de acceso");
        detail.setProperty("codigo", e.codigo());
        return ResponseEntity.status(e.status()).body(detail);
    }
}

