package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record CrearSolicitudResponse(
        UUID solicitudId,
        UUID documentoId,
        String estado,
        String mensaje,
        String correlativo,
        Instant deadline
) {
    public CrearSolicitudResponse(UUID solicitudId, UUID documentoId, String estado, String mensaje) {
        this(solicitudId, documentoId, estado, mensaje, null, null);
    }
}
