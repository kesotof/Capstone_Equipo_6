package com.capstone.sistema.audit.dto;

import java.time.Instant;

public record AuditEventResponse(
        Long id,
        String email,
        String eventType,
        String ipAddress,
        String detalle,
        Instant occurredAt
) {
}
