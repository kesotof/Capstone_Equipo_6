package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.FlujoDefinicion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface FlujoDefinicionRepository extends JpaRepository<FlujoDefinicion, Long> {

    @Query(value = "select exists(select 1 from flujo_definicion where lower(btrim(nombre))=lower(btrim(:nombre)) and (cast(:id as bigint) is null or id<>cast(:id as bigint)))", nativeQuery = true)
    boolean existsNormalizedName(@Param("nombre") String nombre, @Param("id") Long id);

    Optional<FlujoDefinicion> findByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

    List<FlujoDefinicion> findByArea_Id(Long areaId);

    List<FlujoDefinicion> findByActivoTrue();
}
