package com.capstone.sistema.users.exception;

import org.springframework.http.HttpStatus;

import java.util.Map;

public class PasswordChangeException extends RuntimeException {
    private final HttpStatus status;
    private final String code;
    private final Map<String, String> invalidFields;

    public PasswordChangeException(HttpStatus status, String code, String message) {
        this(status, code, message, Map.of());
    }

    public PasswordChangeException(HttpStatus status, String code, String message, Map<String, String> invalidFields) {
        super(message);
        this.status = status;
        this.code = code;
        this.invalidFields = Map.copyOf(invalidFields);
    }

    public HttpStatus status() { return status; }
    public String code() { return code; }
    public Map<String, String> invalidFields() { return invalidFields; }

    public static PasswordChangeException unavailable() {
        return new PasswordChangeException(HttpStatus.SERVICE_UNAVAILABLE, "IDENTITY_PROVIDER_UNAVAILABLE",
                "No fue posible verificar la seguridad de la cuenta. Inténtelo más tarde.");
    }
}
