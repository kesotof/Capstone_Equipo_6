package com.capstone.sistema.doc;

import com.capstone.sistema.rbac.exception.RbacException;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.Map;

@RestController
@RequestMapping("/api/doc")
@PreAuthorize("isAuthenticated()")
public class DocController {
    private final MinioStorageService storage;
    public DocController(MinioStorageService storage) {
        this.storage=storage;
    }
    @PostMapping("/upload")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> uploadDocument(@RequestParam("file") MultipartFile file) throws Exception {
        if(file==null || file.isEmpty()) throw RbacException.invalid("El archivo es obligatorio.");
        String key=storage.uploadFile(file);
        return ResponseEntity.ok(Map.of("message","Archivo almacenado en MinIO correctamente","fileKey",key,
                "originalName",file.getOriginalFilename()==null?"archivo":file.getOriginalFilename()));
    }
}
