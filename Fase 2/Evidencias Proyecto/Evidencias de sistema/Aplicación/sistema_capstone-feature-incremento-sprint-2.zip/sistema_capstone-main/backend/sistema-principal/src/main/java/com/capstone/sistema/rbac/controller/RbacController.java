package com.capstone.sistema.rbac.controller;

import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.service.*;
import com.capstone.sistema.users.dto.UserResponse;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.*;

@RestController
@PreAuthorize("isAuthenticated()")
public class RbacController {
    private final RbacAccessService access;
    private final RbacManagementService management;
    private final RbacCatalogService catalog;
    public RbacController(RbacAccessService access,RbacManagementService management,RbacCatalogService catalog) {
        this.access=access; this.management=management; this.catalog=catalog;
    }
    @GetMapping("/api/rbac/me")
    public ResponseEntity<Me> me() { return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(access.me()); }
    @GetMapping("/api/rbac/permisos")
    public List<Permission> permissions() { return management.permissions(); }
    @GetMapping("/api/rbac/roles")
    public Page<Role> roles(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="10") int size,
                           @RequestParam(required=false) String q,@RequestParam(required=false) Boolean activo) { return management.list(page,size,q,activo); }
    @GetMapping("/api/rbac/roles/{id}")
    public Role role(@PathVariable Long id) { return management.role(id); }
    @PostMapping("/api/rbac/roles")
    public ResponseEntity<Role> create(@Valid @RequestBody RoleCreate request) {
        Role role=management.create(request); return ResponseEntity.created(URI.create("/api/rbac/roles/"+role.id())).body(role);
    }
    @PutMapping("/api/rbac/roles/{id}")
    public Role update(@PathVariable Long id,@Valid @RequestBody RoleUpdate request) { return management.update(id,request); }
    @PatchMapping("/api/rbac/roles/{id}/status")
    public Role status(@PathVariable Long id,@Valid @RequestBody Status request) { return management.status(id,request); }
    @PutMapping("/api/users/{id}/roles")
    public UserResponse membership(@PathVariable UUID id,@Valid @RequestBody Membership request) { return management.membership(id,request); }
    @PutMapping("/api/users/{id}/jefatura")
    public UserResponse manager(@PathVariable UUID id,@Valid @RequestBody Manager request) { return management.manager(id,request); }
    @GetMapping("/api/rbac/catalogos/areas")
    public List<AreaItem> areas() { return catalog.areas(); }
    @GetMapping("/api/rbac/catalogos/revisores")
    public List<Reviewer> reviewers(@RequestParam(required=false) Long areaId) { return catalog.reviewers(areaId); }
}

