package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record RequestDetailResponse(
        UUID id,
        String correlativo,
        String titulo,
        String descripcion,
        String estado,
        UUID emisorId,
        String emisorNombre,
        Instant createdAt,
        Instant updatedAt,
        Long version,
        FlujoDetalleResponse flujo,
        AreaDetalleResponse areaOrigen,
        AreaDetalleResponse areaFlujo,
        EtapaSolicitudResponse etapaActual,
        DocumentoDetalleResponse documentoVigente,
        List<DocumentoDetalleResponse> documentos,
        SlaDetalleResponse sla,
        SeccionDetalleResponse<ObservacionDetalleResponse> observaciones,
        SeccionDetalleResponse<EventoDetalleResponse> historial,
        List<String> accionesPermitidas
) {
    public RequestDetailResponse {
        documentos = List.copyOf(documentos);
        accionesPermitidas = List.copyOf(accionesPermitidas);
    }
}
