package com.capstone.sistema.flow.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Configuration
public class DashboardSummaryWebConfig {
    @Bean
    public FilterRegistrationBean<OncePerRequestFilter> dashboardSummaryNoStoreFilter() {
        var registration = new FilterRegistrationBean<OncePerRequestFilter>();
        registration.setFilter(new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                    throws ServletException, IOException {
                response.setHeader("Cache-Control", "no-store");
                response.setHeader("X-Content-Type-Options", "nosniff");
                chain.doFilter(request, response);
            }
        });
        registration.setName("dashboardSummaryNoStore");
        registration.setUrlPatterns(List.of("/api/dashboard/summary"));
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 23);
        return registration;
    }
}
