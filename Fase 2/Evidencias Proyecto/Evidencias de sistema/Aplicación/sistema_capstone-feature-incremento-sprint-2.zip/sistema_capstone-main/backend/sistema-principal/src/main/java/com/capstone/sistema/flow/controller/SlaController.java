package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.CreateSlaConfigRequest;
import com.capstone.sistema.flow.dto.SlaConfigResponse;
import com.capstone.sistema.flow.dto.UpdateSlaConfigRequest;
import com.capstone.sistema.flow.service.SlaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@Tag(name = "SLA", description = "Administración de plazos contractuales y tiempos de respuesta por tipo de documento")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/sla")
public class SlaController {

    private final SlaService slaService;

    public SlaController(SlaService slaService) {
        this.slaService = slaService;
    }

    @Operation(summary = "Listar reglas SLA vigentes")
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<SlaConfigResponse>> listAll() {
        return ResponseEntity.ok(slaService.listAll());
    }

    @Operation(summary = "Obtener regla SLA por ID")
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<SlaConfigResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(slaService.getById(id));
    }

    @Operation(summary = "Crear nueva regla SLA por tipo de documento")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<SlaConfigResponse> create(@Valid @RequestBody CreateSlaConfigRequest request) {
        SlaConfigResponse created = slaService.create(request);
        return ResponseEntity.created(URI.create("/api/sla/" + created.id())).body(created);
    }

    @Operation(summary = "Actualizar plazo en días hábiles de una regla SLA")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<SlaConfigResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateSlaConfigRequest request
    ) {
        return ResponseEntity.ok(slaService.update(id, request));
    }

    @Operation(summary = "Eliminar una regla SLA")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        slaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
