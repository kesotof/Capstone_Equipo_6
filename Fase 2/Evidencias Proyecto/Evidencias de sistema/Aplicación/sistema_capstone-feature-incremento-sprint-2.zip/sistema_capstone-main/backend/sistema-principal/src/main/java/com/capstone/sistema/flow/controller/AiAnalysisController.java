package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.AiAnalysisRequest;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.service.AiAnalysisService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/solicitudes/{id}/ai-analysis")
@Tag(name = "Análisis IA", description = "Endpoints de auditoría y evaluación inteligente de documentos")
@PreAuthorize("isAuthenticated()")
public class AiAnalysisController {

    private final AiAnalysisService aiAnalysisService;

    public AiAnalysisController(AiAnalysisService aiAnalysisService) {
        this.aiAnalysisService = aiAnalysisService;
    }

    @PostMapping
    @Operation(summary = "Solicitar o consultar análisis de IA para una solicitud",
               description = "Inicia un análisis asíncrono vía RabbitMQ y OpenRouter o retorna el resultado en caché si el documento y prompt no han cambiado.")
    public ResponseEntity<AiAnalysisResponse> solicitarAnalisis(
            @PathVariable UUID id,
            @RequestBody(required = false) AiAnalysisRequest request,
            @RequestParam(value = "force", defaultValue = "false") boolean force
    ) {
        String prompt = request != null ? request.prompt() : null;
        AiAnalysisResponse response = aiAnalysisService.solicitarAnalisis(id, prompt, force);

        if (response.cached()) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }

    @GetMapping
    @Operation(summary = "Obtener el último análisis de IA de la solicitud",
               description = "Retorna el análisis más reciente realizado sobre la solicitud.")
    public ResponseEntity<AiAnalysisResponse> obtenerUltimoAnalisis(@PathVariable UUID id) {
        AiAnalysisResponse response = aiAnalysisService.obtenerUltimoAnalisis(id);
        return ResponseEntity.ok(response);
    }
}
