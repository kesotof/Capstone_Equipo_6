package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.SolicitudTransicion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface SolicitudTransicionRepository extends JpaRepository<SolicitudTransicion, Long>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<SolicitudTransicion> {

    List<SolicitudTransicion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId);
    List<SolicitudTransicion> findBySolicitud_IdOrderByCreatedAtAscIdAsc(UUID solicitudId);

    long countByDentroSlaTrue();

    long countByDentroSlaFalse();

    @Query("""
            select t.id as id, origen.codigo as estadoOrigen, destino.codigo as estadoDestino,
                   a.accion as accion, u.firstName as usuarioNombre, u.lastName as usuarioApellido,
                   case when :comentariosVisibles = true then t.comentario else null end as comentario,
                   t.dentroSla as dentroSla, t.createdAt as createdAt,
                   eo.id as etapaOrigenId, eo.orden as etapaOrigenOrden, eo.nombre as etapaOrigenNombre,
                   ed.id as etapaDestinoId, ed.orden as etapaDestinoOrden, ed.nombre as etapaDestinoNombre
            from SolicitudTransicion t
            left join t.estadoOrigen origen
            join t.estadoDestino destino
            join t.accionUsuario a
            join t.usuario u
            left join t.etapaOrigen eo
            left join t.etapaDestino ed
            where t.solicitud.id = :solicitudId
            order by t.createdAt asc, t.id asc
            """)
    List<Detalle> consultarDetalle(@Param("solicitudId") UUID solicitudId,
                                  @Param("comentariosVisibles") boolean comentariosVisibles);

    interface Detalle {
        Long getId();
        String getEstadoOrigen();
        String getEstadoDestino();
        String getAccion();
        String getUsuarioNombre();
        String getUsuarioApellido();
        String getComentario();
        Boolean getDentroSla();
        Instant getCreatedAt();
        Long getEtapaOrigenId();
        Integer getEtapaOrigenOrden();
        String getEtapaOrigenNombre();
        Long getEtapaDestinoId();
        Integer getEtapaDestinoOrden();
        String getEtapaDestinoNombre();
    }
}
