package com.capstone.sistema.rbac.config;

import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.*;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.LinkedHashSet;

/** Primer administrador por subject explícito, solo en una instalación sin administrador local. */
@Component
@Order(5)
public class RbacBootstrapInitializer implements ApplicationRunner {
    private static final Logger log=LoggerFactory.getLogger(RbacBootstrapInitializer.class);
    private final String subject;
    private final JdbcTemplate jdbc;
    private final UserAccountRepository users;
    private final RolFlujoRepository roles;
    private final RbacManagementService management;
    public RbacBootstrapInitializer(@Value("${rbac.bootstrap-admin-sub:}") String subject,JdbcTemplate jdbc,
                                   UserAccountRepository users,RolFlujoRepository roles,RbacManagementService management) {
        this.subject=subject;this.jdbc=jdbc;this.users=users;this.roles=roles;this.management=management;
    }
    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        var before=management.prepareMutation();
        int initialized=jdbc.queryForObject("select bootstrap_completado::int from rbac_control where id=1",Integer.class);
        if(initialized!=0) return;
        long count=jdbc.queryForObject("select count(*) from usuario u join usuario_rol ur on ur.usuario_id=u.id join rol_flujo r on r.id=ur.rol_id where u.activo=true and r.activo=true and r.nombre='ADMIN'",Long.class);
        if(count>0) {
            jdbc.update("update rbac_control set bootstrap_completado=true where id=1");
            return;
        }
        if(subject.isBlank()) {
            log.warn("No existe ADMIN local activo. Configure RBAC_BOOTSTRAP_ADMIN_SUB explícitamente para la primera asignación; las identidades importadas no reciben privilegios.");
            return;
        }
        var user=users.findByKeycloakUserId(subject).filter(u->u.isEnabled()).orElseThrow(
                ()->new IllegalStateException("El subject de bootstrap debe corresponder a una cuenta local activa importada desde Keycloak."));
        var selected=new LinkedHashSet<>(user.getRolEntities());
        selected.add(roles.findByNombreIgnoreCase("ADMIN").orElseThrow());
        user.setRolEntities(selected);user.incrementVersionAcceso();users.saveAndFlush(user);
        jdbc.update("update rbac_control set bootstrap_completado=true where id=1");
        management.finishMutation(before);
        management.auditChange("BOOTSTRAP_ADMIN",user.getId(),java.util.List.of(),java.util.List.of("ADMIN"));
    }
}

