package com.capstone.sistema.flow.util;

import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.time.Instant;
import static org.assertj.core.api.Assertions.assertThat;

class SlaStatusCalculatorTest {
    private static final Instant DEADLINE = Instant.parse("2026-10-12T13:00:00Z");

    @Test
    void limitesDeAlertaYDecisionSonCoherentes() {
        assertThat(SlaStatusCalculator.status(DEADLINE, DEADLINE.minus(Duration.ofHours(24))))
                .isEqualTo("NORMAL");
        assertThat(SlaStatusCalculator.status(DEADLINE, DEADLINE.minus(Duration.ofHours(24)).plusNanos(1)))
                .isEqualTo("POR_VENCER");
        assertThat(SlaStatusCalculator.status(DEADLINE, DEADLINE)).isEqualTo("POR_VENCER");
        assertThat(SlaStatusCalculator.status(DEADLINE, DEADLINE.plusNanos(1))).isEqualTo("VENCIDO");
        assertThat(SlaStatusCalculator.withinDeadline(DEADLINE, DEADLINE.minusNanos(1))).isTrue();
        assertThat(SlaStatusCalculator.withinDeadline(DEADLINE, DEADLINE)).isTrue();
        assertThat(SlaStatusCalculator.withinDeadline(DEADLINE, DEADLINE.plusNanos(1))).isFalse();
    }

    @Test
    void plazoAusenteNoInventaEstadoOCumplimiento() {
        assertThat(SlaStatusCalculator.status(null, DEADLINE)).isNull();
        assertThat(SlaStatusCalculator.withinDeadline(null, DEADLINE)).isNull();
    }

    @Test
    void ventanaEsDeHorasCorridasInclusoFinDeSemana() {
        assertThat(SlaStatusCalculator.status(DEADLINE, Instant.parse("2026-10-11T14:00:00Z")))
                .isEqualTo("POR_VENCER");
    }

    @Test
    void evaluacionNoDesbordaAlFinalDelRangoInstant() {
        assertThat(SlaStatusCalculator.status(Instant.MAX, Instant.MAX.minusSeconds(1))).isEqualTo("POR_VENCER");
    }
}
