package com.capstone.sistema.users.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.UpdateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.exception.UserExceptionHandler;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.service.UserManagementService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserController.class)
@Import({SecurityConfig.class, UserExceptionHandler.class})
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserManagementService userManagementService;

    @MockBean
    private com.capstone.sistema.users.repository.AreaRepository areaRepository;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("Admin crea usuario exitosamente con RUT chileno válido")
    void createUser_withValidRut_returnsCreated201() throws Exception {
        UUID newId = UUID.randomUUID();
        CreateUserRequest request = new CreateUserRequest(
                "carlos@empresa.cl",
                "22459056-3",
                "Carlos",
                "Mendoza",
                "Temporal123!",
                Set.of(SystemRole.APPROVER),
                2L,
                false
        );

        UserResponse response = new UserResponse(
                newId,
                "kc-uuid-1",
                "carlos@empresa.cl",
                "22459056-3",
                "Carlos",
                "Mendoza",
                2L,
                "Finanzas",
                true,
                false,
                Set.of(SystemRole.APPROVER),
                Instant.now()
        );

        when(userManagementService.createUser(any(CreateUserRequest.class))).thenReturn(response);

        mockMvc.perform(post("/api/users")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(newId.toString()))
                .andExpect(jsonPath("$.email").value("carlos@empresa.cl"))
                .andExpect(jsonPath("$.rut").value("22459056-3"))
                .andExpect(jsonPath("$.areaId").value(2))
                .andExpect(jsonPath("$.areaNombre").value("Finanzas"));

        verify(userManagementService).createUser(any(CreateUserRequest.class));
    }

    @Test
    @DisplayName("Rechaza solicitud de creación cuando el RUT está vacío")
    void createUser_withBlankRut_returnsBadRequest400() throws Exception {
        CreateUserRequest request = new CreateUserRequest(
                "carlos@empresa.cl",
                "",
                "Carlos",
                "Mendoza",
                "Temporal123!",
                Set.of(SystemRole.APPROVER),
                null,
                false
        );

        mockMvc.perform(post("/api/users")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"));
    }

    @Test
    @DisplayName("Usuario con rol distinto a ADMIN recibe 403 Forbidden")
    void createUser_forbiddenForNonAdmin_returnsForbidden403() throws Exception {
        CreateUserRequest request = new CreateUserRequest(
                "carlos@empresa.cl",
                "22459056-3",
                "Carlos",
                "Mendoza",
                "Temporal123!",
                Set.of(SystemRole.APPROVER),
                null,
                false
        );

        mockMvc.perform(post("/api/users")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_APPROVER")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Admin actualiza usuario y le asigna nueva área respondiendo 200 OK")
    void updateUser_assignArea_returnsOk200() throws Exception {
        UUID userId = UUID.randomUUID();
        UpdateUserRequest request = new UpdateUserRequest("Carlos", "Mendoza", 3L, null, null);

        UserResponse response = new UserResponse(
                userId,
                "kc-uuid-1",
                "carlos@empresa.cl",
                "22459056-3",
                "Carlos",
                "Mendoza",
                3L,
                "Operaciones",
                true,
                false,
                Set.of(SystemRole.APPROVER),
                Instant.now()
        );

        when(userManagementService.updateUser(eq(userId), any(UpdateUserRequest.class))).thenReturn(response);

        mockMvc.perform(put("/api/users/" + userId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.areaId").value(3))
                .andExpect(jsonPath("$.areaNombre").value("Operaciones"));
    }

    @Test
    @DisplayName("Admin lista usuarios con RUT y datos de área")
    void listUsers_returnsListWithRutAndArea() throws Exception {
        UserResponse user1 = new UserResponse(
                UUID.randomUUID(), "kc-1", "user1@capstone.local", "22459056-3",
                "Carlos", "Mendoza", 1L, "General", true, false, Set.of(SystemRole.ADMIN), Instant.now()
        );
        UserResponse user2 = new UserResponse(
                UUID.randomUUID(), "kc-2", "user2@capstone.local", "5761313-0",
                "Andrea", "Perez", 2L, "Finanzas", true, false, Set.of(SystemRole.APPROVER), Instant.now()
        );

        when(userManagementService.listUsers()).thenReturn(List.of(user1, user2));

        mockMvc.perform(get("/api/users")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].rut").value("22459056-3"))
                .andExpect(jsonPath("$[0].areaNombre").value("General"))
                .andExpect(jsonPath("$[1].rut").value("5761313-0"))
                .andExpect(jsonPath("$[1].areaNombre").value("Finanzas"));
    }

    @Test
    @DisplayName("Usuario autenticado cambia contraseña exitosamente")
    void changePassword_success_returns200Ok() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("OldPassword123!", "NewSecret456!", "NewSecret456!");

        mockMvc.perform(post("/api/users/me/change-password")
                        .with(jwt().jwt(j -> j.claim("email", "user@empresa.cl")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Contraseña actualizada exitosamente"));

        verify(userManagementService).changePassword(any(com.capstone.sistema.users.dto.ChangePasswordRequest.class));
    }

    @Test
    @DisplayName("changePassword cuando la clave actual es incorrecta responde 400 Bad Request con detalle exacto")
    void changePassword_wrongCurrentPassword_returnsBadRequest400() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("WrongPass123!", "NewSecret456!", "NewSecret456!");

        org.mockito.Mockito.doThrow(new com.capstone.sistema.users.exception.InvalidCurrentPasswordException())
                .when(userManagementService).changePassword(any(com.capstone.sistema.users.dto.ChangePasswordRequest.class));

        mockMvc.perform(post("/api/users/me/change-password")
                        .with(jwt().jwt(j -> j.claim("email", "user@empresa.cl")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value("La contraseña actual es incorrecta, inténtelo nuevamente."));
    }

    @Test
    @DisplayName("changePassword cuando las contraseñas no coinciden responde 400 Bad Request con detalle exacto")
    void changePassword_mismatchedPasswords_returnsBadRequest400() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("OldPassword123!", "NewSecret456!", "Different456!");

        org.mockito.Mockito.doThrow(new com.capstone.sistema.users.exception.PasswordMismatchException())
                .when(userManagementService).changePassword(any(com.capstone.sistema.users.dto.ChangePasswordRequest.class));

        mockMvc.perform(post("/api/users/me/change-password")
                        .with(jwt().jwt(j -> j.claim("email", "user@empresa.cl")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value("Las contraseñas no coinciden."));
    }

    @Test
    @DisplayName("changePassword cuando la contraseña no cumple política responde 400 Bad Request")
    void changePassword_policyViolation_returnsBadRequest400() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("OldPassword123!", "weakpass123", "weakpass123");

        org.mockito.Mockito.doThrow(new com.capstone.sistema.users.exception.PasswordPolicyException("La nueva contraseña debe tener al menos 8 caracteres."))
                .when(userManagementService).changePassword(any(com.capstone.sistema.users.dto.ChangePasswordRequest.class));

        mockMvc.perform(post("/api/users/me/change-password")
                        .with(jwt().jwt(j -> j.claim("email", "user@empresa.cl")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value("La nueva contraseña debe tener al menos 8 caracteres."));
    }

    @Test
    @DisplayName("Petición sin autenticación para cambio de contraseña retorna 401")
    void changePassword_unauthenticated_returnsUnauthorized401() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("OldPassword123!", "NewSecret456!", "NewSecret456!");

        mockMvc.perform(post("/api/users/me/change-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("POST /api/users con JSON malformado responde 400 Bad Request (no 500)")
    void createUser_withMalformedJson_returnsBadRequest400() throws Exception {
        String jsonMalformado = "{\"email\": \"carlos@empresa.cl\", invalid_syntax}";

        mockMvc.perform(post("/api/users")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonMalformado))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Cuerpo de solicitud inválido"));
    }

    @Test
    @DisplayName("PUT /api/users/{id} con UUID inválido responde 400 Bad Request (no 500)")
    void updateUser_withInvalidUuid_returnsBadRequest400() throws Exception {
        UpdateUserRequest request = new UpdateUserRequest("Carlos", "Mendoza", 3L, null, null);

        mockMvc.perform(put("/api/users/no-es-un-uuid")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Parámetro inválido"));
    }

    @Test
    @DisplayName("POST /api/users/me/change-password con contraseña vacía responde 400 Bad Request")
    void changePassword_withBlankPassword_returnsBadRequest400() throws Exception {
        com.capstone.sistema.users.dto.ChangePasswordRequest request =
                new com.capstone.sistema.users.dto.ChangePasswordRequest("", "", "");

        mockMvc.perform(post("/api/users/me/change-password")
                        .with(jwt().jwt(j -> j.claim("email", "user@empresa.cl")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Error de validación"));
    }
}
