package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.exception.FlujoNotFoundException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Service
@Transactional(readOnly = true)
public class FlujoConfigService {
    private final FlujoDefinicionRepository definitions;
    private final SolicitudRepository requests;
    private final AreaRepository areas;
    private final AuditService audit;
    private final RbacAccessService access;
    private final RbacManagementService security;
    private final FlujoConcurrencyService concurrency;
    private final FlujoIntegrityService integrity;
    private final FlujoReviewerResolver reviewers;

    public FlujoConfigService(FlujoDefinicionRepository definitions, SolicitudRepository requests,
            AreaRepository areas, AuditService audit, RbacAccessService access,
            RbacManagementService security, FlujoConcurrencyService concurrency, FlujoIntegrityService integrity, FlujoReviewerResolver reviewers) {
        this.definitions=definitions; this.requests=requests; this.areas=areas;
        this.audit=audit; this.access=access; this.security=security;
        this.concurrency=concurrency; this.integrity=integrity; this.reviewers=reviewers;
    }

    @Transactional
    public FlujoResponse crearFlujo(CrearFlujoRequest request) {
        Set<String> before=security.prepareMutation();
        access.manageFlow(request.areaId());
        String name=validateName(request.nombre());
        if (FlujoIntegrityService.BASE_NAME.equalsIgnoreCase(name)) throw protectedFlow();
        checkUnique(name,null);
        FlujoDefinicion flow=new FlujoDefinicion(name,validateDescription(request.descripcion()),activeArea(request.areaId()));
        definitions.saveAndFlush(flow);
        security.finishMutation(before);
        audit.registerUserManagementEvent("CREAR_FLUJO","Flujo creado inactivo e incompleto: " + flow.getId() + " — " + name);
        return toResponse(flow);
    }

    @Transactional
    public FlujoResponse actualizarFlujo(Long id, ActualizarFlujoRequest request) {
        Set<String> before=security.prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        access.manageFlow(request.areaId());
        String name=validateName(request.nombre());
        Long previousArea=areaId(flow);
        boolean base=integrity.isBase(flow);
        if (base && (!FlujoIntegrityService.BASE_NAME.equals(name) || request.areaId()!=null)) throw protectedFlow();
        if (!base && FlujoIntegrityService.BASE_NAME.equalsIgnoreCase(name)) throw protectedFlow();
        if (!Objects.equals(previousArea,request.areaId()) && requests.existsByFlujoDefinicion_Id(id)) {
            throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION","Un flujo con solicitudes vinculadas conserva su área. Cree otra definición para el nuevo destino.");
        }
        checkUnique(name,id);
        flow.setNombre(name);
        flow.setDescripcion(validateDescription(request.descripcion()));
        // Conservar metadata de áreas históricas inactivas si no hay traslado ni activación.
        if (!Objects.equals(previousArea,request.areaId())) flow.setArea(activeArea(request.areaId()));
        if (request.activo()!=null) setStatus(flow,request.activo());
        else if (flow.isActivo()) validateActivation(flow);
        else flow.setCompleto(integrity.complete(flow));
        flow.touch();
        definitions.saveAndFlush(flow);
        security.finishMutation(before);
        audit.registerUserManagementEvent("ACTUALIZAR_FLUJO","Metadatos del flujo " + id + " actualizados; versión " + flow.getVersion());
        return toResponse(flow);
    }

    @Transactional
    public FlujoResponse cambiarEstado(Long id, EstadoFlujoRequest request) {
        Set<String> before=security.prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        if (request.activo()==null) throw new IllegalArgumentException("El estado activo es obligatorio.");
        setStatus(flow,request.activo());
        flow.touch();
        definitions.saveAndFlush(flow);
        security.finishMutation(before);
        audit.registerUserManagementEvent("CAMBIAR_ESTADO_FLUJO","Flujo " + id + ": activo=" + flow.isActivo() + ", versión=" + flow.getVersion());
        return toResponse(flow);
    }

    public FlujoResponse obtenerFlujo(Long id) {
        FlujoDefinicion flow=definitions.findById(id).orElseThrow(()->new FlujoNotFoundException("Flujo no encontrado"));
        if (!access.canManageFlow(areaId(flow)) && !selectable(flow)) throw RbacException.missing();
        return toResponse(flow);
    }

    public List<FlujoResponse> listarFlujos(Long areaId, Boolean activo) { return listarFlujos(areaId,activo,null); }

    public List<FlujoResponse> listarFlujos(Long areaId, Boolean activo, Boolean completo) {
        if (areaId!=null && areaId<=0) throw new IllegalArgumentException("El ID del área debe ser positivo.");
        List<FlujoDefinicion> flows=areaId!=null ? definitions.findByArea_Id(areaId) : definitions.findAll();
        return flows.stream()
                .filter(f->access.canManageFlow(areaId(f)) || selectable(f))
                .filter(f->activo==null || f.isActivo()==activo)
                .filter(f->completo==null || integrity.complete(f)==completo)
                .sorted(Comparator.comparing(FlujoDefinicion::getNombre,String.CASE_INSENSITIVE_ORDER).thenComparing(FlujoDefinicion::getId))
                .map(this::toResponse).toList();
    }

    @Transactional
    public FlujoResponse configurarEtapas(Long id, ConfigurarEtapasRequest request) {
        Set<String> before=security.prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        if (Long.valueOf(1).equals(id)) throw protectedFlow();
        if (requests.existsByFlujoDefinicion_Id(id)) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "No puede reemplazar las etapas de un flujo con solicitudes vinculadas.");
        List<EtapaConfigItem> items=request.etapas();
        if (items==null || items.isEmpty() || items.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Debe configurar al menos una etapa válida.");
        }
        List<EtapaConfigItem> ordered=items.stream().sorted(Comparator.comparing(EtapaConfigItem::orden,
                Comparator.nullsLast(Comparator.naturalOrder()))).toList();
        List<FlujoEtapa> stages=new ArrayList<>();
        for (int i=0;i<ordered.size();i++) {
            EtapaConfigItem item=ordered.get(i);
            if (item.orden()==null || item.orden()!=i+1) throw new IllegalArgumentException("Las etapas deben tener orden consecutivo desde 1, sin duplicados ni saltos.");
            if (item.tipoAccion()!=TipoAccionEtapa.REVISION) throw new IllegalArgumentException("El tipo de acción soportado es REVISION.");
            FlujoEtapa stage=new FlujoEtapa(flow,item.orden(),validateName(item.nombre()));
            reviewers.assign(stage,item.tipoAsignacion(),item.revisorId(),item.rolRevisorId());
            stages.add(stage);
        }
        boolean complete=true;
        flow.getEtapas().clear();
        definitions.flush();
        stages.forEach(flow::addEtapa);
        flow.setCompleto(complete);
        if (flow.isActivo()) validateActivation(flow);
        flow.touch();
        definitions.saveAndFlush(flow);
        security.finishMutation(before);
        audit.registerUserManagementEvent("CONFIGURAR_ETAPAS_FLUJO","Flujo " + id + ": " + stages.size()
                + " etapas secuenciales, completo=" + complete + ", versión=" + flow.getVersion());
        return toResponse(flow);
    }

    @Transactional
    public void eliminarFlujo(Long id, Long version) {
        Set<String> before=security.prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,version);
        if (Long.valueOf(1).equals(id)) throw protectedFlow();
        boolean used=requests.existsByFlujoDefinicion_Id(id);
        if (used) { flow.setActivo(false); flow.touch(); definitions.save(flow); }
        else definitions.delete(flow);
        definitions.flush();
        security.finishMutation(before);
        audit.registerUserManagementEvent(used?"DESACTIVAR_FLUJO":"ELIMINAR_FLUJO",
                "Flujo " + id + (used?" desactivado conservando solicitudes y etapas.":" eliminado sin solicitudes vinculadas."));
    }

    @Transactional
    public void eliminarFlujo(Long id) { eliminarFlujo(id,null); }

    private FlujoDefinicion managedDefinition(Long id, Long version) {
        FlujoDefinicion flow=concurrency.lockDefinition(id);
        access.manageFlow(areaId(flow));
        concurrency.checkVersion(flow.getVersion(),version,"FLUJO_VERSION_CONFLICTO");
        return flow;
    }

    private void setStatus(FlujoDefinicion flow, boolean active) {
        if (active) validateActivation(flow);
        else flow.setCompleto(integrity.complete(flow));
        flow.setActivo(active);
    }

    private void validateActivation(FlujoDefinicion flow) {
        if (flow.getArea()!=null && !flow.getArea().isActivo()) throw RbacException.conflict("FLUJO_INACTIVO","El área del flujo está inactiva.");
        integrity.orderedStages(flow);
        if (!integrity.isBase(flow)) flow.getEtapas().forEach(reviewers::requireAvailable);
        flow.setCompleto(true);
    }

    private boolean selectable(FlujoDefinicion flow) {
        return access.canEmitFlow(flow) && integrity.complete(flow)
                && (flow.getArea()==null || flow.getArea().isActivo());
    }

    private Area activeArea(Long id) {
        if (id==null) return null;
        if (id<=0) throw new IllegalArgumentException("El ID del área debe ser positivo.");
        Area area=areas.findById(id).orElseThrow(()->new IllegalArgumentException("El área indicada no existe."));
        if (!area.isActivo()) throw new IllegalArgumentException("No puede asociar el flujo a un área inactiva.");
        return area;
    }

    private void checkUnique(String name,Long id) {
        if (definitions.existsNormalizedName(name,id)) throw new FlujoConflictException("Ya existe un flujo con ese nombre.");
    }

    private static String validateName(String value) {
        if (value==null) throw new IllegalArgumentException("El nombre es obligatorio.");
        String name=value.trim();
        if (name.isBlank() || name.length()>150 || name.codePoints().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException("El nombre admite entre 1 y 150 caracteres, sin caracteres de control.");
        }
        return name;
    }

    private static String validateDescription(String value) {
        if (value==null) return null;
        if (value.length()>2000 || value.indexOf(0)>=0) throw new IllegalArgumentException("La descripción admite hasta 2000 caracteres, sin el carácter nulo.");
        return value.trim();
    }

    private static Long areaId(FlujoDefinicion flow) { return flow.getArea()==null?null:flow.getArea().getId(); }
    private static RbacException protectedFlow() { return RbacException.conflict("FLUJO_BASE_PROTEGIDO","La identidad y estructura del flujo base están protegidas."); }

    public FlujoResponse toResponse(FlujoDefinicion flow) {
        boolean manage=access.canManageFlow(areaId(flow));
        List<FlujoEtapaResponse> stages=flow.getEtapas().stream().sorted(Comparator.comparingInt(FlujoEtapa::getOrden))
                .map(e->{
                    UserAccount reviewer=manage?e.getRevisor():null;
                    String name=reviewer==null?null:((Objects.toString(reviewer.getFirstName(),"") + " " + Objects.toString(reviewer.getLastName(),"")).trim());
                    return new FlujoEtapaResponse(e.getId(),e.getOrden(),e.getNombre(),reviewer==null?null:reviewer.getId(),
                            reviewer==null?null:(name.isEmpty()?reviewer.getEmail():name),reviewer==null?null:reviewer.getEmail(),e.getTipoAccion(),
                            e.getTipoAsignacion(),manage && e.getRolRevisor()!=null?e.getRolRevisor().getId():null,
                            manage && e.getRolRevisor()!=null?e.getRolRevisor().getNombreVisible():null,
                            integrity.isBase(flow) || !reviewers.candidates(e).isEmpty(),
                            manage && !integrity.isBase(flow)?reviewers.candidates(e).size():null);
                }).toList();
        return new FlujoResponse(flow.getId(),flow.getNombre(),flow.getDescripcion(),areaId(flow),
                flow.getArea()==null?null:flow.getArea().getNombre(),flow.isActivo(),integrity.complete(flow),stages,
                flow.getCreatedAt(),flow.getUpdatedAt(),flow.getVersion(),
                manage && !Long.valueOf(1).equals(flow.getId()) && !requests.existsByFlujoDefinicion_Id(flow.getId()));
    }
}
