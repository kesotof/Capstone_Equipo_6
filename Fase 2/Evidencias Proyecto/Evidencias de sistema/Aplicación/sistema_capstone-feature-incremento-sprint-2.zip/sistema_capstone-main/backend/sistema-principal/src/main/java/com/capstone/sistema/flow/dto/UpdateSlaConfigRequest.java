package com.capstone.sistema.flow.dto;

import jakarta.validation.constraints.Min;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public record UpdateSlaConfigRequest(
        @Min(value = 1, message = "El plazo en días hábiles debe ser mayor o igual a 1")
        @JsonDeserialize(using = SlaDaysDeserializer.class)
        int plazoDias
) {}
