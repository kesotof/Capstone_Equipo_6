-- Reserva la identidad fija del catálogo base. Nunca renumera ni reemplaza flujos.
DO $base_flow_seed$
DECLARE
    inserted_rows integer;
BEGIN
    PERFORM pg_advisory_xact_lock(41021, 11);
    LOCK TABLE flujo_definicion IN SHARE ROW EXCLUSIVE MODE;
    INSERT INTO flujo_definicion (id, nombre, descripcion, activo, completo, version, created_at, updated_at)
    SELECT 1, 'Revisión Simple', 'Flujo de 1 etapa para revisión de documentos', true, true, 0,
           CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
    WHERE NOT EXISTS (SELECT 1 FROM flujo_definicion WHERE id = 1)
      AND NOT EXISTS (SELECT 1 FROM flujo_definicion WHERE lower(btrim(nombre)) = lower('Revisión Simple'))
    ON CONFLICT DO NOTHING;
    GET DIAGNOSTICS inserted_rows = ROW_COUNT;
    IF inserted_rows > 0 THEN
        -- No bajar la secuencia: conserva IDs consumidos por operaciones previas.
        PERFORM setval(pg_get_serial_sequence('flujo_definicion', 'id'),
            GREATEST((SELECT max(id) FROM flujo_definicion),
                     nextval(pg_get_serial_sequence('flujo_definicion', 'id'))), true);
    END IF;
END
$base_flow_seed$;
