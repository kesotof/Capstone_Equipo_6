package com.capstone.sistema.users.repository;

import com.capstone.sistema.users.model.RolFlujo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RolFlujoRepository extends JpaRepository<RolFlujo, Long> {

    Optional<RolFlujo> findByNombreIgnoreCase(String nombre);
}
