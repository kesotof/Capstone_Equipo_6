package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.NotificacionResponse;
import com.capstone.sistema.flow.model.Notificacion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.model.SolicitudTransicion;
import com.capstone.sistema.flow.model.TipoNotificacion;
import com.capstone.sistema.flow.repository.NotificacionRepository;
import com.capstone.sistema.flow.repository.TipoNotificacionRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.Instant;
import java.util.List;

@Service
public class NotificacionService {

    private static final Logger log = LoggerFactory.getLogger(NotificacionService.class);

    private final NotificacionRepository notificacionRepository;
    private final TipoNotificacionRepository tipoNotificacionRepository;
    private final org.springframework.amqp.rabbit.core.RabbitTemplate rabbitTemplate;
    private final RbacAccessService access;
    private final FlujoReviewerResolver reviewers;

    public NotificacionService(
            NotificacionRepository notificacionRepository,
            TipoNotificacionRepository tipoNotificacionRepository,
            org.springframework.amqp.rabbit.core.RabbitTemplate rabbitTemplate,
            RbacAccessService access,
            FlujoReviewerResolver reviewers
    ) {
        this.notificacionRepository = notificacionRepository;
        this.tipoNotificacionRepository = tipoNotificacionRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.access = access;
        this.reviewers = reviewers;
    }

    @Transactional
    public void notificarNuevaSolicitud(Solicitud solicitud, SolicitudTransicion transicion) {
        notificarNuevaSolicitud(solicitud, transicion, false);
    }

    @Transactional
    public void notificarNuevaSolicitud(Solicitud solicitud, SolicitudTransicion transicion, boolean notificarEmail) {
        TipoNotificacion tipo = getTipoNotificacion("NUEVA_SOLICITUD");
        String emisorNombre = getNombreCompleto(solicitud.getEmisor());

        List<UserAccount> destinatarios = responsablesActuales(solicitud);

        for (UserAccount destinatario : destinatarios) {
            String titulo = "Nueva solicitud pendiente de revisión";
            String mensaje = "El usuario " + emisorNombre + " ha registrado una nueva solicitud: '" + solicitud.getTitulo() + "'";
            Notificacion notif = new Notificacion(
                    destinatario,
                    solicitud,
                    transicion,
                    tipo,
                    titulo,
                    mensaje
            );
            notificacionRepository.save(notif);

            if (notificarEmail) {
                publishEmailEvent(
                        destinatario.getEmail(),
                        getNombreCompleto(destinatario),
                        "NUEVA_SOLICITUD",
                        titulo,
                        mensaje,
                        solicitud.getId(),
                        solicitud.getTitulo(),
                        emisorNombre
                );
            }
        }
        log.info("Notificaciones de NUEVA_SOLICITUD creadas para {} usuarios para solicitud {} (email={})",
                destinatarios.size(), solicitud.getId(), notificarEmail);
    }

    @Transactional
    public void notificarAprobacion(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor) {
        notificarAprobacion(solicitud, transicion, revisor, false);
    }

    @Transactional
    public void notificarAprobacion(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor, boolean notificarEmail) {
        if (!access.canRead(solicitud.getEmisor(), solicitud.getId())) return;
        TipoNotificacion tipo = getTipoNotificacion("APROBACION");
        String revisorNombre = getNombreCompleto(revisor);

        String titulo = "Solicitud Aprobada";
        String mensaje = "Tu solicitud '" + solicitud.getTitulo() + "' ha sido aprobada por " + revisorNombre + ".";
        Notificacion notif = new Notificacion(
                solicitud.getEmisor(),
                solicitud,
                transicion,
                tipo,
                titulo,
                mensaje
        );
        notificacionRepository.save(notif);

        if (notificarEmail) {
            publishEmailEvent(
                    solicitud.getEmisor().getEmail(),
                    getNombreCompleto(solicitud.getEmisor()),
                    "APROBACION",
                    titulo,
                    mensaje,
                    solicitud.getId(),
                    solicitud.getTitulo(),
                    revisorNombre
            );
        }
        log.info("Notificación de APROBACION creada para emisor {} en solicitud {} (email={})",
                solicitud.getEmisor().getEmail(), solicitud.getId(), notificarEmail);
    }

    @Transactional
    public void notificarRechazo(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor, String motivo) {
        notificarRechazo(solicitud, transicion, revisor, motivo, false);
    }

    @Transactional
    public void notificarRechazo(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor, String motivo, boolean notificarEmail) {
        if (!access.canRead(solicitud.getEmisor(), solicitud.getId())) return;
        TipoNotificacion tipo = getTipoNotificacion("RECHAZO");
        String revisorNombre = getNombreCompleto(revisor);

        String titulo = "Solicitud Rechazada";
        String mensaje = "Tu solicitud '" + solicitud.getTitulo() + "' ha sido rechazada por " + revisorNombre +
                ". Motivo: " + (motivo != null ? motivo : "Sin motivo especificado");
        Notificacion notif = new Notificacion(
                solicitud.getEmisor(),
                solicitud,
                transicion,
                tipo,
                titulo,
                mensaje
        );
        notificacionRepository.save(notif);

        if (notificarEmail) {
            publishEmailEvent(
                    solicitud.getEmisor().getEmail(),
                    getNombreCompleto(solicitud.getEmisor()),
                    "RECHAZO",
                    titulo,
                    mensaje,
                    solicitud.getId(),
                    solicitud.getTitulo(),
                    revisorNombre
            );
        }
        log.info("Notificación de RECHAZO creada para emisor {} en solicitud {} (email={})",
                solicitud.getEmisor().getEmail(), solicitud.getId(), notificarEmail);
    }

    @Transactional
    public void notificarCorreccionRequerida(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor, String observacion) {
        notificarCorreccionRequerida(solicitud, transicion, revisor, observacion, false);
    }

    @Transactional
    public void notificarCorreccionRequerida(Solicitud solicitud, SolicitudTransicion transicion, UserAccount revisor, String observacion, boolean notificarEmail) {
        if (!access.canRead(solicitud.getEmisor(), solicitud.getId())) return;
        TipoNotificacion tipo = getTipoNotificacion("CORRECCION_REQUERIDA");
        String revisorNombre = getNombreCompleto(revisor);

        String titulo = "Corrección Requerida";
        String mensaje = "El revisor " + revisorNombre + " ha solicitado correcciones para tu solicitud '" +
                solicitud.getTitulo() + "'. Observación: " + (observacion != null ? observacion : "");
        Notificacion notif = new Notificacion(
                solicitud.getEmisor(),
                solicitud,
                transicion,
                tipo,
                titulo,
                mensaje
        );
        notificacionRepository.save(notif);

        if (notificarEmail) {
            publishEmailEvent(
                    solicitud.getEmisor().getEmail(),
                    getNombreCompleto(solicitud.getEmisor()),
                    "CORRECCION_REQUERIDA",
                    titulo,
                    mensaje,
                    solicitud.getId(),
                    solicitud.getTitulo(),
                    revisorNombre
            );
        }
        log.info("Notificación de CORRECCION_REQUERIDA creada para emisor {} en solicitud {} (email={})",
                solicitud.getEmisor().getEmail(), solicitud.getId(), notificarEmail);
    }

    @Transactional
    public void notificarReenvio(Solicitud solicitud, SolicitudTransicion transicion) {
        notificarReenvio(solicitud, transicion, false);
    }

    @Transactional
    public void notificarReenvio(Solicitud solicitud, SolicitudTransicion transicion, boolean notificarEmail) {
        TipoNotificacion tipo = getTipoNotificacion("REENVIO");
        String emisorNombre = getNombreCompleto(solicitud.getEmisor());

        List<UserAccount> destinatarios = responsablesActuales(solicitud);

        for (UserAccount destinatario : destinatarios) {
            String titulo = "Solicitud Corregida Reenviada";
            String mensaje = "El emisor " + emisorNombre + " ha corregido y reenviado la solicitud: '" + solicitud.getTitulo() + "'";
            Notificacion notif = new Notificacion(
                    destinatario,
                    solicitud,
                    transicion,
                    tipo,
                    titulo,
                    mensaje
            );
            notificacionRepository.save(notif);

            if (notificarEmail) {
                publishEmailEvent(
                        destinatario.getEmail(),
                        getNombreCompleto(destinatario),
                        "REENVIO",
                        titulo,
                        mensaje,
                        solicitud.getId(),
                        solicitud.getTitulo(),
                        emisorNombre
                );
            }
        }
        log.info("Notificaciones de REENVIO creadas para {} revisores para solicitud {} (email={})",
                destinatarios.size(), solicitud.getId(), notificarEmail);
    }

    private void publishEmailEvent(
            String recipientEmail,
            String recipientName,
            String notificationType,
            String subject,
            String body,
            java.util.UUID solicitudId,
            String solicitudTitulo,
            String actorName
    ) {
        try {
            java.util.Map<String, Object> event = new java.util.HashMap<>();
            event.put("notificationType", notificationType);
            event.put("recipientEmail", recipientEmail);
            event.put("recipientName", recipientName != null ? recipientName : "");
            event.put("subject", subject);
            event.put("body", body);
            event.put("solicitudId", solicitudId != null ? solicitudId.toString() : "");
            event.put("solicitudTitulo", solicitudTitulo != null ? solicitudTitulo : "");
            event.put("actorName", actorName != null ? actorName : "");
            event.put("timestamp", Instant.now().toString());

            if (!TransactionSynchronizationManager.isSynchronizationActive()) {
                throw new IllegalStateException("La publicación de correo requiere una transacción activa.");
            }
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    try {
                        rabbitTemplate.convertAndSend(com.capstone.sistema.flow.RabbitConfig.EXCHANGE_NAME,
                                com.capstone.sistema.flow.RabbitConfig.EMAIL_ROUTING_KEY,event);
                        log.debug("Evento de email publicado tras commit ({})",notificationType);
                    } catch (Exception ex) {
                        log.warn("No fue posible publicar el correo de la solicitud {} tras commit: {}",solicitudId,ex.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            log.warn("No fue posible publicar evento de email a RabbitMQ para {}: {}", recipientEmail, e.getMessage());
        }
    }

    private List<UserAccount> responsablesActuales(Solicitud solicitud) {
        return reviewers.forRequest(solicitud,solicitud.getFlujoEtapa());
    }

    @Transactional
    public void notificarReasignacion(Solicitud request, java.util.Set<java.util.UUID> previousRecipients) {
        String title="Revisión asignada a tu responsabilidad";
        String message="La solicitud '"+request.getTitulo()+"' está pendiente en la etapa '"+request.getFlujoEtapa().getNombre()+"'.";
        TipoNotificacion type=getTipoNotificacion("NUEVA_SOLICITUD");
        for (UserAccount recipient:responsablesActuales(request)) {
            if (previousRecipients.contains(recipient.getId())) continue;
            notificacionRepository.save(new Notificacion(recipient,request,null,type,title,message));
            publishEmailEvent(recipient.getEmail(),getNombreCompleto(recipient),"NUEVA_SOLICITUD",title,message,
                    request.getId(),request.getTitulo(),"Administración de flujos");
        }
    }

    @Transactional
    public void notificarSiguienteEtapa(Solicitud solicitud, SolicitudTransicion transicion, UserAccount actor, boolean email) {
        String title="Solicitud pendiente en la siguiente etapa";
        String message="La solicitud '" + solicitud.getTitulo() + "' avanzó a la etapa '" + solicitud.getFlujoEtapa().getNombre() + "' y requiere revisión.";
        TipoNotificacion type=getTipoNotificacion("NUEVA_SOLICITUD");
        for (UserAccount recipient:responsablesActuales(solicitud)) {
            notificacionRepository.save(new Notificacion(recipient,solicitud,transicion,type,title,message));
            if (email) publishEmailEvent(recipient.getEmail(),getNombreCompleto(recipient),"NUEVA_SOLICITUD",title,message,
                    solicitud.getId(),solicitud.getTitulo(),getNombreCompleto(actor));
        }
    }

    @Transactional(readOnly = true)
    public List<NotificacionResponse> listarMisNotificaciones(UserAccount user) {
        return notificacionRepository.findByDestinatario_IdOrderByCreatedEnDesc(user.getId())
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public long contarNoLeidas(UserAccount user) {
        return notificacionRepository.countByDestinatario_IdAndLeidaFalse(user.getId());
    }

    @Transactional
    public NotificacionResponse marcarComoLeida(Long notificacionId, UserAccount user) {
        Notificacion notificacion = notificacionRepository.findById(notificacionId)
                .orElseThrow(() -> new IllegalArgumentException("Notificación no encontrada: " + notificacionId));

        if (!notificacion.getDestinatario().getId().equals(user.getId())) {
            throw new org.springframework.security.access.AccessDeniedException("No tienes permiso para marcar esta notificación");
        }

        notificacion.setLeida(true);
        notificacionRepository.save(notificacion);
        return toDto(notificacion);
    }

    @Transactional
    public int marcarTodasComoLeidas(UserAccount user) {
        List<Notificacion> noLeidas = notificacionRepository.findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(user.getId());
        for (Notificacion n : noLeidas) {
            n.setLeida(true);
        }
        notificacionRepository.saveAll(noLeidas);
        log.info("Marcadas como leídas {} notificaciones para usuario {}", noLeidas.size(), user.getEmail());
        return noLeidas.size();
    }

    private NotificacionResponse toDto(Notificacion n) {
        return new NotificacionResponse(
                n.getId(),
                n.getTitulo(),
                n.getMensaje(),
                n.getTipoNotificacion().getTipo(),
                n.getSolicitud() != null ? n.getSolicitud().getId() : null,
                n.isLeida(),
                n.getCreatedEn(),
                n.getLeidaEn()
        );
    }

    private TipoNotificacion getTipoNotificacion(String codigo) {
        return tipoNotificacionRepository.findByTipoIgnoreCase(codigo)
                .orElseGet(() -> tipoNotificacionRepository.save(new TipoNotificacion(codigo)));
    }

    private String getNombreCompleto(UserAccount user) {
        if (user == null) {
            return "Usuario";
        }
        String nombre = user.getFirstName() != null ? user.getFirstName() : "";
        String apellido = user.getLastName() != null ? user.getLastName() : "";
        String full = (nombre + " " + apellido).trim();
        return full.isEmpty() ? user.getEmail() : full;
    }
}
