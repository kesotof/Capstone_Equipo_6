package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.exception.DocumentSearchException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Component
public class DocumentSearchQueryNormalizer {
    public static final List<String> STATUSES = List.of("PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO");
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("America/Santiago");
    private static final Set<String> PARAMETERS = Set.of("query", "documentType", "status", "areaId", "dateFrom", "dateTo", "page", "size", "sort");
    private static final Set<String> SORT_FIELDS = Set.of("createdAt", "updatedAt", "titulo", "correlativo");

    public DocumentSearchCriteria normalize(Map<String, List<String>> parameters) {
        if (!PARAMETERS.containsAll(parameters.keySet())) {
            throw DocumentSearchException.invalid("La búsqueda contiene un parámetro no admitido.");
        }
        if (parameters.values().stream().anyMatch(values -> values == null || values.size() != 1)) {
            throw DocumentSearchException.invalid("Cada parámetro de búsqueda debe enviarse una sola vez.");
        }
        String query = value(parameters, "query", 200);
        String type = uppercase(value(parameters, "documentType", 36));
        if (type != null && !type.matches("[A-Z0-9][A-Z0-9_-]{0,35}")) {
            throw DocumentSearchException.invalid("documentType debe ser un código de formato válido.");
        }
        String status = uppercase(value(parameters, "status", 36));
        if (status != null && !STATUSES.contains(status)) {
            throw DocumentSearchException.invalid("status no corresponde a un estado documental permitido.");
        }
        Long area = number(value(parameters, "areaId", 20), "areaId", 1, Long.MAX_VALUE, null);
        int page = number(value(parameters, "page", 10), "page", 0, Integer.MAX_VALUE, 0L).intValue();
        int size = number(value(parameters, "size", 3), "size", 1, 100, 10L).intValue();
        if ((long) page * size > Integer.MAX_VALUE) {
            throw DocumentSearchException.invalid("El desplazamiento de page y size excede el máximo permitido.");
        }
        DateBoundary from = date(value(parameters, "dateFrom", 64), "dateFrom", false);
        DateBoundary to = date(value(parameters, "dateTo", 64), "dateTo", true);
        if (from != null && to != null && (from.instant().isAfter(to.instant())
                || (to.exclusive() && from.instant().equals(to.instant())))) {
            throw DocumentSearchException.invalid("dateFrom debe ser anterior o igual al límite de dateTo.");
        }
        String sort = value(parameters, "sort", 40);
        String[] order = (sort == null ? "createdAt,desc" : sort).split(",", -1);
        if (order.length != 2 || !SORT_FIELDS.contains(order[0].trim())
                || !("asc".equalsIgnoreCase(order[1].trim()) || "desc".equalsIgnoreCase(order[1].trim()))) {
            throw DocumentSearchException.invalid("sort debe indicar un campo permitido y la dirección asc o desc.");
        }
        return new DocumentSearchCriteria(query, type, status, area,
                from == null ? null : from.instant(), to == null ? null : to.instant(), to != null && to.exclusive(),
                page, size, order[0].trim(), Sort.Direction.fromString(order[1].trim()));
    }

    private String value(Map<String, List<String>> parameters, String name, int maxLength) {
        List<String> values = parameters.get(name);
        if (values == null) return null;
        String raw = values.getFirst();
        if (raw == null) return null;
        if (raw.codePoints().anyMatch(Character::isISOControl)) {
            throw DocumentSearchException.invalid(name + " contiene caracteres de control no admitidos.");
        }
        String trimmed = raw.strip();
        if (trimmed.length() > maxLength) {
            throw DocumentSearchException.invalid(name + " supera la longitud máxima de " + maxLength + " caracteres.");
        }
        return trimmed.isEmpty() ? null : trimmed;
    }

    private Long number(String value, String field, long min, long max, Long defaultValue) {
        if (value == null) return defaultValue;
        try {
            if (!value.matches("[0-9]+")) throw new NumberFormatException();
            long parsed = Long.parseLong(value);
            if (parsed < min || parsed > max) throw new NumberFormatException();
            return parsed;
        } catch (NumberFormatException ex) {
            throw DocumentSearchException.invalid(field + " debe ser un entero entre " + min + " y " + max + ".");
        }
    }

    private DateBoundary date(String value, String field, boolean upper) {
        if (value == null) return null;
        try {
            if (value.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
                LocalDate date = LocalDate.parse(value);
                requireYear(date.getYear());
                return new DateBoundary((upper ? date.plusDays(1) : date).atStartOfDay(BUSINESS_ZONE).toInstant(), upper);
            }
            OffsetDateTime date = OffsetDateTime.parse(value);
            requireYear(date.getYear());
            return new DateBoundary(date.toInstant(), false);
        } catch (DateTimeException ex) {
            throw DocumentSearchException.invalid(field + " debe ser una fecha yyyy-MM-dd o una fecha y hora ISO 8601 con zona u offset, entre los años 0001 y 9999.");
        }
    }

    private void requireYear(int year) {
        if (year < 1 || year > 9999) throw new DateTimeException("Año fuera de rango");
    }

    private String uppercase(String value) {
        return value == null ? null : value.toUpperCase(Locale.ROOT);
    }

    private record DateBoundary(Instant instant, boolean exclusive) { }
}
