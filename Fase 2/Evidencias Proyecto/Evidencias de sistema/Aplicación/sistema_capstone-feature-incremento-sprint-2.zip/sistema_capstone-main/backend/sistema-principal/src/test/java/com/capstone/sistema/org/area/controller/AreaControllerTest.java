package com.capstone.sistema.org.area.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.PaginaAreasResponse;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.exception.AreaExceptionHandler;
import com.capstone.sistema.org.area.service.AreaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AreaController.class)
@Import({SecurityConfig.class, AreaExceptionHandler.class})
class AreaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AreaService areaService;

    @MockBean
    private com.capstone.sistema.users.repository.AreaRepository areaRepository;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    @DisplayName("Admin actualiza área asignando administrador responsable y recibe 200 OK")
    void updateArea_assignAdmin_returnsOk200() throws Exception {
        Long areaId = 2L;
        UUID adminId = UUID.randomUUID();
        UpdateAreaRequest request = new UpdateAreaRequest("Finanzas", "Área contable", null, adminId, 0L);

        AreaResponse response = new AreaResponse(
                areaId,
                "Finanzas",
                "Área contable",
                true,
                null,
                null,
                adminId,
                "Pedro Picapiedra",
                "pedro@empresa.cl",
                Instant.now(),
                Instant.now(),
                1L
        );

        when(areaService.update(eq(areaId), any(UpdateAreaRequest.class))).thenReturn(response);

        mockMvc.perform(put("/api/areas/" + areaId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(areaId))
                .andExpect(jsonPath("$.administradorId").value(adminId.toString()))
                .andExpect(jsonPath("$.administradorNombre").value("Pedro Picapiedra"))
                .andExpect(jsonPath("$.administradorEmail").value("pedro@empresa.cl"));

        verify(areaService).update(eq(areaId), any(UpdateAreaRequest.class));
    }

    @Test
    @DisplayName("GET /api/areas incluye datos del administrador responsable en la lista")
    void getAreas_includesAdminInfo_returnsOk200() throws Exception {
        UUID adminId = UUID.randomUUID();
        AreaResponse area1 = new AreaResponse(
                1L, "General", "Área central", true, null, null,
                null, null, null, Instant.now(), Instant.now(), 0L
        );
        AreaResponse area2 = new AreaResponse(
                2L, "Finanzas", "Área contable", true, null, null,
                adminId, "Pedro Picapiedra", "pedro@empresa.cl", Instant.now(), Instant.now(), 1L
        );

        PaginaAreasResponse pagina = new PaginaAreasResponse(
                List.of(area1, area2), 0, 20, 2L, 1, true, true
        );

        when(areaService.list(0, 20, null, null)).thenReturn(pagina);

        mockMvc.perform(get("/api/areas")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].nombre").value("General"))
                .andExpect(jsonPath("$.contenido[0].administradorId").doesNotExist())
                .andExpect(jsonPath("$.contenido[1].nombre").value("Finanzas"))
                .andExpect(jsonPath("$.contenido[1].administradorId").value(adminId.toString()))
                .andExpect(jsonPath("$.contenido[1].administradorNombre").value("Pedro Picapiedra"))
                .andExpect(jsonPath("$.contenido[1].administradorEmail").value("pedro@empresa.cl"));
    }
}
