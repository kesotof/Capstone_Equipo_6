package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Transicion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface TransicionRepository extends JpaRepository<Transicion, Long> {

    @Query("SELECT t FROM Transicion t WHERE t.flujoDefinicion.id = :flujoId " +
           "AND t.estadoOrigen IS NULL " +
           "AND UPPER(t.accionUsuario.accion) = UPPER(:accion)")
    Optional<Transicion> findInitialTransition(
            @Param("flujoId") Long flujoId,
            @Param("accion") String accion
    );

    @Query("SELECT t FROM Transicion t WHERE t.flujoDefinicion.id = :flujoId " +
           "AND UPPER(t.estadoOrigen.codigo) = UPPER(:estadoOrigen) " +
           "AND UPPER(t.accionUsuario.accion) = UPPER(:accion)")
    Optional<Transicion> findByFlujoAndEstadoOrigenAndAccion(
            @Param("flujoId") Long flujoId,
            @Param("estadoOrigen") String estadoOrigen,
            @Param("accion") String accion
    );
}
