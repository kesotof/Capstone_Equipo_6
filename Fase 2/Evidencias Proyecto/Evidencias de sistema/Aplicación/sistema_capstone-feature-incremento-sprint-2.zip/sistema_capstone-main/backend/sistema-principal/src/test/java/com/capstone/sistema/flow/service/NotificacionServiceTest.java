package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.NotificacionResponse;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.NotificacionRepository;
import com.capstone.sistema.flow.repository.TipoNotificacionRepository;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private TipoNotificacionRepository tipoNotificacionRepository;
    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private org.springframework.amqp.rabbit.core.RabbitTemplate rabbitTemplate;

    private NotificacionService notificacionService;

    private UserAccount emisor;
    private UserAccount revisor;
    private Solicitud solicitud;
    private SolicitudTransicion transicion;

    @BeforeEach
    void setUp() {
        notificacionService = new NotificacionService(
                notificacionRepository,
                tipoNotificacionRepository,
                userAccountRepository,
                rabbitTemplate
        );

        emisor = new UserAccount("kc-1", "emisor@test.local", "Juan", "Emisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(emisor, "id", UUID.randomUUID());

        revisor = new UserAccount("kc-2", "revisor@test.local", "Ana", "Revisora", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(revisor, "id", UUID.randomUUID());

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc");
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        EstadoSolicitud estado = new EstadoSolicitud(1L, "PENDIENTE_REVISION");

        solicitud = new Solicitud(flujo, emisor, "Documento Prueba", "Desc", estado, etapa);
        ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());

        transicion = new SolicitudTransicion(
                solicitud, null, null, estado, new AccionUsuario("CREAR"), emisor, "Crear", "{}"
        );
    }

    @Test
    void testNotificarNuevaSolicitud_CreatesNotificationsForOtherActiveUsers() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("NUEVA_SOLICITUD"))
                .thenReturn(Optional.of(new TipoNotificacion("NUEVA_SOLICITUD")));
        when(userAccountRepository.findAll()).thenReturn(List.of(emisor, revisor));

        notificacionService.notificarNuevaSolicitud(solicitud, transicion);

        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificacionRepository, times(1)).save(captor.capture());

        Notificacion saved = captor.getValue();
        assertThat(saved.getDestinatario().getEmail()).isEqualTo("revisor@test.local");
        assertThat(saved.getTitulo()).contains("Nueva solicitud");
        assertThat(saved.getMensaje()).contains("Juan Emisor");
    }

    @Test
    void testNotificarAprobacion_CreatesNotificationForEmisor() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("APROBACION"))
                .thenReturn(Optional.of(new TipoNotificacion("APROBACION")));

        notificacionService.notificarAprobacion(solicitud, transicion, revisor);

        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificacionRepository).save(captor.capture());

        Notificacion saved = captor.getValue();
        assertThat(saved.getDestinatario().getEmail()).isEqualTo("emisor@test.local");
        assertThat(saved.getTitulo()).isEqualTo("Solicitud Aprobada");
        assertThat(saved.getMensaje()).contains("Ana Revisora");
    }

    @Test
    void testNotificarAprobacion_WithEmailTrue_PublishesRabbitMessage() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("APROBACION"))
                .thenReturn(Optional.of(new TipoNotificacion("APROBACION")));

        notificacionService.notificarAprobacion(solicitud, transicion, revisor, true);

        verify(notificacionRepository).save(any(Notificacion.class));
        verify(rabbitTemplate, times(1)).convertAndSend(
                eq(com.capstone.sistema.flow.RabbitConfig.EXCHANGE_NAME),
                eq(com.capstone.sistema.flow.RabbitConfig.EMAIL_ROUTING_KEY),
                any(java.util.Map.class)
        );
    }

    @Test
    void testNotificarAprobacion_WithEmailFalse_DoesNotPublishRabbitMessage() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("APROBACION"))
                .thenReturn(Optional.of(new TipoNotificacion("APROBACION")));

        notificacionService.notificarAprobacion(solicitud, transicion, revisor, false);

        verify(notificacionRepository).save(any(Notificacion.class));
        verifyNoInteractions(rabbitTemplate);
    }

    @Test
    void testMarcarComoLeida_Success() {
        TipoNotificacion tipo = new TipoNotificacion("APROBACION");
        Notificacion notif = new Notificacion(emisor, solicitud, transicion, tipo, "Titulo", "Mensaje");
        ReflectionTestUtils.setField(notif, "id", 100L);

        when(notificacionRepository.findById(100L)).thenReturn(Optional.of(notif));
        when(notificacionRepository.save(any(Notificacion.class))).thenAnswer(i -> i.getArgument(0));

        NotificacionResponse res = notificacionService.marcarComoLeida(100L, emisor);

        assertThat(res.leida()).isTrue();
        assertThat(notif.isLeida()).isTrue();
        assertThat(notif.getLeidaEn()).isNotNull();
    }

    @Test
    void testContarNoLeidas() {
        when(notificacionRepository.countByDestinatario_IdAndLeidaFalse(emisor.getId())).thenReturn(3L);

        long count = notificacionService.contarNoLeidas(emisor);
        assertThat(count).isEqualTo(3L);
    }

    @Test
    void testNotificarCorreccionRequerida_PersisteInmediatamenteParaEmisor() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("CORRECCION_REQUERIDA"))
                .thenReturn(Optional.of(new TipoNotificacion("CORRECCION_REQUERIDA")));

        notificacionService.notificarCorreccionRequerida(solicitud, transicion, revisor, "Corregir pie de firma");

        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificacionRepository).save(captor.capture());

        Notificacion saved = captor.getValue();
        assertThat(saved.getDestinatario().getEmail()).isEqualTo("emisor@test.local");
        assertThat(saved.getTitulo()).isEqualTo("Corrección Requerida");
        assertThat(saved.getMensaje()).contains("Corregir pie de firma");
        assertThat(saved.isLeida()).isFalse();
        assertThat(saved.getSolicitud().getId()).isEqualTo(solicitud.getId());
    }

    @Test
    void testNotificarRechazo_PersisteInmediatamenteParaEmisor() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("RECHAZO"))
                .thenReturn(Optional.of(new TipoNotificacion("RECHAZO")));

        notificacionService.notificarRechazo(solicitud, transicion, revisor, "No cumple con requisitos");

        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificacionRepository).save(captor.capture());

        Notificacion saved = captor.getValue();
        assertThat(saved.getDestinatario().getEmail()).isEqualTo("emisor@test.local");
        assertThat(saved.getTitulo()).isEqualTo("Solicitud Rechazada");
        assertThat(saved.getMensaje()).contains("No cumple con requisitos");
        assertThat(saved.isLeida()).isFalse();
    }

    @Test
    void testNotificarReenvio_PersisteInmediatamenteParaOtrosUsuarios() {
        when(tipoNotificacionRepository.findByTipoIgnoreCase("REENVIO"))
                .thenReturn(Optional.of(new TipoNotificacion("REENVIO")));
        when(userAccountRepository.findAll()).thenReturn(List.of(emisor, revisor));

        notificacionService.notificarReenvio(solicitud, transicion);

        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificacionRepository).save(captor.capture());

        Notificacion saved = captor.getValue();
        assertThat(saved.getDestinatario().getEmail()).isEqualTo("revisor@test.local");
        assertThat(saved.getTitulo()).contains("Solicitud Corregida Reenviada");
        assertThat(saved.isLeida()).isFalse();
    }

    @Test
    void testMarcarComoLeida_UsuarioNoEsDestinatario_LanzaAccessDeniedException() {
        TipoNotificacion tipo = new TipoNotificacion("APROBACION");
        Notificacion notif = new Notificacion(emisor, solicitud, transicion, tipo, "Titulo", "Mensaje");
        ReflectionTestUtils.setField(notif, "id", 101L);

        when(notificacionRepository.findById(101L)).thenReturn(Optional.of(notif));

        org.junit.jupiter.api.Assertions.assertThrows(
                org.springframework.security.access.AccessDeniedException.class,
                () -> notificacionService.marcarComoLeida(101L, revisor)
        );
        verify(notificacionRepository, never()).save(any());
    }

    @Test
    void testMarcarTodasComoLeidas_ActualizaTodasANoLeidas() {
        TipoNotificacion tipo = new TipoNotificacion("APROBACION");
        Notificacion n1 = new Notificacion(emisor, solicitud, transicion, tipo, "T1", "M1");
        Notificacion n2 = new Notificacion(emisor, solicitud, transicion, tipo, "T2", "M2");
        when(notificacionRepository.findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(emisor.getId()))
                .thenReturn(List.of(n1, n2));

        int actualizadas = notificacionService.marcarTodasComoLeidas(emisor);

        assertThat(actualizadas).isEqualTo(2);
        assertThat(n1.isLeida()).isTrue();
        assertThat(n2.isLeida()).isTrue();
        verify(notificacionRepository).saveAll(List.of(n1, n2));
    }
}
