package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record EventoDetalleResponse(
        Long id,
        String estadoOrigen,
        String estadoDestino,
        String accion,
        String usuarioNombre,
        String comentario,
        boolean comentarioVisible,
        Boolean dentroSla,
        Instant createdAt,
        EtapaSolicitudResponse etapaOrigen,
        EtapaSolicitudResponse etapaDestino
) {
}
