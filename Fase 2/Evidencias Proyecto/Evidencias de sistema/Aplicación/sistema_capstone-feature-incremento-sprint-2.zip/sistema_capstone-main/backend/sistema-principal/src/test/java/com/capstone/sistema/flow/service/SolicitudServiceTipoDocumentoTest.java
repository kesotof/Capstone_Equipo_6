package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.dto.CrearSolicitudResponse;
import com.capstone.sistema.flow.dto.SolicitudResponse;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.time.Clock;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@org.mockito.junit.jupiter.MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
class SolicitudServiceTipoDocumentoTest {

    @Mock
    private SolicitudRepository solicitudRepository;
    @Mock
    private DocumentoRepository documentoRepository;
    @Mock
    private FormatoDocumentoRepository formatoDocumentoRepository;
    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;
    @Mock
    private FlujoEtapaRepository flujoEtapaRepository;
    @Mock
    private EstadoSolicitudRepository estadoSolicitudRepository;
    @Mock
    private AccionUsuarioRepository accionUsuarioRepository;
    @Mock
    private SolicitudTransicionRepository solicitudTransicionRepository;
    @Mock
    private ObservacionRepository observacionRepository;
    @Mock
    private MinioStorageService storageService;
    @Mock
    private NotificacionService notificacionService;
    @Mock
    private AuditService auditService;
    @Mock
    private CurrentUserResolver currentUserResolver;
    @Mock
    private SlaService slaService;
    @Mock
    private AreaRepository areaRepository;
    @Mock
    private RbacAccessService rbac;
    @Mock
    private RbacManagementService rbacManagement;
    @Mock
    private FlujoConcurrencyService concurrency;
    @Mock
    private FlujoIntegrityService integrity;

    private SolicitudService solicitudService;

    private UserAccount emisor;
    private FlujoDefinicion flujoDef;
    private FlujoEtapa etapa;
    private EstadoSolicitud estadoPendiente;
    private AccionUsuario accionCrear;

    @BeforeEach
    void setUp() throws Exception {
        solicitudService = new SolicitudService(
                solicitudRepository,
                documentoRepository,
                formatoDocumentoRepository,
                flujoDefinicionRepository,
                flujoEtapaRepository,
                estadoSolicitudRepository,
                accionUsuarioRepository,
                solicitudTransicionRepository,
                observacionRepository,
                storageService,
                notificacionService,
                auditService,
                currentUserResolver,
                slaService,
                areaRepository,
                rbac,
                rbacManagement,
                concurrency,
                integrity,
                Clock.fixed(Instant.parse("2026-10-09T13:00:00Z"), ZoneOffset.UTC)
        );

        emisor = new UserAccount("kc-emisor", "emisor@test.local", "Juan", "Emisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(emisor, "id", UUID.randomUUID());
        emisor.setArea(new Area(1L, "Operaciones", true));

        flujoDef = new FlujoDefinicion("Revisión Simple", "Flujo base");
        ReflectionTestUtils.setField(flujoDef, "id", 1L);

        etapa = new FlujoEtapa(flujoDef, 1, "Revisión");
        ReflectionTestUtils.setField(etapa, "id", 1L);

        estadoPendiente = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        accionCrear = new AccionUsuario(1L, "CREAR");

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(formatoDocumentoRepository.findByTipoIgnoreCase("pdf")).thenReturn(Optional.of(new FormatoDocumento(1L, "pdf")));
        when(concurrency.lockDefinition(anyLong())).thenReturn(flujoDef);
        when(integrity.isBase(flujoDef)).thenReturn(true);
        when(integrity.orderedStages(flujoDef)).thenReturn(List.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("CREAR")).thenReturn(Optional.of(accionCrear));
        when(storageService.uploadFile(any())).thenReturn("archivo_subido.pdf");

        when(solicitudRepository.saveAndFlush(any(Solicitud.class))).thenAnswer(i -> {
            Solicitud s = i.getArgument(0);
            ReflectionTestUtils.setField(s, "id", UUID.randomUUID());
            return s;
        });
        when(documentoRepository.save(any(Documento.class))).thenAnswer(i -> {
            Documento d = i.getArgument(0);
            ReflectionTestUtils.setField(d, "id", UUID.randomUUID());
            return d;
        });
    }

    @Test
    void crearSolicitud_ConTipoDocumentoExplicito_GuardaTipoYCalculaSlaExacto() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "contrato.pdf", "application/pdf", "Contenido contrato".getBytes()
        );
        Instant deadlineEsperado = Instant.parse("2026-10-10T12:00:00Z");
        when(slaService.calculateDeadline(eq("Contrato"), eq("Contrato de Servicios"), any(Instant.class)))
                .thenReturn(deadlineEsperado);

        CrearSolicitudResponse response = solicitudService.crearSolicitud(
                "Contrato de Servicios", "Descripción", file, false, "Contrato"
        );

        assertThat(response).isNotNull();
        assertThat(response.solicitudId()).isNotNull();

        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository).saveAndFlush(captor.capture());
        Solicitud guardada = captor.getValue();

        assertThat(guardada.getTipoDocumento()).isEqualTo("Contrato");
        assertThat(guardada.getDeadline()).isEqualTo(deadlineEsperado);
        assertThat(guardada.getCorrelativo()).startsWith("CONT-");
        verify(slaService).calculateDeadline(eq("Contrato"), eq("Contrato de Servicios"), any(Instant.class));
    }

    @Test
    void crearSolicitud_SinTipoDocumento_AplicaDefaultGeneral() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido informe".getBytes()
        );
        Instant deadlineEsperado = Instant.parse("2026-10-08T12:00:00Z");
        when(slaService.calculateDeadline(eq("General"), eq("Informe Financiero"), any(Instant.class)))
                .thenReturn(deadlineEsperado);

        CrearSolicitudResponse response = solicitudService.crearSolicitud(
                "Informe Financiero", "Descripción", file
        );

        assertThat(response).isNotNull();

        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository).saveAndFlush(captor.capture());
        Solicitud guardada = captor.getValue();

        assertThat(guardada.getTipoDocumento()).isEqualTo("General");
        assertThat(guardada.getDeadline()).isEqualTo(deadlineEsperado);
        assertThat(guardada.getCorrelativo()).startsWith("DOC-");
        verify(slaService).calculateDeadline(eq("General"), eq("Informe Financiero"), any(Instant.class));
    }

    @Test
    void crearSolicitud_ConTipoDocumentoEspaciosBlanco_NormalizaAGeneral() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "doc.pdf", "application/pdf", "Contenido".getBytes()
        );

        solicitudService.crearSolicitud("Doc Genérico", "Desc", file, false, "   ");

        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository).saveAndFlush(captor.capture());
        Solicitud guardada = captor.getValue();

        assertThat(guardada.getTipoDocumento()).isEqualTo("General");
        assertThat(guardada.getCorrelativo()).startsWith("DOC-");
        verify(slaService).calculateDeadline(eq("General"), eq("Doc Genérico"), any(Instant.class));
    }

    @Test
    void crearSolicitud_ConFlujoEspecificoYTipoDocumento_UtilizaAmbos() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "anexo.pdf", "application/pdf", "Contenido".getBytes()
        );

        solicitudService.crearSolicitud("Factura Proveedor", "Desc", file, false, 2L, "Factura");

        ArgumentCaptor<Solicitud> captor = ArgumentCaptor.forClass(Solicitud.class);
        verify(solicitudRepository).saveAndFlush(captor.capture());
        Solicitud guardada = captor.getValue();

        assertThat(guardada.getTipoDocumento()).isEqualTo("Factura");
        assertThat(guardada.getCorrelativo()).startsWith("FAC-");
        verify(concurrency).lockDefinition(2L);
        verify(slaService).calculateDeadline(eq("Factura"), eq("Factura Proveedor"), any(Instant.class));
    }

    @Test
    void obtenerDetalle_RetornaTipoDocumentoEnResponse() {
        UUID solId = UUID.randomUUID();
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Factura Mayo", "Desc", estadoPendiente, etapa);
        solicitud.setTipoDocumento("Factura");
        solicitud.setCorrelativo("FACT-001");
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(rbac.readable(solId)).thenReturn(solicitud);

        SolicitudResponse response = solicitudService.obtenerDetalle(solId);

        assertThat(response).isNotNull();
        assertThat(response.tipoDocumento()).isEqualTo("Factura");
        assertThat(response.correlativo()).isEqualTo("FACT-001");
        assertThat(response.titulo()).isEqualTo("Factura Mayo");
    }

    @Test
    void crearSolicitud_comparteInstanteDeRegistroCalculoEHistorial() {
        Instant registeredAt = Instant.parse("2026-10-09T13:00:00Z");
        when(slaService.calculateDeadline("Contrato", "Contrato nuevo", registeredAt))
                .thenReturn(Instant.parse("2026-10-16T13:00:00Z"));
        MockMultipartFile file = new MockMultipartFile("file", "contrato.pdf", "application/pdf", new byte[]{1});
        solicitudService.crearSolicitud("Contrato nuevo", "Antecedentes", file, false, "Contrato");
        ArgumentCaptor<Solicitud> request = ArgumentCaptor.forClass(Solicitud.class);
        ArgumentCaptor<SolicitudTransicion> event = ArgumentCaptor.forClass(SolicitudTransicion.class);
        verify(solicitudRepository).saveAndFlush(request.capture());
        verify(solicitudTransicionRepository).save(event.capture());
        assertThat(request.getValue().getCreatedAt()).isEqualTo(registeredAt);
        assertThat(event.getValue().getCreatedAt()).isEqualTo(registeredAt);
        assertThat(event.getValue().getDentroSla()).isNull();
        verify(slaService).calculateDeadline("Contrato", "Contrato nuevo", registeredAt);
    }

    @Test
    void crearSolicitud_tipoDemasiadoLargo_rechazaAntesDePersistir() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "doc.pdf", "application/pdf", new byte[]{1});
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> solicitudService.crearSolicitud(
                "Documento", "Antecedentes", file, false, "x".repeat(101)))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("100 caracteres");
        verify(solicitudRepository, never()).saveAndFlush(any());
        verify(storageService, never()).uploadFile(any());
    }
}
