package com.capstone.sistema.users.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Set;

@Configuration
public class PasswordChangeWebConfig {
    @Bean
    public FilterRegistrationBean<OncePerRequestFilter> passwordChangeHeaders() {
        Set<String> paths = Set.of("/api/auth/password-policy", "/api/auth/change-password", "/api/users/me/change-password");
        var registration = new FilterRegistrationBean<OncePerRequestFilter>();
        registration.setFilter(new OncePerRequestFilter() {
            @Override protected boolean shouldNotFilter(HttpServletRequest request) {
                return !paths.contains(request.getRequestURI().substring(request.getContextPath().length()));
            }
            @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                    throws ServletException, IOException {
                response.setHeader("Cache-Control", "no-store");
                response.setHeader("X-Content-Type-Options", "nosniff");
                chain.doFilter(request, response);
            }
        });
        registration.setName("passwordChangeHeaders");
        registration.setUrlPatterns(List.of("/api/auth/*", "/api/users/me/*"));
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 22);
        return registration;
    }
}
