package com.capstone.sistema.flow.service;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.dto.AreaDetalleResponse;
import com.capstone.sistema.flow.dto.DocumentoDetalleResponse;
import com.capstone.sistema.flow.dto.EtapaSolicitudResponse;
import com.capstone.sistema.flow.dto.EventoDetalleResponse;
import com.capstone.sistema.flow.dto.FlujoDetalleResponse;
import com.capstone.sistema.flow.dto.ObservacionDetalleResponse;
import com.capstone.sistema.flow.dto.RequestDetailResponse;
import com.capstone.sistema.flow.dto.SeccionDetalleResponse;
import com.capstone.sistema.flow.dto.SlaDetalleResponse;
import com.capstone.sistema.flow.exception.RequestDetailDocumentConflictException;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.ObservacionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.repository.SolicitudTransicionRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.repository.AreaRepository;
import jakarta.persistence.criteria.JoinType;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.Clock;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class RequestDetailService {
    private final SolicitudRepository solicitudes;
    private final DocumentoRepository documentos;
    private final ObservacionRepository observaciones;
    private final SolicitudTransicionRepository historial;
    private final AreaRepository areas;
    private final RbacAccessService rbac;
    private final SolicitudService solicitudService;
    private final Clock clock;

    public RequestDetailService(SolicitudRepository solicitudes, DocumentoRepository documentos,
                                ObservacionRepository observaciones, SolicitudTransicionRepository historial,
                                AreaRepository areas, RbacAccessService rbac, SolicitudService solicitudService, Clock clock) {
        this.solicitudes = solicitudes;
        this.documentos = documentos;
        this.observaciones = observaciones;
        this.historial = historial;
        this.areas = areas;
        this.rbac = rbac;
        this.solicitudService = solicitudService;
        this.clock = clock;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public RequestDetailResponse consultar(UUID id) {
        // El contexto de permisos se resuelve dentro de la misma vista transaccional que los datos.
        rbac.clearContext();
        rbac.require(Permiso.SOLICITUD_CONSULTAR);
        Solicitud solicitud = solicitudes.findOne(rbac.visible(Permiso.SOLICITUD_CONSULTAR)
                        .and((root, query, builder) -> builder.equal(root.get("id"), id))
                        .and(conRelacionesDeDetalle()))
                .orElseThrow(RbacException::missing);

        Instant evaluadoEn = clock.instant();
        List<String> acciones = solicitudService.allowedActions(solicitud);
        List<Documento> versiones = documentos.findBySolicitud_IdOrderByVersionDescCreatedAtDescIdAsc(id);
        if (versiones.stream().filter(Documento::isVigente).count() > 1) {
            throw new RequestDetailDocumentConflictException();
        }
        List<DocumentoDetalleResponse> adjuntos = versiones.stream()
                .map(documento -> documentoDetalle(documento, id, acciones.contains("DESCARGAR")))
                .toList();
        DocumentoDetalleResponse vigente = adjuntos.stream()
                .filter(DocumentoDetalleResponse::vigente).findFirst().orElse(null);

        boolean puedeVerObservaciones = rbac.can(id, Permiso.OBSERVACION_CONSULTAR);
        boolean puedeVerHistorial = rbac.can(id, Permiso.HISTORIAL_CONSULTAR);
        SeccionDetalleResponse<ObservacionDetalleResponse> seccionObservaciones = new SeccionDetalleResponse<>(
                puedeVerObservaciones,
                puedeVerObservaciones ? observaciones.consultarDetalle(id).stream()
                        .map(this::observacionDetalle).toList() : List.of());
        SeccionDetalleResponse<EventoDetalleResponse> seccionHistorial = new SeccionDetalleResponse<>(
                puedeVerHistorial,
                puedeVerHistorial ? historial.consultarDetalle(id, puedeVerObservaciones).stream()
                        .map(evento -> eventoDetalle(evento, puedeVerObservaciones)).toList() : List.of());

        Map<Long, Area> areasRegistradas = consultarAreasRegistradas(solicitud);
        String estado = solicitud.getEstadoSolicitud().getCodigo();
        return new RequestDetailResponse(
                solicitud.getId(), solicitud.getCorrelativo(), solicitud.getTitulo(), solicitud.getDescripcion(),
                estado, solicitud.getEmisor().getId(),
                nombreCompleto(solicitud.getEmisor().getFirstName(), solicitud.getEmisor().getLastName()),
                solicitud.getCreatedAt(), solicitud.getUpdatedAt(), solicitud.getVersion(),
                new FlujoDetalleResponse(solicitud.getFlujoDefinicion().getId(), solicitud.getFlujoDefinicion().getNombre()),
                areaDetalle(solicitud.getAreaOrigenId(), areasRegistradas),
                areaDetalle(solicitud.getAreaFlujoId(), areasRegistradas),
                EtapaSolicitudResponse.from(solicitud.getFlujoEtapa()), vigente, adjuntos,
                new SlaDetalleResponse(solicitud.getDeadline(),
                        solicitudService.calculateSlaStatus(solicitud.getDeadline(), evaluadoEn), evaluadoEn,
                        "PENDIENTE_REVISION".equalsIgnoreCase(estado) && solicitud.getDeadline() != null),
                seccionObservaciones, seccionHistorial, acciones);
    }

    private Specification<Solicitud> conRelacionesDeDetalle() {
        return (root, query, builder) -> {
            root.fetch("emisor", JoinType.LEFT);
            root.fetch("estadoSolicitud", JoinType.LEFT);
            root.fetch("flujoDefinicion", JoinType.LEFT);
            root.fetch("flujoEtapa", JoinType.LEFT);
            return builder.conjunction();
        };
    }

    private Map<Long, Area> consultarAreasRegistradas(Solicitud solicitud) {
        Set<Long> ids = new HashSet<>();
        if (solicitud.getAreaOrigenId() != null) ids.add(solicitud.getAreaOrigenId());
        if (solicitud.getAreaFlujoId() != null) ids.add(solicitud.getAreaFlujoId());
        if (ids.isEmpty()) return Map.of();
        return areas.findAllById(ids).stream().collect(Collectors.toMap(Area::getId, Function.identity()));
    }

    private AreaDetalleResponse areaDetalle(Long id, Map<Long, Area> areasRegistradas) {
        if (id == null) return null;
        Area area = areasRegistradas.get(id);
        return new AreaDetalleResponse(id, area == null ? null : area.getNombre(),
                area == null ? null : area.isActivo());
    }

    private DocumentoDetalleResponse documentoDetalle(Documento documento, UUID solicitudId, boolean puedeDescargar) {
        boolean descargaDisponible = puedeDescargar;
        String descargaUrl = descargaDisponible ? "/api/documents/" + documento.getId() + "/download" : null;
        return new DocumentoDetalleResponse(documento.getId(), documento.getNombreArchivo(), documento.getContentType(),
                documento.getSizeBytes(), documento.getVersion(), documento.isVigente(), documento.getCreatedAt(),
                descargaUrl, descargaDisponible && "application/pdf".equalsIgnoreCase(documento.getContentType()));
    }

    private ObservacionDetalleResponse observacionDetalle(ObservacionRepository.Detalle observacion) {
        return new ObservacionDetalleResponse(observacion.getId(), observacion.getContenido(), observacion.getResuelta(),
                nombreCompleto(observacion.getUsuarioNombre(), observacion.getUsuarioApellido()), observacion.getCreatedAt(),
                observacion.getTransicionId(),
                etapaDetalle(observacion.getEtapaId(), observacion.getEtapaOrden(), observacion.getEtapaNombre()));
    }

    private EventoDetalleResponse eventoDetalle(SolicitudTransicionRepository.Detalle evento, boolean comentariosVisibles) {
        return new EventoDetalleResponse(evento.getId(), evento.getEstadoOrigen() == null ? "INICIAL" : evento.getEstadoOrigen(),
                evento.getEstadoDestino(), evento.getAccion(), nombreCompleto(evento.getUsuarioNombre(), evento.getUsuarioApellido()),
                comentariosVisibles ? evento.getComentario() : null, comentariosVisibles, evento.getDentroSla(), evento.getCreatedAt(),
                etapaDetalle(evento.getEtapaOrigenId(), evento.getEtapaOrigenOrden(), evento.getEtapaOrigenNombre()),
                etapaDetalle(evento.getEtapaDestinoId(), evento.getEtapaDestinoOrden(), evento.getEtapaDestinoNombre()));
    }

    private EtapaSolicitudResponse etapaDetalle(Long id, Integer orden, String nombre) {
        return id == null ? null : new EtapaSolicitudResponse(id, orden, nombre);
    }

    private String nombreCompleto(String nombre, String apellido) {
        String completo = ((nombre == null ? "" : nombre) + " " + (apellido == null ? "" : apellido)).trim();
        return completo.isEmpty() ? "Usuario no disponible" : completo;
    }
}
