package com.capstone.sistema.org.area.service;

import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Las futuras escrituras de referencias a áreas deben adquirir este bloqueo antes de consultar el área. */
@Component
public class AreaCatalogLock {

    private final JdbcTemplate jdbcTemplate;

    public AreaCatalogLock(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void acquire() {
        jdbcTemplate.execute((ConnectionCallback<Void>) connection -> {
            try (var statement = connection.prepareStatement("select pg_advisory_xact_lock(41021, 1)")) {
                statement.execute();
            }
            return null;
        });
    }
}
