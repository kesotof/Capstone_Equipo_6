package com.capstone.sistema.flow.dto;

public record DashboardSummaryCriteria(Long areaId, boolean sinArea) {
    public boolean filtered() { return areaId != null || sinArea; }
}
