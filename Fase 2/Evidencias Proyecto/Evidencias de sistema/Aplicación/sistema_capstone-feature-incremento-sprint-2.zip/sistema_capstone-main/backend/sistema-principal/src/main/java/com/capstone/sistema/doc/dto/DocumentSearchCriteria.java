package com.capstone.sistema.doc.dto;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.Instant;

/** Filtros normalizados de consulta; no representa una entidad persistida. */
public record DocumentSearchCriteria(String query, String documentType, String status, Long areaId,
                                     Instant dateFrom, Instant dateTo, boolean dateToExclusive,
                                     int page, int size, String sortField, Sort.Direction sortDirection) {
    public Pageable pageable() {
        return PageRequest.of(page, size, Sort.by(sortDirection, sortField).and(Sort.by("id")));
    }

    public String order() {
        return sortField + "," + sortDirection.name().toLowerCase(java.util.Locale.ROOT) + ";id,asc";
    }
}
