package com.capstone.sistema.audit.service;

import com.capstone.sistema.audit.dto.AuditEventResponse;
import com.capstone.sistema.audit.model.LogEvento;
import com.capstone.sistema.audit.model.TipoEvento;
import com.capstone.sistema.audit.repository.LogEventoRepository;
import com.capstone.sistema.audit.repository.TipoEventoRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Locale;

@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final LogEventoRepository logEventoRepository;
    private final TipoEventoRepository tipoEventoRepository;
    private final UserAccountRepository userAccountRepository;

    public AuditService(
            LogEventoRepository logEventoRepository,
            TipoEventoRepository tipoEventoRepository,
            UserAccountRepository userAccountRepository
    ) {
        this.logEventoRepository = logEventoRepository;
        this.tipoEventoRepository = tipoEventoRepository;
        this.userAccountRepository = userAccountRepository;
    }

    @Transactional
    public AuditEventResponse registerLogin(Jwt jwt, HttpServletRequest request) {
        String email = resolveEmail(jwt);
        String ipAddress = resolveClientIp(request);
        UserAccount user = findUser(jwt, email);

        TipoEvento tipoEvento = getOrCreateTipoEvento("LOGIN");
        LogEvento logEvento = new LogEvento(
                tipoEvento,
                user,
                email,
                ipAddress,
                "Inicio de sesión exitoso de " + email
        );

        LogEvento saved = logEventoRepository.saveAndFlush(logEvento);
        log.info("Inicio de sesión registrado en log_evento (id={}) para {} desde IP {}", saved.getId(), email, ipAddress);

        return new AuditEventResponse(
                saved.getId(),
                email,
                saved.getTipoEvento().getTipo(),
                saved.getIpAddress(),
                saved.getDetalle(),
                saved.getCreatedAt()
        );
    }

    @Transactional
    public AuditEventResponse registerLogout(Jwt jwt, HttpServletRequest request) {
        String email = resolveEmail(jwt);
        String ipAddress = resolveClientIp(request);
        UserAccount user = findUser(jwt, email);

        TipoEvento tipoEvento = getOrCreateTipoEvento("LOGOUT");
        LogEvento logEvento = new LogEvento(
                tipoEvento,
                user,
                email,
                ipAddress,
                "Cierre de sesión de " + email
        );

        LogEvento saved = logEventoRepository.saveAndFlush(logEvento);
        log.info("Cierre de sesión registrado en log_evento (id={}) para {} desde IP {}", saved.getId(), email, ipAddress);

        return new AuditEventResponse(
                saved.getId(),
                email,
                saved.getTipoEvento().getTipo(),
                saved.getIpAddress(),
                saved.getDetalle(),
                saved.getCreatedAt()
        );
    }

    private static final java.util.regex.Pattern SENSITIVE_PATTERN =
            java.util.regex.Pattern.compile("(?i)(password|contrasena|contraseña|secret|token|credencial|bearer)\\s*[:=]\\s*[^\\s,;\\]]+");

    public static String sanitize(String input) {
        if (input == null) {
            return null;
        }
        return SENSITIVE_PATTERN.matcher(input).replaceAll("$1=[PROTECTED]");
    }

    @Transactional
    public void registerUserManagementEvent(String tipo, String detalle) {
        registerUserManagementEvent(tipo, (UserAccount) null, detalle);
    }

    @Transactional
    public void registerUserManagementEvent(String tipo, UserAccount targetUser, String detalle) {
        String activeEmail = resolveCurrentActiveEmail();
        String clientIp = resolveCurrentClientIp();

        // El usuario con sesión activa que realiza la acción se asocia al evento
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserAccount actor = authentication != null && authentication.getPrincipal() instanceof Jwt jwt
                ? userAccountRepository.findByKeycloakUserId(jwt.getSubject()).orElse(null)
                : targetUser;
        String emailToStore = actor != null ? actor.getEmail() : null;

        String sanitizedDetalle = sanitize(detalle);
        TipoEvento tipoEvento = getOrCreateTipoEvento(tipo);
        LogEvento logEvento = new LogEvento(
                tipoEvento,
                actor,
                emailToStore,
                clientIp,
                sanitizedDetalle
        );
        logEventoRepository.save(logEvento);
        log.info("Evento de auditoría {} registrado por [{}] desde IP {}: {}",
                tipo, emailToStore != null ? emailToStore : "ANONIMO", clientIp, sanitizedDetalle);
    }

    @Transactional(readOnly = true)
    public java.util.List<AuditEventResponse> listRecentEvents(int limit) {
        return logEventoRepository.findAllByOrderByCreatedAtDesc().stream()
                .limit(Math.max(1, Math.min(limit, 200)))
                .map(e -> {
                    String email = e.getUsuarioEmail();
                    if (email == null || email.isBlank()) {
                        email = e.getUsuario() != null ? e.getUsuario().getEmail() : "";
                    }
                    return new AuditEventResponse(
                            e.getId(),
                            email,
                            e.getTipoEvento().getTipo(),
                            e.getIpAddress(),
                            e.getDetalle(),
                            e.getCreatedAt()
                    );
                })
                .toList();
    }

    private UserAccount findUser(Jwt jwt, String email) {
        if (jwt != null && jwt.getSubject() != null) {
            var byKeycloak = userAccountRepository.findByKeycloakUserId(jwt.getSubject());
            if (byKeycloak.isPresent()) {
                return byKeycloak.get();
            }
        }
        if (email != null && !email.isBlank()) {
            return userAccountRepository.findByEmailIgnoreCase(email).orElse(null);
        }
        return null;
    }

    private TipoEvento getOrCreateTipoEvento(String tipo) {
        return tipoEventoRepository.findByTipoIgnoreCase(tipo)
                .orElseGet(() -> tipoEventoRepository.save(new TipoEvento(tipo)));
    }

    private String resolveEmail(Jwt jwt) {
        if (jwt == null) {
            return "anonimo";
        }
        String email = jwt.getClaimAsString("email");
        if (email != null && !email.isBlank()) {
            return email.trim().toLowerCase(Locale.ROOT);
        }

        String username = jwt.getClaimAsString("preferred_username");
        if (username != null && !username.isBlank()) {
            return username.trim();
        }

        return jwt.getSubject();
    }

    public String resolveCurrentActiveEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return null;
        }
        if ("anonymousUser".equalsIgnoreCase(authentication.getName())) {
            return null;
        }
        if (authentication.getPrincipal() instanceof Jwt jwt) {
            return resolveEmail(jwt);
        }
        String name = authentication.getName();
        if (name != null && !name.isBlank() && !"anonymousUser".equalsIgnoreCase(name)) {
            return name.trim().toLowerCase(Locale.ROOT);
        }
        return null;
    }

    public String resolveCurrentClientIp() {
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if (attributes instanceof ServletRequestAttributes servletAttributes) {
            return resolveClientIp(servletAttributes.getRequest());
        }
        return "127.0.0.1";
    }

    private String resolveClientIp(HttpServletRequest request) {
        if (request == null) {
            return "127.0.0.1";
        }
        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
