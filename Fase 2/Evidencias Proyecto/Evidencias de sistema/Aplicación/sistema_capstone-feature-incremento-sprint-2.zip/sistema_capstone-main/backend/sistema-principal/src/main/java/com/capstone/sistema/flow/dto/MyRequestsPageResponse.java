package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.List;

public record MyRequestsPageResponse(
        List<MyRequestsSummaryResponse> contenido,
        int pagina,
        int tamanio,
        long totalElementos,
        int totalPaginas,
        boolean primera,
        boolean ultima,
        String orden,
        Instant consultadoEn
) {
    public MyRequestsPageResponse {
        contenido = List.copyOf(contenido);
    }
}
