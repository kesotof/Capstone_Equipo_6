package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.AccionUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccionUsuarioRepository extends JpaRepository<AccionUsuario, Long> {

    Optional<AccionUsuario> findByAccionIgnoreCase(String accion);
}
