package com.capstone.sistema.flow.consumer;

import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.flow.service.AiAnalysisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class AiResultListener {

    private static final Logger log = LoggerFactory.getLogger(AiResultListener.class);

    private final AiAnalysisService aiAnalysisService;

    public AiResultListener(AiAnalysisService aiAnalysisService) {
        this.aiAnalysisService = aiAnalysisService;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.results.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = RabbitConfig.AI_RESULTS_ROUTING_KEY
    ))
    public void onAiResult(Map<String, Object> payload) {
        log.info("Mensaje de resultado de IA recibido desde RabbitMQ: {}", payload);
        aiAnalysisService.procesarResultado(payload);
    }
}
