package com.capstone.sistema.auth;

import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Optional;

@Component
public class CurrentUserResolver {

    private final UserAccountRepository userAccountRepository;

    public CurrentUserResolver(UserAccountRepository userAccountRepository) {
        this.userAccountRepository = userAccountRepository;
    }

    public String resolveCurrentEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || "anonymousUser".equalsIgnoreCase(authentication.getName())) {
            return null;
        }
        if (authentication.getPrincipal() instanceof Jwt jwt) {
            String email = jwt.getClaimAsString("email");
            if (email != null && !email.isBlank()) {
                return email.trim().toLowerCase(Locale.ROOT);
            }
            String username = jwt.getClaimAsString("preferred_username");
            if (username != null && !username.isBlank()) {
                return username.trim().toLowerCase(Locale.ROOT);
            }
        }
        String name = authentication.getName();
        if (name != null && !name.isBlank() && !"anonymousUser".equalsIgnoreCase(name)) {
            return name.trim().toLowerCase(Locale.ROOT);
        }
        return null;
    }

    public Optional<UserAccount> resolveCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return Optional.empty();
        }

        if (authentication.getPrincipal() instanceof Jwt jwt && jwt.getSubject() != null) {
            return userAccountRepository.findByKeycloakUserId(jwt.getSubject()).filter(UserAccount::isEnabled);
        }

        return Optional.empty();
    }

    public boolean isCurrentUserAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return false;
        }

        return resolveCurrentUser()
                .map(user -> user.getRoles().contains(SystemRole.ADMIN))
                .orElse(false);
    }
}
