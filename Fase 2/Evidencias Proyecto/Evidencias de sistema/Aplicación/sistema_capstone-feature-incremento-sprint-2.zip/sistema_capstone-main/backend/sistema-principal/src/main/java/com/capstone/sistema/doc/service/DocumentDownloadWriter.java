package com.capstone.sistema.doc.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import com.capstone.sistema.doc.exception.DocumentDownloadException;
import io.minio.GetObjectResponse;
import io.minio.errors.ErrorResponseException;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Streaming síncrono sin transacción de base ni materialización completa del archivo. */
@Component
public class DocumentDownloadWriter {
    private static final Logger log = LoggerFactory.getLogger(DocumentDownloadWriter.class);
    private final MinioStorageService storage;
    private final AuditService audit;

    public DocumentDownloadWriter(MinioStorageService storage, AuditService audit) {
        this.storage = storage;
        this.audit = audit;
    }

    public void write(DocumentDownloadTarget target, HttpServletResponse response) throws IOException {
        try (GetObjectResponse input = open(target.storageKey())) {
            long size = contentLength(input);
            if (target.sizeBytes() != null && target.sizeBytes() != size) {
                throw DocumentDownloadException.inconsistent();
            }
            String disposition = ContentDisposition.attachment()
                    .filename(filename(target), StandardCharsets.UTF_8).build().toString();
            String type = contentType(target.contentType());
            audit.registerUserManagementEvent("DESCARGAR_DOCUMENTO",
                    "Descarga autorizada iniciada; documentoId=" + target.id() + "; solicitudId="
                            + target.solicitudId() + "; version=" + target.version());
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, disposition);
            response.setContentType(type);
            response.setContentLengthLong(size);
            // Buffer fijo: el tamaño del archivo no incrementa el consumo de memoria del servidor.
            byte[] buffer = new byte[64 * 1024];
            long copied = 0;
            int count;
            var output = response.getOutputStream();
            while ((count = input.read(buffer)) != -1) {
                if (count == 0) continue;
                if (copied + count > size) throw new IOException("Longitud documental inconsistente");
                output.write(buffer, 0, count);
                copied += count;
            }
            if (copied != size) throw new IOException("Transferencia documental incompleta");
            output.flush();
        } catch (IOException ex) {
            log.warn("Transferencia interrumpida; documentoId={}; tipo={}", target.id(), ex.getClass().getSimpleName());
            if (response.isCommitted()) throw ex;
            clearBinaryHeaders(response);
            throw DocumentDownloadException.unavailable();
        }
    }

    private GetObjectResponse open(String key) {
        try {
            return storage.openDownload(key);
        } catch (ErrorResponseException ex) {
            if ("NoSuchKey".equals(ex.errorResponse().code()) || "NoSuchObject".equals(ex.errorResponse().code())) {
                throw DocumentDownloadException.missing();
            }
            log.warn("Almacenamiento documental no disponible; tipo={}", ex.getClass().getSimpleName());
            throw DocumentDownloadException.unavailable();
        } catch (Exception ex) {
            log.warn("Almacenamiento documental no disponible; tipo={}", ex.getClass().getSimpleName());
            throw DocumentDownloadException.unavailable();
        }
    }

    private long contentLength(GetObjectResponse input) {
        try {
            long value = Long.parseLong(input.headers().get(HttpHeaders.CONTENT_LENGTH));
            if (value < 0) throw new NumberFormatException();
            return value;
        } catch (NumberFormatException ex) {
            throw DocumentDownloadException.unavailable();
        }
    }

    private String filename(DocumentDownloadTarget target) {
        String name = target.nombreArchivo() == null ? "" : target.nombreArchivo();
        name = name.substring(Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\')) + 1);
        name = name.replaceAll("[\\p{Cntrl}\\p{Cf}\\\\/:*?\"<>|]", "_").strip();
        name = name.replaceAll("[. ]+$", "");
        return name.isBlank() ? "documento-" + target.id() : name;
    }

    private String contentType(String value) {
        try {
            MediaType type = MediaType.parseMediaType(value);
            return type.isWildcardType() || type.isWildcardSubtype() ? MediaType.APPLICATION_OCTET_STREAM_VALUE : type.toString();
        } catch (IllegalArgumentException ex) {
            return MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }
    }

    private void clearBinaryHeaders(HttpServletResponse response) {
        response.resetBuffer();
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, null);
        response.setHeader(HttpHeaders.CONTENT_LENGTH, null);
        response.setContentType(null);
    }
}
