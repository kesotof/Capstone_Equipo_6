package com.capstone.sistema.flow.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BusinessDaysCalculatorTest {

    private static final ZoneId CHILE_ZONE = ZoneId.of("America/Santiago");

    @Test
    @DisplayName("Sumar 1 día hábil un viernes salta el fin de semana y vence el lunes")
    void sumarDiaHabil_desdeViernes_venceLunes() {
        // Viernes 2026-10-02
        ZonedDateTime viernes = ZonedDateTime.of(2026, 10, 2, 10, 0, 0, 0, CHILE_ZONE);
        Instant deadline = BusinessDaysCalculator.calculateDeadline(viernes.toInstant(), 1);

        ZonedDateTime deadlineZdt = deadline.atZone(CHILE_ZONE);
        assertThat(deadlineZdt.getDayOfWeek()).isEqualTo(DayOfWeek.MONDAY);
        assertThat(deadlineZdt.getDayOfMonth()).isEqualTo(5);
        assertThat(deadlineZdt.getHour()).isEqualTo(10);
    }

    @Test
    @DisplayName("Sumar 3 días hábiles desde un miércoles salta fin de semana y vence el lunes siguiente")
    void sumarTresDiasHabiles_desdeMiercoles_venceLunes() {
        // Miércoles 2026-09-30
        ZonedDateTime miercoles = ZonedDateTime.of(2026, 9, 30, 15, 30, 0, 0, CHILE_ZONE);
        // +1 Jueves (1 Oct), +2 Viernes (2 Oct), +3 Lunes (5 Oct)
        Instant deadline = BusinessDaysCalculator.calculateDeadline(miercoles.toInstant(), 3);

        ZonedDateTime deadlineZdt = deadline.atZone(CHILE_ZONE);
        assertThat(deadlineZdt.getDayOfWeek()).isEqualTo(DayOfWeek.MONDAY);
        assertThat(deadlineZdt.getDayOfMonth()).isEqualTo(5);
    }

    @Test
    @DisplayName("Sumar 5 días hábiles desde un lunes vence el lunes siguiente")
    void sumarCincoDiasHabiles_desdeLunes_venceProximoLunes() {
        // Lunes 2026-09-28
        ZonedDateTime lunes = ZonedDateTime.of(2026, 9, 28, 9, 0, 0, 0, CHILE_ZONE);
        Instant deadline = BusinessDaysCalculator.calculateDeadline(lunes.toInstant(), 5);

        ZonedDateTime deadlineZdt = deadline.atZone(CHILE_ZONE);
        assertThat(deadlineZdt.getDayOfWeek()).isEqualTo(DayOfWeek.MONDAY);
        assertThat(deadlineZdt.getDayOfMonth()).isEqualTo(5);
    }

    @Test
    @DisplayName("Plazo en 0 o negativo retorna la misma fecha de inicio")
    void plazoCero_retornaMismoInicio() {
        Instant now = Instant.now();
        assertThat(BusinessDaysCalculator.calculateDeadline(now, 0)).isEqualTo(now);
        assertThat(BusinessDaysCalculator.calculateDeadline(now, -2)).isEqualTo(now);
    }

    @Test
    void inicioFinDeSemana_unDiaVenceLunesYCincoViernes() {
        for (int day : new int[]{10, 11}) {
            Instant start = ZonedDateTime.of(2026, 10, day, 10, 0, 0, 0, CHILE_ZONE).toInstant();
            assertThat(BusinessDaysCalculator.calculateDeadline(start, 1).atZone(CHILE_ZONE).toLocalDate())
                    .isEqualTo(java.time.LocalDate.of(2026, 10, 12));
            assertThat(BusinessDaysCalculator.calculateDeadline(start, 5).atZone(CHILE_ZONE).toLocalDate())
                    .isEqualTo(java.time.LocalDate.of(2026, 10, 16));
        }
    }

    @Test
    void cambioHorario_conservaHoraLocalInclusoMedianoche() {
        ZonedDateTime start = ZonedDateTime.of(2026, 9, 4, 0, 0, 0, 0, CHILE_ZONE);
        ZonedDateTime end = BusinessDaysCalculator.calculateDeadline(start.toInstant(), 1).atZone(CHILE_ZONE);
        assertThat(end.toLocalDate()).isEqualTo(java.time.LocalDate.of(2026, 9, 7));
        assertThat(end.toLocalTime()).isEqualTo(start.toLocalTime());
        assertThat(end.getOffset()).isNotEqualTo(start.getOffset());
        assertThat(java.time.Duration.between(start, end).toHours()).isEqualTo(71);
    }

    @Test
    void resultadoEquivaleACalendarioDeLunesAViernes() {
        for (int day = 5; day <= 11; day++) {
            ZonedDateTime start = ZonedDateTime.of(2026, 10, day, 10, 0, 0, 0, CHILE_ZONE);
            for (int days = 1; days <= 50; days++) {
                java.time.LocalDate expected = start.toLocalDate();
                int remaining = days;
                while (remaining > 0) {
                    expected = expected.plusDays(1);
                    if (expected.getDayOfWeek().getValue() <= 5) remaining--;
                }
                assertThat(BusinessDaysCalculator.calculateDeadline(start.toInstant(), days))
                        .isEqualTo(expected.atTime(start.toLocalTime()).atZone(CHILE_ZONE).toInstant());
            }
        }
    }

    @Test
    void plazoNoRepresentable_seRechazaSinIteracionMasiva() {
        assertThatThrownBy(() -> BusinessDaysCalculator.calculateDeadline(Instant.parse("2026-10-09T13:00:00Z"),
                Integer.MAX_VALUE)).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("PostgreSQL");
        assertThat(BusinessDaysCalculator.calculateDeadline(null, 5)).isNull();
    }
}
