package com.capstone.sistema.org.area.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.CreateAreaRequest;
import com.capstone.sistema.org.area.dto.PaginaAreasResponse;
import com.capstone.sistema.org.area.dto.ToggleAreaStatusRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.exception.AreaException;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Service
@PreAuthorize("hasRole('ADMIN')")
public class AreaService {

    private final AreaRepository areaRepository;
    private final UserAccountRepository userAccountRepository;
    private final AreaCatalogLock catalogLock;
    private final AreaUsageChecker usageChecker;
    private final AuditService auditService;
    private final EntityManager entityManager;
    private final com.capstone.sistema.rbac.service.RbacManagementService rbac;

    public AreaService(AreaRepository areaRepository, UserAccountRepository userAccountRepository,
                       AreaCatalogLock catalogLock, AreaUsageChecker usageChecker,
                       AuditService auditService, EntityManager entityManager,
                       com.capstone.sistema.rbac.service.RbacManagementService rbac) {
        this.areaRepository = areaRepository;
        this.userAccountRepository = userAccountRepository;
        this.catalogLock = catalogLock;
        this.usageChecker = usageChecker;
        this.auditService = auditService;
        this.entityManager = entityManager;
        this.rbac = rbac;
    }

    @Transactional(readOnly = true)
    public PaginaAreasResponse list(int page, int size, Boolean activo, String q) {
        if (page < 0) {
            throw AreaException.invalidField("page", "La página no puede ser negativa.");
        }
        if (size < 1 || size > 100) {
            throw AreaException.invalidField("size", "El tamaño de página debe estar entre 1 y 100.");
        }
        if (q != null && (length(q) > 100 || q.indexOf('\0') >= 0)) {
            throw AreaException.invalidField("q",
                    "La búsqueda admite hasta 100 caracteres y no admite el carácter nulo.");
        }
        String pattern = q == null || q.isBlank() ? "%"
                : "%" + q.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%";
        // JPA limita el offset a int, aunque el contrato permite cualquier página int positiva.
        if ((long) page * size > Integer.MAX_VALUE) {
            long total = areaRepository.countCatalog(activo, pattern);
            int totalPages = (int) Math.min(Integer.MAX_VALUE, (total + size - 1) / size);
            return new PaginaAreasResponse(List.of(), page, size, total, totalPages, false, true);
        }
        var result = areaRepository.findCatalogPage(activo, pattern, PageRequest.of(page, size));
        return new PaginaAreasResponse(result.getContent().stream().map(AreaService::toResponse).toList(),
                result.getNumber(), result.getSize(), result.getTotalElements(), result.getTotalPages(),
                result.isFirst(), result.isLast());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse create(CreateAreaRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        String name = normalizeName(request.nombre());
        String description = normalizeDescription(request.descripcion());
        validateParentId(request.areaPadreId());
        if (areaRepository.existsNombreNormalizado(name)) {
            throw AreaException.duplicateName();
        }
        Area parent = findParent(request.areaPadreId());
        validateHierarchy(null, parent, true);
        Area area = new Area(name);
        area.setDescripcion(description);
        area.setAreaPadre(parent);
        if (request.administradorId() != null) {
            UserAccount admin = findAdminUser(request.administradorId());
            area.setAdministrador(admin);
        }
        areaRepository.saveAndFlush(area);
        entityManager.refresh(area);
        rbac.finishMutation(securityBefore);
        if (area.getAdministrador() != null) rbac.auditChange("ASIGNAR_ADMIN_AREA",area.getId(),null,area.getAdministrador().getId());
        auditService.registerUserManagementEvent("CREAR_AREA",
                "Área id=" + area.getId() + "; campos=nombre,descripcion,areaPadreId,activo"
                + (area.getAdministrador() != null ? ",administradorId" : "") + ".");
        return toResponse(area);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse update(Long id, UpdateAreaRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(id);
        validateVersion(area, request.version());
        String name = normalizeName(request.nombre());
        String description = normalizeDescription(request.descripcion());
        validateParentId(request.areaPadreId());
        if (areaRepository.existsNombreNormalizadoExcluding(name, id)) {
            throw AreaException.duplicateName();
        }
        Area parent = findParent(request.areaPadreId());
        boolean parentChanged = !Objects.equals(parentId(area), request.areaPadreId());
        validateHierarchy(id, parent, area.isActivo() || parentChanged);

        var changedFields = new ArrayList<String>();
        if (!Objects.equals(area.getNombre(), name)) {
            area.setNombre(name);
            changedFields.add("nombre");
        }
        if (!Objects.equals(area.getDescripcion(), description)) {
            area.setDescripcion(description);
            changedFields.add("descripcion");
        }
        if (parentChanged) {
            area.setAreaPadre(parent);
            changedFields.add("areaPadreId");
        }

        UUID currentAdminId = area.getAdministrador() != null ? area.getAdministrador().getId() : null;
        if (!Objects.equals(currentAdminId, request.administradorId())) {
            UserAccount newAdmin = request.administradorId() != null ? findAdminUser(request.administradorId()) : null;
            area.setAdministrador(newAdmin);
            rbac.auditChange("ASIGNAR_ADMIN_AREA",id,currentAdminId,request.administradorId());
            changedFields.add("administradorId");
            auditService.registerUserManagementEvent("ASIGNAR_ADMIN_AREA",
                    "Área id=" + id + " ('" + area.getNombre() + "'): "
                    + (newAdmin != null ? "asignado administrador " + newAdmin.getEmail() + " (id=" + newAdmin.getId() + ")" : "administrador removido"));
        }

        if (!changedFields.isEmpty()) {
            flushAndRefresh(area);
            auditService.registerUserManagementEvent("ACTUALIZAR_AREA",
                    "Área id=" + id + "; campos=" + String.join(",", changedFields) + ".");
        }
        areaRepository.flush();
        rbac.finishMutation(securityBefore);
        return toResponse(area);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse changeStatus(Long id, ToggleAreaStatusRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(id);
        validateVersion(area, request.version());
        if (request.activo() == null) {
            throw AreaException.invalidField("activo", "El estado activo es obligatorio.");
        }
        if (area.isActivo() == request.activo()) {
            return toResponse(area);
        }
        if (request.activo()) {
            validateHierarchy(id, area.getAreaPadre(), true);
        } else {
            var dependencies = usageChecker.findDependencies(id);
            if (dependencies.isInUse()) {
                throw new AreaException(HttpStatus.CONFLICT, "AREA_EN_USO", "Área en uso",
                        "Resuelve las dependencias del área antes de desactivarla.",
                        Map.of("dependencias", dependencies.asMap()));
            }
        }
        area.setActivo(request.activo());
        flushAndRefresh(area);
        rbac.finishMutation(securityBefore);
        auditService.registerUserManagementEvent(request.activo() ? "ACTIVAR_AREA" : "DESACTIVAR_AREA",
                "Área id=" + id + "; campo=activo; valor=" + request.activo() + ".");
        return toResponse(area);
    }

    private void flushAndRefresh(Area area) {
        areaRepository.flush();
        // La respuesta usa la precisión real persistida, incluso en tablas legacy.
        entityManager.refresh(area);
    }

    private Area findArea(Long id) {
        if (id == null || id <= 0) {
            throw AreaException.invalidField("id", "El ID del área debe ser positivo.");
        }
        return areaRepository.findById(id).orElseThrow(() -> new AreaException(HttpStatus.NOT_FOUND,
                "AREA_NO_ENCONTRADA", "Área no encontrada", "No existe el área indicada.", Map.of()));
    }

    private Area findParent(Long id) {
        return id == null ? null : areaRepository.findById(id).orElseThrow(() -> new AreaException(
                HttpStatus.NOT_FOUND, "AREA_PADRE_NO_ENCONTRADA", "Área padre no encontrada",
                "No existe el área padre indicada.", Map.of()));
    }

    private void validateHierarchy(Long areaId, Area parent, boolean requireActive) {
        Set<Long> visited = new HashSet<>();
        boolean inactiveAncestor = false;
        for (Area ancestor = parent; ancestor != null; ancestor = ancestor.getAreaPadre()) {
            if (Objects.equals(ancestor.getId(), areaId) || !visited.add(ancestor.getId())) {
                throw AreaException.invalidHierarchy();
            }
            inactiveAncestor |= !ancestor.isActivo();
        }
        if (requireActive && inactiveAncestor) {
            throw new AreaException(HttpStatus.CONFLICT, "AREA_PADRE_INACTIVA", "Área padre inactiva",
                    "El padre y todos sus ancestros deben estar activos.", Map.of());
        }
    }

    private void validateVersion(Area area, Long version) {
        if (version == null || version < 0) {
            throw AreaException.invalidField("version", "Envía una versión no negativa.");
        }
        if (area.getVersion() != version) {
            throw new AreaException(HttpStatus.CONFLICT, "AREA_MODIFICADA", "Área modificada",
                    "El área cambió desde tu última consulta. Recarga sus datos antes de editarla.",
                    Map.of("versionActual", area.getVersion()));
        }
    }

    private void validateParentId(Long id) {
        if (id != null && id <= 0) {
            throw AreaException.invalidField("areaPadreId", "El ID del padre debe ser positivo.");
        }
    }

    private String normalizeName(String input) {
        String name = trimSpaces(input);
        if (name == null || name.isEmpty() || length(name) > 100
                || name.codePoints().anyMatch(Character::isISOControl)) {
            throw AreaException.invalidField("nombre",
                    "El nombre debe tener entre 1 y 100 caracteres, sin caracteres de control.");
        }
        return name;
    }

    private String normalizeDescription(String input) {
        String description = trimSpaces(input);
        if (description != null && (length(description) > 1000 || description.indexOf('\0') >= 0)) {
            throw AreaException.invalidField("descripcion",
                    "La descripción admite hasta 1000 caracteres y no admite el carácter nulo.");
        }
        return description == null || description.isEmpty() ? null : description;
    }

    private static String trimSpaces(String value) {
        if (value == null) {
            return null;
        }
        int start = 0;
        int end = value.length();
        while (start < end && value.charAt(start) == ' ') {
            start++;
        }
        while (end > start && value.charAt(end - 1) == ' ') {
            end--;
        }
        return value.substring(start, end);
    }

    private static int length(String value) {
        return value.codePointCount(0, value.length());
    }

    private UserAccount findAdminUser(UUID id) {
        UserAccount user = userAccountRepository.findById(id).orElseThrow(() ->
                AreaException.invalidField("administradorId", "El usuario indicado para administrador no existe."));
        if (!user.isEnabled()) {
            throw AreaException.invalidField("administradorId", "El usuario seleccionado como administrador debe estar activo.");
        }
        return user;
    }

    private static Long parentId(Area area) {
        return area.getAreaPadre() == null ? null : area.getAreaPadre().getId();
    }

    private static AreaResponse toResponse(Area area) {
        Area parent = area.getAreaPadre();
        UserAccount admin = area.getAdministrador();
        UUID adminId = null;
        String adminNombre = null;
        String adminEmail = null;
        if (admin != null) {
            adminId = admin.getId();
            adminEmail = admin.getEmail();
            String f = admin.getFirstName() != null ? admin.getFirstName() : "";
            String l = admin.getLastName() != null ? admin.getLastName() : "";
            adminNombre = (f + " " + l).trim();
            if (adminNombre.isEmpty()) {
                adminNombre = admin.getEmail();
            }
        }

        return new AreaResponse(area.getId(), area.getNombre(), area.getDescripcion(), area.isActivo(),
                parent == null ? null : parent.getId(), parent == null ? null : parent.getNombre(),
                adminId, adminNombre, adminEmail,
                area.getCreatedAt(), area.getUpdatedAt(), area.getVersion());
    }
}
