package com.capstone.sistema.flow.exception;

public class SlaNotFoundException extends RuntimeException {
    public SlaNotFoundException(String message) {
        super(message);
    }
}
