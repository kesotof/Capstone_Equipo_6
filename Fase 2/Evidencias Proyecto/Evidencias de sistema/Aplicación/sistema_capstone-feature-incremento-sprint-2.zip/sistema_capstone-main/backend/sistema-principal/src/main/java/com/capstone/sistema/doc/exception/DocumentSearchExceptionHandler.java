package com.capstone.sistema.doc.exception;

import com.capstone.sistema.doc.controller.DocumentSearchController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice(assignableTypes = DocumentSearchController.class)
@Order(Ordered.HIGHEST_PRECEDENCE + 50)
public class DocumentSearchExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(DocumentSearchExceptionHandler.class);

    @ExceptionHandler(DocumentSearchException.class)
    public ResponseEntity<ProblemDetail> invalidSearch(DocumentSearchException ex) {
        return error(ex.status(), ex.status() == HttpStatus.CONFLICT ? "Información documental inconsistente" : "Parámetros de búsqueda inválidos",
                ex.getMessage(), ex.code());
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> accessDenied(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Control de acceso", "No tiene permiso para realizar esta acción.", "RBAC_ACCION_DENEGADA");
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ProblemDetail> unavailable(RuntimeException ex) {
        // Evitar registrar consultas, valores de filtros o parámetros SQL que puedan contener información privada.
        log.error("Búsqueda documental no disponible: {}", ex.getClass().getSimpleName());
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Búsqueda no disponible",
                "No fue posible consultar los documentos. Intente nuevamente.", "DOCUMENT_SEARCH_UNAVAILABLE");
    }

    private ResponseEntity<ProblemDetail> error(HttpStatus status, String title, String detail, String code) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setProperty("code", code);
        return ResponseEntity.status(status).cacheControl(CacheControl.noStore()).body(problem);
    }
}
