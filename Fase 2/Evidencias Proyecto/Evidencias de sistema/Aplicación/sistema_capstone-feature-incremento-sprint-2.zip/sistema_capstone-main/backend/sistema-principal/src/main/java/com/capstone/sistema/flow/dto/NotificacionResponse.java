package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record NotificacionResponse(
        Long id,
        String titulo,
        String mensaje,
        String tipo,
        UUID solicitudId,
        boolean leida,
        Instant createdEn,
        Instant leidaEn
) {
}
