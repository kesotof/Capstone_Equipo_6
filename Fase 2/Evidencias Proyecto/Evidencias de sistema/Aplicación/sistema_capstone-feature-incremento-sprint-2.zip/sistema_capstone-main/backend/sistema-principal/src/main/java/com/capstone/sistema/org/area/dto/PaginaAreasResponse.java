package com.capstone.sistema.org.area.dto;

import java.util.List;

public record PaginaAreasResponse(
        List<AreaResponse> contenido,
        int pagina,
        int tamanio,
        long totalElementos,
        int totalPaginas,
        boolean primera,
        boolean ultima
) {
}
