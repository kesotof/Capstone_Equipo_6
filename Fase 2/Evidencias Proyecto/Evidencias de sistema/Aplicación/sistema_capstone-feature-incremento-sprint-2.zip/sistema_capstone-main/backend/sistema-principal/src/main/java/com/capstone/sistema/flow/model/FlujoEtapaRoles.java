package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "flujo_etapa_roles")
public class FlujoEtapaRoles {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_etapa_id", nullable = false)
    private FlujoEtapa flujoEtapa;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private UserAccount usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "rol_flujo_id")
    private RolFlujo rolFlujo;

    protected FlujoEtapaRoles() {
    }

    public FlujoEtapaRoles(FlujoEtapa flujoEtapa, UserAccount usuario, Area area, RolFlujo rolFlujo) {
        this.flujoEtapa = flujoEtapa;
        this.usuario = usuario;
        this.area = area;
        this.rolFlujo = rolFlujo;
    }

    public Long getId() {
        return id;
    }

    public FlujoEtapa getFlujoEtapa() {
        return flujoEtapa;
    }

    public void setFlujoEtapa(FlujoEtapa flujoEtapa) {
        this.flujoEtapa = flujoEtapa;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public RolFlujo getRolFlujo() {
        return rolFlujo;
    }

    public void setRolFlujo(RolFlujo rolFlujo) {
        this.rolFlujo = rolFlujo;
    }
}
