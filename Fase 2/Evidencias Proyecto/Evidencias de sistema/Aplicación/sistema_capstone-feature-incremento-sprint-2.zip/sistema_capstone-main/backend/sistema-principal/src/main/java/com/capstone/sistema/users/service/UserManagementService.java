package com.capstone.sistema.users.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.UpdateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.exception.RutDuplicadoException;
import com.capstone.sistema.users.exception.UserAlreadyExistsException;
import com.capstone.sistema.users.exception.UserNotFoundException;
import com.capstone.sistema.users.exception.UserProvisioningException;

import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.RolFlujoRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.capstone.sistema.users.util.RutValidator;
import jakarta.ws.rs.core.Response;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;

import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class UserManagementService {

    private static final Logger log = LoggerFactory.getLogger(UserManagementService.class);

    private final UserAccountRepository userAccountRepository;
    private final RolFlujoRepository rolFlujoRepository;
    private final AreaRepository areaRepository;
    private final KeycloakLockStatusClient keycloakLockStatusClient;
    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties keycloakProperties;
    private final AuditService auditService;
    private final com.capstone.sistema.rbac.service.RbacManagementService rbac;
    private final com.capstone.sistema.auth.CurrentUserResolver currentUserResolver;
    private final jakarta.persistence.EntityManager entityManager;
    private final com.capstone.sistema.users.password.PasswordChangeOperations passwordChanges;

    public UserManagementService(
            UserAccountRepository userAccountRepository,
            RolFlujoRepository rolFlujoRepository,
            AreaRepository areaRepository,
            KeycloakLockStatusClient keycloakLockStatusClient,
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties keycloakProperties,
            AuditService auditService,
            com.capstone.sistema.rbac.service.RbacManagementService rbac,
            com.capstone.sistema.auth.CurrentUserResolver currentUserResolver,
            jakarta.persistence.EntityManager entityManager
    ) {
        this.userAccountRepository = userAccountRepository;
        this.rolFlujoRepository = rolFlujoRepository;
        this.areaRepository = areaRepository;
        this.keycloakLockStatusClient = keycloakLockStatusClient;
        this.keycloakAdminClient = keycloakAdminClient;
        this.keycloakProperties = keycloakProperties;
        this.auditService = auditService;
        this.rbac = rbac;
        this.currentUserResolver=currentUserResolver;
        this.entityManager=entityManager;
        this.passwordChanges = new com.capstone.sistema.users.password.PasswordChangeOperations(
                keycloakAdminClient, keycloakProperties, currentUserResolver, keycloakLockStatusClient, auditService, userAccountRepository);
    }

    @Transactional
    public UserResponse createUser(CreateUserRequest request) {
        var securityBefore = rbac.prepareMutation();
        Set<RolFlujo> selectedRoles = request.roleIds() != null
                ? rbac.explicitRoles(request.roleIds()) : resolveRolFlujoEntities(request.roles());
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (userAccountRepository.existsByEmailIgnoreCase(email)) {
            throw new UserAlreadyExistsException(email);
        }

        String rutNormalizado = RutValidator.normalizar(request.rut());
        if (userAccountRepository.existsByRut(rutNormalizado)) {
            throw new RutDuplicadoException("El RUT " + rutNormalizado + " ya está registrado en el sistema");
        }

        Area area = null;
        if (request.areaId() != null) {
            area = areaRepository.findById(request.areaId())
                    .orElseThrow(() -> new IllegalArgumentException("El área especificada no existe"));
            if (!area.isActivo()) {
                throw new IllegalArgumentException("No se puede asignar un usuario a un área inactiva");
            }
        }

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        if (!users.searchByEmail(email, true).isEmpty()) {
            throw new UserAlreadyExistsException(email);
        }

        UserRepresentation representation = new UserRepresentation();
        representation.setUsername(email);
        representation.setEmail(email);
        representation.setFirstName(request.firstName().trim());
        representation.setLastName(request.lastName().trim());
        representation.setEmailVerified(true);
        representation.setEnabled(true);

        String keycloakUserId = createInKeycloak(users, representation, email);
        try {
            setInitialPassword(users, keycloakUserId, request.password(), request.requirePasswordChange());
            // Keycloak mantiene la identidad; las autorizaciones se guardan localmente.

            UserAccount user = new UserAccount(
                    keycloakUserId,
                    email,
                    rutNormalizado,
                    request.firstName().trim(),
                    request.lastName().trim(),
                    area,
                    true,
                    selectedRoles
            );
            UserAccount saved = userAccountRepository.saveAndFlush(user);
            rbac.finishMutation(securityBefore);
            rbac.auditChange("ASIGNAR_ROLES", saved.getId(), java.util.List.of(),
                    selectedRoles.stream().map(RolFlujo::getId).sorted().toList());
            log.info("Cuenta creada y sincronizada id={} con roles locales",saved.getId());
            String detalleAuditoria = "Usuario creado id=" + saved.getId() + (area != null ? "; areaId=" + area.getId() : "");
            auditService.registerUserManagementEvent("CREAR_USUARIO", saved, detalleAuditoria);
            return rbac.response(saved, false);
        } catch (RuntimeException exception) {
            deleteKeycloakUserQuietly(users, keycloakUserId, email);
            if (exception instanceof UserAlreadyExistsException
                    || exception instanceof RutDuplicadoException
                    || exception instanceof UserProvisioningException) {
                throw exception;
            }
            throw new UserProvisioningException("No fue posible completar la creación de la cuenta", exception);
        }
    }

    @Transactional
    public UserResponse updateUser(UUID id, UpdateUserRequest request) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);

        if (request.areaId() != null && (user.getArea() == null || !request.areaId().equals(user.getArea().getId()))) {
            Area target = areaRepository.findById(request.areaId()).orElseThrow(
                    () -> new IllegalArgumentException("El área especificada no existe"));
            if (!target.isActivo()) throw new IllegalArgumentException("No se puede asignar un usuario a un área inactiva");
            Long previousArea = user.getArea() == null ? null : user.getArea().getId();
            user.setArea(target);
            user.incrementVersionAcceso();
            userAccountRepository.flush();
            rbac.auditChange("CAMBIAR_AREA_USUARIO", id, previousArea, target.getId());
        }
        rbac.finishMutation(securityBefore);
        String firstName = request.firstName().trim();
        String lastName = request.lastName().trim();

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        try {
            UserResource userResource = users.get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setFirstName(firstName);
            rep.setLastName(lastName);

            if (request.newPassword() != null && !request.newPassword().isBlank()) {
                boolean reqPassChange = Boolean.TRUE.equals(request.requirePasswordChange());
                setInitialPassword(users, user.getKeycloakUserId(), request.newPassword().trim(), reqPassChange);
            } else if (request.requirePasswordChange() != null) {
                List<String> actions = rep.getRequiredActions();
                if (actions == null) {
                    actions = new java.util.ArrayList<>();
                }
                if (Boolean.TRUE.equals(request.requirePasswordChange())) {
                    if (!actions.contains("UPDATE_PASSWORD")) {
                        actions.add("UPDATE_PASSWORD");
                    }
                } else {
                    actions.remove("UPDATE_PASSWORD");
                }
                rep.setRequiredActions(actions);
            }

            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al actualizar usuario {} en Keycloak", user.getEmail(), exception);
            throw new UserProvisioningException("No fue posible sincronizar la actualización en Keycloak", exception);
        }

        user.setFirstName(firstName);
        user.setLastName(lastName);

        if (request.areaId() != null) {
            Area currentArea = user.getArea();
            if (currentArea == null || !currentArea.getId().equals(request.areaId())) {
                Area newArea = areaRepository.findById(request.areaId())
                        .orElseThrow(() -> new IllegalArgumentException("El área especificada no existe"));
                if (!newArea.isActivo()) {
                    throw new IllegalArgumentException("No se puede asignar un usuario a un área inactiva");
                }
                user.setArea(newArea);
                auditService.registerUserManagementEvent(
                        "CAMBIAR_AREA_USUARIO",
                        user,
                        "Usuario " + user.getEmail() + " reasignado de área '" +
                                (currentArea != null ? currentArea.getNombre() : "Sin Área") + "' a '" + newArea.getNombre() + "'"
                );
            }
        }

        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String auditDetalle = "Usuario actualizado: " + saved.getEmail() + " (" + firstName + " " + lastName + ")";
        if (request.newPassword() != null && !request.newPassword().isBlank()) {
            auditDetalle += " [Contraseña restablecida]";
        }
        auditService.registerUserManagementEvent(
                "ACTUALIZAR_USUARIO",
                saved,
                auditDetalle
        );

        return rbac.response(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public UserResponse toggleUserStatus(UUID id, boolean enabled) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);

        if (!enabled) rbac.protectAccountRemoval(user);
        user.setEnabled(enabled);
        user.incrementVersionAcceso();
        userAccountRepository.flush();
        rbac.finishMutation(securityBefore);
        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        try {
            UserResource userResource = realm.users().get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setEnabled(enabled);
            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al cambiar estado de usuario {} en Keycloak a enabled={}", user.getEmail(), enabled, exception);
            throw new UserProvisioningException("No fue posible cambiar el estado del usuario en Keycloak", exception);
        }

        user.setEnabled(enabled);
        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String tipo = enabled ? "ACTIVAR_USUARIO" : "DESACTIVAR_USUARIO";
        String detalle = (enabled ? "Cuenta activada" : "Cuenta desactivada") + " para " + saved.getEmail();
        auditService.registerUserManagementEvent(tipo, saved, detalle);

        return rbac.response(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public void deleteUser(UUID id) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);
        rbac.protectAccountDeletion(user);

        String email = user.getEmail();
        String keycloakUserId = user.getKeycloakUserId();

        auditService.registerUserManagementEvent(
                "ELIMINAR_USUARIO",
                user,
                "Usuario eliminado: " + email
        );

        userAccountRepository.delete(user);
        userAccountRepository.flush();
        rbac.finishMutation(securityBefore);

        try {
            RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
            realm.users().delete(keycloakUserId).close();
            log.info("Usuario {} eliminado exitosamente de Keycloak", email);
        } catch (RuntimeException exception) {
            log.warn("No fue posible eliminar usuario {} de Keycloak o ya fue removido: {}", email, exception.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<UserResponse> listUsers() {
        return userAccountRepository.findAllByOrderByEmailAsc().stream()
                .map(user -> rbac.response(
                        user,
                        keycloakLockStatusClient.isTemporarilyLocked(user.getKeycloakUserId())
                ))
                .toList();
    }

    @Transactional
    public int synchronizeExistingUsers() {
        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        int synchronizedUsers = 0;

        for (UserRepresentation representation : users.list()) {
            String email = normalizeEmail(representation);
            if (email == null
                    || userAccountRepository.existsByEmailIgnoreCase(email)
                    || userAccountRepository.existsByKeycloakUserId(representation.getId())) {
                continue;
            }

            // Importar una identidad no concede privilegios por los roles remotos.
            Set<SystemRole> roles = Set.of();
            UserAccount account = new UserAccount(
                    representation.getId(),
                    email,
                    valueOrEmpty(representation.getFirstName()),
                    valueOrEmpty(representation.getLastName()),
                    Boolean.TRUE.equals(representation.isEnabled()),
                    resolveRolFlujoEntities(roles)
            );
            userAccountRepository.save(account);
            synchronizedUsers++;
        }

        userAccountRepository.flush();
        return synchronizedUsers;
    }

    private Set<RolFlujo> resolveRolFlujoEntities(Set<SystemRole> systemRoles) {
        if (systemRoles == null || systemRoles.isEmpty()) {
            return new LinkedHashSet<>();
        }
        Set<RolFlujo> rolEntities = new LinkedHashSet<>();
        for (SystemRole role : systemRoles) {
            for (String code : role == SystemRole.APPROVER ? List.of("EMISOR", "REVISOR") : List.of("ADMIN")) {
                RolFlujo rolFlujo = rolFlujoRepository.findByNombreIgnoreCase(code)
                        .filter(RolFlujo::isActivo).orElseThrow(
                                () -> com.capstone.sistema.rbac.exception.RbacException.invalid("El rol base no está disponible"));
                rolEntities.add(rolFlujo);
            }
        }
        return rolEntities;
    }

    private String createInKeycloak(UsersResource users, UserRepresentation representation, String email) {
        try (Response response = users.create(representation)) {
            if (response.getStatus() == Response.Status.CONFLICT.getStatusCode()) {
                throw new UserAlreadyExistsException(email);
            }
            if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
                throw new UserProvisioningException(
                        "Keycloak rechazó la creación de la cuenta con estado HTTP " + response.getStatus()
                );
            }
            return CreatedResponseUtil.getCreatedId(response);
        } catch (UserAlreadyExistsException | UserProvisioningException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            throw new UserProvisioningException("No fue posible conectar con Keycloak", exception);
        }
    }

    private void setInitialPassword(
            UsersResource users,
            String keycloakUserId,
            String password,
            boolean requirePasswordChange
    ) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(password);
        credential.setTemporary(requirePasswordChange);
        users.get(keycloakUserId).resetPassword(credential);
    }

    private void deleteKeycloakUserQuietly(UsersResource users, String keycloakUserId, String email) {
        try {
            users.delete(keycloakUserId).close();
            log.warn("Se eliminó de Keycloak la cuenta {} porque no pudo persistirse completamente", email);
        } catch (RuntimeException exception) {
            log.error("No fue posible compensar la creación incompleta de la cuenta {}", email, exception);
        }
    }

    private String normalizeEmail(UserRepresentation representation) {
        if (representation.getEmail() == null || representation.getEmail().isBlank()) {
            return null;
        }
        return representation.getEmail().trim().toLowerCase(Locale.ROOT);
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value.trim();
    }

    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public void changePassword(com.capstone.sistema.users.dto.ChangePasswordRequest request) {
        passwordChanges.change(request);
    }

    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public com.capstone.sistema.users.dto.PasswordPolicyResponse passwordPolicy() {
        return passwordChanges.policy();
    }
}
