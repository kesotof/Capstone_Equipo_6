package com.capstone.sistema.flow.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.util.List;

public record ConfigurarEtapasRequest(
        @NotEmpty(message = "Debe enviar al menos una etapa para el flujo")
        List<@NotNull @Valid EtapaConfigItem> etapas,
        @NotNull @PositiveOrZero Long version
) {
    public ConfigurarEtapasRequest(List<EtapaConfigItem> etapas) { this(etapas, null); }
}
