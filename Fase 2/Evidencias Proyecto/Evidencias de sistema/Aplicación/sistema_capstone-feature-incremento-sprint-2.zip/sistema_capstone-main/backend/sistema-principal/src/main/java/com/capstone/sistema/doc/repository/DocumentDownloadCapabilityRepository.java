package com.capstone.sistema.doc.repository;

import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

@Repository
public class DocumentDownloadCapabilityRepository {
    private final EntityManager entityManager;

    public DocumentDownloadCapabilityRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Set<UUID> authorizedIds(List<UUID> pageIds, Specification<Solicitud> permission) {
        if (pageIds.isEmpty()) return Set.of();
        var builder = entityManager.getCriteriaBuilder();
        var query = builder.createQuery(UUID.class);
        var root = query.from(Solicitud.class);
        query.select(root.get("id")).distinct(true).where(root.get("id").in(pageIds),
                permission.toPredicate(root, query, builder));
        return Set.copyOf(entityManager.createQuery(query).getResultList());
    }
}
