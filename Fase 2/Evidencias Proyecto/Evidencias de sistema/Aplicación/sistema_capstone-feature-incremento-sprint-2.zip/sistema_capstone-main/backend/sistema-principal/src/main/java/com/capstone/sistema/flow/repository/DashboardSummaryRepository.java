package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.JoinType;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import java.time.Instant;
import java.util.List;

/** Agregados escalares: no materializa solicitudes ni multiplica filas mediante joins de colecciones. */
@Repository
public class DashboardSummaryRepository {
    private final EntityManager entityManager;
    public DashboardSummaryRepository(EntityManager entityManager) { this.entityManager = entityManager; }

    public record StateCount(Long areaId, String state, long count) {}
    public record DayCount(int day, long count) {}

    public List<StateCount> states(Specification<Solicitud> visibility) {
        var cb = entityManager.getCriteriaBuilder();
        var query = cb.createTupleQuery();
        var request = query.from(Solicitud.class);
        Expression<Long> area = cb.coalesce(request.<Long>get("areaOrigenId"), request.<Long>get("areaFlujoId"));
        Expression<String> state = cb.upper(request.join("estadoSolicitud", JoinType.LEFT).get("codigo"));
        query.multiselect(area, state, cb.count(request)).where(visibility.toPredicate(request, query, cb))
                .groupBy(area, state);
        return entityManager.createQuery(query).getResultList().stream()
                .map(row -> new StateCount(row.get(0, Long.class), row.get(1, String.class), row.get(2, Long.class))).toList();
    }

    public List<DayCount> emissions(Specification<Solicitud> visibility, List<Instant> boundaries) {
        var cb = entityManager.getCriteriaBuilder();
        var query = cb.createTupleQuery();
        var request = query.from(Solicitud.class);
        var created = request.<Instant>get("createdAt");
        var columns = new java.util.ArrayList<jakarta.persistence.criteria.Selection<?>>();
        for (int day = 0; day < 7; day++) {
            columns.add(cb.sum(cb.<Long>selectCase().when(
                    cb.and(cb.greaterThanOrEqualTo(created, boundaries.get(day)),
                            cb.lessThan(created, boundaries.get(day + 1))), 1L).otherwise(0L)));
        }
        query.multiselect(columns).where(
                visibility.toPredicate(request, query, cb),
                cb.greaterThanOrEqualTo(created, boundaries.get(0)), cb.lessThan(created, boundaries.get(7)));
        var row = entityManager.createQuery(query).getSingleResult();
        return java.util.stream.IntStream.range(0, 7).mapToObj(day -> {
            Long count = row.get(day, Long.class);
            return new DayCount(day, count == null ? 0 : count);
        }).toList();
    }
}
