package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record SolicitudResponse(
        UUID id,
        String correlativo,
        String titulo,
        String tipoDocumento,
        String descripcion,
        String estado,
        UUID emisorId,
        String emisorNombre,
        String emisorEmail,
        DocumentoResponse documentoVigente,
        Instant deadline,
        String slaStatus,
        Instant createdAt,
        Instant updatedAt,
        java.util.List<String> accionesPermitidas,
        Long version,
        EtapaSolicitudResponse etapaActual
) {
    public SolicitudResponse(UUID id, String correlativo, String titulo, String descripcion, String estado, UUID emisorId,
                             String emisorNombre, String emisorEmail, DocumentoResponse documentoVigente, Instant deadline,
                             String slaStatus, Instant createdAt, Instant updatedAt, java.util.List<String> accionesPermitidas,
                             Long version, EtapaSolicitudResponse etapaActual) {
        this(id, correlativo, titulo, null, descripcion, estado, emisorId, emisorNombre, emisorEmail, documentoVigente, deadline, slaStatus, createdAt, updatedAt, accionesPermitidas, version, etapaActual);
    }
    public SolicitudResponse(UUID id, String correlativo, String titulo, String descripcion, String estado, UUID emisorId,
                             String emisorNombre, String emisorEmail, DocumentoResponse documentoVigente, Instant deadline,
                             String slaStatus, Instant createdAt, Instant updatedAt, java.util.List<String> accionesPermitidas) {
        this(id, correlativo, titulo, null, descripcion, estado, emisorId, emisorNombre, emisorEmail, documentoVigente, deadline, slaStatus, createdAt, updatedAt, accionesPermitidas, null, null);
    }
    public SolicitudResponse(UUID id, String correlativo, String titulo, String descripcion, String estado, UUID emisorId,
                             String emisorNombre, String emisorEmail, DocumentoResponse documentoVigente, Instant deadline,
                             String slaStatus, Instant createdAt, Instant updatedAt) {
        this(id, correlativo, titulo, null, descripcion, estado, emisorId, emisorNombre, emisorEmail, documentoVigente, deadline, slaStatus, createdAt, updatedAt, java.util.List.of(), null, null);
    }
    public SolicitudResponse(
            UUID id,
            String titulo,
            String descripcion,
            String estado,
            UUID emisorId,
            String emisorNombre,
            String emisorEmail,
            DocumentoResponse documentoVigente,
            Instant createdAt,
            Instant updatedAt
    ) {
        this(id, null, titulo, null, descripcion, estado, emisorId, emisorNombre, emisorEmail, documentoVigente, null, null, createdAt, updatedAt, java.util.List.of(), null, null);
    }
}
