package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class DocumentDownloadRepository {
    private static final String SELECT = """
            select id, solicitud_id, nombre_archivo, content_type, storage_key, size_bytes, version
            from documento
            """;
    private final JdbcTemplate jdbc;

    public DocumentDownloadRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<DocumentDownloadTarget> byId(UUID id) {
        return query(SELECT + " where id=?", id);
    }

    public List<DocumentDownloadTarget> current(UUID solicitudId) {
        return query(SELECT + " where solicitud_id=? and vigente=true order by id limit 2", solicitudId);
    }

    public List<DocumentDownloadTarget> byKey(String key) {
        return query(SELECT + " where storage_key=? order by id limit 2", key);
    }

    private List<DocumentDownloadTarget> query(String sql, Object parameter) {
        return jdbc.query(sql, (rs, row) -> new DocumentDownloadTarget(
                rs.getObject("id", UUID.class), rs.getObject("solicitud_id", UUID.class),
                rs.getString("nombre_archivo"), rs.getString("content_type"), rs.getString("storage_key"),
                rs.getObject("size_bytes", Long.class), rs.getInt("version")), parameter);
    }
}
