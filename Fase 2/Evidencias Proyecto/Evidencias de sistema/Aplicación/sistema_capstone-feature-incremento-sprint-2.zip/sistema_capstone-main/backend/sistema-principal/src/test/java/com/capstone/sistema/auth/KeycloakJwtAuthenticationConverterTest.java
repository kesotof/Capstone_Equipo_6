package com.capstone.sistema.auth;

import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.InvalidBearerTokenException;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class KeycloakJwtAuthenticationConverterTest {

    @Test
    void convertsRealmRolesAndUsesEmailAsPrincipal() {
        UserAccountRepository repository = mock(UserAccountRepository.class);
        when(repository.findByKeycloakUserId("keycloak-admin"))
                .thenReturn(Optional.of(activeUser("keycloak-admin")));
        KeycloakJwtAuthenticationConverter converter = new KeycloakJwtAuthenticationConverter(repository);
        Jwt jwt = jwt("keycloak-admin", "admin@capstone.local", Map.of("roles", List.of("ADMIN", "APPROVER")));

        AbstractAuthenticationToken authentication = converter.convert(jwt);

        assertThat(authentication).isNotNull();
        assertThat(authentication.getName()).isEqualTo("admin@capstone.local");
        assertThat(authentication.getAuthorities())
                .extracting("authority")
                .containsExactlyInAnyOrder("ROLE_ADMIN", "ROLE_APPROVER");
    }

    @Test
    void supportsTokensWithoutRealmRoles() {
        UserAccountRepository repository = mock(UserAccountRepository.class);
        when(repository.findByKeycloakUserId("keycloak-user"))
                .thenReturn(Optional.of(activeUser("keycloak-user")));
        KeycloakJwtAuthenticationConverter converter = new KeycloakJwtAuthenticationConverter(repository);
        Jwt jwt = jwt("keycloak-user", null, null);

        AbstractAuthenticationToken authentication = converter.convert(jwt);

        assertThat(authentication).isNotNull();
        assertThat(authentication.getName()).isEqualTo("usuario");
        assertThat(authentication.getAuthorities()).isEmpty();
    }

    @Test
    void rejectsTokenWhenUserDoesNotExistInPostgresql() {
        UserAccountRepository repository = mock(UserAccountRepository.class);
        when(repository.findByKeycloakUserId("deleted-user")).thenReturn(Optional.empty());
        KeycloakJwtAuthenticationConverter converter = new KeycloakJwtAuthenticationConverter(repository);

        assertThatThrownBy(() -> converter.convert(jwt("deleted-user", "deleted@capstone.local", null)))
                .isInstanceOf(InvalidBearerTokenException.class);
    }

    @Test
    void rejectsTokenWhenUserIsDisabledInPostgresql() {
        UserAccountRepository repository = mock(UserAccountRepository.class);
        when(repository.findByKeycloakUserId("disabled-user"))
                .thenReturn(Optional.of(new UserAccount(
                        "disabled-user", "disabled@capstone.local", "Usuario", "Inactivo", false, Set.of()
                )));
        KeycloakJwtAuthenticationConverter converter = new KeycloakJwtAuthenticationConverter(repository);

        assertThatThrownBy(() -> converter.convert(jwt("disabled-user", "disabled@capstone.local", null)))
                .isInstanceOf(InvalidBearerTokenException.class);
    }

    private Jwt jwt(String subject, String email, Map<String, Object> realmAccess) {
        var builder = Jwt.withTokenValue("token")
                .header("alg", "none")
                .subject(subject)
                .claim("preferred_username", "usuario");
        if (email != null) {
            builder.claim("email", email);
        }
        if (realmAccess != null) {
            builder.claim("realm_access", realmAccess);
        }
        return builder.build();
    }

    private UserAccount activeUser(String keycloakUserId) {
        return new UserAccount(keycloakUserId, "usuario@capstone.local", "Usuario", "Activo", true, Set.of());
    }
}
