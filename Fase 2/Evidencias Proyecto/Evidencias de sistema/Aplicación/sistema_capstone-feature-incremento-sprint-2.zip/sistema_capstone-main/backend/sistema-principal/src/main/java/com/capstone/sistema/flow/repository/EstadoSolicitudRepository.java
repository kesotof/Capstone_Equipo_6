package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.EstadoSolicitud;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EstadoSolicitudRepository extends JpaRepository<EstadoSolicitud, Long> {

    Optional<EstadoSolicitud> findByCodigoIgnoreCase(String codigo);
}
