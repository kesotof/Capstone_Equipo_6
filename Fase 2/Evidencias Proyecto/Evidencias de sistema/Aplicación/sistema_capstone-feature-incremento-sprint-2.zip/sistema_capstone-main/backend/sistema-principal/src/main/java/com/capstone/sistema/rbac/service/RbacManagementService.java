package com.capstone.sistema.rbac.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.service.FlujoReviewerResolver;
import com.capstone.sistema.org.area.service.AreaCatalogLock;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.*;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.mapper.UserMapper;
import com.capstone.sistema.users.model.*;
import com.capstone.sistema.users.repository.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class RbacManagementService {
    private final JdbcTemplate jdbc;
    private final RbacAccessService access;
    private final AreaCatalogLock areaLock;
    private final UserAccountRepository users;
    private final RolFlujoRepository roles;
    private final SolicitudRepository solicitudes;
    private final FlujoEtapaRepository stages;
    private final FlujoReviewerResolver reviewers;
    private final AuditService audit;
    private final ObjectMapper json;
    private final jakarta.persistence.EntityManager entityManager;

    public RbacManagementService(JdbcTemplate jdbc, RbacAccessService access, AreaCatalogLock areaLock,
            UserAccountRepository users, RolFlujoRepository roles, SolicitudRepository solicitudes,
            AuditService audit, ObjectMapper json, jakarta.persistence.EntityManager entityManager,
            FlujoEtapaRepository stages, FlujoReviewerResolver reviewers) {
        this.jdbc=jdbc; this.access=access; this.areaLock=areaLock; this.users=users; this.roles=roles;
        this.solicitudes=solicitudes; this.audit=audit; this.json=json;
        this.entityManager=entityManager; this.stages=stages; this.reviewers=reviewers;
    }

    /** Orden común: catálogo de áreas, control RBAC, entidades. El lock vive hasta el commit. */
    @Transactional
    public Set<String> prepareMutation() {
        lockPolicy();
        return dependencyViolations();
    }

    @Transactional
    public void lockPolicy() {
        areaLock.acquire();
        jdbc.queryForObject("select version_politica from rbac_control where id=1 for update",Long.class);
        access.clearContext();
    }
    @Transactional
    public void finishMutation(Set<String> previous) {
        entityManager.flush();
        Set<String> violations=dependencyViolations();
        violations.removeAll(previous);
        if (!violations.isEmpty()) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "El cambio dejaría flujos activos o revisiones pendientes sin un revisor autorizado.");
        jdbc.update("update rbac_control set version_politica=version_politica+1 where id=1");
    }
    private Set<String> dependencyViolations() {
        Set<String> result=new HashSet<>();
        var reviewerIds=jdbc.query("select distinct e.revisor_id from flujo_etapa e join flujo_definicion f on f.id=e.flujo_definicion_id where f.activo=true and e.revisor_id is not null",
                (rs,n)->(UUID)rs.getObject(1));
        for (UUID id:reviewerIds) {
            UserAccount user=users.findById(id).orElse(null);
            if (user==null) { result.add("FLOW:"+id+":CUENTA"); continue; }
            AccessContext c=access.forUser(user);
            if(!user.isEnabled()) result.add("FLOW:"+id+":CUENTA");
            if(!c.jerarquiaValida()) result.add("FLOW:"+id+":JERARQUIA");
            for(Permiso p:List.of(Permiso.SOLICITUD_CONSULTAR,Permiso.REVISION_CONSULTAR,
                    Permiso.SOLICITUD_APROBAR,Permiso.SOLICITUD_RECHAZAR,Permiso.SOLICITUD_PEDIR_CORRECCION)) {
                boolean allowed=c.has(p);
                if(p==Permiso.SOLICITUD_CONSULTAR) allowed=c.scopes(p).contains(Alcance.ASIGNADAS)
                        || (c.admin() && c.scopes(p).contains(Alcance.GLOBAL));
                if(!allowed) result.add("FLOW:"+id+":"+p);
            }
        }
        var pending=jdbc.query("select s.id,e.revisor_id from solicitud s join estado_solicitud st on st.id=s.estado_solicitud_id join flujo_etapa e on e.id=s.flujo_etapa_id where upper(st.codigo) in ('PENDIENTE_REVISION','CORRECCION_REQUERIDA','REQUIERE_AJUSTES') and e.revisor_id is not null",
                (rs,n)->Map.entry((UUID)rs.getObject(1),(UUID)rs.getObject(2)));
        for (var entry:pending) {
            UserAccount reviewer=users.findById(entry.getValue()).orElse(null);
            if (reviewer==null || !reviewer.isEnabled()) { result.add("REQUEST:"+entry.getKey()+":CUENTA"); continue; }
            AccessContext c=access.forUser(reviewer);
            for (Permiso p:List.of(Permiso.SOLICITUD_APROBAR,Permiso.SOLICITUD_RECHAZAR,Permiso.SOLICITUD_PEDIR_CORRECCION)) {
                if (solicitudes.count(access.visible(c,p).and(access.visible(c,Permiso.SOLICITUD_CONSULTAR))
                        .and((r,q,b)->b.equal(r.get("id"),entry.getKey())))==0) result.add("REQUEST:"+entry.getKey()+":"+p);
            }
        }
        for (var stage:stages.findAll()) {
            if (stage.getFlujoDefinicion().isActivo() && !FlujoReviewerResolver.isDynamicBase(stage)
                    && reviewers.candidates(stage).isEmpty()) result.add("STEP:"+stage.getId()+":RESPONSABLE");
        }
        for (var request:solicitudes.findOpenByFlow(null)) {
            if (request.getFlujoEtapa()==null) { result.add("REQUEST:"+request.getId()+":ETAPA"); continue; }
            for (var stage:request.getFlujoDefinicion().getEtapas()) {
                if (stage.getOrden()>=request.getFlujoEtapa().getOrden() && reviewers.forRequest(request,stage).isEmpty())
                    result.add("REQUEST:"+request.getId()+":STEP:"+stage.getId());
            }
        }
        return result;
    }
    public List<Permission> permissions() {
        access.require(Permiso.ROL_GESTIONAR);
        return Arrays.stream(Permiso.values()).map(p->new Permission(p.name(),p.name().replace('_',' '),
                "Acción "+p.name(),p.reservado(),p.alcancesPermitidos())).toList();
    }
    public Page<Role> list(int page,int size,String q,Boolean active) {
        access.require(Permiso.ROL_GESTIONAR);
        if(page<0 || size<1 || size>100 || (q!=null && (q.length()>100 || q.indexOf(0)>=0))) throw RbacException.invalid("Paginación o búsqueda inválida.");
        String pattern=q==null?"%":"%"+q.trim().replace("!","!!").replace("%","!%").replace("_","!_")+"%";
        String where=" where (?::boolean is null or activo=?::boolean) and (nombre ilike ? escape '!' or nombre_visible ilike ? escape '!')";
        long total=jdbc.queryForObject("select count(*) from rol_flujo"+where,Long.class,active,active,pattern,pattern);
        List<Long> ids=jdbc.query("select id from rol_flujo"+where+" order by lower(nombre_visible),id limit ? offset ?",
                (rs,n)->rs.getLong(1),active,active,pattern,pattern,size,(long)page*size);
        return new Page<>(ids.stream().map(this::role).toList(),page,size,total,(total+size-1)/size,page==0,(long)(page+1)*size>=total);
    }
    public Role role(Long id) {
        access.require(Permiso.ROL_GESTIONAR);
        List<Role> result=jdbc.query("select * from rol_flujo where id=?", (rs,n)->new Role(rs.getLong("id"),
                rs.getString("nombre"),rs.getString("nombre_visible"),rs.getString("descripcion"),rs.getBoolean("activo"),
                rs.getBoolean("sistema"),"AREA_ADMIN".equals(rs.getString("nombre"))?"DERIVADA_AREA":"EXPLICITA",
                rs.getLong("version"),grants(id),rs.getTimestamp("created_at").toInstant(),rs.getTimestamp("updated_at").toInstant()),id);
        if(result.isEmpty()) throw RbacException.missing();
        return result.get(0);
    }
    private List<Grant> grants(Long role) {
        Map<String,Set<Alcance>> values=new TreeMap<>();
        jdbc.query("select p.codigo,rp.alcance from rol_permiso rp join permiso p on p.id=rp.permiso_id where rp.rol_id=?",
                rs->{values.computeIfAbsent(rs.getString(1), k->EnumSet.noneOf(Alcance.class)).add(Alcance.valueOf(rs.getString(2)));},role);
        return values.entrySet().stream().map(e->new Grant(e.getKey(),e.getValue().stream().sorted().toList())).toList();
    }
    @Transactional
    public Role create(RoleCreate request) {
        access.require(Permiso.ROL_GESTIONAR);
        var before=prepareMutation();
        String name=validateName(request.nombre());
        validateGrants(request.permisos(),false);
        checkUnique(request.codigo(),name,null);
        Long id=jdbc.queryForObject("insert into rol_flujo(nombre,nombre_visible,descripcion) values(?,?,?) returning id",
                Long.class,request.codigo(),name,validateDescription(request.descripcion()));
        replaceGrants(id,request.permisos());
        finishMutation(before);
        Role result=role(id); auditChange("CREAR_ROL",id,null,result);
        return result;
    }
    @Transactional
    public Role update(Long id, RoleUpdate request) {
        access.require(Permiso.ROL_GESTIONAR);
        var before=prepareMutation(); Role previous=role(id); checkVersion(previous.version(),request.version());
        String name=validateName(request.nombre());
        if(Set.of("ADMIN","AREA_ADMIN","APPROVER").contains(previous.codigo())) throw RbacException.conflict("RBAC_ROL_PROTEGIDO","Este rol tiene una política protegida.");
        validateGrants(request.permisos(),false); checkUnique(previous.codigo(),name,id);
        jdbc.update("update rol_flujo set nombre_visible=?,descripcion=?,version=version+1,updated_at=current_timestamp where id=?",name,validateDescription(request.descripcion()),id);
        replaceGrants(id,request.permisos()); finishMutation(before);
        Role result=role(id); auditChange("ACTUALIZAR_ROL",id,previous,result); return result;
    }
    @Transactional
    public Role status(Long id,Status request) {
        access.require(Permiso.ROL_GESTIONAR); var before=prepareMutation(); Role previous=role(id);
        checkVersion(previous.version(),request.version());
        if(Set.of("ADMIN","AREA_ADMIN","APPROVER").contains(previous.codigo())) throw RbacException.conflict("RBAC_ROL_PROTEGIDO","No se puede cambiar el estado de este rol.");
        if(!request.activo() && jdbc.queryForObject("select count(*) from usuario_rol where rol_id=?",Long.class,id)>0)
            throw RbacException.conflict("RBAC_ROL_EN_USO","Retire o reasigne las membresías antes de desactivar el rol.");
        jdbc.update("update rol_flujo set activo=?,version=version+1,updated_at=current_timestamp where id=?",request.activo(),id);
        finishMutation(before); Role result=role(id); auditChange("CAMBIAR_ESTADO_ROL",id,previous,result); return result;
    }
    private static String validateName(String value) {
        String name=value.replaceAll("^ +| +$", "");
        if(name.isBlank() || name.codePointCount(0,name.length())>100 || name.codePoints().anyMatch(Character::isISOControl)) throw RbacException.invalid("Nombre de rol inválido.");
        return name;
    }
    private static String validateDescription(String value) {
        if(value==null) return null;
        String description=value.replaceAll("^ +| +$", "");
        if(description.codePointCount(0,description.length())>1000 || description.indexOf(0)>=0)
            throw RbacException.invalid("La descripción admite hasta 1000 caracteres y no admite el carácter nulo.");
        return description.isEmpty()?null:description;
    }
    private void checkUnique(String code,String name,Long id) {
        if(jdbc.queryForObject("select count(*) from rol_flujo where (lower(nombre)=lower(?) or lower(btrim(nombre_visible))=lower(btrim(?))) and (?::bigint is null or id<>?::bigint)",
                Long.class,code,name,id,id)>0) throw RbacException.conflict("RBAC_ROL_DUPLICADO","El código o nombre del rol ya existe.");
    }
    private void validateGrants(List<Grant> grants,boolean admin) {
        Set<String> seen=new HashSet<>();
        for(Grant grant:grants) {
            Permiso p;
            try { p=Permiso.valueOf(grant.codigo()); } catch(IllegalArgumentException e) { throw RbacException.invalid("Permiso desconocido."); }
            if(!seen.add(grant.codigo()) || grant.alcances()==null || grant.alcances().isEmpty()
                    || new HashSet<>(grant.alcances()).size()!=grant.alcances().size()
                    || !p.alcancesPermitidos().containsAll(grant.alcances())) throw RbacException.invalid("Permisos o alcances inválidos.");
            if(!admin && (p.reservado() || grant.alcances().contains(Alcance.GLOBAL))) throw RbacException.conflict("RBAC_ROL_PROTEGIDO","Los permisos administrativos y el alcance GLOBAL son exclusivos de ADMIN.");
        }
    }
    private void replaceGrants(Long id,List<Grant> grants) {
        jdbc.update("delete from rol_permiso where rol_id=?",id);
        for(Grant grant:grants) for(Alcance scope:grant.alcances())
            jdbc.update("insert into rol_permiso select ?,id,? from permiso where codigo=?",id,scope.name(),grant.codigo());
    }
    public Set<RolFlujo> explicitRoles(List<Long> ids) {
        if(ids==null || ids.stream().anyMatch(i->i==null || i<=0) || new HashSet<>(ids).size()!=ids.size()) throw RbacException.invalid("Los roles deben tener IDs positivos y únicos.");
        Set<RolFlujo> result=new LinkedHashSet<>();
        for(Long id:ids) {
            RolFlujo role=roles.findById(id).orElseThrow(RbacException::missing);
            if(!role.isActivo()) throw RbacException.invalid("No puede asignar un rol inactivo.");
            if(Set.of("AREA_ADMIN","APPROVER").contains(role.getNombre())) throw RbacException.invalid("Este rol no admite asignación explícita.");
            result.add(role);
        }
        return result;
    }
    @Transactional
    public UserResponse membership(UUID id,Membership request) {
        access.require(Permiso.USUARIO_GESTIONAR); var before=prepareMutation();
        UserAccount user=users.findById(id).orElseThrow(RbacException::missing);
        entityManager.refresh(user); checkVersion(user.getVersionAcceso(),request.versionAcceso());
        var previous=user.getRolEntities().stream().map(RolFlujo::getId).sorted().toList();
        Set<RolFlujo> selected=explicitRoles(request.roleIds());
        if(selected.stream().noneMatch(r->r.getNombre().equals("ADMIN"))) protectLastAdmin(user);
        user.setRolEntities(selected); user.incrementVersionAcceso(); users.saveAndFlush(user);
        finishMutation(before); auditChange("CAMBIAR_ROLES_USUARIO",id,previous,request.roleIds()); return response(user,false);
    }
    @Transactional
    public UserResponse manager(UUID id,Manager request) {
        access.require(Permiso.USUARIO_GESTIONAR); var before=prepareMutation();
        UserAccount user=users.findById(id).orElseThrow(RbacException::missing);
        entityManager.refresh(user); checkVersion(user.getVersionAcceso(),request.versionAcceso());
        UUID previous=user.getJefaturaDirecta()==null?null:user.getJefaturaDirecta().getId();
        UserAccount manager=request.jefaturaDirectaId()==null?null:users.findById(request.jefaturaDirectaId()).orElseThrow(RbacException::missing);
        Set<UUID> chain=new HashSet<>();
        for(UserAccount next=manager;next!=null;next=next.getJefaturaDirecta()) {
            if(!next.isEnabled() || next.getId().equals(id) || !chain.add(next.getId())) throw RbacException.conflict("RBAC_JERARQUIA_INVALIDA","La jefatura debe estar activa y no puede crear ciclos.");
        }
        user.setJefaturaDirecta(manager); user.incrementVersionAcceso(); users.saveAndFlush(user);
        finishMutation(before); auditChange("CAMBIAR_JEFATURA_USUARIO",id,previous,request.jefaturaDirectaId()); return response(user,false);
    }
    public void protectLastAdmin(UserAccount user) {
        boolean admin=user.isEnabled() && user.getRolEntities().stream().anyMatch(r->r.isActivo() && r.getNombre().equals("ADMIN"));
        if(admin && jdbc.queryForObject("select count(distinct u.id) from usuario u join usuario_rol ur on ur.usuario_id=u.id join rol_flujo r on r.id=ur.rol_id where u.activo=true and r.activo=true and r.nombre='ADMIN'",Long.class)<=1)
            throw RbacException.conflict("RBAC_ULTIMO_ADMIN","Debe conservar al menos un administrador general activo.");
    }
    public void protectAccountRemoval(UserAccount user) {
        protectLastAdmin(user);
        long refs=jdbc.queryForObject("select (select count(*) from usuario where jefatura_directa_id=?)+(select count(*) from area where administrador_id=? and activo=true)",Long.class,user.getId(),user.getId());
        if(refs>0) throw RbacException.conflict("RBAC_JERARQUIA_INVALIDA","Reasigne las jefaturas y áreas administradas antes de desactivar o eliminar esta cuenta.");
    }
    public void protectAccountDeletion(UserAccount user) {
        protectAccountRemoval(user);
        if(user.getId().equals(access.context().usuarioId())) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "No puede eliminar la cuenta de la sesión actual; su identidad debe conservarse en la auditoría.");
        for (String reference : List.of("solicitud:usuario_id","solicitud_transicion:usuario_id","observacion:usuario_id",
                "notificacion:usuario_id","ai_analysis:solicitado_por_id","log_evento:usuario_id","flujo_etapa:revisor_id",
                "flujo_etapa_roles:usuario_id","area:administrador_id")) {
            String[] parts=reference.split(":");
            Long count=jdbc.queryForObject("select count(*) from "+parts[0]+" where "+parts[1]+"=?",Long.class,user.getId());
            if(count>0) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                    "La cuenta conserva referencias operativas o históricas. Reasigne sus responsabilidades y desactívela para preservar la trazabilidad.");
        }
    }
    private void checkVersion(long current,Long requested) {
        if(requested==null || requested<0) throw RbacException.invalid("Envíe una versión no negativa.");
        if(current!=requested) throw RbacException.conflict("RBAC_VERSION_DESACTUALIZADA","Los datos cambiaron. Recargue antes de editar.");
    }
    public void auditChange(String type,Object id,Object before,Object after) {
        Map<String,Object> data=new LinkedHashMap<>(); data.put("recursoId",id);data.put("antes",before);data.put("despues",after);
        try { audit.registerUserManagementEvent(type,json.writeValueAsString(data)); }
        catch(JsonProcessingException e) { throw new IllegalStateException("No fue posible serializar la auditoría RBAC",e); }
    }
    public UserResponse response(UserAccount user,boolean locked) {
        return UserMapper.toResponse(user,locked,access.forUser(user).roles());
    }
}

