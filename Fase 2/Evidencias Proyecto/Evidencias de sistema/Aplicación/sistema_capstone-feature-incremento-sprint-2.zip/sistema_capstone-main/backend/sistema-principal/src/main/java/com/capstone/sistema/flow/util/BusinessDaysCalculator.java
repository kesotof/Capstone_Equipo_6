package com.capstone.sistema.flow.util;

import java.time.DayOfWeek;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public final class BusinessDaysCalculator {

    private static final ZoneId DEFAULT_ZONE = ZoneId.of("America/Santiago");

    private BusinessDaysCalculator() {
    }

    /**
     * Calcula la fecha y hora límite sumando N días hábiles a partir de la fecha de inicio,
     * omitiendo sábados y domingos.
     *
     * @param start        Fecha de inicio
     * @param businessDays Cantidad de días hábiles a sumar
     * @return Instant con la fecha límite calculada
     */
    public static Instant calculateDeadline(Instant start, int businessDays) {
        if (start == null || businessDays <= 0) {
            return start;
        }

        try {
            ZonedDateTime localStart = start.atZone(DEFAULT_ZONE);
            LocalDate date = localStart.toLocalDate();
            int remaining = businessDays;
            if (date.getDayOfWeek() == DayOfWeek.SATURDAY) {
                date = date.plusDays(2);
                remaining--;
            } else if (date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                date = date.plusDays(1);
                remaining--;
            }
            // Semanas completas en tiempo constante; solo quedan hasta cuatro días hábiles.
            date = date.plusDays((remaining / 5L) * 7L);
            remaining %= 5;
            while (remaining > 0) {
                date = date.plusDays(1);
                DayOfWeek day = date.getDayOfWeek();
                if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) remaining--;
            }
            if (date.getYear() > 294276 || date.getYear() < -4712) {
                throw new IllegalArgumentException("El plazo SLA excede el rango de fechas admitido por PostgreSQL");
            }
            // Resolver el offset solo en la fecha final evita propagar saltos de hora de un domingo.
            ZonedDateTime result = date.atTime(localStart.toLocalTime()).atZone(DEFAULT_ZONE);
            if (result.withZoneSameInstant(ZoneOffset.UTC).getYear() > 294276) {
                throw new IllegalArgumentException("El plazo SLA excede el rango de fechas admitido por PostgreSQL");
            }
            return result.toInstant();
        } catch (DateTimeException | ArithmeticException ex) {
            throw new IllegalArgumentException("El plazo SLA no permite representar una fecha límite válida", ex);
        }
    }
}
