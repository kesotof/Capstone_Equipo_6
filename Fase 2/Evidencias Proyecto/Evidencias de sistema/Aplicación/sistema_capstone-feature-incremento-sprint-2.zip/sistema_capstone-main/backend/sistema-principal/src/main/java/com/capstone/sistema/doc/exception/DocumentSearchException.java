package com.capstone.sistema.doc.exception;

import org.springframework.http.HttpStatus;

public class DocumentSearchException extends RuntimeException {
    private final HttpStatus status;
    private final String code;

    private DocumentSearchException(HttpStatus status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public static DocumentSearchException invalid(String message) {
        return new DocumentSearchException(HttpStatus.BAD_REQUEST, "DOCUMENT_SEARCH_INVALID_PARAMETERS", message);
    }

    public static DocumentSearchException inconsistentDocument() {
        return new DocumentSearchException(HttpStatus.CONFLICT, "DOCUMENT_SEARCH_INCONSISTENT_DOCUMENT",
                "Una solicitud del resultado tiene más de un documento vigente. Debe corregirse su información documental.");
    }

    public HttpStatus status() { return status; }
    public String code() { return code; }
}
