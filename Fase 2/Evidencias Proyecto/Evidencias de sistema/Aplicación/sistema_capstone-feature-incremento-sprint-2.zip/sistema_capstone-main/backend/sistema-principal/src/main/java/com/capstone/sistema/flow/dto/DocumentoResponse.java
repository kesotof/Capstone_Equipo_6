package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record DocumentoResponse(
        UUID id,
        String nombreArchivo,
        String contentType,
        Long sizeBytes,
        int version,
        boolean vigente,
        Instant createdAt
) {
}
