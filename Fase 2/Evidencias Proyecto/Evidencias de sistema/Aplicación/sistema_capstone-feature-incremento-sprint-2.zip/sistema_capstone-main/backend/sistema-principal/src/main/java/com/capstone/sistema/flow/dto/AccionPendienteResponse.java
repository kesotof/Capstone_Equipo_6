package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record AccionPendienteResponse(
        UUID solicitudId,
        String titulo,
        String tipoAccion,
        String descripcionAccion,
        String estadoActual,
        String emisorNombre,
        String emisorEmail,
        String nombreArchivo,
        int version,
        Instant fecha,
        String ultimaObservacion
) {
}
