package com.capstone.sistema.doc;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.io.ByteArrayInputStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DocController.class)
@Import(SecurityConfig.class)
class DocControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MinioStorageService storageService;

    @MockBean
    private com.capstone.sistema.audit.service.AuditService auditService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    void rejectsUnauthenticatedDownload() throws Exception {
        mockMvc.perform(get("/api/doc/download/archivo.pdf"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void rejectsUnauthenticatedUpload() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "dummy".getBytes());
        mockMvc.perform(multipart("/api/doc/upload").file(file))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void allowsAuthenticatedDownloadIntermediatedFromMinIO() throws Exception {
        when(storageService.downloadFile("archivo.pdf"))
                .thenReturn(new ByteArrayInputStream("contenido binario".getBytes()));

        mockMvc.perform(get("/api/doc/download/archivo.pdf")
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(header().string("Content-Disposition", "attachment; filename=\"archivo.pdf\""));
    }

    @Test
    void allowsAuthenticatedUploadIntermediatedToMinIO() throws Exception {
        when(storageService.uploadFile(any())).thenReturn("12345_test.xlsx");

        MockMultipartFile file = new MockMultipartFile(
                "file", "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "excel data".getBytes()
        );

        mockMvc.perform(multipart("/api/doc/upload")
                        .file(file)
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fileKey").value("12345_test.xlsx"));
    }

    @Test
    void uploadDocument_emptyFile_returnsBadRequest400() throws Exception {
        MockMultipartFile emptyFile = new MockMultipartFile("file", "vacio.pdf", "application/pdf", new byte[0]);

        mockMvc.perform(multipart("/api/doc/upload")
                        .file(emptyFile)
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("El archivo es obligatorio y no puede estar vacío"));
    }

    @Test
    void downloadDocument_fileNotFoundInMinIO_returnsNotFound404() throws Exception {
        io.minio.errors.ErrorResponseException minioEx = org.mockito.Mockito.mock(io.minio.errors.ErrorResponseException.class);
        io.minio.messages.ErrorResponse errorResponse = org.mockito.Mockito.mock(io.minio.messages.ErrorResponse.class);
        when(errorResponse.code()).thenReturn("NoSuchKey");
        when(minioEx.errorResponse()).thenReturn(errorResponse);

        when(storageService.downloadFile("inexistente.pdf")).thenThrow(minioEx);

        mockMvc.perform(get("/api/doc/download/inexistente.pdf")
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("Archivo no encontrado en almacenamiento: inexistente.pdf"));
    }
}
