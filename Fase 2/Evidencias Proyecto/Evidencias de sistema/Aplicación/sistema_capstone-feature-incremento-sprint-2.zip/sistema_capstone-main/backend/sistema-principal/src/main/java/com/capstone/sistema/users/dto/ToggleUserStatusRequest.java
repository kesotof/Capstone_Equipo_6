package com.capstone.sistema.users.dto;

import jakarta.validation.constraints.NotNull;

public record ToggleUserStatusRequest(
        @NotNull(message = "El estado enabled es obligatorio")
        Boolean enabled
) {
}
