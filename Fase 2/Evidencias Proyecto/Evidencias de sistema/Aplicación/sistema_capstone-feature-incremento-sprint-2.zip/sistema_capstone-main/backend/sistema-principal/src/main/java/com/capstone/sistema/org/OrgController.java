package com.capstone.sistema.org;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "Organización", description = "Consultas de configuración y estructura organizacional")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/org")
public class OrgController {

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> listUsers() {
        return ResponseEntity.ok(List.of(
                Map.of("id", 1, "username", "admin", "roles", List.of("ADMIN")),
                Map.of("id", 2, "username", "operador1", "roles", List.of("APPROVER"))
        ));
    }

    @GetMapping("/config")
    @PreAuthorize("hasAnyRole('ADMIN', 'APPROVER')")
    public ResponseEntity<?> getOrgConfig() {
        return ResponseEntity.ok(Map.of(
                "orgName", "Institución Capstone",
                "flowTimeoutHours", 48,
                "allowAutoApproval", false
        ));
    }
}
