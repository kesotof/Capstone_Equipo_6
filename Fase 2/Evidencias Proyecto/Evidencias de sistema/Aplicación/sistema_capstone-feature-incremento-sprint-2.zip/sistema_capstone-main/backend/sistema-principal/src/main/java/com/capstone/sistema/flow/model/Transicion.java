package com.capstone.sistema.flow.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "transicion", uniqueConstraints = {
        @UniqueConstraint(
                name = "unq_transicion_regla",
                columnNames = {"flujo_definicion_id", "estado_origen_id", "accion_usuario_id", "estado_destino_id"}
        )
})
public class Transicion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_definicion_id", nullable = false)
    private FlujoDefinicion flujoDefinicion;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "estado_origen_id")
    private EstadoSolicitud estadoOrigen;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "estado_destino_id", nullable = false)
    private EstadoSolicitud estadoDestino;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "accion_usuario_id", nullable = false)
    private AccionUsuario accionUsuario;

    protected Transicion() {
    }

    public Transicion(
            FlujoDefinicion flujoDefinicion,
            EstadoSolicitud estadoOrigen,
            EstadoSolicitud estadoDestino,
            AccionUsuario accionUsuario
    ) {
        this.flujoDefinicion = flujoDefinicion;
        this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.accionUsuario = accionUsuario;
    }

    public Long getId() {
        return id;
    }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public EstadoSolicitud getEstadoOrigen() {
        return estadoOrigen;
    }

    public void setEstadoOrigen(EstadoSolicitud estadoOrigen) {
        this.estadoOrigen = estadoOrigen;
    }

    public EstadoSolicitud getEstadoDestino() {
        return estadoDestino;
    }

    public void setEstadoDestino(EstadoSolicitud estadoDestino) {
        this.estadoDestino = estadoDestino;
    }

    public AccionUsuario getAccionUsuario() {
        return accionUsuario;
    }

    public void setAccionUsuario(AccionUsuario accionUsuario) {
        this.accionUsuario = accionUsuario;
    }
}
