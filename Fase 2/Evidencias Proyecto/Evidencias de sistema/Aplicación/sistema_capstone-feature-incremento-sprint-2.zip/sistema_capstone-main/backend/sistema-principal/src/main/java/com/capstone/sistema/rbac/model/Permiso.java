package com.capstone.sistema.rbac.model;

import java.util.Set;
import static com.capstone.sistema.rbac.model.Alcance.*;

public enum Permiso {
    ROL_GESTIONAR(true), USUARIO_GESTIONAR(true), AREA_GESTIONAR(true),
    AUDITORIA_CONSULTAR(true), SLA_GESTIONAR(true),
    FLUJO_GESTIONAR(false, AREAS_ADMINISTRADAS),
    SOLICITUD_CREAR(false, PROPIAS), SOLICITUD_REENVIAR(false, PROPIAS),
    SOLICITUD_APROBAR(false, ASIGNADAS), SOLICITUD_RECHAZAR(false, ASIGNADAS),
    SOLICITUD_PEDIR_CORRECCION(false, ASIGNADAS),
    REVISION_CONSULTAR(false, ASIGNADAS),
    SOLICITUD_CONSULTAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    DOCUMENTO_DESCARGAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    HISTORIAL_CONSULTAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    OBSERVACION_CONSULTAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    METRICAS_CONSULTAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    IA_SOLICITAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA),
    IA_CONSULTAR(false, PROPIAS, AREA, EQUIPO_DIRECTO, ASIGNADAS, AREAS_ADMINISTRADAS, PARTICIPACION_AREA);

    private final boolean reservado;
    private final Set<Alcance> alcances;
    Permiso(boolean reservado, Alcance... alcances) {
        this.reservado = reservado;
        var permitted = java.util.EnumSet.of(GLOBAL);
        permitted.addAll(java.util.List.of(alcances));
        this.alcances = Set.copyOf(permitted);
    }
    public boolean reservado() { return reservado; }
    public Set<Alcance> alcancesPermitidos() { return alcances; }
}

