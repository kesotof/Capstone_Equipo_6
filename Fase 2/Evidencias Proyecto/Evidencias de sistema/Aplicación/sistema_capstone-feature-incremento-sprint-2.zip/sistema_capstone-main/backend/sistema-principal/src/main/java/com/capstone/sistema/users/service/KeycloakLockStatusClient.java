package com.capstone.sistema.users.service;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import org.keycloak.admin.client.Keycloak;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import java.time.Duration;

@Component
public class KeycloakLockStatusClient {

    private static final Logger log = LoggerFactory.getLogger(KeycloakLockStatusClient.class);

    private final RestClient restClient;
    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties keycloakProperties;

    public KeycloakLockStatusClient(
            RestClient.Builder restClientBuilder,
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties keycloakProperties
    ) {
        var requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(Duration.ofSeconds(3));
        requestFactory.setReadTimeout(Duration.ofSeconds(10));
        this.restClient = restClientBuilder.requestFactory(requestFactory).baseUrl(keycloakProperties.serverUrl()).build();
        this.keycloakAdminClient = keycloakAdminClient;
        this.keycloakProperties = keycloakProperties;
    }

    public boolean isTemporarilyLocked(String keycloakUserId) {
        try {
            BruteForceStatus status = restClient.get()
                    .uri(
                            "/admin/realms/{realm}/attack-detection/brute-force/users/{userId}",
                            keycloakProperties.targetRealm(),
                            keycloakUserId
                    )
                    .headers(headers -> headers.setBearerAuth(
                            keycloakAdminClient.tokenManager().getAccessToken().getToken()
                    ))
                    .retrieve()
                    .body(BruteForceStatus.class);
            return status != null && status.disabled();
        } catch (RuntimeException exception) {
            log.warn("No fue posible consultar el bloqueo temporal de la cuenta {}", keycloakUserId, exception);
            return false;
        }
    }

    private record BruteForceStatus(boolean disabled) {
    }
}
