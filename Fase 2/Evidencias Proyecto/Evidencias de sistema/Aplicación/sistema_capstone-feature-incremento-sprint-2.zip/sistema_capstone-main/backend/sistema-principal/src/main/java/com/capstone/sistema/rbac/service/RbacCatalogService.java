package com.capstone.sistema.rbac.service;

import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class RbacCatalogService {
    private final RbacAccessService access;
    private final AreaRepository areas;
    private final UserAccountRepository users;
    private final SolicitudRepository solicitudes;
    public RbacCatalogService(RbacAccessService access,AreaRepository areas,UserAccountRepository users,SolicitudRepository solicitudes) {
        this.access=access;this.areas=areas;this.users=users;this.solicitudes=solicitudes;
    }
    public List<AreaItem> areas() {
        var c=access.context();
        Set<Long> ids=new HashSet<>(c.managedAreas());
        if(c.areaId()!=null) ids.add(c.areaId());
        if(!c.admin()) {
            solicitudes.findAll(access.visible(Permiso.SOLICITUD_CONSULTAR)).forEach(s->{
                if(s.getAreaOrigenId()!=null) ids.add(s.getAreaOrigenId());
                if(s.getAreaFlujoId()!=null) ids.add(s.getAreaFlujoId());
            });
        }
        return areas.findAll().stream().filter(a->a.isActivo() && (c.admin() || ids.contains(a.getId())))
                .sorted(Comparator.comparing(a->a.getNombre().toLowerCase(Locale.ROOT)))
                .map(a->new AreaItem(a.getId(),a.getNombre())).toList();
    }
    public List<Reviewer> reviewers(Long areaId) {
        if (areaId!=null && areaId<=0) throw com.capstone.sistema.rbac.exception.RbacException.invalid("El área debe tener un ID positivo.");
        access.manageFlow(areaId);
        if (areaId!=null && !areas.existsById(areaId)) throw com.capstone.sistema.rbac.exception.RbacException.missing();
        return users.findAllByOrderByEmailAsc().stream().filter(access::eligibleReviewer)
                .map(u->new Reviewer(u.getId(),(u.getFirstName()+" "+u.getLastName()).trim(),
                        u.getArea()!=null && u.getArea().isActivo()?u.getArea().getId():null,
                        u.getArea()!=null && u.getArea().isActivo()?u.getArea().getNombre():null)).toList();
    }
}

