package com.capstone.sistema.audit.controller;

import com.capstone.sistema.audit.dto.AuditEventResponse;
import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuditController.class)
@Import(SecurityConfig.class)
class AuditControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuditService auditService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    void rejectsLogoutAuditWithoutAnAccessToken() throws Exception {
        mockMvc.perform(post("/api/audit/logout"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void rejectsLoginAuditWithoutAnAccessToken() throws Exception {
        mockMvc.perform(post("/api/audit/login"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void createsLoginAuditEntryForAnAuthenticatedUser() throws Exception {
        when(auditService.registerLogin(any(Jwt.class), any(HttpServletRequest.class))).thenReturn(new AuditEventResponse(
                10L,
                "admin@capstone.local",
                "LOGIN",
                "127.0.0.1",
                "Inicio de sesión exitoso de admin@capstone.local",
                Instant.parse("2026-09-14T00:00:00Z")
        ));

        mockMvc.perform(post("/api/audit/login")
                        .with(jwt().jwt(jwt -> jwt
                                .subject("keycloak-user-1")
                                .claim("email", "admin@capstone.local")
                        )))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("admin@capstone.local"))
                .andExpect(jsonPath("$.eventType").value("LOGIN"));

        verify(auditService).registerLogin(any(Jwt.class), any(HttpServletRequest.class));
    }

    @Test
    void createsLogoutAuditEntryForAnAuthenticatedUser() throws Exception {
        when(auditService.registerLogout(any(Jwt.class), any(HttpServletRequest.class))).thenReturn(new AuditEventResponse(
                11L,
                "admin@capstone.local",
                "LOGOUT",
                "127.0.0.1",
                "Cierre de sesión de admin@capstone.local",
                Instant.parse("2026-09-14T00:00:00Z")
        ));

        mockMvc.perform(post("/api/audit/logout")
                        .with(jwt().jwt(jwt -> jwt
                                .subject("keycloak-user-1")
                                .claim("email", "admin@capstone.local")
                        )))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("admin@capstone.local"))
                .andExpect(jsonPath("$.eventType").value("LOGOUT"));

        verify(auditService).registerLogout(any(Jwt.class), any(HttpServletRequest.class));
    }

    @Test
    void returnsRecentAuditEventsForAdmin() throws Exception {
        when(auditService.listRecentEvents(50)).thenReturn(java.util.List.of(
                new AuditEventResponse(
                        101L,
                        "operador@capstone.local",
                        "CREAR_USUARIO",
                        "127.0.0.1",
                        "Usuario creado: operador@capstone.local",
                        Instant.parse("2026-09-15T00:00:00Z")
                )
        ));

        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/api/audit/events")
                        .with(jwt().jwt(jwt -> jwt
                                .subject("admin-user")
                                .claim("email", "admin@capstone.local")
                        ).authorities(new org.springframework.security.core.authority.SimpleGrantedAuthority("ROLE_ADMIN"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].email").value("operador@capstone.local"))
                .andExpect(jsonPath("$[0].eventType").value("CREAR_USUARIO"));

        verify(auditService).listRecentEvents(50);
    }
}
