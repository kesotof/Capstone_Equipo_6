package com.capstone.sistema.flow.dto;

import java.util.List;

public record SeccionDetalleResponse<T>(boolean accesible, List<T> elementos) {
    public SeccionDetalleResponse {
        elementos = accesible ? List.copyOf(elementos) : List.of();
    }
}
