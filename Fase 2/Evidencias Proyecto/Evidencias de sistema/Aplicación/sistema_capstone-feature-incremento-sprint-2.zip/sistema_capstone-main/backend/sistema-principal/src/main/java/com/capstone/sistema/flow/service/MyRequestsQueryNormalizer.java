package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.dto.MyRequestsCriteria;
import com.capstone.sistema.flow.exception.MyRequestsException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Component
public class MyRequestsQueryNormalizer {
    private static final Set<String> OWN_PARAMETERS = Set.of("query", "status", "page", "size");
    private static final Set<String> ACCESSIBLE_PARAMETERS = Set.of("query", "status", "areaId", "page", "size");
    private static final Set<String> STATUSES = Set.of(
            "PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO");

    public MyRequestsCriteria normalize(Map<String, List<String>> parameters, boolean ownOnly) {
        Set<String> allowed = ownOnly ? OWN_PARAMETERS : ACCESSIBLE_PARAMETERS;
        if (!allowed.containsAll(parameters.keySet())) {
            throw MyRequestsException.invalid("La consulta contiene un parámetro no admitido en esta bandeja.");
        }
        if (parameters.values().stream().anyMatch(values -> values == null || values.size() != 1)) {
            throw MyRequestsException.invalid("Cada parámetro de consulta debe enviarse una sola vez.");
        }

        String query = value(parameters, "query", 200);
        String status = value(parameters, "status", 36);
        if (status != null) {
            status = status.toUpperCase(Locale.ROOT);
            if (!STATUSES.contains(status)) {
                throw MyRequestsException.invalid("status no corresponde a un estado documental permitido.");
            }
        }
        Long areaId = number(value(parameters, "areaId", 20), "areaId", 1, Long.MAX_VALUE, null);
        int page = number(value(parameters, "page", 10), "page", 0, Integer.MAX_VALUE, 0L).intValue();
        int size = number(value(parameters, "size", 3), "size", 1, 100, 10L).intValue();
        if ((long) page * size > Integer.MAX_VALUE) {
            throw MyRequestsException.invalid("El desplazamiento de page y size excede el máximo permitido.");
        }
        return new MyRequestsCriteria(query, status, areaId, page, size);
    }

    private String value(Map<String, List<String>> parameters, String name, int maxLength) {
        List<String> values = parameters.get(name);
        if (values == null || values.getFirst() == null) {
            return null;
        }
        String raw = values.getFirst();
        if (raw.codePoints().anyMatch(Character::isISOControl)) {
            throw MyRequestsException.invalid(name + " contiene caracteres de control no admitidos.");
        }
        String normalized = raw.strip();
        if (normalized.length() > maxLength) {
            throw MyRequestsException.invalid(name + " supera la longitud máxima de " + maxLength + " caracteres.");
        }
        return normalized.isEmpty() ? null : normalized;
    }

    private Long number(String value, String field, long min, long max, Long defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        try {
            if (!value.matches("[0-9]+")) {
                throw new NumberFormatException();
            }
            long parsed = Long.parseLong(value);
            if (parsed < min || parsed > max) {
                throw new NumberFormatException();
            }
            return parsed;
        } catch (NumberFormatException ex) {
            throw MyRequestsException.invalid(field + " debe ser un entero entre " + min + " y " + max + ".");
        }
    }
}
