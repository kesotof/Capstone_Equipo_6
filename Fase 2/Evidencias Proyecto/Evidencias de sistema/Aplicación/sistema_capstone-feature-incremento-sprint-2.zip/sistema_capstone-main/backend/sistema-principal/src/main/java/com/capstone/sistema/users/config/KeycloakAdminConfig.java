package com.capstone.sistema.users.config;

import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import jakarta.ws.rs.client.ClientBuilder;
import org.keycloak.admin.client.JacksonProvider;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableConfigurationProperties(KeycloakAdminProperties.class)
public class KeycloakAdminConfig {

    @Bean(destroyMethod = "close")
    public Keycloak keycloakAdminClient(KeycloakAdminProperties properties) {
        return KeycloakBuilder.builder()
                .serverUrl(properties.serverUrl())
                .realm(properties.realm())
                .clientId(properties.clientId())
                .grantType(OAuth2Constants.PASSWORD)
                .username(properties.username())
                .password(properties.password())
                .resteasyClient(ClientBuilder.newBuilder().connectTimeout(3, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS).register(JacksonProvider.class).build())
                .build();
    }
}
