package com.capstone.sistema.flow.exception;

import java.util.UUID;

public class SolicitudNotFoundException extends RuntimeException {
    public SolicitudNotFoundException(UUID id) {
        super("No se encontró la solicitud con ID: " + id);
    }

    public SolicitudNotFoundException(String message) {
        super(message);
    }
}
