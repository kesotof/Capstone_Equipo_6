package com.capstone.sistema.rbac.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;
import javax.sql.DataSource;

/** Completa las restricciones de solicitudes creadas por Hibernate en una instalación nueva. */
@Component
@Order(-100)
public class RbacSchemaInitializer implements ApplicationRunner {
    private final DataSource dataSource;
    public RbacSchemaInitializer(DataSource dataSource) { this.dataSource=dataSource; }
    @Override
    public void run(ApplicationArguments args) {
        var script = new ResourceDatabasePopulator(new ClassPathResource("db/rbac-schema.sql"));
        script.setSeparator("^^^ END OF SCRIPT ^^^");
        script.execute(dataSource);
    }
}

