package com.capstone.sistema.audit.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "log_evento")
public class LogEvento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "tipo_evento_id", nullable = false)
    private TipoEvento tipoEvento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private UserAccount usuario;

    @Column(name = "usuario_email", length = 255)
    private String usuarioEmail;

    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Column(name = "detalle", length = 500)
    private String detalle;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected LogEvento() {
    }

    public LogEvento(TipoEvento tipoEvento, UserAccount usuario, String ipAddress, String detalle) {
        this.tipoEvento = tipoEvento;
        this.usuario = usuario;
        this.usuarioEmail = usuario != null ? usuario.getEmail() : null;
        this.ipAddress = ipAddress;
        this.detalle = detalle;
    }

    public LogEvento(TipoEvento tipoEvento, UserAccount usuario, String usuarioEmail, String ipAddress, String detalle) {
        this.tipoEvento = tipoEvento;
        this.usuario = usuario;
        this.usuarioEmail = usuarioEmail != null ? usuarioEmail : (usuario != null ? usuario.getEmail() : null);
        this.ipAddress = ipAddress;
        this.detalle = detalle;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(TipoEvento tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getUsuarioEmail() {
        return usuarioEmail;
    }

    public void setUsuarioEmail(String usuarioEmail) {
        this.usuarioEmail = usuarioEmail;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
