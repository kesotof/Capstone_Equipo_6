package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.RequestDetailResponse;
import com.capstone.sistema.flow.service.RequestDetailService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@PreAuthorize("isAuthenticated()")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Solicitudes", description = "Gestión del ciclo de vida documental y motor de flujos de aprobación")
public class RequestDetailController {
    private final RequestDetailService detalles;

    public RequestDetailController(RequestDetailService detalles) {
        this.detalles = detalles;
    }

    @Operation(summary = "Consultar detalle integral de una solicitud",
            description = "Metadatos, áreas registradas, versiones documentales, etapa, SLA, observaciones e historial. "
                    + "Aplica permisos por solicitud y sección; solo el documento vigente autorizado tiene enlace de descarga.")
    @GetMapping(value = {"/api/requests/{id}/detail", "/api/solicitudes/{id}/detalle"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RequestDetailResponse> consultar(@PathVariable UUID id) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(detalles.consultar(id));
    }
}
