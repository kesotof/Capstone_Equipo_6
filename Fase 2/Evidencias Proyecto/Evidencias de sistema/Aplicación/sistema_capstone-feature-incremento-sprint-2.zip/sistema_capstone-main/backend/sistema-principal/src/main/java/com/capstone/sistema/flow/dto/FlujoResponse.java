package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.List;

public record FlujoResponse(
        Long id,
        String nombre,
        String descripcion,
        Long areaId,
        String areaNombre,
        boolean activo,
        boolean completo,
        List<FlujoEtapaResponse> etapas,
        Instant createdAt,
        Instant updatedAt,
        Long version,
        boolean estructuraEditable
) {
    public FlujoResponse(Long id, String nombre, String descripcion, Long areaId, String areaNombre,
                         boolean activo, boolean completo, List<FlujoEtapaResponse> etapas,
                         Instant createdAt, Instant updatedAt, Long version) {
        this(id,nombre,descripcion,areaId,areaNombre,activo,completo,etapas,createdAt,updatedAt,version,false);
    }
    public FlujoResponse(Long id, String nombre, String descripcion, Long areaId, String areaNombre,
                         boolean activo, boolean completo, List<FlujoEtapaResponse> etapas,
                         Instant createdAt, Instant updatedAt) {
        this(id,nombre,descripcion,areaId,areaNombre,activo,completo,etapas,createdAt,updatedAt,null,false);
    }
}
