package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.TipoAsignacionRevisor;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.util.UUID;

public record AsignarResponsableRequest(
        @NotNull @Min(0) Long version,
        @NotNull TipoAsignacionRevisor tipoAsignacion,
        UUID revisorId,
        @Positive Long rolRevisorId
) {}
