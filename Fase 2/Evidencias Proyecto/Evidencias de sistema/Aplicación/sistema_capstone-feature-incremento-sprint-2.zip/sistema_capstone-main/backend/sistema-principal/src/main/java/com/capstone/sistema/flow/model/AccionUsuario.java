package com.capstone.sistema.flow.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "accion_usuario")
public class AccionUsuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String accion;

    protected AccionUsuario() {
    }

    public AccionUsuario(String accion) {
        this.accion = accion;
    }

    public AccionUsuario(Long id, String accion) {
        this.id = id;
        this.accion = accion;
    }

    public Long getId() {
        return id;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccionUsuario that = (AccionUsuario) o;
        return Objects.equals(accion, that.accion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accion);
    }
}
