package com.capstone.sistema.org.area.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.exception.AreaException;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AreaServiceTest {

    @Mock
    private AreaRepository areaRepository;

    @Mock
    private UserAccountRepository userAccountRepository;

    @Mock
    private AreaCatalogLock catalogLock;

    @Mock
    private AreaUsageChecker usageChecker;

    @Mock
    private AuditService auditService;

    @Mock
    private EntityManager entityManager;

    private AreaService areaService;

    @BeforeEach
    void setUp() {
        areaService = new AreaService(areaRepository, userAccountRepository, catalogLock, usageChecker, auditService, entityManager);
    }

    @Test
    @DisplayName("Asigna exitosamente un administrador activo a un área existente y genera auditoría")
    void assignAdmin_activeUser_success() {
        Long areaId = 2L;
        UUID adminId = UUID.randomUUID();

        Area area = new Area("Finanzas");
        area.setDescripcion("Área contable");

        UserAccount admin = new UserAccount(adminId, "kc-1", "admin.finanzas@empresa.cl", "22459056-3", "Pedro", "Picapiedra", null, true, Set.of());

        when(areaRepository.findById(areaId)).thenReturn(Optional.of(area));
        when(areaRepository.existsNombreNormalizadoExcluding("Finanzas", areaId)).thenReturn(false);
        when(userAccountRepository.findById(adminId)).thenReturn(Optional.of(admin));

        UpdateAreaRequest request = new UpdateAreaRequest("Finanzas", "Área contable", null, adminId, 0L);
        AreaResponse response = areaService.update(areaId, request);

        assertThat(area.getAdministrador()).isEqualTo(admin);
        assertThat(response.administradorId()).isEqualTo(adminId);
        assertThat(response.administradorEmail()).isEqualTo("admin.finanzas@empresa.cl");

        ArgumentCaptor<String> detalleCaptor = ArgumentCaptor.forClass(String.class);
        verify(auditService).registerUserManagementEvent(eq("ASIGNAR_ADMIN_AREA"), detalleCaptor.capture());
        assertThat(detalleCaptor.getValue()).contains("asignado administrador admin.finanzas@empresa.cl");
    }

    @Test
    @DisplayName("Rechaza la asignación si el usuario administrador seleccionado está inactivo")
    void assignAdmin_inactiveUser_throwsException() {
        Long areaId = 2L;
        UUID adminId = UUID.randomUUID();

        Area area = new Area("Finanzas");
        UserAccount inactiveUser = new UserAccount(adminId, "kc-1", "inactivo@empresa.cl", "5761313-0", "Juan", "Inactivo", null, false, Set.of());

        when(areaRepository.findById(areaId)).thenReturn(Optional.of(area));
        when(areaRepository.existsNombreNormalizadoExcluding("Finanzas", areaId)).thenReturn(false);
        when(userAccountRepository.findById(adminId)).thenReturn(Optional.of(inactiveUser));

        UpdateAreaRequest request = new UpdateAreaRequest("Finanzas", null, null, adminId, 0L);

        assertThatThrownBy(() -> areaService.update(areaId, request))
                .isInstanceOf(AreaException.class)
                .hasMessageContaining("debe estar activo");
    }

    @Test
    @DisplayName("Reemplaza el administrador previo y registra evento de auditoría correspondiente")
    void assignAdmin_replacesExistingAdmin_successAndAudited() {
        Long areaId = 2L;
        UUID oldAdminId = UUID.randomUUID();
        UUID newAdminId = UUID.randomUUID();

        UserAccount oldAdmin = new UserAccount(oldAdminId, "kc-old", "antiguo@empresa.cl", "5246001-8", "Antiguo", "Admin", null, true, Set.of());
        UserAccount newAdmin = new UserAccount(newAdminId, "kc-new", "nuevo@empresa.cl", "23330610-K", "Nuevo", "Admin", null, true, Set.of());

        Area area = new Area("Finanzas");
        area.setAdministrador(oldAdmin);

        when(areaRepository.findById(areaId)).thenReturn(Optional.of(area));
        when(areaRepository.existsNombreNormalizadoExcluding("Finanzas", areaId)).thenReturn(false);
        when(userAccountRepository.findById(newAdminId)).thenReturn(Optional.of(newAdmin));

        UpdateAreaRequest request = new UpdateAreaRequest("Finanzas", null, null, newAdminId, 0L);
        AreaResponse response = areaService.update(areaId, request);

        assertThat(area.getAdministrador()).isEqualTo(newAdmin);
        assertThat(response.administradorEmail()).isEqualTo("nuevo@empresa.cl");

        verify(auditService).registerUserManagementEvent(eq("ASIGNAR_ADMIN_AREA"), any());
    }
}
