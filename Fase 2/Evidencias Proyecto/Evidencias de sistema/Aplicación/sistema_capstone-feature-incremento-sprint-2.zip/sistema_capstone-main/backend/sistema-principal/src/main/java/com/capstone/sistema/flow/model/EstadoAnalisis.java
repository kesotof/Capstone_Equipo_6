package com.capstone.sistema.flow.model;

public enum EstadoAnalisis {
    PENDIENTE,
    COMPLETADO,
    ERROR
}
