package com.capstone.sistema.flow.dto;

public record FlujoDetalleResponse(Long id, String nombre) {
}
