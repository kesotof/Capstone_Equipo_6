package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DocumentSearchCatalogRepository {
    private final EntityManager entityManager;

    public DocumentSearchCatalogRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public List<CatalogEntry> findVisible(Specification<Solicitud> visibility) {
        var builder = entityManager.getCriteriaBuilder();
        var query = builder.createTupleQuery();
        var request = query.from(Solicitud.class);
        var document = query.from(Documento.class);
        query.multiselect(request.get("areaOrigenId").alias("origen"), request.get("areaFlujoId").alias("flujo"),
                        builder.upper(document.get("formatoDocumento").get("tipo")).alias("tipo"))
                .distinct(true).where(builder.equal(document.get("solicitud").get("id"), request.get("id")),
                        builder.isTrue(document.get("vigente")), visibility.toPredicate(request, query, builder));
        return entityManager.createQuery(query).getResultList().stream()
                .map(row -> new CatalogEntry(row.get("origen", Long.class), row.get("flujo", Long.class),
                        row.get("tipo", String.class))).toList();
    }

    public record CatalogEntry(Long areaOrigenId, Long areaFlujoId, String documentType) { }
}
