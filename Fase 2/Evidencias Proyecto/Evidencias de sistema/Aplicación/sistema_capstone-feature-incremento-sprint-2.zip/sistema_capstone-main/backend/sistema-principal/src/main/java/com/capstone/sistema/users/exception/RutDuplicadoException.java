package com.capstone.sistema.users.exception;

public class RutDuplicadoException extends RuntimeException {

    public RutDuplicadoException(String message) {
        super(message);
    }
}
