package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.AiAnalysis;
import com.capstone.sistema.flow.model.EstadoAnalisis;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record AiAnalysisResponse(
        UUID id,
        UUID solicitudId,
        UUID documentoId,
        EstadoAnalisis estado,
        Integer puntaje,
        Boolean valido,
        String observaciones,
        List<String> recomendaciones,
        String modeloUsado,
        String promptUtilizado,
        boolean cached,
        Instant createdAt,
        Instant completedAt
) {
    public static AiAnalysisResponse fromEntity(AiAnalysis entity, boolean cached, List<String> recomendaciones) {
        return new AiAnalysisResponse(
                entity.getId(),
                entity.getSolicitud().getId(),
                entity.getDocumento() != null ? entity.getDocumento().getId() : null,
                entity.getEstado(),
                entity.getPuntaje(),
                entity.getValido(),
                entity.getObservaciones(),
                recomendaciones,
                entity.getModeloUsado(),
                entity.getPromptUtilizado(),
                cached,
                entity.getCreatedAt(),
                entity.getCompletedAt()
        );
    }
}
