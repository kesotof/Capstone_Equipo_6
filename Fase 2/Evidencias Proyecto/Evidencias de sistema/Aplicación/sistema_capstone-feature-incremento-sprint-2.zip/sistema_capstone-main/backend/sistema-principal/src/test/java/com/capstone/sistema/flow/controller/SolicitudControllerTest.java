package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.DocumentoNoDisponibleException;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.SolicitudNotFoundException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.service.SolicitudService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SolicitudController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class SolicitudControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SolicitudService solicitudService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    void rejectsUnauthenticatedAccess() throws Exception {
        mockMvc.perform(get("/api/solicitudes/mis-solicitudes"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void crearSolicitud_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();
        when(solicitudService.crearSolicitud(eq("Informe 2026"), eq("Desc"), any(), eq(false), eq("General")))
                .thenReturn(new CrearSolicitudResponse(solId, docId, "PENDIENTE_REVISION", "Documento registrado"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "Informe 2026")
                        .param("descripcion", "Desc")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.solicitudId").value(solId.toString()))
                .andExpect(jsonPath("$.documentoId").value(docId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE_REVISION"))
                .andExpect(jsonPath("$.mensaje").value("Documento registrado"));
    }

    @Test
    void crearSolicitud_ConTipoDocumento_PasaTipoAServicio() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();
        when(solicitudService.crearSolicitud(eq("Contrato Proveedor"), eq("Desc"), any(), eq(false), eq("Contrato")))
                .thenReturn(new CrearSolicitudResponse(solId, docId, "PENDIENTE_REVISION", "Documento registrado"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "contrato.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "Contrato Proveedor")
                        .param("tipoDocumento", "Contrato")
                        .param("descripcion", "Desc")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.solicitudId").value(solId.toString()))
                .andExpect(jsonPath("$.documentoId").value(docId.toString()));
    }

    @Test
    void crearSolicitud_ValidacionMimeTypesPermitidos_Retorna201Created() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();
        when(solicitudService.crearSolicitud(any(), any(), any(), anyBoolean(), anyString()))
                .thenReturn(new CrearSolicitudResponse(solId, docId, "PENDIENTE_REVISION", "Documento registrado correctamente"));

        // Lista de formatos y tipos MIME permitidos por el sistema
        record FormatoMime(String filename, String mimeType) {}
        List<FormatoMime> formatosValidos = List.of(
                new FormatoMime("documento.pdf", "application/pdf"),
                new FormatoMime("documento.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
                new FormatoMime("documento.doc", "application/msword"),
                new FormatoMime("planilla.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
                new FormatoMime("planilla.xls", "application/vnd.ms-excel"),
                new FormatoMime("datos.xml", "application/xml"),
                new FormatoMime("nota.txt", "text/plain")
        );

        for (FormatoMime fmt : formatosValidos) {
            MockMultipartFile file = new MockMultipartFile("file", fmt.filename(), fmt.mimeType(), "contenido de prueba".getBytes());
            mockMvc.perform(multipart("/api/solicitudes")
                            .file(file)
                            .param("titulo", "Solicitud " + fmt.filename())
                            .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.estado").value("PENDIENTE_REVISION"));
        }
    }

    @Test
    void crearSolicitud_RechazoArchivosNoPermitidos_Returns400ProblemDetail() throws Exception {
        when(solicitudService.crearSolicitud(any(), any(), any(), anyBoolean(), anyString()))
                .thenThrow(new InvalidDocumentFormatException("Formato de archivo no permitido (.exe). Formatos aceptados: .doc, .docx, .pdf, .xml, .txt, .xlsx, .xls"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "malware.exe", "application/octet-stream", "bad".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "Software")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Documento Inválido"))
                .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.containsString("Formato de archivo no permitido (.exe)")));
    }

    @Test
    void crearSolicitud_FaltanCamposObligatorios_TituloVacio_Returns400BadRequest() throws Exception {
        when(solicitudService.crearSolicitud(eq(""), any(), any(), anyBoolean(), anyString()))
                .thenThrow(new IllegalArgumentException("El título del documento es obligatorio"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Solicitud Inválida"))
                .andExpect(jsonPath("$.detail").value("El título del documento es obligatorio"));
    }

    @Test
    void crearSolicitud_FaltanCamposObligatorios_ArchivoVacio_Returns400BadRequest() throws Exception {
        when(solicitudService.crearSolicitud(any(), any(), any(), anyBoolean(), anyString()))
                .thenThrow(new IllegalArgumentException("El archivo del documento es obligatorio"));

        MockMultipartFile emptyFile = new MockMultipartFile(
                "file", "vacio.pdf", "application/pdf", new byte[0]
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(emptyFile)
                        .param("titulo", "Documento con archivo vacío")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Solicitud Inválida"))
                .andExpect(jsonPath("$.detail").value("El archivo del documento es obligatorio"));
    }

    @Test
    void crearSolicitud_FaltanCamposObligatorios_ParametroFileAusente_Returns400BadRequest() throws Exception {
        mockMvc.perform(multipart("/api/solicitudes")
                        .param("titulo", "Documento sin archivo")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void crearSolicitud_FaltanCamposObligatorios_ParametroTituloAusente_Returns400BadRequest() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void aprobar_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false), isNull())).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "APROBADO", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("APROBADO"));
    }

    @Test
    void aprobar_UnauthorizedAction_Returns403ProblemDetail() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false), isNull()))
                .thenThrow(new UnauthorizedActionException("El emisor no puede aprobar su propio documento"));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.title").value("Acción No Autorizada"))
                .andExpect(jsonPath("$.detail").value("El emisor no puede aprobar su propio documento"));
    }

    @Test
    void aprobar_InvalidTransition_Returns409ProblemDetail() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false), isNull()))
                .thenThrow(new InvalidTransitionException("No se puede aprobar la solicitud"));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.title").value("Transición de Estado Inválida"));
    }

    @Test
    void rechazar_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.rechazar(eq(solId), eq("No cumple formato"), eq(false), isNull())).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "RECHAZADO", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/rechazar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"motivo\": \"No cumple formato\"}")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RECHAZADO"));
    }

    @Test
    void pedirCorreccion_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.pedirCorreccion(eq(solId), eq("Falta firma"), eq(false), isNull())).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "CORRECCION_REQUERIDA", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/pedir-correccion")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"observacion\": \"Falta firma\"}")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CORRECCION_REQUERIDA"));
    }

    @Test
    void listarMisSolicitudes_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.listarMisSolicitudes()).thenReturn(List.of(
                new SolicitudResponse(solId, "Mi Solicitud", "Desc", "PENDIENTE_REVISION",
                        UUID.randomUUID(), "Emisor", "emisor@test.local", null, Instant.now(), Instant.now())
        ));

        mockMvc.perform(get("/api/solicitudes/mis-solicitudes")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Mi Solicitud"));
    }

    @Test
    void listarRevisionesPendientes_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        Instant fechaDesde = Instant.parse("2026-09-01T00:00:00Z");
        Instant fechaHasta = Instant.parse("2026-09-16T23:59:59Z");
        when(solicitudService.listarRevisionesPendientes(
                eq("contrato"), eq("emisor@test.local"), eq(fechaDesde), eq(fechaHasta),
                eq("PENDIENTE_REVISION"), eq(1), anyInt()
        )).thenReturn(new PaginaSolicitudesPendientesResponse(
                List.of(new SolicitudPendienteResponse(
                        solId, "Doc a Revisar", "contrato.pdf", "Emisor", "emisor@test.local",
                        Instant.now(), "PENDIENTE_REVISION"
                )),
                1, 10, 11, 2, false, true
        ));

        mockMvc.perform(get("/api/solicitudes/pendientes-revision")
                        .param("nombreArchivo", "contrato")
                        .param("emisor", "emisor@test.local")
                        .param("fechaDesde", fechaDesde.toString())
                        .param("fechaHasta", fechaHasta.toString())
                        .param("estado", "PENDIENTE_REVISION")
                        .param("pagina", "1")
                        .param("tamanio", "10")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].titulo").value("Doc a Revisar"))
                .andExpect(jsonPath("$.contenido[0].nombreArchivo").value("contrato.pdf"))
                .andExpect(jsonPath("$.pagina").value(1))
                .andExpect(jsonPath("$.totalElementos").value(11));
    }

    @Test
    void listarRevisionesPendientes_CualquierUsuarioAutenticadoAccede_Sprint1SinRoles() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.listarRevisionesPendientes(
                any(), any(), any(), any(), any(), anyInt(), anyInt()
        )).thenReturn(new PaginaSolicitudesPendientesResponse(
                List.of(new SolicitudPendienteResponse(
                        solId, "Solicitud Pendiente", "archivo.pdf", "Emisor", "emisor@test.local",
                        Instant.now(), "PENDIENTE_REVISION"
                )),
                0, 10, 1, 1, true, true
        ));

        // En Sprint 1 sin roles, un emisor estándar accede directamente a la bandeja sin recibir 403 Forbidden
        mockMvc.perform(get("/api/solicitudes/pendientes-revision")
                        .with(jwt().jwt(j -> j.claim("email", "emisor.estandar@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].estado").value("PENDIENTE_REVISION"))
                .andExpect(jsonPath("$.totalElementos").value(1));
    }

    @Test
    void obtenerHistorial_OrdenCronologicoEstricto_IncluyeQueQuienCuandoYObservaciones() throws Exception {
        UUID solId = UUID.randomUUID();
        Instant t1 = Instant.parse("2026-09-27T10:00:00Z");
        Instant t2 = Instant.parse("2026-09-27T11:00:00Z");
        Instant t3 = Instant.parse("2026-09-27T12:00:00Z");

        when(solicitudService.obtenerHistorial(solId)).thenReturn(List.of(
                new TransicionResponse(1L, "INICIAL", "PENDIENTE_REVISION", "CREAR_SOLICITUD",
                        "emisor@test.local", "Juan Emisor", "Creación de documento sin planilla", true, t1),
                new TransicionResponse(2L, "PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "PEDIR_CORRECCION",
                        "revisor@test.local", "Ana Revisor", "Se requiere adjuntar anexo legal firmado y corregir vigencia", true, t2),
                new TransicionResponse(3L, "CORRECCION_REQUERIDA", "PENDIENTE_REVISION", "REENVIAR_SOLICITUD",
                        "emisor@test.local", "Juan Emisor", "Subsanación enviada con nuevo PDF adjunto", true, t3)
        ));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/historial")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(3))
                // 1. Verificación de qué ocurrió (acción y transición de estados)
                .andExpect(jsonPath("$[0].accion").value("CREAR_SOLICITUD"))
                .andExpect(jsonPath("$[0].estadoOrigen").value("INICIAL"))
                .andExpect(jsonPath("$[0].estadoDestino").value("PENDIENTE_REVISION"))
                .andExpect(jsonPath("$[1].accion").value("PEDIR_CORRECCION"))
                .andExpect(jsonPath("$[1].estadoOrigen").value("PENDIENTE_REVISION"))
                .andExpect(jsonPath("$[1].estadoDestino").value("CORRECCION_REQUERIDA"))
                .andExpect(jsonPath("$[2].accion").value("REENVIAR_SOLICITUD"))
                .andExpect(jsonPath("$[2].estadoOrigen").value("CORRECCION_REQUERIDA"))
                .andExpect(jsonPath("$[2].estadoDestino").value("PENDIENTE_REVISION"))
                // 2. Verificación de quién lo realizó
                .andExpect(jsonPath("$[0].usuarioEmail").value("emisor@test.local"))
                .andExpect(jsonPath("$[0].usuarioNombre").value("Juan Emisor"))
                .andExpect(jsonPath("$[1].usuarioEmail").value("revisor@test.local"))
                .andExpect(jsonPath("$[1].usuarioNombre").value("Ana Revisor"))
                .andExpect(jsonPath("$[2].usuarioEmail").value("emisor@test.local"))
                // 3. Verificación de cuándo ocurrió (orden cronológico estricto t1 < t2 < t3)
                .andExpect(jsonPath("$[0].createdAt").value("2026-09-27T10:00:00Z"))
                .andExpect(jsonPath("$[1].createdAt").value("2026-09-27T11:00:00Z"))
                .andExpect(jsonPath("$[2].createdAt").value("2026-09-27T12:00:00Z"))
                // 4. Presencia de observaciones de revisores
                .andExpect(jsonPath("$[1].comentario").value("Se requiere adjuntar anexo legal firmado y corregir vigencia"));
    }

    @Test
    void obtenerHistorial_Inmutabilidad_SinEndpointsModificacionOBorrado() throws Exception {
        UUID solId = UUID.randomUUID();

        // 1. PUT sobre historial no permitido
        mockMvc.perform(put("/api/solicitudes/" + solId + "/historial")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"comentario\":\"intento de modificacion\"}")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isMethodNotAllowed());

        // 2. PATCH sobre historial no permitido
        mockMvc.perform(patch("/api/solicitudes/" + solId + "/historial")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"comentario\":\"intento de parche\"}")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isMethodNotAllowed());

        // 3. DELETE sobre historial no permitido
        mockMvc.perform(delete("/api/solicitudes/" + solId + "/historial")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isMethodNotAllowed());

        // 4. DELETE sobre un evento puntual de auditoría no expuesto (404 o 405)
        mockMvc.perform(delete("/api/solicitudes/" + solId + "/historial/1")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isNotFound());
    }

    @Test
    void obtenerHistorial_ControlAcceso_UsuarioSinPermisos_Retorna403Forbidden() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerHistorial(solId))
                .thenThrow(new UnauthorizedActionException("No tiene permisos para acceder a esta solicitud o documento de otra área corporativa"));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/historial")
                        .with(jwt().jwt(j -> j.claim("email", "usuario.ajeno@test.local"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.title").value("Acción No Autorizada"))
                .andExpect(jsonPath("$.status").value(403))
                .andExpect(jsonPath("$.detail").value("No tiene permisos para acceder a esta solicitud o documento de otra área corporativa"));
    }

    @Test
    void obtenerHistorial_SolicitudInexistente_Retorna404NotFound() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerHistorial(solId))
                .thenThrow(new SolicitudNotFoundException("Solicitud no encontrada: " + solId));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/historial")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.title").value("Solicitud No Encontrada"))
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    void obtenerObservaciones_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerObservaciones(solId)).thenReturn(List.of(
                new ObservacionResponse(1L, "Nota de corrección", false,
                        "revisor@test.local", "Revisor", Instant.now())
        ));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/observaciones")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].contenido").value("Nota de corrección"));
    }

    @Test
    void obtenerDashboard_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerResumenDashboard()).thenReturn(new DashboardResponse(
                List.of(new AccionPendienteResponse(
                        solId, "Doc Pendiente", "REVISION", "Requiere tu revisión",
                        "PENDIENTE_REVISION", "Emisor Test", "emisor@test.local",
                        "doc.pdf", 1, Instant.now(), null
                )),
                List.of(new SolicitudResponse(
                        solId, "Doc en Trámite", "Desc", "PENDIENTE_REVISION",
                        UUID.randomUUID(), "Emisor", "emisor@test.local", null,
                        Instant.now(), Instant.now()
                ))
        ));

        mockMvc.perform(get("/api/solicitudes/dashboard")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accionesPendientes[0].titulo").value("Doc Pendiente"))
                .andExpect(jsonPath("$.accionesPendientes[0].tipoAccion").value("REVISION"))
                .andExpect(jsonPath("$.misSolicitudesPendientes[0].titulo").value("Doc en Trámite"));
    }

    @Test
    void consultarSolicitudes_multicriterio_returnsPaged200() throws Exception {
        UUID solId = UUID.randomUUID();
        PaginaSolicitudesPendientesResponse response = new PaginaSolicitudesPendientesResponse(
                List.of(new SolicitudPendienteResponse(
                        solId, "CONT-001", "Contrato Servicios", "contrato.pdf",
                        "Juan Perez", "juan@test.local", Instant.now(), Instant.now().plusSeconds(86400),
                        "NORMAL", "PENDIENTE_REVISION"
                )),
                0, 20, 1, 1, true, true
        );

        when(solicitudService.consultarSolicitudes(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt()))
                .thenReturn(response);

        mockMvc.perform(get("/api/solicitudes")
                        .param("q", "Contrato")
                        .param("correlativo", "CONT-001")
                        .param("areaId", "1")
                        .with(jwt().jwt(j -> j.claim("email", "auditor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].correlativo").value("CONT-001"))
                .andExpect(jsonPath("$.contenido[0].titulo").value("Contrato Servicios"))
                .andExpect(jsonPath("$.totalElementos").value(1));

        mockMvc.perform(get("/api/solicitudes/buscar")
                        .param("q", "Contrato")
                        .with(jwt().jwt(j -> j.claim("email", "auditor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].correlativo").value("CONT-001"));
    }

    @Test
    void obtenerMetricas_success_returns200Ok() throws Exception {
        MetricasResponse metricas = new MetricasResponse(
                10L, 25L, 3L, 2L, 40L, 35L, 5L, 2L, "Finanzas"
        );

        when(solicitudService.obtenerMetricas(eq(2L))).thenReturn(metricas);

        mockMvc.perform(get("/api/solicitudes/metricas")
                        .param("areaId", "2")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalGeneral").value(40))
                .andExpect(jsonPath("$.totalPendientes").value(10))
                .andExpect(jsonPath("$.totalAprobadas").value(25))
                .andExpect(jsonPath("$.totalDentroSla").value(35))
                .andExpect(jsonPath("$.areaNombre").value("Finanzas"));
    }

    @Test
    void obtenerMetricasPorArea_success_returns200Ok() throws Exception {
        MetricasResponse m1 = new MetricasResponse(
                5L, 10L, 1L, 0L, 16L, 14L, 2L, 1L, "Finanzas"
        );
        MetricasResponse m2 = new MetricasResponse(
                8L, 15L, 2L, 1L, 26L, 20L, 6L, 2L, "Operaciones"
        );

        when(solicitudService.obtenerMetricasPorArea()).thenReturn(List.of(m1, m2));

        mockMvc.perform(get("/api/solicitudes/metricas/por-area")
                        .with(jwt().jwt(j -> j.claim("email", "admin@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].areaId").value(1))
                .andExpect(jsonPath("$[0].areaNombre").value("Finanzas"))
                .andExpect(jsonPath("$[0].totalGeneral").value(16))
                .andExpect(jsonPath("$[1].areaId").value(2))
                .andExpect(jsonPath("$[1].areaNombre").value("Operaciones"))
                .andExpect(jsonPath("$[1].totalGeneral").value(26));
    }


    @Test
    void obtenerDetalle_uuidInvalido_returnsBadRequest400() throws Exception {
        mockMvc.perform(get("/api/solicitudes/not-a-uuid")
                        .with(jwt().jwt(j -> j.claim("email", "user@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Parámetro inválido"));
    }

    @Test
    void crearSolicitud_faltaParametroObligatorioTitulo_returnsBadRequest400() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void listarRevisionesPendientes_paginaNegativa_returnsBadRequest400() throws Exception {
        mockMvc.perform(get("/api/solicitudes/pendientes-revision")
                        .param("pagina", "-1")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Restricción de parámetro violada"));
    }

    @Test
    void reenviar_EstadoInvalido_Retorna409Conflict() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.reenviar(eq(solId), any(), any(), any(), anyBoolean(), eq(1L)))
                .thenThrow(new InvalidTransitionException("No se puede reenviar la solicitud porque su estado actual es 'PENDIENTE_REVISION' (se requiere 'CORRECCION_REQUERIDA')"));

        mockMvc.perform(multipart("/api/solicitudes/" + solId + "/reenviar")
                        .with(request -> { request.setMethod("PUT"); return request; })
                        .param("version", "1")
                        .param("titulo", "Documento Reenviado")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.title").value("Transición de Estado Inválida"))
                .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.containsString("se requiere 'CORRECCION_REQUERIDA'")));
    }

    @Test
    void reenviar_TituloVacio_Retorna400BadRequest() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.reenviar(eq(solId), eq("   "), any(), any(), anyBoolean(), eq(1L)))
                .thenThrow(new IllegalArgumentException("El título del documento es obligatorio"));

        mockMvc.perform(multipart("/api/solicitudes/" + solId + "/reenviar")
                        .with(request -> { request.setMethod("PUT"); return request; })
                        .param("version", "1")
                        .param("titulo", "   ")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Solicitud Inválida"))
                .andExpect(jsonPath("$.detail").value("El título del documento es obligatorio"));
    }

    @Test
    void reenviar_SolicitudValida_Retorna200OkYTransicionaAPendienteRevision() throws Exception {
        UUID solId = UUID.randomUUID();
        SolicitudResponse mockResponse = new SolicitudResponse(
                solId,
                "Documento Subsanado",
                "Descripción corregida",
                "PENDIENTE_REVISION",
                UUID.randomUUID(),
                "Juan Emisor",
                "emisor@test.local",
                null,
                Instant.now(),
                Instant.now()
        );

        when(solicitudService.reenviar(eq(solId), eq("Documento Subsanado"), any(), any(), anyBoolean(), eq(1L)))
                .thenReturn(mockResponse);

        mockMvc.perform(multipart("/api/solicitudes/" + solId + "/reenviar")
                        .with(request -> { request.setMethod("PUT"); return request; })
                        .param("version", "1")
                        .param("titulo", "Documento Subsanado")
                        .param("descripcion", "Descripción corregida")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(solId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE_REVISION"))
                .andExpect(jsonPath("$.titulo").value("Documento Subsanado"));
    }
}
