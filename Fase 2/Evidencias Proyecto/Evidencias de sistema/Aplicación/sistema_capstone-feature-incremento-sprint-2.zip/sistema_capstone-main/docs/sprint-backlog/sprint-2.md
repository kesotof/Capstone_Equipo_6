# Sprint 2 Backlog - Flujos Configurables, Organización, RUT y SLA

**Sprint**: 2  
**Tablero Trello**: `Sprint 2: Flujos configurables y motor RBAC`  
**Board ID**: `6ababbd1f8dcf05351074e87`  
**Lista Trello**: `Sprint Backlog` (`6ababbeddb97d82da451bef7`)  
**Documentos Vivos Asociados en Google Workspace**:
- **Minuta Acta de Reunión N° 1**: `1xrnJKkMArH7o2X5CR7zbn4TqOTv4V4sc` (16 de septiembre de 2026)
- **Minuta Acta de Reunión N° 2**: `1_xkap49-WeLhYmR_Pua84-sfwt-FXLmk` (21 de septiembre de 2026)
- **Burndown Chart**: `1FJGQswZO9VT2rOujiujITYT_ijHNhHhGF5v9cu7k4fk` (Pestaña: *sprint 2*)
- **Especificación de Pruebas E2E**: [`tests/e2e/SPRINT_2_E2E_SPECS.md`](../../tests/e2e/SPRINT_2_E2E_SPECS.md)

---

## 1. Resumen Ejecutivo del Sprint 2

El Sprint 2 tiene como objetivo completar la arquitectura de flujos configurables por área, la estructura departamental corporativa basada en el organigrama real de Masterbase, el control de identidades con RUT chileno validado, y los acuerdos de nivel de servicio (SLA) con alertas por tipo de documento:

1. **Estructura Organizacional y Jerarquía**: Gestión de áreas corporativas, vinculación de usuarios a departamentos, asignación de administradores de área y aislamiento de permisos vertical/horizontal según las actas de reunión.
2. **Identidad y Trazabilidad (RUT)**: Validación de formato `NN.NNN.NNN-N` con dígito verificador y unicidad al crear usuarios.
3. **Flujos Dinámicos Configurables**: Definición de pasos secuenciales y responsables de revisión por cada tipo de trámite.
4. **Matriz de Plazos SLA y Alertas**: Configuración de plazos máximos en días hábiles por tipo de documento y alertas visuales de vencimiento en revisiones pendientes.
5. **Inventario, Consultas y Reportes**: Búsqueda avanzada con filtros departamentales, visualización de estado en tiempo real, descarga de documentos y dashboard de resumen general.

---

## 2. Historias de Usuario Oficiales del Sprint Backlog (14 Historias)

A continuación se detallan las 14 historias de usuario presentes en el Sprint Backlog de Trello sincronizadas en local, con sus criterios de aceptación oficiales, listas de control `Por implementar` y mapeo a suites automatizadas:

---

### Historia 1: Asignar un RUT al crear usuario (`HU-S2-01` / `auth-005`)
- **Card Trello**: `6abac8b22eb672e2c03aa317` | [Ver en Trello](https://trello.com/c/WiZIsYvm)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** asignar un RUT a los usuarios de la plataforma cuando estoy creando sus cuentas.
  - **Para:** registrar datos de cada usuario de forma completa y tener mejor trazabilidad.
- **Criterios de Aceptación Oficiales**:
  - Al momento de crear un usuario, se debe agregar un rut asociado a la nueva cuenta.
  - El campo de rut se debe autoformatear a medida que se ingresan los numeros del rut (formato NN.NNN.NNN-N, donde N es un numero o la letra “K”).
    - Si se ingresa una “k” minuscula, se debe mostrar en pantalla como “K” mayuscula con el autoformato.
  - No debe estar permitido ingresar caracteres diferentes a numeros, la letra “k” o “K”.
  - No debe estar permitido ingresar espacios vacios.
  - No debe estar permitido ingresar caracteres “de mas”.
  - Casos en donde no se permite crear una cuenta:
    - Rut ingresado no es válido (verificacion por digito verificador).
    - Rut ingresado está duplicado.
  - Si hay algunos de los errores anteriores, mostrar en pantalla un mensaje de error explicativo según sea el caso.
- **Lista de Control (Por implementar)**:
  1. [ ] al momento de crear un usuario, se debe agregar un rut asociado a la nueva cuenta
  2. [ ] el campo de rut se debe autoformatear a medida que se ingresan los numeros del rut (formato NN.NNN.NNN-N, donde N es un numero o la letra “K”)
     1. [ ] si se ingresa una “k” minuscula, se debe mostrar en pantalla como “K” mayuscula con el autoformato
  3. [ ] no debe estar permitido ingresar caracteres diferentes a numeros, la letra “k” o “K”
  4. [ ] no debe estar permitido ingresar espacios vacios
  5. [ ] no debe estar permitido ingresar caracteres “de mas”
  6. [ ] casos en donde no se permite crear una cuenta:
     1. [ ] rut ingresado no es válido (verificacion por digito verificador)
     2. [ ] rut ingresado está duplicado
  7. [ ] si hay algunos de los errores anteriores, mostrar en pantalla un mensaje de error explicativo según sea el caso
- **Mapeo de Pruebas E2E**: `E2E-RUT-01` (`rut-validation.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Modelado y especificación de validación de RUT chileno`
  - `[BACKEND] Validación de RUT, unicidad y persistencia en auth-service`
  - `[FRONTEND] Input de RUT con autoformato en tiempo real y manejo de errores`
  - `[TEST] Validación de criterios de aceptación para Asignar un RUT al crear usuario`
- **Estado Técnico**: **POR HACER**

---

### Historia 2: Gestionar areas corporativas (`HU-S2-02` / `org-001`)
- **Card Trello**: `6abac5222fe8f491e650d0fb` | [Ver en Trello](https://trello.com/c/9FxpGqoY)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** crear y mantener las áreas de la empresa.
  - **Para:** organizar a los usuarios y solicitudes según el área a la que pertenecen.
- **Criterios de Aceptación Oficiales**:
  - Se debe poder crear una nueva área con un nombre.
  - Se debe poder cambiar la información de un área existente.
  - Se debe poder desactivar un área que ya no se utilice.
  - No se deben permitir dos áreas con el mismo nombre.
  - Solo los administradores deben poder realizar estos cambios.
- **Lista de Control (Por implementar)**:
  1. [ ] se debe poder crear una nueva área con un nombre
  2. [ ] se debe poder cambiar la información de un área existente
  3. [ ] se debe poder desactivar un área que ya no se utilice
  4. [ ] no se deben permitir dos áreas con el mismo nombre
  5. [ ] solo los administradores deben poder realizar estos cambios
- **Mapeo de Pruebas E2E**: `E2E-ORG-01` (`corporate-areas.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Modelo de datos y contratos REST para áreas corporativas`
  - `[BACKEND] APIs de gestión y ciclo de vida de áreas corporativas`
  - `[FRONTEND] Vista de administración y modales de gestión de áreas`
  - `[TEST] Validación de criterios de aceptación para Gestionar áreas corporativas`
- **Estado Técnico**: **POR HACER**

---

### Historia 3: Asignar administrador de área (`HU-S2-03` / `org-002`)
- **Card Trello**: `6abac5446c5284bcd007bca9` | [Ver en Trello](https://trello.com/c/91ZbUjB4)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** asignar un administrador a cada área.
  - **Para:** dejar a una persona responsable de gestionar esa área dentro de la plataforma.
- **Criterios de Aceptación Oficiales**:
  - Solo un administrador debe poder realizar esta asignación.
  - La persona elegida debe ser un usuario activo.
  - Debe quedar claro qué área administra cada persona.
  - Se debe poder cambiar al administrador de un área cuando sea necesario.
  - El cambio debe quedar registrado.
- **Lista de Control (Por implementar)**:
  1. [ ] solo un administrador debe poder realizar esta asignación
  2. [ ] la persona elegida debe ser un usuario activo
  3. [ ] debe quedar claro qué área administra cada persona
  4. [ ] se debe poder cambiar al administrador de un área cuando sea necesario
  5. [ ] el cambio debe quedar registrado
- **Mapeo de Pruebas E2E**: `E2E-ORG-01` (`corporate-areas.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Modelo relacional y auditoría de administradores de área`
  - `[BACKEND] Endpoint de asignación de admin de área y registro de auditoría`
  - `[FRONTEND] Selector de administrador de área en interfaz y trazabilidad visual`
  - `[TEST] Validación de criterios de aceptación para Asignar administrador de área`
- **Estado Técnico**: **POR HACER**

---

### Historia 4: Vincular usuarios con sus áreas (`HU-S2-04` / `org-003`)
- **Card Trello**: `6abac5536ab271708b508519` | [Ver en Trello](https://trello.com/c/JScODKgq)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** asignar cada usuario a su área correspondiente.
  - **Para:** organizar correctamente a las personas dentro de la empresa y mostrarles lo que corresponde a su área.
- **Criterios de Aceptación Oficiales**:
  - El usuario y el área deben existir antes de realizar la asignación.
  - Se debe poder elegir el área a la que pertenece un usuario.
  - El área asignada debe aparecer en la información del usuario.
  - Se debe poder cambiar de área a un usuario cuando sea necesario.
  - El cambio debe quedar registrado.
- **Lista de Control (Por implementar)**:
  1. [ ] el usuario y el área deben existir antes de realizar la asignación
  2. [ ] se debe poder elegir el área a la que pertenece un usuario
  3. [ ] el área asignada debe aparecer en la información del usuario
  4. [ ] se debe poder cambiar de área a un usuario cuando sea necesario
  5. [ ] el cambio debe quedar registrado
- **Mapeo de Pruebas E2E**: `E2E-ORG-01` (`corporate-areas.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Estructura de vinculación departamental de usuarios`
  - `[BACKEND] Endpoints para vinculación y consulta de usuarios por área`
  - `[FRONTEND] Asignación de área en gestión de usuarios y visualización de pertenencia`
  - `[TEST] Validación de criterios de aceptación para Vincular usuarios con sus áreas`
- **Estado Técnico**: **POR HACER**

---

### Historia 5: Gestionar flujos (`HU-S2-05` / `flow-008`)
- **Card Trello**: `6abac56a5dd4367af193f826` | [Ver en Trello](https://trello.com/c/A2IsGPkM)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** crear y configurar los pasos que debe seguir cada tipo de solicitud.
  - **Para:** adaptar el proceso de revisión y aprobación a las necesidades de cada área.
- **Criterios de Aceptación Oficiales**:
  - Se debe poder crear un flujo con un nombre y asociarlo a un área.
  - Se deben poder definir los pasos por los que pasará una solicitud.
  - Se debe poder indicar quién será responsable de revisar en cada paso.
  - Se debe poder cambiar el orden o la configuración del flujo.
  - Un flujo incompleto no debe poder utilizarse para nuevas solicitudes.
- **Lista de Control (Por implementar)**:
  1. [x] se debe poder crear un flujo con un nombre y asociarlo a un área
  2. [x] se deben poder definir los pasos por los que pasará una solicitud
  3. [x] se debe poder indicar quién será responsable de revisar en cada paso
  4. [x] se debe poder cambiar el orden o la configuración del flujo
  5. [x] un flujo incompleto no debe poder utilizarse para nuevas solicitudes
- **Mapeo de Pruebas E2E**: `E2E-FLOW-CONFIG-01` (`flow-configuration.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Modelo de máquina de estados para flujos configurables por área` — [tarjeta](https://trello.com/c/gupnrtKD), diseño documental completo el 03-10-2026.
  - `[BACKEND] APIs de definición de flujos y etapas secuenciales` — [tarjeta](https://trello.com/c/LYr0pd2i), implementación backend completa y activada con consumidor compatible el 03-10-2026; validación funcional pendiente.
  - `[FRONTEND] Interfaz de diagramación y configuración de flujos por área` — [tarjeta](https://trello.com/c/xTM8j6ZW), implementación completa y activada en Docker local el 03-10-2026; validación del equipo pendiente.
  - `[TEST] Validación de criterios de aceptación para Gestionar flujos`
- **Revisión de continuidad (03-10-2026)**: La configuración y el resultado E2E del 02-10-2026 se conservan como evidencia histórica de los checks anteriores. La lectura de las tarjetas vigentes y del código detectó que aprobar no avanza a la etapa siguiente, el alta deja flujos activos/incompletos y la activación no exige consistencia. Los checks anteriores no acreditan estas reglas del motor ni concurrencia tras RBAC.
- **Entrega de diseño**: [flujos-configurables-por-area-sprint-2.md](../design/flujos-configurables-por-area-sprint-2.md) define el modelo, transición por etapa, activación, permisos, historial y compatibilidad. [API_CONTRACTS.md §8.1](../API_CONTRACTS.md#81-gestión-y-configuración-de-flujos-corporativos-apiflujos) documenta alias `/api/workflows`, PATCH status, REVISION y versiones implementados.
- **Entrega backend (03-10-2026)**: alta inactiva, activación consistente, CRUD y alias, etapas 1..N, avance intermedio/final, corrección/reenvío en el mismo paso, versiones obligatorias, locks comunes con RBAC, historial por etapa y avisos al responsable actual. Migración aditiva con reconciliación única; conservación de solicitudes terminales e historial legacy. Artefacto compilado omitiendo tests; revisión funcional posterior pendiente.
- **Entrega frontend**: diseñador secuencial con responsables autorizados, 10 filas/filtros, borradores inactivos, activación explícita, protección de base/estructura usada y conflictos con recarga explícita. Decisión/reenvío envían versión, muestran etapa actual y aprobación intermedia; historial presenta origen/destino sin reconstruir eventos legacy. Pestaña SLA conservada.
- **Activación local**: Vite 1594 módulos y Maven Java 21 sin tests correctos; frontend/backend activados conjuntamente. Health UP, ruta y bundle HTTP 200; 23 solicitudes, 32 documentos y 63 eventos conservados con hashes coincidentes. Estas comprobaciones no acreditan los CAs funcionales.
- **Pendiente de aprobación**: recorridos funcionales del motor, concurrencia y destinatarios, E2E del equipo y confirmación visual. HU-S2-05 permanece in_progress; HU-S2-06 conserva alcance separado para reasignar responsables sin reemplazar etapas usadas.
- **Estado Técnico**: **EN PROGRESO** (Diseño, backend y frontend implementados, registrados en 465c673 y activados localmente. Verificación funcional/E2E y confirmación visual pendientes.)

---

### Historia 6: Configurar responsables de revisión (`HU-S2-06` / `flow-009`)
- **Card Trello**: `6abac58f50dc5ec3df943eae` | [Ver en Trello](https://trello.com/c/EdDP9OK9)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** definir quién revisará cada etapa de una solicitud.
  - **Para:** asegurar que cada documento llegue a la persona correcta durante su proceso de revisión.
- **Criterios de Aceptación Oficiales**:
  - Se debe poder elegir quién será responsable de revisar cada etapa.
  - Solo se deben poder seleccionar usuarios que estén disponibles en la plataforma.
  - Se debe poder cambiar al responsable cuando sea necesario.
  - Una etapa no debe quedar sin responsable si necesita revisión.
  - Los cambios deben quedar guardados.
- **Lista de Control (Por implementar)**:
  1. [ ] se debe poder elegir quién será responsable de revisar cada etapa
  2. [ ] solo se deben poder seleccionar usuarios que estén disponibles en la plataforma
  3. [ ] se debe poder cambiar al responsable cuando sea necesario
  4. [ ] una etapa no debe quedar sin responsable si necesita revisión
  5. [ ] los cambios deben quedar guardados
- **Mapeo de Pruebas E2E**: `E2E-FLOW-CONFIG-01` (`flow-configuration.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Modelo de asignación de revisores y reglas de no-orfandad`
  - `[BACKEND] Lógica de asignación de revisores y validación de etapas huérfanas`
  - `[FRONTEND] Componente de selección de revisores por etapa de flujo`
  - `[TEST] Validación de criterios de aceptación para Configurar responsables de revisión`
- **Estado Técnico**: **IMPLEMENTADO — validación funcional/E2E y visual pendiente**

- **Revisión Trello 03-10-2026**: historia EdDP9OK9 (lista 0/5), diseño C2bSMzBf, backend DHtQRd5C y frontend W9HG4MpI leídos completos. Las tarjetas técnicas permanecen en Por Hacer.
- **Diseño**: docs/design/asignacion-revisores-no-orfandad-sprint-2.md completo; tipos USUARIO/ROL_DEPARTAMENTAL, resolución local, no-orfandad, contratos, versiones, continuidad, notificaciones e interfaz.
- **Backend**: PUT /api/workflows/{id}/steps/{stepId}/assignee y alias español, catálogos por flujo/etapa, rol departamental resoluble, validaciones 422, reasignación sin reemplazar IDs y protección RBAC de etapas actuales/futuras. Versiones, auditoría antes/después y nuevos destinatarios sin alterar historial documental.
- **Frontend**: ReviewerSelector compartido, usuario/rol disponible, candidatos/área de rol, avisos rojo/ámbar y bloqueo de guardar/activar. Cambio específico de responsable en flujos usados; versiones, conflicto con formulario preservado y recarga explícita. Componentes corporativos existentes y 10 filas.
- **Entrega**: Java 21 Maven package con tests omitidos y Vite producción correctos; Docker backend/frontend actualizado, health UP, ruta y assets HTTP 200. Datos de negocio conservados. HU-S2-06 in_progress hasta aprobación del equipo; 5/5 del 02-10-2026 es evidencia histórica y no acredita el comportamiento nuevo.

---

### Historia 7: Gestionar roles y permisos (`HU-S2-07` / `auth-004`)
- **Card Trello**: `6abac57cf46c0ced5e0dcb37` | [Ver en Trello](https://trello.com/c/tDqEOocd)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** definir los roles, departamentos y niveles de acceso de los usuarios.
  - **Para:** asegurar que cada usuario acceda solo a los documentos y funciones de su área respetando la jerarquía corporativa.
- **Criterios de Aceptación Oficiales**:
  - Se debe poder crear y editar roles.
  - Cada rol debe permitir definir qué acciones puede realizar en la plataforma.
  - Solo los administradores deben poder cambiar los roles y permisos.
  - Un usuario no debe poder realizar acciones que no correspondan a su rol.
  - Los permisos de visualización deben aislar los documentos según el departamento o área corporativa del usuario.
  - Se debe respetar la jerarquía organizacional: una jefatura puede visualizar documentos de su equipo a cargo, pero no los de su superior directo.
  - Los cambios de permisos y roles deben quedar guardados y auditables.
- **Lista de Control (Por implementar)**:
  1. [ ] se debe poder crear y editar roles
  2. [ ] cada rol debe permitir definir qué acciones puede realizar en la plataforma
  3. [ ] solo los administradores deben poder cambiar los roles y permisos
  4. [ ] un usuario no debe poder realizar acciones que no correspondan a su rol
  5. [ ] los permisos de visualización deben aislar los documentos según el departamento o área corporativa del usuario
  6. [ ] se debe respetar la jerarquía organizacional: una jefatura puede visualizar documentos de su equipo a cargo, pero no los de su superior directo
  7. [ ] los cambios de permisos y roles deben quedar guardados y auditables
- **Mapeo de Pruebas E2E**: `E2E-DOC-SEARCH-01` (`document-search-isolation.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Matriz de control de acceso RBAC departamental y jerárquico`
  - `[BACKEND] Filtros de seguridad departamentales y jerárquicos en endpoints`
  - `[FRONTEND] Adaptación de menús, vistas y controles según rol y área`
  - `[TEST] Validación de criterios de aceptación para Gestionar roles y permisos`
- **Entrega de Diseño (03-10-2026)**: Matriz, alcances departamentales, jefatura directa, modelo y migración completos en [rbac-departamental-jerarquico-sprint-2.md](../design/rbac-departamental-jerarquico-sprint-2.md).
- **Entrega Backend (03-10-2026)**: Filtros comunes mediante especificaciones JPA, autorización local por acción, roles configurables, jefatura directa, contexto propio, auditoría y migración implementados. Contratos en [API_CONTRACTS.md §9](../API_CONTRACTS.md#9-diseño-rbac-departamental-y-jerárquico--hu-s2-07). Frontend y activación local entregados; validación funcional/E2E y visual pendiente. HU-S2-07 permanece EN PROGRESO.
- **Entrega Frontend y activación (03-10-2026)**: Contexto local, rutas/menús por permiso, gestión de roles y jefatura, catálogos autorizados y controles por solicitud implementados. Vite/Maven compilados; backend y frontend activados localmente con compatibilidad de flujo_definicion.completo. Comprobaciones de arranque/salud; criterios funcionales y aprobación visual pendientes.
- **Estado Técnico**: **EN PROGRESO** (Diseño, backend y frontend implementados y activados localmente. Verificación funcional/E2E y confirmación visual pendientes; los criterios de aceptación permanecen sin acreditar.)

---

### Historia 8: Configurar plazos de aprobación y alertas por tipo de documento (`HU-S2-08` / `sla-001`)
- **Card Trello**: `6abad413a4c55641782295e2` | [Ver en Trello](https://trello.com/c/DFZX95Lp)
- **Descripción**:
  - **Como:** Administrador.
  - **Quiero:** definir una matriz de plazos de aprobación según el tipo de documento y configurar alertas visuales de vencimiento.
  - **Para:** controlar los acuerdos de nivel de servicio (SLA), evitar retrasos operacionales y alertar oportunamente a los revisores.
- **Criterios de Aceptación Oficiales**:
  - Se debe poder configurar un plazo máximo en días hábiles según el tipo de documento (ej. 4 días hábiles para contratos de servicios, 2 días para órdenes de compra).
  - El cálculo del plazo debe iniciar al registrarse o enviarse el documento a revisión.
  - El sistema debe mostrar alertas visuales en la bandeja de revisiones pendientes cuando un plazo esté por vencer o vencido.
  - El plazo configurado debe aplicar a las decisiones de aprobación, rechazo y solicitud de correcciones.
  - Solo los administradores deben poder configurar o modificar los plazos.
- **Lista de Control (Por implementar)**:
  1. [x] se debe poder configurar un plazo máximo en días hábiles según el tipo de documento (ej. 4 días hábiles para contratos de servicios, 2 días para órdenes de compra)
  2. [x] el cálculo del plazo debe iniciar al registrarse o enviarse el documento a revisión
  3. [x] el sistema debe mostrar alertas visuales en la bandeja de revisiones pendientes cuando un plazo esté por vencer o vencido
  4. [x] el plazo configurado debe aplicar a las decisiones de aprobación, rechazo y solicitud de correcciones
  5. [x] solo los administradores deben poder configurar o modificar los plazos
- **Mapeo de Pruebas E2E**: `E2E-SLA-01` (`sla-matrix-alerts.spec.ts`)
- **Tareas Técnicas**:
  - `[DISEÑO] Modelo de matriz SLA en días hábiles y estados de alerta semántica` — entrega documental completa el 12-10-2026.
  - `[BACKEND] Servicio de cálculo SLA y enriquecimiento de solicitudes` — completo y activo localmente el 12-10-2026.
  - `[FRONTEND] Configuración de SLA y badges de alerta en bandeja de revisiones` — completo y activo localmente el 12-10-2026; 100 comprobaciones focalizadas correctas.
  - `[TEST] Validación de criterios de aceptación para Plazos de aprobación y alertas SLA`
- **Entrega de Diseño (12-10-2026)**: **COMPLETA** en [matriz-sla-dias-habiles-sprint-2.md](../design/matriz-sla-dias-habiles-sprint-2.md): matriz global por tipo, fecha única por solicitud, calendario de lunes a viernes en Santiago, ventana de 24 horas corridas, cumplimiento por decisión, contratos, permisos, dependencias y casos de validación. Las tarjetas backend/frontend continúan con su implementación existente y los ajustes identificados para revisión posterior.
- **Entrega Backend (12-10-2026)**: **COMPLETA**, compilada y activa localmente. Reloj/registro/decisiones coherentes, cálculo eficiente con DST, límites de alerta, resolución estable, validaciones JSON, unicidad concurrente y migración aditiva. Corregido arranque con flujo base ausente sin renumerar el flujo de compra. [Evidencia: 101/101 comprobaciones focalizadas, PostgreSQL aislado, salud UP y datos conservados](../verification/sla-backend-2026-10-12.md). Sin E2E, commit ni push.
- **Evidencia histórica y revisión de estado (12-10-2026)**: Se conservan los cinco checks y el resultado 5/5 registrado el 03-10-2026 en `claude-progress.md` hito 78. La suite actual comprueba “A tiempo”, aprobación y corrección dentro de plazo; faltan pruebas específicas de por vencer/vencido, rechazo, decisiones atrasadas y límites exactos. La limpieza de cookies SSO ya está implementada. El registro histórico de cierre no coincide con `feature_list.json`, que mantiene `in_progress`; esta revisión alinea el estado sin atribuir nuevas pruebas a la entrega documental.
- **Entrega Frontend (12-10-2026)**: **COMPLETA** y activa en Docker local. Matriz global con validación/confirmación, permiso ADMIN y SLA_GESTIONAR, lectura cancelable y mensajes distintos para carga/error/vacío; valores/foco preservados y exclusión de doble envío. Fechas Santiago y badges comunes en bandeja/modal/detalle, nulos/desconocidos neutros, corrección sin pausa ni reinicio y actualización desde servidor. [Evidencia: 100/100 comprobaciones focalizadas, revisión visual aislada escritorio/móvil, compilación y HTTP 200](../verification/sla-frontend-2026-10-12.md). Datos reales conservados; sin E2E, commit ni push.
- **Estado Técnico**: **EN PROGRESO** (Diseño, backend y frontend completos. Pendientes la validación integrada de criterios restantes en la tarjeta TEST y la confirmación visual/E2E del equipo. Las comprobaciones focalizadas y la vista aislada no sustituyen esa validación.)

---

### Historia 9: Ver detalle de una solicitud (Emisor/Revisor) (`HU-S2-09` / `flow-010`)
- **Card Trello**: `6abac5cbe57497ce0ac4653c` | [Ver en Trello](https://trello.com/c/evnCim54)
- **Descripción**:
  - **Como:** Emisor o Revisor.
  - **Quiero:** ver toda la información de una solicitud.
  - **Para:** revisar en un solo lugar sus datos, documentos, estado y observaciones.
- **Criterios de Aceptación Oficiales**:
  - La solicitud debe mostrar su información principal.
  - Se deben poder ver los documentos adjuntos.
  - Se debe mostrar el estado actual de la solicitud.
  - Se deben poder mostrar las observaciones cuando existan.
  - Solo las personas con acceso a la solicitud deben poder ver su detalle.
- **Lista de Control (Por implementar)**:
  1. [ ] la solicitud debe mostrar su información principal
  2. [ ] se deben poder ver los documentos adjuntos
  3. [ ] se debe mostrar el estado actual de la solicitud
  4. [ ] se deben poder mostrar las observaciones cuando existan
  5. [ ] solo las personas con acceso a la solicitud deben poder ver su detalle
- **Mapeo de Pruebas E2E**: `E2E-DOC-SEARCH-01` (`document-search-isolation.spec.ts`)
- **Tareas Técnicas**:
  - `[DISEÑO] Contrato de respuesta y layout visual de detalle de solicitud`
  - `[BACKEND] Endpoint unificado de detalle y consulta de solicitud`
  - `[FRONTEND] Componente y vista de detalle integral de solicitud`
  - `[TEST] Validación de criterios de aceptación para Ver detalle de una solicitud`
- **Entrega de Diseño (03-10-2026)**: [detalle-solicitud-sprint-2.md](../design/detalle-solicitud-sprint-2.md) completa la tarjeta [DHw7tXhY](https://trello.com/c/DHw7tXhY). Historia y cuatro tarjetas técnicas consultadas en Trello. DTO RequestDetailResponse, endpoint requerido GET /api/requests/{id}/detail y alias, proyección consistente, permisos por sección, compatibilidad legacy y layout empresarial definidos. Contratos en [API_CONTRACTS.md §10](../API_CONTRACTS.md#10-detalle-integral-de-solicitud--hu-s2-09).
- **Entrega de Backend (03-10-2026)**: tarjeta [hI0sFxji](https://trello.com/c/hI0sFxji) implementada: RequestDetailController/Service, DTOs inmutables, lectura REPEATABLE_READ con contexto RBAC renovado, versiones documentales y áreas capturadas, proyecciones de observaciones/eventos con orden estable y comentarios restringidos, SLA/capacidades compartidos. Conflicto 409 si hay varios vigentes; errores seguros y no-store. Contratos existentes preservados, sin migraciones.
- **Entrega de Frontend (03-10-2026)**: tarjeta [2BZTI0DJ](https://trello.com/c/2BZTI0DJ) implementada: `/solicitudes/:id`, cabecera corporativa, pestañas Resumen/Documentos/Observaciones/Historial, 10 registros por página, visor PDF y descarga autenticada del vigente, secciones restringidas y errores seguros, recarga cancelable ante cambios de ID/sesión/acceso. Accesos desde Estado de solicitudes, Revisar documento y Mis documentos con recuperación de filtros/página/selección y enlace directo compatible con OIDC. Vite producción correcto, 1605 módulos; Docker frontend actualizado, HTTP 200 y backend UP.
- **Siguiente entrega**: validación funcional/E2E y aprobación visual del equipo ([m4v3uOPe](https://trello.com/c/m4v3uOPe)). Los cinco criterios siguen sin acreditar; compilación y disponibilidad no sustituyen esa evidencia.
- **Estado Técnico**: **EN PROGRESO** (Diseño, backend y frontend implementados; validación pendiente. Tarjeta frontend releída En Proceso.)

---

### Historia 10: Consultar documentos (`HU-S2-10` / `doc-002`)
- **Card Trello**: `6abac613487611c98ad7f89e` | [Ver en Trello](https://trello.com/c/iWk3otyk)
- **Descripción**:
  - **Como:** Usuario del sistema.
  - **Quiero:** buscar y consultar documentos.
  - **Para:** encontrar rápidamente la información que necesito según mi área y perfil asignado.
- **Criterios de Aceptación Oficiales**:
  - El usuario debe ver solo los documentos que correspondan a su departamento y rol permitido.
  - Se debe respetar la jerarquía organizacional: las jefaturas acceden a documentos de sus colaboradores directos pero no a los de rangos superiores.
  - Se debe poder buscar documentos por información relevante.
  - Se debe poder filtrar por datos como tipo de documento, estado, área o fecha.
  - Cada resultado debe mostrar información básica del documento incluyendo su código correlativo.
  - Al seleccionar un documento, se debe poder ver su detalle.
- **Lista de Control (Por implementar)**:
  1. [ ] el usuario debe ver solo los documentos que correspondan a su departamento y rol permitido
  2. [ ] se debe respetar la jerarquía organizacional: las jefaturas acceden a documentos de sus colaboradores directos pero no a los de rangos superiores
  3. [ ] se debe poder buscar documentos por información relevante
  4. [ ] se debe poder filtrar por datos como tipo de documento, estado, área o fecha
  5. [ ] cada resultado debe mostrar información básica del documento incluyendo su código correlativo
  6. [ ] al seleccionar un documento, se debe poder ver su detalle
- **Mapeo de Pruebas E2E**: `E2E-DOC-SEARCH-01` (`document-search-isolation.spec.ts`)
- **Tareas Técnicas y entrega local**:
  - `[DISEÑO] Especificación de búsqueda multicriterio y filtros de consulta` ([eEYq5cka](https://trello.com/c/eEYq5cka)): diseño completo en `docs/design/busqueda-documentos-sprint-2.md` y API §11.
  - `[BACKEND] Endpoint de búsqueda avanzada de documentos con especificaciones JPA` ([VUmgxQbW](https://trello.com/c/VUmgxQbW)): implementación completa de GET `/api/documents/search` y `/filters`, filtros, paginación/orden y DTOs; RBAC antes de contar/paginar y documento vigente con enlace al detalle integral.
  - `[FRONTEND] Barra de búsqueda y panel de filtros avanzados de documentos` ([ViMR7Qq0](https://trello.com/c/ViMR7Qq0)): implementada en `/consultar-documentos`; DocumentSearchPage, texto libre, filtros colapsables, limpieza, orden, páginas fijas de 10 y navegación al detalle con regreso al contexto.
  - `[TEST] Validación de criterios de aceptación para Consultar documentos` ([Jre5yKxV](https://trello.com/c/Jre5yKxV)): pendiente del equipo; seis criterios sin acreditar.
- **Definiciones**: `documentType` corresponde al formato persistido, no a una clasificación empresarial inferida. Fecha de emisión de la solicitud en America/Santiago; áreas capturadas, versiones históricas en el detalle; ningún filtro amplía el alcance.
- **Evidencia técnica (03-10-2026)**: Maven Java 21 package BUILD SUCCESS, 178 fuentes; compilación y ejecución de tests omitidas. Backend actualizado en Docker, JPA inicializado, health UP y reinicios 0; OpenAPI publica ambas rutas y nueve parámetros. Frontend Vite producción correcto, 1610 módulos, imagen local actualizada; ruta y cuatro assets JS/CSS HTTP 200. Esto no acredita recorridos funcionales ni criterios de aislamiento.
- **Lectura de Trello (03-10-2026)**: diseño/backend/frontend en Por Hacer; TEST en Por Hacer. Tablero: 14 historias, 36 Por Hacer, 0 En Proceso, 21 Terminado.
- **Estado Técnico**: **EN PROGRESO** — diseño/backend/frontend implementados; validación funcional/E2E y aprobación visual pendientes. Los checklists oficiales permanecen abiertos.

---

### Historia 11: Consultar estado de mis solicitudes (`HU-S2-11` / `flow-011`)
- **Card Trello**: `6abac635d5ba9c0fb81aec6b` | [Ver en Trello](https://trello.com/c/cCa4ae8F)
- **Descripción**:
  - **Como:** Emisor.
  - **Quiero:** consultar el estado de mis solicitudes.
  - **Para:** saber en qué etapa se encuentran y si tengo que realizar alguna acción.
- **Criterios de Aceptación Oficiales**:
  - El usuario debe ver sus solicitudes y aquellas a las que tenga acceso.
  - Cada solicitud debe mostrar claramente su estado actual y su código correlativo.
  - Debe indicarse si está pendiente de revisión, necesita correcciones, fue aprobada o fue rechazada.
  - Al seleccionar una solicitud, se debe poder ver su detalle e historial inmutable.
  - Los cambios de estado deben verse reflejados en la consulta.
- **Lista de Control (Por implementar)**:
  1. [ ] el usuario debe ver sus solicitudes y aquellas a las que tenga acceso
  2. [ ] cada solicitud debe mostrar claramente su estado actual y su código correlativo
  3. [ ] debe indicarse si está pendiente de revisión, necesita correcciones, fue aprobada o fue rechazada
  4. [ ] al seleccionar una solicitud, se debe poder ver su detalle e historial inmutable
  5. [ ] los cambios de estado deben verse reflejados en la consulta
- **Mapeo de Pruebas E2E**: `E2E-DOC-SEARCH-01` (`document-search-isolation.spec.ts`)
- **Tareas Técnicas**:
  - `[DISEÑO] Modelo de consulta y experiencia de seguimiento para el emisor` — [VQYbuikz](https://trello.com/c/VQYbuikz): diseño completo en [seguimiento-solicitudes-emisor-sprint-2.md](../design/seguimiento-solicitudes-emisor-sprint-2.md).
  - `[BACKEND] Endpoint de consulta de solicitudes propias del emisor` — [geKNR0T0](https://trello.com/c/geKNR0T0): implementado y disponible en Docker; tarjeta releída En Proceso.
  - `[FRONTEND] Vista de "Mis Solicitudes" con correlativo y estado en tiempo real` — [uLsr2Uww](https://trello.com/c/uLsr2Uww): implementada y disponible en Docker; tarjeta releída En Proceso.
  - `[TEST] Validación de criterios de aceptación para Consultar estado de mis solicitudes` — [Xv7UDGGc](https://trello.com/c/Xv7UDGGc): validación del equipo pendiente.
- **Entrega de diseño (04-10-2026)**: MyRequestsSummaryResponse/MyRequestsPageResponse, propia estricta mediante sub → cuenta local y bandeja autorizada por RBAC; GET `/api/requests/my-requests` y `/api/requests/accessible` propuestos, orden por última actualización descendente y páginas de servidor de 10. Experiencia en la ruta existente `/estado-solicitudes`, componentes corporativos, cuatro estados, etapa/fechas, detalle e historial HU-S2-09, corrección por capacidad, refresco visible de 30 segundos, control de acceso/cancelación y navegación restaurable. Contratos API §12 y cinco criterios trazados; consumidores legacy compatibles, sin cambios al motor ni datos.
- **Entrega backend (04-10-2026)**: GET propia/autorizada implementados con MyRequestsController/Service/QueryNormalizer, records inmutables, filtros de texto/estado/área, páginas y RBAC antes del total. Etapa/emisor/estado en la lectura; áreas y capacidad REENVIAR por lotes. No-store en respuestas y errores, ProblemDetail seguro, sin MinIO, migraciones o cambios de contratos legacy. Maven Java 21 BUILD SUCCESS, 189 fuentes, tests omitidos. Backend Docker arrancado, health UP y OpenAPI publica ambas rutas, 14 campos de resumen y nueve de página; frontend existente HTTP 200. Esta evidencia no acredita los recorridos funcionales de los cinco criterios.
- **Entrega frontend (04-10-2026)**: MyRequestsPage sustituye EstadoSolicitudesView en la misma ruta, con carga diferida y montaje por cuenta. Dos bandejas, correlativo destacado, filtros compartidos, etapa/estado/fechas, diez filas de servidor y refresco manual/visible cada 30 segundos. Servicio/hook validan contrato, renuevan acceso, cancelan lectores, retiran datos por contexto/denegación y diferencian fallos/desactualizados con reintentos 60/120 segundos. Detalle/corrección conservan regreso; enlaces legacy/OIDC por UUID validado, incluyendo ID autorizado de otro emisor para ADMIN. Vite correcto, 1613 módulos; ruta y cuatro assets HTTP 200, backend UP. Diseño, contratos y guía visual actualizados.
- **Estado Técnico**: **EN PROGRESO** — diseño/backend/frontend implementados y disponibles localmente; cinco criterios funcionales/E2E/visuales pendientes de validación. Trello releído con 30 Por Hacer, 3 En Proceso y 24 Terminado; tarjetas de implementación HU-S2-11 en proceso y criterios aún sin verificación.

---

### Historia 12: Descargar documentos (`HU-S2-12` / `doc-003`)
- **Card Trello**: `6abac625c9a5cbe76d9340dc` | [Ver en Trello](https://trello.com/c/wtZ90Wh1)
- **Descripción**:
  - **Como:** Usuario del sistema.
  - **Quiero:** descargar un documento.
  - **Para:** poder revisarlo o utilizarlo fuera de la plataforma.
- **Criterios de Aceptación Oficiales**:
  - Solo se deben poder descargar documentos a los que el usuario tenga acceso.
  - El archivo descargado debe mantener su contenido y formato.
  - El nombre del archivo debe conservarse cuando sea posible.
  - Si el archivo no está disponible, se debe mostrar un mensaje al usuario.
- **Lista de Control (Por implementar)**:
  1. [x] solo se deben poder descargar documentos a los que el usuario tenga acceso
  2. [x] el archivo descargado debe mantener su contenido y formato
  3. [x] el nombre del archivo debe conservarse cuando sea posible
  4. [x] si el archivo no está disponible, se debe mostrar un mensaje al usuario
- **Mapeo de Pruebas E2E**: `E2E-DOC-SEARCH-01` (`document-search-isolation.spec.ts`)
- **Tareas Técnicas Implementadas**:
  - `[DISEÑO] Arquitectura de streaming y autorización para descarga de archivos`
  - `[BACKEND] Endpoint de descarga y streaming seguro desde MinIO S3`
  - `[FRONTEND] Botón y feedback de descarga en tabla y vista de detalle`
  - `[TEST] Validación de criterios de aceptación para Descargar documentos`
- **Estado Técnico**: **IMPLEMENTADO — validación funcional/E2E y visual pendiente**

- **Implementación 04-10-2026**: [diseño](https://trello.com/c/7a1PceeO) completo en docs/design/descarga-documentos-sprint-2.md; [backend](https://trello.com/c/LVU4eSqj) y [frontend](https://trello.com/c/Cz7mZUdY) implementados y disponibles localmente. Las tres tarjetas estaban En Proceso al releer Trello.
- **Resultado**: GET por ID/versiones y rutas legacy bajo RBAC; streaming acotado de MinIO, UTF-8/longitud/MIME, errores seguros y auditoría de inicio. Botón compartido en tablas/detalle/revisión con progreso, cancelación, URLs temporales y toast; versiones anteriores descargables.
- **Evidencia**: Maven Java 21 BUILD SUCCESS (198 fuentes; tests omitidos), Vite 1617 módulos/6.04 s, backend UP y frontend/assets disponibles, ambos con cero reinicios. Contrato API sección 13 y mapa actualizados.
- **Validación**: cuatro criterios funcionales/E2E y aprobación visual pendientes del equipo; checklists conservados sin marcar. [TEST](https://trello.com/c/v73cX0rq) no ejecutada en esta implementación.

---

### Historia 13: Cambiar Contraseña (`HU-S2-13` / `auth-006`)
- **Card Trello**: `6abac5e4c1604e7b8b0d286a` | [Ver en Trello](https://trello.com/c/40Xb6TFv)
- **Descripción**:
  - **Como usuario del sistema, quiero cambiar mi contraseña para mantener mi cuenta segura y proteger mi información.**
- **Criterios de Aceptación Oficiales**:
  - El usuario debe ingresar su **contraseña actual** antes de realizar el cambio.
  - El usuario debe ingresar una **nueva contraseña** y confirmarla.
  - Si la contraseña actual es incorrecta, mostrar el mensaje: **“La contraseña actual es incorrecta, inténtelo nuevamente.”**
  - La nueva contraseña debe cumplir con los **requisitos mínimos de seguridad** establecidos por el sistema.
  - Si las contraseñas nuevas no coinciden, mostrar un mensaje indicando que **las contraseñas no coinciden**.
  - Al cambiar correctamente la contraseña, mostrar un mensaje de **confirmación** y permitir al usuario continuar utilizando el sistema.
- **Lista de Control (Verificada)**:
  1. [x] El usuario debe ingresar su contraseña actual antes de realizar el cambio.
  2. [x] El usuario debe ingresar una nueva contraseña y confirmarla.
  3. [x] Si la contraseña actual es incorrecta, mostrar el mensaje: “La contraseña actual es incorrecta, inténtelo nuevamente.”
  4. [x] La nueva contraseña debe cumplir con los requisitos mínimos de seguridad establecidos por el sistema.
  5. [x] Si las contraseñas nuevas no coinciden, mostrar un mensaje indicando que las contraseñas no coinciden.
  6. [x] Al cambiar correctamente la contraseña, mostrar un mensaje de confirmación y permitir al usuario continuar utilizando el sistema.
- **Mapeo de Pruebas E2E**: `E2E-SEC-AUTH-01` (`change-password.spec.ts`)
- **Tareas Técnicas**:
  - `[DISEÑO] Especificación de seguridad para flujo de cambio de contraseña`
  - `[BACKEND] Integración con Keycloak para actualización de credenciales`
  - `[FRONTEND] Formulario de cambio de contraseña con validación de complejidad`
  - `[TEST] Validación de criterios de aceptación para Cambiar Contraseña`
- **Estado Técnico**: **VERIFICADO — SEIS CRITERIOS DE ACEPTACIÓN CORRECTOS**
- **Diseño**: [Cambio de contraseña](../design/cambio-contrasena-sprint-2.md), contratos API §8.4.
- **Backend**: GET `/api/auth/password-policy`, POST `/api/auth/change-password` y alias `/api/users/me/change-password`; identidad desde JWT, comprobación de clave actual contra Keycloak, confirmación, política efectiva, cierre exclusivo de sesión temporal y auditoría posterior. Errores ProblemDetail sin credenciales, no-store y resultado incierto sin reintento automático.
- **Frontend**: `/cambiar-contrasena`, menú Cuenta, componentes corporativos, tres campos y Mostrar/Ocultar, requisitos y fortaleza orientativa en tiempo real, foco de errores, bloqueo durante POST, vaciado de claves y toast/confirmación de éxito con continuación.
- **Configuración verificada**: política efectiva de 8–1024 caracteres, sin grupos de caracteres obligatorios ni reglas adicionales. Cliente público capstone-client/Direct Grant habilitado y fuerza bruta 4 intentos/1800 s. Configuración de identidad preservada; credencial original de prueba restaurada al finalizar.
- **Compilación y disponibilidad final (14-10-2026)**: Maven/Java 21 package BUILD SUCCESS en 2 min 27 s; nueve pruebas de regresión ejecutadas correctamente. Imagen activa capstone-password-fix:20261014-ca133-keycloak401, backend UP y cero reinicios.
- **Validación final (14-10-2026)**: lectura OAuth antes del cierre del cliente y clasificación de HTTP 400/401 con invalid_grant como HTTP 400/CURRENT_PASSWORD_INVALID. PasswordChangeOperationsTest: 9/9 pruebas correctas, cero fallos/errores/omitidos, 12.592 s. E2E: 6/6 casos correctos, sin omisiones ni reintentos, 30.4 s; seis criterios acreditados, incluido el mensaje exacto de contraseña actual incorrecta, continuidad de sesión y rechazo/acceso con contraseña anterior/nueva. Credencial original restaurada y autenticación final HTTP 200; sesión temporal cerrada HTTP 204. auth-006 passing.
- **Evidencia técnica**: HTML `tests/e2e/playwright-report/password-2026-10-14-docker-05/index.html`, seis videos en `tests/e2e/test-results/password-2026-10-14-docker-05` y XML `backend/sistema-principal/target/surefire-reports/TEST-com.capstone.sistema.users.password.PasswordChangeOperationsTest.xml`.

---

### Historia 14: Ver resumen general de solicitudes (`HU-S2-14` / `dash-002`)
- **Card Trello**: `6abac65daf0bbca6ae17bbea` | [Ver en Trello](https://trello.com/c/YnKoOQH8)
- **Descripción**:
  - **Como:** Administrador o encargado.
  - **Quiero:** ver un resumen general de las solicitudes.
  - **Para:** conocer rápidamente cómo se encuentran los procesos dentro de la plataforma.
- **Criterios de Aceptación Oficiales**:
  - Se debe mostrar la cantidad de solicitudes pendientes, aprobadas, rechazadas y en corrección.
  - Se debe poder ver información general por área cuando corresponda.
  - La información debe actualizarse según los cambios de las solicitudes.
  - Cada usuario debe ver solo la información que tenga permitido consultar.
  - El resumen debe ser claro y fácil de entender.
- **Lista de Control (Por implementar)**:
  1. [x] se debe mostrar la cantidad de solicitudes pendientes, aprobadas, rechazadas y en corrección
  2. [x] se debe poder ver información general por área cuando corresponda
  3. [x] la información debe actualizarse según los cambios de las solicitudes
  4. [x] cada usuario debe ver solo la información que tenga permitido consultar
  5. [x] el resumen debe ser claro y fácil de entender
- **Mapeo de Pruebas E2E**: `E2E-DASH-METRICS-01` (`dashboard-general-summary.spec.ts`)
- **Tareas Técnicas en Por Hacer**:
  - `[DISEÑO] Especificación de métricas de dashboard y contratos de agregación`
  - `[BACKEND] Endpoints de métricas agregadas por estado y área`
  - `[FRONTEND] Dashboard con tarjetas KPI, gráficos y desglose por área`
  - `[TEST] Validación de criterios de aceptación para Ver resumen general de solicitudes`
- **Estado Técnico**: **DISEÑO / BACKEND / FRONTEND IMPLEMENTADOS — VALIDACIÓN FUNCIONAL/E2E Y VISUAL PENDIENTE**
- **Diseño y contrato**: [Resumen general de solicitudes](../design/resumen-general-solicitudes-sprint-2.md), API §14. Cada solicitud pertenece a un único grupo por área de origen capturada, con respaldo del flujo y grupo sin área. Total igual a suma de estados; estados históricos adicionales explícitos.
- **Backend**: GET `/api/dashboard/summary`, agregación escalar de estados/áreas y emisiones de siete días en America/Santiago. Contexto RBAC renovado, intersección METRICAS_CONSULTAR/SOLICITUD_CONSULTAR, transacción REPEATABLE_READ y filtro global estricto. Catálogo histórico, ceros, ProblemDetail seguro y no-store/nosniff; sin migraciones ni cambios al motor documental.
- **Frontend**: DashboardSummary integrado sobre las bandejas existentes; KPI ámbar/verde/rojo/azul, distribución, emisiones y desglose de diez áreas por página. DropdownSelect y componentes corporativos reutilizados. Lecturas cancelables, validación de contrato, acceso/selección aislados, actualización local/periódica/visible y datos desactualizados diferenciados de cero/error.
- **Cobertura técnica**: los cinco criterios tienen correspondencia en el diseño y la implementación. El checklist conserva su estado hasta contar con resultados funcionales y aprobación visual verificables.
- **Compilación/disponibilidad**: Maven BUILD SUCCESS, 214 fuentes/1 min 28 s; Vite 1624 módulos/4.62 s. Docker backend/frontend actualizados, health UP, contrato publicado y entrada/estilos HTTP 200; contenedores sin reinicios. Evidencia acotada a compilación, arranque y publicación.

---

## 3. Matriz Resumen de Suites E2E Playwright (Sprint 2)

| Suite E2E | Archivo de Prueba | Historias de Usuario Cubiertas | Criterios Cubiertos |
| :--- | :--- | :--- | :--- |
| **`E2E-RUT-01`** | `src/specs/auth/rut-validation.spec.ts` | `HU-S2-01` (RUT al crear usuario) | 8 CAs (autoformato, `k/K`, DV, unicidad) |
| **`E2E-ORG-01`** | `src/specs/org/corporate-areas.spec.ts` | `HU-S2-02`, `HU-S2-03`, `HU-S2-04` (Áreas, admin y vinculación) | 15 CAs (CRUD áreas, admin responsable, pertenencia) |
| **`E2E-FLOW-CONFIG-01`** | `src/specs/flow/flow-configuration.spec.ts` | `HU-S2-05`, `HU-S2-06` (Flujos y revisores) | 10 CAs (etapas secuenciales, revisores, no orfandad) |
| **`E2E-SLA-01`** | `src/specs/flow/sla-matrix-alerts.spec.ts` | `HU-S2-08` (Plazos SLA y alertas) | 5 CAs (matriz días hábiles, badges verde/amarillo/rojo) |
| **`E2E-SEC-AUTH-01`** | `src/specs/auth/change-password.spec.ts` | `HU-S2-13` (Cambiar contraseña) | 6 CAs (clave actual, complejidad, confirmación) |
| **`E2E-DOC-SEARCH-01`** | `src/specs/doc/document-search-isolation.spec.ts` | `HU-S2-07`, `HU-S2-09`, `HU-S2-10`, `HU-S2-11`, `HU-S2-12` | 27 CAs (RBAC, detalle, búsqueda, estado, descarga MinIO) |
| **`E2E-DASH-METRICS-01`** | `src/specs/flow/dashboard-general-summary.spec.ts` | `HU-S2-14` (Resumen general) | 5 CAs (métricas cuantitativas, filtro área, refresco) |
