# Gobernanza Documental y Protocolo de Sincronización (Capstone)

Este documento es la **fuente de verdad operacional** sobre el rol, permisos, reglas de negocio y ciclo de actualización de todos los artefactos del proyecto almacenados en **Google Drive** y su sincronización con el **Sprint Backlog** y los **Agentes de IA**.

---

## 1. Mapa y Reglas de Artefactos en Google Drive

Todos los archivos se encuentran en formato **nativo de Google Workspace** (Google Docs y Google Sheets) dentro de la carpeta compartida del proyecto.

| Artefacto | ID en Google Drive | Tipo | Nivel de Acceso Agente | Propósito y Reglas Operativas |
| :--- | :--- | :--- | :--- | :--- |
| **`registro daily meeting`** | `1vJsoRlvYiRCBXyJ_D4w1Nu1_uPn8ZLp9s8SVQz8Dg0Q` | Google Sheet | **Solo Lectura** | Bitácora donde el equipo humano registra diariamente los acuerdos y bloqueos. El agente solo lo consulta para contexto de avance; nunca modifica filas históricas. |
| **`planificacion capstone.xlsb`** | `1DTJxtktQzw-o9x7aHxMgPTKuwv_GMyloM5mWlxDSbU0` | Google Sheet | **Solo Lectura** | Cronograma maestro de hitos y semanas académicas. Solo lectura para el agente. |
| **`Definición Proyecto APT`** | `1-Dbvk-CmO4K2zHdLmK8mjdWbBbbNgBFwBQK2Eccz5sk` | Google Doc | **Solo Lectura** | Documento base de contexto del negocio, marco teórico, alcance y requerimientos del cliente. Inmutable para los agentes. |
| **`Plan de pruebas`** | `1IJVYgmhlkqEzsfF7tfGzisUNOMW9AQva6ddavRvom9A` | Google Doc | **Editable por Agente** *(Append / Propuesta)* | **Documento vivo**. Explica la estrategia global de aseguramiento de calidad (unitarias, integración, E2E con Playwright) y **enumera y ordena los tests existentes SIN detallar**, sincronizándolos de forma estructurada con *Casos de Prueba*. |
| **`Casos de prueba`** | `19aAcFH3jr4JMrPwAJ_AUXNoC93aRvmJt6rEvJcq4v5g` | Google Sheet | **Editable por Agente** *(Append / Propuesta)* | **Documento vivo de ejecución**. Registra en detalle cada caso de prueba, su tipo (Unitario, API, E2E) y su resultado por Sprint. **Regla de oro: debe existir al menos 1 caso de prueba por cada criterio de aceptación del backlog**. |
| **`burndown chart`** | `1FJGQswZO9VT2rOujiujITYT_ijHNhHhGF5v9cu7k4fk` | Google Sheet | **Solo Lectura** | Gráfico de quema de horas/puntos del Sprint. El equipo humano lo actualiza a mano según el ritmo de entrega. |
| **`evidencias`** | `1ScHTQ8y54VDRPqrkGQ5_W1nj3zbK0dOU` | Carpeta Drive | **Lectura / Depósito** | Contenedor de capturas, logs y reportes generados. |

---

## 2. Protocolo de Sincronización Local del Sprint Backlog (`docs/sprint-backlog/`)

### 2.1 Por qué mantener una réplica local
Para que los agentes de codificación puedan planificar, implementar y testear sin depender de tokens externos de corta duración o llamadas de red lentas a APIs de gestión (como Trello), el estado del sprint se consolida en Markdown dentro de:
```
docs/sprint-backlog/sprint-<N>.md
```

### 2.2 Estructura estándar de `sprint-<N>.md`
Cada archivo de sprint local debe contener:
1. **Objetivo del Sprint**: Meta de negocio acordada.
2. **Historias y Criterios de Aceptación**: Lista clara de requerimientos funcionales (`Dado que... Cuando... Entonces...`).
3. **Mapeo de Pruebas Requeridas**: Enlace explícito entre cada criterio de aceptación y su correspondiente caso en el Google Sheet `Casos de prueba`.
4. **Estado de Ejecución**: Tareas en curso, completadas y bloqueos.

---

## 3. Ciclo de Trabajo para Agentes (TDD / Criterios de Aceptación / DoD)

Cuando un agente recibe la tarea de implementar o verificar una funcionalidad o historia de usuario:

```mermaid
flowchart TD
    A[1. Leer Criterios de Aceptación en docs/sprint-backlog/] --> B[2. Implementar Backend y Frontend]
    B --> C[3. Implementar / Actualizar Suites E2E Playwright]
    C --> D[4. Prueba Visual Conjunta con el Desarrollador UI / Headed]
    D --> E{¿Desarrollador confirma correcto funcionamiento?}
    E -- No --> B
    E -- Sí (Aprobado) --> F[5. Anexar Caso en 'Casos de prueba' Google Sheet]
    F --> G[6. Actualizar Inventario en 'Plan de pruebas' Google Doc]
    G --> H[7. Marcar Historia como Terminada en Trello y feature_list.json]
```

### Reglas de Modificación y Aceptación:
1. **Validación Visual Conjunta (Definition of Done)**:
   - **Cada vez que se implemente una feature o se complete una historia de usuario**, se deben implementar o actualizar sus tests E2E con Playwright.
   - La prueba debe ejecutarse en conjunto con el desarrollador (usando `.\scripts\run-e2e-tests.ps1 -UI` o con navegador local visible).
   - **Criterio de Aceptación Formal**: Si el desarrollador prueba visualmente el flujo y comprueba su correcto funcionamiento, se considera terminado y validado (`OK / passing`).
2. **En `Casos de prueba` (Google Sheet)**:
   - El agente añade una nueva fila en la pestaña del Sprint correspondiente (ej. `casos prueba sprint 1`) con: ID del Test, Módulo, Criterio de Aceptación cubierto, Tipo (E2E/Unitario), Estado (`PASSED`/`FAILED`), Fecha y Evidencia.
   - **Nunca** borra ni sobreescribe casos de prueba de sprints anteriores.
3. **En `Plan de pruebas` (Google Doc)**:
   - El agente añade una entrada en la tabla o lista de inventario de tests con la categoría y el nombre del test. No describe el paso a paso detallado (el detalle vive en `Casos de prueba`), manteniendo el Plan de Pruebas limpio, conciso y fácil de auditar.
4. **Lectura de Confirmación Inmediata**:
   - Todo cambio realizado por el agente en Google Workspace debe ser leído de vuelta usando el servidor MCP para validar que la API persistió la información correctamente.
