﻿# Progress Log - Archivo Historico Sprint 1 (2026-09-08 al 2026-09-28)

Este documento contiene la bitacora historica de hitos completados correspondientes a la **Infraestructura Base** y el **Sprint 1: Flujo documental simple, autenticacion y notificaciones** (Hitos 1 al 38).

Para el progreso activo del Sprint 2 y proximos pasos prioritarios, consultar [claude-progress.md](../../claude-progress.md).

---

## Estado Base del Proyecto (2026-09-08)

### Hitos Completados
1. **Infraestructura Docker Inicial (`infra-001`)**:
   - Creado `docker-compose.yml` con 4 motores de infraestructura base:
     - PostgreSQL 16 (`keycloak_db` y `sistema_db`).
     - Keycloak 24.0.5 (SSO / OIDC).
     - RabbitMQ 3.13 con interfaz de gestión.
     - MinIO con inicializador automático de buckets S3 (`documentos`).
   - Creados archivos `.env.example`, `.env` y script de base de datos `docker/postgres/init/01-init-databases.sh`.
   - Definidos perfiles de Compose para levantar solo infraestructura o todo el conjunto (`--profile apps`).
   - **Verificación en caliente ejecutada (Stack Completo)**: Construidas y levantadas con éxito todas las imágenes en Docker Desktop. Los **8 contenedores** se encuentran en ejecución activa y respondiendo:
     - `capstone-frontend`: React SPA en puerto `3000` (HTTP 200).
     - `capstone-sistema-principal`: Spring Boot en puerto `8081` (`{"status":"UP"}`).
     - `capstone-service-notificaciones`: Spring Boot en puerto `8082` (`{"status":"UP"}`).
     - `capstone-service-ia`: Spring Boot en puerto `8083` (`{"status":"UP"}`).
     - `capstone-keycloak`: Keycloak en puerto `8080` (HTTP 200, healthy).
     - `capstone-minio`: MinIO S3 en puertos `9000` y `9001` (HTTP 200, healthy).
     - `capstone-postgres`: PostgreSQL en puerto `5432` (healthy).
     - `capstone-rabbitmq`: RabbitMQ en puertos `5672` y `15672` (HTTP 200, healthy).

2. **Estructura de Directorios de Sistemas (`arch-001`)**:
   - Creado `frontend/` (SPA React + Vite):
     - Vistas de Acceso (`Login`, `Recuperar Contraseña`).
     - Vistas de Configuración (`Configurar Flujos`, `Organización y Usuarios`, `Configurar Planillas`).
     - Vistas de Documentos (`Nuevo Documento`, `Mis Documentos`, `Completar Planilla`).
     - Vistas de Flujos (`Revisar Documento`, `Corregir Documento`, `Estado Solicitudes`).
     - Clientes de integración: `keycloak.js` y `api.js` (con inyección automática de Bearer JWT).
     - `Dockerfile`, `package.json`, `vite.config.js`.
   - Creado `backend/sistema-principal/` (Spring Boot 3.2, Java 21):
     - Módulos RBAC: `auth` (OAuth2 Resource Server), `flow` (Motor de flujos y RabbitMQ), `doc` (Gestor documental y MinIO), `org` (Organización y usuarios).
     - `pom.xml`, `application.yml`, `Dockerfile`.
   - Creado `backend/service-notificaciones/` (Spring Boot 3.2, Java 21):
     - Consumidor RabbitMQ y cliente HTTP hacia MasterBase® API.
     - `pom.xml`, `application.yml`, `Dockerfile`.
   - Creado `backend/service-ia/` (Spring Boot 3.2, Java 21):
     - Consumidor RabbitMQ y cliente HTTP hacia Google Gemini API.
     - `pom.xml`, `application.yml`, `Dockerfile`.

3. **Documentación Estructural y Mapa de Navegación (`PROJECT_STRUCTURE.md` + `AGENTS.md`)**:
   - Creado [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) como catálogo integral de archivos, arquitectura de subsistemas, contratos de red, puertos, credenciales y flujos de datos.
   - Rediseñado [`AGENTS.md`](./AGENTS.md) para operar como un mapa de navegación y guía ágil para agentes autónomos.
   - **Pruebas en caliente registradas**:
     - Keycloak: Emisión exitosa de JWT para las cuentas del modelo actual de dos roles.
     - Spring Boot Security: HTTP 401 en `/api/org/config` sin token, HTTP 200 con Bearer JWT.
     - MinIO: Upload exitoso de archivos físicos a bucket `documentos` (`POST /api/doc/upload`) y descarga íntegra (`GET /api/doc/download/{fileKey}`).
     - RabbitMQ: Publicación exitosa desde `/api/flow/submit` hacia `capstone.exchange`.
   - **Hallazgos técnicos documentados para resolver**:
     - RabbitMQ: Configurar `@Bean MessageConverter` (`Jackson2JsonMessageConverter`) en los 3 servicios para evitar `SecurityException` por serialización Java nativa.
     - Seguridad RBAC: Implementar `JwtAuthenticationConverter` en `SecurityConfig` para extraer los roles del realm.

4. **Base de Conocimiento y Habilidades de Desarrollo Spring Boot (`.agents/skills/`)**:
   - Creada skill [`.agents/skills/spring-docs-research/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.agents/skills/spring-docs-research/SKILL.md):
     - Protocolo **Local-First**: el agente primero consulta el índice local [INDEX.md](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.agents/skills/spring-docs-research/references/INDEX.md); si la información no existe, busca en `docs.spring.io` vía `search_web` / `read_url_content`, sintetiza la solución y la persiste en Markdown local.
     - Referencias sembradas: OAuth2 Resource Server con Keycloak JWT, RabbitMQ con Jackson JSON, MinIO SDK 8.5+ y API fluida RestClient (Spring Boot 3.2+).
   - Creada skill [`.agents/skills/spring-boot-best-practices/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.agents/skills/spring-boot-best-practices/SKILL.md):
     - Resumen general y guía de estándares: arquitectura de capas, inyección por constructor (`@RequiredArgsConstructor`), DTOs con records de Java 21, manejo global de errores con `ProblemDetail` (RFC 7807), persistencia eficiente en JPA (prevención N+1, FetchType.LAZY), seguridad RBAC declarativa (`@PreAuthorize`) y checklist de calidad.
     - Referencias complementarias: estándares RESTful, reglas de rendimiento JPA y directrices RBAC.

5. **Integración de Web Scraper Crawl4AI como Servidor MCP (`mcp-001`)**:
   - Descargada e instalada la imagen oficial de `unclecode/crawl4ai:latest` en Docker Desktop, aislada completamente fuera del proyecto en `C:\Users\Eduardo K\.crawl4ai\`.
   - Generada imagen local `crawl4ai-mcp:latest` con endpoint MCP habilitado en puerto `11235` (`http://localhost:11235/mcp/sse`).
   - Configurado el servidor global en `C:\Users\Eduardo K\.gemini\config\mcp_config.json` con transporte SSE.
   - Generados los esquemas de herramientas (`md`, `html`, `screenshot`, `pdf`, `execute_js`, `crawl`, `ask`) en `C:\Users\Eduardo K\.gemini\antigravity\mcp\crawl4ai\`.
   - **Validación en vivo con Crawl4AI** sobre la documentación oficial de Spring (`docs.spring.io`):
     - **REST APIs & ProblemDetail RFC 7807**: Scrapeada y registrada en [`rest-apis-problemdetails.md`](.agents/skills/spring-docs-research/references/rest-apis-problemdetails.md).
     - **JWT & RBAC**: Scrapeada y registrada en [`security-oauth2-resource-server.md`](.agents/skills/spring-docs-research/references/security-oauth2-resource-server.md).
     - **RabbitMQ & Eventos**: Scrapeada y registrada en [`amqp-rabbitmq-json.md`](.agents/skills/spring-docs-research/references/amqp-rabbitmq-json.md).
     - **Realtime WebSockets (STOMP / SockJS)**: Scrapeada y registrada en [`websocket-stomp-realtime.md`](.agents/skills/spring-docs-research/references/websocket-stomp-realtime.md).
   - Actualizado el índice maestro [`.agents/skills/spring-docs-research/references/INDEX.md`](.agents/skills/spring-docs-research/references/INDEX.md) con todas las URLs oficiales verificadas.
   - Incorporada la sección de WebSockets y STOMP en la skill principal [`.agents/skills/spring-boot-best-practices/SKILL.md`](.agents/skills/spring-boot-best-practices/SKILL.md).
   - **Estrategia de Backup y Compatibilidad (Zero Dependencies)**: Formalizada la estrategia dual en la skill `spring-docs-research`. Si otros desarrolladores o agentes no tienen Crawl4AI instalado, el flujo degrada de forma transparente al backup nativo (`search_web` + `read_url_content`), asegurando que Crawl4AI sea una mejora opcional y nunca un bloqueo para el equipo.

6. **Guía de estilo del Frontend**:
   - Creado [`frontend/DESIGN_SYSTEM.md`](./frontend/DESIGN_SYSTEM.md) como fuente de verdad visual para Masterbase.
   - Integra la identidad del prototipo Figma (marca y navegación púrpura) con una dirección empresarial inspirada en Microsoft: superficies claras, jerarquía operacional, densidad moderada y accesibilidad WCAG AA.
   - Define tokens de color, tipografía, espaciado, responsive, patrones de sidebar, formularios, tablas, estados de flujo, modales y convenciones para React + CSS global sin dependencias nuevas.
   - **Verificación ejecutada**: `npm run build` en `frontend/` completó exitosamente con Vite 5.4.21.

7. **Autenticación Keycloak y RBAC (`auth-001`)**:
   - Configurado el realm para login por correo, recuperación de contraseña, correos únicos y orígenes/redirecciones locales explícitos.
   - Habilitada la detección de fuerza bruta de Keycloak: cuatro intentos fallidos producen bloqueo temporal de treinta minutos; no existe bloqueo permanente. Los intentos automatizados excesivamente rápidos mantienen además una defensa mínima de un minuto.
   - El modelo RBAC vigente usa solo `ADMIN` y `APPROVER` (Usuario operativo). `ADMIN` gestiona usuarios; `APPROVER` accede al resto de la plataforma.
   - El frontend inicializa Keycloak con `login-required` y Authorization Code + PKCE S256: al abrir la aplicación redirige directamente a Keycloak, renueva el JWT y permite cerrar sesión.
   - Agregado `KeycloakJwtAuthenticationConverter` para convertir `realm_access.roles` en `ROLE_ADMIN` y `ROLE_APPROVER`.
   - Aplicado RBAC declarativo: `/api/users` requiere `ADMIN`; envío, consulta de flujo y configuración general aceptan `ADMIN` o `APPROVER`.
   - Eliminado el formulario de acceso intermedio de React. Keycloak concentra el ingreso de correo y contraseña y, después de una autenticación exitosa, redirige a `/dashboard`.
   - **Verificación de fuerza bruta**: una cuenta temporal autenticó con HTTP 200; tras cuatro claves incorrectas separadas por dos segundos recibió bloqueo activo de 1.797 segundos (HTTP 401 incluso con clave correcta), y volvió a autenticar con HTTP 200 al limpiar los fallos. La cuenta temporal fue eliminada. `npm run build` del frontend pasó correctamente.
   - Agregada una extensión local de Keycloak que conserva el formulario estándar de usuario/contraseña, pero presenta el aviso de bloqueo temporal dentro de Keycloak. El flujo `browser-capstone-lock-message` se provisiona de forma idempotente mediante `keycloak-init`.
   - La autenticación del realm está forzada a español: “Accede a tu cuenta”, “Correo electrónico”, “Contraseña” e “Iniciar sesión”.
   - **Verificación UI del aviso**: una cuenta desechable recibió cuatro fallos separados por dos segundos; al enviar su contraseña correcta mientras permanecía bloqueada, el formulario de Keycloak mostró “Demasiados intentos de inicio de sesión. Espera unos minutos antes de volver a intentarlo.”
   - Keycloak usa la identidad Masterbase definida en `frontend/DESIGN_SYSTEM.md`: acceso centrado de una columna, logo autómata local, botones `#5B1A62`, tarjeta blanca, iconos funcionales, tipografía Segoe UI y controles accesibles de 44 px.
   - **Verificación del acceso directo**: abrir `http://localhost:3000/` redirigió inmediatamente al endpoint OIDC del realm en Keycloak con PKCE S256 y retorno configurado a `/dashboard`; no apareció una pantalla React intermedia. `npm run build` pasó correctamente.
   - Ajustado el tema de Keycloak para preservar los iconos de correo, contraseña y visibilidad en gris `#6B7280` aunque el navegador autocomplete campos. El mensaje de fallo de credenciales es: `credenciales invalidas, intentelo denuevo`.
   - Implementada la administración de usuarios para `ADMIN` en la vista “Organización y Usuarios”: formulario con correo, nombre, contraseña inicial, roles y cambio obligatorio de contraseña, más listado de cuentas registradas.
   - Refinada la vista administrativa para priorizar una tabla de usuarios a ancho completo. El formulario se abre desde “Agregar usuario” en un diálogo y permanece oculto durante la consulta normal.
   - Agregados `POST /api/users` y `GET /api/users`, ambos protegidos con `ROLE_ADMIN`. La creación usa Keycloak Admin Client para provisionar credenciales y roles, persiste el vínculo en PostgreSQL (`app_users` y `app_user_roles`) y elimina la cuenta de Keycloak como compensación si falla la operación.
   - Agregadas validaciones de entrada, detección de correos duplicados, respuestas `ProblemDetail` y pruebas unitarias del servicio de provisión.
   - Agregada sincronización inicial idempotente de las identidades que ya existen en Keycloak.
   - **Verificación integral de administración**: una cuenta temporal se creó con HTTP 201, apareció en `GET /api/users`, Keycloak y PostgreSQL conservaron el mismo identificador, inició sesión por correo con HTTP 200 y un usuario `APPROVER` recibió HTTP 403. La cuenta temporal fue eliminada de ambos sistemas. Los builds de backend/frontend pasaron y `/actuator/health` respondió `UP`.
   - Migrado el entorno local al modelo de dos roles: eliminado `USER` de Keycloak y de PostgreSQL; cuentas antes asociadas a ese rol pasaron a `APPROVER`, mientras `admin@capstone.local` conserva únicamente `ADMIN`. Verificación en vivo: el Usuario operativo obtuvo HTTP 200 en envío/consulta de flujo y configuración, y HTTP 403 en `/api/users`.
   - Implementado cierre de sesión seguro y auditado: React registra `POST /api/audit/logout` con el JWT vigente y luego ejecuta el logout OIDC de Keycloak con retorno a `/login`. El backend persiste eventos `LOGOUT` en la tabla `audit_events` de PostgreSQL.
   - **Verificación de cierre de sesión**: el endpoint autenticado devolvió HTTP 201 y dejó un registro `admin@capstone.local|LOGOUT`; sin JWT devolvió HTTP 401. El build Docker del backend ejecutó 8 pruebas sin fallos (incluye pruebas de servicio y HTTP del endpoint), el build de React pasó y `/actuator/health` respondió `UP` tras reiniciar los contenedores.

8. **Integración de Servidor MCP Google Workspace (`drive-mcp` - Drive, Docs & Sheets)**:
   - Configurado servicio `drive-mcp` en `docker-compose.yml` basado en `ghcr.io/taylorwilsdon/google_workspace_mcp:latest`.
   - Corregido el enlace de host del servidor mediante `WORKSPACE_MCP_HOST: "0.0.0.0"` y `WORKSPACE_MCP_PORT: "8000"`.
   - Habilitadas herramientas completas para Google Drive, Google Docs y Google Sheets (`TOOLS="docs drive sheets"`).
   - Autenticación mediante Google Cloud Service Account (`agentes@spherical-rune-508620-v1.iam.gserviceaccount.com`).
   - Verificado el handshake Streamable-HTTP (`/mcp`) y `/health` respondiendo `200 OK`.
   - Implementado y documentado el **Protocolo de Ediciones Seguras** (`docker/mcp-gws/README.md`) restringiendo a los agentes a anexo (`append`), comentarios de propuesta y lectura de confirmación obligatoria.
   - Prueba bidireccional en vivo completada con éxito en Google Drive: respuesta manual del desarrollador (`nice!`) leída y replicada por el agente en tiempo real.

9. **Gobernanza Documental y Protocolo Sprint Backlog Local (`docs/`)**:
   - Todo el ecosistema de artefactos en Google Drive fue migrado exitosamente por el equipo a formatos nativos de Google Workspace (Google Docs y Google Sheets).
   - Creado [`docs/GOBERNANZA_DOCUMENTAL.md`](./docs/GOBERNANZA_DOCUMENTAL.md) definiendo la matriz formal de roles, permisos y propósitos:
     - `registro daily meeting`: Solo lectura para agentes (bitácora humana de acuerdos).
     - `planificacion capstone`: Solo lectura para agentes (cronograma maestro de hitos).
     - `Definición Proyecto APT`: Solo lectura para agentes (contexto del proyecto y requerimientos).
     - `Plan de pruebas`: Documento vivo editable por agentes (**explica la estrategia global y enumera/ordena tests sin detallar**).
     - `Casos de prueba`: Documento vivo editable por agentes (**regla de oro: al menos 1 test por criterio de aceptación**).
     - `burndown chart`: Solo lectura para agentes (avance manual del equipo).
   - Creado [`docs/sprint-backlog/sprint-1.md`](./docs/sprint-backlog/sprint-1.md) como réplica local del Sprint Backlog para consumo offline de baja latencia por agentes.
   - **Prueba en caliente ejecutada con éxito**: Poblados los 5 casos de prueba de Sprint 1 (`CP-AUTH-01` a `CP-USER-02`) en Google Sheet `Casos de prueba` (pestaña `casos prueba sprint 1`), y verificada su persistencia en Drive mediante lectura de confirmación en tiempo real.

10. **Sincronización Sprint 1 Backlog (Trello MCP), Matriz E2E y Protocolo DoD**:
    - Conectado el servidor MCP oficial de Trello (`trello-official`) al tablero `sprint 1: sesiones + flujo base + notificaciones` (`6aa416e7f9aa35e0fd7d66c4`).
    - Extraídas las **12 historias de usuario** completas de la lista `sprint backlog` con sus checklists oficiales de criterios de aceptación.
    - Consolidado el backlog completo en local en [`docs/sprint-backlog/sprint-1.md`](./docs/sprint-backlog/sprint-1.md).
    - Actualizado [`feature_list.json`](./feature_list.json) alineando cada característica con su ID de tarjeta Trello, sus criterios de aceptación exactos y su estado actual (`passing`, `in_progress`, `not_started`).
    - Documentada la especificación completa de pruebas E2E en [`tests/e2e/SPRINT_1_E2E_SPECS.md`](./tests/e2e/SPRINT_1_E2E_SPECS.md), agrupando criterios en 8 suites integrales de usuario (`E2E-AUTH-01/02`, `E2E-USER-01`, `E2E-DOC-01`, `E2E-REV-01/02/03`, `E2E-CORR-01`, `E2E-HIST-01`, `E2E-NOTIF-01`).
    - **Actualizado el Protocolo de Desarrollo y Definition of Done** en [`AGENTS.md`](./AGENTS.md) y [`docs/GOBERNANZA_DOCUMENTAL.md`](./docs/GOBERNANZA_DOCUMENTAL.md):
      - Cada vez que se implemente una feature o historia de usuario, es obligatorio implementar sus tests E2E con Playwright.
      - **Criterio formal de aceptación (DoD)**: El desarrollador prueba visualmente la funcionalidad junto al agente (usando `.\scripts\run-e2e-tests.ps1 -UI` o con navegador en pantalla); si el desarrollador confirma el correcto funcionamiento visual en pantalla, la feature se da por terminada (`OK / passing`).

11. **Pruebas E2E de Cierre de Sesión y Protección de URLs del Sistema (Visuales y Automatizadas)**:
    - Agregado en `frontend/src/App.jsx` el enrutamiento explícito para `/logout` y comodín `*` hacia `/dashboard`, garantizando navegación limpia sin caídas ni pantallas vacías.
    - Reconstruido el contenedor `capstone-frontend` con la nueva configuración de rutas.
    - Implementados en [`tests/e2e/src/specs/auth/login-flow.spec.ts`](./tests/e2e/src/specs/auth/login-flow.spec.ts) dos nuevos casos de prueba clave:
      - **Test 4**: Iniciar sesión -> Cerrar sesión -> Intentar acceder directamente a URLs protegidas (`/dashboard`, `/configurar-org-usuarios`) y verificar que se bloquea y redirige obligatoriamente al login de Keycloak.
      - **Test 5**: Sin sesión iniciada, iterar sobre todas las URLs del sistema (`/dashboard`, `/configurar-flujos`, `/configurar-org-usuarios`, `/configurar-planillas`, `/nuevo-documento`, `/mis-documentos`, `/revisar-documento`, `/corregir-documento`, `/estado-solicitudes`, `/logout`, `/login`) comprobando redirección limpia al login de Keycloak sin arrojar errores de página ni excepciones de consola.
    - **Verificación en caliente ejecutada**: Los **5 tests de la suite pasaron exitosamente al 100%** (12.0s en Playwright).
    - Servidor visual Playwright UI Web activo en `http://localhost:9323` para inspección interactiva.

12. **Integración Completa del Modelo Relacional (`modelo.datos.sql`) y Auditoría de Login/Logout**:
    - Incorporado el modelo de datos relacional completo (19 tablas, catálogos, claves foráneas, índices y constraints) a partir del borrador [`backend/sistema-principal/modelo.datos.sql`](./backend/sistema-principal/modelo.datos.sql).
    - Creado [`backend/sistema-principal/src/main/resources/schema-postgresql.sql`](./backend/sistema-principal/src/main/resources/schema-postgresql.sql) en dialecto PostgreSQL y ejecutado exitosamente en `sistema_db`.
    - Creadas todas las entidades JPA correspondientes en `sistema-principal`:
      - Identidad y Organización: `Area`, `RolFlujo`, `UserAccount` (adaptada a tabla `usuario` y relación `usuario_rol`).
      - Auditoría: `TipoEvento`, `LogEvento` (tabla `log_evento`).
      - Motor de Flujos: `AccionUsuario`, `EstadoSolicitud`, `TipoNotificacion`, `FlujoDefinicion`, `FlujoEtapa`, `FlujoEtapaRoles`, `Transicion`, `Solicitud`, `SolicitudTransicion`, `Observacion`, `Notificacion`.
      - Documentos: `FormatoDocumento`, `Documento`.
    - Actualizado `UserManagementService` para resolver entidades `RolFlujo` y persistir en las nuevas tablas normalizadas.
    - Implementada la auditoría de inicio y cierre de sesión en `AuditService` y `AuditController` (`POST /api/audit/login` y `POST /api/audit/logout`), capturando IP del cliente, usuario autenticado, tipo de evento y detalle.
    - Integrado el registro de auditoría de inicio de sesión en el frontend (`frontend/src/services/keycloak.js` con `registerLoginAudit()`), registrando automáticamente el evento de login al inicializar la sesión OIDC.
    - Creados tests unitarios y de slice (`DataModelEntitiesTest`, `AuditServiceTest`, `AuditControllerTest`, `UserManagementServiceTest`) con 15 tests pasando en verde.
    - Actualizada y ejecutada la suite E2E de Playwright (`tests/e2e/src/specs/auth/login-flow.spec.ts`): los **5 tests pasaron al 100% en 11.9s**, verificando la inserción efectiva de registros `LOGIN` y `LOGOUT` en la tabla `log_evento`.

13. **Gestión Completa de Usuarios (`HU-03` / `auth-003`) y Suite E2E Playwright (`E2E-USER-01`)**:
    - Implementada la gestión de usuarios adaptada al alcance del Sprint 1 (sin roles en edición; todos los usuarios actúan como emisores y revisores en el flujo base):
      - Backend (`sistema-principal`):
        - Creados DTOs `UpdateUserRequest` (`firstName`, `lastName`) y `ToggleUserStatusRequest` (`enabled`).
        - Creada excepción `UserNotFoundException` mapeada a HTTP 404 en `UserExceptionHandler`.
        - En `UserManagementService`: implementados `updateUser(UUID, UpdateUserRequest)`, `toggleUserStatus(UUID, boolean)` y `deleteUser(UUID)`, con sincronización bidireccional inmediata en Keycloak Admin REST Client y PostgreSQL.
        - Inyectado `AuditService` para registrar en `log_evento` las acciones: `CREAR_USUARIO`, `ACTUALIZAR_USUARIO`, `DESACTIVAR_USUARIO`, `ACTIVAR_USUARIO`, `ELIMINAR_USUARIO`.
        - En `UserController`: expuestos endpoints `@PutMapping("/{id}")`, `@PatchMapping("/{id}/status")` y `@DeleteMapping("/{id}")`, protegidos con `@PreAuthorize("hasRole('ADMIN')")`.
        - Actualizado catálogo y secuencias de PostgreSQL (`tipo_evento` y `rol_flujo`) en `schema-postgresql.sql` y sincronizadas en la base de datos viva con `setval`.
        - Tests unitarios en `UserManagementServiceTest` ampliados a 5 tests, sumando un total de **18 tests de Spring Boot pasando al 100%** en Maven.
      - Frontend (`frontend/src/views/configuracion/ConfigurarOrgUsuariosView.jsx` y `App.css`):
        - Badges de estado simplificados a **Activo** e **Inactivo**.
        - Tabla con columna de Acciones: botón Editar (icono lápiz), botón Activar/Desactivar (icono power) y botón Eliminar (icono basurero).
        - Modal de edición para modificar nombre y apellido con bloqueo de correo electrónico.
        - Toggle de activación y desactivación lógica que bloquea el login en Keycloak (`enabled=false`) sin borrar el registro ni el historial en la base de datos.
        - Modal de confirmación para eliminación definitiva de cuenta.
      - Suite de Pruebas Automatizadas E2E Playwright (`tests/e2e/src/specs/auth/user-management.spec.ts` y Page Object `UsersPage.ts`):
        - **Test 1 [CA 3.1]**: Admin crea nuevo usuario -> Cierra sesión -> Nuevo usuario inicia sesión exitosamente en el sistema y accede al Dashboard.
        - **Test 2 [CA 3.2]**: Admin modifica nombre y apellido del usuario -> Cambios reflejados en la tabla y en la base de datos.
        - **Test 3 [CA 3.3]**: Admin desactiva usuario -> Usuario desactivado intenta iniciar sesión -> Keycloak bloquea el acceso con *"La cuenta está desactivada, contacta con el administrador"*, sin perder historial en base de datos.
        - **Test 4**: Admin reactiva al usuario -> Usuario reactivado vuelve a ingresar exitosamente al sistema.
        - **Test 5 [CA 3.4]**: Intento de registrar un usuario con correo ya existente es rechazado con mensaje de conflicto/duplicado impidiendo la duplicación.
        - **Test 6**: Admin elimina usuario -> Cuenta removida de la tabla y de Keycloak.
      - **Verificación en caliente ejecutada**:
        - Ejecución completa de regresión con `.\scripts\run-e2e-tests.ps1`: **11 tests pasando en verde (100%) en 42 segundos** (5 tests de autenticación + 6 tests de gestión de usuarios).
        - Verificación en PostgreSQL: Registros de auditoría corroborados en `log_evento` para todas las acciones (`CREAR_USUARIO`, `ACTUALIZAR_USUARIO`, `DESACTIVAR_USUARIO`, `ACTIVAR_USUARIO`, `ELIMINAR_USUARIO`).

14. **Refactorizaciones de Gestión de Usuarios y Retención de Video E2E**:
    - **Rol Operativo Renombrado**: En la UI (`ConfigurarOrgUsuariosView.jsx`), selector de roles y badges de la tabla, se cambió la etiqueta técnica de `"APPROVER"` por `"Emisor y Revisor"` para total coherencia con el modelo de negocio.
    - **Doble Campo de Contraseña en Alta de Usuarios**: En el modal "Crear usuario" se añadieron dos campos: *Contraseña inicial* y *Confirmar contraseña*, con validación estricta de igualdad en cliente antes de procesar el alta.
    - **Asignación de Nueva Contraseña en Edición**:
      - Backend: Extendido `UpdateUserRequest` con `newPassword` y `requirePasswordChange`. `UserManagementService` aplica el restablecimiento en Keycloak (`resetPassword`) con flag `temporary` si se marca solicitar cambio al iniciar sesión, registrando la auditoría en `log_evento`.
      - Frontend: En el modal "Editar usuario" se agregaron campos para nueva contraseña opcional, confirmación y checkbox de requerir cambio en próximo login.
    - **Retención Condicional de Videos Playwright**: Creado `VideoRetentionReporter.ts` y configurado `video: 'on'`. Si la suite completa pasa al 100%, se conservan todas las grabaciones `.webm` en `tests/e2e/test-results/`; si hay fallos, se descartan automáticamente.
    - **Verificación en Caliente**:
      - 22 tests unitarios Spring Boot pasando al 100% en Maven (incluyendo `registersUserManagementActionsInDatabase` y `returnsRecentAuditEventsForAdmin`).
      - 13 tests E2E Playwright pasando en verde (100% en 51.6s), incluyendo Test 8 que consulta el endpoint administrativo y verifica en vivo la persistencia efectiva de cada acción (`CREAR_USUARIO`, `ACTUALIZAR_USUARIO`, `DESACTIVAR_USUARIO`, `ACTIVAR_USUARIO`, `ELIMINAR_USUARIO`) en la tabla relacional `log_evento` de PostgreSQL.

15. **Sanitización Rigurosa de Contraseñas y Secretos en Logs y Auditoría (`CWE-532` / OWASP)**:
    - **Protección en DTOs (Java Records)**:
      - Sobrescrito método `toString()` en `CreateUserRequest` para enmascarar `password=[PROTECTED]`.
      - Sobrescrito método `toString()` en `UpdateUserRequest` para enmascarar `newPassword=[PROTECTED]`.
      - Previene filtraciones involuntarias de contraseñas si un middleware, framework de logging o manejador de excepciones imprime los DTOs.
    - **Filtro de Sanitización en Servicio de Auditoría (`AuditService`)**:
      - Implementado patrón regex `SENSITIVE_PATTERN` (`password|contrasena|contraseña|secret|token|credencial|bearer`) y método estático `sanitize(String input)` que reemplaza de forma determinística cualquier clave o valor sensible con `[PROTECTED]`.
      - Sanitización automática aplicada tanto en la persistencia en `log_evento.detalle` de PostgreSQL como en los registros emitidos a consola con SLF4J (`log.info`).
      - Validado en base de datos viva que no existen credenciales en texto plano (`detalle ILIKE '%pass%'` retorna 0 coincidencias).
    - **Verificación Automatizada**:
      - Test unitario `sanitizesRawPasswordsAndTokensInAuditDetails` en `AuditServiceTest`. Total de 23 tests de Spring Boot pasando al 100% (0 errores, 0 fallos).
      - Suite E2E completa en Playwright: 13 de 13 tests en verde (100%) con videos preservados.

16. **Registro del Correo Activo en Auditoría (`usuario_email`) y Mensaje Explícito de Bloqueo por Fuerza Bruta (CA 1.3)**:
    - **Auditoría con Identificación del Usuario Ejecutor**:
      - En base de datos (`schema-postgresql.sql` y `modelo.datos.sql`): agregada la columna `usuario_email VARCHAR(255)` e índice `idx_audit_usuario_email` en la tabla `log_evento`.
      - En PostgreSQL viva (`capstone-postgres`): ejecutado `ALTER TABLE` y backfill de los 275 registros históricos con queries SQL.
      - En backend Spring Boot (`LogEvento.java` y `AuditService.java`): extracción del email del actor autenticado desde `SecurityContextHolder` (`resolveCurrentActiveEmail`) asociándolo en `log_evento.usuario_email`, manteniendo `null` para eventos no autenticados. En `listRecentEvents`, se expone dicho correo como `email`.
      - Corroborado con queries SQL que todas las acciones administrativas (`CREAR_USUARIO`, `ACTUALIZAR_USUARIO`, etc.) quedan asociadas a `admin@capstone.local` y los inicios/cierres de sesión al usuario que opera.
    - **Resolución y Despliegue de Mensaje Explícito de Bloqueo en Keycloak**:
      - Corregido `configure-login-flow.sh` normalizando finales de línea a LF e integrando `capstone-username-password-form` dentro del subflujo `browser-capstone-lock-message forms` (prioridad 0, requerido) reemplazando al estándar `auth-username-password-form`.
      - `capstone-realm.json` actualizado con `"browserFlow": "browser-capstone-lock-message"`.
      - Textos de bloqueo en `messages_es.properties` y `messages_en.properties` actualizados con el tiempo explícito:
        `"Demasiados intentos de inicio de sesión fallidos. Tu cuenta ha sido bloqueada temporalmente durante 30 minutos."`
      - Servicio `capstone-keycloak-init` ejecutado con éxito (código 0) aplicando el nuevo flujo y tema en caliente.
    - **Suite de Pruebas E2E y Unitarias**:
      - Implementado nuevo **Test 6 [CA 1.3]** en `tests/e2e/src/specs/auth/login-flow.spec.ts`: crea usuario temporal vía Keycloak Admin API, ejecuta 4 intentos fallidos verificando "credenciales invalidas", comprueba que tras el 4to intento se muestra en pantalla el bloqueo explícito por 30 minutos (incluso con la contraseña correcta), y limpia el usuario de prueba.
      - Actualizado Test 8 en `user-management.spec.ts` para filtrar específicamente eventos de gestión de usuarios asegurando que el actor verificado sea el administrador.
      - **25 tests unitarios Spring Boot (100% pasando, BUILD SUCCESS)** en Maven.
      - **14 de 14 tests E2E Playwright pasando en verde (100%)** en `.\scripts\run-e2e-tests.ps1` con grabaciones de video retenidas.

17. **Implementación de Lógica Backend para Flujo de Solicitudes, Gestión Documental MinIO S3 y Notificaciones (Sprint 1)**:
    - **Catálogos y Semillas en PostgreSQL**:
      - Incorporados en `schema-postgresql.sql` y aplicados en la base de datos `sistema_db`:
        - Flujo base (`flujo_definicion` id=1: "Revisión Simple").
        - Etapa base (`flujo_etapa` id=1: "Revisión", orden=1).
        - 5 Reglas de la máquina de estados en `transicion` (CREAR -> PENDIENTE_REVISION; APROBAR -> APROBADO; RECHAZAR -> RECHAZADO; PEDIR_CORRECCION -> CORRECCION_REQUERIDA; REENVIAR -> PENDIENTE_REVISION).
        - 5 nuevos tipos de evento en `tipo_evento`: `CREAR_SOLICITUD` (8), `APROBAR_SOLICITUD` (9), `RECHAZAR_SOLICITUD` (10), `PEDIR_CORRECCION` (11), `REENVIAR_SOLICITUD` (12).
    - **Servicio de Flujos y Ciclo de Vida Documental (`SolicitudService`)**:
      - `crearSolicitud`: validación estricta de extensiones (.pdf, .docx, .doc), tamaño máximo de 10 MB, almacenamiento en MinIO S3, persistencia en `documento` (versión 1, vigente), creación de `solicitud` en `PENDIENTE_REVISION`, registro de transición `CREAR`, notificación a revisores y auditoría `CREAR_SOLICITUD`.
      - `aprobar`: validación de estado previo `PENDIENTE_REVISION`, validación de permisos (el emisor no puede auto-aprobar salvo que posea rol `ADMIN`, facilitando testing manual), transición a `APROBADO`, emisión de notificación al emisor y auditoría.
      - `rechazar`: validación de motivo obligatorio, transición a `RECHAZADO`, notificación con motivo y auditoría.
      - `pedirCorreccion`: validación de observación obligatoria, registro inmutable en `observacion`, transición a `CORRECCION_REQUERIDA`, notificación y auditoría.
      - `reenviar`: validación de solicitud observada, permiso exclusivo del emisor (o admin), soporte para nuevo archivo adjunto con incremento de versión (`version = previous + 1`) e invalidación de la anterior (`vigente = false`), resolución automática de observaciones previas, retorno a `PENDIENTE_REVISION` y notificación a revisores.
      - Consultas: `listarMisSolicitudes`, `listarRevisionesPendientes` (excluye las propias para usuarios regulares, incluye todas para administradores), `obtenerHistorial` (inmutable, orden cronológico), `obtenerObservaciones` y `descargarDocumento` (streaming desde MinIO).
    - **Servicio de Notificaciones In-App (`NotificacionService`)**:
      - Gestión directa en PostgreSQL con lectura, marcado individual (`marcarComoLeida`) con timestamp `leida_en`, y contador optimizado de no leídas (`contarNoLeidas`).
    - **Mapeo y Seguridad REST**:
      - `SolicitudController` (`/api/solicitudes`): 10 endpoints cubriendo el ciclo completo.
      - `NotificacionController` (`/api/notificaciones`): 3 endpoints para listado, contador y lectura.
      - `FlowExceptionHandler` (`@RestControllerAdvice`): mapeo uniforme a RFC 7807 (`ProblemDetail`) para 400 (formato/tamaño), 403 (acción no autorizada), 404 (no encontrado) y 409 (transición inválida).
    - **Batería de Pruebas Unitarias e Integración MockMvc**:
      - `SolicitudServiceTest`: 13 tests cubriendo aprobaciones, rechazos, correcciones, reenvíos con versionamiento, validaciones de permisos de emisor y privilegio de admin.
      - `NotificacionServiceTest`: 4 tests cubriendo emisión por tipo de evento y marcado de lectura.
      - `SolicitudControllerTest`: 12 tests MockMvc verificando contratos REST, ProblemDetail y seguridad.
      - `NotificacionControllerTest`: 4 tests MockMvc.
      - Total suite Maven en Docker: **58 tests pasando al 100% (0 errores, 0 fallos, BUILD SUCCESS)**.
    - **Verificación en Vivo y Regresión E2E**:
      - Reconstruido y reiniciado el contenedor `capstone-sistema-principal` con Tomcat 8081 saludable (`/actuator/health` UP).
      - Verificación funcional viva de punta a punta: creación de solicitudes, auto-aprobación admin, ciclo de corrección con versionado v1->v2, rechazo fundamentado, descarga de binario desde MinIO y comprobación de eventos en `log_evento`.
      - Suite de regresión Playwright: **14 de 14 tests E2E pasando en verde (100%)** con videos retenidos.


13. **Validación de identidad local para JWT (`auth-001`)**:
    - `KeycloakJwtAuthenticationConverter` ahora consulta `usuario.keycloak_id` con el claim `sub` antes de crear la autenticación Spring; la cuenta debe existir y estar activa (`activo = true`).
    - Un JWT con firma válida, pero de una cuenta ausente o desactivada en PostgreSQL, lanza `InvalidBearerTokenException` y el Resource Server responde HTTP 401.
    - Agregadas pruebas unitarias para cuenta activa, ausente e inactiva. Los contextos MVC que importan `SecurityConfig` ahora proveen un mock del convertidor.
    - **Verificación ejecutada**: reconstrucción Docker de `sistema-principal` exitosa con **60 pruebas** (0 fallos, 0 errores); `/actuator/health` respondió `UP`. Una cuenta temporal obtuvo HTTP 200 en `/api/solicitudes/mis-solicitudes` mientras existía en PostgreSQL; después de eliminar únicamente sus relaciones/registro local, usando exactamente el mismo JWT, obtuvo HTTP 401. La identidad temporal se eliminó también de Keycloak.
    - La cobertura E2E y la validación visual de este cambio quedan pendientes; `auth-001` conserva el estado `in_progress` según la Definition of Done.

18. **Pantalla de Registro de Documento sin Planilla (`doc-001`, frontend)**:
    - Reemplazada la carga aislada a `/api/doc/upload` por el formulario real de solicitud en `NuevoDocumentoView`: título obligatorio, descripción opcional y envío `multipart/form-data` a `POST /api/solicitudes`.
    - Implementada área accesible de arrastre y soltado, selector de archivos, vista del archivo elegido y opción para quitarlo.
    - La validación cliente y backend permite `.doc`, `.docx`, `.pdf`, `.xml` y `.txt`, y bloquea archivos fuera de esa lista o mayores a 10 MB; también informa la ausencia de título o archivo antes de enviar.
    - `Axios onUploadProgress` alimenta una barra de progreso durante la subida. Los errores de red/API se presentan de forma persistente y el resultado `201` muestra confirmación visual.
    - Ampliados los formatos aceptados a `.xml` y `.txt` en React y `SolicitudService`; la prueba unitaria `testCrearSolicitud_AcceptsXmlAndTxtFormats` cubre ambas extensiones.
    - **Verificación ejecutada**: `npm run build` de Vite correcto; imagen Docker de `frontend` reconstruida y `http://localhost:3000` respondió HTTP 200. La reconstrucción Docker del backend ejecutó **61 pruebas Maven sin fallos** (incluidas XML y TXT) y `/actuator/health` respondió `UP`.
    - La cobertura `E2E-DOC-01` y la validación visual autenticada quedan pendientes. Por Definition of Done, `doc-001` se mantiene `in_progress`; las vistas de solicitudes cubrirán CA 4.3 y CA 4.4.

19. **Corrección de catálogos faltantes al registrar solicitudes**:
    - Diagnóstico en PostgreSQL y logs del backend: `flujo_definicion` y sus catálogos relacionados estaban vacíos, provocando HTTP 500 con `No existe definición de flujo configurada` al enviar un documento válido.
    - Incorporado `DefaultFlowCatalogInitializer`, ejecutado transaccionalmente al iniciar el backend. Crea únicamente los estados, acciones, formatos y transiciones ausentes del flujo base “Revisión Simple”, sin duplicar los existentes.
    - La semilla SQL incluye también los formatos `xml` y `txt`, de modo que tanto una base nueva como una existente sin semillas quedan preparadas para registrar solicitudes.

20. **Soporte para Hojas de Cálculo (.xlsx, .xls) y Descarga Intermediada Segura con JWT**:
    - **Soporte de Formatos Excel**:
      - `SolicitudService` amplió `ALLOWED_EXTENSIONS` incluyendo `xlsx` y `xls`.
      - Agregados formatos a las semillas SQL de `formato_documento` (IDs 6 y 7).
      - Actualizado `SolicitudServiceTest` cubriendo subidas de `.xlsx` y `.xls`.
    - **Descarga Intermediada y Bloqueo de Acceso Directo a S3**:
      - Reconfigurado MinIO (`create-buckets.sh`) aplicando política `mc anonymous set none` sobre el bucket `documentos` para impedir descargas directas públicas o anónimas hacia el almacenamiento S3.
      - Endpoints de descarga (`/api/solicitudes/{id}/documento/descargar` y `/api/doc/download/{filename}`) asegurados con `@PreAuthorize("isAuthenticated()")` y Bearer JWT obligatorio. El backend actúa como intermediario seguro transmitiendo el binario en streaming.
      - Añadida suite unitaria `DocControllerTest` con Spring Security (`WebMvcTest`), verificando rechazo 401 sin credenciales, descarga intermediada 200 con encabezado `attachment` y carga autenticada de archivo Excel.
      - Documentación de contratos REST sincronizada en `docs/API_CONTRACTS.md`.
    - **Verificación en Vivo y Suite Maven**:
      - Total de pruebas unitarias Spring Boot: **65 tests pasando al 100% (0 fallos, 0 errores, BUILD SUCCESS)**.
      - Acceso anónimo directo a MinIO `http://localhost:9000/documentos/...` &rarr; Verificado `HTTP 403 Forbidden` (`AccessDenied`).
      - Acceso no autenticado a `/api/doc/download/...` &rarr; Verificado `HTTP 401 Unauthorized`.
      - Flujo funcional autenticado de extremo a extremo: registro exitoso de solicitud con archivo `.xlsx` (`HTTP 200`), y descarga intermediada a través de `/api/solicitudes/{id}/documento/descargar` con Bearer JWT (`HTTP 200` y `Content-Disposition: attachment; filename="test_upload.xlsx"`).

21. **Microservicio de Notificaciones por Correo con Resend y RabbitMQ**:
    - **Control Selectivo de Envío (Checkbox notificarEmail)**:
      - Para evitar saturación de correos a los usuarios, se incorporó el parámetro `notificarEmail` (booleano, por defecto `false`) en todas las acciones documentales (`crear`, `aprobar`, `rechazar`, `pedirCorreccion`, `reenviar`) a través de `AccionRequest` y request params.
      - La persistencia in-app en PostgreSQL **siempre se almacena**.
      - El evento a RabbitMQ hacia `capstone.exchange` (`notifications.email`) **solo se emite si `notificarEmail == true`**.
    - **Microservicio `service-notificaciones` Refactorizado con Resend**:
      - Eliminado el cliente placeholder `MasterBaseClient` y el controlador obsoleto `FlowController` en el backend principal.
      - Implementado `ResendEmailClient` con `RestClient` nativo de Spring Boot 3.2, headers requeridos (`Authorization`, `User-Agent`, `Idempotency-Key`).
      - Soporte de **modo simulación con temporizador**: mediante `RESEND_SIMULATION_ENABLED=true` (o detección automática si la key es dummy), el microservicio simula el tiempo de respuesta HTTP y emite logs informativos claros sin fallar la cola de RabbitMQ.
      - Implementado `EmailTemplateService` que renderiza HTML responsivo estilizado y versión en texto plano para los eventos (`NUEVA_SOLICITUD`, `APROBACION`, `RECHAZO`, `CORRECCION_REQUERIDA`, `REENVIO`).
      - Implementado `RabbitConfig` con `Jackson2JsonMessageConverter` en ambos servicios para serialización y deserialización automática transparente.
    - **Batería de Pruebas Unitarias y Verificación en Vivo**:
      - `sistema-principal`: **67 tests pasando al 100% (0 errores, 0 fallos)**, incluyendo verificación de llamadas a `RabbitTemplate` condicionales según `notificarEmail`.
      - `service-notificaciones`: **5 tests unitarios pasando al 100%**, cubriendo `ResendEmailClientTest`, `EmailTemplateServiceTest` y `NotificationQueueListenerTest`.
      - **Prueba Funcional en Vivo en Docker**:
        - Acción con `notificarEmail=false`: registrada en base de datos sin emitir a RabbitMQ.
        - Acción con `notificarEmail=true`: mensaje encolado en RabbitMQ, consumido por `service-notificaciones`, plantilla renderizada y correo simulado con éxito (`[SIMULACIÓN] Correo simulado exitosamente hacia: test@test.com - Asunto: 'Nueva solicitud pendiente de revisión' - ID: sim_...`).
      - Actualizados `.env`, `.env.example`, `docker-compose.yml`, `docs/API_CONTRACTS.md` y `PROJECT_STRUCTURE.md`.

22. **Microservicio de Auditoría Documental y Consultas IA (OpenRouter LLM + RabbitMQ + MinIO)**:
    - **Arquitectura Worker Asíncrono con Reply Queue y Claim Check Pattern**:
      - `service-ia` opera como worker sin estado (0 bases de datos relacionales locales, 0 endpoints REST).
      - RabbitMQ transporta solo metadatos y punteros de archivo (`storageKey`, `nombreArchivo`, `contentType`, `titulo`, `descripcion`, `prompt`), manteniendo el broker ultraligero y evitando saturación.
      - `service-ia` descarga el archivo directamente desde MinIO S3 (`http://minio:9000`) y extrae texto plano con **Apache Tika 2.9**, soportando de forma universal `.pdf`, `.docx`, `.doc`, `.xlsx`, `.xls`, `.xml` y `.txt`.
      - Extractor con truncado configurable mediante `AI_MAX_DOCUMENT_CHARS` (por defecto 15.000 caracteres / ~3.800 tokens) para garantizar compatibilidad con la ventana de contexto de los modelos LLM.
    - **Integración con OpenRouter API**:
      - Modelo primario: `meta-llama/llama-3.3-70b-instruct:free` con cadena de fallback: `deepseek/deepseek-chat:free`, `qwen/qwen-2.5-72b-instruct:free`, `openrouter/free`.
      - Modo simulación con temporizador emulado (`OPENROUTER_SIMULATION_ENABLED=true` o detección de API keys dummy) que responde con JSON estructurado analítico sin gastar cuota de OpenRouter en dev/test.
      - Prompt dinámico: la petición desde el frontend puede enviar instrucciones o reglas de negocio específicas a evaluar contra el documento.
    - **Persistencia, API y Caché Inteligente en `sistema-principal`**:
      - Entidad JPA `AiAnalysis` en PostgreSQL asociada a la `Solicitud` y al `Documento`.
      - Endpoints REST: `POST /api/solicitudes/{id}/ai-analysis` y `GET /api/solicitudes/{id}/ai-analysis`.
      - **Caché Inteligente e Idempotencia**: Si el documento vigente y el prompt solicitado no han cambiado y ya existe un análisis `COMPLETADO`, retorna de inmediato `HTTP 200 OK` con `cached: true` sin consultar a la IA ni encolar a RabbitMQ. Parámetro `force=true` disponible para forzar re-análisis (`HTTP 202 Accepted`, `cached: false`).
    - **Batería de Pruebas y Verificación en Vivo**:
      - `service-ia`: **6/6 tests unitarios pasando al 100%** (`DocumentTextExtractorTest`, `OpenRouterApiClientTest`, `AiTaskListenerTest`).
      - `sistema-principal`: **79/79 tests unitarios y MVC pasando al 100%** (`AiAnalysisServiceTest`, `AiAnalysisControllerTest`, `AiResultListenerTest`, `SolicitudControllerTest`, `SolicitudServiceTest`, etc.).
      - **Verificación en Vivo con Docker**: Solicitud creada con archivo adjunto -> evento `ai.analysis` emitido a RabbitMQ -> `service-ia` descarga de MinIO S3 con `storageKey` -> extracción con Apache Tika -> análisis simulado -> publicación a `ai.results` -> persistencia en PostgreSQL (`AiAnalysis`) -> consulta GET con HTTP 200 -> segundo POST con mismo prompt devuelve `cached: true` instantáneo -> POST con `force=true` re-analiza con éxito.
      - Actualizados `.env`, `.env.example`, `docker-compose.yml`, `PROJECT_STRUCTURE.md`, `feature_list.json` (`ia-001` en `passing`) y `docs/API_CONTRACTS.md`.
23. **Verificación en Vivo de Conexión Real con OpenRouter API**:
    - **Configuración y Descubrimiento de Modelos**:
      - Clave de API real de OpenRouter configurada en `.env` y sincronizada con el contenedor `capstone-service-ia`.
      - Modo simulación deshabilitado (`OPENROUTER_SIMULATION_ENABLED=false`).
      - Actualizado modelo primario a `openrouter/free` (con fallbacks activos: `qwen/qwen3.8-27b:free` y `deepseek/deepseek-v4-flash-0731:free`).
      - Ajustado el arreglo `models` a un máximo de 3 elementos según la especificación estricta de la API de OpenRouter.
    - **Verificación Funcional en Vivo**:
      - **Prueba 1 (Detección de incongruencias)**: Contrato con datos incompletos en el monto de renta y garantía. El LLM (`deepseek/deepseek-v4-flash-0731:free` ruteado por OpenRouter) identificó con precisión que las cifras numéricas de renta y garantía estaban incompletas, asignó puntaje de 60/100 (`valido: false`) y entregó recomendaciones puntuales de subsanación.
      - **Prueba 2 (Aprobación completa)**: Contrato con vigencia (24 meses), renta ($650.000) y garantía ($1.300.000) detallados. El LLM evaluó el documento, otorgó puntaje de 100/100 (`valido: true`) y confirmó el cumplimiento exacto de las reglas de negocio.
      - Tiempo promedio de respuesta en vivo: 5.4 segundos.

24. **Implementación del Flujo Completo de Solicitud Simple en Frontend y Suite E2E**:
    - **Registro de Documentos (`NuevoDocumentoView.jsx`)**:
      - Soporte universal para archivos `.doc`, `.docx`, `.pdf`, `.xml`, `.txt`, `.xlsx` y `.xls`.
      - Mensajes de confirmación claros con enlaces de navegación directa hacia "Estado Solicitudes" y "Mis Documentos".
    - **Revisión y Aprobación (`RevisarDocumentoView.jsx`)**:
      - Lista de revisiones pendientes (`GET /api/solicitudes/pendientes-revision`) con vista en dos paneles interactiva.
      - Descarga intermediada segura del documento vigente mediante streaming con JWT (`GET /api/solicitudes/{id}/documento/descargar`).
      - Modales de confirmación con validaciones:
        - **Aprobar**: Modal de confirmación que transiciona a `APROBADO`.
        - **Rechazar**: Modal con campo de motivo obligatorio que transiciona a `RECHAZADO`.
        - **Pedir Corrección (Rechazo Parcial)**: Modal con observaciones obligatorias para mejora documental que transiciona a `CORRECCION_REQUERIDA`.
    - **Subsanación y Reenvío (`CorregirDocumentoView.jsx`)**:
      - Detección y listado de solicitudes observadas (`CORRECCION_REQUERIDA`).
      - Visualización destacada de las observaciones del revisor (`GET /api/solicitudes/{id}/observaciones`).
      - Formulario para editar título/descripción y opcionalmente adjuntar un archivo sustituto.
      - Reenvío exitoso (`PUT /api/solicitudes/{id}/reenviar`) retornando la solicitud al estado `PENDIENTE_REVISION`.
    - **Trazabilidad e Historial (`EstadoSolicitudesView.jsx` & `MisDocumentosView.jsx`)**:
      - Visualización completa de solicitudes con badges de estado consistentes.
      - Línea de tiempo cronológica inmutable (`GET /api/solicitudes/{id}/historial`) mostrando qué ocurrió, quién lo realizó y cuándo.
      - Acceso directo a descarga intermediada y enlace a subsanación si la solicitud fue observada.
    - **Inbox de Notificaciones en la Topbar (`NotificationBell.jsx`)**:
      - Campana en la barra superior con contador de no leídas (`GET /api/notificaciones/no-leidas/count`).
      - Dropdown interactivo con lista de alertas in-app (`GET /api/notificaciones`).
      - Soporte para marcar como leídas individualmente (`PATCH /api/notificaciones/{id}/leer`) y de forma masiva (`PATCH /api/notificaciones/marcar-todas-leidas`), implementado tanto en backend Spring Boot como en frontend React.
    - **Verificación Automatizada E2E con Playwright**:
      - Nueva suite `tests/e2e/src/specs/flow/simple-request-flow.spec.ts` con **7 pruebas de extremo a extremo pasando al 100% en verde (45.9s, 0 fallos, 0 errores)**:
        1. Emisión / Registro con archivo adjunto (`HU-04`).
        2. Revisión con Solicitud de Corrección / Rechazo Parcial y descarga intermediada (`HU-05`, `HU-08`).
        3. Visualización de observaciones y subsanación con reenvío (`HU-09`, `HU-10`).
        4. Aprobación final de solicitud subsanada (`HU-06`).
        5. Rechazo con motivo obligatorio (`HU-07`).
        6. Inbox de notificaciones in-app y lectura (`HU-12`).
        7. Trazabilidad e historial cronológico inmutable (`HU-11`).
      - Regresión de autenticación y sesiones (`login-flow.spec.ts`): **6/6 tests pasando al 100%**.

25. **Dashboard Operativo de Solicitudes y Acciones Pendientes (Cockpit de Tareas)**:
    - **Backend Agregado (`sistema-principal`)**:
      - Nuevo endpoint REST `GET /api/solicitudes/dashboard` documentado con OpenAPI y protegido por OAuth2 / JWT.
      - DTOs inmutables con records de Java 21: `DashboardResponse` y `AccionPendienteResponse`.
      - Lógica de agregación y segregación en `SolicitudService.obtenerResumenDashboard()`:
        - Revisor/Admin: identifica revisiones pendientes requeridas (`PENDIENTE_REVISION`).
        - Emisor: identifica solicitudes propias observadas que requieren subsanación (`CORRECCION_REQUERIDA`), extrayendo el contenido de la última observación activa.
        - Ordenamiento cronológico de acciones pendientes por fecha descendente.
        - Listado de solicitudes emitidas por el usuario que se encuentran en trámite (`misSolicitudesPendientes`).
    - **Frontend React SPA (`frontend/src/views/dashboard/DashboardView.jsx`)**:
      - Vista operativa diseñada según [DESIGN_SYSTEM.md](./frontend/DESIGN_SYSTEM.md): tarjeta hero con saludo al usuario, rol RBAC visible (`Administrador` o `Usuario Operativo`), botón "Nueva Solicitud" y botón "Actualizar" con animación de giro para refresco en caliente.
      - Pestañas con contadores numéricos: **"Acciones Pendientes"** y **"Mis Solicitudes en Trámite"**.
      - Tabla de tareas con tags semánticos: "Revisión Requerida" (azul con icono `FileCheck2`) y "Subsanación Requerida" (ámbar con icono `FileEdit`).
      - Visualización de autor, archivo físico adjunto (con versión), fecha y extracto destacado de la observación del revisor.
      - **Navegación Profunda (Deep-Linking)**:
        - Botón "Revisar": navega a `/revisar-documento?id={id}` preseleccionando automáticamente el documento para revisión.
        - Botón "Subsanar": navega a `/corregir-documento?id={id}` preseleccionando el formulario de corrección.
        - Botón "Ver Estado": navega a `/estado-solicitudes?id={id}` para trazabilidad.
      - Incorporado enlace a "Dashboard" en la barra lateral (`sidebar`) de `App.jsx`.
      - Empty state amigable con icono verde `CheckCircle2` cuando el usuario está al día ("¡Estás al día!").
    - **Verificación Automatizada**:
      - Backend: **82/82 tests pasando al 100%** (incluyendo `SolicitudControllerTest` y `SolicitudServiceTest`).
      - E2E Playwright: Nueva suite `dashboard-flow.spec.ts` con **4/4 tests pasando en verde (13.3s)**.
      - Regresión E2E: `simple-request-flow.spec.ts` (7/7 tests pasando) y `login-flow.spec.ts` (6/6 tests pasando). Total: **17/17 tests E2E pasando**.
      - Actualizados `docs/API_CONTRACTS.md`, `PROJECT_STRUCTURE.md` y `claude-progress.md`.

26. **Bandeja paginada de solicitudes para revisión (Sprint 1)**:
    - **Backend (`sistema-principal`)**:
      - `GET /api/solicitudes/pendientes-revision` ahora admite filtros combinables por nombre de archivo, emisor, rango de creación y estado, además de paginación (`pagina`, `tamanio`).
      - Consulta implementada mediante `Specification`, `Pageable` y `EntityGraph` para cargar emisor/estado sin consultas repetidas; los documentos vigentes se resuelven por lote para la proyección reducida de la tabla.
      - Se mantuvieron intactas las transiciones existentes de aprobar, rechazar, pedir corrección y reenviar.
    - **Frontend (`RevisarDocumentoView.jsx`)**:
      - Tabla responsive con filtros reactivos de 350 ms, contador, navegación por páginas y badges de estado.
      - Panel lateral de detalle con datos de la solicitud, descarga segura y previsualización para PDF, TXT y XML.
      - Las acciones existentes se conservan dentro del panel y refrescan la bandeja al completarse.
    - **Verificación automatizada**:
      - Backend: **83/83 pruebas pasando** en la compilación del contenedor.
      - Frontend: `npm run build` completado correctamente.
      - Suite E2E integrada `simple-request-flow.spec.ts`: **7/7 pruebas pasando** (22.3 s), incluyendo filtros dinámicos y paginación, descarga, corrección, reenvío, aprobación, rechazo, notificaciones e historial.
      - Queda pendiente exclusivamente la validación visual conjunta con el desarrollador antes de registrar la aprobación manual de la historia.

27. **Cierre técnico de rechazo, reenvío y subsanación (Sprint 1)**:
    - **Rechazo con motivo obligatorio**:
      - Alineado al criterio de flujo simplificado sin asignación de roles: cualquier usuario autenticado puede rechazar una solicitud pendiente, incluso si es el emisor.
      - El motivo continúa siendo obligatorio y normalizado; se conservan la transición a `RECHAZADO`, el historial, la auditoría y la notificación interna.
      - La acción de rechazo del frontend ahora solicita la notificación por correo, publicando el evento RabbitMQ para el emisor.
    - **Reenvío transaccional y versionado documental**:
      - `PUT /api/solicitudes/{id}/reenviar` acepta únicamente solicitudes en `CORRECCION_REQUERIDA` y del emisor original (o administrador).
      - Se valida que un título enviado no esté vacío; el archivo nuevo se carga antes de desactivar la versión vigente y se registra una compensación que lo elimina de MinIO si la transacción de base de datos revierte.
      - Se comprobó en PostgreSQL que el documento anterior queda `vigente = false`, la nueva versión queda `vigente = true` y las observaciones pasan a resueltas.
    - **Formulario de subsanación**:
      - Mantiene precargados título y descripción, permite limpiar la descripción y reemplazar opcionalmente el archivo.
      - Prioriza las observaciones activas, informa de forma explícita enlaces a solicitudes no corregibles y mejora la activación por teclado del selector de archivo.
    - **Verificación ejecutada**:
      - Build de `sistema-principal`: **83/83 pruebas pasando**; build de frontend completado correctamente.
      - `simple-request-flow.spec.ts`: **7/7 pruebas pasando**; caso aislado de rechazo: **1/1 pasando**.
      - RabbitMQ entregó el evento `RECHAZO` al microservicio de notificaciones y la simulación de correo terminó correctamente.
      - Las tres tarjetas permanecen en progreso hasta completar la revisión visual.

28. **Modal centrado para detalle y revisión documental**:
    - Reemplazado el panel lateral de `RevisarDocumentoView.jsx` por una ventana modal centrada de hasta 1080 px, con adaptación a pantalla completa en dispositivos móviles.
    - El encabezado y las acciones de revisión permanecen visibles, mientras el detalle y la previsualización se desplazan dentro del modal sin mover la página de fondo.
    - La previsualización de PDF/TXT/XML usa todo el ancho disponible, solicita ajuste a ancho de página y puede ocultarse sin cerrar el detalle.
    - Añadidos bloqueo del desplazamiento del fondo, cierre con `Escape`, ciclo de foco dentro del diálogo y devolución del foco al control de origen.
    - Se confirmó mediante búsqueda que no existen otros paneles laterales de revisión con el patrón `review-drawer`; los diálogos administrativos y de confirmación existentes ya se muestran centrados.
    - **Verificación ejecutada**: `npm run build` completado correctamente y la imagen Docker del frontend se reconstruyó y levantó. La revisión visual autenticada quedó pendiente porque la sesión del navegador expiró al reiniciar el frontend.

29. **Cierre de interfaz para aprobación, observaciones y notificaciones (Sprint 1)**:
    - **Aprobación**: confirmación visual con resumen del documento y transición de estado, foco y cierre por teclado, bloqueo de envíos duplicados, actualización inmediata de la fila y aviso de resultado. La bandeja se sincroniza después con el servidor.
    - **Observaciones**: componente `ObservationTimeline.jsx` compartido por subsanación y estado de solicitudes. Ordena las indicaciones cronológicamente e identifica autor, fecha, contenido y si ya fueron subsanadas. `GET /api/solicitudes/{id}/observaciones` exige que el usuario sea emisor o administrador y devuelve `403` al resto.
    - **Notificaciones**: campana y panel más legibles con categorías, estados de lectura, filtros, fechas y acciones. Las notificaciones de nueva solicitud/reenvío enlazan a revisión; las de corrección, a subsanación; las de aprobación/rechazo, al estado de la solicitud.

30. **Biblioteca visual compartida y aplicación gradual (22-09-2026)**:
    - Se creó `frontend/src/components/ui/index.jsx` con botones/enlaces, campos, indicadores de estado, mensajes, estados vacíos, tablas y tarjetas reutilizables. Sus variantes reutilizan la paleta y las clases corporativas existentes.
    - Se adoptaron en Dashboard, Mis Documentos, Nuevo Documento, Revisar Documento, Corregir Documento, Estado de Solicitudes y Organización/Usuarios. La navegación ahora muestra la sección activa y ofrece menú lateral adaptable a móvil con control de foco.
    - Se documentó el uso en `frontend/DESIGN_SYSTEM.md` y la ubicación en `PROJECT_STRUCTURE.md`. No se regeneraron mocks ni datos: los datos iniciales existentes quedaron intactos, según el alcance acordado.
    - **Verificación ejecutada**: `npm run build` y `docker compose build frontend` completaron correctamente; el contenedor frontend se recreó y `http://localhost:3000/` respondió HTTP 200. `git diff --check` sin errores de whitespace. La validación automatizada quedó pendiente.

31. **Rediseño visual de la aplicación autenticada (23-09-2026)**:
    - Alcance: shell (sidebar y topbar), Dashboard, Nuevo documento, Mis documentos, Revisar documento, Corregir documento, Estado de solicitudes, Organización y usuarios y centro de notificaciones. No se tocaron el acceso de Keycloak ni las vistas aún no implementadas (Configurar flujos, Configurar planillas, Completar planilla), que en el menú muestran la etiqueta “Pronto”.
    - **Shell**: sidebar con el logotipo MasterBase del acceso (`public/masterbase-wordmark.png`), grupos reordenados por frecuencia de uso (Principal, Documentos, Flujos de aprobación, Configuración), estado activo con barra lateral y tarjeta de usuario al pie (avatar con iniciales, nombre, rol y botón de cerrar sesión). La topbar muestra la ruta actual (sección › página) y las notificaciones. Favicon y título de pestaña con la marca.
    - **Componentes nuevos** en `components/ui/index.jsx`: `PageHeader`, `UserAvatar` (retirado en el hito 34), `FileTypeIcon` y utilidades `formatDateTime`, `formatFileSize`, `getStatusLabel`. `App.css` se reescribió por secciones, eliminando reglas duplicadas y estilos sin uso; tokens nuevos de borde, sombra y radio (tarjetas de 12 px, igual que el acceso).
    - **Vistas**: Dashboard con cuatro indicadores (revisiones, correcciones, en trámite y resueltas; esta última usa `GET /api/solicitudes/mis-solicitudes`) y pestañas dentro de una tarjeta; Nuevo documento con panel “¿Cómo funciona?” y contador de caracteres; Mis documentos con búsqueda y filtros por estado en el cliente; Estado y Corregir con patrón lista/detalle y teclado en las filas; historial con iconos por acción, más reciente primero y código de auditoría visible; Usuarios con resumen de cuentas, búsqueda y avatares.
    - **Estados**: `Pendiente de revisión` pasó a azul (información) y `Corrección requerida` a ámbar, según la correspondencia de `DESIGN_SYSTEM.md`; `Inactivo` pasó a neutro.
    - **Tests E2E**: se actualizó la marca esperada en `login-flow.spec.ts` (`Sistema Capstone` → `MasterBase`). Se restauraron ganchos que ya faltaban desde el hito 30 (`.btn-new-request`, `.btn-refresh`, `.btn-review`, `.btn-correct`, `.btn-track` y `.detail-card-body` en el modal de revisión). Pendiente conocido previo al rediseño: algunos tests esperan `Pendiente de Revisión` con mayúscula, mientras la interfaz muestra `Pendiente de revisión`.
    - **Verificación ejecutada**: `npm run build` correcto. Se agregó `.claude/launch.json` para levantar Vite en `localhost:5173` (origen ya permitido por Keycloak y CORS). No se ejecutó la suite E2E ni se reconstruyó el contenedor `capstone-frontend`; la revisión visual autenticada quedó pendiente.

32. **Correcciones de acceso y adaptación a móviles (23-09-2026)**:
    - **Acceso (Keycloak, `capstone-login.css`)**: la contraseña autocompletada recibía `padding-left: 44px` además del espacio del candado y se alejaba del icono; ahora cada campo tiene su propio relleno al autocompletarse. El icono del correo se posicionaba desde el borde inferior del grupo y bajaba al aparecer “credenciales invalidas”; ahora comparte la celda de cuadrícula del campo y se mantiene centrado. En pantallas bajas la tarjeta crece con su contenido y la página se desplaza (antes el contenido se superponía); en teléfonos horizontales (alto ≤ 520 px) se usa el diseño apilado y se oculta la ilustración. Versión del CSS: `v=20260923-10`.
    - **Aplicación**: las tablas del Dashboard, Mis documentos y Usuarios se muestran como tarjetas con etiqueta por campo (reemplazado en el hito 33 por `table-stackable`); los filtros de Revisar documento se pliegan tras un botón “Filtros” con contador; las pestañas del Dashboard se reparten el ancho; los botones del encabezado ocupan el ancho disponible; en Estado y Corregir, al tocar una fila en pantallas angostas se desplaza hasta el detalle.
    - **Verificación ejecutada**: login revisado en 375×812, 812×375 y 1100×620 con el estado de error simulado (icono centrado, sin superposiciones medidas por posición de elementos). `npm run build` correcto. Los cambios del tema se copiaron en caliente al contenedor `capstone-keycloak`; para conservarlos al recrearlo hay que reconstruir la imagen (`docker compose up -d --build keycloak`). Falta la revisión visual autenticada de la aplicación en móvil.

33. **Responsividad en anchos intermedios (24-09-2026)**:
    - La revisión en tablet/ventana angosta identificó columnas de tablas comprimidas letra por letra, calendario de filtros fuera de pantalla y franja vacía bajo la aplicación en Corregir documento.
    - **Causas y correcciones**: (1) `overflow-wrap: anywhere` reducía el ancho mínimo de las columnas: ahora los bloques con icono tienen `min-width: 10rem` y las tablas pasan a tarjetas según el ancho real del contenedor mediante *container queries* (`.table-stackable`, umbrales 960 px y 520 px), aplicado a Dashboard, Mis documentos, Revisar documento y Usuarios. La tabla de acciones del Dashboard pasó de 6 a 5 columnas (el detalle quedó bajo la etiqueta de acción) y las fechas se muestran en dos líneas (`DateTimeStack`). (2) El calendario mide el espacio al abrirse y se alinea a la derecha si no cabe (`review-calendar--end`); los filtros usan `auto-fit`. (3) Los elementos `.visually-hidden` absolutos no tenían contenedor posicionado y alargaban el documento: `.app-container` y `.content-body` son `position: relative` y `body` no se desplaza. También se quitó una barra de desplazamiento de 1 px en las pestañas del Dashboard y las etiquetas de filtro de Mis documentos se ajustan en varias filas en móvil.
    - **Verificación ejecutada**: página de prueba temporal (Keycloak y API simulados con nombres largos reales) en 375×812, 820×1180, 1024×768, 1300, 1310, 1366 y 1440 px de ancho: sin desbordamiento horizontal en ninguna vista, documento siempre igual al alto de la ventana, tablas en modo tabla sin barra horizontal desde ~965 px de contenedor y en tarjetas por debajo. La página de prueba se eliminó. `npm run build` correcto.

34. **Detalle en modal para vistas lista/detalle y retiro de avatares (24-09-2026)**:
    - Bajo 1120 px, Estado de solicitudes y Corregir documento muestran solo la lista (título, fecha y estado apilados, con flecha) y abren el detalle en `DetailModal` al tocar una fila: centrado en tablet y como hoja inferior en teléfono, con encabezado fijo, cuerpo desplazable y, en Corregir, el botón de reenvío fijo al pie. Los enlaces con `?id=` abren el modal directamente; tras reenviar con éxito el modal se cierra y el aviso queda en la página. En escritorio se conservan ambos paneles y los selectores E2E siguen en `.detail-card`.
    - Se eliminaron los avatares de iniciales (sidebar, Dashboard, Revisar documento y Usuarios) junto con el componente `UserAvatar`, `getInitials` y sus estilos; los datos de persona usan `.cell-person` para mantener el ancho mínimo de columna.
    - Se reemplazó `scrollIntoView` por el modal y se separó en líneas distintas la fecha y la etiqueta “Corrección solicitada” de las observaciones.
    - **Verificación ejecutada** con página de prueba temporal (eliminada): 375×812 (lista y hoja inferior; pie fijo al borde), 700×460 (clic real abre el modal), 820×1180 (modal centrado de 760 px) y 1440×900 (dos paneles, sin modal). Teclado: Enter abre, el foco entra al diálogo, Escape cierra y el foco vuelve a la fila. `npm run build` correcto.

35. **Lista con desplazamiento propio en escritorio (24-09-2026)**: sobre 1120 px, la lista de Estado de solicitudes y Corregir documento queda fija (sticky) junto al detalle, con alto limitado a la ventana, desplazamiento propio y cabecera de columnas fija. El historial muestra “Inicio” cuando el backend envía el origen `INICIAL`. Verificado con página de prueba temporal (19 solicitudes, 1440×800): la lista ocupa 72–752 px, se desplaza sola y la cabecera se mantiene. Build correcto.

36. **Auditoría de Actas de Reunión contra Backlog de Trello y Alineación de Sprints (28-09-2026)**:
    - Se ejecutó diagnóstico y verificación en vivo de MCPs de integración:
      - **Trello (`trello-official`)**: Conexión verificada con la cuenta de Eduardo Kusar, workspace `proyecto capstone` y tableros `Product Backlog`, `sprint 1` y `sprint 2`.
      - **Google Drive (`workspace-docs`)**: Se inició el contenedor `capstone-drive-mcp` (puerto 8000, `HTTP 200 OK`) y se ajustó la configuración a `127.0.0.1`. Se validó lectura de archivos, planillas y documentos Google Workspace.
      - **Stack Docker Base**: Todo el stack levantado y saludable (frontend en 3000, sistema-principal en 8081, notificaciones en 8082, IA en 8083, Keycloak en 8080 con realm importado y flujo de bloqueo configurado, PostgreSQL en 5432, RabbitMQ en 5672/15672, MinIO en 9000/9001).
    - Se leyeron y analizaron las minutas de reunión con la clienta Karin Pohl (Masterbase):
      - *Acta de Reunión N° 1* (16-09-2026, Semana 6, Sprint 1): acuerdos sobre identificador único (RUT), permisos por área y jerarquía estricta, y recomendación de reducir alcance.
      - *Acta de Reunión N° 2* (21-09-2026, Semana 7, Sprint 2): reemplazo de "qué ocurrió" por "estado", orden de fechas explícito, notificaciones diferenciadas por perfil y con correlativo, selector inicial de tipo de documento, control de versiones (v2) y matriz de plazos SLA con alertas.
    - Se actualizaron las descripciones y criterios de aceptación en Trello tanto en el Product Backlog como en el Sprint 2:
      - `Consultar historial de flujos` (Product Backlog): Criterios de estado y orden cronológico explícito, con sección `Por implementar:` completa (marcada como implementada en Sprint 1).
      - `Revisar notificaciones en bandeja de entrada` (Product Backlog): Criterios de estado, correlativo y mensajes diferenciados por perfil con su sección `Por implementar:`.
      - `Ver revisiones pendiente (Revisor)` (Product Backlog): Grilla con tipo de documento y acciones condicionadas a perfil/rol.
      - `Registrar documento sin planilla (Emisor)` (Product Backlog): Primer campo obligatorio tipo de documento (desplegable), estado inicial "Pendiente de revisión" y correlativo único.
      - `Corregir documento (Emisor)` (Product Backlog): Versionado documental (v2) al reenviar tras observaciones.
      - `Gestionar roles y permisos` (Product Backlog y Sprint 2): Aislamiento departamental y jerarquía vertical según organigrama.
      - `Consultar documentos` (Product Backlog y Sprint 2): Filtros por departamento, tipo de documento y respeto a jerarquía.
      - `Consultar estado de mis solicitudes` (Product Backlog y Sprint 2): Correlativo y seguimiento inmutable.
      - `Asignar un RUT al crear usuario` (Product Backlog y Sprint 2): Formato `NN.NNN.NNN-N`, validación de DV y unicidad con sección `Por implementar:`.
      - Creada nueva tarjeta `Configurar plazos de aprobación y alertas por tipo de documento` en el Product Backlog y en el Sprint Backlog del Sprint 2 para cubrir la brecha de matriz de plazos y SLA.
      - Agregada la sección `Por implementar:` a todas las 14 tarjetas del Sprint Backlog del Sprint 2 para control ágil.
    - Creado documento de referencia [`docs/sprint-backlog/sprint-2.md`](docs/sprint-backlog/sprint-2.md) reflejando el estado alineado del Sprint 2.

37. **Trazabilidad Total con Etiquetas y Marca `[AGENTE]` en Trello para Revisión Manual (28-09-2026)**:
    - Se completó la trazabilidad sistemática en todas las tarjetas modificadas y creadas:
      - **Marca textual**: Cada tarjeta intervenida cuenta con el encabezado de nota explicativa `> **[AGENTE]**: ...`, criterios nuevos señalizados con el prefijo `[AGENTE]` y sección de control de criterios `### [AGENTE] Por implementar:`.
      - **Etiqueta dedicada**: Se aplicó la etiqueta morada (`purple`) a las 10 tarjetas modificadas/creadas del Product Backlog y a las 14 tarjetas del Sprint 2 (`Sprint Backlog`), permitiendo filtrar inmediatamente en Trello por color morado para revisión manual.
      - **Comentarios de auditoría**: Se publicó un comentario formal `[AGENTE] ...` en la actividad de cada tarjeta detallando la naturaleza de la modificación para trazabilidad histórica inmutable.

38. **Sincronización Sprint 1 de Trello, Reseteo Seguro de BD y Suite E2E al 100% (28-09-2026)**:
    - **Sincronización Trello <-> Local**: Se leyeron vía MCP de Trello las 12 historias de usuario del Sprint Backlog (`HU-01` a `HU-12`) con todos sus criterios de aceptación y checklists, actualizando y sincronizando localmente [`docs/sprint-backlog/sprint-1.md`](docs/sprint-backlog/sprint-1.md) (HU-03 completada al 100% y HU-09 con sus 4 CAs oficiales).
    - **Scripts de Reseteo Seguro y Determinista**: Se crearon [`scripts/clean-test-db.ps1`](scripts/clean-test-db.ps1) y [`scripts/clean-test-db.sh`](scripts/clean-test-db.sh) para garantizar un estado limpio antes de correr pruebas. El script:
      - Limpia tablas transaccionales de PostgreSQL (`observacion`, `documento`, `notificacion`, `solicitud_transicion`, `solicitud`, `audit_events`, `log_evento`).
      - Restablece las cuentas base en Keycloak (`admin@capstone.local` con rol ADMIN y `revisor@capstone.local` con rol APPROVER) y las sincroniza en `app_users`/`app_user_roles`.
      - Limpia bloqueos de brute-force en Keycloak.
      - Vacía el bucket S3 `documentos` en MinIO.
      - Purga las colas residuales en RabbitMQ.
      - Se integró el flag `-Clean` / `--clean` a los ejecutores [`scripts/run-e2e-tests.ps1`](scripts/run-e2e-tests.ps1) y [`scripts/run-e2e-tests.sh`](scripts/run-e2e-tests.sh).
    - **Alineación y Cierre de Brechas E2E (Playwright)**:
      - Implementado Test 9 en `tests/e2e/src/specs/auth/user-management.spec.ts` para validar `CA 3.5` (rol `APPROVER` sin acceso a UI de gestión de usuarios, redirección al dashboard y rechazo en API con 401/403).
      - Ajustadas aserciones insensibles a mayúsculas/minúsculas para el badge `"Pendiente de revisión"` en `dashboard-flow.spec.ts` y `simple-request-flow.spec.ts`.
      - Corregido el matcher del toast de éxito al solicitar corrección en `simple-request-flow.spec.ts`.
      - Corregidas validaciones de códigos de seguridad (401/403) en `user-management.spec.ts` y `ver-observaciones-revisor.spec.ts`.
    - **Verificación Completa en Caliente**:
      - Ejecución exitosa de la suite completa: **33 de 33 tests PASSING (100% verde)** en 4.1 minutos vía contenedor Docker de Playwright (`.\scripts\run-e2e-tests.ps1 -Clean`).
      - Retención de videos habilitada en `tests/e2e/test-results/`.
      - Documento de especificaciones [`tests/e2e/SPRINT_1_E2E_SPECS.md`](tests/e2e/SPRINT_1_E2E_SPECS.md) actualizado reflejando la matriz completa de 33 tests aprobados.

