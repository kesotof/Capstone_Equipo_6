# Product Backlog Oficial — Sistema de Gestión Documental y Flujos de Aprobación

> **Catálogo Maestro de Historias de Usuario, Criterios de Aceptación y Matriz de Trazabilidad**  
> **Proyecto**: Capstone — Duoc UC / Masterbase  
> **Fuente de Verdad**: Tableros Oficiales de Trello sincronizados en tiempo real vía Trello MCP  
> **Fecha de Extracción y Consolidación**: 10 de octubre de 2026  
> **Estado General del Backlog**: 36 Historias de Usuario activas (12 en Sprint 1, 14 en Sprint 2, 10 en Backlog Futuro)  

---

## 1. Resumen Ejecutivo y Estadísticas del Backlog

El presente documento consolida el **Product Backlog completo** del Sistema de Gestión Documental y Flujos de Aprobación, extraído directamente desde los tableros oficiales de Trello (`Product Backlog`, `Sprint 1: Sesiones, Flujo Base y Notificaciones`, y `Sprint 2: Flujos configurables y motor RBAC`).

Este catálogo proporciona **trazabilidad integral de extremo a extremo (E2E)**, ordenando cada historia de usuario con un **ID Único secuencial (`US-01` a `US-36`)**, su código ágil de sprint (`HU-XX` / `HU-S2-XX` / `HU-PB-XX`), su épica temática en Trello, su estado actual y sus criterios de aceptación formales.

### 1.1. Distribución por Sprint

| Sprint / Alcance | Cantidad de Historias | Rango de IDs | Estado Ágil Principal | Enfoque de Entrega |
| :--- | :---: | :---: | :--- | :--- |
| **Sprint 1** | 12 | `US-01` a `US-12` | **Terminado / Passing** | Autenticación base, gestión de usuarios, flujo simple de aprobación y notificaciones in-app. |
| **Sprint 2** | 14 | `US-13` a `US-26` | **En Desarrollo / Validado** | Estructura organizacional, RUT chileno, flujos configurables por área, motor RBAC jerárquico y SLA. |
| **Product Backlog Futuro** | 10 | `US-27` a `US-36` | **Priorizado (Sprint 3+)** | Plantillas dinámicas, correlativos, versionado documental v2, IA generativa y notificaciones externas. |
| **TOTAL GENERAL** | **36** | **`US-01` a `US-36`** | **100% Trazable** | **Cobertura completa de la plataforma** |

### 1.2. Distribución por Lista Temática (Épicas de Trello)

| # | Épica / Lista Temática en Trello | Cantidad de Historias | Historias Asociadas |
| :-: | :--- | :---: | :--- |
| 1 | **Autenticacion y sesiones** | 4 | `US-01` (Login), `US-02` (Logout), `US-25` (Cambio Clave), `US-27` (Recuperar Clave) |
| 2 | **Flujos: operacion** | 12 | `US-04`, `US-05`, `US-06`, `US-07`, `US-08`, `US-09`, `US-10`, `US-21`, `US-28`, `US-29`, `US-30`, `US-31` |
| 3 | **Flujos: configuracion** | 9 | `US-03`, `US-13`, `US-14`, `US-15`, `US-16`, `US-17`, `US-18`, `US-19`, `US-20` |
| 4 | **Plantillas** | 3 | `US-32` (Crear Plantilla), `US-33` (Gestionar Plantillas), `US-34` (Tipos Documento / Correlativos) |
| 5 | **Inventario de Documentos** | 4 | `US-11` (Historial), `US-22` (Consulta), `US-23` (Mis Solicitudes), `US-24` (Descarga) |
| 6 | **Notificaciones** | 3 | `US-12` (Bandeja In-App), `US-35` (Correo Externo), `US-36` (Diferenciadas por Rol) |
| 7 | **Dashboards** | 1 | `US-26` (Resumen General Cuantitativo) |
| | **TOTAL** | **36** | |

---

## 2. Matriz Maestra de Trazabilidad del Product Backlog

A continuación se presenta la tabla resumen de trazabilidad global ordenada por el **ID Único (`US-01` a `US-36`)**:

| ID Único | Código Ágil | Título de la Historia de Usuario | Épica / Lista Trello | Sprint | CAs | Estado Ágil | Enlace Trello |
| :---: | :---: | :--- | :--- | :---: | :---: | :--- | :---: |
| **US-01** | `HU-01` | **Iniciar Sesion** | Autenticacion y sesiones | Sprint 1 | 4 | Terminado / Passing | [Trello](https://trello.com/c/lxjJ3aYt/1-iniciar-sesion) |
| **US-02** | `HU-02` | **Cerrar Sesion** | Autenticacion y sesiones | Sprint 1 | 4 | Terminado / Passing | [Trello](https://trello.com/c/jr7VKayi/2-cerrar-sesion) |
| **US-03** | `HU-03` | **Gestionar usuarios** | Flujos: configuracion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/bSF2qXvx/5-gestionar-usuarios) |
| **US-04** | `HU-04` | **Registrar documento sin planilla (Emisor)** | Flujos: operacion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/jBvVQU8O/19-registrar-documento-sin-planilla-emisor) |
| **US-05** | `HU-05` | **Ver revisiones pendiente  (Revisor)** | Flujos: operacion | Sprint 1 | 6 | Terminado / Passing | [Trello](https://trello.com/c/CbiHVWdA/22-ver-revisiones-pendiente-revisor) |
| **US-06** | `HU-06` | **Aprobar documento (Revisor)** | Flujos: operacion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/YK0QuRx4/24-aprobar-documento-revisor) |
| **US-07** | `HU-07` | **Rechazar documento (Revisor)** | Flujos: operacion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/UAYbIEtw/25-rechazar-documento-revisor) |
| **US-08** | `HU-08` | **Solicitar correccion a documento (Revisor)** | Flujos: operacion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/843Tld7G/26-solicitar-correccion-a-documento-revisor) |
| **US-09** | `HU-09` | **Ver observaciones del revisor (emisor)** | Flujos: operacion | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/bOj3c5Gh/37-ver-observaciones-del-revisor-emisor) |
| **US-10** | `HU-10` | **Corregir documento (Emisor)** | Flujos: operacion | Sprint 1 | 6 | Terminado / Passing | [Trello](https://trello.com/c/gHB5HuZm/27-corregir-documento-emisor) |
| **US-11** | `HU-11` | **Consultar historial de flujos** | Inventario de Documentos | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/5O1z9spx/15-consultar-historial-de-flujos) |
| **US-12** | `HU-12` | **Revisar notificaciones en bandeja de entrada** | Notificaciones | Sprint 1 | 5 | Terminado / Passing | [Trello](https://trello.com/c/PaBe3moE/21-revisar-notificaciones-en-bandeja-de-entrada) |
| **US-13** | `HU-S2-01` | **Asignar un RUT al crear usuario** | Flujos: configuracion | Sprint 2 | 10 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/I7vtlb7l/42-asignar-un-rut-al-crear-usuario) |
| **US-14** | `HU-S2-02` | **Gestionar areas corporativas** | Flujos: configuracion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/KykMRs6o/4-gestionar-areas-corporativas) |
| **US-15** | `HU-S2-03` | **Asignar administrador de área** | Flujos: configuracion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/NaRiukPf/29-asignar-administrador-de-%C3%A1rea) |
| **US-16** | `HU-S2-04` | **Vincular usuarios con sus áreas** | Flujos: configuracion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/CenMoJjL/6-vincular-usuarios-con-sus-%C3%A1reas) |
| **US-17** | `HU-S2-05` | **Gestionar flujos** | Flujos: configuracion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/ideLp09f/30-gestionar-flujos) |
| **US-18** | `HU-S2-06` | **Configurar responsables de revisión** | Flujos: configuracion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/9Em3ir60/39-configurar-responsables-de-revisi%C3%B3n) |
| **US-19** | `HU-S2-07` | **Gestionar roles y permisos** | Flujos: configuracion | Sprint 2 | 7 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/jNbcabRl/38-gestionar-roles-y-permisos) |
| **US-20** | `HU-S2-08` | **Configurar plazos de aprobación y alertas por tipo de documento** | Flujos: configuracion | Sprint 2 | 5 | Terminado / Passing | [Trello](https://trello.com/c/NORGmvuT/43-configurar-plazos-de-aprobaci%C3%B3n-y-alertas-por-tipo-de-documento) |
| **US-21** | `HU-S2-09` | **Ver detalle de una solicitud (Emisor/Revisor)** | Flujos: operacion | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/ApzaiAfx/36-ver-detalle-de-una-solicitud-emisor-revisor) |
| **US-22** | `HU-S2-10` | **Consultar documentos** | Inventario de Documentos | Sprint 2 | 6 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/7J6MKccA/13-consultar-documentos) |
| **US-23** | `HU-S2-11` | **Consultar estado de mis solicitudes** | Inventario de Documentos | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/YGejrHU6/40-consultar-estado-de-mis-solicitudes) |
| **US-24** | `HU-S2-12` | **Descargar documentos** | Inventario de Documentos | Sprint 2 | 4 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/KUsk0128/14-descargar-documentos) |
| **US-25** | `HU-S2-13` | **Cambiar Contraseña** | Autenticacion y sesiones | Sprint 2 | 6 | Verificado / Passing | [Trello](https://trello.com/c/MLbAxxNR/3-cambiar-contrase%C3%B1a) |
| **US-26** | `HU-S2-14` | **Ver resumen general de solicitudes** | Dashboards | Sprint 2 | 5 | En Desarrollo / Por Validar | [Trello](https://trello.com/c/lY5wpFsR/35-ver-resumen-general-de-solicitudes) |
| **US-27** | `HU-PB-01` | **Recuperar Contraseña** | Autenticacion y sesiones | Product Backlog (Futuro) | 11 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/473u017N/47-recuperar-contrase%C3%B1a) |
| **US-28** | `HU-PB-02` | **Registrar documento usando planilla (Emisor)** | Flujos: operacion | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/cIbTJfP8/20-registrar-documento-usando-planilla-emisor) |
| **US-29** | `HU-PB-03` | **Autocompletar documento usando IA (Emisor)** | Flujos: operacion | Product Backlog (Futuro) | 6 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/rirUoorE/32-autocompletar-documento-usando-ia-emisor) |
| **US-30** | `HU-PB-04` | **Evaluación de la IA de la solicitud  (Revisor)** | Flujos: operacion | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/scyD5quq/23-evaluaci%C3%B3n-de-la-ia-de-la-solicitud-revisor) |
| **US-31** | `HU-PB-05` | **Control de versiones de documentos** | Flujos: operacion | Product Backlog (Futuro) | 4 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/6oiaegRL/45-control-de-versiones-de-documentos) |
| **US-32** | `HU-PB-06` | **Crear plantilla dinámica** | Plantillas | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/LW7VDU6T/16-crear-plantilla-din%C3%A1mica) |
| **US-33** | `HU-PB-07` | **Gestionar plantillas** | Plantillas | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/nFxBs7xR/17-gestionar-plantillas) |
| **US-34** | `HU-PB-08` | **Definir tipos de documento y correlativos** | Plantillas | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/mdj2b3ig/44-definir-tipos-de-documento-y-correlativos) |
| **US-35** | `HU-PB-09` | **Recibir notificaciones por correo** | Notificaciones | Product Backlog (Futuro) | 5 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/3uqQoVP5/28-recibir-notificaciones-por-correo) |
| **US-36** | `HU-PB-10` | **Notificaciones diferenciadas por rol y evento** | Notificaciones | Product Backlog (Futuro) | 4 | Priorizado para Sprint 3 | [Trello](https://trello.com/c/kKXMXyMi/46-notificaciones-diferenciadas-por-rol-y-evento) |

---

## 3. Historias de Usuario — Sprint 1: Sesiones, Flujo Base y Notificaciones

### [US-01] Iniciar Sesion (`HU-01`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-01`** |
| **Código Ágil / Historia** | `HU-01` (Feature: `auth-001`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Autenticacion y sesiones` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-AUTH-01 (login-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/lxjJ3aYt/1-iniciar-sesion) (ID: `6a9deba9a378941eecb28b5c`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Iniciar sesion para tener acceso seguro al sistema
- **Para:** Tener acceso seguro al sistema

#### Criterios de Aceptación Oficiales (4 CAs)
- [x] **CA 01.1**: nombre de usuario solo en formato correos
- [x] **CA 01.2**: si credenciales son invalidas, mostrar un mensaje: “credenciales invalidas, intentelo denuevo“
- [x] **CA 01.3**: si fallo el inicio 4 veces seguidas, se bloquea el nombre de usuario por 30 minutos.
- [x] **CA 01.4**: al ingresar correctamente, el usuario debe acceder a la plataforma

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Acceso mediante credenciales válidas en Keycloak OIDC, validación de formato de correo, bloqueo temporal tras 4 intentos fallidos y registro de auditoría.

---

### [US-02] Cerrar Sesion (`HU-02`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-02`** |
| **Código Ágil / Historia** | `HU-02` (Feature: `auth-002`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Autenticacion y sesiones` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-AUTH-02 (login-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/jr7VKayi/2-cerrar-sesion) (ID: `6a9debc566d5f6571b4c2741`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Cerrar sesión para finalizar mi acceso de forma segura y evitar que otras personas puedan acceder a mi cuenta
- **Para:** Finalizar mi acceso de forma segura y evitar que otras personas puedan acceder a mi cuenta

#### Criterios de Aceptación Oficiales (4 CAs)
- [x] **CA 02.1**: Al seleccionar **“Cerrar Sesion”**, el sistema debe finalizar la sesión activa.
- [x] **CA 02.2**: El usuario debe ser redirigido a la pantalla de **inicio de sesión**.
- [x] **CA 02.3**: Una vez cerrada la sesión, no se debe permitir acceder nuevamente a las funcionalidades del sistema sin iniciar sesión.
- [x] **CA 02.4**: El sistema debe registrar el **cierre de sesión** en el historial de actividades.

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Cierre de sesión seguro invalidando token OIDC, redirección a pantalla de login, bloqueo de rutas protegidas y evento LOGOUT registrado.

---

### [US-03] Gestionar usuarios (`HU-03`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-03`** |
| **Código Ágil / Historia** | `HU-03` (Feature: `auth-003`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-USER-01 (user-management.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/bSF2qXvx/5-gestionar-usuarios) (ID: `6a9deca1eb3653dcac925799`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Gestionar los usuarios de la plataforma
- **Para:** Controlar quién puede ingresar y utilizar el sistema

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 03.1**: se debe poder agregar un usuario usando un correo válido
- [x] **CA 03.2**: se debe poder cambiar la información permitida de un usuario
- [x] **CA 03.3**: se debe poder desactivar un usuario sin borrar su historial
- [x] **CA 03.4**: no se deben permitir dos usuarios con el mismo correo
- [x] **CA 03.5**: solo los administradores deben poder gestionar usuarios

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Administración de usuarios por rol ADMIN: creación con correo único, edición de nombres, desactivación lógica sin pérdida de historial y logs.

---

### [US-04] Registrar documento sin planilla (Emisor) (`HU-04`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-04`** |
| **Código Ágil / Historia** | `HU-04` (Feature: `doc-001`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-DOC-01 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/jBvVQU8O/19-registrar-documento-sin-planilla-emisor) (ID: `6a9df0671462a4ecc87bc162`) |

#### Narrativa Ágil
- **Como:** Emisor
- **Quiero:** Registrar un documento sin usar una planilla
- **Para:** Enviarlo a revisión y comenzar su proceso de aprobación

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 04.1**: se deben poder adjuntar documentos en formato .doc, .docx y .pdf
- [x] **CA 04.2**: antes de enviar, los campos obligatorios deben estar completos
- [x] **CA 04.3**: después de registrarlo, el documento debe aparecer entre las solicitudes del emisor
- [x] **CA 04.4**: el emisor debe poder ver el estado actual del documento
- [x] **CA 04.5**: al registrarlo correctamente, se debe mostrar una confirmación

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Emisión de solicitudes con adjunto (.doc, .docx, .pdf, .xml, .txt) almacenado en MinIO S3, estado inicial pendiente de revisión y confirmación visual.

---

### [US-05] Ver revisiones pendiente  (Revisor) (`HU-05`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-05`** |
| **Código Ágil / Historia** | `HU-05` (Feature: `flow-001`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-REV-01 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/CbiHVWdA/22-ver-revisiones-pendiente-revisor) (ID: `6a9df0d532b4e4bee8804e1c`) |

#### Narrativa Ágil
- **Como:** Revisor del sistema
- **Quiero:** Ver las revisiones pendientes asignadas
- **Para:** Identificar y revisar oportunamente los documentos que requieren mi aprobación

#### Criterios de Aceptación Oficiales (6 CAs)
- [x] **CA 05.1**: el revisor debe poder visualizar una lista de documentos pendientes de revisión
- [x] **CA 05.2**: cada documento en la lista debe mostrar información relevante: nombre, emisor, fecha y estado
- [x] **CA 05.3**: el revisor debe poder seleccionar un documento para revisar su contenido y antecedentes
- [x] **CA 05.4**: solo deben mostrarse como pendientes los documentos que requieren una revisión humana
- [x] **CA 05.5**: el sistema debe permitir aprobar, rechazar o solicitar correcciones
- [x] **CA 05.6**: una vez realizada la revisión, el documento debe actualizar su estado y dejar registro inmutable en el historial

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Bandeja de entrada para rol revisor con lista de solicitudes pendientes, datos de emisor y fecha, y modal con acciones rápidas de decisión.

---

### [US-06] Aprobar documento (Revisor) (`HU-06`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-06`** |
| **Código Ágil / Historia** | `HU-06` (Feature: `flow-002`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-REV-02 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/YK0QuRx4/24-aprobar-documento-revisor) (ID: `6a9df1015de720c7598bb382`) |

#### Narrativa Ágil
- **Como:** Revisor
- **Quiero:** Aprobar un documento que ya revisé
- **Para:** Permitir que continúe a la siguiente etapa o finalice su proceso

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 06.1**: solo el revisor asignado debe poder aprobar la solicitud
- [x] **CA 06.2**: antes de aprobar, se debe pedir una confirmación
- [x] **CA 06.3**: al aprobar, la solicitud debe avanzar al siguiente estado correspondiente
- [x] **CA 06.4**: la aprobación debe quedar registrada con la fecha y el usuario que la realizó
- [x] **CA 06.5**: el emisor debe recibir una notificación del cambio

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Transición a estado APROBADO con confirmación en pantalla, registro de usuario y fecha en historial y emisión de notificación a involucrados.

---

### [US-07] Rechazar documento (Revisor) (`HU-07`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-07`** |
| **Código Ágil / Historia** | `HU-07` (Feature: `flow-003`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-REV-03 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/UAYbIEtw/25-rechazar-documento-revisor) (ID: `6a9df105ad7611b3ee8b6076`) |

#### Narrativa Ágil
- **Como:** Revisor
- **Quiero:** Rechazar un documento que no cumple con lo necesario
- **Para:** Cerrar su proceso e informar al emisor el motivo del rechazo

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 07.1**: solo el revisor asignado debe poder rechazar la solicitud
- [x] **CA 07.2**: debe ser obligatorio escribir el motivo del rechazo
- [x] **CA 07.3**: antes de rechazar, se debe pedir una confirmación
- [x] **CA 07.4**: la solicitud debe quedar marcada como rechazada
- [x] **CA 07.5**: el emisor debe recibir una notificación con el motivo

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Transición a estado RECHAZADO exigiendo motivo fundamentado obligatorio, registro inmutable y notificación al emisor con la justificación.

---

### [US-08] Solicitar correccion a documento (Revisor) (`HU-08`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-08`** |
| **Código Ágil / Historia** | `HU-08` (Feature: `flow-004`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-CORR-01 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/843Tld7G/26-solicitar-correccion-a-documento-revisor) (ID: `6a9df13f161020199b840721`) |

#### Narrativa Ágil
- **Como:** Revisor
- **Quiero:** Pedir correcciones en un documento
- **Para:** Que el emisor pueda corregir lo necesario antes de volver a enviarlo

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 08.1**: solo el revisor asignado debe poder pedir correcciones
- [x] **CA 08.2**: debe ser obligatorio escribir al menos una observación
- [x] **CA 08.3**: las observaciones deben quedar visibles para el emisor
- [x] **CA 08.4**: la solicitud debe quedar marcada como pendiente de corrección
- [x] **CA 08.5**: el emisor debe recibir una notificación

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Transición a estado CORRECCION_REQUERIDA con ingreso de observaciones obligatorias visibles para el emisor y notificación contextual.

---

### [US-09] Ver observaciones del revisor (emisor) (`HU-09`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-09`** |
| **Código Ágil / Historia** | `HU-09` (Feature: `flow-005`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-CORR-01 (ver-observaciones-revisor.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/bOj3c5Gh/37-ver-observaciones-del-revisor-emisor) (ID: `6a9eb45f02242157cd7b0a37`) |

#### Narrativa Ágil
- **Como:** Emisor
- **Quiero:** Ver las observaciones que hizo el revisor sobre mi solicitud
- **Para:** Saber qué debo corregir antes de volver a enviarla

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 09.1**: las observaciones deben mostrarse dentro de la solicitud correspondiente
- [x] **CA 09.2**: el usuario debe poder identificar qué información o documento debe corregir
- [x] **CA 09.3**: las observaciones deben quedar disponibles mientras la solicitud esté pendiente de corrección
- [x] **CA 09.4**: el emisor debe poder revisar las observaciones antes de modificar la solicitud
- [x] **CA 09.5**: solo las personas con acceso a la solicitud deben poder verlas

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Visualización de observaciones emitidas por el revisor dentro de la solicitud observada antes de editarla, con control de acceso estricto.

---

### [US-10] Corregir documento (Emisor) (`HU-10`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-10`** |
| **Código Ágil / Historia** | `HU-10` (Feature: `flow-006`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-CORR-02 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/gHB5HuZm/27-corregir-documento-emisor) (ID: `6a9df149193c48cdc7eea4d3`) |

#### Narrativa Ágil
- **Como:** Emisor
- **Quiero:** Corregir un documento que recibió observaciones
- **Para:** Solucionar lo indicado por el revisor y volver a enviarlo a revisión

#### Criterios de Aceptación Oficiales (6 CAs)
- [x] **CA 10.1**: el emisor debe poder ver las observaciones obligatorias del revisor
- [x] **CA 10.2**: solo se pueden corregir solicitudes que estén pendientes de corrección
- [x] **CA 10.3**: el emisor debe poder cambiar la información o archivos necesarios
- [x] **CA 10.4**: antes de volver a enviar, los campos obligatorios deben estar completos
- [x] **CA 10.5**: al reenviar, la solicitud debe quedar en 'pendiente de revisión'
- [x] **CA 10.6**: el revisor debe recibir notificación para volver a revisar

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Edición de formulario o sustitución de archivo observado, validación de obligatoriedad y reenvío automático a estado PENDIENTE_REVISION.

---

### [US-11] Consultar historial de flujos (`HU-11`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-11`** |
| **Código Ágil / Historia** | `HU-11` (Feature: `flow-007`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Inventario de Documentos` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-HIST-01 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/5O1z9spx/15-consultar-historial-de-flujos) (ID: `6a9def630673f8d7f917f3d4`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Consultar el historial de una solicitud
- **Para:** Saber qué cambios, revisiones y decisiones ha tenido desde que fue enviada

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 11.1**: el historial debe mostrar los cambios en orden cronológico según fecha (creación, envío o aprobación)
- [x] **CA 11.2**: cada registro debe indicar el estado (aprobado, rechazado o devuelto con observaciones), quién lo realizó y cuándo
- [x] **CA 11.3**: las observaciones de revisores deben aparecer cuando correspondan
- [x] **CA 11.4**: solo las personas con acceso a la solicitud deben poder ver su historial
- [x] **CA 11.5**: la información del historial no debe poder modificarse (inmutable)

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Línea de tiempo cronológica inmutable con eventos de creación, aprobación, rechazo y observaciones con usuario actor, fecha y estado.

---

### [US-12] Revisar notificaciones en bandeja de entrada (`HU-12`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-12`** |
| **Código Ágil / Historia** | `HU-12` (Feature: `notif-001`) |
| **Sprint Asociado** | **Sprint 1** |
| **Épica / Lista en Trello** | `Notificaciones` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-NOTIF-01 (simple-request-flow.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/PaBe3moE/21-revisar-notificaciones-en-bandeja-de-entrada) (ID: `6a9df0c165db721717615749`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Revisar mis notificaciones dentro de la plataforma
- **Para:** Enterarme de cambios de estado o acciones pendientes relacionadas con mis solicitudes

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 12.1**: el usuario debe ver solo sus propias notificaciones
- [x] **CA 12.2**: cada notificación indica qué ocurrió y a qué solicitud corresponde
- [x] **CA 12.3**: se debe distinguir entre notificaciones leídas y no leídas
- [x] **CA 12.4**: al seleccionar una notificación, se debe poder ir a la solicitud relacionada
- [x] **CA 12.5**: las notificaciones se deben generar ante cambios importantes

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Bandeja de notificaciones in-app con contador de no leídas, diferenciación leídas/no leídas, enlace directo a solicitud y aislamiento por usuario.

---

## 4. Historias de Usuario — Sprint 2: Flujos Configurables y Motor RBAC

### [US-13] Asignar un RUT al crear usuario (`HU-S2-01`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-13`** |
| **Código Ágil / Historia** | `HU-S2-01` (Feature: `auth-005`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-RUT-01 (rut-validation.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/I7vtlb7l/42-asignar-un-rut-al-crear-usuario) (ID: `6abac6d69e1634dec1893867`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Asignar un RUT a los usuarios de la plataforma cuando estoy creando sus cuentas
- **Para:** Registrar datos de cada usuario de forma completa y tener mejor trazabilidad

#### Criterios de Aceptación Oficiales (10 CAs)
- [ ] **CA 01.1**: al momento de crear un usuario, se debe agregar un rut asociado a la nueva cuenta
- [ ] **CA 01.2**: el campo de rut se debe autoformatear a medida que se ingresan los numeros del rut (formato NN.NNN.NNN-N, donde N es un numero o la letra “K”)
- [ ] **CA 01.3**: si se ingresa una “k” minuscula, se debe mostrar en pantalla como “K” mayuscula con el autoformato
- [ ] **CA 01.4**: no debe estar permitido ingresar caracteres diferentes a numeros, la letra “k” o “K”
- [ ] **CA 01.5**: no debe estar permitido ingresar espacios vacios
- [ ] **CA 01.6**: no debe estar permitido ingresar caracteres “de mas”
- [ ] **CA 01.7**: casos en donde no se permite crear una cuenta:
- [ ] **CA 01.8**: rut ingresado no es válido (verificacion por digito verificador)
- [ ] **CA 01.9**: rut ingresado está duplicado
- [ ] **CA 01.10**: si hay algunos de los errores anteriores, mostrar en pantalla un mensaje de error explicativo según sea el caso

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Validación de RUT chileno con dígito verificador módulo 11, máscara interactiva NN.NNN.NNN-N, manejo de k/K, unicidad y mensajes de error.

---

### [US-14] Gestionar areas corporativas (`HU-S2-02`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-14`** |
| **Código Ágil / Historia** | `HU-S2-02` (Feature: `org-001`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-ORG-01 (corporate-areas.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/KykMRs6o/4-gestionar-areas-corporativas) (ID: `6a9dec9808b547373a23960c`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Crear y mantener las áreas de la empresa
- **Para:** Organizar a los usuarios y solicitudes según el área a la que pertenecen

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 02.1**: se debe poder crear una nueva área con un nombre
- [ ] **CA 02.2**: se debe poder cambiar la información de un área existente
- [ ] **CA 02.3**: se debe poder desactivar un área que ya no se utilice
- [ ] **CA 02.4**: no se deben permitir dos áreas con el mismo nombre
- [ ] **CA 02.5**: solo los administradores deben poder realizar estos cambios

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: CRUD de áreas corporativas por ADMIN con unicidad de nombre, jerarquía opcional padre/hija, baja lógica con comprobación de uso y auditoría.

---

### [US-15] Asignar administrador de área (`HU-S2-03`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-15`** |
| **Código Ágil / Historia** | `HU-S2-03` (Feature: `org-002`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-ORG-01 (corporate-areas.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/NaRiukPf/29-asignar-administrador-de-%C3%A1rea) (ID: `6a9df2a99419f0f864410cc3`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Asignar un administrador a cada área
- **Para:** Dejar a una persona responsable de gestionar esa área dentro de la plataforma

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 03.1**: solo un administrador debe poder realizar esta asignación
- [ ] **CA 03.2**: la persona elegida debe ser un usuario activo
- [ ] **CA 03.3**: debe quedar claro qué área administra cada persona
- [ ] **CA 03.4**: se debe poder cambiar al administrador de un área cuando sea necesario
- [ ] **CA 03.5**: el cambio debe quedar registrado

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Asignación de jefatura o encargado de departamento con control de acceso jerárquico a solicitudes de su área.

---

### [US-16] Vincular usuarios con sus áreas (`HU-S2-04`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-16`** |
| **Código Ágil / Historia** | `HU-S2-04` (Feature: `org-003`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-ORG-01 (corporate-areas.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/CenMoJjL/6-vincular-usuarios-con-sus-%C3%A1reas) (ID: `6a9decab637636f4b0afb01b`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Asignar cada usuario a su área correspondiente
- **Para:** Organizar correctamente a las personas dentro de la empresa y mostrarles lo que corresponde a su área

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 04.1**: el usuario y el área deben existir antes de realizar la asignación
- [ ] **CA 04.2**: se debe poder elegir el área a la que pertenece un usuario
- [ ] **CA 04.3**: el área asignada debe aparecer en la información del usuario
- [ ] **CA 04.4**: se debe poder cambiar de área a un usuario cuando sea necesario
- [ ] **CA 04.5**: el cambio debe quedar registrado

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Asignación bidireccional de colaboradores a un departamento corporativo, actualizando visibilidad y trazabilidad en flujos.

---

### [US-17] Gestionar flujos (`HU-S2-05`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-17`** |
| **Código Ágil / Historia** | `HU-S2-05` (Feature: `flow-008`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-FLOW-CONFIG-01 (workflow-config.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/ideLp09f/30-gestionar-flujos) (ID: `6a9df304c3d1bef27581ec5f`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Crear y configurar los pasos que debe seguir cada tipo de solicitud
- **Para:** Adaptar el proceso de revisión y aprobación a las necesidades de cada área

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 05.1**: se debe poder crear un flujo con un nombre y asociarlo a un área
- [ ] **CA 05.2**: se deben poder definir los pasos por los que pasará una solicitud
- [ ] **CA 05.3**: se debe poder indicar quién será responsable de revisar en cada paso
- [ ] **CA 05.4**: se debe poder cambiar el orden o la configuración del flujo
- [ ] **CA 05.5**: un flujo incompleto no debe poder utilizarse para nuevas solicitudes

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Configuración de flujos dinámicos por área, etapas secuenciales 1..N, validación de completitud y protección de flujos en uso.

---

### [US-18] Configurar responsables de revisión (`HU-S2-06`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-18`** |
| **Código Ágil / Historia** | `HU-S2-06` (Feature: `flow-009`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-FLOW-CONFIG-01 (workflow-config.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/9Em3ir60/39-configurar-responsables-de-revisi%C3%B3n) (ID: `6a9eb4ae0aa0a10be55db3c3`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Definir quién revisará cada etapa de una solicitud
- **Para:** Asegurar que cada documento llegue a la persona correcta durante su proceso de revisión

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 06.1**: se debe poder elegir quién será responsable de revisar cada etapa
- [ ] **CA 06.2**: solo se deben poder seleccionar usuarios que estén disponibles en la plataforma
- [ ] **CA 06.3**: se debe poder cambiar al responsable cuando sea necesario
- [ ] **CA 06.4**: una etapa no debe quedar sin responsable si necesita revisión
- [ ] **CA 06.5**: los cambios deben quedar guardados

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Asignación explícita de revisores activos por etapa en cada flujo, previniendo etapas huérfanas y reasignación ante bajas.

---

### [US-19] Gestionar roles y permisos (`HU-S2-07`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-19`** |
| **Código Ágil / Historia** | `HU-S2-07` (Feature: `auth-004`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-ORG-01 (corporate-areas.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/jNbcabRl/38-gestionar-roles-y-permisos) (ID: `6a9eb49c6a77199bbd1b80d7`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Definir los roles, departamentos y niveles de acceso de los usuarios
- **Para:** Asegurar que cada usuario acceda solo a los documentos y funciones de su área respetando la jerarquía corporativa

#### Criterios de Aceptación Oficiales (7 CAs)
- [ ] **CA 07.1**: se debe poder crear y editar roles
- [ ] **CA 07.2**: cada rol debe permitir definir qué acciones puede realizar en la plataforma
- [ ] **CA 07.3**: solo los administradores deben poder cambiar los roles y permisos
- [ ] **CA 07.4**: un usuario no debe poder realizar acciones que no correspondan a su rol
- [ ] **CA 07.5**: los permisos de visualización deben aislar los documentos según el departamento o área corporativa del usuario
- [ ] **CA 07.6**: se debe respetar la jerarquía organizacional: una jefatura puede visualizar documentos de su equipo a cargo, pero no los de su superior directo
- [ ] **CA 07.7**: los cambios de permisos y roles deben quedar guardados y auditables

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Motor RBAC jerárquico departamental con aislamiento horizontal por área y visibilidad vertical de jefaturas.

---

### [US-20] Configurar plazos de aprobación y alertas por tipo de documento (`HU-S2-08`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-20`** |
| **Código Ágil / Historia** | `HU-S2-08` (Feature: `sla-001`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: configuracion` |
| **Estado de Entrega** | **Terminado / Passing** |
| **Suite de Prueba Asignada** | `E2E-SLA-01 (sla-matrix-alerts.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/NORGmvuT/43-configurar-plazos-de-aprobaci%C3%B3n-y-alertas-por-tipo-de-documento) (ID: `6abad3d2f675272430d09693`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Definir una matriz de plazos de aprobación según el tipo de documento y configurar alertas visuales de vencimiento
- **Para:** Controlar los acuerdos de nivel de servicio (SLA), evitar retrasos operacionales y alertar oportunamente a los revisores

#### Criterios de Aceptación Oficiales (5 CAs)
- [x] **CA 08.1**: se debe poder configurar un plazo máximo en días hábiles según el tipo de documento (ej. 4 días hábiles para contratos de servicios, 2 días para órdenes de compra)
- [x] **CA 08.2**: el cálculo del plazo debe iniciar al registrarse o enviarse el documento a revisión
- [x] **CA 08.3**: el sistema debe mostrar alertas visuales en la bandeja de revisiones pendientes cuando un plazo esté por vencer o vencido
- [x] **CA 08.4**: el plazo configurado debe aplicar a las decisiones de aprobación, rechazo y solicitud de correcciones
- [x] **CA 08.5**: solo los administradores deben poder configurar o modificar los plazos

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Matriz de SLA en días hábiles excluyendo fines de semana según tipo de documento y badges visuales reactivos (A tiempo, Por vencer, Vencido).

---

### [US-21] Ver detalle de una solicitud (Emisor/Revisor) (`HU-S2-09`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-21`** |
| **Código Ágil / Historia** | `HU-S2-09` (Feature: `flow-010`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-DOC-SEARCH-01 (document-search.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/ApzaiAfx/36-ver-detalle-de-una-solicitud-emisor-revisor) (ID: `6a9eb44fedc9abb833238dca`) |

#### Narrativa Ágil
- **Como:** Emisor o Revisor
- **Quiero:** Ver toda la información de una solicitud
- **Para:** Revisar en un solo lugar sus datos, documentos, estado y observaciones

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 09.1**: la solicitud debe mostrar su información principal
- [ ] **CA 09.2**: se deben poder ver los documentos adjuntos
- [ ] **CA 09.3**: se debe mostrar el estado actual de la solicitud
- [ ] **CA 09.4**: se deben mostrar las observaciones cuando existan
- [ ] **CA 09.5**: solo las personas con acceso a la solicitud deben poder ver su detalle

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Endpoint y vista unificada de detalle integral con pestañas de resumen, documentos con visor PDF seguro, observaciones e historial.

---

### [US-22] Consultar documentos (`HU-S2-10`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-22`** |
| **Código Ágil / Historia** | `HU-S2-10` (Feature: `doc-002`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Inventario de Documentos` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-DOC-SEARCH-01 (document-search.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/7J6MKccA/13-consultar-documentos) (ID: `6a9def4f12bb4c9e1eaa2c31`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Buscar y consultar documentos
- **Para:** Encontrar rápidamente la información que necesito según mi área y perfil asignado

#### Criterios de Aceptación Oficiales (6 CAs)
- [ ] **CA 10.1**: el usuario debe ver solo los documentos que correspondan a su departamento y rol permitido
- [ ] **CA 10.2**: se debe respetar la jerarquía organizacional: las jefaturas acceden a documentos de sus colaboradores directos pero no a los de rangos superiores
- [ ] **CA 10.3**: se debe poder buscar documentos por información relevante
- [ ] **CA 10.4**: se debe poder filtrar por datos como tipo de documento, estado, área o fecha
- [ ] **CA 10.5**: cada resultado debe mostrar información básica del documento incluyendo su código correlativo
- [ ] **CA 10.6**: al seleccionar un documento, se debe poder ver su detalle

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Buscador multicriterio con filtros de texto libre, formato, área, estado y fechas (America/Santiago) con aislamiento RBAC estricto.

---

### [US-23] Consultar estado de mis solicitudes (`HU-S2-11`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-23`** |
| **Código Ágil / Historia** | `HU-S2-11` (Feature: `flow-011`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Inventario de Documentos` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-DOC-SEARCH-01 (document-search.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/YGejrHU6/40-consultar-estado-de-mis-solicitudes) (ID: `6a9eb4e0937936d99d5f439a`) |

#### Narrativa Ágil
- **Como:** Emisor
- **Quiero:** Consultar el estado de mis solicitudes
- **Para:** Saber en qué etapa se encuentran y si tengo que realizar alguna acción

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 11.1**: el usuario debe ver sus solicitudes y aquellas a las que tenga acceso
- [ ] **CA 11.2**: cada solicitud debe mostrar claramente su estado actual y su código correlativo
- [ ] **CA 11.3**: debe indicarse si está pendiente de revisión, necesita correcciones, fue aprobada o fue rechazada
- [ ] **CA 11.4**: al seleccionar una solicitud, se debe poder ver su detalle e historial inmutable
- [ ] **CA 11.5**: los cambios de estado deben verse reflejados en la consulta

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Bandejas 'Mis Solicitudes' y 'Según mi acceso' con refresco automático de 30s, correlativo destacado y navegación al detalle.

---

### [US-24] Descargar documentos (`HU-S2-12`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-24`** |
| **Código Ágil / Historia** | `HU-S2-12` (Feature: `doc-003`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Inventario de Documentos` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-DOC-SEARCH-01 (document-search.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/KUsk0128/14-descargar-documentos) (ID: `6a9def582f6e4d11de32c08f`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Descargar un documento
- **Para:** Poder revisarlo o utilizarlo fuera de la plataforma

#### Criterios de Aceptación Oficiales (4 CAs)
- [ ] **CA 12.1**: solo se deben poder descargar documentos a los que el usuario tenga acceso
- [ ] **CA 12.2**: el archivo descargado debe mantener su contenido y formato
- [ ] **CA 12.3**: el nombre del archivo debe conservarse cuando sea posible
- [ ] **CA 12.4**: si el archivo no está disponible, se debe mostrar un mensaje al usuario

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Streaming seguro desde MinIO S3 con autorización previa, headers UTF-8 Content-Disposition, cierre de recursos y prevención de doble clic.

---

### [US-25] Cambiar Contraseña (`HU-S2-13`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-25`** |
| **Código Ágil / Historia** | `HU-S2-13` (Feature: `auth-006`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Autenticacion y sesiones` |
| **Estado de Entrega** | **Verificado / Passing** |
| **Suite de Prueba Asignada** | `E2E-SEC-AUTH-01 (change-password.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/MLbAxxNR/3-cambiar-contrase%C3%B1a) (ID: `6a9debcca63f6cb455d30435`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Cambiar mi contraseña para mantener mi cuenta segura y proteger mi información
- **Para:** Mantener mi cuenta segura y proteger mi información

#### Criterios de Aceptación Oficiales (6 CAs)
- [x] **CA 13.1**: El usuario debe ingresar su **contraseña actual** antes de realizar el cambio.
- [x] **CA 13.2**: El usuario debe ingresar una **nueva contraseña** y confirmarla.
- [x] **CA 13.3**: Si la contraseña actual es incorrecta, mostrar el mensaje: **“La contraseña actual es incorrecta, inténtelo nuevamente.”**
- [x] **CA 13.4**: La nueva contraseña debe cumplir con los **requisitos mínimos de seguridad** establecidos por el sistema.
- [x] **CA 13.5**: Si las contraseñas nuevas no coinciden, mostrar un mensaje indicando que **las contraseñas no coinciden**.
- [x] **CA 13.6**: Al cambiar correctamente la contraseña, mostrar un mensaje de **confirmación** y permitir al usuario continuar utilizando el sistema.

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Autogestión de credenciales con validación de contraseña actual en Keycloak, política efectiva de seguridad y confirmación en tiempo real.

- **Validación técnica final (14-10-2026)**: PasswordChangeOperationsTest 9/9 correctas en 12.592 s; Maven package BUILD SUCCESS en 2 min 27 s. E2E-SEC-AUTH-01: 6/6 correctas en 30.4 s, sin omisiones ni reintentos; seis criterios verificados y auth-006 passing.
- **Estado del entorno**: credencial original restaurada, autenticación HTTP 200 y cierre de sesión temporal HTTP 204; backend UP y cero reinicios. Política efectiva de 8–1024 caracteres preservada.
- **Evidencia**: `tests/e2e/playwright-report/password-2026-10-14-docker-05/index.html`, seis videos en `tests/e2e/test-results/password-2026-10-14-docker-05` y XML de regresión en `backend/sistema-principal/target/surefire-reports`.

---

### [US-26] Ver resumen general de solicitudes (`HU-S2-14`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-26`** |
| **Código Ágil / Historia** | `HU-S2-14` (Feature: `dash-002`) |
| **Sprint Asociado** | **Sprint 2** |
| **Épica / Lista en Trello** | `Dashboards` |
| **Estado de Entrega** | **En Desarrollo / Por Validar** |
| **Suite de Prueba Asignada** | `E2E-DASH-METRICS-01 (dashboard-general-summary.spec.ts)` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/lY5wpFsR/35-ver-resumen-general-de-solicitudes) (ID: `6a9e3e3d5fe007d04599c6f9`) |

#### Narrativa Ágil
- **Como:** Administrador o encargado
- **Quiero:** Ver un resumen general de las solicitudes
- **Para:** Conocer rápidamente cómo se encuentran los procesos dentro de la plataforma

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 14.1**: se debe mostrar la cantidad de solicitudes pendientes, aprobadas, rechazadas y en corrección
- [ ] **CA 14.2**: se debe poder ver información general por área cuando corresponda
- [ ] **CA 14.3**: la información debe actualizarse según los cambios de las solicitudes
- [ ] **CA 14.4**: cada usuario debe ver solo la información que tenga permitido consultar
- [ ] **CA 14.5**: el resumen debe ser claro y fácil de entender

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Dashboard cuantitativo con tarjetas KPI, desglose por área corporativa, tendencia de emisiones y actualización reactiva.

---

## 5. Historias de Usuario — Product Backlog Futuro (Sprint 3 y Posteriores)

### [US-27] Recuperar Contraseña (`HU-PB-01`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-27`** |
| **Código Ágil / Historia** | `HU-PB-01` (Feature: `auth-fut-01`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Autenticacion y sesiones` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-AUTH-RECOVERY` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/473u017N/47-recuperar-contrase%C3%B1a) (ID: `6abaf1762d20fb81162942fd`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Recuperar mi contraseña en caso de olvido
- **Para:** Volver a tener acceso al sistema

#### Criterios de Aceptación Oficiales (11 CAs)
- [ ] **CA 01.1**: en la página de Login hay un boton o link para ir a la vista “Recuperar Contraseña”
- [ ] **CA 01.2**: se debe ingresar el correo asociado a la cuenta para iniciar el proceso de recuperacion
- [ ] **CA 01.3**: debe llegar al correo un link para recuperar contraseña
- [ ] **CA 01.4**: iniciar el proceso de recuperación no inhabilita la contraseña antigua
- [ ] **CA 01.5**: la nueva contraseña debe cumplir con el estandar de seguridad basico
- [ ] **CA 01.6**: luego de cambiar la contraseña
- [ ] **CA 01.7**: la contraseña antigua no permite hacer login
- [ ] **CA 01.8**: solo se puede hacer login con la nueva contraseña
- [ ] **CA 01.9**: debe quedar registrado en logs
- [ ] **CA 01.10**: quien solicito la recuperacion
- [ ] **CA 01.11**: si tuvo exito en el cambio de contraseña

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Mecanismo de autoservicio de recuperación de contraseña vía correo con enlace seguro de un solo uso y expiración temporal.

---

### [US-28] Registrar documento usando planilla (Emisor) (`HU-PB-02`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-28`** |
| **Código Ágil / Historia** | `HU-PB-02` (Feature: `tmpl-fut-01`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-TMPL-EMIT` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/cIbTJfP8/20-registrar-documento-usando-planilla-emisor) (ID: `6a9df08e7f0650b8bcc4deab`) |

#### Narrativa Ágil
- **Como:** Emisor
- **Quiero:** Registrar un documento usando una planilla
- **Para:** Completar una solicitud de forma ordenada y enviarla a revisión

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 02.1**: el usuario debe poder elegir una planilla disponible
- [ ] **CA 02.2**: la planilla debe mostrar los campos que debe completar
- [ ] **CA 02.3**: los campos obligatorios deben estar completos antes de enviar
- [ ] **CA 02.4**: se deben poder adjuntar los documentos requeridos
- [ ] **CA 02.5**: al registrar la solicitud, se debe mostrar una confirmación

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Generación y llenado interactivo de formularios estructurados basados en plantillas empresariales preconfiguradas.

---

### [US-29] Autocompletar documento usando IA (Emisor) (`HU-PB-03`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-29`** |
| **Código Ágil / Historia** | `HU-PB-03` (Feature: `ai-fut-01`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-AI-AUTOCOMPLETE` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/rirUoorE/32-autocompletar-documento-usando-ia-emisor) (ID: `6a9df6f08cf8353af65bbc4c`) |

#### Narrativa Ágil
- **Como:** Emisor del sistema
- **Quiero:** Utilizar IA para autocompletar la información de un documento, para agilizar su elaboración y reducir errores al ingresar los datos
- **Para:** Autocompletar la información de un documento, para agilizar su elaboración y reducir errores al ingresar los datos

#### Criterios de Aceptación Oficiales (6 CAs)
- [ ] **CA 03.1**: El Emisor debe poder **cargar o seleccionar un documento** para utilizar la función de autocompletado.
- [ ] **CA 03.2**: La IA debe **analizar la información disponible en el documento** y proponer los campos que puedan ser completados.
- [ ] **CA 03.3**: El sistema debe mostrar al Emisor los **datos sugeridos por la IA antes de guardar** el documento.
- [ ] **CA 03.4**: El Emisor debe poder **revisar y modificar las sugerencias** realizadas por la IA.
- [ ] **CA 03.5**: Si la IA no puede identificar algún dato, el campo debe quedar disponible para **completarse manualmente**.
- [ ] **CA 03.6**: El documento solo podrá continuar al siguiente proceso **después de que el Emisor confirme la información**.

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Asistente generativo basado en OpenRouter / Apache Tika para extracción semántica y autocompletado de metadatos de documentos.

---

### [US-30] Evaluación de la IA de la solicitud  (Revisor) (`HU-PB-04`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-30`** |
| **Código Ágil / Historia** | `HU-PB-04` (Feature: `ai-fut-02`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-AI-EVAL` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/scyD5quq/23-evaluaci%C3%B3n-de-la-ia-de-la-solicitud-revisor) (ID: `6a9df0f8fcf275970f561e4e`) |

#### Narrativa Ágil
- **Como:** Revisor
- **Quiero:** Ver la evaluación que hizo la IA sobre una solicitud
- **Para:** Tener una ayuda adicional al momento de revisar el documento

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 04.1**: la evaluación debe corresponder a la solicitud que se está revisando
- [ ] **CA 04.2**: la IA debe mostrar observaciones o datos que puedan ayudar al revisor
- [ ] **CA 04.3**: debe quedar claro que la decisión final corresponde al revisor
- [ ] **CA 04.4**: el revisor debe poder aprobar, rechazar o pedir correcciones aunque la IA sugiera otra cosa
- [ ] **CA 04.5**: si la IA no está disponible, la revisión manual debe seguir funcionando

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Análisis de calidad y cumplimiento normativo asistido por IA para asistir al revisor con pre-evaluación y puntaje porcentual.

---

### [US-31] Control de versiones de documentos (`HU-PB-05`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-31`** |
| **Código Ágil / Historia** | `HU-PB-05` (Feature: `doc-fut-01`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Flujos: operacion` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-DOC-VERSIONING` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/6oiaegRL/45-control-de-versiones-de-documentos) (ID: `6abae036074e6106adee2758`) |

#### Narrativa Ágil
- **Como:** Emisor o Revisor del sistema
- **Quiero:** Que la plataforma gestione y versione automáticamente los documentos al subsanar observaciones
- **Para:** Mantener la trazabilidad de cambios entre versiones sucesivas y preservar el historial íntegro de archivos adjuntos

#### Criterios de Aceptación Oficiales (4 CAs)
- [ ] **CA 05.1**: al registrarse una solicitud por primera vez, el documento adjunto debe identificarse automáticamente como versión 1 (v1)
- [ ] **CA 05.2**: cuando una solicitud sea observada y el emisor la reenvíe tras corregirla, el sistema debe incrementar automáticamente el número de versión (ej. versión 2)
- [ ] **CA 05.3**: el historial de la solicitud debe registrar la nueva versión indicando usuario, fecha, motivo de corrección y el archivo adjunto sustituido
- [ ] **CA 05.4**: los usuarios autorizados deben poder visualizar el número de versión actual y acceder a consultar o descargar versiones archivadas anteriores

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Versionado formal de documentos (v1, v2, vN) al reenviar con observaciones, historial de sustitución de binarios y auditoría.

---

### [US-32] Crear plantilla dinámica (`HU-PB-06`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-32`** |
| **Código Ágil / Historia** | `HU-PB-06` (Feature: `tmpl-fut-02`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Plantillas` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-TMPL-DYNAMIC` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/LW7VDU6T/16-crear-plantilla-din%C3%A1mica) (ID: `6a9df02a511b4850f2ed0210`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Crear una plantilla para un tipo de solicitud
- **Para:** Un tipo de solicitud

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 06.1**: se debe poder indicar un nombre y una descripción para la plantilla
- [ ] **CA 06.2**: se deben poder agregar, cambiar, ordenar y eliminar campos
- [ ] **CA 06.3**: se debe poder indicar cuáles campos son obligatorios
- [ ] **CA 06.4**: antes de guardar, la plantilla debe tener la información mínima necesaria
- [ ] **CA 06.5**: una plantilla disponible debe poder ser utilizada al crear nuevas solicitudes

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Diseñador de plantillas dinámicas por administradores definiendo campos obligatorios/opcionales y tipos de datos.

---

### [US-33] Gestionar plantillas (`HU-PB-07`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-33`** |
| **Código Ágil / Historia** | `HU-PB-07` (Feature: `tmpl-fut-03`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Plantillas` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-TMPL-MANAGEMENT` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/nFxBs7xR/17-gestionar-plantillas) (ID: `6a9df030a4db347cbe572c89`) |

#### Narrativa Ágil
- **Como:** Administrador
- **Quiero:** Administrar las plantillas existentes
- **Para:** Mantener actualizados los formularios que utilizan los usuarios

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 07.1**: se debe mostrar una lista con las plantillas disponibles
- [ ] **CA 07.2**: se debe poder abrir y modificar una plantilla
- [ ] **CA 07.3**: se debe poder activar o desactivar una plantilla
- [ ] **CA 07.4**: una plantilla desactivada no debe aparecer para nuevas solicitudes
- [ ] **CA 07.5**: las solicitudes antiguas deben conservar la información de la plantilla que utilizaron

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Catálogo y ciclo de vida de plantillas documentales (alta, edición, activación/desactivación y versionamiento).

---

### [US-34] Definir tipos de documento y correlativos (`HU-PB-08`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-34`** |
| **Código Ágil / Historia** | `HU-PB-08` (Feature: `doc-fut-02`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Plantillas` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-DOC-CORRELATIVE` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/mdj2b3ig/44-definir-tipos-de-documento-y-correlativos) (ID: `6abae01a2f4c0566eeaccbed`) |

#### Narrativa Ágil
- **Como:** Administrador del sistema
- **Quiero:** Crear y administrar los tipos de documento disponibles en la plataforma y configurar su prefijo correlativo único
- **Para:** Mantener la atomicidad del backlog según Minuta Acta N° 2

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 08.1**: se debe poder crear, editar y desactivar tipos de documento indicando nombre y descripción
- [ ] **CA 08.2**: cada tipo de documento debe permitir configurar un prefijo de código correlativo único (ej. CONT, MEMO, FAC)
- [ ] **CA 08.3**: en el formulario de registro de solicitudes, se debe incluir como primer campo obligatorio la selección del tipo de documento mediante lista desplegable
- [ ] **CA 08.4**: al guardarse la solicitud, el sistema genera automáticamente un correlativo secuencial único según su tipo (ej. CONT-001, CONT-002)
- [ ] **CA 08.5**: en las listas de revisión, inventario y consulta de solicitudes, se debe mostrar la columna o etiqueta con el tipo de documento y su código correlativo

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Catálogo administrativo de tipos de documento con asignación de prefijo oficial (ej. CONT-, MEMO-) y correlativos automáticos.

---

### [US-35] Recibir notificaciones por correo (`HU-PB-09`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-35`** |
| **Código Ágil / Historia** | `HU-PB-09` (Feature: `notif-fut-01`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Notificaciones` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-NOTIF-EMAIL` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/3uqQoVP5/28-recibir-notificaciones-por-correo) (ID: `6a9df16abfe38af5a29a9636`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema
- **Quiero:** Recibir avisos por correo cuando ocurra un cambio importante en mis solicitudes
- **Para:** Mantenerme informado aunque no esté usando la plataforma

#### Criterios de Aceptación Oficiales (5 CAs)
- [ ] **CA 09.1**: los avisos deben llegar al correo asociado a la cuenta del usuario
- [ ] **CA 09.2**: el correo debe indicar qué ocurrió y a qué solicitud corresponde
- [ ] **CA 09.3**: se deben enviar avisos cuando una solicitud cambie de estado o requiera una acción del usuario
- [ ] **CA 09.4**: si el correo no puede enviarse, la solicitud debe seguir funcionando normalmente
- [ ] **CA 09.5**: el sistema debe guardar que se intentó enviar el aviso

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Integración transaccional con servicio de correo externo (MasterBase / Resend) vía cola asíncrona RabbitMQ.

---

### [US-36] Notificaciones diferenciadas por rol y evento (`HU-PB-10`)

| Atributo | Detalle |
| :--- | :--- |
| **ID Único de Trazabilidad** | **`US-36`** |
| **Código Ágil / Historia** | `HU-PB-10` (Feature: `notif-fut-02`) |
| **Sprint Asociado** | **Product Backlog (Futuro)** |
| **Épica / Lista en Trello** | `Notificaciones` |
| **Estado de Entrega** | **Priorizado para Sprint 3** |
| **Suite de Prueba Asignada** | `E2E-NOTIF-ROLE` |
| **Tarjeta Oficial Trello** | [Ver en Trello](https://trello.com/c/kKXMXyMi/46-notificaciones-diferenciadas-por-rol-y-evento) (ID: `6abae0507379e70ecb236c96`) |

#### Narrativa Ágil
- **Como:** Usuario del sistema (Emisor / Revisor)
- **Quiero:** Recibir notificaciones contextualizadas según mi rol específico en el flujo de aprobación
- **Para:** Distinguir de inmediato las solicitudes que requieren mi revisión humana de aquellas donde solo se me informa el avance de mi trámite

#### Criterios de Aceptación Oficiales (4 CAs)
- [ ] **CA 10.1**: el emisor debe recibir notificaciones informativas sobre el avance y resolución de su solicitud (aprobada, rechazada o devuelta con observaciones) haciendo referencia a su código correlativo
- [ ] **CA 10.2**: el revisor debe recibir notificaciones de asignación que indiquen documentos pendientes por revisar
- [ ] **CA 10.3**: las notificaciones se deben generar únicamente cuando ocurra una transición efectiva de estado en la solicitud
- [ ] **CA 10.4**: cada notificación debe incluir enlace directo para abrir el trámite en pantalla

#### Trazabilidad Técnica y Arquitectónica
> **Resumen Técnico**: Plantillas de notificación personalizadas distinguiendo rol emisor (informativas con correlativo) de rol revisor (asignación de trabajo).

---

## 6. Control de Cambios y Gobernanza del Backlog

| Versión | Fecha | Autor / Agente | Descripción del Cambio |
| :---: | :---: | :--- | :--- |
| 1.0.0 | 28-09-2026 | Equipo Ágil / Agente | Cierre del Sprint 1 y desacoplamiento atómico de criterios en Product Backlog. |
| 1.1.0 | 04-10-2026 | Equipo Ágil / Agente | Formalización y desarrollo de las 14 historias del Sprint 2 en Trello. |
| 2.0.0 | 10-10-2026 | Agente Antigravity | Extracción integral vía Trello MCP, normalización de 36 historias con ID único `US-01` a `US-36` y generación de matriz de trazabilidad para exportación a PDF. |
