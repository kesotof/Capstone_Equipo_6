# Contratos de API REST (API Contracts) - Sistema Principal Capstone

Este documento es la **referencia directa e inmutable de los contratos REST** del backend (`sistema-principal`, puerto `8081`) para el desarrollo de vistas, servicios y componentes en el frontend.

La sección 7 cuenta con implementación backend revisada mediante peticiones HTTP; la interfaz, las pruebas E2E del equipo y la validación visual siguen pendientes.

---

## 1. Convenciones Generales

- **Base URL**: `http://localhost:8081` (o proxy `/api/*` configurado en frontend).
- **Autenticación**: Cabecera HTTP `Authorization: Bearer <access_token>` (JWT emitido por Keycloak, realm `capstone-realm`, client `capstone-client`).
- **Formato de Error Global (RFC 7807 ProblemDetail)**:
  ```json
  {
    "type": "https://capstone.local/errors/<codigo-error>",
    "title": "Descripción corta del error",
    "status": 400,
    "detail": "Explicación detallada del error",
    "timestamp": "2026-09-15T17:00:00Z"
  }
  ```
- **Roles del Sistema**:
  - `ADMIN`: Administrador con control total sobre usuarios, auditoría y flujos.
  - `APPROVER` (en UI mostrado como *"Emisor y Revisor"*): Usuario operativo estándar. Puede emitir y revisar documentos.

---

## 2. Módulo de Solicitudes y Flujo Documental (`/api/solicitudes`)

### 2.1 Registrar Solicitud con Documento Inicial
Crea una solicitud documental en estado `PENDIENTE_REVISION`, sube el archivo a MinIO S3 y genera el documento en versión 1.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes`
- **Seguridad**: Autenticado (`ADMIN` o `APPROVER`)
- **Content-Type**: `multipart/form-data`
- **Parámetros Form-Data**:
  - `titulo` (String, obligatorio): Título del documento.
  - `tipoDocumento` (String, opcional, por defecto `"General"`): Tipo documental según catálogo SLA (ej: `Contrato`, `Factura`, `Memorándum`, `General`). Determina el plazo límite (deadline) exacto de SLA y el prefijo de correlativo.
  - `descripcion` (String, opcional): Resumen o contexto de la solicitud.
  - `file` (File, obligatorio): Archivo adjunto (`.pdf`, `.docx`, `.doc`, `.xml`, `.txt`, `.xlsx`, `.xls`). Máximo: 10 MB.
  - `notificarEmail` (Boolean, opcional, por defecto `false`): Si es `true`, publica el evento a RabbitMQ para despacho de correo vía Resend.
  - `flujoId` (Long, opcional): ID del flujo de trabajo a asociar; por defecto usa el flujo base (ID 1).
- **Respuesta (201 Created)**:
  ```json
  {
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "656ba77b-2231-4b17-9007-01de7e007d53",
    "estado": "PENDIENTE_REVISION",
    "mensaje": "Documento registrado correctamente y solicitud enviada a revisión"
  }
  ```
- **Errores**:
  - `400 Bad Request`: Formato no permitido (`.exe`, etc.) o archivo > 10MB o título vacío.
  - `401 Unauthorized`: Token no provisto o inválido.

---

### 2.2 Listar Mis Solicitudes (Bandeja del Emisor)
Devuelve las solicitudes emitidas por el usuario logueado en orden cronológico descendente.

Este endpoint conserva su respuesta de array y orden por creación. El lector paginado de seguimiento HU-S2-11 está implementado por separado en [§12](#12-consulta-y-seguimiento-de-solicitudes-del-emisor--hu-s2-11); no sustituir este contrato por una página.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/mis-solicitudes`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
      "titulo": "Contrato de Proveedor Q3",
      "descripcion": "Contrato para adquisicion de equipos",
      "estado": "PENDIENTE_REVISION",
      "emisorId": "3194f022-344b-473c-baee-85cc2d6155c7",
      "emisorNombre": "Admin Capstone",
      "emisorEmail": "admin@capstone.local",
      "documentoVigente": {
        "id": "656ba77b-2231-4b17-9007-01de7e007d53",
        "nombreArchivo": "contrato.pdf",
        "contentType": "application/pdf",
        "sizeBytes": 1048576,
        "version": 1,
        "vigente": true,
        "createdAt": "2026-09-15T17:12:24.613Z"
      },
      "createdAt": "2026-09-15T17:12:24.160Z",
      "updatedAt": "2026-09-15T17:12:24.160Z"
    }
  ]
  ```

---

### 2.3 Listar Revisiones Pendientes (Bandeja del Revisor)
Devuelve solicitudes en estado `PENDIENTE_REVISION` (o según filtro) de forma paginada y filtrable.

> **Importante para agentes**:
> - La ruta exacta es `GET /api/solicitudes/pendientes-revision` (NO usar `/api/solicitudes/pendientes`, ya que `{id}` es un `@PathVariable UUID` y la palabra `pendientes` provoca `MethodArgumentTypeMismatchException` con HTTP 400).
> - Los parámetros de paginación en este endpoint usan nombres en español: `pagina` (base 0) y `tamanio` (default 20, max 100). No usar `page` ni `size`.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/pendientes-revision`
- **Seguridad**: Autenticado (`ADMIN` o `APPROVER`)
- **Parámetros Query**:
  - `nombreArchivo` (String, opcional): Búsqueda por coincidencia en el nombre del documento adjunto.
  - `emisor` (String, opcional): Búsqueda por nombre o correo del emisor.
  - `fechaDesde` (Instant ISO 8601, opcional): Filtro desde fecha de creación.
  - `fechaHasta` (Instant ISO 8601, opcional): Filtro hasta fecha de creación.
  - `estado` (String, opcional, por defecto `PENDIENTE_REVISION`): Estado de la solicitud.
  - `pagina` (int, opcional, por defecto `0`, min `0`): Índice de página.
  - `tamanio` (int, opcional, por defecto `20`, min `1`, max `100`): Tamaño de página.
- **Respuesta (200 OK)**:
  ```json
  {
    "contenido": [
      {
        "id": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "correlativo": "CONT-001",
        "titulo": "Contrato de Proveedor Q3",
        "nombreArchivo": "contrato.pdf",
        "emisorNombre": "Admin Capstone",
        "emisorEmail": "admin@capstone.local",
        "fechaCreacion": "2026-09-15T17:12:24.160Z",
        "deadline": "2026-09-21T17:12:24.160Z",
        "slaStatus": "NORMAL",
        "estado": "PENDIENTE_REVISION"
      }
    ],
    "pagina": 0,
    "tamanio": 20,
    "totalElementos": 1,
    "totalPaginas": 1,
    "primera": true,
    "ultima": true
  }
  ```
- **Valores posibles de `slaStatus`**:
  - `"NORMAL"`: Con plazo vigente (> 24h restantes). En frontend se muestra badge info *"A tiempo"*.
  - `"POR_VENCER"`: Quedan 24 horas o menos antes del deadline. En frontend se muestra badge warning *"Por vencer"*.
  - `"VENCIDO"`: Fecha límite ya expiró. En frontend se muestra badge error *"Vencido"*.

---

### 2.4 Resumen del Dashboard y Acciones Pendientes
Devuelve de manera agregada y atómica las acciones que el usuario autenticado tiene pendientes por realizar (revisiones requeridas o correcciones observadas pendientes de subsanación) junto con la lista de solicitudes emitidas por el usuario que se encuentran en trámite.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/dashboard`
- **Seguridad**: Autenticado (`ADMIN` o `APPROVER`)
- **Respuesta (200 OK)**:
  ```json
  {
    "accionesPendientes": [
      {
        "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Contrato de Arrendamiento Q3",
        "tipoAccion": "REVISION",
        "descripcionAccion": "Requiere tu revisión y decisión",
        "estadoActual": "PENDIENTE_REVISION",
        "emisorNombre": "Juan Pérez",
        "emisorEmail": "jperez@capstone.local",
        "nombreArchivo": "contrato.pdf",
        "version": 1,
        "fecha": "2026-09-15T17:12:24.160Z",
        "ultimaObservacion": null
      },
      {
        "solicitudId": "b123ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Informe Financiero Anual",
        "tipoAccion": "CORRECCION",
        "descripcionAccion": "Requiere subsanación de observaciones",
        "estadoActual": "CORRECCION_REQUERIDA",
        "emisorNombre": "Admin Capstone",
        "emisorEmail": "admin@capstone.local",
        "nombreArchivo": "informe.xlsx",
        "version": 1,
        "fecha": "2026-09-15T18:00:00.000Z",
        "ultimaObservacion": "Falta adjuntar el balance auditado en la hoja 2."
      }
    ],
    "misSolicitudesPendientes": [
      {
        "id": "b123ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Informe Financiero Anual",
        "descripcion": "Balance anual",
        "estado": "CORRECCION_REQUERIDA",
        "emisorId": "3194f022-344b-473c-baee-85cc2d6155c7",
        "emisorNombre": "Admin Capstone",
        "emisorEmail": "admin@capstone.local",
        "documentoVigente": {
          "id": "656ba77b-2231-4b17-9007-01de7e007d53",
          "nombreArchivo": "informe.xlsx",
          "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "sizeBytes": 524288,
          "version": 1,
          "vigente": true,
          "createdAt": "2026-09-15T17:12:24.613Z"
        },
        "createdAt": "2026-09-15T17:12:24.160Z",
        "updatedAt": "2026-09-15T18:00:00.000Z"
      }
    ]
  }
  ```

---

### 2.5 Obtener Detalle de una Solicitud
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` único (mismo schema individual de 2.2).
- En el backend secuencial agrega `version` de la solicitud y `etapaActual:{id,orden,nombre}`. Esta versión es independiente de `documentoVigente.version`; debe conservarse para decidir/reenviar.
- **Errores**: `404 Not Found` si el UUID no existe.

El detalle integral de HU-S2-09 está implementado por separado en [§10](#10-detalle-integral-de-solicitud--hu-s2-09). Esta ruta conserva `SolicitudResponse`.

---

### 2.6 Aprobar Solicitud
Aprueba la etapa actual. Si existe otra, conserva `PENDIENTE_REVISION` y avanza al responsable siguiente; solo la última termina en `APROBADO`. Registra evento con etapas, SLA y auditoría. Notifica al siguiente responsable o al emisor en el cierre final.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/aprobar`
- **Seguridad**: Autenticado. Revisor ≠ Emisor (excepto si el revisor tiene rol `ADMIN`).
- **Query Params / JSON Body**:
  - JSON `version` (Long no negativa, obligatoria): versión observada en GET detalle.
  - `notificarEmail` (Boolean, opcional, por defecto `false`): correo al destinatario autorizado correspondiente, publicado tras commit.
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` con etapa y versión actuales; estado pendiente en avance o aprobado en cierre.
- **Errores**:
  - `403 Forbidden`: Si el emisor intenta auto-aprobar y no es Admin.
  - `409 Conflict`: Si el estado actual no es `PENDIENTE_REVISION`.

---

### 2.7 Rechazar Solicitud
Transiciona de `PENDIENTE_REVISION` a `RECHAZADO` conservando la etapa. Requiere motivo, versión observada y autorización de decisión RBAC sobre la solicitud; registra evento/SLA/auditoría y notifica al emisor con acceso vigente.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/rechazar`
- **Seguridad**: cuenta local con permiso de rechazo en la etapa actual; restricciones de emisor propio/superiores y excepción ADMIN de la política vigente.
- **Content-Type**: `application/json` (o query params)
- **Request Body**:
  ```json
  {
    "motivo": "El presupuesto sobrepasa el límite autorizado para el área.",
    "version": 0,
    "notificarEmail": true
  }
  ```
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` actualizado con `estado: "RECHAZADO"`.
- **Errores**:
  - `400 Bad Request`: Si `motivo` viene vacío.
  - `409 Conflict`: Si la solicitud no está en `PENDIENTE_REVISION`.
- **Notificaciones**: La notificación interna siempre se persiste. Con `notificarEmail: true`, además se publica el evento RabbitMQ para informar al emisor por correo.

---

### 2.8 Solicitar Corrección a Solicitud
Transiciona a `CORRECCION_REQUERIDA` en la misma etapa y crea una observación activa visible para el emisor. Exige versión observada y autorización de decisión RBAC.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/pedir-correccion`
- **Seguridad**: Autenticado. Revisor ≠ Emisor (o Admin).
- **Content-Type**: `application/json` (o query params)
- **Request Body**:
  ```json
  {
    "observacion": "Falta adjuntar la firma del responsable técnico en la última página.",
    "version": 0,
    "notificarEmail": false
  }
  ```
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` con `estado: "CORRECCION_REQUERIDA"`.
- **Errores**:
  - `400 Bad Request`: Si `observacion` viene vacía.
  - `403 Forbidden`: Si emisor intenta auto-observarse (no Admin).
  - `409 Conflict`: Si estado actual no es `PENDIENTE_REVISION`.

---

### 2.9 Reenviar Solicitud Subsanada
Permite al emisor actualizar título/descripción y opcionalmente adjuntar un nuevo archivo. Marca el archivo anterior como `vigente = false`, genera una nueva versión (`version = previous + 1`), resuelve observaciones pendientes y retorna a `PENDIENTE_REVISION`. La actualización de base de datos es transaccional; si falla después de subir un reemplazo, el archivo nuevo se elimina de MinIO como compensación para evitar datos huérfanos.

- **Método**: `PUT`
- **Ruta**: `/api/solicitudes/{id}/reenviar`
- **Seguridad**: Autenticado. Solo el emisor original (o `ADMIN`).
- **Content-Type**: `multipart/form-data`
- **Parámetros Form-Data**:
  - `version` (Long no negativa, obligatoria): versión de solicitud obtenida al consultar el detalle.
  - `titulo` (String, opcional): Nuevo título corregido.
  - `descripcion` (String, opcional): Nueva descripción explicativa.
  - `file` (File, opcional): Nuevo archivo sustituto.
  - `notificarEmail` (Boolean, opcional, por defecto `false`): Si se activa, notifica a los revisores.
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` actualizado con `estado: "PENDIENTE_REVISION"`.
- Conserva la etapa y el deadline; no reinicia aprobaciones previas. Retorna versión de solicitud actualizada y notifica al responsable autorizado de ese paso.
- **Errores**:
  - `400 Bad Request`: Si se envía `titulo` vacío o el archivo no cumple formato/tamaño.
  - `403 Forbidden`: Si un usuario distinto al emisor intenta reenviar.
  - `409 Conflict`: Si la solicitud no está en `CORRECCION_REQUERIDA`.

---

### 2.10 Consultar Historial de Transiciones (Línea de Tiempo)
Devuelve todas las transiciones ordenadas cronológicamente (`createdAt` e ID ascendentes). Es inmutable. `etapaOrigen` y `etapaDestino` describen id/orden/nombre; eventos antiguos mantienen null, sin reconstrucción retrospectiva.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/historial`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "estadoOrigen": "INICIAL",
      "estadoDestino": "PENDIENTE_REVISION",
      "accion": "CREAR",
      "usuarioEmail": "emisor@capstone.local",
      "usuarioNombre": "Juan Emisor",
      "comentario": "Registro inicial de solicitud y carga de documento",
      "createdAt": "2026-09-15T17:12:24.615Z"
    },
    {
      "id": 2,
      "estadoOrigen": "PENDIENTE_REVISION",
      "estadoDestino": "APROBADO",
      "accion": "APROBAR",
      "usuarioEmail": "revisor@capstone.local",
      "usuarioNombre": "Ana Revisora",
      "comentario": "Solicitud aprobada por Ana Revisora",
      "createdAt": "2026-09-15T17:15:00.000Z"
    }
  ]
  ```

---

### 2.11 Consultar Observaciones de la Solicitud
Devuelve las notas u observaciones formuladas por los revisores en orden cronológico, con autor, fecha y estado de subsanación.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/observaciones`
- **Seguridad**: Autenticado; solo el emisor de la solicitud o un administrador puede consultar estas observaciones.
- **Error**: `403 Forbidden` si otro usuario intenta consultar las observaciones.
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "contenido": "Falta firma en página 3",
      "resuelta": false,
      "usuarioEmail": "revisor@capstone.local",
      "usuarioNombre": "Ana Revisora",
      "createdAt": "2026-09-15T17:13:15.104Z"
    }
  ]
  ```

---

### 2.12 Descargar Documento Vigente
Descarga intermediada por el backend Spring Boot (`sistema-principal`) desde el bucket privado de MinIO S3 hacia el cliente. No se permite descarga directa de usuarios al bucket S3 para asegurar el control estricto de autorización mediante token JWT.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/documento/descargar`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Respuesta (200 OK)**:
  - Header: `Content-Disposition: attachment; filename="<nombre_archivo>"`
  - Content-Type: el tipo MIME almacenado para el archivo, por ejemplo `application/pdf`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, `application/vnd.ms-excel`, `application/xml` o `text/plain`.
  - Body: Binario del archivo transmitido en streaming desde el backend.
- **Errores**:
  - `403 Forbidden`: `SOLICITUD_ACCESO_DENEGADO` si el usuario no pertenece al área autorizada ni es revisor asignado.
  - `404 Not Found`:
    - Solicitud no encontrada: ProblemDetail con `title: "Solicitud No Encontrada"`.
    - Archivo no disponible en almacenamiento: RFC 7807 `ProblemDetail` con `title: "Documento No Disponible"`, `code: "DOCUMENTO_NO_DISPONIBLE"`, `detail: "El archivo no está disponible."`, `type: "https://capstone.local/errors/documento-no-disponible"`.

---

### 2.13 Intermediario de Archivos en MinIO Storage (`/api/doc`)

Endpoints utilitarios para carga y descarga intermediada bajo control de seguridad con JWT (el bucket MinIO tiene acceso público denegado / política privada `none`):
- `POST /api/doc/upload`: Requiere `Authorization: Bearer <JWT>` con rol **ADMIN** (`403` en otro caso). Sube archivo a MinIO retornando la clave interna del objeto.
- `GET /api/doc/download/{filename}`: Requiere `Authorization: Bearer <JWT>`. Transmite el binario desde MinIO en streaming hacia el cliente. Denegado a usuarios anónimos (`401 Unauthorized`). Si el archivo no existe o no está disponible en MinIO, responde con RFC 7807 `404 Not Found` (`title: "Documento No Disponible"`, `code: "DOCUMENTO_NO_DISPONIBLE"`, `detail: "El archivo no está disponible."`).

### 3.1 Listar Mis Notificaciones
- **Método**: `GET`
- **Ruta**: `/api/notificaciones`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 5,
      "titulo": "Solicitud Aprobada",
      "mensaje": "Tu solicitud 'Contrato Q3' ha sido aprobada por Admin Capstone.",
      "tipo": "APROBACION",
      "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
      "leida": false,
      "createdEn": "2026-09-15T17:12:25.006Z",
      "leidaEn": null
    }
  ]
  ```

---

### 3.2 Conteo de Notificaciones No Leídas
Ideal para badges o indicadores numéricos en la campana de la barra superior.

- **Método**: `GET`
- **Ruta**: `/api/notificaciones/no-leidas/count`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  {
    "count": 3
  }
  ```

---

### 3.3 Marcar Notificación como Leída
- **Método**: `PATCH`
- **Ruta**: `/api/notificaciones/{id}/leer`
- **Seguridad**: Autenticado (solo el destinatario)
- **Respuesta (200 OK)**: Notificación actualizada con `leida: true` y `leidaEn: "<timestamp>"`.
- **Errores**: `403 Forbidden` si la notificación pertenece a otro usuario.

---

### 3.4 Marcar Todas como Leídas
- **Método y ruta**: `PATCH /api/notificaciones/marcar-todas-leidas` (autenticado; afecta solo al usuario actual). Usado por `NotificationBell.jsx`.

---

## 4. Módulo de Administración de Usuarios (`/api/users`)

- **Seguridad**: Exclusivo para administradores (`ROLE_ADMIN`).

### 4.1 Listar Usuarios
- **Método**: `GET`
- **Ruta**: `/api/users`
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": "3194f022-344b-473c-baee-85cc2d6155c7",
      "email": "admin@capstone.local",
      "firstName": "Admin",
      "lastName": "Capstone",
      "roles": ["ADMIN"],
      "enabled": true,
      "temporarilyLocked": false,
      "createdAt": "2026-09-14T00:00:00Z",
      "updatedAt": "2026-09-14T00:00:00Z"
    }
  ]
  ```

### 4.2 Crear Usuario
- **Método**: `POST`
- **Ruta**: `/api/users`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "email": "nuevo@capstone.local",
    "firstName": "Pedro",
    "lastName": "Pascal",
    "password": "Password123!",
    "roles": ["APPROVER"]
  }
  ```
- **Respuesta (201 Created)**: `UserResponse`.

### 4.3 Actualizar Usuario / Restablecer Contraseña
- **Método**: `PUT`
- **Ruta**: `/api/users/{id}`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "firstName": "Pedro",
    "lastName": "Pascal Modificado",
    "roles": ["APPROVER"],
    "newPassword": "NuevaPassword123!",
    "requirePasswordChange": true
  }
  ```
- **Respuesta (200 OK)**: `UserResponse`.

### 4.4 Activar / Desactivar Estado
- **Método**: `PATCH`
- **Ruta**: `/api/users/{id}/status`
- **Request Body**: `{"enabled": false}`
- **Respuesta (200 OK)**: `UserResponse`.

### 4.5 Eliminar Usuario
- **Método**: `DELETE`
- **Ruta**: `/api/users/{id}`
- **Respuesta (204 No Content)**.

---

## 5. Módulo de Auditoría (`/api/audit`)

- `POST /api/audit/login` y `POST /api/audit/logout`: cualquier usuario autenticado; registran el evento LOGIN/LOGOUT (usados por el frontend).
- **Seguridad de lectura**: Exclusivo para administradores (`ROLE_ADMIN`).
- **Endpoint**: `GET /api/audit/events?limit=50` (la ruta `/recent` NO existe)
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 384,
      "email": "admin@capstone.local",
      "tipo": "RECHAZAR_SOLICITUD",
      "ipAddress": "127.0.0.1",
      "detalle": "Rechazo de solicitud 'Factura Mayo 2026'. Motivo: [PROTECTED]",
      "createdAt": "2026-09-15T17:13:15.442Z"
    }
  ]
  ```

---

## 6. Módulo de Análisis Documental con IA (`/api/solicitudes/{id}/ai-analysis`)

Permite a los emisores, revisores y administradores solicitar y consultar auditorías inteligentes sobre el documento vigente de una solicitud mediante OpenRouter LLM y RabbitMQ.

### 6.1 Solicitar Análisis con IA
- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/ai-analysis`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Query Params**:
  - `force` (opcional, boolean, default `false`): Si es `true`, fuerza un nuevo análisis ignorando la caché.
- **Request Body** (opcional, `application/json`):
  ```json
  {
    "prompt": "Verificar que el documento incluya cláusulas de confidencialidad y vigencia de al menos 12 meses."
  }
  ```
- **Comportamiento de Caché Inteligente**:
  - Si ya existe un análisis `COMPLETADO` para el mismo documento y el mismo prompt (y `force=false`), retorna **HTTP 200 OK** con `cached: true`.
  - Si el documento cambió, el prompt cambió, o no existe análisis previo, crea una tarea `PENDIENTE`, la encola en RabbitMQ y retorna **HTTP 202 Accepted** con `cached: false`.
- **Respuesta (200 OK - Caché o ya completado)**:
  ```json
  {
    "id": "e4b1b369-026c-486a-bfe0-55e11d0a5f91",
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "b1234567-89ab-cdef-0123-456789abcdef",
    "estado": "COMPLETADO",
    "puntaje": 88,
    "valido": true,
    "observaciones": "El documento cumple con los estándares generales de formato y coherencia respecto a la solicitud.",
    "recomendaciones": [
      "Validar consistencia de fechas en las cláusulas principales",
      "Confirmar la firma digital de los intervinientes"
    ],
    "modeloUsado": "meta-llama/llama-3.3-70b-instruct:free",
    "promptUtilizado": "Verificar que el documento incluya...",
    "cached": true,
    "createdAt": "2026-09-17T21:00:00Z",
    "completedAt": "2026-09-17T21:00:02Z"
  }
  ```
- **Respuesta (202 Accepted - Encolado en proceso)**:
  ```json
  {
    "id": "e4b1b369-026c-486a-bfe0-55e11d0a5f91",
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "b1234567-89ab-cdef-0123-456789abcdef",
    "estado": "PENDIENTE",
    "puntaje": null,
    "valido": null,
    "observaciones": null,
    "recomendaciones": [],
    "modeloUsado": null,
    "promptUtilizado": "Verificar que el documento...",
    "cached": false,
    "createdAt": "2026-09-17T21:05:00Z",
    "completedAt": null
  }
  ```

---

### 6.2 Consultar Último Análisis con IA
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/ai-analysis`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Respuesta (200 OK)**: Mismo esquema `AiAnalysisResponse`.
- **Respuesta (404 Not Found)**: Si la solicitud no tiene análisis realizados aún (`RFC 7807 ProblemDetail`).

---

### 6.3 Eventos Asíncronos RabbitMQ (Exchange: `capstone.exchange`)
- **Tópico de Tareas**: `ai.analysis`
  - Payload emitido por `sistema-principal` y consumido por `service-ia` (`ai.queue`):
    `{ analysisId, solicitudId, storageKey, nombreArchivo, contentType, titulo, descripcion, prompt }`
- **Tópico de Resultados**: `ai.results`
  - Payload emitido por `service-ia` y consumido por `sistema-principal` (`ai.results.queue`):
    `{ analysisId, solicitudId, status, resultado, modeloUsado, timestamp }`

---

## 7. Áreas Corporativas (`/api/areas`) — Sprint 2

**Estado: backend implementado y revisado por HTTP; interfaz, E2E y validación visual pendientes.** Tarjeta [[BACKEND] APIs de gestión y ciclo de vida de áreas corporativas](https://trello.com/c/zWa740Ry). Modelo, migración y reglas: [diseño de áreas](./design/areas-corporativas-sprint-2.md). Evidencia de la revisión solicitada: [94 comprobaciones correctas](./verification/areas-api-2026-09-30.md).

### 7.1 Convenciones y DTO de respuesta

Los cuatro endpoints requieren JWT válido, cuenta local activa y rol `ADMIN`. Un `APPROVER` sin `ADMIN` recibe 403. Se conserva la seguridad actual del sistema; no se introduce otro rol para esta tarjeta. Las peticiones y respuestas usan JSON; los errores de negocio usan `application/problem+json`.

`AreaResponse` es un DTO plano, sin serializar entidades ni colecciones recursivas:

```json
{
  "id": 5,
  "nombre": "Área de ejemplo",
  "descripcion": "Descripción de ejemplo",
  "activo": true,
  "areaPadreId": null,
  "areaPadreNombre": null,
  "createdAt": "2026-09-30T22:00:00Z",
  "updatedAt": "2026-09-30T22:00:00Z",
  "version": 0
}
```

Los ejemplos son ficticios, no representan el organigrama oficial. `id` y `areaPadreId` son números enteros positivos, no UUID. Si hay padre, `areaPadreNombre` contiene su nombre actual. Las fechas son ISO 8601 en UTC y proceden del servidor. `version` es un entero no negativo utilizado para detectar modificaciones concurrentes. ID, fechas, nombre del padre y versión inicial son de solo lectura; el estado inicial siempre es activo.

El nombre se guarda sin espacios exteriores U+0020, con 1–100 caracteres Unicode y sin caracteres de control. La unicidad global usa `lower(btrim(nombre))`; también incluye áreas inactivas. La descripción admite hasta 1000 caracteres Unicode y texto multilínea; ausencia, NULL o texto vacío normalizado se representan como NULL. El carácter nulo U+0000 no está permitido en descripción ni búsqueda, porque PostgreSQL no admite ese carácter en texto. Acentos y espacios internos del nombre son significativos.

### 7.2 Crear área

- **Método y ruta:** `POST /api/areas`.
- **Cuerpo:** nombre obligatorio, descripción y padre opcionales. Un padre no nulo debe existir, estar activo y tener sus ancestros activos.

```json
{
  "nombre": "Área de ejemplo",
  "descripcion": "Descripción de ejemplo",
  "areaPadreId": null
}
```

- **201 Created:** `AreaResponse` con ID generado, `activo = true`, `version = 0` y ambas fechas iguales.
- **Errores específicos:** 400 por datos inválidos; 404 por padre inexistente; 409 por nombre duplicado o padre/ancestro inactivo.

### 7.3 Listar áreas

- **Método y ruta:** `GET /api/areas`.
- **Parámetros opcionales:** `page` (entero ≥ 0, default 0), `size` (1–100, default 20), `activo` (boolean; omitido incluye ambos estados), `q` (texto de hasta 100 caracteres; búsqueda literal por parte del nombre, sin distinguir mayúsculas; blanco se interpreta sin filtro).
- **Orden fijo:** `lower(nombre)` ascendente y, para desempatar, `id` ascendente. `%` y `_` en `q` se tratan como texto literal, no comodines enviados por el cliente.
- **200 OK:** `PaginaAreasResponse`; la estructura de paginación sigue la respuesta estable existente de solicitudes.

```json
{
  "contenido": [
    {
      "id": 5,
      "nombre": "Área de ejemplo",
      "descripcion": "Descripción de ejemplo",
      "activo": true,
      "areaPadreId": null,
      "areaPadreNombre": null,
      "createdAt": "2026-09-30T22:00:00Z",
      "updatedAt": "2026-09-30T22:00:00Z",
      "version": 0
    }
  ],
  "pagina": 0,
  "tamanio": 20,
  "totalElementos": 1,
  "totalPaginas": 1,
  "primera": true,
  "ultima": true
}
```

Un catálogo vacío devuelve `contenido: []`, `totalElementos: 0`, `totalPaginas: 0` y `primera: true`, `ultima: true` para la página 0. Una página posterior al final devuelve contenido vacío y los totales reales; no es 404. Los filtros se aplican antes del conteo. Parámetros mal formados o fuera del rango devuelven 400. Para construir un selector completo hay que consultar las páginas necesarias; una primera página no representa todo el organigrama.

### 7.4 Editar información y padre

- **Método y ruta:** `PUT /api/areas/{id}`.
- **Cuerpo:** reemplaza los campos editables; `nombre` y `version` son obligatorios. Descripción y padre omitidos o NULL se eliminan. La interfaz debe enviar los valores actuales que quiera conservar.

```json
{
  "nombre": "Área de ejemplo actualizada",
  "descripcion": null,
  "areaPadreId": null,
  "version": 0
}
```

- **200 OK:** `AreaResponse`; en una modificación efectiva incrementa la versión y actualiza `updatedAt`, conservando ID, `createdAt` y estado.
- Se puede editar un área inactiva. El movimiento requiere un padre activo; conservar su padre actual inactivo es válido solo para un área también inactiva. Ningún movimiento puede formar un ciclo.
- **Errores específicos:** 400 por campos o jerarquía inválidos; 404 por área o padre inexistente; 409 por nombre duplicado, padre/ancestro inactivo o versión desactualizada.
- Enviar los mismos valores normalizados con la versión vigente devuelve 200 con fechas y versión sin cambio.

### 7.5 Activar o desactivar

- **Método y ruta:** `PATCH /api/areas/{id}/status`.
- **Cuerpo:** `activo` boolean obligatorio y `version` no negativa obligatoria.

```json
{
  "activo": false,
  "version": 1
}
```

- **200 OK:** `AreaResponse` con el estado solicitado. Un cambio efectivo incrementa la versión y actualiza `updatedAt`; repetir el estado actual con la versión vigente no modifica datos ni crea otra auditoría.
- La desactivación exige que no haya hijas activas, usuarios activos vinculados ni asignaciones a esa área en flujos activos. Ante uso, 409 con cantidades; no modifica dependencias.
- La activación exige que todos los ancestros estén activos. Las hijas y cuentas no se reactivan automáticamente.
- **Errores específicos:** 400 por cuerpo/ID inválidos; 404 por área inexistente; 409 por área en uso, ancestro inactivo o versión desactualizada.
- La baja es lógica; no se ofrece `DELETE /api/areas/{id}` en esta historia.

### 7.6 Errores y comportamiento de conflictos

| HTTP | `codigo` de negocio | Situación y dato adicional |
| --- | --- | --- |
| 400 | `AREA_DATOS_INVALIDOS` | Campos, cuerpo o parámetros inválidos; `invalidFields` cuando corresponda |
| 400 | `AREA_JERARQUIA_INVALIDA` | Padre igual al área o movimiento cíclico; `invalidFields.areaPadreId` |
| 401 | Según seguridad existente | Token ausente/inválido o cuenta local no activa |
| 403 | Según seguridad existente | Usuario autenticado sin ADMIN |
| 404 | `AREA_NO_ENCONTRADA` | ID del recurso inexistente |
| 404 | `AREA_PADRE_NO_ENCONTRADA` | Padre indicado inexistente |
| 409 | `AREA_NOMBRE_DUPLICADO` | Otra área tiene el nombre normalizado; `invalidFields.nombre` |
| 409 | `AREA_PADRE_INACTIVA` | Padre o ancestro inactivo |
| 409 | `AREA_EN_USO` | Desactivación impedida; `dependencias` con cantidades |
| 409 | `AREA_MODIFICADA` | Versión enviada distinta de la actual; `versionActual` |

La forma de los 401/403 sigue la cadena de seguridad actual: esta tarjeta no promete que los errores previos al controlador tengan un formato distinto. El advice acotado a áreas devuelve `AREA_DATOS_INVALIDOS` e `invalidFields` para Bean Validation, sin modificar el manejo global de usuarios y flujos.

Ejemplo de duplicado:

```json
{
  "type": "about:blank",
  "title": "Nombre de área duplicado",
  "status": 409,
  "detail": "Ya existe un área con ese nombre.",
  "codigo": "AREA_NOMBRE_DUPLICADO",
  "instance": "/api/areas",
  "invalidFields": { "nombre": "El nombre ya está registrado." },
  "timestamp": "2026-09-30T22:01:00Z"
}
```

Ejemplo de área en uso:

```json
{
  "type": "about:blank",
  "title": "Área en uso",
  "status": 409,
  "detail": "Resuelve las dependencias del área antes de desactivarla.",
  "codigo": "AREA_EN_USO",
  "instance": "/api/areas/5/status",
  "dependencias": {
    "hijasActivas": 0,
    "usuariosActivos": 2,
    "asignacionesEnFlujosActivos": 1
  },
  "timestamp": "2026-09-30T22:02:00Z"
}
```

Para comprobar y escribir un cambio se usa una sola transacción. El modelo incluye versión e índice único; la coordinación de cambios jerárquicos y nuevas referencias se detalla en [el diseño](./design/areas-corporativas-sprint-2.md#5-transacciones-concurrencia-y-auditoría). Ante un 409 la interfaz conserva los datos editados, explica el conflicto y permite recargar; no reintenta una escritura con una nueva versión sin intervención del administrador.

### 7.7 Consumidor frontend de áreas

`AreaManagementPage` consume estos contratos mediante `frontend/src/services/areas.js` y el cliente Axios/JWT existente. La ruta `/configurar-areas` y su enlace en Configuración se habilitan para ADMIN. La API mantiene la autorización definitiva.

Los campos `areaPadreId` y `areaPadreNombre` se presentan al usuario como **Área superior**. La opción sin asignación se denomina **Sin dependencia jerárquica** y la tabla muestra **Nivel principal**. Los selectores de área superior y estado utilizan el componente compartido `DropdownSelect`, con la apariencia de Revisar documento.

- La tabla solicita `size=10` y aplica búsqueda, estado y paginación en el servidor. El pie muestra el rango de resultados, número de página y controles Anterior/Siguiente. Cada fila usa `areaPadreNombre` de la respuesta; no consulta el padre por separado.
- Alta/edición envían nombre, descripción y padre explícitos. PUT conserva la versión original; PATCH envía el estado solicitado y la versión del área seleccionada. Desactivación y reactivación requieren confirmación.
- El selector recorre todas las páginas del catálogo, incluyendo inactivas para identificar descendientes. Ofrece padres con cadena activa y excluye la propia área, sus descendientes y ciclos. Un área inactiva puede conservar el padre actual inactivo sin borrarlo al editar.
- La validación de texto replica los límites Unicode y el recorte exclusivo de U+0020. Duplicados y jerarquía se resuelven definitivamente en el servidor; `invalidFields` se muestran junto al campo y `dependencias` en la confirmación.
- Ante `AREA_MODIFICADA`, los valores se conservan y guardar queda bloqueado hasta la recarga explícita que descarta los cambios del formulario. Ante respuesta perdida o 5xx, se solicita recargar antes de otra escritura. No hay reintentos automáticos ni actualización silenciosa de la versión.

La interfaz está implementada; su compilación no constituye aprobación funcional o E2E. Las pruebas funcionales y la validación visual permanecen pendientes.

---

## 8. Nuevos Contratos de API REST - Sprint 2

### 8.1 Gestión y Configuración de Flujos Corporativos (`/api/flujos`)

**Estado:** backend implementado el 03-10-2026. Ambas rutas comparten controlador, DTOs, persistencia y autorización. Backend y frontend compatibles activados conjuntamente en Docker local. Las escrituras exigen versiones; la validación funcional/E2E y visual continúa pendiente. [Modelo de estados y etapas](design/flujos-configurables-por-area-sprint-2.md).

#### 8.1.1 Crear Flujo

- **POST** `/api/flujos` o `/api/workflows`.
- **Seguridad:** cuenta local activa con `FLUJO_GESTIONAR`; ADMIN o administración autorizada del área. Un destino general (`areaId=null`) exige ADMIN.
- **Body:** `{"nombre":"Revisión documental de área","descripcion":"Ejemplo ilustrativo","areaId":1}`.
- Nombre obligatorio tras trim, 1–150 caracteres sin controles; descripción opcional hasta 2000; ID de área Long positivo y activa. Unicidad global mediante `lower(btrim(nombre))` en servicio y PostgreSQL. Nombre Revisión Simple reservado.
- **201 Created:** `FlujoResponse`, `activo=false`, `completo=false`, `etapas=[]`, `version=0`; `Location: /api/flujos/{id}` como ruta canónica.
- `completo`, estado, versión e IDs no son campos editables del alta. Guardar metadatos crea una definición inactiva; configurar etapas no la activa automáticamente.

#### 8.1.2 Listar Flujos

- **GET** `/api/flujos` o `/api/workflows`.
- Filtros opcionales: `areaId` Long positivo, `activo` Boolean, `completo` Boolean.
- **200 OK:** lista plana ordenada por nombre e ID. Incluye definiciones gestionables o seleccionables por el actor. Los emisores solo reciben flujos activos, consistentes y de área autorizada.
- `completo` se calcula con las referencias y capacidades RBAC actuales, también al filtrar. El flujo base tiene completitud válida únicamente si conserva ID 1, nombre exacto, área general y una etapa REVISION sin responsable explícito.

#### 8.1.3 Obtener Detalle de Flujo con Etapas

- **GET** `/api/flujos/{id}` o `/api/workflows/{id}`; exige gestionar o poder emitir usando el flujo.
- **200 OK:**

```json
{
  "id": 2,
  "nombre": "Revisión documental de área",
  "descripcion": "Ejemplo ilustrativo",
  "areaId": 1,
  "areaNombre": "Área de ejemplo",
  "activo": false,
  "completo": true,
  "etapas": [
    {
      "id": 2,
      "orden": 1,
      "nombre": "Revisión Técnica",
      "revisorId": "00000000-0000-4000-8000-000000000001",
      "revisorNombre": "Responsable de ejemplo",
      "revisorEmail": "responsable@example.com",
      "tipoAccion": "REVISION",
      "tipoAsignacion": "USUARIO",
      "rolRevisorId": null,
      "rolRevisorNombre": null,
      "responsableDisponible": true,
      "revisoresDisponibles": 1
    }
  ],
  "createdAt": "2026-10-03T12:00:00Z",
  "updatedAt": "2026-10-03T12:01:00Z",
  "version": 1,
  "estructuraEditable": true
}
```

`estructuraEditable` es una capacidad informativa calculada por el backend: exige administración del flujo y ausencia de solicitudes vinculadas; siempre es false en el flujo base. Permite presentar la secuencia y el área en modo de consulta sin anticipar una escritura rechazada. El servidor vuelve a comprobar las reglas en cada mutación.

IDs de flujo/etapa/área: Long; responsable: UUID; fechas: UTC. Etapas ordenadas por `orden`. Quien solo emite recibe identidad/nombre/email del revisor, rolRevisorId/rolRevisorNombre y revisoresDisponibles a null. La cantidad se obtiene de `etapas.length`; no existen `codigo`, `totalEtapas`, `rolRevisor`, `diasPlazo` ni `requiereFirma` en este DTO.

#### 8.1.4 Actualizar Metadatos del Flujo

- **PUT** `/{id}` en cualquiera de las dos rutas.
- Body: `{"nombre":"Revisión documental de área","descripcion":"Texto","areaId":1,"activo":null,"version":1}`.
- `nombre` y `version` no negativa obligatorios. Omitir descripción/área las elimina; enviar `activo=null` conserva el estado. Gestionar origen y destino; área activa al trasladar. Un flujo utilizado no puede trasladarse. El flujo base conserva identidad y estructura.
- **200 OK:** `FlujoResponse` con versión actual. `activo=true` usa las mismas comprobaciones de activación que PATCH; ninguna escritura deja incompleto un flujo activo.

#### 8.1.5 Configurar Etapas y Revisores Asignados

- **PUT** `/{id}/etapas` en ambas rutas; `FLUJO_GESTIONAR` sobre el flujo.
- Body:

```json
{
  "version": 1,
  "etapas": [
    {"nombre":"Revisión Técnica","orden":1,"tipoAccion":"REVISION","revisorId":"00000000-0000-4000-8000-000000000001"},
    {"nombre":"Aprobación Financiera","orden":2,"tipoAccion":"REVISION","revisorId":"00000000-0000-4000-8000-000000000002"}
  ]
}
```

- Orden exacto 1..N, sin saltos ni duplicados, mínimo una etapa. Nombres 1–150 tras trim, sin controles. El servidor admite únicamente REVISION; omitir `tipoAccion` lo interpreta como REVISION.
- Responsable UUID activo y elegible bajo permisos locales de consulta, revisión y decisión; puede pertenecer a otra área. No se conceden permisos a partir del formulario.
- Desde HU-S2-06, guardar etapas exige un responsable resoluble por usuario o rol departamental en cada paso. Ausente/no disponible: 422 FLUJO_ETAPA_HUERFANA, también en borradores. Lista vacía: 400. Omitir tipoAsignacion conserva USUARIO; ROL_DEPARTAMENTAL requiere rolRevisorId y revisorId=null (sección 8.1.10).
- **200 OK:** `FlujoResponse`. Sustitución atómica DELETE/flush/INSERT, conservando el índice de orden. Antes del primer uso se permite reordenar. Con cualquier solicitud vinculada se rechaza reemplazar etapas, incluso si las solicitudes terminaron. El flujo base no admite reemplazo. No se activa automáticamente.

#### 8.1.6 Eliminar o Desactivar

- **DELETE** `/{id}?version=2` en ambas rutas; versión obligatoria y gestión autorizada.
- Sin solicitudes: elimina definición y etapas. Con solicitudes: desactiva y conserva referencias e historial. Flujo base: 409.
- **204 No Content.**

#### 8.1.7 Errores y Concurrencia

- 400: cuerpo inválido, versión ausente/negativa, nombre u orden inválido, tipo desconocido, referencias inválidas.
- 404: definición inexistente o sin visibilidad. 403: acción/área no autorizada.
- 409 con propiedad `codigo`: `FLUJO_VERSION_CONFLICTO`, `SOLICITUD_VERSION_CONFLICTO`, `FLUJO_INCOMPLETO`, `FLUJO_INACTIVO`, `FLUJO_CATALOGO_INCONSISTENTE`, `FLUJO_BASE_PROTEGIDO`, `RBAC_DEPENDENCIA_REVISION`.
- 422 `codigo=FLUJO_ETAPA_HUERFANA`: responsable ausente, inactivo, sin capacidades o sin candidatos autorizados en el rol/solicitud.
- Nombre duplicado: 409 `FlujoConflictException`. Estado documental inválido/terminal: 409 `InvalidTransitionException`. El guarda optimista residual devuelve 409 con `code=VERSION_CONFLICTO`.
- Las escrituras toman locks en orden catálogo de áreas → control RBAC → definición → solicitud. Configuración y primera emisión comparten lock de definición. `@Version` y versión del cliente impiden aceptar dos decisiones de la misma revisión, incluso con un mismo responsable en etapas consecutivas. Todo fallo revierte datos, evento y notificaciones locales. Recargar ante conflicto; no reintentar automáticamente con otra versión.

#### 8.1.8 Activación y Ejecución Secuencial

- **PATCH** `/api/flujos/{id}/status` o `/api/workflows/{id}/status`.
- Body: `{"activo":true,"version":2}`; ambos campos obligatorios. **200 OK:** `FlujoResponse`.
- Activar comprueba área activa, mínimo una etapa, orden 1..N, nombres, tipo y responsables activos con capacidades vigentes. Desactivar bloquea nuevas emisiones y permite continuar solicitudes existentes.
- Crear solicitud selecciona exclusivamente el flujo indicado, o el catálogo base exacto si se omite ID. No selecciona otra definición ni crea una etapa de respaldo. La emisión valida todas las responsabilidades contra el emisor concreto, incluidas exclusiones de superior/autorrevisión y excepción ADMIN. Una responsabilidad imposible responde 422 FLUJO_ETAPA_HUERFANA y revierte el registro.
- `SolicitudResponse` agrega `version` y `etapaActual:{id,orden,nombre}`. La versión de solicitud es independiente de `documentoVigente.version` y de la versión del flujo. GET detalle antes de decidir/reenviar proporciona la versión observada.
- POST `/api/solicitudes/{id}/aprobar`: body `{"version":0,"notificarEmail":false}`. Si existe otra etapa, conserva PENDIENTE_REVISION y avanza a ella; solo la última cierra APROBADO. Cada aprobación registra etapa origen/destino y dentroSla.
- POST `/rechazar` y `/pedir-correccion`: conservan motivo/observación y notificarEmail; agregan `version` obligatoria. Rechazo termina en el mismo paso. Corrección conserva el paso actual.
- PUT `/reenviar`: multipart agrega `version` obligatoria. Retorna a revisión en el mismo paso, preserva aprobaciones anteriores y deadline. Archivo nuevo incrementa únicamente la versión documental correspondiente.
- Historial agrega `etapaOrigen` y `etapaDestino` con `{id,orden,nombre}`; eventos legacy mantienen null. Orden estable por createdAt e ID. No se reabren solicitudes terminales antiguas ni se reconstruyen etapas sin evidencia.
- Nueva solicitud/reenvío/avance avisan al responsable autorizado de la etapa actual. La excepción base resuelve revisores autorizados de esa solicitud. Corrección/cierres avisan al emisor con acceso vigente. La aprobación intermedia no comunica un cierre al emisor. Correo RabbitMQ se publica tras commit; un fallo externo no revierte la decisión.

**Migración:** `flow-schema.sql` añade versiones iniciales 0, REVISION y referencias históricas nullable antes de Hibernate; `FlowSchemaInitializer` completa restricciones en instalaciones nuevas. Duplicados normalizados informan IDs y detienen la migración sin renombrar. `FlujoCatalogIntegrityInitializer` recalcula una vez la completitud y desactiva configuraciones legacy inválidas, conservando etapas, documentos, estados y deadlines. Frontend adaptado y desplegado junto al backend; la revisión funcional/E2E y visual permanece pendiente.

#### 8.1.9 Consumidor frontend

`FlowDefinitionsPanel` muestra flujos gestionables con búsqueda, área/estado y paginación local fija de 10 filas. Los nuevos flujos se crean como borradores inactivos. El diseñador agrega, elimina y ordena etapas REVISION con el selector compartido ReviewerSelector y catálogos autorizados por flujo de usuarios/roles; no permite guardar una secuencia vacía o sin responsables. Activación/desactivación y eliminación requieren confirmación con una versión leída recientemente. El flujo base conserva nombre/área/estructura; los flujos usados muestran la secuencia en consulta, permiten Cambiar responsable por etapa y conservan el área.

Metadatos, etapas, estado, DELETE, decisiones y reenvío transmiten la versión observada del recurso correcto. Un 409 o resultado de escritura no confirmado conserva el formulario y bloquea otra escritura hasta una recarga explícita. En configuración, cargar la versión vigente informa que descarta el borrador; en decisión/reenvío conserva el comentario o datos y archivo para revisión. La emisión consulta activo=true y completo=true, exige selección explícita y comprueba solicitudes registradas tras una respuesta incierta para evitar reenvíos duplicados.

Revisión y corrección muestran la etapa actual. El resultado real de aprobación distingue avance intermedio y cierre; Estado de solicitudes presenta etapas históricas cuando existen y conserva el orden estable fecha/ID. Los eventos legacy no reconstruyen etapas. SLA conserva sus operaciones y presentación en una pestaña independiente con permiso SLA_GESTIONAR. Compilación y disponibilidad no equivalen a aprobación funcional.

#### 8.1.10 Responsables por usuario o rol departamental (HU-S2-06)

**Estado:** diseño, backend y frontend implementados el 03-10-2026; compilación y arranque comprobados, aprobación funcional/E2E y visual pendientes. [Modelo de asignación](design/asignacion-revisores-no-orfandad-sprint-2.md).

- **PUT** `/api/workflows/{id}/steps/{stepId}/assignee`, alias `/api/flujos/{id}/etapas/{stepId}/responsable`. Los prefijos comparten ambas terminaciones.
- Seguridad: cuenta activa y FLUJO_GESTIONAR sobre el área de la definición. La etapa debe pertenecer al flujo; el flujo base no admite esta operación.
- Body por usuario: `{"version":2,"tipoAsignacion":"USUARIO","revisorId":"00000000-0000-4000-8000-000000000001","rolRevisorId":null}`.
- Body por rol: `{"version":2,"tipoAsignacion":"ROL_DEPARTAMENTAL","revisorId":null,"rolRevisorId":3}`.
- versión no negativa de la **definición** y tipo obligatorios. Referencias mutuamente excluyentes; rol positivo. Tipo/ref contradictorios o inexistentes: 400; responsable ausente/no resoluble: 422; sin autorización: 403; definición/etapa ajena inexistente: 404; versión anterior o base protegida: 409.
- **200 OK:** FlujoResponse con versión actual y etapa existente actualizada. Mantiene ID, orden y nombre de etapa; no usa el reemplazo estructural PUT etapas. Cambia responsables de solicitudes actuales/futuras, sin reabrir etapas aprobadas o terminales ni alterar documentos, estados o deadlines.
- USUARIO exige una cuenta activa con permisos efectivos de consulta/revisión/decisión. ROL_DEPARTAMENTAL exige rol activo y al menos un miembro efectivo elegible cuyo departamento activo coincide con el área del flujo. Se combinan permisos locales, rol, área y exclusiones jerárquicas; no se conceden capacidades desde la configuración.
- El rol representa un conjunto de responsables autorizados. Cualquiera puede atender la etapa; versión de solicitud impide dos decisiones sobre la misma revisión. Se conservan las capacidades administrativas globales existentes.
- Locks: áreas → control RBAC → definición → solicitudes abiertas afectadas en orden de ID. Se revalida la asignación para cada solicitud que aún debe pasar por la etapa. Incompatibilidad revierte toda la escritura.
- Las solicitudes en la etapa actual incrementan versión; futuras mantienen su versión hasta avanzar. Un cambio idéntico válido no incrementa versiones ni repite auditoría/notificaciones.
- Auditoría ASIGNAR_RESPONSABLE_ETAPA registra antes/después, etapa, referencias, versión y número de solicitudes actuales. Nuevos destinatarios de pendientes reciben notificación local y correo tras commit, sin crear una transición documental falsa. Correcciones notifican al reenviar. No se repite aviso a miembros que ya eran responsables.
- Guardar etapas y activar requieren disponibilidad; el motor comprueba responsabilidades contra el emisor concreto. Cambiar cuentas, roles/permisos, membresías, áreas o jefaturas no puede introducir etapas huérfanas en flujos activos ni en etapas actuales/futuras de solicitudes abiertas, incluso con flujo desactivado. Inconsistencias anteriores no impiden cambios ajenos o su reparación progresiva; nuevas dependencias responden 409 RBAC_DEPENDENCIA_REVISION.

**Catálogos:** GET `/api/flujos/{id}/assignee-options` y GET `/api/flujos/{id}/steps/{stepId}/assignee-options`, también bajo /api/workflows. Solo administradores autorizados del flujo; la variante de etapa filtra opciones incompatibles con solicitudes abiertas actuales/futuras. Devuelve:

```json
{
  "usuarios": [{"id":"00000000-0000-4000-8000-000000000001","nombre":"Responsable de ejemplo","email":"responsable@example.com","areaNombre":"Área de ejemplo"}],
  "roles": [{"id":3,"nombre":"Revisor","cantidadUsuarios":1,"usuarios":[{"id":"00000000-0000-4000-8000-000000000001","nombre":"Responsable de ejemplo","email":"responsable@example.com","areaNombre":"Área de ejemplo"}]}],
  "version":2
}
```

FlujoEtapaResponse agrega tipoAsignacion, rolRevisorId/nombre, responsableDisponible y revisoresDisponibles. Los emisores no reciben identidad de responsables, rol ni conteo de empleados. El flujo base conserva su excepción dinámica. SQL aditivo: tipo_asignacion USUARIO por defecto, rol_revisor_id nullable, FK restrictiva, índice y check de exclusión; etapas por usuario anteriores conservan su referencia.

**Interfaz:** ReviewerSelector reutiliza DropdownSelect/FormField/FeedbackMessage, con tipo y selección, área y candidatos de rol. Asignaciones vacías muestran rojo; actuales no disponibles, ámbar sin sustitución automática. Guardar/activar bloqueados ante incompletitud. En flujos usados, Cambiar responsable abre un formulario específico con versión del flujo y catálogo de etapa; conserva datos ante conflicto y exige recarga explícita. Un flujo general admite usuarios; el selector explica que el modo departamental requiere área. Tabla de 10 filas y diseño corporativo existentes.

---
### 8.2 Configuración de Plazos y SLA (`/api/sla`) — OBSOLETO

> [!] Diseño original (SLA por flujo/etapa, `/api/sla/flujo/{flujoId}`, `diasAlerta`, `activo`) **nunca se implementó**. El contrato vigente y verificado contra `SlaController` es la matriz por tipo de documento de §8.8. Plazo por defecto 5 días hábiles si ningún tipo coincide; el cálculo excluye sábados y domingos.

---

### 8.3 Búsqueda Multicriterio y Métricas de Solicitudes (`/api/solicitudes`)

#### 8.3.1 Búsqueda Multicriterio con Paginación
Filtra por estado, rango de fechas, texto (en título o descripción), correlativo y área. Aplica aislamiento departamental automáticamente según el rol y área del usuario que consulta.
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/buscar` (alias: `GET /api/solicitudes`), ej. `?estado=PENDIENTE_REVISION&q=factura&fechaDesde=2026-09-01T00:00:00Z&fechaHasta=2026-09-30T23:59:59Z&correlativo=FAC-001&solicitante=...&areaId=1&pagina=0&tamanio=10`
- **Parámetros reales**: `q`, `correlativo`, `solicitante`, `areaId`, `estado`, `fechaDesde`, `fechaHasta` (ISO DATE_TIME), `pagina` (base 0), `tamanio` (1-100, default 20). NO existen `texto`, `desde`, `hasta`, `page`, `size` aquí.
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: página con `contenido`, `pagina`, `tamanio`, `totalElementos`, `totalPaginas` (mismo sobre que §2.3), con `deadline` y trazabilidad de SLA por solicitud.

#### 8.3.2 Métricas de Solicitudes y SLA
Proporciona contadores de solicitudes pendientes, aprobadas, rechazadas, en corrección, vencidas, por vencer (alerta SLA), totales dentro/fuera de plazo y porcentaje global de cumplimiento de SLA en transiciones históricas (`dentro_sla = true`).
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/metricas`
- **Parámetros Query**:
  - `areaId` (Long, opcional): ID del área para filtrar métricas. Si se omite, calcula a nivel global (ADMIN) o según el alcance del usuario autenticado.
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: `MetricasResponse`
  ```json
  {
    "pendientes": 5,
    "aprobadas": 12,
    "rechazadas": 2,
    "enCorreccion": 1,
    "vencidas": 1,
    "porVencer": 2,
    "totalDentroSla": 16,
    "totalFueraSla": 4,
    "cumplimientoSlaPorcentaje": 80.0,
    "areaId": 1,
    "areaNombre": "Operaciones"
  }
  ```

#### 8.3.3 Métricas Agrupadas por Área Corporativa (`/api/solicitudes/metricas/por-area`)
Retorna el desglose de métricas y cumplimiento SLA por cada área corporativa autorizada para el usuario autenticado (todas las áreas activas ordenadas alfabéticamente si es `ADMIN`, o las áreas administradas/asignadas en caso contrario).
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/metricas/por-area`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: `List<MetricasResponse>`
  ```json
  [
    {
      "pendientes": 5,
      "aprobadas": 12,
      "rechazadas": 2,
      "enCorreccion": 1,
      "vencidas": 1,
      "porVencer": 2,
      "totalDentroSla": 16,
      "totalFueraSla": 4,
      "cumplimientoSlaPorcentaje": 80.0,
      "areaId": 1,
      "areaNombre": "Operaciones"
    }
  ]
  ```

---

### 8.4 Cambio de contraseña y política efectiva (HU-S2-13)

**Implementado** en `sistema-principal/users`, con [diseño de seguridad](./design/cambio-contrasena-sprint-2.md). Cualquier cuenta local activa puede cambiar exclusivamente sus propias credenciales, sin requerir permisos documentales ni rol ADMIN. La cuenta se resuelve desde el JWT validado (`sub` → `usuario.keycloak_id`).

#### GET `/api/auth/password-policy`

Lectura autenticada de la política efectiva del realm y el mínimo existente del sistema (8 caracteres). No usa valores supuestos si falla el proveedor. Respuesta `200 OK`:

```json
{
  "minLength": 8,
  "maxLength": 1024,
  "minUppercase": 0,
  "minLowercase": 0,
  "minDigits": 0,
  "minSpecial": 0,
  "notUsername": false,
  "notEmail": false,
  "username": "cuenta@example.com",
  "email": "cuenta@example.com",
  "additionalRules": false
}
```

Valores ilustrativos: las cantidades/restricciones se obtienen de la configuración vigente. Nombre/correo pertenecen exclusivamente a la cuenta autenticada y permiten presentar las reglas `notUsername`/`notEmail`. `additionalRules` identifica comprobaciones de Keycloak que no se replican en el navegador (historial, blacklist, regex o proveedores adicionales). Todas siguen evaluándose al escribir.

#### POST `/api/auth/change-password`

Ruta canónica de la tarjeta de diseño. Alias compatible: `POST /api/users/me/change-password`; aplica exactamente las mismas reglas y respuesta. Ambos exigen JSON autenticado:

```json
{
  "currentPassword": "ClaveActualDeEjemplo!",
  "newPassword": "NuevaPasswordSegura2026!",
  "confirmPassword": "NuevaPasswordSegura2026!"
}
```

Los tres campos son obligatorios, con máximo de 1024 caracteres. `newPassword` tiene mínimo de 8, debe cumplir la política vigente y ser diferente de `currentPassword`. La confirmación debe coincidir exactamente. Las contraseñas no se recortan ni normalizan. Una petición que solo incluye `newPassword` ya no es válida.

Antes de escribir, el backend verifica la contraseña actual con Direct Grant del cliente configurado, comprueba que el `sub` devuelto corresponde a la cuenta y elimina su sesión temporal. La SPA conserva Authorization Code + PKCE. La escritura se realiza mediante Admin API con credencial no temporal; no se cierra deliberadamente la sesión OIDC original.

Respuesta `200 OK` (no 204):

```json
{ "message": "Contraseña actualizada exitosamente" }
```

Error de contraseña actual `400 Bad Request`, `application/problem+json`:

```json
{
  "type": "about:blank",
  "title": "Cambio de contraseña",
  "status": 400,
  "detail": "La contraseña actual es incorrecta, inténtelo nuevamente.",
  "code": "CURRENT_PASSWORD_INVALID",
  "invalidFields": {
    "currentPassword": "La contraseña actual es incorrecta, inténtelo nuevamente."
  }
}
```

Los errores de campos incluyen `invalidFields` limitado a `currentPassword`, `newPassword` y `confirmPassword`. Confirmación distinta: “Las contraseñas no coinciden.”. Las respuestas nunca incluyen valores enviados o respuestas remotas.

| HTTP | Código / significado |
| --- | --- |
| 400 | `CURRENT_PASSWORD_INVALID`; clave anterior incorrecta. |
| 400 | `PASSWORD_VALIDATION_FAILED`; campos, coincidencia, diferencia o política inválidos. La validación Bean Validation conserva el formato general `invalidFields`. |
| 400 | `PASSWORD_POLICY_REJECTED`; rechazo definitivo de política al escribir en Keycloak. |
| 401 / 403 | Sin autenticación válida o cuenta local inactiva. |
| 409 | `PASSWORD_CHANGE_BUSY`; operación simultánea en la misma instancia. |
| 409 | `PASSWORD_CHANGE_REAUTH_REQUIRED`; OTP/acciones de identidad requieren gestión de cuenta del proveedor. |
| 429 | `PASSWORD_ACCOUNT_LOCKED`; bloqueo temporal por intentos fallidos, sin eludir fuerza bruta. |
| 503 | `IDENTITY_PROVIDER_UNAVAILABLE`; comprobación/configuración no disponible, sin iniciar escritura. |
| 502 | `PASSWORD_CHANGE_UNCERTAIN`; fallo durante la escritura y resultado no confirmado. No reintentar automáticamente. |

Las tres rutas incluyen `Cache-Control: no-store` y `X-Content-Type-Options: nosniff`, también en respuestas de seguridad. El evento local `CAMBIAR_PASSWORD` se intenta después de una actualización remota confirmada; un fallo de auditoría se registra en el log operativo y no afirma que se haya revertido una contraseña ya cambiada. No se mantiene una transacción PostgreSQL durante el intercambio con Keycloak.

---

### 8.5 Descarga Auditada con Aislamiento Departamental

Tanto la descarga de documento desde la solicitud como desde el repositorio central validan aislamiento departamental y registran el evento de auditoría `DESCARGAR_DOCUMENTO`.
- **Rutas**:
  - `GET /api/solicitudes/{id}/documento/descargar`
  - `GET /api/doc/download/{filename}` (repositorio MinIO; ver §2.13). No existe `/api/docs/{id}/download`.
- **Seguridad**: Autenticado. Acceso permitido a:
  - Admin Maestro (transversal).
  - Usuarios del área emisora o área del flujo.
  - Revisor asignado específicamente a una etapa de la solicitud (incluso de otra área).
- **Respuesta**: Stream de bytes con cabecera `Content-Disposition: attachment; filename="..."`.
- **Error (403 Forbidden)**: `SOLICITUD_ACCESO_DENEGADO` si el usuario no pertenece al área autorizada ni es revisor asignado.
- **Error (404 Not Found)**: `DOCUMENTO_NO_DISPONIBLE` con ProblemDetail RFC 7807 (`title: "Documento No Disponible"`, `detail: "El archivo no está disponible."`) si el archivo físico no se encuentra o no está disponible en MinIO.

---

### 8.6 Asignación de Administrador de Área

> [!] No existe `POST /api/areas/{id}/administrador` (auditoría 03-10-2026). El administrador se asigna con el campo opcional `administradorId` (**UUID** de usuario activo) en `POST /api/areas` y `PUT /api/areas/{id}` (ver §7). Respuesta: `AreaResponse` con `administradorId`.

---

### 8.7 Reglas de Negocio Corporativas Clarificadas (Sprint 2)

1. **Generación de Correlativo Oficial**:
   - Se mantiene como **secuencia continua perpetua** por prefijo documental (`CONT-001`, `MEMO-001`, `INFORME-001`, etc.), generada automáticamente en el momento de la aprobación final.
   - No tiene reseteo anual por año fiscal, garantizando trazabilidad unívoca y evitando colisiones de numeración entre períodos.

2. **Alcance de Visibilidad del Administrador de Área**:
   - **Área Propia**: Visualiza todas las solicitudes originadas por usuarios de su área o asignadas al flujo de su área.
   - **Participación Transversal**: Visualiza además las solicitudes externas provenientes de otras áreas siempre que **revisores pertenecientes a su área participen en alguna de las etapas** de aprobación.
   - **Aislamiento**: No tiene visibilidad sobre solicitudes de otras áreas donde no intervenga personal de su área.

3. **Gobernanza de Respuestas HTTP de Entrada (Input Integrity)**:
   - Prohibición estricta de emitir HTTP 500 (Internal Server Error) ante datos del usuario o del cliente HTTP.
   - JSON sintácticamente malformado (`HttpMessageNotReadableException`), tipos de parámetros erróneos (`MethodArgumentTypeMismatchException`), valores fuera de rango (`ConstraintViolationException`), o campos obligatorios ausentes devuelven HTTP 400 con `ProblemDetail` (RFC 7807).
   - Objetos o archivos inexistentes devuelven HTTP 404 (`ProblemDetail`).

---

### 8.8 Matriz de Plazos Contractuales SLA (`/api/sla`)

Administración de la matriz de plazos de respuesta en días hábiles por tipo de documento.

**Diseño HU-S2-08 (12-10-2026):** [Matriz SLA, calendario, estados y dependencias](design/matriz-sla-dias-habiles-sprint-2.md). El tipo es de negocio, independiente del formato del archivo. Cada solicitud captura una sola fecha límite para todo su recorrido; editar/eliminar reglas, avanzar de etapa, corregir o reenviar no recalcula esa fecha. El cálculo cuenta lunes a viernes en `America/Santiago`, conserva la hora local y no excluye feriados.

#### 8.8.1 Listar Reglas SLA
- **Método**: `GET`
- **Ruta**: `/api/sla`
- **Seguridad**: Exclusivo `ADMIN` (`@PreAuthorize("hasRole('ADMIN')")` en todos los métodos de `SlaController`, incluido GET; `GET /api/sla/{id}` también existe). La vista de revisión obtiene el plazo desde `deadline` de la solicitud, no desde este endpoint.
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "tipoDocumento": "Contrato",
      "plazoDias": 5,
      "createdAt": "2026-09-15T10:00:00Z",
      "updatedAt": "2026-09-15T10:00:00Z"
    }
  ]
  ```

#### 8.8.2 Crear Regla SLA
- **Método**: `POST`
- **Ruta**: `/api/sla`
- **Seguridad**: Exclusivo `ADMIN` (usuarios con solo `APPROVER` reciben `HTTP 403 Forbidden`)
- **Body**:
  ```json
  {
    "tipoDocumento": "Contrato de Servicios",
    "plazoDias": 4
  }
  ```
- **Validaciones**: `tipoDocumento` obligatorio (máx. 100 caracteres, `@NotBlank`), `plazoDias` número entero JSON `>= 1`. Decimales, cadenas numéricas, booleanos, null y números fuera de `int` devuelven 400; no se truncan. El DTO no fija otro tope, pero el servicio rechaza plazos cuya fecha resultante excede el rango PostgreSQL, sin iterar millones de días. La resolución prioriza coincidencia exacta del tipo enviado, incluida `General`; solo si no encuentra regla recurre al título (exacto, luego subcadena más larga), compatibilidad histórica y finalmente `General` o 5 días. Los empates usan nombre normalizado ascendente con `Locale.ROOT`. La unicidad por `lower(btrim(tipo_documento))` se protege también en PostgreSQL y devuelve 409 ante creaciones concurrentes equivalentes.
- **Respuesta (201 Created)**: Objeto `SlaConfigResponse` con cabecera `Location: /api/sla/{id}`.
- **Errores**: 400 por datos inválidos; 403 por rol no autorizado; 409 por tipo ya existente.

#### 8.8.3 Actualizar Plazo de Regla SLA
- **Método**: `PUT`
- **Ruta**: `/api/sla/{id}`
- **Seguridad**: Exclusivo `ADMIN` (`HTTP 403 Forbidden` si no es administrador)
- **Body**:
  ```json
  {
    "plazoDias": 3
  }
  ```
- **Respuesta (200 OK)**: Objeto `SlaConfigResponse` actualizado.
- **Validación**: Las mismas restricciones de entero positivo y fecha representable que POST. No cambia el tipo ni recalcula solicitudes existentes. El contrato conserva la política actual de última escritura persistida, sin versión optimista de configuración.

#### 8.8.4 Eliminar Regla SLA
- **Método**: `DELETE`
- **Ruta**: `/api/sla/{id}`
- **Seguridad**: Exclusivo `ADMIN` (`HTTP 403 Forbidden` si no es administrador)
- **Respuesta (204 No Content)**.

#### 8.8.5 Lectura de Alertas SLA

Las revisiones pendientes exponen `deadline` y `slaStatus`; el detalle integral expone `deadline`, `status`, `evaluadoEn` y `enRevision`. No requieren acceso administrativo a `/api/sla` ni modifican la solicitud al leer.

| Condición al evaluar | Código | Texto |
| --- | --- | --- |
| Sin deadline | `null` | Sin plazo registrado |
| Después del deadline | `VENCIDO` | Vencido |
| Antes o exactamente en el deadline, con menos de 24 horas corridas restantes | `POR_VENCER` | Por vencer |
| Exactamente 24 horas restantes o más | `NORMAL` | A tiempo |

`enRevision` es verdadero solo en `PENDIENTE_REVISION` con plazo. En corrección/terminal se conserva el dato histórico; corregir no pausa el reloj ni reenviar lo reinicia. El vencimiento no bloquea decisiones autorizadas ni cambia el estado documental automáticamente.

**Backend (12-10-2026):** reloj UTC inyectable con precisión de microsegundos para PostgreSQL; un instante de registro para solicitud/deadline/evento inicial y un instante por decisión para fecha de transición/cumplimiento. La bandeja evalúa todas las filas de una lectura con el mismo instante; el detalle expone ese instante mediante `evaluadoEn`. Calendario local Santiago con hora conservada incluso al cruzar un cambio de offset.

---

### 8.9 Historial de Transiciones de Solicitud (`GET /api/solicitudes/{id}/historial`)

Devuelve la secuencia cronológica de transiciones de estado por las que ha pasado la solicitud, incluyendo la auditoría de cumplimiento de SLA (`dentroSla`).

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/historial`
- **Seguridad**: Autenticado (sujeto a validación de acceso al documento)
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 101,
      "estadoOrigen": "INICIAL",
      "estadoDestino": "PENDIENTE_REVISION",
      "accion": "CREAR",
      "usuarioEmail": "admin@capstone.local",
      "usuarioNombre": "Admin Capstone",
      "comentario": "Creación inicial",
      "dentroSla": null,
      "createdAt": "2026-10-02T12:00:00Z"
    },
    {
      "id": 102,
      "estadoOrigen": "PENDIENTE_REVISION",
      "estadoDestino": "APROBADO",
      "accion": "APROBAR",
      "usuarioEmail": "revisor@capstone.local",
      "usuarioNombre": "Revisor Documental",
      "comentario": null,
      "dentroSla": true,
      "createdAt": "2026-10-02T12:15:00Z"
    }
  ]
  ```
- **Regla de Negocio `dentroSla` (CA 8.4)**:
  - En transiciones de decisión (`APROBAR`, `RECHAZAR`, `PEDIR_CORRECCION`), `dentroSla` es un `Boolean`:
    - `true`: si la decisión se emitió antes o exactamente en el `deadline` calculado.
    - `false`: si la decisión se emitió de forma extemporánea (posterior al `deadline`).
  - En la creación o reenvíos no resolutivos es `null`.
  - Si una solicitud histórica no tiene `deadline`, es `null` también en una decisión; no se inventa un plazo al leerla. El resultado de cada decisión se conserva, independientemente del estado SLA calculado en consultas posteriores.

---

### 8.10 Convenciones de Nombres de Parámetros de Paginación

Para evitar confusión en llamadas directas vía `window.api` o `curl`:
| Endpoint | Parámetro Página | Parámetro Tamaño | Default |
| :--- | :--- | :--- | :--- |
| `GET /api/solicitudes/pendientes-revision` | `pagina` (base 0) | `tamanio` (1-100) | `pagina=0`, `tamanio=20` |
| `GET /api/solicitudes/buscar` | `pagina` (base 0) | `tamanio` (1-100) | `pagina=0`, `tamanio=20` |
| `GET /api/areas` | `page` (base 0) | `size` (1-100) | `page=0`, `size=20` |
| `GET /api/users` | `page` (base 0) | `size` (1-100) | `page=0`, `size=20` |
| `GET /api/solicitudes/mis-solicitudes` | *(No paginado, retorna lista plana ordenada por fecha descendente)* | - | - |

---

### 8.11 Catálogo de Tipos de Documento (`/api/catalogos/tipos-documento`)

Permite a emisores y usuarios autenticados consultar el catálogo unificado de tipos documentales y sus plazos SLA (derivados de `sla_config`), sin requerir privilegios administrativos (`ADMIN`).

- **Método**: `GET`
- **Ruta**: `/api/catalogos/tipos-documento`
- **Seguridad**: Autenticado (`isAuthenticated()`)
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "tipo": "Contrato",
      "plazoDias": 3
    },
    {
      "tipo": "Convenio",
      "plazoDias": 5
    },
    {
      "tipo": "Factura",
      "plazoDias": 2
    },
    {
      "tipo": "Memorándum",
      "plazoDias": 1
    },
    {
      "tipo": "General",
      "plazoDias": 5
    }
  ]
  ```
- **Errores**:
  - `401 Unauthorized`: Token no provisto o expirado.

---

### 8.12 Catálogo General de Áreas (`/api/catalogos/areas`)

Permite a los usuarios autenticados consultar la lista completa de áreas activas registradas en el sistema para selector de filtros o asignación departamental, ordenadas alfabéticamente por nombre.

- **Método**: `GET`
- **Ruta**: `/api/catalogos/areas`
- **Seguridad**: Autenticado (`isAuthenticated()`)
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "nombre": "Administración y Finanzas"
    },
    {
      "id": 2,
      "nombre": "Operaciones"
    },
    {
      "id": 3,
      "nombre": "Recursos Humanos"
    }
  ]
  ```
- **Errores**:
  - `401 Unauthorized`: Token no provisto o expirado.

---

## 9. Diseño RBAC departamental y jerárquico — HU-S2-07

**Estado: backend y consumidor frontend implementados y activados localmente el 03-10-2026.** Esta sección sustituye las reglas de autorización de Sprint 1 descritas anteriormente. HU-S2-07 conserva pendiente la verificación funcional/E2E y visual.

La política, modelo, alcances, migración y trazabilidad están en [rbac-departamental-jerarquico-sprint-2.md](design/rbac-departamental-jerarquico-sprint-2.md). Roles base: ADMIN, AREA_ADMIN derivado de áreas administradas, REVISOR y EMISOR; APPROVER es compatibilidad del modo anterior. Keycloak autentica; la autorización funcional objetivo se resuelve por cuenta/roles/permisos locales vigentes usando el `sub` del JWT.

### 9.1 Contexto de acceso propio

`GET /api/rbac/me` — cuenta autenticada activa; `200`, `401`. Siempre consulta el contexto actual; `Cache-Control: no-store`. UUID de usuario, IDs BIGINT de roles/áreas, versiones no negativas.

```json
{
  "usuarioId": "3bc4ce7a-cb35-4a1b-8c04-7265bf307a1d",
  "areaId": 12,
  "jefaturaDirectaId": null,
  "administradorGlobal": false,
  "roles": [{"id": 4, "codigo": "EMISOR", "nombre": "Emisor", "origen": "EXPLICITO"}],
  "areasAdministradas": [],
  "permisos": [
    {"codigo": "SOLICITUD_CONSULTAR", "alcances": ["PROPIAS"]},
    {"codigo": "SOLICITUD_CREAR", "alcances": ["PROPIAS"]}
  ],
  "versionAcceso": 0,
  "versionPolitica": 1
}
```

El ejemplo es parcial; la respuesta contiene todos los permisos efectivos. `origen` admite EXPLICITO/AREA; roles derivados no son editables mediante asignación de membresías. `areaId` nullable representa pertenencia activa efectiva; `areasAdministradas` incluye cada área activa a cargo, con `{id,nombre}`. El contexto no contiene la cadena de superiores, documentos ni datos ajenos; el backend resuelve esa cadena internamente. `administradorGlobal` depende del ADMIN local activo, no del token o de permisos personalizados.

### 9.2 Catálogo de permisos y roles

- `GET /api/rbac/permisos`: ADMIN; lista de `{codigo,nombre,descripcion,reservado,alcancesPermitidos}`. Catálogo fijo para edición; no admite alta HTTP de permisos.
- `GET /api/rbac/roles?page=0&size=10&q=...&activo=true`: ADMIN; búsqueda literal por código/nombre, estado opcional, orden nombre e ID. `page` base 0, `size` 1–100, default 10. Respuesta paginada `{contenido,pagina,tamanio,totalElementos,totalPaginas,primera,ultima}`, igual al sobre de áreas. La interfaz usa siempre 10 registros.
- `GET /api/rbac/roles/{id}`: ADMIN; `200` con el DTO completo del rol para edición/recarga; ID inexistente `404`.
- `POST /api/rbac/roles`: ADMIN; alta activa, `201` con `Location: /api/rbac/roles/{id}` y DTO del rol.
- `PUT /api/rbac/roles/{id}`: ADMIN; `200`; reemplaza nombre visible, descripción y todas las concesiones. Código/origen/sistema no son campos editables.
- `PATCH /api/rbac/roles/{id}/status`: ADMIN; `{ "activo": false, "version": 2 }`; `200`. Desactivación lógica, sin DELETE. Rol protegido o en uso: `409`.

Body de alta:

```json
{
  "codigo": "CONSULTA_EQUIPO",
  "nombre": "Consulta del equipo directo",
  "descripcion": "Consulta y seguimiento dentro del departamento autorizado.",
  "permisos": [
    {"codigo": "SOLICITUD_CONSULTAR", "alcances": ["PROPIAS", "EQUIPO_DIRECTO"]},
    {"codigo": "HISTORIAL_CONSULTAR", "alcances": ["PROPIAS", "EQUIPO_DIRECTO"]}
  ]
}
```

Body de edición: mismos campos excepto `codigo`; añade `version` obligatoria. `nombre` 1–100 caracteres normalizados y sin caracteres de control; `descripcion` opcional hasta 1000. Código ASCII `^[A-Z][A-Z0-9_]{2,49}$`, estable y único incluso entre roles inactivos; nombre visible único con `lower(btrim(nombre_visible))`. Permisos/alcances desconocidos, duplicados, array vacío de alcances o combinación incompatible: `400`. `permisos:[]` es un rol sin concesiones documentales, válido; no cambia ADMIN protegido. Nombre/descripcion usan recorte de U+0020 y límites Unicode como los formularios de áreas.

Respuesta de rol: `{id,codigo,nombre,descripcion,activo,sistema,asignacion,version,permisos,createdAt,updatedAt}`. `asignacion`: EXPLICITA o DERIVADA_AREA. Todas las respuestas son DTOs; `permisos` se agrupa por código con array de alcances.

### 9.3 Membresías y jefatura de usuarios

`PUT /api/users/{id}/roles` — ADMIN; reemplazo atómico, `200` con DTO de usuario ampliado:

```json
{"roleIds": [3, 4], "versionAcceso": 0}
```

IDs positivos, únicos y de roles activos EXPLICITOS. Lista vacía revoca las capacidades funcionales y conserva cuenta propia/notificaciones; no puede afectar al último ADMIN ni dejar revisiones operativas sin responsable elegible. AREA_ADMIN se deriva exclusivamente de la asignación administrativa del área.

`PUT /api/users/{id}/jefatura` — ADMIN; `200` con DTO ampliado:

```json
{"jefaturaDirectaId": "01729a35-2171-47b1-bf90-87ac77c92f51", "versionAcceso": 1}
```

`jefaturaDirectaId:null` elimina la relación. Debe existir una cuenta activa, diferente del usuario y sin ciclo. Referencia inexistente: `404`; autoasignación/ciclo/inactividad/dependencia operativa: `409`. Ninguna relación por sí sola concede un permiso documental.

Ampliación implementada de `UserResponse`: `rolesFuncionales:[{id,codigo,nombre,origen}]`, `jefaturaDirectaId`, `jefaturaDirectaNombre`, `versionAcceso`. `roles` legado conserva su representación ADMIN/APPROVER sin utilizarse como fuente de autorización. `rolesFuncionales` es canónico para roles nuevos/personalizados e incluye el origen de la administración de áreas.

Alta existente `POST /api/users`: admite `roleIds` como alternativa a `roles` legado; enviar ambos, ninguno, IDs inválidos o AREA_ADMIN directo devuelve `400`. `roles:["APPROVER"]` resuelve las membresías EMISOR+REVISOR. La edición actual de datos personales/contraseña conserva membresías y jefatura; no las cambia por omisión. Asignación de administrador de área continúa mediante `administradorId` en los DTOs de alta/edición de área existentes.

### 9.4 Catálogos operativos mínimos

- `GET /api/rbac/catalogos/areas`: cuenta activa; lista `{id,nombre}` de áreas activas propias, administradas o conocidas mediante solicitudes efectivamente autorizadas; ADMIN obtiene todas las activas. Sin información documental ni organigrama privado.
- `GET /api/rbac/catalogos/revisores?areaId=12`: exige permiso FLUJO_GESTIONAR en el área objetivo. Lista `{id,nombre,areaId,areaNombre}` de candidatos activos con capacidades de revisión requeridas. Admite selección transversal; no devuelve RUT, email, roles, estado de bloqueo ni datos de credenciales. `areaId` positivo cuando se envía; omitirlo solicita responsables de flujos generales y exige ADMIN local. `400` para ID inválido, `403` fuera de administración, `404` área inexistente tras comprobar autorización de catálogo.

El catálogo de flujos existente filtra por selección autorizada y no revela revisores/correos internos a cuentas que solo emiten. El catálogo no sustituye la comprobación de elegibilidad al guardar ni al ejecutar decisiones.

### 9.5 Aplicación a contratos de solicitudes existentes

Se conservan rutas y parámetros existentes: búsqueda `q`, `solicitante`, `areaId`, `fechaDesde`, `fechaHasta`, `pagina`, `tamanio`; ningún campo de contexto enviado por el cliente modifica el actor o su alcance.

| Endpoint/grupo existente | Regla objetivo |
| --- | --- |
| Registro y reenvío multipart | SOLICITUD_CREAR/REENVIAR, emisor y propiedad, área efectiva y validaciones de flujo/estado |
| Mis solicitudes | SOLICITUD_CONSULTAR y propiedad del actor; no lista solicitudes ajenas por rol administrativo |
| Búsqueda/listado/detalle | SOLICITUD_CONSULTAR, departamentos/equipo/participación y exclusión de superiores |
| Revisiones pendientes | REVISION_CONSULTAR y asignación a una etapa del flujo; las decisiones y acciones del dashboard exigen la etapa actual o la excepción acotada del flujo base |
| Aprobar/rechazar/corrección | Permiso de decisión específico, visibilidad, etapa actual y reglas operativas; cierre del acceso abierto de Sprint 1 |
| Historial/observaciones/IA/descarga | Permiso propio de la acción y SOLICITUD_CONSULTAR sobre la misma solicitud |
| Dashboard/métricas | Predicado autorizado antes de listar/agregar, incluidas transiciones dentro/fuera de SLA |
| `/api/doc/download/{filename}` | Resolver Documento.storageKey a solicitud y autorizar antes de leer MinIO; sin vínculo: 404 |
| `/api/doc/upload` | Utilidad exclusiva ADMIN; registro operativo conserva POST de solicitud multipart |

Detalle ampliado con `accionesPermitidas:["DESCARGAR","REENVIAR"]`, calculado por permiso, relación y estado. La lista puede ser vacía; la API vuelve a comprobar la acción al ejecutarla. No representa disponibilidad irrevocable ni concede acceso a otro recurso.

### 9.6 Errores, versiones y auditoría

Errores `application/problem+json` con `{type,title,status,detail,instance,codigo}`, `invalidFields` cuando corresponde. `401` para autenticación/cuenta; `403 RBAC_ACCION_DENEGADA` para acción sin permiso; `404 RECURSO_NO_ENCONTRADO` idéntico para solicitud/documento inaccesible o inexistente. Filtros de consulta fuera del conjunto autorizado dan página vacía; no información sobre existencia.

Conflictos `409`: `RBAC_VERSION_DESACTUALIZADA`, `RBAC_ROL_PROTEGIDO`, `RBAC_ROL_DUPLICADO`, `RBAC_ROL_EN_USO`, `RBAC_ULTIMO_ADMIN`, `RBAC_JERARQUIA_INVALIDA`, `RBAC_DEPENDENCIA_REVISION`. Payload inválido: `400 RBAC_DATOS_INVALIDOS`. Los IDs/nombres de dependencias solo aparecen en respuestas administrativas autorizadas, nunca en errores de recursos documentales invisibles.

Versiones separadas: rol `version`, usuario `versionAcceso`, contexto global `versionPolitica`. No reintentar escrituras automáticamente con versiones nuevas; recargar y revisar el formulario. Las mutaciones incrementan versiones y auditan actor/objetivo/antes/después en la misma transacción, conforme al diseño.

### 9.7 Arranque, compatibilidad e integridad operativa

- Antes de Hibernate se ejecutan `db/area-schema.sql`, `db/flow-schema.sql` y `db/rbac-schema.sql`. El script de flujos agrega `completo`, versiones y tipo REVISION con defaults antes de Hibernate, además de referencias históricas nullable e índice de nombre normalizado. Su inicializador completa restricciones tras Hibernate y reconcilia una vez los catálogos legacy, conservando solicitudes/documentos/etapas e historia. RBAC vuelve a aplicar sus restricciones tras Hibernate para cubrir instalaciones vacías. Las semillas se instalan una sola vez mediante `seed_version`; reiniciar no restaura permisos editados ni membresías revocadas.
- Las asociaciones APPROVER existentes se expanden una sola vez en EMISOR y REVISOR. Las solicitudes históricas sin snapshots conservan áreas nulas: visibilidad por propiedad, asignación o ADMIN, sin reconstruir departamentos a partir de datos actuales.
- El sincronizador de Keycloak importa identidades sin conceder permisos remotos ni sobrescribir la autorización local. En una instalación sin ADMIN local, `RBAC_BOOTSTRAP_ADMIN_SUB` permite identificar explícitamente al primer administrador por su `sub` activo ya importado; solo actúa una vez. No asigna privilegios por correo o por roles del token.
- La matriz SLA completa queda reservada a ADMIN; el cálculo de plazos y los badges existentes se conservan. Las métricas documentales cuentan únicamente solicitudes y transiciones visibles.
- Reemplazar etapas de un flujo con solicitudes vinculadas devuelve `409 RBAC_DEPENDENCIA_REVISION` para preservar sus referencias e historial. Retirar capacidades de un responsable vigente también comprueba dependencias; las inconsistencias anteriores se comparan con el estado posterior para impedir nuevas pérdidas de autorización.
- Una cuenta con referencias históricas no se elimina físicamente: devuelve `409 RBAC_DEPENDENCIA_REVISION`; la desactivación conserva la trazabilidad y exige reasignar responsabilidades operativas.

### 9.8 Consumo frontend implementado

- `AccessProvider` carga `/api/rbac/me` antes de mostrar el shell. `AccessGate` controla rutas directas; los enlaces y controles usan permisos locales vigentes. Una cuenta sin roles conserva sesión y notificaciones, con un panel sin operaciones documentales.
- El contexto se actualiza al navegar, recuperar el foco, realizar una mutación administrativa y recibir 401/403. Las peticiones concurrentes de contexto se agrupan; una mutación ocurrida durante la lectura programa una actualización posterior. Los errores de acceso no reintentan escrituras ni provocan ciclos de refresco de las vistas.
- Organización y usuarios separa Usuarios y Roles y permisos en pestañas independientes dentro de la misma ruta. Cada sección muestra sus propias acciones, mensajes y tabla; conserva filtros y paginación al alternar. Roles y permisos incluye nombre/descripción, permisos y alcances, alta/edición/estado, roles protegidos y tabla de 10 filas. El código estable se genera internamente al crear. Roles de usuario y Jefatura directa tienen diálogos separados y envían `versionAcceso`; AREA_ADMIN se presenta como derivado.
- Estado de solicitudes conserva la bandeja propia y agrega Según mi acceso, mediante el listado paginado del servidor y su catálogo de áreas. Cada detalle se vuelve a consultar; descarga y corrección dependen de `accionesPermitidas`. Revisión, previsualización y reenvío también comprueban esas capacidades; indicadores y trazabilidad se condicionan a sus permisos.
- Configuración de flujos limita unidades y controles a áreas administradas o ADMIN, carga el catálogo mínimo de revisores del destino y reserva la matriz SLA a su permiso administrativo. Registro documental utiliza únicamente flujos seleccionables y conserva la excepción del flujo base.
- Los diálogos de roles/jefatura reutilizan el foco, teclado y fondo inerte de `AreaDialog`, junto con `DropdownSelect` y los componentes compartidos. Un conflicto de versión conserva la selección y ofrece recarga explícita; no hay reintentos automáticos con versiones nuevas.

---

## 10. Detalle integral de solicitud — HU-S2-09

**Estado: diseño, backend y frontend implementados y activados localmente el 03-10-2026; validación funcional/E2E y visual pendiente.** El esquema completo, ejemplo JSON, permisos por sección, tratamiento de datos legacy y presentación están en [detalle-solicitud-sprint-2.md](design/detalle-solicitud-sprint-2.md). `RequestDetailController` delega ambas rutas a `RequestDetailService`, un lector independiente del ciclo de escritura.

### 10.1 Consulta unificada

- `GET /api/requests/{id}/detail`, requerido por la tarjeta [BACKEND hI0sFxji](https://trello.com/c/hI0sFxji).
- Alias: `GET /api/solicitudes/{id}/detalle`; ambos usan UUID de solicitud y el mismo lector/autorización.
- JWT y cuenta local activa, permiso SOLICITUD_CONSULTAR y alcance efectivo sobre esa solicitud. No se acepta contexto de autorización del cliente.
- `200 application/json`, `Cache-Control: no-store`, DTO `RequestDetailResponse`: identidad, correlativo, título/descripción, estado, emisor, fechas, versión de solicitud, flujo, áreas capturadas, etapa, documento vigente, metadatos de versiones, SLA, observaciones, historial y acciones permitidas.
- Historial y observaciones usan `{accesible,elementos}`: los permisos propios se comprueban por solicitud. Sin acceso, elementos vacíos y sección restringida; con acceso y sin filas, sección vacía. Comentarios de historial ocultos si falta permiso de observaciones.
- Documentos: metadatos de todas las versiones. HU-S2-12 informa descargaUrl por ID de cada versión autorizada, bajo DOCUMENTO_DESCARGAR. El detalle no consulta MinIO ni publica storageKey. Visor PDF autenticado para el vigente; descarga independiente para cada versión.
- Observaciones e historial en orden `createdAt ASC, id ASC`. Solo eventos documentales vinculados; no expone auditoría administrativa global ni infiere datos históricos ausentes.
- SLA conserva deadline y cálculo vigente, con instante de evaluación; los estados terminales no muestran alertas de revisión activa. El GET no genera correlativos, recalcula deadlines ni produce transiciones/notificaciones.
- Lectura consistente en transacción readOnly con aislamiento REPEATABLE_READ; proyecciones y consultas separadas evitan multiplicación de colecciones y consultas por evento.

`RequestDetailResponse` usa records y listas inmutables. Las versiones documentales se ordenan por `version DESC, createdAt DESC, id ASC`; `documentoVigente` es la misma proyección que su entrada en `documentos`, o null si no hay vigente. Las áreas mantienen los IDs capturados por la solicitud y consultan el nombre/actividad actual del catálogo; una referencia legacy sin fila conserva ID y valores nulos. No se sustituye por el departamento actual del emisor.

Las observaciones incluyen resueltas y pendientes, autor, fecha, `transicionId` y etapa de origen registrada. Los eventos incluyen estado origen/destino, acción, autor, fecha, cumplimiento SLA y etapas registradas; origen ausente se representa como INICIAL. Los comentarios restringidos se excluyen también en la consulta de historial y se responden como `comentario:null, comentarioVisible:false`. No se consultan las colecciones sin su permiso.

`sla.evaluadoEn` se captura una sola vez y comparte el cálculo de `SolicitudService`; `sla.enRevision` requiere PENDIENTE_REVISION y deadline. `accionesPermitidas` reutiliza el mismo cálculo del DTO existente. `previsualizable` requiere documento vigente, capacidad DESCARGAR y MIME `application/pdf`. No se accede a MinIO ni se modifica la solicitud para componer esta respuesta.

### 10.2 Errores y compatibilidad

UUID inválido `400 SOLICITUD_ID_INVALIDO`; token inválido `401`; falta de habilitación/permiso general `403 RBAC_ACCION_DENEGADA`; solicitud inexistente o fuera de alcance `404 RECURSO_NO_ENCONTRADO`, sin distinguirlas; varios documentos vigentes `409 SOLICITUD_DOCUMENTO_INCONSISTENTE`. Fallos de composición o persistencia devuelven `500 DETALLE_SOLICITUD_NO_DISPONIBLE`, sin sustituirlos por listas vacías ni exponer trazas al cliente. Errores de negocio en ProblemDetail; `RbacExceptionHandler` conserva la propiedad `codigo` para sus errores y el advice acotado de detalle utiliza `code`. Respuestas de detalle sin almacenamiento en caché.

`GET /api/solicitudes/{id}`, `/historial`, `/observaciones` y `/documento/descargar` conservan sus contratos y autorización vigentes. La nueva respuesta no reemplaza `SolicitudResponse` ni crea permisos, tablas o migraciones.

### 10.3 Consumidor frontend implementado

`RequestDetailPage` se carga bajo demanda en `/solicitudes/:id`, protegida por SOLICITUD_CONSULTAR. `services/requestDetails.js` y `hooks/useRequestDetail.js` consumen `GET /api/requests/{id}/detail` con Axios/JWT. Cancelación, secuencia y clave ID/sesión/revisión RBAC evitan respuestas anteriores; Actualizar recarga el DTO completo. La revisión del contexto al recuperar foco activa una nueva consulta. Carga, error/reintento, vacío y restricción tienen estados propios.

Resumen presenta datos, áreas, flujo, etapa y SLA separado del estado documental. Documentos, Observaciones e Historial muestran 10 registros por página, conservando el orden del contrato. `ObservationTimeline` dispone de modo neutral de consulta y el historial respeta `comentarioVisible`. Secciones sin acceso no muestran contadores ni contenido restringido.

RequestDocuments utiliza el lector autenticado de HU-S2-12 y la ruta exacta del ID de documento. Ofrece descarga del vigente y de versiones anteriores según permiso; el visor PDF del vigente comprueba la firma y limpia URLs Blob al cerrar, cambiar o desmontar. Los errores binarios se decodifican antes de abrir o guardar.

`RequestDetailLink` integra Estado de solicitudes, Revisar documento y Mis documentos con regreso interno y recuperación de filtros/página/selección. El login OIDC conserva la ruta de un detalle abierto directamente. Compilación Vite y disponibilidad Docker comprobadas; los cinco criterios esperan validación funcional/E2E y visual del equipo.

---

## 11. Búsqueda multicriterio de documentos — HU-S2-10

**Estado: diseño, backend y frontend implementados y activados localmente el 03-10-2026; validación funcional/E2E y visual pendiente.** Diseño y trazabilidad de los seis criterios en [busqueda-documentos-sprint-2.md](design/busqueda-documentos-sprint-2.md). `DocumentSearchController` y `DocumentSearchService` pertenecen al módulo `doc` de sistema-principal. No hay tablas, migraciones ni permisos nuevos.

### 11.1 Búsqueda paginada

`GET /api/documents/search` — JWT/cuenta activa, `SOLICITUD_CONSULTAR`. Devuelve una fila por solicitud visible con documento vigente, `200 application/json` y `Cache-Control: no-store`.

| Parámetro | Validación y significado |
| --- | --- |
| `query` | Opcional; texto parcial literal, hasta 200 caracteres, sin distinguir mayúsculas. Título, descripción, correlativo, nombre del emisor o nombre del archivo vigente. `%`, `_` y `\` se tratan como texto. |
| `documentType` | Opcional; código real de `FormatoDocumento.tipo`, normalizado a mayúsculas, máximo 36 caracteres alfanuméricos, guion o guion bajo. Ejemplo PDF. No representa una clasificación empresarial deducida desde el título. |
| `status` | Opcional; PENDIENTE_REVISION, CORRECCION_REQUERIDA, APROBADO, RECHAZADO; normalizado a mayúsculas. |
| `areaId` | Opcional; Long positivo; área de origen o flujo capturada en la solicitud. Se intersecta con el alcance del usuario. |
| `dateFrom` / `dateTo` | Opcionales; fecha `yyyy-MM-dd` o fecha y hora ISO 8601 con offset/Z. Filtran la emisión (`Solicitud.createdAt`), con años 0001–9999. Desde inclusivo; hasta fecha sola incluye todo el día en America/Santiago mediante inicio exclusivo del siguiente día, considerando cambios de horario; hasta instante es inclusivo. Rango invertido: 400. |
| `page` | Desde cero, predeterminado 0; `page * size` no puede exceder Integer.MAX_VALUE. |
| `size` | Predeterminado 10, rango 1–100. |
| `sort` | `createdAt,desc` por defecto; campos createdAt, updatedAt, titulo o correlativo, y dirección asc/desc. Un campo; desempate adicional `id,asc`. Los correlativos nulos siguen el orden nativo de PostgreSQL. |

Filtros vacíos se omiten; desconocidos o repetidos se rechazan con 400. Los filtros se combinan con AND. Área inexistente o no accesible y formato válido sin coincidencias devuelven una página vacía, sin confirmar su existencia. Estado inválido, números inválidos, caracteres de control o fechas sin offset producen 400.

Ejemplo de contrato (IDs y nombres ilustrativos):

```json
{
  "contenido": [{
    "id": "9f6e80a5-b7c0-4687-8d0e-893d6e8b9d14",
    "solicitudId": "58341208-d981-4b72-babd-0e581b0634a4",
    "correlativo": "CONT-001",
    "titulo": "Contrato de servicios",
    "nombreArchivo": "contrato.pdf",
    "documentType": "PDF",
    "contentType": "application/pdf",
    "sizeBytes": 2048,
    "version": 1,
    "estado": "PENDIENTE_REVISION",
    "emisorNombre": "Nombre Apellido",
    "areaOrigen": {"id": 12, "nombre": "Área de ejemplo", "activa": true},
    "areaFlujo": {"id": 12, "nombre": "Área de ejemplo", "activa": true},
    "createdAt": "2026-10-03T15:00:00Z",
    "updatedAt": "2026-10-03T15:00:00Z",
    "documentoCreatedAt": "2026-10-03T15:00:00Z",
    "detalleUrl": "/api/requests/58341208-d981-4b72-babd-0e581b0634a4/detail",
    "descargaUrl": null
  }],
  "pagina": 0,
  "tamanio": 10,
  "totalElementos": 1,
  "totalPaginas": 1,
  "primera": true,
  "ultima": true,
  "orden": "createdAt,desc;id,asc"
}
```

`correlativo` puede ser null en registros antiguos. Las áreas conservan el ID registrado, nombre/actividad actuales y valores null si falta la referencia; no se sustituyen por el área actual del emisor. `createdAt`/`updatedAt` pertenecen a la solicitud; `documentoCreatedAt` al archivo vigente. La página fuera del rango se devuelve vacía conservando el total autorizado. Las versiones anteriores se consultan en el detalle y no participan en la búsqueda.

El resultado excluye storageKey, email, RUT, enlaces presignados, observaciones e historial. `detalleUrl` apunta a HU-S2-09 y vuelve a comprobar el acceso; descargar sigue exigiendo DOCUMENTO_DESCARGAR. Este endpoint no concede capacidades de escritura o descarga.

### 11.2 Opciones de filtros

`GET /api/documents/search/filters` — mismo permiso y contexto, sin parámetros; `200` y `Cache-Control: no-store`:

```json
{
  "documentTypes": ["DOCX", "PDF"],
  "areas": [{"id": 12, "nombre": "Área de ejemplo", "activa": true}],
  "statuses": ["PENDIENTE_REVISION", "CORRECCION_REQUERIDA", "APROBADO", "RECHAZADO"]
}
```

Formatos y áreas derivados exclusivamente de documentos vigentes en solicitudes visibles. Las áreas históricas desactivadas se incluyen con `activa:false`. Formatos ordenados por código; áreas por nombre sin distinguir mayúsculas, nulos al final e ID como desempate. Sin resultados, `documentTypes` y `areas` vacíos. No expone conteos ni un catálogo documental global.

### 11.3 Autorización, consistencia y errores

`DocumentSearchSpecification` usa raíz Solicitud y EXISTS correlacionado sobre Documento. Se compone con `RbacAccessService.visible(SOLICITUD_CONSULTAR)` antes de selección, conteo y paginación; reutiliza departamento, roles, asignaciones, jefatura directa y exclusión de superiores. El cliente no controla el contexto. La identidad procede del JWT y la organización vigente del almacenamiento local.

Ambas lecturas usan transacción readOnly REPEATABLE_READ y contexto RBAC renovado. La página carga emisor/estado mediante EntityGraph; documentos vigentes/formato y áreas se consultan por lotes, sin llamadas por resultado a detalle, permisos o MinIO. El catálogo utiliza proyección escalar DISTINCT con la misma política. El GET no altera solicitudes, archivos, correlativos, deadlines ni auditoría del ciclo de escritura.

| HTTP | Código/forma | Caso |
| --- | --- | --- |
| 400 | `code: DOCUMENT_SEARCH_INVALID_PARAMETERS` | Filtro, orden o paginación inválidos; parámetros desconocidos/repetidos. |
| 401 | Resource server | Token ausente, inválido o cuenta no autenticable. |
| 403 | `codigo: RBAC_ACCION_DENEGADA` | Falta de permiso de consulta; handler RBAC existente. |
| 409 | `code: DOCUMENT_SEARCH_INCONSISTENT_DOCUMENT` | Varios archivos vigentes para una solicitud seleccionada; no se elige uno arbitrariamente. |
| 500 | `code: DOCUMENT_SEARCH_UNAVAILABLE` | Error interno seguro, sin devolver detalles de SQL o filtros. |

Los errores de negocio usan ProblemDetail. Los errores propios del lector llevan no-store; RBAC y autenticación conservan su manejo común. `/api/solicitudes/buscar` mantiene sus parámetros y DTOs existentes. Los seis criterios esperan validación del equipo.

### 11.4 Consumidor frontend implementado

`DocumentSearchPage` se carga bajo demanda en `/consultar-documentos`, desde Documentos → Consultar documentos, con `SOLICITUD_CONSULTAR` tanto en el enlace como en la ruta. `documentSearch.js` consume ambos endpoints mediante Axios/JWT y comprueba estructura de página, catálogo e identificadores antes de presentar resultados; los enlaces de detalle corresponden al ID de solicitud y al contrato HU-S2-09.

La barra admite texto libre y envío con Buscar o Enter. Filtros colapsables de formato, área, estado y fechas, con Limpiar filtros. `DropdownSelect` comparte apariencia y teclado con la administración y revisión; `DateFilter` extraído del calendario de Revisar documento ofrece límites desde/hasta, Borrar/Hoy, etiquetas y retorno de foco. Fechas de emisión y Hoy se presentan según America/Santiago. No hay catálogo de tipos empresariales inferidos.

Los valores editados se conservan como borrador hasta Buscar, con aviso de cambios pendientes. Una consulta aplicada reinicia la página; Limpiar conserva el orden y elimina todos los filtros. Ordenar por utiliza únicamente campos/direcciones del contrato. La tabla muestra correlativo real o Sin correlativo, documento/archivo/formato/versión/tamaño, emisor, áreas registradas, estado y emisión. Paginación fija de 10, con Anterior/Siguiente, totales y página obtenidos del servidor; sin filtrado local de documentos ni selector de tamaño. Una página fuera del rango se ajusta al último índice válido.

`useDocumentSearch` separa búsqueda y catálogo, con AbortController, secuencia y claves de parámetros/usuario/revisión RBAC. Al cambiar consulta, cuenta, permisos o recarga, las respuestas anteriores no se presentan. Actualizar recarga listado y opciones; recuperar foco reutiliza AccessProvider. Los fallos de catálogo permiten buscar por texto/estado/fechas y ofrecen recarga; falta de acceso oculta resultados y opciones. Carga, error, restricción, vacío y Sin resultados tienen estados propios.

Ver detalle reutiliza RequestDetailLink y `/solicitudes/:id`. Volver y el historial del navegador recuperan filtros aplicados, borrador, página, orden y expansión del panel; el snapshot solo se recupera para la misma cuenta. El acceso OIDC conserva la ruta directa de consulta. Tabla apilable según el ancho de su contenedor, controles móviles y paginación accesible siguen los componentes y tokens existentes.

Vite producción compilado: 1610 módulos. Ruta, bundle principal y chunks JS/CSS nuevos disponibles en Docker por HTTP 200; backend UP. La navegación directa solicita autenticación y conserva `/consultar-documentos`. Compilación y disponibilidad no acreditan los seis criterios, recorridos de interacción ni aislamiento funcional; E2E y aprobación visual pendientes del equipo.

---

## 12. Consulta y seguimiento de solicitudes del emisor — HU-S2-11

**Estado: diseño, backend y frontend implementados y disponibles localmente el 04-10-2026; validación funcional/E2E/visual pendiente.** Modelo, experiencia, compatibilidad y trazabilidad de los cinco criterios en [seguimiento-solicitudes-emisor-sprint-2.md](design/seguimiento-solicitudes-emisor-sprint-2.md). Responsabilidad de `flow` y `rbac` en sistema-principal; sin nuevas tablas, estados ni permisos.

### 12.1 Bandejas paginadas implementadas

- `GET /api/requests/my-requests`: cuenta local activa resuelta mediante JWT sub → keycloakUserId, con `SOLICITUD_CONSULTAR`. Intersecta siempre RBAC y emisor local autenticado, incluso para ADMIN. No acepta un identificador de emisor del cliente.
- `GET /api/requests/accessible`: mismo permiso; todo el conjunto visible por RBAC, incluyendo propias cuando corresponda. Completa CA 11.1 sin ampliar la bandeja estrictamente propia. Misma respuesta de resumen.

Ambas devuelven `200 application/json`, con `Cache-Control: no-store`. Total, filtros y paginación se aplican únicamente a solicitudes visibles, incluidas aquellas sin documento vigente. No consultan MinIO.

| Parámetro | Validación y significado |
| --- | --- |
| `page` | Desde cero, predeterminado 0, entero no negativo; `page * size` debe caber en Integer.MAX_VALUE. |
| `size` | Predeterminado 10, rango 1–100. UI fija en 10. |
| `query` | Opcional; hasta 200 caracteres, espacios exteriores recortados, búsqueda parcial literal en título/correlativo sin distinguir mayúsculas. `%`, `_` y `\` se escapan como texto. |
| `status` | Opcional; PENDIENTE_REVISION, CORRECCION_REQUERIDA, APROBADO o RECHAZADO, normalizado a mayúsculas. |
| `areaId` | Solo `/accessible`: Long positivo, área de origen o flujo capturada. Intersecta RBAC; fuera de alcance o inexistente devuelve una página vacía. En `/my-requests` se rechaza. |

Orden fijo `updatedAt,desc`, desempate `id,asc`; no admite `sort`. Filtros AND antes de count/offset. Vacíos opcionales se omiten; parámetros desconocidos/repetidos, caracteres de control, estados y números inválidos producen 400. Nunca aceptar sub, usuario, emisor o email para cambiar la identidad de la bandeja propia.

### 12.2 Respuesta de resumen

`MyRequestsSummaryResponse` es el record de cada fila; `MyRequestsPageResponse` es su envoltorio. Ejemplo ilustrativo, no obtenido del runtime:

```json
{
  "contenido": [{
    "id": "58341208-d981-4b72-babd-0e581b0634a4",
    "correlativo": "CONT-001",
    "titulo": "Contrato de servicios",
    "estado": "CORRECCION_REQUERIDA",
    "createdAt": "2026-10-03T15:00:00Z",
    "updatedAt": "2026-10-04T12:30:00Z",
    "version": 3,
    "etapaActual": {"id": 21, "orden": 2, "nombre": "Revisión jurídica"},
    "emisorNombre": "Nombre Apellido",
    "propia": true,
    "areaOrigen": {"id": 12, "nombre": "Área de ejemplo", "activa": true},
    "areaFlujo": {"id": 12, "nombre": "Área de ejemplo", "activa": true},
    "accionesPermitidas": ["REENVIAR"],
    "detalleUrl": "/api/requests/58341208-d981-4b72-babd-0e581b0634a4/detail",
    "descargaUrl": null
  }],
  "pagina": 0,
  "tamanio": 10,
  "totalElementos": 1,
  "totalPaginas": 1,
  "primera": true,
  "ultima": true,
  "orden": "updatedAt,desc",
  "consultadoEn": "2026-10-04T12:31:00Z"
}
```

Tipos: id UUID; correlativo String nullable; titulo/estado/emisorNombre/detalleUrl String; createdAt/updatedAt/consultadoEn Instant; version Long; etapaActual EtapaSolicitudResponse nullable; propia boolean; areaOrigen/areaFlujo AreaDetalleResponse nullable; accionesPermitidas List<String>. Página: contenido List<MyRequestsSummaryResponse>, pagina/tamanio/totalPaginas int, totalElementos long, primera/ultima boolean, orden String.

`createdAt` identifica el envío inicial; `updatedAt` la última modificación del trámite. Reenvío conserva emisión/correlativo. `version` es de solicitud, independiente del archivo/flujo. En terminales, etapaActual indica la última etapa registrada, sin presentarla como revisión abierta. Correlativo legacy nulo permanece null y la UI informa Sin correlativo registrado; no se genera durante GET. Nombre del emisor procede de nombres/apellidos, fallback Usuario, sin correo/RUT.

`propia` compara IDs locales; siempre true en `/my-requests`. Áreas por IDs capturados y catálogo actual; referencias no resolubles conservan ID con nombre/actividad nulos. Acciones de resumen: vacío o REENVIAR, solo en CORRECCION_REQUERIDA, con visibilidad, permiso SOLICITUD_REENVIAR y emisor propio o ADMIN según el servicio vigente. El detalle conserva su conjunto completo de capacidades.

Total cero: contenido vacío, totalPaginas 0, primera según page==0 y ultima true. Índice fuera de rango: página vacía con total vigente; consumidor ajusta y relee una vez. Una nueva modificación puede reordenar filas entre peticiones; no existe snapshot persistente entre páginas.

### 12.3 Seguridad, errores y compatibilidad

Lectura readOnly/REPEATABLE_READ, con contexto RBAC renovado dentro de la transacción. Predicado común antes de count/página; relaciones to-one de emisor/estado/etapa, áreas por lote y una consulta de IDs autorizados para REENVIAR. No ejecutar detalle, capacidades completas, documentos o permisos por cada fila. Sin storageKey, sub, correo/RUT, URLs públicas, observaciones ni historia en el resumen.

Errores: `400 code: MY_REQUESTS_INVALID_PARAMETERS`, resource server 401, `403 codigo: RBAC_ACCION_DENEGADA` del handler RBAC o `code` del advice acotado para AccessDeniedException, `500 code: MY_REQUESTS_UNAVAILABLE` seguro. ProblemDetail en errores de negocio; `MyRequestsWebConfig` registra un filtro no-store antes de seguridad, limitado a estas dos rutas, que incluye errores de autenticación/RBAC. Error de lectura no equivale a una bandeja vacía. El detalle HU-S2-09 conserva sus propios errores y autorización por sección.

GET `/api/solicitudes/mis-solicitudes` sigue devolviendo el array de SolicitudResponse, ordenado por creación. `/api/solicitudes`, `/buscar` y sus DTOs también permanecen compatibles. Los endpoints de resumen son aditivos; no cambian permisos, transiciones, SLA, historial ni el flujo de reenvío.

### 12.4 Consumidor frontend implementado

`MyRequestsPage` ocupa `/estado-solicitudes`, con SOLICITUD_CONSULTAR y montaje por cuenta, carga diferida y menú Estado de solicitudes conservado. EstadoSolicitudesView delega a esta página. Dos bandejas, búsqueda título/correlativo, estado y área solo en autorizada; DropdownSelect y componentes corporativos existentes. Selectores aplican inmediatamente; texto mediante Buscar/Enter con borrador separado. Tabla con correlativo destacado, etapa, badge de estado, emisión/última actualización y acciones; diez filas de servidor con Anterior/Siguiente, sin selector de tamaño. Fechas en America/Santiago y filas apilables por ancho disponible.

Actualización por entrada, Actualizar, regreso, foco/visibilidad y temporizador visible de 30 segundos después de cada lectura; sin llamadas solapadas, con cancelación/secuencia y claves por cuenta/revisión/bandeja/filtros/página. Latencia periódica acotada, sin promesa de push instantáneo. Errores transitorios: reintentos a 60/120 segundos; datos anteriores del mismo contexto identificados como desactualizados y corrección bloqueada. Cambios de contexto o 401/403 retiran los datos inmediatamente.

`myRequests.js` valida el esquema completo de página/fila, IDs únicos, enlace exacto, listas y capacidad REENVIAR. Consulta con Axios/JWT, AbortSignal y timeout de 20 segundos; GET `/api/rbac/catalogos/areas` solo para la bandeja autorizada. Un error del catálogo conserva el filtro aplicado y no amplía la consulta. `useMyRequests` revalida acceso antes de la lectura, utiliza la revisión de AccessProvider como disparador y conserva filas solo con la misma identidad/política/consulta; cancela lectores y temporizador al ocultar/desmontar. Denegaciones del catálogo también retiran datos hasta revalidación. Los cambios de contenido se anuncian sin reemplazar las filas por una pantalla de carga durante refrescos del mismo contexto.

Ver detalle abre `/solicitudes/:id` y conserva parámetros/borrador/página para la misma cuenta, sin almacenar DTOs. Historial reutiliza HU-S2-09 y sus permisos; corrección abre la vista operativa con ID y nueva lectura de versión. Deep links existentes `/estado-solicitudes?id=...` se resuelven al detalle autorizado con retorno sin id; allowlist OIDC e internos conservan solo rutas e identificadores válidos. Carga, vacíos, falta de coincidencias, errores, restricción y recarga tienen estados diferenciados.

### 12.5 Disponibilidad y alcance de verificación backend — 04-10-2026

Maven Java 21 `package -Dmaven.test.skip=true`: BUILD SUCCESS, 189 fuentes, 1 min 43 s; tests no compilados ni ejecutados. Backend actualizado en Docker con imagen `capstone-my-requests-backend:20261004`, respaldo `capstone-my-requests-backend-before:20261004`, arranque 19.227 s, health UP y reinicios 0. Frontend existente HTTP 200.

OpenAPI HTTP 200 publica ambos GET, cuatro parámetros de propia/cinco de autorizada, MyRequestsSummaryResponse con 14 campos y MyRequestsPageResponse con nueve. Los lectores legacy, el detalle HU-S2-09 y la búsqueda HU-S2-10 siguen publicados. La evidencia cubre compilación, arranque y forma del contrato; consultas autenticadas, aislamiento, cambios de estado, navegación, refresco y cinco criterios funcionales/E2E/visuales permanecen pendientes del equipo.

### 12.6 Disponibilidad frontend — 04-10-2026

Vite producción compilado: 1613 módulos, 4.92 s, entrada `index-DL3yX-Cc.js`, página `MyRequestsPage-DSkAI_mb.js` y estilos `MyRequestsPage-IgoA8u3_.css`. Imagen `capstone-my-requests-frontend:20261004` activada solo en frontend; respaldo `capstone-my-requests-frontend-before:20261004` conservado. Ruta, entrada y cuatro assets JS/CSS HTTP 200, contenedor sin reinicios y backend UP. Compilación/disponibilidad no acreditan interacción, aislamiento, transiciones ni refresco funcional; validación del equipo pendiente.

---

## 13. Descarga segura y streaming documental — HU-S2-12

**Estado: diseño, backend y frontend implementados y disponibles en Docker el 04-10-2026; validación funcional/E2E y visual pendiente.** [Diseño y trazabilidad](design/descarga-documentos-sprint-2.md). No hay tablas, migraciones ni permisos nuevos.

### 13.1 Rutas

| GET autenticado | Identificador y comportamiento |
| --- | --- |
| /api/documents/{id}/download | UUID de Documento: versión exacta, vigente o anterior. Ruta indicada por Trello. |
| /api/docs/{id}/download | Alias de la ruta por Documento. |
| /api/solicitudes/{id}/documento/descargar | UUID de Solicitud: resuelve una sola vez su documento vigente. |
| /api/doc/download/{filename} | Compatibilidad por storageKey interno ya conocido; exige vínculo único y autorización sobre la solicitud. |

DocumentDownloadController concentra las cuatro rutas. DocController conserva solo carga administrativa; SolicitudController conserva las operaciones de solicitudes. DocumentDownloadResolver obtiene metadata escalar con DocumentDownloadRepository, renueva el contexto RBAC y autoriza sobre la solicitud vinculada dentro de una transacción corta REPEATABLE_READ. SOLICITUD_CONSULTAR no concede DOCUMENTO_DESCARGAR; departamento, jerarquía, asignación, administradores de área y cuenta activa siguen el predicado vigente. Falta de visibilidad devuelve 404; falta de descarga en una solicitud visible, 403. MinIO se abre después del control de acceso.

### 13.2 Respuesta binaria 200

- Content-Disposition attachment con filename y filename* UTF-8. Se conserva nombre/extensión salvo controles, separadores y caracteres incompatibles; nombre vacío usa documento-ID.
- Content-Type: MIME registrado válido; application/octet-stream si falta o es inválido/comodín.
- Content-Length: longitud del mismo GET de MinIO; se comprueba con sizeBytes cuando está registrado.
- Cache-Control: no-store, no-transform; X-Content-Type-Options: nosniff. El filtro cubre también los rechazos previos de autenticación.
- CORS expone Content-Disposition, Content-Length y Content-Type exclusivamente a los orígenes locales ya permitidos.
- Cuerpo: bytes originales, copia síncrona con buffer de 64 KiB. Sin readAllBytes, archivo temporal, URL pública/presignada o transacción de base durante la copia.

DocumentDownloadWriter cierra GetObjectResponse en éxito, error y desconexión. No realiza una consulta stat separada. La auditoría DESCARGAR_DOCUMENTO registra inicio de descarga autorizado después de abrir y validar el objeto, con IDs y versión; no afirma guardado en el equipo del usuario.

### 13.3 Errores

| HTTP | Código o situación |
| --- | --- |
| 400 | DOCUMENT_DOWNLOAD_INVALID_ID |
| 401 | Resource server: sesión/token no disponible |
| 403 | RBAC_ACCION_DENEGADA |
| 404 | DOCUMENT_NOT_AVAILABLE o RECURSO_NO_ENCONTRADO sin revelar solicitudes no visibles |
| 409 | DOCUMENT_DOWNLOAD_CONFLICT: varios vigentes, clave ambigua o longitud distinta de metadata |
| 503 | DOCUMENT_STORAGE_UNAVAILABLE: almacenamiento no disponible o lectura interrumpida antes de comprometer la respuesta |
| 500 | DOCUMENT_DOWNLOAD_UNAVAILABLE: fallo interno seguro |

Errores de negocio: application/problem+json con code, status, title y detail. No se exponen credenciales, bucket, claves internas o trazas. Un fallo de escritura previo al compromiso retira Content-Disposition, Content-Length y MIME binario. Después de transmitir bytes se interrumpe la transferencia; nunca se añade JSON al archivo.

### 13.4 Integración con consultas y frontend

DocumentoDetalleResponse mantiene su esquema y cambia descargaUrl a /api/documents/{documentoId}/download para cada versión autorizada. Versiones anteriores ya pueden descargarse desde el detalle. DocumentSearchItemResponse añade descargaUrl nullable, calculada en una consulta escalar por lote limitada a los IDs de la página y al permiso de descarga.

DocumentDownloadButton se integra en Consultar documentos, Mis documentos, detalle/versiones y revisión. Reutiliza Button, icono Download, FeedbackMessage y tokens corporativos; botón condicionado por capacidad y permiso global, carga/progreso, rechazo de doble clic y aviso de error con role alert y cierre accesible, también dentro del diálogo de revisión.

documentDownloads.js consume Axios/JWT con timeout de 60 segundos, AbortSignal y progreso. Decodifica errores Blob, exige respuesta attachment, comprueba longitud y lee filename* UTF-8/filename con alternativa a metadata. Conserva el Blob sin conversión y usa enlace temporal revocado tras 30 segundos o al desmontar. useDocumentDownload controla identidad, revisión RBAC, documento, secuencia y cancelación. El estado «Archivo preparado para descarga» no acredita guardado en disco. La previsualización PDF reutiliza este lector y comprueba firma.

La autorización del servidor corresponde al inicio de cada petición. Una transferencia iniciada no se revoca en mitad del stream; el cliente cancela ante cambios conocidos de acceso/contexto.

---

## 14. Resumen general de solicitudes — HU-S2-14

GET /api/dashboard/summary requiere sesión vigente y ambos permisos METRICAS_CONSULTAR y SOLICITUD_CONSULTAR. Se agregan únicamente solicitudes en la intersección de sus alcances locales vigentes, incluida la exclusión jerárquica. No acepta identidad, rol ni departamento alternativo para ampliar el acceso.

| Parámetro opcional | Regla |
| --- | --- |
| areaId | Long positivo, registrado en el catálogo; exclusivamente ADMIN con GLOBAL en ambos permisos. |
| sinArea | Solo true; agrupa solicitudes sin área capturada. Misma capacidad global. |
| Sin parámetros | Todo el conjunto autorizado. |

Los filtros son excluyentes. Parámetros desconocidos, repetidos, vacíos o inválidos: 400 DASHBOARD_INVALID_PARAMETERS. Filtro sin capacidad global o falta de permiso: 403 RBAC_ACCION_DENEGADA. Sesión inválida: 401. Fallo interno: 500 DASHBOARD_UNAVAILABLE. Errores ProblemDetail sin SQL ni datos internos; código en code para el advice de resumen y en codigo para el advice RBAC común. Respuestas, incluidos rechazos de seguridad: Cache-Control no-store y X-Content-Type-Options nosniff.

DashboardSummaryResponse:

| Campo | Contenido |
| --- | --- |
| totales | pendientes, aprobadas, rechazadas, enCorreccion, otros, total: enteros no negativos. Total = suma de los cinco grupos. |
| porArea | [{areaId, nombre, activa, totales}]; suma de grupos = totales. ID/activa nullable en datos sin catálogo. |
| catalogoAreas | [{id, nombre, activa}]; solo acceso global, incluye áreas inactivas para histórico. |
| puedeFiltrarPorArea | Capacidad global efectiva, calculada en servidor. |
| areaId / sinArea | Filtro aplicado; null/false sin selección. |
| tendencias | Siete objetos {fecha: YYYY-MM-DD, emitidas}, días consecutivos incluyendo hoy, días vacíos con cero. |
| zonaHoraria / consultadoEn | America/Santiago e instante ISO-8601 de lectura. |

Estados: PENDIENTE_REVISION, APROBADO, RECHAZADO, CORRECCION_REQUERIDA; códigos históricos distintos pertenecen a otros. Cada solicitud se asigna una vez a COALESCE(areaOrigenId, areaFlujoId), capturado al emitir. La tendencia cuenta emisiones mediante createdAt, con límites de calendario local y horario estacional; no cuenta decisiones.

DashboardSummaryRepository ejecuta dos consultas escalares con autorización: COUNT/GROUP BY de estado/área y siete SUM(CASE...) de emisiones diarias en una fila. DashboardSummaryService mantiene instantánea REPEATABLE_READ para RBAC, catálogo, conteos y tendencia. No carga colecciones documentales ni hace consultas por solicitud. Los contratos legacy /api/solicitudes/dashboard y /api/solicitudes/metricas se conservan.

Frontend: DashboardSummary, lector con validación del contrato y useDashboardResource cancelable; cuatro KPI, distribución, emisiones y tabla de áreas de diez filas. Actualización al entrar, seleccionar, recuperar foco/visibilidad, mutaciones locales y cada 30 segundos visibles; reintento transitorio 60/120 segundos. Cambio de acceso o 401/403 retira datos previos; fallo transitorio del mismo contexto informa cifras desactualizadas. Las bandejas operativas usan el mismo control de lecturas.

### 14.1 Evidencia técnica — 04-10-2026

Maven Java 21 package BUILD SUCCESS: 214 fuentes/1 min 28 s, maven.test.skip=true. Vite producción: 1624 módulos/4.62 s, entrada index-8lqZ9sCH.js y estilos index-DvRJb0_g.css. Imágenes capstone-dashboard-backend/frontend:20261004 activadas, respaldos capstone-dashboard-backend/frontend-before:20261004 conservados. Backend health UP, arranque 17.108 s, servicios running sin reinicios; frontend y assets HTTP 200. OpenAPI publica GET autenticado, areaId/sinArea y nueve campos de DashboardSummaryResponse. Compilación, salud y publicación no acreditan consultas autenticadas, exactitud/aislamiento funcional, actualización entre sesiones ni aprobación visual de los cinco criterios.


### 13.5 Evidencia técnica

Maven Java 21 package: BUILD SUCCESS, 198 fuentes, 2 min 08 s; maven.test.skip=true omite compilación y ejecución de tests. Vite producción: 1617 módulos, 6.04 s. Backend/frontend actualizados mediante imágenes runtime desde compilaciones existentes; health UP, rutas OpenAPI publicadas, assets disponibles y cero reinicios. Imágenes capstone-download-backend/frontend:20261004 y respaldos capstone-download-backend/frontend-before:20261004. Compilación, arranque y disponibilidad no acreditan los cuatro criterios funcionales ni aprobación visual.
