# Handoff Sprint 2: instrucciones para continuar (F1 en adelante)

> Plan maestro completo: `sprint2-remaining-work-plan.md` (artefacto de la sesión; resumen de fases abajo).
> Estado al 03-10-2026: **F0 terminada** (HU-S2-08 passing, 5/5 E2E). **F1 (HU-S2-13 contraseña)** implementada por agente; **pendiente su verificación E2E** (`-Module` de `change-password`) y validación visual.

## 1. Modo de trabajo con subagentes (ahorra tokens)
- El orquestador solo reparte fases y lee reportes. Agentes definidos: `impl-dev` (escribe código + JUnit focalizado, NO corre Playwright) y `qa-runner` (rebuild + corre tests, solo arregla código de test). Usar modelo `flash`.
- Una fase = un `impl-dev` + luego un `qa-runner`. **No paralelizar fases que reconstruyan contenedores o corran E2E** (comparten BD/Keycloak). Sí se puede paralelizar código en archivos distintos.
- Pedir a cada agente un reporte de máx. 20-25 líneas.
- Los subagentes se pierden si el servidor se reinicia: reencargar la fase con el mismo prompt.

## 2. Lecciones de F0 y F1 (no repetir)
1. **Cookies SSO de Keycloak**: antes de iniciar sesión con OTRO usuario ejecutar `await page.context().clearCookies(); await page.goto('/');`. Aplica a todos los tests, incluidos cambios de usuario dentro de un mismo test. (`tests/e2e/README.md §5.1`)
2. **`clean-test-db.ps1` y roles Keycloak**: `ConvertTo-Json` de un solo objeto envía un objeto, no un arreglo, a `/role-mappings/realm`; el revisor quedaba sin rol `APPROVER`. Usar siempre `ConvertTo-Json -InputObject @(...)` y sincronizar `usuario_rol`. Ya corregido en `scripts/clean-test-db.ps1`; si se toca otro script que asigne roles, aplicar lo mismo.
3. **Test IDs de badges SLA**: el estado NORMAL ("A tiempo") genera `sla-badge-normal`, no `sla-badge-a-tiempo`. Los selectores deben usar el ID real del frontend (`RevisarDocumentoView.jsx`); verificar siempre el `data-testid` en el JSX antes de escribir el spec.
4. **Página de Page Objects**: inicializar locators dentro del `constructor(page)`, nunca como campos de clase.
5. **Shell de la herramienta (Windows)**: no poner `|` dentro de argumentos entre comillas (rompe el parser); para comandos complejos escribir un `.ps1` en scratch y ejecutarlo con `& ruta`. `powershell -Command` no está disponible en la herramienta (usar el shell directo). `git grep -e A -e B` en vez de `A\|B`.
6. **Documentación vs código**: antes de documentar un endpoint verificar el controller real (`@RequestMapping`/`@PreAuthorize`). En la auditoría del 03-10-2026 se corrigieron rutas inexistentes (`/api/audit/recent`, `/api/docs/{id}/download`, `POST /api/areas/{id}/administrador`, SLA por flujo/etapa).
7. **Estados del backlog desactualizados**: `sprint-2.md` marcaba "POR HACER" historias ya implementadas. Al cerrar una fase, actualizar `sprint-2.md`, `feature_list.json` y `claude-progress.md` en el mismo paso.

## 3. Pasos inmediatos
1. **Verificar F1** con `qa-runner`: reconstruir `sistema-principal` y `frontend` (`docker compose --profile apps up -d --build sistema-principal frontend`), correr `mvn -q test -Dtest=UserManagementServiceTest,UserControllerTest` y `.\scripts\run-e2e-tests.ps1 -Clean -Module auth` (o el módulo que contenga `change-password.spec.ts`; ver `scripts/run-e2e-tests.ps1`).
   - Riesgo conocido: la verificación de contraseña actual usa el *password grant* de Keycloak; el cliente debe tener *direct access grants* habilitado (realm de desarrollo).
   - El test debe restaurar la contraseña original del usuario de prueba (`docs/SYSTEM_INVARIANTS.md`); si un test falla a mitad, `clean-test-db.ps1 -Clean` debe devolver la clave a su valor base. Verificar que lo haga.
2. Pedir al desarrollador la validación visual de la vista de cambio de contraseña, y recién entonces marcar `auth-006` como `passing`.
3. Commit (rama `main`): hay cambios sin commitear de docs (auditoría de endpoints), F0 y F1.

## 4. Fases restantes (detalle en el plan maestro)
- **F2**: columna `solicitud.tipo_documento` (DDL + `db/sprint2-migration.sql` + entidad), `GET /api/catalogos/tipos-documento`, `POST /api/solicitudes` con `tipoDocumento`, SLA por tipo exacto, select de tipo en `NuevoDocumentoView`. Actualizar `sla-matrix-alerts.spec.ts` (usa títulos con subcadena) sin relajar aserciones.
- **F3**: `buscar?tipoDocumento`, `mis-solicitudes?alcance=propias|accesibles` + `requiereAccion`, correlativo **al crear** (decisión asumida; actualizar `API_CONTRACTS.md §8.7`).
- **F4**: `GET /{id}/documentos`, `GET /{id}/documentos/{docId}/descargar`, 404 amigable si falta el archivo en MinIO, modal de detalle compartido.
- **F5**: `GET /api/solicitudes/metricas/por-area` y dashboard KPI.
- **F6**: specs faltantes (RBAC roles HU-07, vínculo usuario↔área HU-04), sincronizar estados obsoletos del backlog.
- **F7**: regresión final (`mvn test` + E2E completo en orden: auth, org, flow, doc, dash, `zz-security` al final).
- Specs nuevos esperados: `auth/change-password.spec.ts`, `flow/document-search-isolation.spec.ts`, `flow/dashboard-general-summary.spec.ts`, `auth/rbac-roles.spec.ts`.
