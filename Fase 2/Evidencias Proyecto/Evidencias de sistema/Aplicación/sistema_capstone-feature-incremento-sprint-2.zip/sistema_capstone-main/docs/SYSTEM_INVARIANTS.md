# Invariantes del Sistema y Guía de Referencia Rápida (Cheat Sheet)

Este documento centraliza los **invariantes de infraestructura, datos semilla y credenciales maestras** del proyecto Capstone para consulta rápida bajo demanda por parte de los agentes de codificación.

---

## 1. Identidades y Credenciales de Prueba

Keycloak Realm: `capstone-realm` | Client ID: `capstone-client` | Keycloak URL: `http://localhost:8080`

| Usuario (Email) | Contraseña | Rol Keycloak | Rol en UI | Propósito y Capacidades |
| :--- | :--- | :--- | :--- | :--- |
| `admin@capstone.local` | `admin123` | `ADMIN` | Administrador | Control total del sistema: gestión de áreas, organización de usuarios, matriz de plazos SLA, configuración de flujos y auditoría. |
| `revisor@capstone.local` | `revisor123` | `APPROVER` | Emisor y Revisor | Usuario operativo estándar: emite solicitudes, revisa solicitudes de su área o asignadas, aprueba, rechaza y solicita correcciones. No tiene acceso a configuración (`/configurar-*`). |
| `admin` (Keycloak Master) | `admin_secure_pass` | `admin-cli` | Superadmin Keycloak | Administración interna del servidor Keycloak en realm `master` (usado por scripts de limpieza). |

---

## 2. Invariantes Críticos de Base de Datos (`sistema_db`)

### 2.1 Flujo Base Inmutable: ID 1 ("Revisión Simple")
- **Regla del Backend**: Cuando una solicitud es registrada sin especificar un flujo personalizado (`flujoId = null`), `SolicitudService` busca obligatoriamente:
  1. `flujoDefinicionRepository.findById(1L)`
  2. o `findByNombreIgnoreCase("Revisión Simple")`
  3. Si no existe ninguno, lanza: `IllegalStateException: No existe definición de flujo configurada en el sistema`.
- **Estructura Requerida**:
  - `flujo_definicion`: `id = 1`, `nombre = 'Revisión Simple'`, `activo = true`.
  - `flujo_etapa`: `id = 1`, `flujo_definicion_id = 1`, `orden = 1`, `nombre = 'Revisión'`.
  - `transicion`: Requiere las 5 transiciones base de la máquina de estados:
    - ID 1: `(inicio)` $\rightarrow$ `PENDIENTE_REVISION` (Acción: `CREAR`)
    - ID 2: `PENDIENTE_REVISION` $\rightarrow$ `APROBADO` (Acción: `APROBAR`)
    - ID 3: `PENDIENTE_REVISION` $\rightarrow$ `RECHAZADO` (Acción: `RECHAZAR`)
    - ID 4: `PENDIENTE_REVISION` $\rightarrow$ `REQUIERE_AJUSTES` (Acción: `PEDIR_CORRECCION`)
    - ID 5: `REQUIERE_AJUSTES` $\rightarrow$ `PENDIENTE_REVISION` (Acción: `REENVIAR`)
- **Impacto en Scripts de Limpieza**:
  **NUNCA** ejecutar `TRUNCATE TABLE flujo_definicion CASCADE;` sin re-sembrar inmediatamente el flujo 1 y sus transiciones. En `clean-test-db.ps1` y `clean-test-db.sh` se utiliza:
  ```sql
  DELETE FROM flujo_etapa WHERE flujo_definicion_id > 1;
  DELETE FROM transicion WHERE flujo_definicion_id > 1;
  DELETE FROM flujo_definicion WHERE id > 1;
  ```

---

## 3. Invariantes de la Matriz de Plazos SLA (`sla_config`)

- **Reglas Base por Defecto**:
  - `"Contrato"`: 5 días hábiles
  - `"Factura"`: 3 días hábiles
  - `"Informe"`: 7 días hábiles
  - `"Memorando"`: 2 días hábiles
  - `"General"`: 5 días hábiles
- **Mecanismo de Resolución**:
  Primero coincide el tipo de negocio persistido, sin distinguir mayúsculas/minúsculas, incluida la regla `"General"`. Si no encuentra regla, usa título exacto, luego la subcadena configurada más larga y las familias históricas de Contrato/Factura/Memorando/Informe. Finalmente aplica `"General"` o 5 días. El formato PDF/DOCX no es el tipo de negocio.
- **Cómputo en Días Hábiles**:
  El plazo (`deadline`) suma lunes a viernes bajo `America/Santiago`, excluyendo el día inicial y conservando la hora local. No excluye feriados ni aplica horario de oficina.
- **Continuidad**:
  La fecha se captura al emitir; cambios de matriz, etapas, reasignaciones, correcciones y reenvíos no la reinician. Solicitudes históricas sin fecha permanecen con `null`.
- **Alertas y decisiones**:
  `NORMAL` con 24 horas restantes o más; `POR_VENCER` con menos de 24 horas corridas y hasta el instante límite inclusive; `VENCIDO` después. Aprobar, rechazar o pedir corrección registra `dentroSla = instanteDecision <= deadline`; sin deadline, `null`. El atraso no cambia el estado documental ni impide decisiones autorizadas.
- **Referencia y estado**:
  [Diseño SLA HU-S2-08](design/matriz-sla-dias-habiles-sprint-2.md), completo el 12-10-2026. Backend implementa reloj común con microsegundos, desempate estable, entero JSON estricto e índice de tipo normalizado. `db/sla-schema.sql` se aplica antes/después de Hibernate, conserva reglas existentes y carga semillas solo si la tabla es nueva; no recalcula solicitudes. La historia conserva `in_progress` hasta la entrega frontend y validación del equipo.

---

## 4. Invariantes de Infraestructura y Servicios

| Servicio | Contenedor | Puerto Local | Healthcheck / Verificación |
| :--- | :--- | :--- | :--- |
| **PostgreSQL 16** | `capstone-postgres` | `5432` | `pg_isready -U sistema_user -d sistema_db` |
| **Keycloak 24** | `capstone-keycloak` | `8080` | `http://localhost:8080/realms/capstone-realm` |
| **RabbitMQ 3.13** | `capstone-rabbitmq` | `5672`, `15672` | UI en `http://localhost:15672` (`guest`/`guest`) |
| **MinIO S3** | `capstone-minio` | `9000`, `9001` | UI en `http://localhost:9001` (`minioadmin`/`minioadmin_secure_pass`), bucket `documentos` |
| **Sistema Principal** | `capstone-sistema-principal` | `8081` | `http://localhost:8081/actuator/health` |
| **Frontend React** | `capstone-frontend` | `3000` | `http://localhost:3000` (HTTP 200) |
