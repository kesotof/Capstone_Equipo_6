# AGENTS.md

Este archivo es la **guía operativa y mapa de navegación** para agentes de codificación autónomos que operan en el **Sistema de Gestión Documental y Flujos de Aprobación** (Capstone). Su objetivo es dirigir al agente hacia las fuentes especializadas de contexto, mantener un ciclo de trabajo predecible y asegurar la calidad en cada sesión.

---

## Mapa de Referencias del Proyecto

No explores todos los archivos del repositorio para adquirir contexto. Utiliza este mapa directo:

| Referencia | Propósito | Cuándo consultarlo |
| :--- | :--- | :--- |
| [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) | **Catálogo Arquitectónico y de Código**: Detalle exhaustivo de cada carpeta y archivo, tecnologías, diagramas Mermaid, puertos, credenciales, flujos transaccionales y guía de "dónde tocar según la tarea". | **Al iniciar cualquier tarea de código** o cuando requieras entender componentes, contratos REST, colas RabbitMQ o vistas React. |
| [`feature_list.json`](./feature_list.json) | **Fuente Única de Verdad del Backlog**: Lista priorizada de características (`infra-001` a `front-001`), reglas de negocio, criterios de aceptación, estado y evidencia. | **Al iniciar la sesión** para seleccionar la siguiente característica y **al finalizar** para registrar evidencia y actualizar el estado. |
| [`claude-progress.md`](./claude-progress.md) | **Bitácora de Trabajo Continuo (Sprint Activo)**: Historial reciente de hitos del sprint en curso (Sprint 2), último estado en caliente verificado y siguiente paso prioritario. | **Al inicio y fin de cada sesión** para asegurar continuidad sin sobrecarga de contexto. |
| [`docs/progress/sprint-1-archive.md`](./docs/progress/sprint-1-archive.md) | **Archivo Histórico de Progreso (Sprint 1)**: Registro detallado de hitos 1 al 38 (infraestructura base, Keycloak, flujos base y entregables del Sprint 1). | Cuando se requiera consultar decisiones de diseño o detalles históricos anteriores al Sprint 2. |
| [`docker-compose.yml`](./docker-compose.yml) | **Infraestructura y Orquestación**: Definición declarativa de PostgreSQL 16, Keycloak 24, RabbitMQ 3.13, MinIO S3 y los perfiles de microservicios (`--profile apps`). | Cuando necesites levantar servicios, verificar puertos o revisar dependencias entre contenedores. |
| [`.env.example`](./.env.example) / [`.env`](./.env) | **Diccionario de Variables de Entorno**: Puertos, cadenas JDBC, credenciales de desarrollo y claves de APIs externas (Gemini, MasterBase). | Al configurar o verificar variables requeridas por los microservicios. |
| [`init.ps1`](./init.ps1) / [`init.sh`](./init.sh) | **Scripts Estándar de Inicialización**: Validación automática de variables, herramientas Docker y estructura de carpetas. | Al iniciar sesión para validar el entorno de trabajo. |
| [`spring-boot-best-practices`](./.agents/skills/spring-boot-best-practices/SKILL.md) | **Skill de Buenas Prácticas Spring Boot**: Estándares de desarrollo, inyección limpia, DTOs con records, Spring Security 6, JPA, RabbitMQ y control de errores. | **Antes de implementar o modificar código backend** en cualquiera de los 3 microservicios. |
| [`spring-docs-research`](./.agents/skills/spring-docs-research/SKILL.md) | **Skill de Investigación y Cacheo de Docs**: Flujo Local-First para consultar documentación oficial de Spring Boot, o buscar en la web y persistir lo aprendido en Markdown local. Incluye estrategia dual con fallback estándar nativo (`search_web` / `read_url_content`) si el desarrollador no tiene Crawl4AI instalado. | **Cuando una duda técnica de Spring Boot no esté en el resumen de buenas prácticas**: primero local, si no buscar en web y guardar. |
| [`docs/sprint-backlog/sprint-1.md`](./docs/sprint-backlog/sprint-1.md) | **Sprint 1 Backlog Oficial**: Detalle de las 12 historias de usuario de Trello, checklists de criterios de aceptación y mapeo a suites de prueba E2E. | **Al iniciar el desarrollo de cualquier historia del sprint 1** para conocer criterios exactos y estado. |
| [`docs/sprint-backlog/sprint-2.md`](./docs/sprint-backlog/sprint-2.md) | **Sprint 2 Backlog Oficial**: Detalle de las 14 historias de usuario de Trello, organización corporativa, RUT chileno, SLA y estado ágil. | **Al iniciar el desarrollo de cualquier historia del sprint 2** para conocer criterios exactos y estado. |
| [`docs/API_CONTRACTS.md`](./docs/API_CONTRACTS.md) | **Contratos de API REST Backend**: Catálogo completo de endpoints, métodos, esquemas de petición/respuesta (JSON y multipart), códigos HTTP, reglas de negocio y formato RFC 7807 (`ProblemDetail`). | **Al implementar vistas o servicios frontend**, para consumir las APIs directamente sin revisar el código Java del backend. |
| [`docs/SYSTEM_INVARIANTS.md`](./docs/SYSTEM_INVARIANTS.md) | **Invariantes del Sistema y Cheat Sheet**: Credenciales maestras de prueba (`admin`, `revisor`), puertos, flujo base ID 1 ("Revisión Simple"), matriz SLA por defecto y reglas de limpieza de base de datos. | **Al requerir credenciales de prueba, entender flujos base por defecto o depurar scripts de limpieza/datos.** |
| [`docs/SPRINT_2_HANDOFF.md`](./docs/SPRINT_2_HANDOFF.md) | **Handoff Sprint 2**: modo de trabajo con subagentes, lecciones aprendidas (SSO, scripts, shell, selectores), pasos inmediatos y fases F2-F7 restantes. | **Al retomar el Sprint 2** o antes de delegar fases a subagentes. |
| [`tests/e2e/README.md`](./tests/e2e/README.md) | **Guía y Patrones Playwright E2E**: Ejecución de suites, aislamiento de sesiones SSO Keycloak (`clearCookies`), patrón constructor de Page Objects y llamadas seguras con `window.api`. | **Antes de crear o modificar tests automatizados con Playwright** o al depurar fallos de timeout/sesión. |
| [`tests/e2e/`](./tests/e2e/) / [`SPRINT_1_E2E_SPECS.md`](./tests/e2e/SPRINT_1_E2E_SPECS.md) | **Suite de Pruebas E2E y Regresión Sprint 1**: Contenedor oficial, especificación multicriterio y casos de prueba automatizados ejecutables vía `.\scripts\run-e2e-tests.ps1` (o con flag `-UI`). | **Únicamente si el usuario lo solicita explícitamente** para ejecutar pruebas E2E del Sprint 1. |
| [`tests/e2e/SPRINT_2_E2E_SPECS.md`](./tests/e2e/SPRINT_2_E2E_SPECS.md) | **Planificación y Especificación de Pruebas E2E Sprint 2**: Catálogo de 7 suites de prueba automatizadas para cubrir el 100% de los criterios de aceptación (76 CAs) del Sprint 2 con Playwright. | **Al consultar o escribir pruebas automatizadas**, recordando ejecutarlas **sólo si el usuario lo pide explícitamente**. |


---

## Flujo de Inicio de Sesión (Startup Workflow)

Antes de escribir o modificar código, sigue estrictamente esta secuencia:

1. **Confirmar directorio de trabajo**: `Get-Location` o `pwd`.
2. **Consultar el estado del trabajo**: Leer [`claude-progress.md`](./claude-progress.md) para conocer el último estado verificado y el siguiente paso.
3. **Seleccionar característica**: Leer [`feature_list.json`](./feature_list.json) y tomar la característica de mayor prioridad con estado `not_started` o `in_progress`.
4. **Obtener contexto técnico**: Consultar la sección correspondiente en [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) para identificar los archivos exactos a modificar y los contratos de integración.
5. **Revisar últimos commits**: Ejecutar `git log --oneline -5`.
6. **Ejecutar script de inicialización**:
   - En Windows / PowerShell: `.\init.ps1`
   - En Linux / Bash / WSL: `./init.sh`
7. **Levantar la infraestructura necesaria**:
   - Solo infraestructura base: `docker compose up -d postgres keycloak rabbitmq minio minio-init`
   - Todo el stack (incluyendo aplicaciones): `docker compose --profile apps up -d`
8. **Verificación base previa**: Ejecutar smoke tests o llamadas de salud (`/actuator/health`, HTTP 200 en frontend) antes de iniciar nuevo código. Si el estado base está quebrado, resuélvelo antes de continuar.
9. **Pruebas focalizadas**: Al implementar características nuevas o refactorizaciones, probar **únicamente el código nuevo o modificado**. **No ejecutar la suite de pruebas E2E a menos que el usuario lo pida explícitamente.**


---

## Reglas Operativas

- **Una sola característica a la vez**: Trabajar exclusivamente en la característica seleccionada en el backlog.
- **Alcance de Pruebas (Solo Código Nuevo o Modificado)**: Al implementar nuevas características o realizar refactorizaciones, **solo testear el código nuevo o modificado** (ej. unitarias/integración focalizadas en el módulo afectado). No ejecutar suites masivas de prueba ni módulos no tocados.
- **Restricción de Pruebas E2E**: **NO ejecutar pruebas E2E (Playwright) a menos que el usuario lo pida explícitamente.** Las pruebas E2E quedan excluidas del flujo automático de inicio, verificación intermedia o cierre por parte del agente.
- **Validación Verificable**: Una característica solo se marca como `passing` si la verificación focalizada del código nuevo o modificado se ejecutó efectivamente con éxito y fue documentada con resultados concretos.
- **Alcance acotado**: No realizar modificaciones innecesarias fuera de la característica activa.
- **Integridad de verificación**: No relajar ni modificar silenciosamente las reglas de prueba para forzar que pasen.
- **Artefactos durables**: Toda decisión, cambio relevante o hallazgo debe persistirse en los documentos del repositorio (`claude-progress.md`, `feature_list.json`, `PROJECT_STRUCTURE.md`), evitando depender del historial temporal de chat.

---

## Criterio de Finalización (Definition of Done)

Una característica o historia de usuario se considera terminada **únicamente** cuando se cumple todo lo siguiente:
1. El comportamiento objetivo está completamente implementado en backend y frontend.
2. Las pruebas asociadas al código nuevo o modificado están ejecutadas y pasan en verde.
3. Se han implementado/actualizado las especificaciones o archivos de pruebas E2E si corresponde a la historia, pero su **ejecución efectiva se realiza únicamente si el usuario lo solicita explícitamente**.
4. La evidencia del código nuevo/modificado probó su correcto funcionamiento y quedó documentada en [`feature_list.json`](./feature_list.json) y/o [`claude-progress.md`](./claude-progress.md).
5. El repositorio permanece operable y levantable mediante la ruta estándar de inicio (`init.ps1` / `init.sh` / `docker compose`).

---

## Cierre de Sesión (Handoff)

Antes de terminar la interacción:
1. Actualizar [`claude-progress.md`](./claude-progress.md) con el trabajo efectuado y el próximo paso claro.
2. Actualizar [`feature_list.json`](./feature_list.json) si cambió el estado de alguna característica.
3. Si se agregaron nuevos componentes, endpoints o archivos, actualizar [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md).
4. Registrar riesgos o bloqueos pendientes.
5. Realizar `git commit` con un mensaje descriptivo si el código se encuentra en un estado seguro y compilable.
6. Dejar los servicios en estado estable y limpio.