# Estado actual

**Actualizado:** 2026-11-04 · por Kevin

> Único archivo de estado que se lee al iniciar sesión. **Se sobrescribe completo** al cerrar cada sesión (máximo 80 líneas). La historia va en [`claude-progress.md`](./claude-progress.md).

## Dónde estamos

- **Sprint activo:** 3 · [`docs/sprint-3/README.md`](./docs/sprint-3/README.md)
- **Rama activa:** `Plantilla-ia`, sobre `origin/main` (`f785e42`). Sus cambios todavía no están en `main`.
- **Backend Sprint 3 + Plantillas Word (Kevin):** integrados. Flyway `V1` a `V11` aplicadas; backend, `service-ia`, `service-notificaciones` y frontend arriba.
- **IA real:** autocompletar, sugerir campos y evaluar funcionan contra OpenRouter solo con los arreglos de esta rama (decisión S3-A19). `origin/main` todavía falla con IA real: 429/404 y evaluaciones que muestran "sin problemas" aunque el veredicto sea `NO_CUMPLE`.
- **Documento editable:** en «Nueva solicitud» con plantilla el emisor completa el Word directamente, con la IA opcional y el formulario como alternativa (S3-A20).
- **Corrección desde plantilla:** «Por corregir» abre el documento con los datos anteriores y genera una nueva versión, siempre con la versión de plantilla que usó (S3-A21).

## Tarea en curso

Ninguna.

## Próximo paso

1. Pasar `Plantilla-ia` a `main` para que la IA real, el documento editable y la corrección desde plantilla lleguen a todo el equipo.

## Bloqueos y riesgos abiertos

- **Evaluación automática:** solo corre si la etapa tiene `criterio_ia` (D3-03), y el frontend aún no permite definirlo; hoy se usa `PATCH /api/flujos/{id}/etapas/{etapaId}/criterio-ia`. Sin criterio, el revisor la pide con «Evaluar versión vigente». Falta decidir con Eduardo.
- **S3-A19:** el cambio de modelos y tokens espera aprobación de Eduardo.
- **IA real pendiente de probar:** el 04-11 se agotó el cupo gratuito diario de OpenRouter. Falta ver con IA real la ayuda y la sección de las sugerencias de campos, y el autocompletado dentro del documento; se probaron con el respaldo de reglas locales.
- **Jefatura de «Gerencia General»:** en la base local no tiene jefatura, así que `admin@capstone.local` no puede emitir con el flujo base (422).
- **E2E:** sin ejecutar. «Nueva solicitud» con plantilla ahora parte en modo documento: `E2E-TMPL-EMIT` y `E2E-AI-AUTOCOMPLETE` deben contemplarlo (`ver-formulario` cambia al formulario).
- **Bases locales con la numeración vieja** (quien haya corrido `Plantilla-ia` antes del merge): ver la entrada del 2026-11-04 en la bitácora.

## Verificación del harness

- `node scripts/harness-check.js` → OK (3 avisos: historias con nivel inferido y `sync-skills` pendiente).
