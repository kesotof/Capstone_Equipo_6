package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.SolicitudAnexo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SolicitudAnexoRepository extends JpaRepository<SolicitudAnexo, UUID> {

    List<SolicitudAnexo> findBySolicitud_IdOrderByCreatedAtAscNombreArchivoAsc(UUID solicitudId);
}
