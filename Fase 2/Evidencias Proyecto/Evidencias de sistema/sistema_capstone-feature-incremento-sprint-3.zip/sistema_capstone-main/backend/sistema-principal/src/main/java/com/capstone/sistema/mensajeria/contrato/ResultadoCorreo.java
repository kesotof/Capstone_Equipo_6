package com.capstone.sistema.mensajeria.contrato;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.UUID;

/**
 * §5.2 — resultado de service-notificaciones al principal (routing «notificacion.correo.resultado»),
 * uno por intento. `final = true` cuando no habrá más intentos (el nombre JSON es `final`,
 * palabra reservada en Java).
 */
public record ResultadoCorreo(
        int version,
        UUID mensajeId,
        Long notificacionId,
        int intento,
        String resultado,
        @JsonProperty("final") boolean resultadoFinal,
        String destino,
        String proveedorId,
        String codigoError,
        String errorDetalle,
        Instant ocurridoEn
) {
}
