package com.capstone.sistema.rbac.controller;

import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.*;

@RestController
@PreAuthorize("isAuthenticated()")
public class RbacController {

    private final RbacAccessService access;
    private final RbacCatalogService catalog;
    private final RolService rolService;
    private final AccesoUsuarioService accesoUsuarioService;
    private final AccesoEfectivoService accesoEfectivoService;

    /**
     * Los servicios son opcionales solo para no romper el arranque de contextos parciales; si falta uno,
     * el endpoint responde 503 SERVICIO_NO_DISPONIBLE (nunca un 200/204 vacío sin hacer nada).
     * La autorización (permisos v5) la aplica cada servicio.
     */
    @Autowired
    public RbacController(
            RbacAccessService access,
            @Autowired(required = false) RbacCatalogService catalog,
            @Autowired(required = false) RolService rolService,
            @Autowired(required = false) AccesoUsuarioService accesoUsuarioService,
            @Autowired(required = false) AccesoEfectivoService accesoEfectivoService
    ) {
        this.access = access;
        this.catalog = catalog;
        this.rolService = rolService;
        this.accesoUsuarioService = accesoUsuarioService;
        this.accesoEfectivoService = accesoEfectivoService;
    }

    private static <T> T disponible(T service, String nombre) {
        if (service == null) {
            throw new RbacException(HttpStatus.SERVICE_UNAVAILABLE, "SERVICIO_NO_DISPONIBLE",
                    "El servicio de " + nombre + " no está disponible. Intente nuevamente más tarde.");
        }
        return service;
    }

    @GetMapping("/api/rbac/me")
    public ResponseEntity<?> me(@RequestParam(value = "v", required = false) String version) {
        if ("2".equals(version)) {
            return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(access.meV2());
        }
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(access.me());
    }

    @GetMapping("/api/rbac/permisos")
    public List<PermissionDto> permissions() {
        return disponible(rolService, "roles").permisos();
    }

    @GetMapping("/api/rbac/roles/matriz")
    public MatrizRolPermiso matriz() {
        return disponible(rolService, "roles").matriz();
    }

    @GetMapping("/api/rbac/roles")
    public Page<RoleDtoV5> roles(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) Boolean activo
    ) {
        return disponible(rolService, "roles").list(page, size, q, activo);
    }

    @GetMapping("/api/rbac/roles/{id}")
    public RoleDtoV5 role(@PathVariable Long id) {
        return disponible(rolService, "roles").get(id);
    }

    /** Requiere ROL.GESTIONAR (en RolService). Body: {codigo, nombre, descripcion?, permisos: string[] | [{codigo, ...}]}. */
    @PostMapping("/api/rbac/roles")
    public ResponseEntity<RoleDtoV5> create(@RequestBody Map<String, Object> body) {
        RolService service = disponible(rolService, "roles");
        String codigo = texto(body.get("codigo"));
        String nombre = texto(body.get("nombre"));
        String descripcion = texto(body.get("descripcion"));
        List<String> permisos = extractPermisos(body.get("permisos"));
        RoleDtoV5 created = service.create(codigo, nombre, descripcion, permisos);
        return ResponseEntity.created(URI.create("/api/rbac/roles/" + created.id())).body(created);
    }

    /** Requiere ROL.GESTIONAR (en RolService). Body: {nombre, descripcion?, permisos, version}. */
    @PutMapping("/api/rbac/roles/{id}")
    public RoleDtoV5 update(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        RolService service = disponible(rolService, "roles");
        String nombre = texto(body.get("nombre"));
        String descripcion = texto(body.get("descripcion"));
        List<String> permisos = extractPermisos(body.get("permisos"));
        Long version = body.get("version") instanceof Number n ? n.longValue() : null;
        return service.update(id, nombre, descripcion, permisos, version);
    }

    /** Requiere ROL.GESTIONAR (en RolService). */
    @PatchMapping("/api/rbac/roles/{id}/status")
    public RoleDtoV5 status(@PathVariable Long id, @Valid @RequestBody Status request) {
        return disponible(rolService, "roles").status(id, request.activo(), request.version());
    }

    // Endpoints de Asignaciones de Acceso por Usuario (autorización en AccesoUsuarioService / AccesoEfectivoService)
    @GetMapping("/api/users/{id}/accesos")
    public UserAccesosResponse userAccesos(@PathVariable UUID id) {
        return disponible(accesoUsuarioService, "accesos").getAccesos(id);
    }

    @PostMapping("/api/users/{id}/accesos")
    public ResponseEntity<AsignacionAccesoDto> asignarAcceso(
            @PathVariable UUID id,
            @Valid @RequestBody AsignarAccesoRequest request
    ) {
        AsignacionAccesoDto dto = disponible(accesoUsuarioService, "accesos").asignarAcceso(id, request, null);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @DeleteMapping("/api/users/{id}/accesos/{asignacionId}")
    public ResponseEntity<Void> revocarAcceso(
            @PathVariable UUID id,
            @PathVariable Long asignacionId,
            @RequestParam Long versionAcceso
    ) {
        disponible(accesoUsuarioService, "accesos").revocarAcceso(id, asignacionId, versionAcceso);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/users/{id}/acceso-efectivo")
    public AccesoEfectivoResponse userAccesoEfectivo(@PathVariable UUID id) {
        return disponible(accesoEfectivoService, "acceso efectivo").getAccesoEfectivo(id);
    }

    /** Selectores: solo áreas activas, salvo incluirInactivas=true (p. ej. para nombrar flujos existentes). */
    @GetMapping("/api/rbac/catalogos/areas")
    public List<AreaItem> areas(@RequestParam(defaultValue = "false") boolean incluirInactivas) {
        return disponible(catalog, "catálogos").areas(incluirInactivas);
    }

    @GetMapping("/api/rbac/catalogos/revisores")
    public List<Reviewer> reviewers(@RequestParam(required = false) Long areaId) {
        return disponible(catalog, "catálogos").reviewers(areaId);
    }

    private static String texto(Object value) {
        return value instanceof String s ? s : null;
    }

    @SuppressWarnings("unchecked")
    private List<String> extractPermisos(Object permisosObj) {
        if (permisosObj instanceof Collection<?> col) {
            List<String> list = new ArrayList<>();
            for (Object item : col) {
                if (item instanceof String s) {
                    list.add(s);
                } else if (item instanceof Map<?, ?> m && m.get("codigo") instanceof String c) {
                    list.add(c);
                }
            }
            return list;
        }
        return List.of();
    }
}
