package com.capstone.sistema.rbac.model;

import com.capstone.sistema.model.enums.AmbitoRol;
import com.capstone.sistema.model.enums.TipoAsignacionRol;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "rol")
public class Rol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String codigo;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(length = 1000)
    private String descripcion;

    @Column(nullable = false)
    private boolean sistema = false;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TipoAsignacionRol asignacion = TipoAsignacionRol.MANUAL;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AmbitoRol ambito = AmbitoRol.AREA_O_GLOBAL;

    @Column(name = "permisos_bloqueados", nullable = false)
    private boolean permisosBloqueados = false;

    @Column(nullable = false)
    private boolean activo = true;

    @Version
    @Column(name = "lock_version", nullable = false)
    private long lockVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "rol_permiso",
            joinColumns = @JoinColumn(name = "rol_id"),
            inverseJoinColumns = @JoinColumn(name = "permiso_id")
    )
    private Set<PermisoEntity> permisos = new LinkedHashSet<>();

    protected Rol() {
    }

    public Rol(String codigo, String nombre, String descripcion, boolean sistema) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.sistema = sistema;
        this.activo = true;
    }

    public Rol(String codigo, String nombre, String descripcion, boolean sistema, TipoAsignacionRol asignacion, AmbitoRol ambito) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.sistema = sistema;
        this.asignacion = asignacion;
        this.ambito = ambito;
        this.activo = true;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        updatedAt = createdAt;
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public Long getId() {
        return id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isSistema() {
        return sistema;
    }

    public void setSistema(boolean sistema) {
        this.sistema = sistema;
    }

    public TipoAsignacionRol getAsignacion() {
        return asignacion;
    }

    public void setAsignacion(TipoAsignacionRol asignacion) {
        this.asignacion = asignacion;
    }

    public AmbitoRol getAmbito() {
        return ambito;
    }

    public void setAmbito(AmbitoRol ambito) {
        this.ambito = ambito;
    }

    public boolean isPermisosBloqueados() {
        return permisosBloqueados;
    }

    public void setPermisosBloqueados(boolean permisosBloqueados) {
        this.permisosBloqueados = permisosBloqueados;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public long getLockVersion() {
        return lockVersion;
    }

    public void setLockVersion(long lockVersion) {
        this.lockVersion = lockVersion;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public Set<PermisoEntity> getPermisos() {
        return permisos;
    }

    public void setPermisos(Set<PermisoEntity> permisos) {
        this.permisos = permisos != null ? permisos : new LinkedHashSet<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rol rol = (Rol) o;
        return Objects.equals(codigo, rol.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
