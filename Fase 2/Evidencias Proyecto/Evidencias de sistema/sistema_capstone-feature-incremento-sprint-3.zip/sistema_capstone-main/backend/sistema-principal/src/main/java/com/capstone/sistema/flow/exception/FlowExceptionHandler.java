package com.capstone.sistema.flow.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.net.URI;
import java.time.Instant;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

/**
 * Manejador global (sin alcance) de errores del módulo de flujos y de las excepciones genéricas de Spring MVC.
 * Todas las respuestas llevan {@code codigo} y {@code code} (mismo valor), {@code mensaje} y {@code detail}.
 * <p>
 * Orden: los advices con alcance ({@code assignableTypes}/{@code basePackages}) se registran con mayor precedencia
 * ({@code HIGHEST_PRECEDENCE} … {@code +50}) y resuelven primero sus controladores; {@code RbacExceptionHandler}
 * (global, {@code HIGHEST_PRECEDENCE}) solo maneja {@code RbacException} y {@code AccessDeniedException}.
 */
@Order(Ordered.HIGHEST_PRECEDENCE + 100)
@RestControllerAdvice
public class FlowExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(FlowExceptionHandler.class);

    static final String RECURSO_NO_ENCONTRADO = "RECURSO_NO_ENCONTRADO";
    static final String DATOS_INVALIDOS = "SOLICITUD_DATOS_INVALIDOS";

    private final DatabaseRuleViolationTranslator databaseRuleViolationTranslator;

    public FlowExceptionHandler() {
        this(new DatabaseRuleViolationTranslator());
    }

    public FlowExceptionHandler(DatabaseRuleViolationTranslator databaseRuleViolationTranslator) {
        this.databaseRuleViolationTranslator = databaseRuleViolationTranslator != null
                ? databaseRuleViolationTranslator
                : new DatabaseRuleViolationTranslator();
    }

    @org.springframework.beans.factory.annotation.Autowired
    public FlowExceptionHandler(org.springframework.beans.factory.ObjectProvider<DatabaseRuleViolationTranslator> ruleTranslatorProvider) {
        this.databaseRuleViolationTranslator = ruleTranslatorProvider != null
                ? ruleTranslatorProvider.getIfAvailable(DatabaseRuleViolationTranslator::new)
                : new DatabaseRuleViolationTranslator();
    }

    @ExceptionHandler(org.springframework.orm.ObjectOptimisticLockingFailureException.class)
    public ProblemDetail handleVersionConflict(org.springframework.orm.ObjectOptimisticLockingFailureException ex) {
        return databaseRuleViolationTranslator.translate(ex).map(FlowExceptionHandler::withCodigo).orElseGet(() ->
                problem(HttpStatus.CONFLICT, "Conflicto de versión", "El recurso cambió. Recargue antes de volver a guardar.",
                        "SOLICITUD_VERSION_CONFLICTO", null));
    }

    @ExceptionHandler(org.springframework.dao.DataIntegrityViolationException.class)
    public ProblemDetail handleDataIntegrityViolation(org.springframework.dao.DataIntegrityViolationException ex) {
        log.error("Violación de integridad de datos: {}", ex.getMessage(), ex);
        return databaseRuleViolationTranslator.translate(ex).map(FlowExceptionHandler::withCodigo).orElseGet(() ->
                problem(HttpStatus.CONFLICT, "Conflicto de Datos", "Violación de regla de integridad de datos.",
                        "DATA_INTEGRITY_VIOLATION", null));
    }

    @ExceptionHandler(java.sql.SQLException.class)
    public ProblemDetail handleSqlException(java.sql.SQLException ex) {
        log.error("Error SQL no traducido: {}", ex.getMessage(), ex);
        return databaseRuleViolationTranslator.translate(ex).map(FlowExceptionHandler::withCodigo).orElseGet(() ->
                problem(HttpStatus.INTERNAL_SERVER_ERROR, "Error de Base de Datos", "Error en operación de base de datos.",
                        "DATABASE_ERROR", null));
    }

    @ExceptionHandler(FlujoNotFoundException.class)
    public ProblemDetail handleFlujoNotFound(FlujoNotFoundException ex) {
        log.warn("Flujo no encontrado: {}", ex.getMessage());
        return problem(HttpStatus.NOT_FOUND, "Flujo No Encontrado", ex.getMessage(), RECURSO_NO_ENCONTRADO,
                "https://capstone.local/errors/flujo-not-found");
    }

    @ExceptionHandler(FlujoConflictException.class)
    public ProblemDetail handleFlujoConflict(FlujoConflictException ex) {
        log.warn("Conflicto en flujo: {}", ex.getMessage());
        return problem(HttpStatus.CONFLICT, "Conflicto en Definición de Flujo", ex.getMessage(), ex.getCodigo(),
                "https://capstone.local/errors/flujo-conflict");
    }

    @ExceptionHandler(SolicitudNotFoundException.class)
    public ProblemDetail handleSolicitudNotFound(SolicitudNotFoundException ex) {
        log.warn("Solicitud no encontrada: {}", ex.getMessage());
        return problem(HttpStatus.NOT_FOUND, "Solicitud No Encontrada", ex.getMessage(), RECURSO_NO_ENCONTRADO,
                "https://capstone.local/errors/solicitud-not-found");
    }

    @ExceptionHandler(AlmacenamientoNoDisponibleException.class)
    public ProblemDetail handleAlmacenamientoNoDisponible(AlmacenamientoNoDisponibleException ex) {
        log.error("Almacenamiento de archivos no disponible: {}", ex.getMessage());
        return problem(HttpStatus.SERVICE_UNAVAILABLE, "Almacenamiento No Disponible",
                "No fue posible almacenar el archivo adjunto. Intente nuevamente más tarde.", "ALMACENAMIENTO_NO_DISPONIBLE",
                "https://capstone.local/errors/almacenamiento-no-disponible");
    }

    @ExceptionHandler(DocumentoNoDisponibleException.class)
    public ProblemDetail handleDocumentoNoDisponible(DocumentoNoDisponibleException ex) {
        log.warn("Documento no disponible: {}", ex.getMessage());
        String detail = (ex.getMessage() != null && !ex.getMessage().isBlank())
                ? ex.getMessage()
                : "El archivo no está disponible.";
        return problem(HttpStatus.NOT_FOUND, "Documento No Disponible", detail, "DOCUMENTO_NO_DISPONIBLE",
                "https://capstone.local/errors/documento-no-disponible");
    }

    @ExceptionHandler(InvalidTransitionException.class)
    public ProblemDetail handleInvalidTransition(InvalidTransitionException ex) {
        log.warn("Transición inválida: {}", ex.getMessage());
        return problem(HttpStatus.CONFLICT, "Transición de Estado Inválida", ex.getMessage(), "TRANSICION_INVALIDA",
                "https://capstone.local/errors/invalid-transition");
    }

    @ExceptionHandler(UnauthorizedActionException.class)
    public ProblemDetail handleUnauthorizedAction(UnauthorizedActionException ex) {
        log.warn("Acción no autorizada en flujo: {}", ex.getMessage());
        return problem(HttpStatus.FORBIDDEN, "Acción No Autorizada", ex.getMessage(), "RBAC_ACCION_DENEGADA",
                "https://capstone.local/errors/unauthorized-action");
    }

    @ExceptionHandler(InvalidDocumentFormatException.class)
    public ProblemDetail handleInvalidDocumentFormat(InvalidDocumentFormatException ex) {
        log.warn("Documento inválido: {}", ex.getMessage());
        return problem(HttpStatus.BAD_REQUEST, "Documento Inválido", ex.getMessage(), DATOS_INVALIDOS,
                "https://capstone.local/errors/invalid-document");
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ProblemDetail handleIllegalArgument(IllegalArgumentException ex) {
        log.warn("Solicitud inválida: {}", ex.getMessage());
        return problem(HttpStatus.BAD_REQUEST, "Solicitud Inválida", ex.getMessage(), DATOS_INVALIDOS,
                "https://capstone.local/errors/invalid-request");
    }

    @ExceptionHandler(SlaNotFoundException.class)
    public ProblemDetail handleSlaNotFound(SlaNotFoundException ex) {
        log.warn("Configuración SLA no encontrada: {}", ex.getMessage());
        return problem(HttpStatus.NOT_FOUND, "Regla SLA No Encontrada", ex.getMessage(), RECURSO_NO_ENCONTRADO,
                "https://capstone.local/errors/sla-not-found");
    }

    @ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(org.springframework.web.bind.MethodArgumentNotValidException ex) {
        log.warn("Error de validación en parámetros de entrada: {}", ex.getMessage());
        java.util.Map<String, String> invalidFields = new java.util.LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                invalidFields.putIfAbsent(error.getField(), error.getDefaultMessage())
        );
        ProblemDetail problem = problem(HttpStatus.BAD_REQUEST, "Error de validación",
                "Revisa los campos enviados e inténtalo nuevamente.", DATOS_INVALIDOS,
                "https://capstone.local/errors/validation-error");
        problem.setProperty("invalidFields", invalidFields);
        return problem;
    }

    @ExceptionHandler(org.springframework.http.converter.HttpMessageNotReadableException.class)
    public ProblemDetail handleHttpMessageNotReadable(org.springframework.http.converter.HttpMessageNotReadableException ex) {
        log.warn("Cuerpo de petición malformado o ilegible: {}", ex.getMessage());
        return problem(HttpStatus.BAD_REQUEST, "Cuerpo de solicitud inválido",
                "El cuerpo de la solicitud no es un JSON válido o contiene tipos de datos incorrectos.", DATOS_INVALIDOS,
                "https://capstone.local/errors/invalid-body");
    }

    @ExceptionHandler(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleTypeMismatch(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException ex) {
        log.warn("Tipo de dato de parámetro incompatible: {} = {}", ex.getName(), ex.getValue());
        ProblemDetail problem = problem(HttpStatus.BAD_REQUEST, "Parámetro inválido",
                String.format("El parámetro '%s' tiene un formato o tipo inválido: '%s'", ex.getName(), ex.getValue()),
                DATOS_INVALIDOS, "https://capstone.local/errors/invalid-parameter");
        problem.setProperty("parametro", ex.getName());
        return problem;
    }

    @ExceptionHandler(jakarta.validation.ConstraintViolationException.class)
    public ProblemDetail handleConstraintViolation(jakarta.validation.ConstraintViolationException ex) {
        log.warn("Violación de restricciones en parámetros: {}", ex.getMessage());
        java.util.Map<String, String> violations = new java.util.LinkedHashMap<>();
        ex.getConstraintViolations().forEach(v -> {
            String property = v.getPropertyPath() != null ? v.getPropertyPath().toString() : "param";
            violations.putIfAbsent(property, v.getMessage());
        });
        ProblemDetail problem = problem(HttpStatus.BAD_REQUEST, "Restricción de parámetro violada",
                "Uno o más parámetros no cumplen las restricciones requeridas.", DATOS_INVALIDOS,
                "https://capstone.local/errors/constraint-violation");
        problem.setProperty("violations", violations);
        return problem;
    }

    @ExceptionHandler(org.springframework.web.bind.MissingServletRequestParameterException.class)
    public ProblemDetail handleMissingServletRequestParameter(org.springframework.web.bind.MissingServletRequestParameterException ex) {
        log.warn("Parámetro requerido ausente: {}", ex.getParameterName());
        ProblemDetail problem = problem(HttpStatus.BAD_REQUEST, "Parámetro requerido ausente",
                String.format("El parámetro obligatorio '%s' no fue proporcionado en la solicitud.", ex.getParameterName()),
                DATOS_INVALIDOS, "https://capstone.local/errors/missing-parameter");
        problem.setProperty("parametro", ex.getParameterName());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.multipart.support.MissingServletRequestPartException.class)
    public ProblemDetail handleMissingServletRequestPart(org.springframework.web.multipart.support.MissingServletRequestPartException ex) {
        log.warn("Parte multipart requerida ausente: {}", ex.getRequestPartName());
        ProblemDetail problem = problem(HttpStatus.BAD_REQUEST, "Parte requerida ausente",
                String.format("La parte requerida '%s' no fue proporcionada en la solicitud multipart.", ex.getRequestPartName()),
                DATOS_INVALIDOS, "https://capstone.local/errors/missing-part");
        problem.setProperty("parte", ex.getRequestPartName());
        return problem;
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ProblemDetail handleMaxUploadSize(MaxUploadSizeExceededException ex) {
        log.warn("Tamaño de archivo excedido: {}", ex.getMessage());
        return problem(HttpStatus.BAD_REQUEST, "Tamaño de Archivo Excedido",
                "El tamaño del archivo excede el límite máximo permitido (10 MB)", "DOCUMENTO_TAMANO_EXCEDIDO",
                "https://capstone.local/errors/max-upload-size");
    }

    private static ProblemDetail problem(HttpStatus status, String title, String detail, String codigo, String type) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        if (type != null) problem.setType(URI.create(type));
        problem.setProperty("codigo", codigo);
        problem.setProperty("code", codigo);
        problem.setProperty("mensaje", detail);
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    /** Completa {@code codigo}/{@code mensaje} en los ProblemDetail del traductor de reglas de BD (que solo pone {@code code}). */
    private static ProblemDetail withCodigo(ProblemDetail problem) {
        java.util.Map<String, Object> props = problem.getProperties();
        Object code = props != null ? props.get("code") : null;
        if (code != null && (props.get("codigo") == null)) problem.setProperty("codigo", code);
        if (props == null || props.get("mensaje") == null) problem.setProperty("mensaje", problem.getDetail());
        if (props == null || props.get("timestamp") == null) problem.setProperty("timestamp", Instant.now());
        return problem;
    }
}
