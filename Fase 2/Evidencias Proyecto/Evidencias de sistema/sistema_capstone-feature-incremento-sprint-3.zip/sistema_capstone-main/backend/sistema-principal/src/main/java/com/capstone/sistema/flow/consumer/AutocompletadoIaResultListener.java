package com.capstone.sistema.flow.consumer;

import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.template.service.AutocompletadoIaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class AutocompletadoIaResultListener {

    private static final Logger log = LoggerFactory.getLogger(AutocompletadoIaResultListener.class);

    private final AutocompletadoIaService autocompletadoService;

    public AutocompletadoIaResultListener(AutocompletadoIaService autocompletadoService) {
        this.autocompletadoService = autocompletadoService;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.autocomplete.results.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = RabbitConfig.AI_AUTOCOMPLETE_RESULT_ROUTING_KEY
    ))
    public void onResultado(Map<String, Object> resultado) {
        log.info("Resultado de autocompletado con IA recibido: {} ({})", resultado.get("autocompletadoId"), resultado.get("status"));
        autocompletadoService.procesarResultado(resultado);
    }
}
