package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Solicitud;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SolicitudRepository extends JpaRepository<Solicitud, UUID>, JpaSpecificationExecutor<Solicitud> {

    @Override
    @EntityGraph(attributePaths = {"usuario", "estado"})
    Page<Solicitud> findAll(Specification<Solicitud> specification, Pageable pageable);

    @Query("SELECT s FROM Solicitud s WHERE s.usuario.id = :emisorId ORDER BY s.createdAt DESC")
    List<Solicitud> findByEmisor_IdOrderByCreatedAtDesc(@Param("emisorId") UUID emisorId);

    @Query("SELECT s FROM Solicitud s WHERE LOWER(s.estado.codigo) = LOWER(:codigo) ORDER BY s.createdAt DESC")
    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc(@Param("codigo") String codigo);

    @Query("SELECT s FROM Solicitud s WHERE LOWER(s.estado.codigo) = LOWER(:codigo) AND s.usuario.id <> :emisorId ORDER BY s.createdAt DESC")
    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseAndEmisor_IdNotOrderByCreatedAtDesc(@Param("codigo") String codigo, @Param("emisorId") UUID emisorId);

    @Query("SELECT s FROM Solicitud s WHERE (:flowId IS NULL OR s.flujoDefinicion.id = :flowId) AND UPPER(s.estado.codigo) NOT IN ('APROBADO','RECHAZADO') ORDER BY s.id")
    List<Solicitud> findOpenByFlow(@Param("flowId") Long flowId);

    long countByFlujoDefinicion_Id(Long flujoDefinicionId);

    boolean existsByFlujoDefinicion_Id(Long flujoDefinicionId);

    boolean existsByCorrelativo(String correlativo);

    boolean existsByTipoDocumento_Id(Long tipoDocumentoId);

    Optional<Solicitud> findByCorrelativoIgnoreCase(String correlativo);
}
