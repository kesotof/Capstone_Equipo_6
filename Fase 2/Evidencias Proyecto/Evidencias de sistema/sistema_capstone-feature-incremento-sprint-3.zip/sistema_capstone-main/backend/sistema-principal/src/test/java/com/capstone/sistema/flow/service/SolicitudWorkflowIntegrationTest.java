package com.capstone.sistema.flow.service;
import com.capstone.sistema.notificacion.controller.NotificacionController;
import com.capstone.sistema.notificacion.service.NotificacionService;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.doc.service.CorrelativoService;
import com.capstone.sistema.flow.exception.DatabaseRuleViolationTranslator;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.AccionTransicionRepository;
import com.capstone.sistema.flow.repository.EstadoSolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.model.enums.EstadoSolicitudEnum;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.model.view.VFlujoDisponibleUsuarioRepository;
import com.capstone.sistema.model.view.VRevisorSolicitudRepository;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SolicitudWorkflowIntegrationTest {

    private static DataSource dataSource;
    private static JdbcTemplate realJdbcTemplate;

    @BeforeAll
    static void setupDatabase() {
        dataSource = resolveDataSource();
        if (dataSource != null) {
            Flyway flyway = Flyway.configure()
                    .dataSource(dataSource)
                    .locations("classpath:db/migration")
                    .cleanDisabled(false)
                    .load();
            flyway.clean();
            flyway.migrate();
            realJdbcTemplate = new JdbcTemplate(dataSource);
        }
    }

    private static DataSource resolveDataSource() {
        String customUrl = System.getenv("TEST_DATASOURCE_URL");
        if (customUrl != null && !customUrl.isBlank()) {
            DriverManagerDataSource ds = new DriverManagerDataSource();
            ds.setDriverClassName("org.postgresql.Driver");
            ds.setUrl(customUrl);
            ds.setUsername(System.getenv().getOrDefault("TEST_DATASOURCE_USER", "sistema_user"));
            ds.setPassword(System.getenv().getOrDefault("TEST_DATASOURCE_PASS", "sistema_secure_pass"));
            return ds;
        }

        String[] candidateHosts = new String[]{"host.docker.internal", "localhost", "postgres"};
        for (String host : candidateHosts) {
            try {
                DriverManagerDataSource ds = new DriverManagerDataSource();
                ds.setDriverClassName("org.postgresql.Driver");
                ds.setUrl("jdbc:postgresql://" + host + ":5432/sistema_v5_test");
                ds.setUsername("sistema_user");
                ds.setPassword("sistema_secure_pass");
                try (Connection conn = ds.getConnection()) {
                    return ds;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    @Test
    @DisplayName("F3-01: Correlativo Concurrente en PostgreSQL - 20 hilos simultáneos generan correlativos únicos sin saltos")
    void testCorrelativoConcurrente20Hilos() throws InterruptedException {
        if (realJdbcTemplate == null) {
            System.out.println("Salteando testCorrelativoConcurrente20Hilos: Base PostgreSQL no disponible.");
            return;
        }

        CorrelativoService correlativoService = new CorrelativoService(realJdbcTemplate, Clock.systemUTC());

        Long tipoDocId = realJdbcTemplate.queryForObject(
                "SELECT id FROM tipo_documento LIMIT 1", Long.class);
        assertThat(tipoDocId).isNotNull();

        int numThreads = 20;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch finishLatch = new CountDownLatch(numThreads);
        Set<String> correlativosGenerados = Collections.newSetFromMap(new ConcurrentHashMap<>());
        List<Throwable> exceptions = Collections.synchronizedList(new ArrayList<>());

        for (int i = 0; i < numThreads; i++) {
            executor.submit(() -> {
                try {
                    startLatch.await();
                    String corr = correlativoService.siguienteCorrelativo(tipoDocId);
                    correlativosGenerados.add(corr);
                } catch (Throwable t) {
                    exceptions.add(t);
                } finally {
                    finishLatch.countDown();
                }
            });
        }

        startLatch.countDown();
        boolean completed = finishLatch.await(10, TimeUnit.SECONDS);
        executor.shutdown();

        assertThat(completed).isTrue();
        assertThat(exceptions).isEmpty();
        assertThat(correlativosGenerados).hasSize(numThreads);
    }

    @Test
    @DisplayName("F3-02: Función PostgreSQL es_revisor evalúa correctamente LISTA y JEFATURA_AREA_SOLICITUD con herencia")
    void testFuncionEsRevisorPostgres() {
        if (realJdbcTemplate == null) {
            System.out.println("Salteando testFuncionEsRevisorPostgres: Base PostgreSQL no disponible.");
            return;
        }

        Long areaPadreId = realJdbcTemplate.queryForObject(
                "INSERT INTO area (nombre, descripcion, activo) VALUES ('Gerencia Test', 'Padre', true) RETURNING id", Long.class);
        Long areaHijaId = realJdbcTemplate.queryForObject(
                "INSERT INTO area (nombre, descripcion, area_padre_id, activo) VALUES ('Finanzas Test', 'Hija', ?, true) RETURNING id", Long.class, areaPadreId);

        UUID jefeId = UUID.randomUUID();
        realJdbcTemplate.update("INSERT INTO usuario (id, email, rut, nombre, apellido, area_id, activo) " +
                "VALUES (?, 'jefe@test.local', '11111111-1', 'Jefe', 'Gerencia', ?, true)", jefeId, areaPadreId);

        UUID emisorId = UUID.randomUUID();
        realJdbcTemplate.update("INSERT INTO usuario (id, email, rut, nombre, apellido, area_id, activo) " +
                "VALUES (?, 'emisor@test.local', '22222222-2', 'Emisor', 'Finanzas', ?, true)", emisorId, areaHijaId);

        UUID revisorListaId = UUID.randomUUID();
        realJdbcTemplate.update("INSERT INTO usuario (id, email, rut, nombre, apellido, area_id, activo) " +
                "VALUES (?, 'revisor@test.local', '33333333-3', 'Revisor', 'Lista', ?, true)", revisorListaId, areaPadreId);

        realJdbcTemplate.update("INSERT INTO area_jefatura (area_id, usuario_id) VALUES (?, ?)", areaPadreId, jefeId);

        Long flujoId = realJdbcTemplate.queryForObject(
                "INSERT INTO flujo_definicion (nombre, area_id, activo, version) VALUES ('Flujo Test es_revisor', ?, true, 1) RETURNING id", Long.class, areaPadreId);
        Long etapa1Id = realJdbcTemplate.queryForObject(
                "INSERT INTO flujo_etapa (flujo_definicion_id, orden, nombre, modo_revisor) VALUES (?, 1, 'Etapa Jefe', 'JEFATURA_AREA_SOLICITUD') RETURNING id", Long.class, flujoId);
        Long etapa2Id = realJdbcTemplate.queryForObject(
                "INSERT INTO flujo_etapa (flujo_definicion_id, orden, nombre, modo_revisor) VALUES (?, 2, 'Etapa Lista', 'LISTA') RETURNING id", Long.class, flujoId);

        realJdbcTemplate.update("INSERT INTO flujo_etapa_revisor (flujo_etapa_id, usuario_id) VALUES (?, ?)", etapa2Id, revisorListaId);

        Long tipoDocId = realJdbcTemplate.queryForObject("SELECT id FROM tipo_documento LIMIT 1", Long.class);
        UUID solicitudId = UUID.randomUUID();
        realJdbcTemplate.update("INSERT INTO solicitud (id, correlativo, tipo_documento_id, flujo_definicion_id, flujo_etapa_id, usuario_id, area_id, titulo, estado) " +
                "VALUES (?, 'SOL-TEST-REV-01', ?, ?, ?, ?, ?, 'Solicitud Test Revisor', 'PENDIENTE_REVISION')",
                solicitudId, tipoDocId, flujoId, etapa1Id, emisorId, areaHijaId);

        Boolean esJefeRevisor = realJdbcTemplate.queryForObject(
                "SELECT es_revisor(?, ?, ?)", Boolean.class, solicitudId, etapa1Id, jefeId);
        assertThat(esJefeRevisor).isTrue();

        Boolean esEmisorRevisor = realJdbcTemplate.queryForObject(
                "SELECT es_revisor(?, ?, ?)", Boolean.class, solicitudId, etapa1Id, emisorId);
        assertThat(esEmisorRevisor).isFalse();

        // Avanzar la solicitud a Etapa 2 para verificar revisores en Modo LISTA
        realJdbcTemplate.update("UPDATE solicitud SET flujo_etapa_id = ? WHERE id = ?", etapa2Id, solicitudId);

        Boolean esRevisorLista = realJdbcTemplate.queryForObject(
                "SELECT es_revisor(?, ?, ?)", Boolean.class, solicitudId, etapa2Id, revisorListaId);
        assertThat(esRevisorLista).isTrue();

        Boolean esJefeEnLista = realJdbcTemplate.queryForObject(
                "SELECT es_revisor(?, ?, ?)", Boolean.class, solicitudId, etapa2Id, jefeId);
        assertThat(esJefeEnLista).isFalse();
    }

    @Test
    @DisplayName("F3-03: Flujo simple (1 etapa): registrar -> aprobar -> estado=APROBADO, historial completo")
    void testFlujoSimpleUnaEtapa() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        Clock fixedClock = Clock.fixed(Instant.parse("2026-10-16T12:00:00Z"), ZoneOffset.UTC);
        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, fixedClock
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@test.local", "11111111-1", "Emisor", "Test", area, true);
        UserAccount revisor = new UserAccount("kc-revisor", "revisor@test.local", "22222222-2", "Revisor", "Test", area, true);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo 1 Etapa", "Desc", area);
        ReflectionTestUtils.setField(flujo, "id", 10L);
        flujo.setActivo(true);

        FlujoEtapa etapa1 = new FlujoEtapa(flujo, 1, "Única Etapa");
        ReflectionTestUtils.setField(etapa1, "id", 101L);
        etapa1.setModoRevisor(ModoRevisor.LISTA);
        etapa1.getRevisores().add(revisor);

        TipoDocumento tipoDoc = new TipoDocumento(5L, "Memorándum", "Desc", "MEMO", 48);

        when(flujoRepo.findById(10L)).thenReturn(Optional.of(flujo));
        when(tipoRepo.findById(5L)).thenReturn(Optional.of(tipoDoc));
        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(10L, 1)).thenReturn(Optional.of(etapa1));
        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(10L, 2)).thenReturn(Optional.empty());
        when(correlativoService.siguienteCorrelativo(5L)).thenReturn("MEMO-2026-0001");
        Instant deadline = Instant.parse("2026-10-18T12:00:00Z");
        when(slaService.calculateDeadline(tipoDoc, fixedClock.instant())).thenReturn(deadline);
        when(slaService.isDentroSla(deadline, fixedClock.instant())).thenReturn(true);

        when(solRepo.saveAndFlush(any(Solicitud.class))).thenAnswer(inv -> inv.getArgument(0));
        when(solRepo.save(any(Solicitud.class))).thenAnswer(inv -> inv.getArgument(0));

        // 1. REGISTRAR
        SolicitudWorkflowService.RegistrarCommand cmd = new SolicitudWorkflowService.RegistrarCommand(
                "Mi Solicitud", "Descripción", 10L, 5L, emisor,
                "documento.pdf", "application/pdf", "storage/memo1.pdf", 1024L, "sha256hash", "v1", null, null
        );

        Solicitud solicitud = service.registrar(cmd);

        assertThat(solicitud.getCorrelativo()).isEqualTo("MEMO-2026-0001");
        assertThat(solicitud.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.PENDIENTE_REVISION.name());
        assertThat(solicitud.getFlujoEtapa()).isEqualTo(etapa1);

        // 2. APROBAR
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);
        solicitud.setLockVersion(0L);

        when(solRepo.findById(solId)).thenReturn(Optional.of(solicitud));
        when(jdbcTemplate.queryForObject(anyString(), any(Class.class), any(), any(), any())).thenReturn(true);

        Solicitud aprobada = service.aprobar(solId, revisor, "Aprobado sin reparos", 0L);

        assertThat(aprobada.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.APROBADO.name());
        assertThat(aprobada.getFlujoEtapa()).isEqualTo(etapa1);
        verify(auditService).registerEvent(org.mockito.ArgumentMatchers.eq("SOLICITUD_APROBADA"), org.mockito.ArgumentMatchers.eq(revisor), anyString());
    }

    @Test
    @DisplayName("F3-04: Flujo multicapa (3 etapas): avanzar etapa a etapa hasta aprobación final")
    void testFlujoMulticapaTresEtapas() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        Clock fixedClock = Clock.fixed(Instant.parse("2026-10-16T12:00:00Z"), ZoneOffset.UTC);
        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, fixedClock
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@test.local", "11111111-1", "Emisor", "Test", area, true);
        UserAccount revisor1 = new UserAccount("kc-rev1", "rev1@test.local", "22222222-2", "Rev1", "Test", area, true);
        UserAccount revisor2 = new UserAccount("kc-rev2", "rev2@test.local", "33333333-3", "Rev2", "Test", area, true);
        UserAccount revisor3 = new UserAccount("kc-rev3", "rev3@test.local", "44444444-4", "Rev3", "Test", area, true);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo 3 Etapas", "Desc", area);
        ReflectionTestUtils.setField(flujo, "id", 20L);
        flujo.setActivo(true);

        FlujoEtapa etapa1 = new FlujoEtapa(flujo, 1, "Etapa 1");
        ReflectionTestUtils.setField(etapa1, "id", 201L);
        FlujoEtapa etapa2 = new FlujoEtapa(flujo, 2, "Etapa 2");
        ReflectionTestUtils.setField(etapa2, "id", 202L);
        FlujoEtapa etapa3 = new FlujoEtapa(flujo, 3, "Etapa 3");
        ReflectionTestUtils.setField(etapa3, "id", 203L);

        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(20L, 2)).thenReturn(Optional.of(etapa2));
        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(20L, 3)).thenReturn(Optional.of(etapa3));
        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(20L, 4)).thenReturn(Optional.empty());

        when(jdbcTemplate.queryForObject(anyString(), any(Class.class), any(), any(), any())).thenReturn(true);
        when(solRepo.save(any(Solicitud.class))).thenAnswer(inv -> inv.getArgument(0));

        UUID solId = UUID.randomUUID();
        Solicitud solicitud = new Solicitud(flujo, emisor, "Solicitud 3 Etapas", "Desc",
                new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name()), etapa1);
        ReflectionTestUtils.setField(solicitud, "id", solId);
        solicitud.setCorrelativo("SOL-3E-01");
        solicitud.setLockVersion(0L);
        when(solRepo.findById(solId)).thenReturn(Optional.of(solicitud));

        // 1. Aprobar etapa 1 -> debe pasar a etapa 2, estado PENDIENTE_REVISION
        Solicitud enEtapa2 = service.aprobar(solId, revisor1, "Pasa etapa 1", 0L);
        assertThat(enEtapa2.getFlujoEtapa()).isEqualTo(etapa2);
        assertThat(enEtapa2.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.PENDIENTE_REVISION.name());

        // 2. Aprobar etapa 2 -> debe pasar a etapa 3, estado PENDIENTE_REVISION
        solicitud.setLockVersion(1L);
        Solicitud enEtapa3 = service.aprobar(solId, revisor2, "Pasa etapa 2", 1L);
        assertThat(enEtapa3.getFlujoEtapa()).isEqualTo(etapa3);
        assertThat(enEtapa3.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.PENDIENTE_REVISION.name());

        // 3. Aprobar etapa 3 -> etapa final -> estado APROBADO
        solicitud.setLockVersion(2L);
        Solicitud aprobadaFinal = service.aprobar(solId, revisor3, "Aprobación final", 2L);
        assertThat(aprobadaFinal.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.APROBADO.name());
        assertThat(aprobadaFinal.getFlujoEtapa()).isEqualTo(etapa3);
    }

    @Test
    @DisplayName("F3-05: Ciclo de corrección - solicitar corrección -> corregir: incrementa versión del documento y PRESERVA fecha_limite_sla (P7)")
    void testCicloCorreccionPreservaSla() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        Clock fixedClock = Clock.fixed(Instant.parse("2026-10-16T12:00:00Z"), ZoneOffset.UTC);
        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, fixedClock
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@test.local", "11111111-1", "Emisor", "Test", area, true);
        UserAccount revisor = new UserAccount("kc-revisor", "revisor@test.local", "22222222-2", "Revisor", "Test", area, true);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc", area);
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        ReflectionTestUtils.setField(etapa, "id", 301L);

        Instant originalDeadline = Instant.parse("2026-10-20T18:00:00Z");

        UUID solId = UUID.randomUUID();
        Solicitud solicitud = new Solicitud(flujo, emisor, "Solicitud para Corrección", "Desc",
                new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name()), etapa);
        ReflectionTestUtils.setField(solicitud, "id", solId);
        solicitud.setCorrelativo("SOL-CORR-01");
        solicitud.setDeadline(originalDeadline);
        solicitud.setLockVersion(0L);

        when(solRepo.findById(solId)).thenReturn(Optional.of(solicitud));
        when(solRepo.save(any(Solicitud.class))).thenAnswer(inv -> inv.getArgument(0));
        when(jdbcTemplate.queryForObject(anyString(), any(Class.class), any(), any(), any())).thenReturn(true);
        Documento docV1 = new Documento(
                null,
                null,
                1,
                "documento_v1.pdf",
                "application/pdf",
                "storage/doc_v1.pdf",
                1024L,
                "sha256v1hash",
                "s3-version-1",
                null,
                null
        );
        when(docRepo.findBySolicitud_IdOrderByVersionDesc(solId)).thenReturn(List.of(docV1));

        // 1. Revisor solicita corrección
        Solicitud enCorreccion = service.solicitarCorreccion(solId, revisor, "Favor adjuntar documento firmado", 0L);
        assertThat(enCorreccion.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.CORRECCION_REQUERIDA.name());
        assertThat(enCorreccion.getDeadline()).isEqualTo(originalDeadline); // SLA inalterada

        // 2. Emisor corrige adjuntando versión corregida
        solicitud.setLockVersion(1L);
        SolicitudWorkflowService.CorregirCommand cmd = new SolicitudWorkflowService.CorregirCommand(
                solId,
                emisor,
                "Se adjunta documento corregido y firmado",
                "documento_v2.pdf",
                "application/pdf",
                "storage/doc_v2.pdf",
                2048L,
                "sha256v2hash",
                "s3-version-2",
                null,
                null,
                1L
        );
        Solicitud corregida = service.corregir(cmd);

        assertThat(corregida.getEstadoSolicitud().getCodigo()).isEqualTo(EstadoSolicitudEnum.PENDIENTE_REVISION.name());
        assertThat(corregida.getDeadline()).isEqualTo(originalDeadline); // REGLA P7: SLA INALTERADA

        ArgumentCaptor<Documento> docCaptor = ArgumentCaptor.forClass(Documento.class);
        verify(docRepo).save(docCaptor.capture());
        Documento savedDoc = docCaptor.getValue();
        assertThat(savedDoc.getVersion()).isEqualTo(2); // Versión incrementada de 1 a 2
        assertThat(savedDoc.getChecksumSha256()).isEqualTo("sha256v2hash");
    }

    @Test
    @DisplayName("F3-06: Auto-revisión prohibida - un usuario emisor no puede aprobar su propia solicitud si no es revisor")
    void testAutoRevisionProhibida() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, Clock.systemUTC()
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@test.local", "11111111-1", "Emisor", "Test", area, true);
        UUID emisorId = UUID.randomUUID();
        ReflectionTestUtils.setField(emisor, "id", emisorId);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc", area);
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        ReflectionTestUtils.setField(etapa, "id", 401L);

        UUID solId = UUID.randomUUID();
        Solicitud solicitud = new Solicitud(flujo, emisor, "Solicitud Propia", "Desc",
                new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name()), etapa);
        ReflectionTestUtils.setField(solicitud, "id", solId);
        solicitud.setLockVersion(0L);

        when(solRepo.findById(solId)).thenReturn(Optional.of(solicitud));
        when(jdbcTemplate.queryForObject(anyString(), any(Class.class), any(), any(), any())).thenReturn(false);

        assertThatThrownBy(() -> service.aprobar(solId, emisor, "Intento de auto-aprobar", 0L))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("no tiene atribuciones");
    }

    @Test
    @DisplayName("F3-07: Conflicto de versión optimista - 409 CONFLICT cuando expectedVersion no coincide con lock_version")
    void testConflictoVersionOptimista() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, Clock.systemUTC()
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount actor = new UserAccount("kc-rev", "rev@test.local", "11111111-1", "Rev", "Test", area, true);
        ReflectionTestUtils.setField(actor, "id", UUID.randomUUID());

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc", area);
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");

        UUID solId = UUID.randomUUID();
        Solicitud solicitud = new Solicitud(flujo, actor, "Solicitud Concurrente", "Desc",
                new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name()), etapa);
        ReflectionTestUtils.setField(solicitud, "id", solId);
        solicitud.setLockVersion(5L);

        when(solRepo.findById(solId)).thenReturn(Optional.of(solicitud));

        assertThatThrownBy(() -> service.aprobar(solId, actor, "Aprobar", 4L))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Conflicto de versión");
    }

    @Test
    @DisplayName("F3-08: Prevención de etapa huérfana - Si la etapa 1 no tiene revisores configurados, registrar lanza 422")
    void testPrevencionEtapaHuerfana() {
        SolicitudRepository solRepo = mock(SolicitudRepository.class);
        DocumentoRepository docRepo = mock(DocumentoRepository.class);
        HistorialTransicionRepository histRepo = mock(HistorialTransicionRepository.class);
        EstadoSolicitudRepository estadoRepo = mock(EstadoSolicitudRepository.class);
        AccionTransicionRepository accionRepo = mock(AccionTransicionRepository.class);
        FlujoDefinicionRepository flujoRepo = mock(FlujoDefinicionRepository.class);
        FlujoEtapaRepository etapaRepo = mock(FlujoEtapaRepository.class);
        TipoDocumentoRepository tipoRepo = mock(TipoDocumentoRepository.class);
        VRevisorSolicitudRepository revRepo = mock(VRevisorSolicitudRepository.class);
        VFlujoDisponibleUsuarioRepository flujoDispRepo = mock(VFlujoDisponibleUsuarioRepository.class);
        CorrelativoService correlativoService = mock(CorrelativoService.class);
        SlaService slaService = mock(SlaService.class);
        NotificacionService notificacionService = mock(NotificacionService.class);
        AuditService auditService = mock(AuditService.class);
        DatabaseRuleViolationTranslator translator = new DatabaseRuleViolationTranslator();
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        SolicitudWorkflowService service = new SolicitudWorkflowService(
                solRepo, docRepo, histRepo, estadoRepo, accionRepo, flujoRepo, etapaRepo,
                tipoRepo, revRepo, flujoDispRepo, correlativoService, slaService,
                notificacionService, auditService, translator, jdbcTemplate, Clock.systemUTC()
        );

        Area area = new Area(1L, "Operaciones", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@test.local", "11111111-1", "Emisor", "Test", area, true);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Sin Revisores", "Desc", area);
        ReflectionTestUtils.setField(flujo, "id", 50L);
        flujo.setActivo(true);

        FlujoEtapa etapa1 = new FlujoEtapa(flujo, 1, "Etapa Vacía");
        etapa1.setModoRevisor(ModoRevisor.LISTA);
        etapa1.getRevisores().clear();

        TipoDocumento tipoDoc = new TipoDocumento(5L, "Memorándum", "Desc", "MEMO", 48);

        when(flujoRepo.findById(50L)).thenReturn(Optional.of(flujo));
        when(tipoRepo.findById(5L)).thenReturn(Optional.of(tipoDoc));
        when(etapaRepo.findByFlujoDefinicion_IdAndOrden(50L, 1)).thenReturn(Optional.of(etapa1));

        SolicitudWorkflowService.RegistrarCommand cmd = new SolicitudWorkflowService.RegistrarCommand(
                "Solicitud Huérfana", "Desc", 50L, 5L, emisor,
                null, null, null, null, null, null, null, null
        );

        assertThatThrownBy(() -> service.registrar(cmd))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("no cuenta con revisores activos");
    }
}
