package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.notificacion.dto.MensajeNotificacion;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * F3 (§6.1): fábrica de textos de notificación por rol y evento (US-36). Es la única
 * fuente de títulos, mensajes, enlaces y etiquetas de botón; los textos se limitan a la
 * columna: título hasta 255 caracteres y la observación se trunca a 300 con «…».
 *
 * <p>Los enlaces guardan la <strong>ruta relativa</strong>; la URL absoluta del correo se
 * arma con {@code app.frontend-base-url + enlace} (CA 10.4).</p>
 */
@Component
public class NotificacionMensajeFactory {

    /** §6.1: plazo en America/Santiago con el formato pedido por el plan. */
    static final DateTimeFormatter DEADLINE_FMT =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm").withZone(ZoneId.of("America/Santiago"));

    private static final int MAX_TITULO = 255;
    private static final int MAX_OBSERVACION = 300;

    public MensajeNotificacion construir(String tipo, NotificacionContexto ctx) {
        return switch (tipo) {
            case "REVISION_ASIGNADA" -> revisionAsignada(ctx);
            case "SOLICITUD_AVANZA" -> new MensajeNotificacion(
                    titulo(ctx, "avanzó a " + orDash(ctx.etapaDestino())),
                    ctx.nombreActor() + " aprobó la etapa " + orDash(ctx.etapaOrigen()) + ".",
                    enlace(ctx, null),
                    "Ver solicitud");
            case "SOLICITUD_APROBADA" -> new MensajeNotificacion(
                    titulo(ctx, "fue aprobada"),
                    "«" + ctx.tituloSolicitud() + "» completó su flujo de aprobación.",
                    enlace(ctx, null),
                    "Ver solicitud");
            case "SOLICITUD_RECHAZADA" -> new MensajeNotificacion(
                    titulo(ctx, "fue rechazada"),
                    ctx.nombreActor() + " rechazó «" + ctx.tituloSolicitud() + "». Motivo: "
                            + observacion(ctx),
                    enlace(ctx, null),
                    "Ver solicitud");
            case "CORRECCION_REQUERIDA" -> new MensajeNotificacion(
                    titulo(ctx, "requiere correcciones"),
                    ctx.nombreActor() + " pidió corregir «" + ctx.tituloSolicitud()
                            + "». Observación: " + observacion(ctx),
                    enlace(ctx, "corregir"),
                    "Corregir solicitud");
            case "DECISION_ADMIN_GLOBAL" -> new MensajeNotificacion(
                    limitarTitulo("El administrador decidió sobre " + orDash(ctx.correlativo())),
                    ctx.nombreActor() + " " + verbo(ctx.accion()) + " «" + ctx.tituloSolicitud()
                            + "» en tu lugar.",
                    enlace(ctx, null),
                    "Ver solicitud");
            case "PLAZO_POR_VENCER" -> new MensajeNotificacion(
                    limitarTitulo(orDash(ctx.correlativo()) + " vence en menos de 24 horas"),
                    "«" + ctx.tituloSolicitud() + "» debe revisarse antes del " + fecha(ctx) + ".",
                    enlace(ctx, "revisar"),
                    "Revisar solicitud");
            case "PLAZO_VENCIDO" -> new MensajeNotificacion(
                    limitarTitulo(orDash(ctx.correlativo()) + " venció su plazo de revisión"),
                    "El plazo de «" + ctx.tituloSolicitud() + "» venció el " + fecha(ctx) + ".",
                    enlace(ctx, "revisar"),
                    "Revisar solicitud");
            default -> throw new IllegalArgumentException("Tipo de notificación desconocido: " + tipo);
        };
    }

    /** REVISION_ASIGNADA: REGISTRAR/APROBAR envían el documento; CORREGIR lo devuelve corregido. */
    private MensajeNotificacion revisionAsignada(NotificacionContexto ctx) {
        String titulo = limitarTitulo("Tienes una solicitud por revisar"
                + (ctx.correlativo() != null ? ": " + ctx.correlativo() : ""));
        String mensaje;
        if ("CORREGIR".equals(ctx.accion())) {
            mensaje = ctx.nombreEmisor() + " corrigió «" + ctx.tituloSolicitud()
                    + "» y vuelve a tu revisión." + plazo(ctx);
        } else {
            mensaje = ctx.nombreEmisor() + " envió «" + ctx.tituloSolicitud() + "» ("
                    + orDash(ctx.tipoDocumento()) + "). Etapa: " + orDash(ctx.etapaDestino()) + "."
                    + plazo(ctx);
        }
        return new MensajeNotificacion(titulo, mensaje, enlace(ctx, "revisar"), "Revisar solicitud");
    }

    private String plazo(NotificacionContexto ctx) {
        return ctx.deadline() != null ? " Plazo: " + fecha(ctx) + "." : "";
    }

    private String fecha(NotificacionContexto ctx) {
        return ctx.deadline() != null ? DEADLINE_FMT.format(ctx.deadline()) : "—";
    }

    /** Título con el correlativo adelante; si no existe, usa una frase sin él. */
    private String titulo(NotificacionContexto ctx, String sufijo) {
        return limitarTitulo(ctx.correlativo() != null
                ? ctx.correlativo() + " " + sufijo
                : "La solicitud " + sufijo);
    }

    private String enlace(NotificacionContexto ctx, String accion) {
        String base = "/solicitudes/" + ctx.solicitudId();
        return accion != null ? base + "?accion=" + accion : base;
    }

    private String verbo(String accion) {
        return switch (accion) {
            case "APROBAR" -> "aprobó";
            case "RECHAZAR" -> "rechazó";
            case "SOLICITAR_CORRECCION", "PEDIR_CORRECCION" -> "pidió corregir";
            default -> "actuó sobre";
        };
    }

    /** §6.1: la observación se trunca a 300 caracteres con «…». */
    private String observacion(NotificacionContexto ctx) {
        String obs = ctx.observacion() != null && !ctx.observacion().isBlank()
                ? ctx.observacion()
                : "Sin observación";
        return obs.length() > MAX_OBSERVACION ? obs.substring(0, MAX_OBSERVACION) + "…" : obs;
    }

    private String limitarTitulo(String titulo) {
        return titulo != null && titulo.length() > MAX_TITULO
                ? titulo.substring(0, MAX_TITULO - 1) + "…"
                : titulo;
    }

    private String orDash(String valor) {
        return valor != null && !valor.isBlank() ? valor : "—";
    }
}
