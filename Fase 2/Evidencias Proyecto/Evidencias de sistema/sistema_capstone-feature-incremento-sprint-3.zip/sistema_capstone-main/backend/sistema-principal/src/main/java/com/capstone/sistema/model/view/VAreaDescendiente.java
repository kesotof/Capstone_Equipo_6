package com.capstone.sistema.model.view;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

@Entity
@Table(name = "v_area_descendiente")
@Immutable
public class VAreaDescendiente {

    @EmbeddedId
    private VAreaDescendienteId id;

    protected VAreaDescendiente() {
    }

    public VAreaDescendiente(Long ancestroId, Long areaId) {
        this.id = new VAreaDescendienteId(ancestroId, areaId);
    }

    public VAreaDescendienteId getId() {
        return id;
    }

    public Long getAncestroId() {
        return id != null ? id.getAncestroId() : null;
    }

    public Long getAreaId() {
        return id != null ? id.getAreaId() : null;
    }
}
