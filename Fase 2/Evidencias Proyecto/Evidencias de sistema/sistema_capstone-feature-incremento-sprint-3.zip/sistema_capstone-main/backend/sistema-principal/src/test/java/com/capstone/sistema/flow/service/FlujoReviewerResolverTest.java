package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.TipoAsignacionRevisor;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FlujoReviewerResolverTest {

    @Mock
    private RbacAccessService access;

    @Mock
    private UserAccountRepository users;

    @Mock
    private JdbcTemplate jdbc;

    private FlujoReviewerResolver resolver;
    private FlujoDefinicion flow;

    @BeforeEach
    void setUp() {
        resolver = new FlujoReviewerResolver(access, users, jdbc);
        flow = new FlujoDefinicion("Contratos", "Flujo de prueba");
    }

    private static UserAccount usuario(String email, String first, String last) {
        UserAccount u = new UserAccount("kc-" + email, email, first, last, true);
        u.setId(UUID.randomUUID());
        return u;
    }

    @Test
    void assignListaVaciaLanzaFlujoEtapaHuerfana() {
        FlujoEtapa etapa = new FlujoEtapa(flow, 1, "Revisión");

        assertThatThrownBy(() -> resolver.assign(etapa, TipoAsignacionRevisor.USUARIO, List.of()))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("FLUJO_ETAPA_HUERFANA"));
    }

    @Test
    void assignRevisorInactivoLanzaUsuarioInactivo() {
        UserAccount inactivo = usuario("inactivo@capstone.local", "Inac", "Tivo");
        FlujoEtapa etapa = new FlujoEtapa(flow, 1, "Revisión");

        when(users.findById(inactivo.getId())).thenReturn(Optional.of(inactivo));
        when(access.eligibleReviewer(inactivo)).thenReturn(false);

        assertThatThrownBy(() -> resolver.assign(etapa, TipoAsignacionRevisor.USUARIO, List.of(inactivo.getId())))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("USUARIO_INACTIVO"))
                .hasMessageContaining("está inactivo");
    }

    @Test
    void assignEtapaJefaturaLanzaFlujoBaseProtegido() {
        FlujoEtapa etapa = new FlujoEtapa(flow, 1, "Revisión", ModoRevisor.JEFATURA_AREA_SOLICITUD);

        assertThatThrownBy(() -> resolver.assign(etapa, TipoAsignacionRevisor.USUARIO, List.of(UUID.randomUUID())))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("FLUJO_BASE_PROTEGIDO"));
    }

    @Test
    void assignDosRevisoresSeGuardanOrdenadosPorNombre() {
        UserAccount zeta = usuario("zeta@capstone.local", "Zoe", "Zapata");
        UserAccount alfa = usuario("alfa@capstone.local", "Ana", "Alvarez");
        FlujoEtapa etapa = new FlujoEtapa(flow, 1, "Revisión");

        when(users.findById(zeta.getId())).thenReturn(Optional.of(zeta));
        when(users.findById(alfa.getId())).thenReturn(Optional.of(alfa));
        when(access.eligibleReviewer(zeta)).thenReturn(true);
        when(access.eligibleReviewer(alfa)).thenReturn(true);

        resolver.assign(etapa, TipoAsignacionRevisor.USUARIO, List.of(zeta.getId(), alfa.getId()));

        assertThat(etapa.getRevisoresOrdenados()).containsExactly(alfa, zeta);
        assertThat(etapa.getRevisores()).containsExactlyInAnyOrder(alfa, zeta);
    }
}
