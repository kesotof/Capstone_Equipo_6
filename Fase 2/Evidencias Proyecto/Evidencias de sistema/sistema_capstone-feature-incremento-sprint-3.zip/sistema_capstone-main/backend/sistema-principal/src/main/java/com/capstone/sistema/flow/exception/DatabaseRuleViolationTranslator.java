package com.capstone.sistema.flow.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Optional;

@Component
public class DatabaseRuleViolationTranslator {

    /**
     * Traduce códigos de error SQLSTATE de PostgreSQL (especialmente CB001-CB014 y 23514)
     * a ProblemDetail RFC 7807 según el diseño de Modelo v5 (§5.3 y §6).
     */
    public Optional<ProblemDetail> translate(Throwable throwable) {
        if (throwable == null) {
            return Optional.empty();
        }

        SQLException sqlEx = findSqlException(throwable);
        if (sqlEx == null) {
            if (throwable instanceof org.springframework.orm.ObjectOptimisticLockingFailureException
                    || throwable instanceof jakarta.persistence.OptimisticLockException) {
                ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.CONFLICT,
                        "El recurso cambió concurrentemente. Recargue antes de volver a intentar."
                );
                problem.setTitle("Conflicto de versión");
                problem.setType(URI.create("https://capstone.local/errors/version-conflict"));
                problem.setProperty("code", "SOLICITUD_VERSION_CONFLICTO");
                problem.setProperty("codigo", "SOLICITUD_VERSION_CONFLICTO");
                problem.setProperty("timestamp", Instant.now());
                return Optional.of(problem);
            }
            return Optional.empty();
        }

        String sqlState = sqlEx.getSQLState();
        String message = sqlEx.getMessage();
        if (sqlState == null) {
            return Optional.empty();
        }

        ProblemDetail problem = null;

        switch (sqlState) {
            case "CB001":
            case "CB002":
            case "CB003":
            case "CB004":
            case "CB008":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Violación de inmutabilidad en la base de datos: " + extractCleanMessage(message)
                );
                problem.setTitle("Violación de Inmutabilidad");
                problem.setProperty("code", "DATABASE_INMUTABILIDAD_VIOLADA");
                break;

            case "CB006":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.CONFLICT,
                        "El flujo o sus etapas ya registran solicitudes activas y no pueden modificarse destructivamente."
                );
                problem.setTitle("Flujo en Uso");
                problem.setProperty("code", "RBAC_DEPENDENCIA_REVISION");
                break;

            case "CB007":
            case "CB010":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Inconsistencia en datos de origen o etapa ajena de la solicitud."
                );
                problem.setTitle("Error de Integridad Transaccional");
                problem.setProperty("code", "DATABASE_INTEGRIDAD_ORIGEN");
                break;

            case "CB011":
            case "CB012":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.FORBIDDEN,
                        "El usuario no tiene atribuciones válidas de revisor para ejecutar esta acción en la etapa actual."
                );
                problem.setTitle("Acción Denegada");
                problem.setProperty("code", "RBAC_ACCION_DENEGADA");
                break;

            case "CB013":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.BAD_REQUEST,
                        "El rol tiene un ámbito incompatible con la asignación solicitada."
                );
                problem.setTitle("Ámbito Incompatible");
                problem.setProperty("code", "ROL_AMBITO_INCOMPATIBLE");
                break;

            case "CB014":
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.CONFLICT,
                        "No se permite modificar o eliminar un rol protegido del sistema."
                );
                problem.setTitle("Rol Protegido");
                problem.setProperty("code", "RBAC_ROL_PROTEGIDO");
                break;

            case "23514": // CHECK constraint violation
                if (message != null && (message.toLowerCase().contains("observacion") || message.toLowerCase().contains("comentario"))) {
                    problem = ProblemDetail.forStatusAndDetail(
                            HttpStatus.BAD_REQUEST,
                            "Es obligatorio indicar una observación o motivo para esta acción."
                    );
                    problem.setTitle("Observación Obligatoria");
                    problem.setProperty("code", "OBSERVACION_REQUERIDA");
                } else {
                    problem = ProblemDetail.forStatusAndDetail(
                            HttpStatus.CONFLICT,
                            "La transición solicitada no está permitida por la máquina de estados: " + extractCleanMessage(message)
                    );
                    problem.setTitle("Transición Inválida");
                    problem.setProperty("code", "TRANSICION_INVALIDA");
                }
                break;

            case "23505": // Unique constraint
                problem = ProblemDetail.forStatusAndDetail(
                        HttpStatus.CONFLICT,
                        "Ya existe un registro con los mismos identificadores únicos: " + extractCleanMessage(message)
                );
                problem.setTitle("Conflicto de Unicidad");
                problem.setProperty("code", "REGISTRO_DUPLICADO");
                break;

            default:
                break;
        }

        if (problem != null) {
            problem.setType(URI.create("https://capstone.local/errors/" + sqlState.toLowerCase()));
            problem.setProperty("sqlState", sqlState);
            problem.setProperty("timestamp", Instant.now());
            if (problem.getProperties() != null && problem.getProperties().containsKey("code")) {
                problem.setProperty("codigo", problem.getProperties().get("code"));
            }
            return Optional.of(problem);
        }

        return Optional.empty();
    }

    public RuntimeException translateToException(Throwable throwable) {
        Optional<ProblemDetail> problemOpt = translate(throwable);
        if (problemOpt.isPresent()) {
            ProblemDetail pd = problemOpt.get();
            HttpStatus status = HttpStatus.valueOf(pd.getStatus());
            return new ResponseStatusException(status, pd.getDetail(), throwable);
        }
        if (throwable instanceof RuntimeException re) {
            return re;
        }
        return new RuntimeException(throwable);
    }

    private SQLException findSqlException(Throwable throwable) {
        Throwable current = throwable;
        while (current != null) {
            if (current instanceof SQLException sqle) {
                return sqle;
            }
            current = current.getCause();
        }
        return null;
    }

    private String extractCleanMessage(String raw) {
        if (raw == null) return "";
        int colon = raw.indexOf("ERROR: ");
        if (colon >= 0) {
            int newline = raw.indexOf("\n", colon);
            if (newline > colon) {
                return raw.substring(colon + 7, newline).trim();
            }
            return raw.substring(colon + 7).trim();
        }
        return raw.trim();
    }
}
