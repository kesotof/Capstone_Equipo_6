package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.EstadoAnalisis;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/** Análisis de IA; {@code documentoVigente} indica si evaluó la versión actual del documento de la solicitud. */
public record AiAnalysisResponse(
        UUID id,
        UUID solicitudId,
        UUID documentoId,
        EstadoAnalisis estado,
        Integer puntaje,
        Boolean valido,
        String observaciones,
        List<String> recomendaciones,
        String modeloUsado,
        String promptUtilizado,
        boolean cached,
        Instant createdAt,
        Instant completedAt,
        Integer documentoVersion,
        String documentoNombre,
        boolean documentoVigente
) {
}
