-- Tareas de autocompletado con IA del formulario de una plantilla. Se registran aparte de ai_analysis
-- porque todavía no existe la solicitud: el emisor está completando el formulario.
CREATE TABLE ia_autocompletado (
    id                   UUID         DEFAULT gen_random_uuid() PRIMARY KEY,
    plantilla_version_id BIGINT       NOT NULL REFERENCES plantilla_version(id) ON DELETE CASCADE,
    usuario_id           UUID         NOT NULL REFERENCES usuario(id),
    estado               VARCHAR(30)  DEFAULT 'PENDIENTE' NOT NULL CHECK (estado IN ('PENDIENTE', 'COMPLETADO', 'ERROR')),
    nombre_archivo       VARCHAR(255),
    storage_key          VARCHAR(500),
    indicaciones         TEXT,
    sugerencias          JSONB,
    mensaje              TEXT,
    modelo_usado         VARCHAR(100),
    created_at           TIMESTAMPTZ  DEFAULT now() NOT NULL,
    completed_at         TIMESTAMPTZ,
    CONSTRAINT ia_autocompletado_origen CHECK (storage_key IS NOT NULL OR indicaciones IS NOT NULL)
);
CREATE INDEX idx_ia_autocompletado_version ON ia_autocompletado (plantilla_version_id);
CREATE INDEX idx_ia_autocompletado_usuario ON ia_autocompletado (usuario_id);
