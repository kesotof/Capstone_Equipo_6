package com.capstone.sistema.rbac.service;

import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.model.Alcance;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Capa de compatibilidad transitoria (hasta F14) según Sección 7.2 del Modelo v5.
 * Traduce el modelo de permisos v2 (recursos .VER, .GESTIONAR, .CREAR y capacidades)
 * a la estructura de Grants y Alcances legados consumida por el frontend v1.
 */
@Component
public class LegacyAccessTranslator {

    public Me translate(MeV2 v2) {
        if (v2 == null) {
            return null;
        }

        List<ContextRole> contextRoles = v2.roles().stream()
                .map(r -> new ContextRole(r.rolId(), r.codigo(), r.nombre(), r.origen() != null ? r.origen() : "ASIGNADO"))
                .toList();

        List<AreaItem> managedAreas = new ArrayList<>();
        Set<Long> registeredAreaIds = new HashSet<>();
        if (v2.jefaturas() != null) {
            for (JefaturaItem j : v2.jefaturas()) {
                if (registeredAreaIds.add(j.areaId())) {
                    managedAreas.add(new AreaItem(j.areaId(), j.nombre()));
                }
            }
        }

        Map<String, PermisoItemV2> permisosMap = new HashMap<>();
        if (v2.permisos() != null) {
            for (PermisoItemV2 p : v2.permisos()) {
                permisosMap.put(p.codigo().toUpperCase(), p);
            }
        }

        List<Grant> grants = new ArrayList<>();

        // 1. SOLICITUD_CONSULTAR, HISTORIAL, OBSERVACION, IA
        Set<Alcance> solConsultarAlcances = new LinkedHashSet<>();
        solConsultarAlcances.add(Alcance.PROPIAS);
        if (permisosMap.containsKey("SOLICITUD.VER")) {
            PermisoItemV2 p = permisosMap.get("SOLICITUD.VER");
            if (p.areas() == null || v2.administradorSistema()) {
                solConsultarAlcances.add(Alcance.GLOBAL);
            } else {
                solConsultarAlcances.add(Alcance.AREA);
            }
        }
        if (v2.capacidades().esRevisor()) {
            solConsultarAlcances.add(Alcance.ASIGNADAS);
        }
        grants.add(new Grant("SOLICITUD_CONSULTAR", new ArrayList<>(solConsultarAlcances)));
        grants.add(new Grant("HISTORIAL_CONSULTAR", new ArrayList<>(solConsultarAlcances)));
        grants.add(new Grant("OBSERVACION_CONSULTAR", new ArrayList<>(solConsultarAlcances)));
        grants.add(new Grant("IA_CONSULTAR", new ArrayList<>(solConsultarAlcances)));

        // 2. DOCUMENTO_DESCARGAR
        Set<Alcance> docDescargarAlcances = new LinkedHashSet<>();
        docDescargarAlcances.add(Alcance.PROPIAS);
        if (v2.capacidades().esRevisor()) {
            docDescargarAlcances.add(Alcance.ASIGNADAS);
        }
        if (permisosMap.containsKey("DOCUMENTO.DESCARGAR")) {
            PermisoItemV2 p = permisosMap.get("DOCUMENTO.DESCARGAR");
            if (p.areas() == null || v2.administradorSistema()) {
                docDescargarAlcances.add(Alcance.GLOBAL);
            } else {
                docDescargarAlcances.add(Alcance.AREA);
            }
        }
        grants.add(new Grant("DOCUMENTO_DESCARGAR", new ArrayList<>(docDescargarAlcances)));

        // 3. SOLICITUD_CREAR y SOLICITUD_REENVIAR
        if (v2.capacidades().puedeEmitir()) {
            grants.add(new Grant("SOLICITUD_CREAR", List.of(Alcance.PROPIAS, Alcance.AREA)));
            grants.add(new Grant("SOLICITUD_REENVIAR", List.of(Alcance.PROPIAS, Alcance.AREA)));
        }

        // 4. REVISION_CONSULTAR, APROBAR, RECHAZAR, PEDIR_CORRECCION
        if (v2.capacidades().esRevisor()) {
            grants.add(new Grant("REVISION_CONSULTAR", List.of(Alcance.ASIGNADAS)));
            grants.add(new Grant("SOLICITUD_APROBAR", List.of(Alcance.ASIGNADAS)));
            grants.add(new Grant("SOLICITUD_RECHAZAR", List.of(Alcance.ASIGNADAS)));
            grants.add(new Grant("SOLICITUD_PEDIR_CORRECCION", List.of(Alcance.ASIGNADAS)));
        }

        // 5. METRICAS_CONSULTAR
        Set<Alcance> metricasAlcances = new LinkedHashSet<>();
        metricasAlcances.add(Alcance.PROPIAS);
        if (permisosMap.containsKey("DASHBOARD.VER")) {
            PermisoItemV2 p = permisosMap.get("DASHBOARD.VER");
            if (p.areas() == null || v2.administradorSistema()) {
                metricasAlcances.add(Alcance.GLOBAL);
            } else {
                metricasAlcances.add(Alcance.AREA);
            }
        }
        grants.add(new Grant("METRICAS_CONSULTAR", new ArrayList<>(metricasAlcances)));

        // 6. FLUJO_GESTIONAR
        if (permisosMap.containsKey("FLUJO.GESTIONAR")) {
            PermisoItemV2 p = permisosMap.get("FLUJO.GESTIONAR");
            if (p.areas() == null || v2.administradorSistema()) {
                grants.add(new Grant("FLUJO_GESTIONAR", List.of(Alcance.GLOBAL)));
            } else {
                grants.add(new Grant("FLUJO_GESTIONAR", List.of(Alcance.AREAS_ADMINISTRADAS)));
            }
        }

        // 7. GESTION DE ADMINISTRACIÓN
        if (permisosMap.containsKey("USUARIO.GESTIONAR") || v2.administradorSistema()) {
            grants.add(new Grant("USUARIO_GESTIONAR", List.of(Alcance.GLOBAL)));
        }
        if (permisosMap.containsKey("AREA.GESTIONAR") || v2.administradorSistema()) {
            grants.add(new Grant("AREA_GESTIONAR", List.of(Alcance.GLOBAL)));
        }
        if (permisosMap.containsKey("TIPO_DOCUMENTO.GESTIONAR") || permisosMap.containsKey("SLA.GESTIONAR") || v2.administradorSistema()) {
            grants.add(new Grant("SLA_GESTIONAR", List.of(Alcance.GLOBAL)));
        }
        if (permisosMap.containsKey("ROL.GESTIONAR") || v2.administradorSistema()) {
            grants.add(new Grant("ROL_GESTIONAR", List.of(Alcance.GLOBAL)));
        }
        if (permisosMap.containsKey("AUDITORIA.VER") || v2.administradorSistema()) {
            grants.add(new Grant("AUDITORIA_CONSULTAR", List.of(Alcance.GLOBAL)));
        }

        Long areaId = v2.area() != null ? v2.area().id() : null;
        String areaNombre = v2.area() != null ? v2.area().nombre() : null;

        return new Me(
                v2.usuarioId(),
                areaId,
                areaNombre,
                null,
                v2.administradorSistema(),
                contextRoles,
                managedAreas,
                grants,
                v2.versionAcceso(),
                v2.versionPolitica()
        );
    }
}
