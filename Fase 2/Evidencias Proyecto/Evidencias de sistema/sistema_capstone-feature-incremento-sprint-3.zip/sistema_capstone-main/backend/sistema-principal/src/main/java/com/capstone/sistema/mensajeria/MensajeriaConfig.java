package com.capstone.sistema.mensajeria;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capstone.sistema.ia.config.IaProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * F2/F3/F6: infraestructura común de mensajería (plan §6.0). El contenido de la antigua
 * {@code flow/RabbitConfig} vive aquí: exchange, conversor JSON con JavaTimeModule y
 * RabbitTemplate. Las colas de resultados de correo e IA las declara aquí su consumidor (el
 * principal, §3.1); las colas de comando de los servicios asíncronos las declara cada servicio (§8).
 */
@Configuration
@EnableConfigurationProperties({MensajeriaProperties.class, AppProperties.class, NotificacionesCorreoProperties.class, IaProperties.class})
public class MensajeriaConfig {

    public static final String EXCHANGE_NAME = "capstone.exchange";
    public static final String DLX_NAME = "capstone.dlx";

    /** Llaves del nuevo contrato (§5). */
    public static final String ROUTING_CORREO_ENVIAR = "notificacion.correo.enviar";
    public static final String ROUTING_CORREO_RESULTADO = "notificacion.correo.resultado";
    public static final String ROUTING_IA_EJECUTAR = "ia.tarea.ejecutar";
    public static final String ROUTING_IA_RESULTADO = "ia.tarea.resultado";

    /** F3 (§3.1): cola y DLQ de resultados de correo; las declara su consumidor (este servicio). */
    public static final String COLA_CORREO_RESULTADO = "notificacion.correo.resultado.q";
    public static final String COLA_CORREO_RESULTADO_DLQ = COLA_CORREO_RESULTADO + ".dlq";

    /** F6 (§3.1): cola y DLQ de resultados de IA; las declara su consumidor (este servicio). */
    public static final String COLA_IA_RESULTADO = "ia.tarea.resultado.q";
    public static final String COLA_IA_RESULTADO_DLQ = COLA_IA_RESULTADO + ".dlq";

    @Bean
    public TopicExchange capstoneExchange() {
        return new TopicExchange(EXCHANGE_NAME, true, false);
    }

    @Bean
    public DirectExchange capstoneDlx() {
        return new DirectExchange(DLX_NAME, true, false);
    }

    @Bean
    public Queue colaCorreoResultado() {
        return QueueBuilder.durable(COLA_CORREO_RESULTADO)
                .withArgument("x-dead-letter-exchange", DLX_NAME)
                .withArgument("x-dead-letter-routing-key", COLA_CORREO_RESULTADO)
                .build();
    }

    @Bean
    public Queue colaCorreoResultadoDlq() {
        return QueueBuilder.durable(COLA_CORREO_RESULTADO_DLQ).build();
    }

    @Bean
    public Binding bindingCorreoResultadoDlq(DirectExchange capstoneDlx, Queue colaCorreoResultadoDlq) {
        return BindingBuilder.bind(colaCorreoResultadoDlq).to(capstoneDlx).with(COLA_CORREO_RESULTADO);
    }

    @Bean
    public Binding bindingCorreoResultado(TopicExchange capstoneExchange, Queue colaCorreoResultado) {
        return BindingBuilder.bind(colaCorreoResultado).to(capstoneExchange).with(ROUTING_CORREO_RESULTADO);
    }

    @Bean
    public Queue colaIaResultado() {
        return QueueBuilder.durable(COLA_IA_RESULTADO)
                .withArgument("x-dead-letter-exchange", DLX_NAME)
                .withArgument("x-dead-letter-routing-key", COLA_IA_RESULTADO)
                .build();
    }

    @Bean
    public Queue colaIaResultadoDlq() {
        return QueueBuilder.durable(COLA_IA_RESULTADO_DLQ).build();
    }

    @Bean
    public Binding bindingIaResultadoDlq(DirectExchange capstoneDlx, Queue colaIaResultadoDlq) {
        return BindingBuilder.bind(colaIaResultadoDlq).to(capstoneDlx).with(COLA_IA_RESULTADO);
    }

    @Bean
    public Binding bindingIaResultado(TopicExchange capstoneExchange, Queue colaIaResultado) {
        return BindingBuilder.bind(colaIaResultado).to(capstoneExchange).with(ROUTING_IA_RESULTADO);
    }

    @Bean
    public Jackson2JsonMessageConverter jsonMessageConverter(ObjectMapper objectMapper) {
        Jackson2JsonMessageConverter converter = new Jackson2JsonMessageConverter(objectMapper);
        converter.setAlwaysConvertToInferredType(true);
        return converter;
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, Jackson2JsonMessageConverter converter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(converter);
        return template;
    }
}
