package com.capstone.sistema.doc.model;

import java.util.Objects;

public class FormatoDocumento {

    private Long id;
    private String tipo;

    public FormatoDocumento() {
    }

    public FormatoDocumento(String tipo) {
        this.tipo = tipo;
    }

    public FormatoDocumento(Long id, String tipo) {
        this.id = id;
        this.tipo = tipo;
    }

    public Long getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FormatoDocumento that = (FormatoDocumento) o;
        return Objects.equals(tipo, that.tipo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tipo);
    }
}
