package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.FormatoDocumento;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FormatoDocumentoRepository {

    public Optional<FormatoDocumento> findByTipoIgnoreCase(String tipo) {
        if (tipo == null || tipo.isBlank()) return Optional.empty();
        return Optional.of(new FormatoDocumento(1L, tipo.toLowerCase()));
    }

    public FormatoDocumento save(FormatoDocumento formato) {
        return formato;
    }
}
