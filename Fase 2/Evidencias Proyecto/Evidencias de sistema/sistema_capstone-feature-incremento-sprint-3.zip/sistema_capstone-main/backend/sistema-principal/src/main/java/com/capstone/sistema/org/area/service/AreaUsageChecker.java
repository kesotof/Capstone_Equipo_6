package com.capstone.sistema.org.area.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Component
public class AreaUsageChecker {

    private final JdbcTemplate jdbcTemplate;

    public AreaUsageChecker(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public Dependencies findDependencies(Long areaId) {
        return jdbcTemplate.queryForObject("""
                select
                  (select count(*) from area where area_padre_id = ? and activo = true) as hijas,
                  (select count(*) from usuario where area_id = ? and activo = true) as usuarios,
                  (select count(*) from solicitud s
                   join flujo_definicion f on f.id = s.flujo_definicion_id
                   where s.area_id = ? and f.activo = true and s.estado in ('PENDIENTE_REVISION', 'CORRECCION_REQUERIDA')) as asignaciones
                """, (row, index) -> new Dependencies(row.getLong("hijas"), row.getLong("usuarios"),
                row.getLong("asignaciones")), areaId, areaId, areaId);
    }

    public record Dependencies(long hijasActivas, long usuariosActivos, long asignacionesEnFlujosActivos) {
        public boolean isInUse() {
            return hijasActivas > 0 || usuariosActivos > 0 || asignacionesEnFlujosActivos > 0;
        }

        public Map<String, Long> asMap() {
            return Map.of("hijasActivas", hijasActivas, "usuariosActivos", usuariosActivos,
                    "asignacionesEnFlujosActivos", asignacionesEnFlujosActivos);
        }
    }
}
