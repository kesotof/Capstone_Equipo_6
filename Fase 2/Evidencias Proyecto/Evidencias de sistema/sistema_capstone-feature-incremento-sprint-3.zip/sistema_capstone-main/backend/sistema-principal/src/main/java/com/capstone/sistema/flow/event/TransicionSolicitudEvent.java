package com.capstone.sistema.flow.event;

import java.util.List;
import java.util.UUID;

/**
 * F2 (A-11/§6.0.2) + C2: evento de dominio publicado por el motor de estados al completar una
 * transición (después del INSERT del historial y del UPDATE de la solicitud, dentro de la
 * transacción). Lo consumen con {@code @EventListener}, en la misma transacción:
 * <ul>
 *   <li>{@code notificacion.NotificacionTransicionListener} (avisos por rol, US-36);</li>
 *   <li>{@code ia.IaEvaluacionAutomaticaListener} (evaluación automática, US-30, en F6).</li>
 * </ul>
 * Los consumidores del evento son parte atómica de la transición; los efectos externos
 * (correo, IA) ocurren después del commit y nunca la rompen.
 *
 * <p>F3: la elegibilidad de correo la decide el catálogo (D3-01) — el evento ya no lleva la
 * bandera {@code notificarCorreo}. En su lugar transporta los revisores de la etapa origen
 * cuando el administrador global decidió en una etapa ajena (US-37/CA 37.4): la vista
 * {@code v_revisor_solicitud} solo expone la etapa actual, así que el motor los captura
 * <em>antes</em> de avanzar.</p>
 *
 * @param revisoresEtapaOrigen revisores asignados de la etapa en que el admin actuó;
 *                             vacío cuando {@code actuoComoAdmin} es falso.
 */
public record TransicionSolicitudEvent(
        UUID solicitudId,
        Long historialId,
        String accion,
        String estadoOrigen,
        String estadoDestino,
        Long etapaOrigenId,
        Long etapaDestinoId,
        UUID documentoVigenteId,
        UUID actorId,
        boolean actuoComoAdmin,
        List<UUID> revisoresEtapaOrigen,
        String observacion
) {
}
