package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.util.UUID;

@Entity
@Table(name = "v_acceso_descarga")
@IdClass(VAccesoDescargaId.class)
@Immutable
public class VAccesoDescarga {

    @Id
    @Column(name = "solicitud_id")
    private UUID solicitudId;

    @Id
    @Column(name = "usuario_id")
    private UUID usuarioId;

    @Id
    @Column(name = "motivo")
    private String motivo;

    protected VAccesoDescarga() {
    }

    public VAccesoDescarga(UUID solicitudId, UUID usuarioId, String motivo) {
        this.solicitudId = solicitudId;
        this.usuarioId = usuarioId;
        this.motivo = motivo;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public String getMotivo() {
        return motivo;
    }
}
