package com.capstone.sistema.audit.keycloak;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.idm.EventRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;

/**
 * F9 (§10, US-27) + C1: Importador programado de eventos de Keycloak a log_evento.
 * Polling cada 2 minutos con advisory lock de sesión PostgreSQL (41030, 3) para evitar concurrencia en cluster.
 * Importa eventos del flujo de recuperación de contraseña:
 * - SEND_RESET_PASSWORD / SEND_RESET_PASSWORD_ERROR -> RECUPERACION_SOLICITADA
 * - RESET_PASSWORD / _ERROR -> RECUPERACION_COMPLETADA
 * - UPDATE_PASSWORD / _ERROR -> RECUPERACION_COMPLETADA (solo si existe SEND_RESET_PASSWORD en los 30 min previos)
 * Deduplicación por clave_externa = 'kc:' + time + ':' + type + ':' + coalesce(userId, details.username).
 */
@Component
public class KeycloakEventosImporter {

    private static final Logger log = LoggerFactory.getLogger(KeycloakEventosImporter.class);

    public static final List<String> TIPOS_KC = List.of(
            "SEND_RESET_PASSWORD",
            "SEND_RESET_PASSWORD_ERROR",
            "RESET_PASSWORD",
            "RESET_PASSWORD_ERROR",
            "UPDATE_PASSWORD",
            "UPDATE_PASSWORD_ERROR"
    );

    public static final String INSERTAR_EVENTO = """
            INSERT INTO log_evento (tipo_evento_id, usuario_id, usuario_email, entidad, entidad_id,
                                    resultado, datos_despues, ip_address, created_at, clave_externa)
            SELECT te.id, ?, ?, 'usuario', ?, ?, ?::jsonb, ?, ?, ?
              FROM tipo_evento te
             WHERE te.codigo = ?
            ON CONFLICT (clave_externa) WHERE clave_externa IS NOT NULL DO NOTHING
            """;

    public static final String BUSCAR_SOLICITUD_PREVIA = """
            SELECT COUNT(*)
              FROM log_evento le
              JOIN tipo_evento te ON le.tipo_evento_id = te.id
             WHERE te.codigo = 'RECUPERACION_SOLICITADA'
               AND le.resultado = 'EXITO'
               AND le.usuario_id = ?
               AND le.created_at >= ?
            """;

    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties properties;
    private final UserAccountRepository userAccountRepository;
    private final IntegracionCursorRepository cursorRepository;
    private final JdbcTemplate jdbcTemplate;
    private final TransactionTemplate transactionTemplate;
    private final ObjectMapper objectMapper;

    public KeycloakEventosImporter(
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties properties,
            UserAccountRepository userAccountRepository,
            IntegracionCursorRepository cursorRepository,
            JdbcTemplate jdbcTemplate,
            TransactionTemplate transactionTemplate,
            ObjectMapper objectMapper
    ) {
        this.keycloakAdminClient = keycloakAdminClient;
        this.properties = properties;
        this.userAccountRepository = userAccountRepository;
        this.cursorRepository = cursorRepository;
        this.jdbcTemplate = jdbcTemplate;
        this.transactionTemplate = transactionTemplate;
        this.objectMapper = objectMapper;
    }

    @Scheduled(fixedDelay = 120000)
    public void importarEventos() {
        jdbcTemplate.execute((ConnectionCallback<Void>) con -> {
            boolean locked = false;
            try (PreparedStatement ps = con.prepareStatement("SELECT pg_try_advisory_lock(41030, 3)");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getBoolean(1)) {
                    locked = true;
                }
            } catch (Exception e) {
                log.warn("Error al intentar obtener advisory lock (41030, 3): {}", e.getMessage());
                return null;
            }

            if (!locked) {
                log.debug("Advisory lock (41030, 3) ocupado por otra instancia; se omite ejecución de importador Keycloak");
                return null;
            }

            try {
                ejecutarLoteImportacion();
            } finally {
                try (PreparedStatement ps = con.prepareStatement("SELECT pg_advisory_unlock(41030, 3)");
                     ResultSet rs = ps.executeQuery()) {
                    // Lock liberado
                } catch (Exception e) {
                    log.warn("Error liberando advisory lock (41030, 3): {}", e.getMessage());
                }
            }
            return null;
        });
    }

    public void ejecutarLoteImportacion() {
        Long cursorMsObj = transactionTemplate.execute(status -> {
            IntegracionCursor cursor = cursorRepository.findByNombre("KEYCLOAK_EVENTOS")
                    .orElseGet(() -> cursorRepository.save(new IntegracionCursor("KEYCLOAK_EVENTOS", "0")));
            try {
                return Long.parseLong(cursor.getValor().trim());
            } catch (NumberFormatException e) {
                log.warn("Valor de cursor KEYCLOAK_EVENTOS inválido: '{}'; se reinicia a 0", cursor.getValor());
                return 0L;
            }
        });
        long cursorMs = cursorMsObj != null ? cursorMsObj : 0L;

        String dateFrom = null;
        if (cursorMs > 0) {
            dateFrom = LocalDate.ofInstant(Instant.ofEpochMilli(cursorMs), ZoneOffset.UTC).toString();
        }

        List<EventRepresentation> rawEvents = new ArrayList<>();
        try {
            RealmResource realmResource = keycloakAdminClient.realm(properties.targetRealm());
            int first = 0;
            int pageSize = 200;
            int pageCount = 0;
            int maxPages = 25;
            while (pageCount < maxPages) {
                List<EventRepresentation> page = realmResource.getEvents(
                        TIPOS_KC,
                        null,
                        null,
                        dateFrom,
                        null,
                        null,
                        first,
                        pageSize
                );
                if (page == null || page.isEmpty()) {
                    break;
                }
                rawEvents.addAll(page);
                pageCount++;
                if (page.size() < pageSize) {
                    break;
                }
                first += pageSize;
            }
            if (pageCount >= maxPages) {
                log.warn("Se alcanzó el límite de seguridad de paginación de eventos de Keycloak ({} páginas, {} eventos)", maxPages, rawEvents.size());
            }
        } catch (Exception e) {
            log.warn("No se pudo conectar a Keycloak para importar eventos: {}", e.getMessage());
            return;
        }

        if (rawEvents.isEmpty()) {
            return;
        }

        List<EventRepresentation> events = new ArrayList<>(rawEvents);
        events.sort(Comparator.comparingLong(EventRepresentation::getTime));

        int insertados = 0;
        for (EventRepresentation ev : events) {
            long evTime = ev.getTime();
            if (evTime <= cursorMs) {
                continue;
            }

            boolean ok = procesarEvento(ev, events);
            if (ok) {
                insertados++;
            }
        }
        if (insertados > 0) {
            log.info("Lote de eventos Keycloak procesado. Nuevos eventos importados: {}", insertados);
        }
    }

    private boolean procesarEvento(EventRepresentation ev, List<EventRepresentation> todosLosEventos) {
        long evTime = ev.getTime();

        UUID usuarioId = null;
        String usuarioEmail = null;

        if (ev.getUserId() != null && !ev.getUserId().isBlank()) {
            Optional<UserAccount> userOpt = userAccountRepository.findByKeycloakUserId(ev.getUserId());
            if (userOpt.isPresent()) {
                usuarioId = userOpt.get().getId();
                usuarioEmail = userOpt.get().getEmail();
            }
        }

        if (usuarioEmail == null && ev.getDetails() != null) {
            usuarioEmail = ev.getDetails().get("username");
            if (usuarioEmail != null && usuarioId == null) {
                Optional<UserAccount> uOpt = userAccountRepository.findByEmailIgnoreCase(usuarioEmail);
                if (uOpt.isPresent()) {
                    usuarioId = uOpt.get().getId();
                }
            }
        }

        String tipoKc = ev.getType();
        String codigoEvento;
        String resultado;

        if ("SEND_RESET_PASSWORD".equals(tipoKc)) {
            codigoEvento = "RECUPERACION_SOLICITADA";
            resultado = "EXITO";
        } else if ("SEND_RESET_PASSWORD_ERROR".equals(tipoKc)) {
            codigoEvento = "RECUPERACION_SOLICITADA";
            resultado = "FALLO";
        } else if ("RESET_PASSWORD".equals(tipoKc)) {
            codigoEvento = "RECUPERACION_COMPLETADA";
            resultado = "EXITO";
        } else if ("RESET_PASSWORD_ERROR".equals(tipoKc)) {
            codigoEvento = "RECUPERACION_COMPLETADA";
            resultado = "FALLO";
        } else if ("UPDATE_PASSWORD".equals(tipoKc) || "UPDATE_PASSWORD_ERROR".equals(tipoKc)) {
            boolean tieneSolicitud = verificarSolicitudPrevia(ev, todosLosEventos, usuarioId);
            if (!tieneSolicitud) {
                log.debug("Evento {} omitido para actor {} (sin SEND_RESET_PASSWORD en 30m previos)", tipoKc, ev.getUserId());
                transactionTemplate.execute(status -> {
                    avanzarCursor(evTime);
                    return null;
                });
                return false;
            }
            codigoEvento = "RECUPERACION_COMPLETADA";
            resultado = "UPDATE_PASSWORD".equals(tipoKc) ? "EXITO" : "FALLO";
        } else {
            transactionTemplate.execute(status -> {
                avanzarCursor(evTime);
                return null;
            });
            return false;
        }

        String actor = ev.getUserId() != null ? ev.getUserId() : (usuarioEmail != null ? usuarioEmail : "unknown");
        String claveExterna = "kc:" + evTime + ":" + tipoKc + ":" + actor;
        if (claveExterna.length() > 150) {
            claveExterna = claveExterna.substring(0, 150);
        }

        if (usuarioEmail != null && usuarioEmail.length() > 255) {
            usuarioEmail = usuarioEmail.substring(0, 255);
        }

        Map<String, Object> datos = new LinkedHashMap<>();
        datos.put("kcEvento", tipoKc);
        if (ev.getClientId() != null) {
            datos.put("clientId", ev.getClientId());
        }
        if (ev.getError() != null) {
            datos.put("error", ev.getError());
        }
        if (ev.getDetails() != null) {
            datos.put("details", ev.getDetails());
        }
        String datosJson;
        try {
            datosJson = objectMapper.writeValueAsString(datos);
        } catch (Exception e) {
            datosJson = "{\"kcEvento\":\"" + tipoKc + "\"}";
        }

        Instant createdAt = Instant.ofEpochMilli(evTime);
        String entidadId = usuarioId != null ? usuarioId.toString() : null;

        final UUID finalUsuarioId = usuarioId;
        final String finalUsuarioEmail = usuarioEmail;
        final String finalEntidadId = entidadId;
        final String finalResultado = resultado;
        final String finalDatosJson = datosJson;
        final String finalClaveExterna = claveExterna;
        final String finalCodigoEvento = codigoEvento;

        boolean insertado = false;
        try {
            insertado = Boolean.TRUE.equals(transactionTemplate.execute(status -> {
                int rows = jdbcTemplate.update(
                        INSERTAR_EVENTO,
                        finalUsuarioId,
                        finalUsuarioEmail,
                        finalEntidadId,
                        finalResultado,
                        finalDatosJson,
                        ev.getIpAddress(),
                        Timestamp.from(createdAt),
                        finalClaveExterna,
                        finalCodigoEvento
                );
                return rows > 0;
            }));
        } catch (DataAccessException dae) {
            log.warn("Error al insertar evento de Keycloak clave_externa='{}': {}", claveExterna, dae.getMessage());
        }

        transactionTemplate.execute(status -> {
            avanzarCursor(evTime);
            return null;
        });

        return insertado;
    }

    private boolean verificarSolicitudPrevia(EventRepresentation ev, List<EventRepresentation> todosLosEventos, UUID usuarioId) {
        long ventanaMs = 30 * 60 * 1000L;
        long limiteInferior = ev.getTime() - ventanaMs;

        if (ev.getUserId() != null) {
            boolean enMemoria = todosLosEventos.stream().anyMatch(e ->
                    "SEND_RESET_PASSWORD".equals(e.getType())
                            && ev.getUserId().equals(e.getUserId())
                            && e.getTime() <= ev.getTime()
                            && e.getTime() >= limiteInferior
            );
            if (enMemoria) {
                return true;
            }
        }

        if (usuarioId != null) {
            Timestamp tsLimite = Timestamp.from(Instant.ofEpochMilli(limiteInferior));
            Integer count = jdbcTemplate.queryForObject(BUSCAR_SOLICITUD_PREVIA, Integer.class, usuarioId, tsLimite);
            return count != null && count > 0;
        }

        return false;
    }

    private void avanzarCursor(long evTime) {
        IntegracionCursor cursor = cursorRepository.findByNombre("KEYCLOAK_EVENTOS")
                .orElseGet(() -> new IntegracionCursor("KEYCLOAK_EVENTOS", "0"));
        long valorActual = 0L;
        try {
            valorActual = Long.parseLong(cursor.getValor().trim());
        } catch (NumberFormatException ignored) {
        }
        if (evTime > valorActual) {
            cursor.setValor(String.valueOf(evTime));
            cursorRepository.save(cursor);
        }
    }
}
