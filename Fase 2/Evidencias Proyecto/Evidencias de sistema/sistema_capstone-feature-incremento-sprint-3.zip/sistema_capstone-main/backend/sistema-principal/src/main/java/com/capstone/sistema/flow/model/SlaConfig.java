package com.capstone.sistema.flow.model;

import java.time.Instant;
import java.util.Objects;

public class SlaConfig {

    private Long id;
    private String tipoDocumento;
    private int plazoDias;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    public SlaConfig() {
    }

    public SlaConfig(String tipoDocumento, int plazoDias) {
        this.tipoDocumento = tipoDocumento;
        this.plazoDias = plazoDias;
    }

    public SlaConfig(Long id, String tipoDocumento, int plazoDias) {
        this.id = id;
        this.tipoDocumento = tipoDocumento;
        this.plazoDias = plazoDias;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public int getPlazoDias() {
        return plazoDias;
    }

    public void setPlazoDias(int plazoDias) {
        this.plazoDias = plazoDias;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SlaConfig that = (SlaConfig) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
