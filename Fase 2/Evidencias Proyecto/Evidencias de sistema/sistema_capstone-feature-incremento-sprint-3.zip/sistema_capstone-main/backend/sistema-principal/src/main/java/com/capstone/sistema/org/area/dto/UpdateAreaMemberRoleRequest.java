package com.capstone.sistema.org.area.dto;

public record UpdateAreaMemberRoleRequest(
        boolean esJefeArea
) {}
