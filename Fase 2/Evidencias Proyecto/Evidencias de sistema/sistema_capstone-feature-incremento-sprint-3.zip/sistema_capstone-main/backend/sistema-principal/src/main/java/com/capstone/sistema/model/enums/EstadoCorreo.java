package com.capstone.sistema.model.enums;

/**
 * US-35: estado del envío de correo de una notificación.
 * <ul>
 *   <li>{@link #NO_APLICA}: el tipo no envía correo, el correo está deshabilitado o el
 *       destinatario está inactivo (D3-01 y usuarios inactivos §6.1).</li>
 *   <li>{@link #PENDIENTE}: comando publicado en RabbitMQ pendiente de resultado.</li>
 *   <li>{@link #ENVIADO}: confirmación del proveedor (gana siempre, aunque llegue tarde, §6.2).</li>
 *   <li>{@link #FALLIDO}: agotados los reintentos o error no reintenable.</li>
 * </ul>
 */
public enum EstadoCorreo {
    NO_APLICA,
    PENDIENTE,
    ENVIADO,
    FALLIDO
}
