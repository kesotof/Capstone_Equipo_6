package com.capstone.sistema.flow.consumer;

import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.template.service.SugerenciaCamposService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SugerenciaCamposResultListener {

    private static final Logger log = LoggerFactory.getLogger(SugerenciaCamposResultListener.class);

    private final SugerenciaCamposService sugerenciaCamposService;

    public SugerenciaCamposResultListener(SugerenciaCamposService sugerenciaCamposService) {
        this.sugerenciaCamposService = sugerenciaCamposService;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.fields.results.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = RabbitConfig.AI_FIELDS_RESULT_ROUTING_KEY
    ))
    public void onResultado(Map<String, Object> resultado) {
        log.info("Sugerencia de campos con IA recibida: {} ({})", resultado.get("sugerenciaId"), resultado.get("status"));
        sugerenciaCamposService.registrarResultado(resultado);
    }
}
