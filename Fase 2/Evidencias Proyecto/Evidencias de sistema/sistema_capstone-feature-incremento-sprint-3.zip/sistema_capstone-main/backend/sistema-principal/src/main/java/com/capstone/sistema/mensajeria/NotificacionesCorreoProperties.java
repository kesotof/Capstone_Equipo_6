package com.capstone.sistema.mensajeria;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * F2/F3: la bandera global de envío de correo (`notificaciones.correo.habilitado`).
 * Combinada con `tipo_notificacion.envia_correo` y `destinatario.activo` (D3-01).
 */
@ConfigurationProperties(prefix = "notificaciones.correo")
public record NotificacionesCorreoProperties(boolean habilitado) {
}
