-- Sprint 3 fix: compatibilidad de jsonb en Hibernate (SqlTypes.JSON) con chk_ia_estado.
-- En PostgreSQL un valor 'null'::jsonb no es SQL NULL ('null'::jsonb IS NULL es false).
-- Para estado PENDIENTE se admite tanto SQL NULL como JSON null ('null'::jsonb).

ALTER TABLE ia_tarea DROP CONSTRAINT IF EXISTS chk_ia_estado;

ALTER TABLE ia_tarea ADD CONSTRAINT chk_ia_estado CHECK (
    (estado = 'PENDIENTE'  AND (resultado IS NULL OR resultado = 'null'::jsonb) AND completed_at IS NULL)
 OR (estado = 'COMPLETADA' AND resultado IS NOT NULL AND resultado != 'null'::jsonb AND completed_at IS NOT NULL)
 OR (estado = 'FALLIDA'    AND codigo_error IS NOT NULL AND completed_at IS NOT NULL)
);
