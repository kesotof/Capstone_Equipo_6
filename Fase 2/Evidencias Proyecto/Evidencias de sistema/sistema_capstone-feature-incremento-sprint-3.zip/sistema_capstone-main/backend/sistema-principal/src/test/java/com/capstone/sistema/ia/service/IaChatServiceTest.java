package com.capstone.sistema.ia.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.dto.IaMensajeChatDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IaChatServiceTest {

    @Mock
    private IaProperties iaProperties;

    @Mock
    private IaTareaRepository iaTareaRepository;

    @Mock
    private SolicitudRepository solicitudRepository;

    @Mock
    private DocumentoRepository documentoRepository;

    @Mock
    private IaAccesoPolicy accesoPolicy;

    @Mock
    private IaComandoFactory comandoFactory;

    @Mock
    private MensajePublicador publicador;

    @Mock
    private AuditService auditService;

    @InjectMocks
    private IaChatService chatService;

    private final UUID solicitudId = UUID.randomUUID();
    private final UserAccount usuario = new UserAccount("kc-rev", "revisor@test.cl", "Revisor", "Test", true);

    @BeforeEach
    void setUp() {
        usuario.setId(UUID.randomUUID());
        lenient().when(iaProperties.habilitada()).thenReturn(true);
        lenient().when(iaProperties.chat()).thenReturn(new IaProperties.Chat(1000, 50));
    }

    @Test
    @DisplayName("crearChat exitoso crea tarea PENDIENTE, publica comando y audita IA_CONSULTA_REALIZADA")
    void crearChat_exito() {
        when(accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.puedeVer(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)).thenReturn(true);

        Solicitud solicitud = mock(Solicitud.class);
        EstadoSolicitud estado = mock(EstadoSolicitud.class);
        when(estado.getCodigo()).thenReturn("PENDIENTE_REVISION");
        when(solicitud.getEstadoSolicitud()).thenReturn(estado);
        when(solicitud.getFlujoEtapa()).thenReturn(new FlujoEtapa(null, 1, "Etapa 1"));
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));

        when(iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
                solicitudId, TipoTareaIa.CHAT, usuario.getId(), EstadoTareaIa.PENDIENTE
        )).thenReturn(false);

        when(iaTareaRepository.countPreguntasChatDesde(eq(solicitudId), any())).thenReturn(5L);

        Documento doc = mock(Documento.class);
        when(doc.getVersion()).thenReturn(1);
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)).thenReturn(Optional.of(doc));

        UUID msgId = UUID.randomUUID();
        ComandoTareaIa comando = new ComandoTareaIa(1, msgId, UUID.randomUUID(), "CHAT", null, null, "pregunta", List.of(), List.of(), Instant.now());
        when(comandoFactory.crearComando(any())).thenReturn(comando);

        IaMensajeChatDto dto = chatService.crearChat(solicitudId, usuario, "¿Cuál es el plazo?");

        assertThat(dto.estado()).isEqualTo("PENDIENTE");
        assertThat(dto.pregunta()).isEqualTo("¿Cuál es el plazo?");
        verify(iaTareaRepository).saveAndFlush(any(IaTarea.class));
        verify(publicador).publicarTrasCommit(eq("ia.tarea.ejecutar"), eq(comando), eq(msgId));
        verify(auditService).registerAuditEvent(eq("IA_CONSULTA_REALIZADA"), eq("solicitud"), eq(solicitudId.toString()), eq("EXITO"), anyString());
    }

    @Test
    @DisplayName("Carrera concurrente en saveAndFlush lanza IA_TAREA_EN_CURSO (409)")
    void crearChat_carreraConcurrente_lanzaTareaEnCurso() {
        when(accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.puedeVer(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)).thenReturn(true);

        Solicitud solicitud = mock(Solicitud.class);
        EstadoSolicitud estado = mock(EstadoSolicitud.class);
        when(estado.getCodigo()).thenReturn("PENDIENTE_REVISION");
        when(solicitud.getEstadoSolicitud()).thenReturn(estado);
        when(solicitud.getFlujoEtapa()).thenReturn(new FlujoEtapa(null, 1, "Etapa 1"));
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));

        when(iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
                solicitudId, TipoTareaIa.CHAT, usuario.getId(), EstadoTareaIa.PENDIENTE
        )).thenReturn(false);

        when(iaTareaRepository.countPreguntasChatDesde(eq(solicitudId), any())).thenReturn(0L);

        Documento doc = mock(Documento.class);
        when(documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)).thenReturn(Optional.of(doc));

        doThrow(new DataIntegrityViolationException("uq_ia_manual_en_curso"))
                .when(iaTareaRepository).saveAndFlush(any(IaTarea.class));

        assertThatThrownBy(() -> chatService.crearChat(solicitudId, usuario, "¿Cuál es el plazo?"))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_TAREA_EN_CURSO");
    }

    @Test
    @DisplayName("Pregunta vacía o mayor a maxPregunta lanza IA_PREGUNTA_INVALIDA (400)")
    void crearChat_preguntaInvalida() {
        assertThatThrownBy(() -> chatService.crearChat(solicitudId, usuario, "   "))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_PREGUNTA_INVALIDA");

        String muyLarga = "A".repeat(1001);
        assertThatThrownBy(() -> chatService.crearChat(solicitudId, usuario, muyLarga))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_PREGUNTA_INVALIDA");
    }

    @Test
    @DisplayName("Superar límite diario de 50 preguntas lanza IA_LIMITE_DIARIO (429)")
    void crearChat_limiteDiario() {
        when(accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.puedeVer(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)).thenReturn(true);

        Solicitud solicitud = mock(Solicitud.class);
        EstadoSolicitud estado = mock(EstadoSolicitud.class);
        when(estado.getCodigo()).thenReturn("PENDIENTE_REVISION");
        when(solicitud.getEstadoSolicitud()).thenReturn(estado);
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));

        when(iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(any(), any(), any(), any())).thenReturn(false);
        when(iaTareaRepository.countPreguntasChatDesde(eq(solicitudId), any())).thenReturn(50L);

        assertThatThrownBy(() -> chatService.crearChat(solicitudId, usuario, "Pregunta"))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_LIMITE_DIARIO");
    }

    @Test
    @DisplayName("Pregunta concurrente cuando ya hay una PENDIENTE lanza IA_TAREA_EN_CURSO (409)")
    void crearChat_tareaEnCurso() {
        when(accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.puedeVer(usuario.getId(), solicitudId)).thenReturn(true);
        when(accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)).thenReturn(true);

        Solicitud solicitud = mock(Solicitud.class);
        EstadoSolicitud estado = mock(EstadoSolicitud.class);
        when(estado.getCodigo()).thenReturn("PENDIENTE_REVISION");
        when(solicitud.getEstadoSolicitud()).thenReturn(estado);
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));

        when(iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
                solicitudId, TipoTareaIa.CHAT, usuario.getId(), EstadoTareaIa.PENDIENTE
        )).thenReturn(true);

        assertThatThrownBy(() -> chatService.crearChat(solicitudId, usuario, "Pregunta"))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_TAREA_EN_CURSO");
    }
}
