package com.capstone.sistema.notificacion.repository;

import com.capstone.sistema.notificacion.model.TipoNotificacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TipoNotificacionRepository extends JpaRepository<TipoNotificacion, Long> {

    Optional<TipoNotificacion> findByCodigoIgnoreCase(String codigo);

    default Optional<TipoNotificacion> findByTipoIgnoreCase(String tipo) {
        return findByCodigoIgnoreCase(tipo);
    }
}
