package com.capstone.sistema.org.area.exception;

import org.springframework.http.HttpStatus;

import java.util.Map;

public class AreaException extends RuntimeException {

    private final HttpStatus status;
    private final String codigo;
    private final String title;
    private final Map<String, Object> properties;

    public AreaException(HttpStatus status, String codigo, String title, String detail,
                         Map<String, Object> properties) {
        super(detail);
        this.status = status;
        this.codigo = codigo;
        this.title = title;
        this.properties = Map.copyOf(properties);
    }

    public static AreaException invalidField(String field, String detail) {
        return new AreaException(HttpStatus.BAD_REQUEST, "AREA_DATOS_INVALIDOS",
                "Datos de área inválidos", detail, Map.of("invalidFields", Map.of(field, detail)));
    }

    public static AreaException usuarioInactivo() {
        return new AreaException(HttpStatus.UNPROCESSABLE_ENTITY, "USUARIO_INACTIVO",
                "Usuario inactivo", "El usuario especificado no está activo.", Map.of());
    }

    public static AreaException duplicateName() {
        return new AreaException(HttpStatus.CONFLICT, "AREA_NOMBRE_DUPLICADO",
                "Nombre de área duplicado", "Ya existe un área con ese nombre.",
                Map.of("invalidFields", Map.of("nombre", "El nombre ya está registrado.")));
    }

    public static AreaException conflict(String detail) {
        return new AreaException(HttpStatus.CONFLICT, "AREA_CONFLICTO",
                "Conflicto en área", detail, Map.of());
    }

    public static AreaException invalidHierarchy() {
        String detail = "El padre no puede ser la misma área ni formar un ciclo en la jerarquía.";
        return new AreaException(HttpStatus.BAD_REQUEST, "AREA_JERARQUIA_INVALIDA",
                "Jerarquía de áreas inválida", detail,
                Map.of("invalidFields", Map.of("areaPadreId", detail)));
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getTitle() {
        return title;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }
}
