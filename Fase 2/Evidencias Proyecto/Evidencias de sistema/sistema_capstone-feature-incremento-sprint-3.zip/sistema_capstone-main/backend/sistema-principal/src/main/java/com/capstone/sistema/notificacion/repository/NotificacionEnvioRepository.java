package com.capstone.sistema.notificacion.repository;

import com.capstone.sistema.notificacion.model.NotificacionEnvio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NotificacionEnvioRepository extends JpaRepository<NotificacionEnvio, Long> {

    List<NotificacionEnvio> findByNotificacion_Id(Long notificacionId);

    /** F3 (§6.2): siguiente intento para re-publicar (0 si aún no hay intentos). */
    @Query("SELECT COALESCE(MAX(e.intento), 0) FROM NotificacionEnvio e WHERE e.notificacion.id = :notificacionId")
    int maximoIntento(@Param("notificacionId") Long notificacionId);

    /**
     * F3 (§6.4): bitácora inmutable de intentos (CB004) con dedup por
     * {@code (notificacion_id, canal, intento)}; devuelve {@code null} si el intento ya existía.
     */
    @Query(value = """
            INSERT INTO notificacion_envio (notificacion_id, canal, destino, intento, resultado,
                                            error_detalle, proveedor_id, codigo_error, created_at)
            VALUES (:notificacionId, :canal, :destino, :intento, :resultado,
                    :errorDetalle, :proveedorId, :codigoError, now())
            ON CONFLICT (notificacion_id, canal, intento) DO NOTHING
            RETURNING id
            """, nativeQuery = true)
    Long insertarIntento(@Param("notificacionId") Long notificacionId,
                         @Param("canal") String canal,
                         @Param("destino") String destino,
                         @Param("intento") int intento,
                         @Param("resultado") String resultado,
                         @Param("errorDetalle") String errorDetalle,
                         @Param("proveedorId") String proveedorId,
                         @Param("codigoError") String codigoError);
}
