package com.capstone.sistema.ia.dto;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.UUID;

/**
 * F6 (§7.2): representación de una evaluación de IA (US-30).
 */
public record IaEvaluacionDto(
        UUID id,
        String estado,
        String origen,
        EtapaDto etapa,
        DocumentoDto documento,
        String criterio,
        JsonNode resultado,
        ErrorDto error,
        SolicitadoPorDto solicitadoPor,
        String modelo,
        boolean vigente,
        Instant createdAt,
        Instant completedAt,
        String aviso
) {
    public static final String AVISO_LEGAL = "Sugerencia generada por IA. La decisión final corresponde al revisor.";

    public record EtapaDto(Long id, String nombre) {}
    public record DocumentoDto(UUID id, Integer version, String nombreArchivo) {}
    public record SolicitadoPorDto(UUID id, String nombre) {}
    public record ErrorDto(String codigo, String mensaje) {}
}
