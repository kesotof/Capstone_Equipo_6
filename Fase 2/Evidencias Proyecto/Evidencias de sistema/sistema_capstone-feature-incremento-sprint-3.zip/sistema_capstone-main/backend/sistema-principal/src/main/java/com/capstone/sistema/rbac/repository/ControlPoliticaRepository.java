package com.capstone.sistema.rbac.repository;

import com.capstone.sistema.rbac.model.ControlPolitica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ControlPoliticaRepository extends JpaRepository<ControlPolitica, Integer> {

    @Modifying
    @Query("UPDATE ControlPolitica c SET c.version = c.version + 1, c.updatedAt = CURRENT_TIMESTAMP WHERE c.id = 1")
    int incrementarVersion();
}
