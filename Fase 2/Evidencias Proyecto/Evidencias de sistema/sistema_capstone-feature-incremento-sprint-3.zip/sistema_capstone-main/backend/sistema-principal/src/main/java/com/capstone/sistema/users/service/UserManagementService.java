package com.capstone.sistema.users.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.UpdateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.exception.AreaInactivaException;
import com.capstone.sistema.users.exception.RutDuplicadoException;
import com.capstone.sistema.users.exception.RutInvalidoException;
import com.capstone.sistema.users.exception.UserAlreadyExistsException;
import com.capstone.sistema.users.exception.UserNotFoundException;
import com.capstone.sistema.users.exception.UserProvisioningException;

import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.repository.RolRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService.RolSeleccionado;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.capstone.sistema.users.util.RutValidator;
import jakarta.ws.rs.core.Response;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;

import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserManagementService {

    private static final Logger log = LoggerFactory.getLogger(UserManagementService.class);

    private static final String SIN_AREA = "Sin área";

    private final UserAccountRepository userAccountRepository;
    private final AreaRepository areaRepository;
    private final KeycloakLockStatusClient keycloakLockStatusClient;
    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties keycloakProperties;
    private final AuditService auditService;
    private final com.capstone.sistema.rbac.service.RbacManagementService rbac;
    private final com.capstone.sistema.auth.CurrentUserResolver currentUserResolver;
    private final jakarta.persistence.EntityManager entityManager;
    private final com.capstone.sistema.users.password.PasswordChangeOperations passwordChanges;
    private final RbacAccessService accessService;
    private final RolRepository rolRepository;

    public UserManagementService(
            UserAccountRepository userAccountRepository,
            AreaRepository areaRepository,
            KeycloakLockStatusClient keycloakLockStatusClient,
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties keycloakProperties,
            AuditService auditService,
            com.capstone.sistema.rbac.service.RbacManagementService rbac,
            com.capstone.sistema.auth.CurrentUserResolver currentUserResolver,
            jakarta.persistence.EntityManager entityManager,
            RbacAccessService accessService,
            RolRepository rolRepository
    ) {
        this.accessService = accessService;
        this.rolRepository = rolRepository;
        this.userAccountRepository = userAccountRepository;
        this.areaRepository = areaRepository;
        this.keycloakLockStatusClient = keycloakLockStatusClient;
        this.keycloakAdminClient = keycloakAdminClient;
        this.keycloakProperties = keycloakProperties;
        this.auditService = auditService;
        this.rbac = rbac;
        this.currentUserResolver=currentUserResolver;
        this.entityManager=entityManager;
        this.passwordChanges = new com.capstone.sistema.users.password.PasswordChangeOperations(
                keycloakAdminClient, keycloakProperties, currentUserResolver, keycloakLockStatusClient, auditService, userAccountRepository);
    }

    @Transactional
    public UserResponse createUser(CreateUserRequest request) {
        var securityBefore = rbac.prepareMutation();
        // Los roles elegidos al crear la cuenta se guardan como asignaciones globales en USUARIO_ROL.
        List<RolSeleccionado> selectedRoles = request.roleIds() != null
                ? rbac.explicitRoles(request.roleIds()) : List.of();
        rechazarAdminGlobal(selectedRoles);
        requireAdminSiRolesProtegidos(selectedRoles);
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (userAccountRepository.existsByEmailIgnoreCase(email)) {
            throw new UserAlreadyExistsException(email);
        }

        String rutIngresado = request.rut() != null ? request.rut().trim() : "";
        if (!RutValidator.esValido(rutIngresado)) {
            throw new RutInvalidoException("El RUT ingresado no es válido o tiene un dígito verificador incorrecto");
        }
        String rutNormalizado = RutValidator.normalizar(rutIngresado);
        String rutLimpio = RutValidator.limpiar(rutIngresado);
        if (userAccountRepository.existsByRut(rutNormalizado) || userAccountRepository.existsByRut(rutIngresado) || userAccountRepository.existsByRutLimpio(rutLimpio)) {
            throw new RutDuplicadoException("El RUT " + rutIngresado + " ya está registrado en el sistema");
        }

        Area area = null;
        if (request.areaId() != null) {
            area = areaRepository.findById(request.areaId())
                    .orElseThrow(() -> new IllegalArgumentException("El área especificada no existe"));
            if (!area.isActivo()) {
                throw new AreaInactivaException("No se puede asignar un usuario a un área inactiva");
            }
        }

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        if (!users.searchByEmail(email, true).isEmpty()) {
            throw new UserAlreadyExistsException(email);
        }

        UserRepresentation representation = new UserRepresentation();
        representation.setUsername(email);
        representation.setEmail(email);
        representation.setFirstName(request.firstName().trim());
        representation.setLastName(request.lastName().trim());
        representation.setEmailVerified(true);
        representation.setEnabled(true);

        String keycloakUserId = createInKeycloak(users, representation, email);
        try {
            setInitialPassword(users, keycloakUserId, request.password(), request.requirePasswordChange());
            // Keycloak mantiene la identidad; las autorizaciones se guardan localmente.

            UserAccount user = new UserAccount(
                    keycloakUserId,
                    email,
                    rutIngresado,
                    request.firstName().trim(),
                    request.lastName().trim(),
                    area,
                    true
            );
            UserAccount saved = userAccountRepository.saveAndFlush(user);
            UUID otorgadoPor = currentUserResolver.resolveCurrentUser().map(UserAccount::getId).orElse(saved.getId());
            rbac.assignGlobalRoles(saved.getId(), selectedRoles, otorgadoPor);
            rbac.finishMutation(securityBefore);
            log.info("Cuenta creada y sincronizada id={} con {} rol(es) global(es)", saved.getId(), selectedRoles.size());
            String detalleAuditoria = "Usuario creado: " + saved.getEmail()
                    + " (área: " + (area != null ? area.getNombre() : SIN_AREA)
                    + (selectedRoles.isEmpty() ? "" : "; roles: " + selectedRoles.stream()
                            .map(RolSeleccionado::nombre).collect(Collectors.joining(", ")))
                    + ")";
            auditService.registerAuditEvent("CREAR_USUARIO", "usuario", String.valueOf(saved.getId()), "EXITO", detalleAuditoria);
            return rbac.response(saved, false);
        } catch (RuntimeException exception) {
            deleteKeycloakUserQuietly(users, keycloakUserId, email);
            if (exception instanceof UserAlreadyExistsException
                    || exception instanceof RutDuplicadoException
                    || exception instanceof AreaInactivaException
                    || exception instanceof UserProvisioningException) {
                throw exception;
            }
            throw new UserProvisioningException("No fue posible completar la creación de la cuenta", exception);
        }
    }

    /** El administrador global se define en Keycloak: no se asigna desde la plataforma (422 ROL_ADMIN_GLOBAL_NO_ASIGNABLE). */
    private void rechazarAdminGlobal(List<RolSeleccionado> roles) {
        for (RolSeleccionado seleccionado : roles) {
            String code = seleccionado.codigo();
            if ("ADMIN_SISTEMA".equalsIgnoreCase(code) || "ADMIN".equalsIgnoreCase(code)) {
                throw RbacException.adminGlobalNoAsignable();
            }
        }
    }

    /**
     * Misma regla que AccesoUsuarioService: asignar un rol con permisos bloqueados solo lo puede hacer
     * un administrador del sistema (403 RBAC_ACCION_DENEGADA).
     */
    private void requireAdminSiRolesProtegidos(List<RolSeleccionado> roles) {
        for (RolSeleccionado seleccionado : roles) {
            boolean protegido = rolRepository.findById(seleccionado.id())
                    .map(Rol::isPermisosBloqueados).orElse(false);
            if (protegido && !accessService.context().admin()) {
                throw RbacException.denied();
            }
        }
    }

    @Transactional
    public UserResponse updateUser(UUID id, UpdateUserRequest request) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);

        String detalleArea = null;
        if (request.areaId() != null && (user.getArea() == null || !request.areaId().equals(user.getArea().getId()))) {
            Area target = areaRepository.findById(request.areaId()).orElseThrow(
                    () -> new IllegalArgumentException("El área especificada no existe"));
            if (!target.isActivo()) throw new AreaInactivaException("No se puede asignar un usuario a un área inactiva");
            Area currentArea = user.getArea();
            String areaAnterior = currentArea != null ? currentArea.getNombre() : SIN_AREA;
            user.setArea(target);
            user.bumpVersionAcceso();
            userAccountRepository.flush();
            detalleArea = "Usuario " + user.getEmail() + ": " + areaAnterior + " → " + target.getNombre();
        }
        rbac.finishMutation(securityBefore);
        if (detalleArea != null) {
            // Un único evento por cambio de área; se escribe solo si la transacción confirma.
            auditService.registerAuditEvent("CAMBIAR_AREA_USUARIO", "usuario", String.valueOf(user.getId()), "EXITO", detalleArea);
        }
        String firstName = request.firstName().trim();
        String lastName = request.lastName().trim();

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        try {
            UserResource userResource = users.get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setFirstName(firstName);
            rep.setLastName(lastName);

            if (request.newPassword() != null && !request.newPassword().isBlank()) {
                boolean reqPassChange = Boolean.TRUE.equals(request.requirePasswordChange());
                setInitialPassword(users, user.getKeycloakUserId(), request.newPassword().trim(), reqPassChange);
            } else if (request.requirePasswordChange() != null) {
                List<String> actions = rep.getRequiredActions();
                if (actions == null) {
                    actions = new java.util.ArrayList<>();
                }
                if (Boolean.TRUE.equals(request.requirePasswordChange())) {
                    if (!actions.contains("UPDATE_PASSWORD")) {
                        actions.add("UPDATE_PASSWORD");
                    }
                } else {
                    actions.remove("UPDATE_PASSWORD");
                }
                rep.setRequiredActions(actions);
            }

            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al actualizar usuario {} en Keycloak", user.getEmail(), exception);
            throw new UserProvisioningException("No fue posible sincronizar la actualización en Keycloak", exception);
        }

        user.setFirstName(firstName);
        user.setLastName(lastName);

        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String auditDetalle = "Usuario actualizado: " + saved.getEmail() + " (" + firstName + " " + lastName + ")";
        if (request.newPassword() != null && !request.newPassword().isBlank()) {
            auditDetalle += " [Contraseña restablecida]";
        }
        auditService.registerAuditEvent("ACTUALIZAR_USUARIO", "usuario", String.valueOf(saved.getId()), "EXITO", auditDetalle);

        return rbac.response(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public UserResponse toggleUserStatus(UUID id, boolean enabled) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);

        if (!enabled) rbac.protectAccountRemoval(user);
        user.setEnabled(enabled);
        user.bumpVersionAcceso();
        userAccountRepository.flush();
        rbac.finishMutation(securityBefore);
        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        try {
            UserResource userResource = realm.users().get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setEnabled(enabled);
            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al cambiar estado de usuario {} en Keycloak a enabled={}", user.getEmail(), enabled, exception);
            throw new UserProvisioningException("No fue posible cambiar el estado del usuario en Keycloak", exception);
        }

        user.setEnabled(enabled);
        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String tipo = enabled ? "ACTIVAR_USUARIO" : "DESACTIVAR_USUARIO";
        String detalle = (enabled ? "Cuenta activada" : "Cuenta desactivada") + " para " + saved.getEmail();
        auditService.registerAuditEvent(tipo, "usuario", String.valueOf(saved.getId()), "EXITO", detalle);

        return rbac.response(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public void deleteUser(UUID id) {
        var securityBefore = rbac.prepareMutation();
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        entityManager.refresh(user);
        rbac.protectAccountDeletion(user);

        String email = user.getEmail();
        String keycloakUserId = user.getKeycloakUserId();

        UUID userId = user.getId();

        userAccountRepository.delete(user);
        userAccountRepository.flush();
        rbac.finishMutation(securityBefore);
        // Se registra solo si el borrado confirma (AuditService difiere los eventos EXITO al commit).
        auditService.registerAuditEvent("ELIMINAR_USUARIO", "usuario", String.valueOf(userId), "EXITO",
                "Usuario eliminado: " + email);

        try {
            RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
            realm.users().delete(keycloakUserId).close();
            log.info("Usuario {} eliminado exitosamente de Keycloak", email);
        } catch (RuntimeException exception) {
            log.warn("No fue posible eliminar usuario {} de Keycloak o ya fue removido: {}", email, exception.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<UserResponse> listUsers() {
        return userAccountRepository.findAllByOrderByEmailAsc().stream()
                .map(user -> rbac.response(
                        user,
                        keycloakLockStatusClient.isTemporarilyLocked(user.getKeycloakUserId())
                ))
                .toList();
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(UUID id) {
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        return rbac.response(
                user,
                keycloakLockStatusClient.isTemporarilyLocked(user.getKeycloakUserId())
        );
    }

    @Transactional
    public int synchronizeExistingUsers() {
        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        int synchronizedUsers = 0;

        for (UserRepresentation representation : users.list()) {
            String email = normalizeEmail(representation);
            if (email == null
                    || userAccountRepository.existsByEmailIgnoreCase(email)
                    || userAccountRepository.existsByKeycloakUserId(representation.getId())) {
                continue;
            }

            // Importar una identidad no concede privilegios por los roles remotos.
            UserAccount account = new UserAccount(
                    representation.getId(),
                    email,
                    valueOrEmpty(representation.getFirstName()),
                    valueOrEmpty(representation.getLastName()),
                    Boolean.TRUE.equals(representation.isEnabled())
            );
            userAccountRepository.save(account);
            synchronizedUsers++;
        }

        userAccountRepository.flush();
        return synchronizedUsers;
    }

    private String createInKeycloak(UsersResource users, UserRepresentation representation, String email) {
        try (Response response = users.create(representation)) {
            if (response.getStatus() == Response.Status.CONFLICT.getStatusCode()) {
                throw new UserAlreadyExistsException(email);
            }
            if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
                throw new UserProvisioningException(
                        "Keycloak rechazó la creación de la cuenta con estado HTTP " + response.getStatus()
                );
            }
            return CreatedResponseUtil.getCreatedId(response);
        } catch (UserAlreadyExistsException | UserProvisioningException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            throw new UserProvisioningException("No fue posible conectar con Keycloak", exception);
        }
    }

    private void setInitialPassword(
            UsersResource users,
            String keycloakUserId,
            String password,
            boolean requirePasswordChange
    ) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(password);
        credential.setTemporary(requirePasswordChange);
        users.get(keycloakUserId).resetPassword(credential);
    }

    private void deleteKeycloakUserQuietly(UsersResource users, String keycloakUserId, String email) {
        try {
            users.delete(keycloakUserId).close();
            log.warn("Se eliminó de Keycloak la cuenta {} porque no pudo persistirse completamente", email);
        } catch (RuntimeException exception) {
            log.error("No fue posible compensar la creación incompleta de la cuenta {}", email, exception);
        }
    }

    private String normalizeEmail(UserRepresentation representation) {
        if (representation.getEmail() == null || representation.getEmail().isBlank()) {
            return null;
        }
        return representation.getEmail().trim().toLowerCase(Locale.ROOT);
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value.trim();
    }

    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public void changePassword(com.capstone.sistema.users.dto.ChangePasswordRequest request) {
        passwordChanges.change(request);
    }

    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public com.capstone.sistema.users.dto.PasswordPolicyResponse passwordPolicy() {
        return passwordChanges.policy();
    }

    @Transactional
    public UserResponse unlockUser(UUID id) {
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("El usuario especificado no existe"));
        if (user.getKeycloakUserId() != null) {
            keycloakLockStatusClient.unlockUser(user.getKeycloakUserId());
        }
        auditService.registerAuditEvent("DESBLOQUEAR_USUARIO", "usuario", String.valueOf(user.getId()), "EXITO",
                "Desbloqueo manual de cuenta bloqueada temporalmente: " + user.getEmail());
        return rbac.response(user, false);
    }
}
