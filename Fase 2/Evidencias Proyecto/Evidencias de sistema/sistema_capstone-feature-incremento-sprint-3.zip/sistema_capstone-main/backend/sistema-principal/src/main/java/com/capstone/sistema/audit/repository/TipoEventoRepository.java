package com.capstone.sistema.audit.repository;

import com.capstone.sistema.audit.model.TipoEvento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TipoEventoRepository extends JpaRepository<TipoEvento, Long> {

    /** Consulta derivada sobre la columna real {@code tipo_evento.codigo}. */
    Optional<TipoEvento> findByCodigoIgnoreCase(String codigo);

    /**
     * Alias de compatibilidad. Es un método default (no una consulta derivada): Spring Data no lo
     * interpreta, por lo que no depende de una propiedad {@code tipo} en la entidad.
     */
    default Optional<TipoEvento> findByTipoIgnoreCase(String tipo) {
        return findByCodigoIgnoreCase(tipo);
    }
}
