package com.capstone.sistema.mensajeria.contrato;

import java.time.Instant;
import java.util.UUID;

/**
 * §5.1 — comando del principal a service-notificaciones (routing «notificacion.correo.enviar»).
 * No escribir nunca a mano el JSON: los tests de round-trip contra
 * {@code src/test/resources/contratos/comando-enviar-correo.json} son el contrato.
 */
public record ComandoEnviarCorreo(
        int version,
        UUID mensajeId,
        Long notificacionId,
        int intentoInicial,
        Destinatario destinatario,
        String asunto,
        String titulo,
        String mensaje,
        Accion accion,
        String categoria,
        Instant emitidoEn
) {

    public record Destinatario(String email, String nombre) {
    }

    public record Accion(String texto, String url) {
    }
}
