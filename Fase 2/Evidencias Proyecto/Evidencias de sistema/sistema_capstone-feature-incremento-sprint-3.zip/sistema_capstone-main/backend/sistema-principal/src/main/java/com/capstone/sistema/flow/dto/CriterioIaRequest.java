package com.capstone.sistema.flow.dto;

import jakarta.validation.constraints.NotNull;

/**
 * F6 (§6.5): body de {@code PATCH /api/flujos/{id}/etapas/{etapaId}/criterio-ia}.
 * {@code criterioIa} admite null para borrar el criterio; el texto se normaliza en el servicio
 * (trim, vacío → null, 10–4000 caracteres; si no → 400 {@code CRITERIO_IA_INVALIDO}).
 */
public record CriterioIaRequest(String criterioIa, @NotNull(message = "La versión del flujo es obligatoria") Long version) {
}
