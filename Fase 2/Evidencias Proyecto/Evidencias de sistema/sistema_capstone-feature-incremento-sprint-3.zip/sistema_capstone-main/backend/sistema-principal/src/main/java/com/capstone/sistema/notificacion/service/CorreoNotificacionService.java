package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.mensajeria.AppProperties;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ComandoEnviarCorreo;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * F3 (§6.2): arma {@code ComandoEnviarCorreo} (§5.1) desde una notificación persistida y lo
 * publica con {@link MensajePublicador} (solo tras commit; los fallos de broker los traga el
 * publicador — CA 09.4). La traza de cada intento la registra el consumidor con
 * {@code ResultadoCorreo} (§6.4).
 *
 * <p>{@code asunto} = {@code titulo} (coincide con el JSON canónico del contrato); la URL
 * absoluta del botón es {@code app.frontend-base-url + enlace} (CA 10.4).</p>
 */
@Service
public class CorreoNotificacionService {

    private static final Logger log = LoggerFactory.getLogger(CorreoNotificacionService.class);

    private final MensajePublicador publicador;
    private final AppProperties app;

    public CorreoNotificacionService(MensajePublicador publicador, AppProperties app) {
        this.publicador = publicador;
        this.app = app;
    }

    /**
     * @param notificacion fila ya en PENDIENTE con {@code correo_publicado_en} fijado en la
     *                     transacción de negocio (el publicador no escribe en base).
     * @param intentoInicial 1 en la publicación inicial; el re-publicador usa
     *                       {@code max(intento) + 1}.
     */
    public void publicar(Notificacion notificacion, int intentoInicial) {
        UUID mensajeId = UUID.randomUUID();
        ComandoEnviarCorreo comando = new ComandoEnviarCorreo(
                MensajePublicador.CONTRATO_VERSION,
                mensajeId,
                notificacion.getId(),
                intentoInicial,
                new ComandoEnviarCorreo.Destinatario(
                        notificacion.getDestinatario().getEmail(),
                        nombreCompleto(notificacion.getDestinatario())),
                notificacion.getTitulo(),
                notificacion.getTitulo(),
                notificacion.getMensaje(),
                new ComandoEnviarCorreo.Accion(
                        accionTexto(notificacion.getEnlace()),
                        urlAbsoluta(notificacion.getEnlace())),
                notificacion.getTipoNotificacion().getCategoria().name(),
                Instant.now()
        );
        publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_CORREO_ENVIAR, comando, mensajeId);
        log.debug("Comando de correo publicado para notificación {} (intento {})", notificacion.getId(), intentoInicial);
    }

    /** La etiqueta del botón se deriva del enlace persistido (§6.1). */
    static String accionTexto(String enlace) {
        if (enlace != null && enlace.contains("accion=revisar")) {
            return "Revisar solicitud";
        }
        if (enlace != null && enlace.contains("accion=corregir")) {
            return "Corregir solicitud";
        }
        return "Ver solicitud";
    }

    private String urlAbsoluta(String enlace) {
        if (enlace == null || enlace.isBlank()) {
            return app.frontendBaseUrl() != null ? app.frontendBaseUrl() : "";
        }
        String base = app.frontendBaseUrl() != null ? app.frontendBaseUrl() : "";
        return base + (enlace.startsWith("/") ? enlace : "/" + enlace);
    }

    private String nombreCompleto(UserAccount user) {
        if (user == null) {
            return "Usuario";
        }
        String nombre = user.getFirstName() != null ? user.getFirstName() : "";
        String apellido = user.getLastName() != null ? user.getLastName() : "";
        String full = (nombre + " " + apellido).trim();
        return full.isEmpty() ? user.getEmail() : full;
    }
}
