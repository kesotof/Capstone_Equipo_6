package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.mensajeria.MensajeriaProperties;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.notificacion.repository.NotificacionEnvioRepository;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Instant;
import java.util.List;

/**
 * F3 (§6.4) + C4: re-publicador de correos pendientes. Cada {@code mensajeria.republicador.intervalo}
 * publica de nuevo los comandos PENDIENTE cuya última publicación superó
 * {@code mensajeria.republicador.umbral-correo} (broker caído o mensaje perdido — CA 09.4).
 *
 * <ul>
 *   <li>Instancia única por transacción con {@code pg_try_advisory_xact_lock(41030, 1)} dentro
 *       de {@link TransactionTemplate}; si otro nodo tomó el lock, la pasada se salta.</li>
 *   <li>{@code FOR UPDATE SKIP LOCKED} para no duplicar trabajo si varios hilos corren.</li>
 *   <li>Alcanzado {@code max-publicaciones} la notificación pasa a FALLIDO con WARN.</li>
 *   <li>Cada re-publicación usa {@code intentoInicial = max(intento registrado) + 1}.</li>
 * </ul>
 */
@Component
@ConditionalOnProperty(prefix = "app.scheduling", name = "enabled", havingValue = "true")
public class RepublicadorPendientes {

    private static final Logger log = LoggerFactory.getLogger(RepublicadorPendientes.class);
    private static final int LOTE_MAXIMO = 100;

    private final NotificacionRepository notificacionRepository;
    private final NotificacionEnvioRepository envioRepository;
    private final CorreoNotificacionService correos;
    private final MensajeriaProperties propiedades;
    private final TransactionTemplate transactionTemplate;

    public RepublicadorPendientes(NotificacionRepository notificacionRepository,
                                  NotificacionEnvioRepository envioRepository,
                                  CorreoNotificacionService correos,
                                  MensajeriaProperties propiedades,
                                  TransactionTemplate transactionTemplate) {
        this.notificacionRepository = notificacionRepository;
        this.envioRepository = envioRepository;
        this.correos = correos;
        this.propiedades = propiedades;
        this.transactionTemplate = transactionTemplate;
    }

    @Scheduled(fixedDelayString = "${mensajeria.republicador.intervalo:PT2M}")
    public void programado() {
        Integer republicados = transactionTemplate.execute(status -> republicar());
        if (republicados != null && republicados > 0) {
            log.info("Re-publicador de correos: {} comando(s) re-publicado(s)", republicados);
        }
    }

    /** @return comandos efectivamente re-publicados (visible para las pruebas). */
    public int republicar() {
        Boolean lock = notificacionRepository.tryAdvisoryLockRepublicacion();
        if (!Boolean.TRUE.equals(lock)) {
            return 0;
        }
        Instant umbral = Instant.now().minus(propiedades.republicador().umbralCorreo());
        List<Notificacion> pendientes = notificacionRepository.pendientesDeRepublicacion(umbral, LOTE_MAXIMO);
        int republicados = 0;
        int maxPublicaciones = propiedades.republicador().maxPublicaciones();
        for (Notificacion notificacion : pendientes) {
            if (notificacion.getCorreoPublicaciones() >= maxPublicaciones) {
                notificacion.setEstadoCorreo(EstadoCorreo.FALLIDO);
                notificacionRepository.save(notificacion);
                log.warn("Notificación {} agotó las {} publicaciones de correo → FALLIDO",
                        notificacion.getId(), maxPublicaciones);
                continue;
            }
            int siguienteIntento = envioRepository.maximoIntento(notificacion.getId()) + 1;
            notificacion.setCorreoPublicaciones(notificacion.getCorreoPublicaciones() + 1);
            notificacion.setCorreoPublicadoEn(Instant.now());
            notificacionRepository.save(notificacion);
            correos.publicar(notificacion, siguienteIntento);
            republicados++;
        }
        return republicados;
    }
}
