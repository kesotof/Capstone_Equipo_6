package com.capstone.sistema.org.area.model;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class AreaJefaturaId implements Serializable {

    private Long areaId;
    private UUID usuarioId;

    public AreaJefaturaId() {
    }

    public AreaJefaturaId(Long areaId, UUID usuarioId) {
        this.areaId = areaId;
        this.usuarioId = usuarioId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(UUID usuarioId) {
        this.usuarioId = usuarioId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AreaJefaturaId that = (AreaJefaturaId) o;
        return Objects.equals(areaId, that.areaId) && Objects.equals(usuarioId, that.usuarioId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(areaId, usuarioId);
    }
}
