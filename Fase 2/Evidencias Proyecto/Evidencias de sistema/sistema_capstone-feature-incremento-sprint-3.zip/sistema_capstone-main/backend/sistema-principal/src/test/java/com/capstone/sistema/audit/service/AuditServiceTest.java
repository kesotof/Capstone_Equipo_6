package com.capstone.sistema.audit.service;

import com.capstone.sistema.audit.dto.AuditEventResponse;
import com.capstone.sistema.audit.model.LogEvento;
import com.capstone.sistema.audit.model.TipoEvento;
import com.capstone.sistema.audit.repository.LogEventoRepository;
import com.capstone.sistema.audit.repository.TipoEventoRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuditServiceTest {

    @Mock
    private LogEventoRepository logEventoRepository;
    @Mock
    private TipoEventoRepository tipoEventoRepository;
    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private PlatformTransactionManager transactionManager;

    @Test
    void registersLoginUsingTheAuthenticatedUsersEmailAndCapturesIp() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-Forwarded-For")).thenReturn("192.168.1.50");

        TipoEvento tipoLogin = new TipoEvento("LOGIN_EXITOSO", "AUTENTICACION", "Inicio de sesión");
        when(tipoEventoRepository.findByCodigoIgnoreCase("LOGIN_EXITOSO")).thenReturn(Optional.of(tipoLogin));

        UserAccount user = new UserAccount("keycloak-user-1", "admin@capstone.local", "Admin", "Capstone", true);
        when(userAccountRepository.findByKeycloakUserId("keycloak-user-1")).thenReturn(Optional.of(user));

        when(logEventoRepository.saveAndFlush(any(LogEvento.class))).thenAnswer(inv -> inv.getArgument(0));

        Jwt jwt = Jwt.withTokenValue("token")
                .header("alg", "none")
                .subject("keycloak-user-1")
                .claim("email", " ADMIN@CAPSTONE.LOCAL ")
                .build();

        AuditEventResponse response = service.registerLogin(jwt, request);

        ArgumentCaptor<LogEvento> event = ArgumentCaptor.forClass(LogEvento.class);
        verify(logEventoRepository).saveAndFlush(event.capture());
        assertThat(event.getValue().getTipoEvento().getTipo()).isEqualTo("LOGIN_EXITOSO");
        assertThat(event.getValue().getIpAddress()).isEqualTo("192.168.1.50");
        assertThat(event.getValue().getDetalle()).contains("admin@capstone.local");
        assertThat(response.email()).isEqualTo("admin@capstone.local");
        assertThat(response.eventType()).isEqualTo("LOGIN_EXITOSO");
    }

    @Test
    void registersLogoutUsingTheAuthenticatedUsersEmail() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getRemoteAddr()).thenReturn("10.0.0.1");

        TipoEvento tipoLogout = new TipoEvento("LOGOUT", "AUTENTICACION", "Cierre de sesión");
        when(tipoEventoRepository.findByCodigoIgnoreCase("LOGOUT")).thenReturn(Optional.of(tipoLogout));

        when(logEventoRepository.saveAndFlush(any(LogEvento.class))).thenAnswer(inv -> inv.getArgument(0));

        Jwt jwt = Jwt.withTokenValue("token")
                .header("alg", "none")
                .subject("keycloak-user-1")
                .claim("email", " admin@capstone.local ")
                .build();

        AuditEventResponse response = service.registerLogout(jwt, request);

        ArgumentCaptor<LogEvento> event = ArgumentCaptor.forClass(LogEvento.class);
        verify(logEventoRepository).saveAndFlush(event.capture());
        assertThat(event.getValue().getTipoEvento().getTipo()).isEqualTo("LOGOUT");
        assertThat(event.getValue().getIpAddress()).isEqualTo("10.0.0.1");
        assertThat(response.email()).isEqualTo("admin@capstone.local");
        assertThat(response.eventType()).isEqualTo("LOGOUT");
    }

    @Test
    void usesUsernameWhenTheTokenDoesNotContainAnEmail() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        HttpServletRequest request = mock(HttpServletRequest.class);

        TipoEvento tipoLogout = new TipoEvento("LOGOUT", "AUTENTICACION", "Cierre de sesión");
        when(tipoEventoRepository.findByCodigoIgnoreCase("LOGOUT")).thenReturn(Optional.of(tipoLogout));
        when(logEventoRepository.saveAndFlush(any(LogEvento.class))).thenAnswer(inv -> inv.getArgument(0));

        Jwt jwt = Jwt.withTokenValue("token")
                .header("alg", "none")
                .subject("keycloak-user-2")
                .claim("preferred_username", "usuario-operativo")
                .build();

        AuditEventResponse response = service.registerLogout(jwt, request);

        assertThat(response.email()).isEqualTo("usuario-operativo");
    }

    @Test
    void registersUserManagementActionsInDatabase() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        UserAccount targetUser = new UserAccount("kc-target-1", "operador@capstone.local", "Operador", "Prueba", true);

        String[] actions = {"CREAR_USUARIO", "ACTUALIZAR_USUARIO", "DESACTIVAR_USUARIO", "ACTIVAR_USUARIO", "ELIMINAR_USUARIO"};

        for (String action : actions) {
            TipoEvento tipoEvento = new TipoEvento(action, "ADMINISTRACION", "Evento de gestión de usuario");
            when(tipoEventoRepository.findByCodigoIgnoreCase(action)).thenReturn(Optional.of(tipoEvento));

            service.registerUserManagementEvent(action, targetUser, "Detalle de " + action + " para " + targetUser.getEmail());

            ArgumentCaptor<LogEvento> captor = ArgumentCaptor.forClass(LogEvento.class);
            verify(logEventoRepository).save(captor.capture());
            LogEvento saved = captor.getValue();

            assertThat(saved.getTipoEvento().getTipo()).isEqualTo(action);
            assertThat(saved.getUsuario()).isEqualTo(targetUser);
            assertThat(saved.getUsuarioEmail()).isEqualTo(targetUser.getEmail());
            assertThat(saved.getDetalle()).contains(action);
            assertThat(saved.getIpAddress()).isEqualTo("127.0.0.1");

            org.mockito.Mockito.reset(logEventoRepository);
        }
    }

    @Test
    void registersUserManagementEventCapturingActiveSessionUser() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        TipoEvento tipo = new TipoEvento("CREAR_USUARIO", "ADMINISTRACION", "Creación de usuario");
        when(tipoEventoRepository.findByCodigoIgnoreCase("CREAR_USUARIO")).thenReturn(Optional.of(tipo));

        UserAccount adminAccount = new UserAccount("kc-admin", "admin@capstone.local", "Admin", "User", true);
        when(userAccountRepository.findByEmailIgnoreCase("admin@capstone.local")).thenReturn(Optional.of(adminAccount));

        Jwt jwt = Jwt.withTokenValue("token")
                .header("alg", "none")
                .subject("kc-admin")
                .claim("email", "admin@capstone.local")
                .build();
        org.springframework.security.core.context.SecurityContextHolder.getContext().setAuthentication(
                new org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken(
                        jwt,
                        java.util.List.of(new org.springframework.security.core.authority.SimpleGrantedAuthority("ROLE_ADMIN"))
                )
        );

        try {
            UserAccount targetUser = new UserAccount("kc-target", "operador@capstone.local", "Operador", "Test", true);
            service.registerUserManagementEvent("CREAR_USUARIO", targetUser, "Usuario creado: operador@capstone.local");

            ArgumentCaptor<LogEvento> captor = ArgumentCaptor.forClass(LogEvento.class);
            verify(logEventoRepository).save(captor.capture());
            LogEvento saved = captor.getValue();

            // Debe capturar el usuario con sesión activa (admin) y su correo
            assertThat(saved.getUsuarioEmail()).isEqualTo("admin@capstone.local");
            assertThat(saved.getUsuario()).isEqualTo(adminAccount);
            assertThat(saved.getDetalle()).contains("operador@capstone.local");
        } finally {
            org.springframework.security.core.context.SecurityContextHolder.clearContext();
        }
    }

    @Test
    void leavesEmailEmptyWhenNoSessionActive() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        TipoEvento tipo = new TipoEvento("EVENTO_ANONIMO", "ADMINISTRACION", "Evento anónimo");
        when(tipoEventoRepository.findByCodigoIgnoreCase("EVENTO_ANONIMO")).thenReturn(Optional.of(tipo));

        org.springframework.security.core.context.SecurityContextHolder.clearContext();

        service.registerUserManagementEvent("EVENTO_ANONIMO", (UserAccount) null, "Acción no autenticada");

        ArgumentCaptor<LogEvento> captor = ArgumentCaptor.forClass(LogEvento.class);
        verify(logEventoRepository).save(captor.capture());
        LogEvento saved = captor.getValue();

        assertThat(saved.getUsuarioEmail()).isNull();
        assertThat(saved.getUsuario()).isNull();
    }

    @Test
    void listsRecentEventsOrderedFromDatabase() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        TipoEvento tipo = new TipoEvento("CREAR_USUARIO", "ADMINISTRACION", "Creación de usuario");
        UserAccount user = new UserAccount("kc-1", "admin@capstone.local", "Admin", "User", true);
        LogEvento evento = new LogEvento(tipo, user, "admin@capstone.local", "127.0.0.1", "Usuario creado");

        when(logEventoRepository.findAllByOrderByCreatedAtDesc()).thenReturn(java.util.List.of(evento));

        java.util.List<AuditEventResponse> results = service.listRecentEvents(10);

        assertThat(results).hasSize(1);
        assertThat(results.get(0).eventType()).isEqualTo("CREAR_USUARIO");
        assertThat(results.get(0).email()).isEqualTo("admin@capstone.local");
        verify(logEventoRepository).findAllByOrderByCreatedAtDesc();
    }

    @Test
    void sanitizesRawPasswordsAndTokensInAuditDetails() {
        AuditService service = new AuditService(logEventoRepository, tipoEventoRepository, userAccountRepository, transactionManager);
        TipoEvento tipo = new TipoEvento("ACTUALIZAR_USUARIO", "ADMINISTRACION", "Actualización de usuario");
        when(tipoEventoRepository.findByCodigoIgnoreCase("ACTUALIZAR_USUARIO")).thenReturn(Optional.of(tipo));

        UserAccount user = new UserAccount("kc-1", "user@capstone.local", "User", "Test", true);
        String unsafeDetail = "Cambio realizado con password=Secret123 y token=eyJh.bc.de para usuario";

        service.registerUserManagementEvent("ACTUALIZAR_USUARIO", user, unsafeDetail);

        ArgumentCaptor<LogEvento> captor = ArgumentCaptor.forClass(LogEvento.class);
        verify(logEventoRepository).save(captor.capture());
        LogEvento saved = captor.getValue();

        assertThat(saved.getDetalle()).doesNotContain("Secret123");
        assertThat(saved.getDetalle()).doesNotContain("eyJh.bc.de");
        assertThat(saved.getDetalle()).contains("password=[PROTECTED]");
        assertThat(saved.getDetalle()).contains("token=[PROTECTED]");
    }
}
