package com.capstone.sistema.ia.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * F6 (§6.8, D3-05): política de visibilidad y acceso a funciones de IA.
 * <ul>
 *   <li>{@code puedeVer}: la evaluación y el chat los ven el revisor de la etapa actual, los
 *       participantes de etapas anteriores y el administrador global. El emisor no los ve (403).</li>
 *   <li>{@code puedePreguntar}: solo el revisor de la etapa actual y el administrador global pueden
 *       preguntar o re-ejecutar, y la solicitud debe estar en PENDIENTE_REVISION.</li>
 *   <li>Sin acceso a la solicitud en absoluto → 404 (mismo comportamiento que el resto del sistema).</li>
 * </ul>
 */
@Component
public class IaAccesoPolicy {

    private final JdbcTemplate jdbc;

    public IaAccesoPolicy(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * Comprueba si la solicitud existe y el usuario tiene acceso básico a verla (en v_acceso_solicitud
     * o como admin global). Si devuelve false, la API debe responder 404.
     */
    public boolean existeSolicitudConAcceso(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        Boolean res = jdbc.queryForObject(
                """
                SELECT EXISTS (
                    SELECT 1 FROM solicitud s
                     WHERE s.id = ?
                       AND (es_admin_global(?) OR EXISTS (
                           SELECT 1 FROM v_acceso_solicitud vas
                            WHERE vas.solicitud_id = s.id AND vas.usuario_id = ?
                       ))
                )
                """,
                Boolean.class, solicitudId, usuarioId, usuarioId
        );
        return Boolean.TRUE.equals(res);
    }

    /**
     * D3-05: revisor actual, participante anterior o administrador global.
     */
    public boolean puedeVer(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        Boolean res = jdbc.queryForObject(
                """
                SELECT EXISTS (
                    SELECT 1 FROM solicitud s
                     WHERE s.id = ?
                       AND (es_admin_global(?) OR EXISTS (
                           SELECT 1 FROM v_acceso_solicitud vas
                            WHERE vas.solicitud_id = s.id
                              AND vas.usuario_id = ?
                              AND vas.motivo IN ('REVISOR', 'PARTICIPANTE')
                       ))
                )
                """,
                Boolean.class, solicitudId, usuarioId, usuarioId
        );
        return Boolean.TRUE.equals(res);
    }

    /**
     * Revisor asignado a la etapa actual de la solicitud o administrador global (independientemente del estado).
     */
    public boolean esRevisorActualOAdmin(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        Boolean res = jdbc.queryForObject(
                """
                SELECT EXISTS (
                    SELECT 1 FROM solicitud s
                     WHERE s.id = ?
                       AND (es_admin_global(?) OR EXISTS (
                           SELECT 1 FROM v_revisor_solicitud rs
                            WHERE rs.solicitud_id = s.id
                              AND rs.flujo_etapa_id = s.flujo_etapa_id
                              AND rs.usuario_id = ?
                       ))
                )
                """,
                Boolean.class, solicitudId, usuarioId, usuarioId
        );
        return Boolean.TRUE.equals(res);
    }

    /**
     * D3-05: solo revisor actual o admin global, Y solicitud en PENDIENTE_REVISION.
     */
    public boolean puedePreguntar(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        Boolean res = jdbc.queryForObject(
                """
                SELECT EXISTS (
                    SELECT 1 FROM solicitud s
                     WHERE s.id = ?
                       AND s.estado = 'PENDIENTE_REVISION'
                       AND (es_admin_global(?) OR EXISTS (
                           SELECT 1 FROM v_revisor_solicitud rs
                            WHERE rs.solicitud_id = s.id
                              AND rs.flujo_etapa_id = s.flujo_etapa_id
                              AND rs.usuario_id = ?
                       ))
                )
                """,
                Boolean.class, solicitudId, usuarioId, usuarioId
        );
        return Boolean.TRUE.equals(res);
    }
}
