package com.capstone.sistema.model.enums;

public enum AmbitoRol {
    AREA_O_GLOBAL,
    SOLO_GLOBAL
}
