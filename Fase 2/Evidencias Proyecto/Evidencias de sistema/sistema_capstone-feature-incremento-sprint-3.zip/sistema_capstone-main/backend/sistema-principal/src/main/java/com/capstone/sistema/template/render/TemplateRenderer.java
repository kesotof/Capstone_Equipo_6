package com.capstone.sistema.template.render;

import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldType;
import com.capstone.sistema.users.util.RutValidator;
import com.deepoove.poi.XWPFTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Renderizador de documentos DOCX a partir de plantillas y modelos de datos utilizando poi-tl.
 */
@Component
public class TemplateRenderer {

    private static final Logger log = LoggerFactory.getLogger(TemplateRenderer.class);
    private static final DateTimeFormatter CHILEAN_DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    /**
     * Renderiza una plantilla DOCX con los datos provistos y retorna los bytes del nuevo DOCX generado.
     */
    public byte[] render(byte[] docxTemplateBytes, List<FieldDefinition> fieldDefs, Map<String, Object> data) {
        if (docxTemplateBytes == null || docxTemplateBytes.length == 0) {
            throw new IllegalArgumentException("El archivo base de la plantilla no puede estar vacío");
        }

        Map<String, Object> renderModel = prepareDataModel(fieldDefs, data);

        try (InputStream in = new ByteArrayInputStream(docxTemplateBytes);
             XWPFTemplate template = XWPFTemplate.compile(in)) {

            template.render(renderModel);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            template.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            log.error("Error al renderizar plantilla con poi-tl: {}", e.getMessage(), e);
            throw new IllegalStateException("Error al generar documento a partir de la plantilla: " + e.getMessage(), e);
        }
    }

    /**
     * Prepara el mapa de variables para poi-tl, aplicando formato amigable para RUTs, fechas y booleanos.
     */
    public Map<String, Object> prepareDataModel(List<FieldDefinition> fieldDefs, Map<String, Object> rawData) {
        Map<String, Object> model = new HashMap<>();
        Map<String, Object> safeRaw = rawData != null ? rawData : Map.of();

        // Crear mapa indexado por key para acceder a los tipos
        Map<String, FieldDefinition> defsByKey = new HashMap<>();
        if (fieldDefs != null) {
            for (FieldDefinition def : fieldDefs) {
                defsByKey.put(def.key(), def);
                // Inicializar por defecto en cadena vacía para evitar huecos 'null'
                model.put(def.key(), "");
            }
        }

        for (Map.Entry<String, Object> entry : safeRaw.entrySet()) {
            String key = entry.getKey();
            Object val = entry.getValue();

            if (val == null) {
                model.put(key, "");
                continue;
            }

            FieldDefinition def = defsByKey.get(key);
            FieldType type = def != null ? def.tipo() : null;

            if (type == FieldType.BOOLEANO || val instanceof Boolean) {
                boolean boolVal = val instanceof Boolean b ? b : Boolean.parseBoolean(val.toString());
                model.put(key, boolVal ? "Sí" : "No");
            } else if (type == FieldType.RUT && val instanceof String s && RutValidator.esValido(s)) {
                try {
                    String norm = RutValidator.normalizar(s);
                    // Formato con puntos: 12.345.678-K
                    String cuerpo = norm.substring(0, norm.length() - 2);
                    String dv = norm.substring(norm.length() - 1);
                    StringBuilder conPuntos = new StringBuilder();
                    int count = 0;
                    for (int i = cuerpo.length() - 1; i >= 0; i--) {
                        conPuntos.insert(0, cuerpo.charAt(i));
                        count++;
                        if (count % 3 == 0 && i > 0) {
                            conPuntos.insert(0, '.');
                        }
                    }
                    model.put(key, conPuntos + "-" + dv);
                } catch (Exception e) {
                    model.put(key, val.toString());
                }
            } else if (type == FieldType.FECHA && val instanceof String s) {
                try {
                    LocalDate ld = LocalDate.parse(s.trim());
                    model.put(key, ld.format(CHILEAN_DATE_FORMAT));
                } catch (Exception e) {
                    model.put(key, val.toString());
                }
            } else if (type == FieldType.NUMERO) {
                model.put(key, formatearNumero(val, "#,##0.##"));
            } else if (type == FieldType.MONTO) {
                model.put(key, "$" + formatearNumero(val, "#,##0"));
            } else {
                model.put(key, val.toString());
            }
        }

        return model;
    }

    /** Número con formato chileno: separador de miles '.', decimales ',' (hasta 2): 1500000.5 -> 1.500.000,5. */
    private static String formatearNumero(Object val, String patron) {
        try {
            BigDecimal numero = new BigDecimal(val.toString().trim().replace(",", "."));
            DecimalFormat formato = new DecimalFormat(patron, DecimalFormatSymbols.getInstance(Locale.forLanguageTag("es-CL")));
            // Igual que el redondeo de la vista previa del navegador (Math.round).
            formato.setRoundingMode(RoundingMode.HALF_UP);
            return formato.format(numero);
        } catch (NumberFormatException e) {
            return val.toString();
        }
    }
}
