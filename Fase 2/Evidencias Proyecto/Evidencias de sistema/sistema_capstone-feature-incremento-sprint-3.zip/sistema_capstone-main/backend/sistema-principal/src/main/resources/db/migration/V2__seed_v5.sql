-- =============================================================================
-- Sistema de Gestión Documental y Flujos de Aprobación — Modelo de datos v5
-- V2__seed_v5.sql (DML) — Catálogos y Datos Semilla
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. ESTADO_SOLICITUD y ACCION_TRANSICION
-- -----------------------------------------------------------------------------
INSERT INTO estado_solicitud (codigo, etiqueta, orden, es_final) VALUES
    ('PENDIENTE_REVISION',   'Pendiente de revisión', 1, false),
    ('CORRECCION_REQUERIDA', 'Corrección requerida',  2, false),
    ('APROBADO',             'Aprobado',              3, true),
    ('RECHAZADO',            'Rechazado',             4, true)
ON CONFLICT (codigo) DO UPDATE SET
    etiqueta = EXCLUDED.etiqueta,
    orden = EXCLUDED.orden,
    es_final = EXCLUDED.es_final;

INSERT INTO accion_transicion (codigo, etiqueta) VALUES
    ('REGISTRAR',            'Registrar'),
    ('APROBAR',              'Aprobar'),
    ('RECHAZAR',             'Rechazar'),
    ('SOLICITAR_CORRECCION', 'Solicitar corrección'),
    ('CORREGIR',             'Corregir')
ON CONFLICT (codigo) DO UPDATE SET
    etiqueta = EXCLUDED.etiqueta;

-- -----------------------------------------------------------------------------
-- 2. PERMISOS
-- -----------------------------------------------------------------------------
INSERT INTO permiso (recurso, accion, descripcion, ambito) VALUES
    ('USUARIO',        'GESTIONAR', 'Crear, editar y desactivar usuarios',                                 'SOLO_GLOBAL'),
    ('AREA',           'GESTIONAR', 'Crear, editar y desactivar áreas y asignar jefaturas',                'SOLO_GLOBAL'),
    ('TIPO_DOCUMENTO', 'GESTIONAR', 'Configurar tipos de documento, prefijos y plazos',                    'SOLO_GLOBAL'),
    ('ROL',            'GESTIONAR', 'Crear y editar roles y asignar accesos',                              'SOLO_GLOBAL'),
    ('AUDITORIA',      'VER',       'Consultar el registro de auditoría',                                  'SOLO_GLOBAL'),
    ('SOLICITUD',      'VER',       'Ver solicitudes, documentos e historial del área',                    'AREA_O_GLOBAL'),
    ('DOCUMENTO',      'DESCARGAR', 'Descargar y previsualizar archivos de solicitudes del área',          'AREA_O_GLOBAL'),
    ('DASHBOARD',      'VER',       'Ver métricas y resumen de solicitudes del área',                      'AREA_O_GLOBAL'),
    ('PLANTILLA',      'CREAR',     'Crear plantillas en el área',                                         'AREA_O_GLOBAL'),
    ('PLANTILLA',      'EDITAR',    'Publicar nuevas versiones y editar datos de plantillas del área',     'AREA_O_GLOBAL'),
    ('PLANTILLA',      'ELIMINAR',  'Eliminar (o desactivar, si ya se usaron) plantillas del área',        'AREA_O_GLOBAL'),
    ('FLUJO',          'GESTIONAR', 'Crear y configurar flujos, etapas y revisores',                       'AREA_O_GLOBAL')
ON CONFLICT (recurso, accion) DO UPDATE SET
    descripcion = EXCLUDED.descripcion,
    ambito = EXCLUDED.ambito;

-- -----------------------------------------------------------------------------
-- 3. TIPOS DE EVENTO DE AUDITORÍA
-- -----------------------------------------------------------------------------
INSERT INTO tipo_evento (codigo, categoria, descripcion) VALUES
    -- Autenticación
    ('LOGIN_EXITOSO',                 'AUTENTICACION',  'Inicio de sesión exitoso'),
    ('LOGIN_FALLIDO',                 'AUTENTICACION',  'Intento fallido de autenticación'),
    ('CUENTA_BLOQUEADA',              'AUTENTICACION',  'Cuenta bloqueada por reintento fallido'),
    ('LOGOUT',                        'AUTENTICACION',  'Cierre de sesión'),
    ('CONTRASENA_CAMBIADA',           'AUTENTICACION',  'Cambio de contraseña exitoso'),
    ('RECUPERACION_SOLICITADA',       'AUTENTICACION',  'Solicitud de restablecimiento de contraseña'),
    ('RECUPERACION_COMPLETADA',       'AUTENTICACION',  'Restablecimiento de contraseña completado'),

    -- Administración
    ('USUARIO_CREADO',                'ADMINISTRACION', 'Usuario creado en el sistema'),
    ('USUARIO_EDITADO',               'ADMINISTRACION', 'Datos de usuario actualizados'),
    ('USUARIO_DESACTIVADO',           'ADMINISTRACION', 'Usuario desactivado'),
    ('USUARIO_ACTIVADO',              'ADMINISTRACION', 'Usuario reactivado'),
    ('USUARIO_AREA_CAMBIADA',         'ADMINISTRACION', 'Área asignada al usuario modificada'),
    ('AREA_CREADA',                   'ADMINISTRACION', 'Área creada en la estructura organizacional'),
    ('AREA_EDITADA',                  'ADMINISTRACION', 'Área actualizada'),
    ('AREA_DESACTIVADA',              'ADMINISTRACION', 'Área desactivada'),
    ('AREA_ACTIVADA',                 'ADMINISTRACION', 'Área reactivada'),
    ('JEFATURA_ASIGNADA',             'ADMINISTRACION', 'Jefatura asignada a un área'),
    ('JEFATURA_REMOVIDA',             'ADMINISTRACION', 'Jefatura removida de un área'),
    ('ROL_CREADO',                    'ADMINISTRACION', 'Rol creado en el catálogo RBAC'),
    ('ROL_EDITADO',                   'ADMINISTRACION', 'Rol actualizado'),
    ('ROL_DESACTIVADO',               'ADMINISTRACION', 'Rol desactivado'),
    ('ROL_ASIGNADO',                  'ADMINISTRACION', 'Rol asignado a un usuario'),
    ('ROL_REVOCADO',                  'ADMINISTRACION', 'Rol revocado de un usuario'),
    ('FLUJO_CREADO',                  'ADMINISTRACION', 'Flujo de aprobación creado'),
    ('FLUJO_EDITADO',                 'ADMINISTRACION', 'Flujo de aprobación modificado'),
    ('FLUJO_DESACTIVADO',             'ADMINISTRACION', 'Flujo desactivado'),
    ('FLUJO_ACTIVADO',                'ADMINISTRACION', 'Flujo reactivado'),
    ('FLUJO_VERSION_CREADA',          'ADMINISTRACION', 'Nueva versión de flujo creada'),
    ('REVISOR_ASIGNADO',              'ADMINISTRACION', 'Revisor asignado a etapa de flujo'),
    ('REVISOR_REMOVIDO',              'ADMINISTRACION', 'Revisor removido de etapa de flujo'),
    ('TIPO_DOCUMENTO_CREADO',         'ADMINISTRACION', 'Tipo de documento y SLA creado'),
    ('TIPO_DOCUMENTO_EDITADO',        'ADMINISTRACION', 'Tipo de documento o SLA modificado'),
    ('PLAZO_MODIFICADO',              'ADMINISTRACION', 'Plazo SLA actualizado'),
    ('PLANTILLA_CREADA',              'ADMINISTRACION', 'Plantilla dinámica creada'),
    ('PLANTILLA_EDITADA',             'ADMINISTRACION', 'Metadatos de plantilla editados'),
    ('PLANTILLA_VERSION_PUBLICADA',   'ADMINISTRACION', 'Nueva versión de plantilla publicada'),
    ('PLANTILLA_DESACTIVADA',         'ADMINISTRACION', 'Plantilla desactivada'),
    ('PLANTILLA_ELIMINADA',           'ADMINISTRACION', 'Plantilla eliminada físicamente'),

    -- Flujo operacional
    ('SOLICITUD_REGISTRADA',          'FLUJO',          'Solicitud emitida e ingresada a revisión'),
    ('DOCUMENTO_GENERADO',            'FLUJO',          'Documento generado desde plantilla'),
    ('SOLICITUD_APROBADA',            'FLUJO',          'Solicitud aprobada'),
    ('SOLICITUD_RECHAZADA',           'FLUJO',          'Solicitud rechazada'),
    ('CORRECCION_SOLICITADA',         'FLUJO',          'Solicitud devuelta para correcciones'),
    ('SOLICITUD_CORREGIDA',           'FLUJO',          'Solicitud corregida y reenviada'),
    ('ANALISIS_IA_SOLICITADO',        'FLUJO',          'Análisis de IA solicitado para la solicitud'),

    -- Acceso y consulta
    ('SOLICITUD_COMPARTIDA',          'ACCESO',         'Acceso a solicitud compartido'),
    ('ACCESO_REVOCADO',               'ACCESO',         'Acceso compartido revocado'),
    ('SOLICITUD_VISUALIZADA',         'ACCESO',         'Detalle de solicitud visualizado'),
    ('DOCUMENTO_VISUALIZADO',         'ACCESO',         'Documento previsualizado en el visor'),
    ('DOCUMENTO_DESCARGADO',          'ACCESO',         'Documento descargado desde almacenamiento'),
    ('DASHBOARD_VISUALIZADO',         'ACCESO',         'Panel de control o métricas consultadas'),
    ('ACCESO_DENEGADO',               'ACCESO',         'Intento de acceso denegado por políticas de seguridad')
ON CONFLICT (codigo) DO UPDATE SET
    categoria = EXCLUDED.categoria,
    descripcion = EXCLUDED.descripcion;

-- -----------------------------------------------------------------------------
-- 4. TIPOS DE NOTIFICACIÓN
-- -----------------------------------------------------------------------------
INSERT INTO tipo_notificacion (codigo, descripcion) VALUES
    ('REVISION_ASIGNADA',          'Revisor: hay una solicitud pendiente de revisión'),
    ('SOLICITUD_AVANZA',           'Emisor: la solicitud pasó a la siguiente etapa'),
    ('SOLICITUD_APROBADA',         'Emisor: la solicitud fue aprobada'),
    ('SOLICITUD_RECHAZADA',        'Emisor: la solicitud fue rechazada'),
    ('CORRECCION_REQUERIDA',       'Emisor: se solicitaron correcciones'),
    ('SOLICITUD_COMPARTIDA_CONTIGO','Se compartió una solicitud contigo o con tu área'),
    ('PLAZO_POR_VENCER',           'Revisor: el plazo de revisión está por vencer'),
    ('PLAZO_VENCIDO',              'Revisor: el plazo de revisión venció')
ON CONFLICT (codigo) DO UPDATE SET
    descripcion = EXCLUDED.descripcion;

-- -----------------------------------------------------------------------------
-- 5. TIPOS DE DOCUMENTO (SLA Y CORRELATIVO)
-- -----------------------------------------------------------------------------
INSERT INTO tipo_documento (id, nombre, descripcion, prefijo, plazo_dias_habiles, ultimo_correlativo, activo) VALUES
    (1, 'Contrato',  'Contratos y acuerdos legales',             'CONT', 5, 0, true),
    (2, 'Factura',   'Facturas comerciales y tributarias',       'FAC',  3, 0, true),
    (3, 'Informe',   'Informes técnicos y ejecutivos',           'INF',  7, 0, true),
    (4, 'Memorando', 'Comunicaciones y memorandos internos',     'MEMO', 2, 0, true),
    (5, 'General',   'Documentación general y otros trámites',   'GEN',  5, 0, true)
ON CONFLICT (id) DO UPDATE SET
    nombre = EXCLUDED.nombre,
    descripcion = EXCLUDED.descripcion,
    prefijo = EXCLUDED.prefijo,
    plazo_dias_habiles = EXCLUDED.plazo_dias_habiles,
    activo = EXCLUDED.activo;

SELECT setval(pg_get_serial_sequence('tipo_documento', 'id'), COALESCE(max(id), 1)) FROM tipo_documento;

-- -----------------------------------------------------------------------------
-- 6. ESTRUCTURA ORGANIZACIONAL BASE
-- -----------------------------------------------------------------------------
INSERT INTO area (id, nombre, descripcion, area_padre_id, activo) VALUES
    (1, 'Gerencia General', 'Dirección general corporativa', NULL, true),
    (2, 'Finanzas',         'Área financiera y contable',    1,    true),
    (3, 'Operaciones',      'Área de operaciones y logística',1,   true),
    (4, 'Recursos Humanos', 'Gestión de personas y talento', 1,    true)
ON CONFLICT (id) DO UPDATE SET
    nombre = EXCLUDED.nombre,
    descripcion = EXCLUDED.descripcion,
    area_padre_id = EXCLUDED.area_padre_id,
    activo = EXCLUDED.activo;

SELECT setval(pg_get_serial_sequence('area', 'id'), COALESCE(max(id), 1)) FROM area;

-- -----------------------------------------------------------------------------
-- 7. FLUJO BASE GLOBAL "Revisión Simple"
-- -----------------------------------------------------------------------------
INSERT INTO flujo_definicion (id, nombre, version, descripcion, area_id, activo) VALUES
    (1, 'Revisión Simple', 1, 'Flujo base global de 1 etapa para revisión por jefatura', NULL, true)
ON CONFLICT (id) DO UPDATE SET
    nombre = EXCLUDED.nombre,
    version = EXCLUDED.version,
    descripcion = EXCLUDED.descripcion,
    area_id = EXCLUDED.area_id,
    activo = EXCLUDED.activo;

SELECT setval(pg_get_serial_sequence('flujo_definicion', 'id'), COALESCE(max(id), 1)) FROM flujo_definicion;

INSERT INTO flujo_etapa (id, flujo_definicion_id, orden, nombre, modo_revisor) VALUES
    (1, 1, 1, 'Revisión', 'JEFATURA_AREA_SOLICITUD')
ON CONFLICT (id) DO UPDATE SET
    flujo_definicion_id = EXCLUDED.flujo_definicion_id,
    orden = EXCLUDED.orden,
    nombre = EXCLUDED.nombre,
    modo_revisor = EXCLUDED.modo_revisor;

SELECT setval(pg_get_serial_sequence('flujo_etapa', 'id'), COALESCE(max(id), 1)) FROM flujo_etapa;

-- -----------------------------------------------------------------------------
-- 8. ROLES DE SISTEMA Y SUS PERMISOS
-- -----------------------------------------------------------------------------
INSERT INTO rol (id, codigo, nombre, descripcion, sistema, asignacion, ambito, permisos_bloqueados, activo) VALUES
    (1, 'JEFATURA_AREA',  'Jefatura de área',           'Rol automático asignado a las jefaturas de área', true, 'AUTO_JEFATURA', 'AREA_O_GLOBAL', false, true),
    (2, 'ADMIN_AREA',     'Administrador de área',      'Administración funcional del área',               true, 'MANUAL',        'AREA_O_GLOBAL', false, true),
    (3, 'LECTOR',         'Lector',                     'Acceso de consulta a solicitudes y dashboards',   true, 'MANUAL',        'AREA_O_GLOBAL', false, true),
    (4, 'AUDITOR',        'Auditor',                    'Auditoría y consulta transversal',                true, 'MANUAL',        'SOLO_GLOBAL',   false, true),
    (5, 'ADMIN_SISTEMA',  'Administrador del sistema',  'Control total de la plataforma',                  true, 'MANUAL',        'SOLO_GLOBAL',   false, true)
ON CONFLICT (id) DO UPDATE SET
    codigo = EXCLUDED.codigo,
    nombre = EXCLUDED.nombre,
    descripcion = EXCLUDED.descripcion,
    sistema = EXCLUDED.sistema,
    asignacion = EXCLUDED.asignacion,
    ambito = EXCLUDED.ambito,
    activo = EXCLUDED.activo;

SELECT setval(pg_get_serial_sequence('rol', 'id'), COALESCE(max(id), 1)) FROM rol;

-- Permisos de JEFATURA_AREA
INSERT INTO rol_permiso (rol_id, permiso_id)
SELECT 1, p.id
  FROM permiso p
 WHERE (p.recurso = 'SOLICITUD'      AND p.accion = 'VER')
    OR (p.recurso = 'DOCUMENTO'      AND p.accion = 'DESCARGAR')
    OR (p.recurso = 'DASHBOARD'      AND p.accion = 'VER')
    OR (p.recurso = 'PLANTILLA'      AND p.accion IN ('CREAR', 'EDITAR', 'ELIMINAR'))
    OR (p.recurso = 'FLUJO'          AND p.accion = 'GESTIONAR')
ON CONFLICT DO NOTHING;

-- Permisos de ADMIN_AREA
INSERT INTO rol_permiso (rol_id, permiso_id)
SELECT 2, p.id
  FROM permiso p
 WHERE (p.recurso = 'FLUJO'          AND p.accion = 'GESTIONAR')
    OR (p.recurso = 'PLANTILLA'      AND p.accion IN ('CREAR', 'EDITAR', 'ELIMINAR'))
    OR (p.recurso = 'DASHBOARD'      AND p.accion = 'VER')
ON CONFLICT DO NOTHING;

-- Permisos de LECTOR
INSERT INTO rol_permiso (rol_id, permiso_id)
SELECT 3, p.id
  FROM permiso p
 WHERE (p.recurso = 'SOLICITUD'      AND p.accion = 'VER')
    OR (p.recurso = 'DOCUMENTO'      AND p.accion = 'DESCARGAR')
    OR (p.recurso = 'DASHBOARD'      AND p.accion = 'VER')
ON CONFLICT DO NOTHING;

-- Permisos de AUDITOR
INSERT INTO rol_permiso (rol_id, permiso_id)
SELECT 4, p.id
  FROM permiso p
 WHERE (p.recurso = 'SOLICITUD'      AND p.accion = 'VER')
    OR (p.recurso = 'DOCUMENTO'      AND p.accion = 'DESCARGAR')
    OR (p.recurso = 'DASHBOARD'      AND p.accion = 'VER')
    OR (p.recurso = 'AUDITORIA'      AND p.accion = 'VER')
ON CONFLICT DO NOTHING;

-- Permisos de ADMIN_SISTEMA (Todos los permisos)
INSERT INTO rol_permiso (rol_id, permiso_id)
SELECT 5, p.id
  FROM permiso p
ON CONFLICT DO NOTHING;

-- Bloquear permisos de ADMIN_SISTEMA una vez sembrados
UPDATE rol SET permisos_bloqueados = true WHERE id = 5;
