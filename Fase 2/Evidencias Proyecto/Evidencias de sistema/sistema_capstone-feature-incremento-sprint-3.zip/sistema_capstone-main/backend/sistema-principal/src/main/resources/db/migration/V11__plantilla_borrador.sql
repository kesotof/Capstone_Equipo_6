-- Borradores del editor de plantillas: trabajo sin publicar de una plantilla nueva (plantilla_id NULL) o de la
-- próxima versión de una existente. Son de quien los guarda; el documento Word vive en MinIO (storage_key).
CREATE TABLE plantilla_borrador (
    id             UUID         PRIMARY KEY,
    plantilla_id   BIGINT       REFERENCES plantilla(id) ON DELETE CASCADE,
    version_base   INTEGER,
    usuario_id     UUID         NOT NULL REFERENCES usuario(id),
    nombre         VARCHAR(150) NOT NULL,
    datos          JSONB        NOT NULL,
    nombre_archivo VARCHAR(255) NOT NULL,
    storage_key    VARCHAR(500) NOT NULL,
    created_at     TIMESTAMPTZ  DEFAULT now() NOT NULL,
    updated_at     TIMESTAMPTZ  DEFAULT now() NOT NULL
);
CREATE INDEX idx_plantilla_borrador_usuario ON plantilla_borrador (usuario_id);
-- Un solo borrador por persona para la próxima versión de cada plantilla.
CREATE UNIQUE INDEX uq_plantilla_borrador_edicion ON plantilla_borrador (plantilla_id, usuario_id) WHERE plantilla_id IS NOT NULL;
