package com.capstone.sistema.flow;

/**
 * Constantes de routing keys para integración de plantillas e IA en RabbitMQ.
 * La configuración de beans (Exchange, Template, Converter) reside en MensajeriaConfig.
 */
public final class RabbitConfig {

    private RabbitConfig() {}

    public static final String EXCHANGE_NAME = "capstone.exchange";
    public static final String AI_AUTOCOMPLETE_ROUTING_KEY = "ai.autocomplete";
    public static final String AI_AUTOCOMPLETE_RESULT_ROUTING_KEY = "ai.autocomplete.result";
    public static final String AI_FIELDS_ROUTING_KEY = "ai.fields";
    public static final String AI_FIELDS_RESULT_ROUTING_KEY = "ai.fields.result";
}
