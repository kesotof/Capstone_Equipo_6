package com.capstone.sistema.audit.service;

import com.capstone.sistema.audit.dto.AuditEventResponse;
import com.capstone.sistema.audit.model.LogEvento;
import com.capstone.sistema.audit.model.TipoEvento;
import com.capstone.sistema.audit.repository.LogEventoRepository;
import com.capstone.sistema.audit.repository.TipoEventoRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Locale;
import java.util.Optional;

/**
 * Registro de auditoría en LOG_EVENTO.
 *
 * <p>Política de transacción (un evento por acción de negocio, solo si la acción se confirma):
 * <ul>
 *   <li>Eventos con resultado {@code EXITO} emitidos dentro de una transacción de negocio activa se
 *       difieren a {@code afterCommit} y se escriben en una transacción nueva (REQUIRES_NEW). Si la
 *       operación de negocio hace rollback, el evento no se registra.</li>
 *   <li>Eventos {@code FALLO}/{@code DENEGADO} (por ejemplo ACCESO_DENEGADO), o emitidos sin
 *       transacción activa, se escriben de inmediato en una transacción nueva, para que sobrevivan al
 *       rollback de la operación que los provocó.</li>
 *   <li>Un error de auditoría (tipo inexistente en el catálogo, error de base de datos) se registra en
 *       el log con nivel ERROR y no interrumpe la operación de negocio.</li>
 * </ul>
 * Los datos de contexto (actor, IP, request id) se capturan en el momento de la llamada.
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private static final String RESULTADO_EXITO = "EXITO";

    private final LogEventoRepository logEventoRepository;
    private final TipoEventoRepository tipoEventoRepository;
    private final UserAccountRepository userAccountRepository;
    private final TransactionTemplate requiresNew;

    public AuditService(
            LogEventoRepository logEventoRepository,
            TipoEventoRepository tipoEventoRepository,
            UserAccountRepository userAccountRepository,
            PlatformTransactionManager transactionManager
    ) {
        this.logEventoRepository = logEventoRepository;
        this.tipoEventoRepository = tipoEventoRepository;
        this.userAccountRepository = userAccountRepository;
        this.requiresNew = new TransactionTemplate(transactionManager);
        this.requiresNew.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditEventResponse registerLogin(Jwt jwt, HttpServletRequest request) {
        String email = resolveEmail(jwt);
        String ipAddress = resolveClientIp(request);
        UserAccount user = findUser(jwt, email);

        TipoEvento tipoEvento = requireTipoEvento("LOGIN_EXITOSO");
        LogEvento logEvento = new LogEvento(
                tipoEvento,
                user,
                email,
                ipAddress,
                "Inicio de sesión exitoso de " + email
        );
        logEvento.setRequestId(resolveCurrentRequestId());

        LogEvento saved = logEventoRepository.saveAndFlush(logEvento);
        log.info("Inicio de sesión registrado en log_evento (id={}) para {} desde IP {}", saved.getId(), email, ipAddress);

        return new AuditEventResponse(
                saved.getId(),
                email,
                saved.getTipoEvento().getCodigo(),
                saved.getIpAddress(),
                saved.getDetalle(),
                saved.getCreatedAt()
        );
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditEventResponse registerLogout(Jwt jwt, HttpServletRequest request) {
        String email = resolveEmail(jwt);
        String ipAddress = resolveClientIp(request);
        UserAccount user = findUser(jwt, email);

        TipoEvento tipoEvento = requireTipoEvento("LOGOUT");
        LogEvento logEvento = new LogEvento(
                tipoEvento,
                user,
                email,
                ipAddress,
                "Cierre de sesión de " + email
        );
        logEvento.setRequestId(resolveCurrentRequestId());

        LogEvento saved = logEventoRepository.saveAndFlush(logEvento);
        log.info("Cierre de sesión registrado en log_evento (id={}) para {} desde IP {}", saved.getId(), email, ipAddress);

        return new AuditEventResponse(
                saved.getId(),
                email,
                saved.getTipoEvento().getCodigo(),
                saved.getIpAddress(),
                saved.getDetalle(),
                saved.getCreatedAt()
        );
    }

    private static final java.util.regex.Pattern SENSITIVE_PATTERN =
            java.util.regex.Pattern.compile("(?i)(password|contrasena|contraseña|secret|token|credencial|bearer)\\s*[:=]\\s*[^\\s,;\\]]+");

    public static String sanitize(String input) {
        if (input == null) {
            return null;
        }
        return SENSITIVE_PATTERN.matcher(input).replaceAll("$1=[PROTECTED]");
    }

    public void registerEvent(String tipo, String detalle) {
        registerEvent(tipo, null, detalle);
    }

    public void registerEvent(String tipo, UserAccount actor, String detalle) {
        String clientIp = resolveCurrentClientIp();
        String emailToStore = actor != null ? actor.getEmail() : resolveCurrentActiveEmail();
        String sanitizedDetalle = sanitize(detalle);
        String requestId = resolveCurrentRequestId();
        dispatch(tipo, RESULTADO_EXITO, () -> {
            Optional<TipoEvento> tipoEvento = findTipoEvento(tipo);
            if (tipoEvento.isEmpty()) {
                return;
            }
            LogEvento logEvento = new LogEvento(tipoEvento.get(), actor, emailToStore, clientIp, sanitizedDetalle);
            logEvento.setRequestId(requestId);
            logEventoRepository.save(logEvento);
            log.info("Evento de auditoría {} registrado por [{}] desde IP {} reqId={}: {}",
                    tipo, emailToStore != null ? emailToStore : "ANONIMO", clientIp, requestId, sanitizedDetalle);
        });
    }

    /**
     * Registra un evento sobre una entidad concreta. Forma preferida: un evento por acción de negocio,
     * con {@code entidad}/{@code entidadId} de la entidad afectada y un detalle legible.
     */
    public void registerAuditEvent(String tipo, String entidad, String entidadId, String resultado, String datosDespues) {
        String activeEmail = resolveCurrentActiveEmail();
        String clientIp = resolveCurrentClientIp();
        String requestId = resolveCurrentRequestId();
        UserAccount actor = resolveCurrentActor(activeEmail);
        String sanitized = sanitize(datosDespues);
        String resultadoFinal = resultado != null ? resultado : RESULTADO_EXITO;
        dispatch(tipo, resultadoFinal, () -> {
            Optional<TipoEvento> tipoEvento = findTipoEvento(tipo);
            if (tipoEvento.isEmpty()) {
                return;
            }
            LogEvento logEvento = new LogEvento(
                    tipoEvento.get(),
                    actor,
                    activeEmail,
                    entidad,
                    entidadId,
                    resultadoFinal,
                    null,
                    sanitized,
                    clientIp,
                    null,
                    requestId
            );
            logEventoRepository.save(logEvento);
            log.info("Evento de auditoría {} registrado para {}:{} ({}) desde IP {} reqId={}",
                    tipo, entidad, entidadId, resultadoFinal, clientIp, requestId);
        });
    }

    public void registerUserManagementEvent(String tipo, String detalle) {
        registerUserManagementEvent(tipo, (UserAccount) null, detalle);
    }

    public void registerUserManagementEvent(String tipo, UserAccount targetUser, String detalle) {
        String activeEmail = resolveCurrentActiveEmail();
        String clientIp = resolveCurrentClientIp();
        String requestId = resolveCurrentRequestId();

        // El usuario con sesión activa que realiza la acción se asocia al evento
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserAccount actor = authentication != null && authentication.getPrincipal() instanceof Jwt
                ? resolveCurrentActor(activeEmail)
                : targetUser;
        String emailToStore = actor != null ? actor.getEmail() : activeEmail;
        String sanitizedDetalle = sanitize(detalle);

        dispatch(tipo, RESULTADO_EXITO, () -> {
            Optional<TipoEvento> tipoEvento = findTipoEvento(tipo);
            if (tipoEvento.isEmpty()) {
                return;
            }
            LogEvento logEvento = new LogEvento(tipoEvento.get(), actor, emailToStore, clientIp, sanitizedDetalle);
            logEvento.setRequestId(requestId);
            logEventoRepository.save(logEvento);
            log.info("Evento de auditoría {} registrado por [{}] desde IP {}: {}",
                    tipo, emailToStore != null ? emailToStore : "ANONIMO", clientIp, sanitizedDetalle);
        });
    }

    @Transactional(readOnly = true)
    public java.util.List<AuditEventResponse> listRecentEvents(int limit) {
        return logEventoRepository.findAllByOrderByCreatedAtDesc().stream()
                .limit(Math.max(1, Math.min(limit, 1000)))
                .map(e -> {
                    String email = e.getUsuarioEmail();
                    if (email == null || email.isBlank()) {
                        email = e.getUsuario() != null ? e.getUsuario().getEmail() : "";
                    }
                    return new AuditEventResponse(
                            e.getId(),
                            email,
                            e.getTipoEvento().getCodigo(),
                            e.getIpAddress(),
                            e.getDetalle(),
                            e.getCreatedAt(),
                            e.getEntidad(),
                            e.getEntidadId(),
                            e.getCreatedAt()
                    );
                })
                .toList();
    }

    /**
     * Escribe el evento después del commit de la transacción de negocio (solo EXITO con transacción
     * activa) o de inmediato. Siempre en una transacción nueva y sin propagar errores.
     */
    private void dispatch(String tipo, String resultado, Runnable writer) {
        boolean deferToCommit = RESULTADO_EXITO.equals(resultado)
                && TransactionSynchronizationManager.isSynchronizationActive()
                && TransactionSynchronizationManager.isActualTransactionActive();
        if (deferToCommit) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    writeInNewTransaction(tipo, writer);
                }
            });
        } else {
            writeInNewTransaction(tipo, writer);
        }
    }

    private void writeInNewTransaction(String tipo, Runnable writer) {
        try {
            requiresNew.executeWithoutResult(status -> writer.run());
        } catch (RuntimeException exception) {
            log.error("No fue posible registrar el evento de auditoría {}; la operación de negocio no se ve afectada.",
                    tipo, exception);
        }
    }

    /** Busca el tipo en el catálogo; nunca lo crea (la categoría la define la migración). */
    private Optional<TipoEvento> findTipoEvento(String tipo) {
        Optional<TipoEvento> found = tipo == null ? Optional.empty() : tipoEventoRepository.findByCodigoIgnoreCase(tipo);
        if (found.isEmpty()) {
            log.error("Tipo de evento de auditoría '{}' no existe en el catálogo TIPO_EVENTO; el evento no se registró. "
                    + "Agregue el código con su categoría en una migración Flyway.", tipo);
        }
        return found;
    }

    private TipoEvento requireTipoEvento(String tipo) {
        return findTipoEvento(tipo).orElseThrow(() -> new IllegalStateException(
                "Tipo de evento de auditoría '" + tipo + "' no existe en el catálogo TIPO_EVENTO."));
    }

    private UserAccount resolveCurrentActor(String activeEmail) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
            return userAccountRepository.findByKeycloakUserId(jwt.getSubject())
                    .or(() -> activeEmail != null ? userAccountRepository.findByEmailIgnoreCase(activeEmail) : Optional.empty())
                    .orElse(null);
        }
        return null;
    }

    private UserAccount findUser(Jwt jwt, String email) {
        if (jwt != null && jwt.getSubject() != null) {
            var byKeycloak = userAccountRepository.findByKeycloakUserId(jwt.getSubject());
            if (byKeycloak.isPresent()) {
                return byKeycloak.get();
            }
        }
        if (email != null && !email.isBlank()) {
            return userAccountRepository.findByEmailIgnoreCase(email).orElse(null);
        }
        return null;
    }

    private String resolveCurrentRequestId() {
        String requestId = org.slf4j.MDC.get("requestId");
        if (requestId == null || requestId.isBlank()) {
            requestId = org.slf4j.MDC.get("request_id");
        }
        if (requestId == null || requestId.isBlank()) {
            RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
            if (attributes instanceof ServletRequestAttributes servletAttributes) {
                HttpServletRequest req = servletAttributes.getRequest();
                requestId = req.getHeader("X-Request-ID");
                if (requestId == null || requestId.isBlank()) {
                    requestId = req.getHeader("X-Correlation-ID");
                }
            }
        }
        return requestId;
    }

    private String resolveEmail(Jwt jwt) {
        if (jwt == null) {
            return "anonimo";
        }
        String email = jwt.getClaimAsString("email");
        if (email != null && !email.isBlank()) {
            return email.trim().toLowerCase(Locale.ROOT);
        }

        String username = jwt.getClaimAsString("preferred_username");
        if (username != null && !username.isBlank()) {
            return username.trim();
        }

        return jwt.getSubject();
    }

    public String resolveCurrentActiveEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return null;
        }
        if ("anonymousUser".equalsIgnoreCase(authentication.getName())) {
            return null;
        }
        if (authentication.getPrincipal() instanceof Jwt jwt) {
            return resolveEmail(jwt);
        }
        String name = authentication.getName();
        if (name != null && !name.isBlank() && !"anonymousUser".equalsIgnoreCase(name)) {
            return name.trim().toLowerCase(Locale.ROOT);
        }
        return null;
    }

    public String resolveCurrentClientIp() {
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if (attributes instanceof ServletRequestAttributes servletAttributes) {
            return resolveClientIp(servletAttributes.getRequest());
        }
        return "127.0.0.1";
    }

    private String resolveClientIp(HttpServletRequest request) {
        if (request == null) {
            return "127.0.0.1";
        }
        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
