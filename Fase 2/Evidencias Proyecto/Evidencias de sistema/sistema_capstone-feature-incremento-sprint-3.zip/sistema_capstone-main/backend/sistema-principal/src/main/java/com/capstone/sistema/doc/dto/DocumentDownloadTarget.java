package com.capstone.sistema.doc.dto;

import java.util.UUID;

/** Metadata interna autorizada; nunca se serializa hacia el cliente. */
public record DocumentDownloadTarget(
        UUID id,
        UUID solicitudId,
        String nombreArchivo,
        String contentType,
        String storageKey,
        Long sizeBytes,
        int version,
        String motivo
) {
    public DocumentDownloadTarget(
            UUID id,
            UUID solicitudId,
            String nombreArchivo,
            String contentType,
            String storageKey,
            Long sizeBytes,
            int version
    ) {
        this(id, solicitudId, nombreArchivo, contentType, storageKey, sizeBytes, version, null);
    }
}
