package com.capstone.sistema.flow.service;
import com.capstone.sistema.notificacion.controller.NotificacionController;
import com.capstone.sistema.notificacion.service.NotificacionService;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.ResponsableOptionsResponse;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * F5-B1: {@code options()} debe devolver el mismo conjunto de usuarios que antes de la optimización, aunque
 * ahora los administradores se aceptan sin recorrer las solicitudes abiertas.
 */
@ExtendWith(MockitoExtension.class)
class FlujoResponsableServiceTest {

    @Mock private FlujoDefinicionRepository definitions;
    @Mock private SolicitudRepository requests;
    @Mock private FlujoReviewerResolver reviewers;
    @Mock private FlujoIntegrityService integrity;
    @Mock private FlujoConcurrencyService concurrency;
    @Mock private FlujoConfigService config;
    @Mock private RbacAccessService access;
    @Mock private RbacManagementService security;
    @Mock private NotificacionService notifications;
    @Mock private AuditService audit;
    @Mock private JdbcTemplate jdbc;
    @Mock private EntityManager entityManager;

    private FlujoResponsableService service;
    private FlujoEtapa stage;

    @BeforeEach
    void setUp() {
        service = new FlujoResponsableService(definitions, requests, reviewers, integrity, concurrency,
                config, access, security, notifications, audit, jdbc, entityManager);
    }

    private static UserAccount user(String email, boolean enabled) {
        UserAccount user = new UserAccount("kc-" + email, email, "Nombre", "Apellido", enabled);
        user.setId(UUID.randomUUID());
        return user;
    }

    @Test
    void optionsReturnsAdminWithoutScannedRequestsAndKeepsTheSameEligibleUsers() {
        UserAccount adminUser = user("admin-op@capstone.local", true);
        UserAccount plainUser = user("revisor-op@capstone.local", true);
        UserAccount withoutAccess = user("sin-area-op@capstone.local", true);
        UserAccount inactive = user("inactivo-op@capstone.local", false);

        flowFixture();
        Solicitud request = mock(Solicitud.class);
        when(request.getFlujoEtapa()).thenReturn(stage);
        when(requests.findOpenByFlow(2L)).thenReturn(List.of(request));

        when(reviewers.eligibleUsers()).thenReturn(List.of(withoutAccess, plainUser, adminUser, inactive));
        when(access.administradorSistemaIds(any())).thenReturn(Set.of(adminUser.getId()));
        when(access.canOperateAtStage(eq(plainUser), eq(request), any(FlujoEtapa.class))).thenReturn(true);
        when(access.canOperateAtStage(eq(withoutAccess), eq(request), any(FlujoEtapa.class))).thenReturn(false);

        ResponsableOptionsResponse response = service.options(2L, 7L);

        assertThat(response.usuarios()).extracting(ResponsableOptionsResponse.Usuario::id)
                .containsExactlyInAnyOrder(adminUser.getId(), plainUser.getId());
        // El administrador no recorre las solicitudes abiertas.
        verify(access, never()).canOperateAtStage(eq(adminUser), any(Solicitud.class), any(FlujoEtapa.class));
    }

    @Test
    void optionsExcludesUsersThatCannotOperateAtTheStage() {
        UserAccount plainUser = user("revisor-nada@capstone.local", true);

        flowFixture();
        Solicitud request = mock(Solicitud.class);
        when(request.getFlujoEtapa()).thenReturn(stage);
        when(requests.findOpenByFlow(2L)).thenReturn(List.of(request));

        when(reviewers.eligibleUsers()).thenReturn(List.of(plainUser));
        when(access.administradorSistemaIds(any())).thenReturn(Set.of());
        when(access.canOperateAtStage(eq(plainUser), eq(request), any(FlujoEtapa.class))).thenReturn(false);

        ResponsableOptionsResponse response = service.options(2L, 7L);

        assertThat(response.usuarios()).isEmpty();
    }

    private void flowFixture() {
        stage = mock(FlujoEtapa.class);
        when(stage.getId()).thenReturn(7L);
        when(stage.getOrden()).thenReturn(1);
        FlujoDefinicion flow = mock(FlujoDefinicion.class);
        when(flow.getId()).thenReturn(2L);
        when(flow.getVersion()).thenReturn(1L);
        when(flow.getEtapas()).thenReturn(List.of(stage));
        when(flow.getArea()).thenReturn(null);
        when(definitions.findById(2L)).thenReturn(Optional.of(flow));
    }
}
