package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Una sola resolución para configuración, ejecución, notificaciones y protección RBAC.
 * <ul>
 *   <li>Modo LISTA (D-05): la etapa tiene una lista de usuarios; cualquiera de los activos puede decidir.</li>
 *   <li>Modo JEFATURA_AREA_SOLICITUD (D-07, flujo base): revisa la jefatura activa del área de la solicitud
 *       o del ancestro más cercano con jefatura (S-03), igual que V_REVISOR_SOLICITUD.</li>
 * </ul>
 */
@Service
@Transactional(readOnly = true)
public class FlujoReviewerResolver {
    /** Jefaturas activas del área indicada o, si no tiene, del ancestro más cercano que sí tenga (S-03). */
    private static final String SQL_JEFATURA_AREA = """
            WITH RECURSIVE rama AS (
                SELECT a.id, a.area_padre_id, 0 AS distancia FROM area a WHERE a.id = ?
                UNION ALL
                SELECT p.id, p.area_padre_id, r.distancia + 1 FROM area p JOIN rama r ON p.id = r.area_padre_id
            ), jefes AS (
                SELECT j.usuario_id, r.distancia
                  FROM rama r
                  JOIN area_jefatura j ON j.area_id = r.id
                  JOIN usuario u ON u.id = j.usuario_id AND u.activo
            )
            SELECT usuario_id FROM jefes WHERE distancia = (SELECT MIN(distancia) FROM jefes)
            """;

    private final RbacAccessService access;
    private final UserAccountRepository users;
    private final JdbcTemplate jdbc;

    public FlujoReviewerResolver(RbacAccessService access, UserAccountRepository users, JdbcTemplate jdbc) {
        this.access=access; this.users=users; this.jdbc=jdbc;
    }

    /** Usuarios activos que pueden figurar como revisores (assignee-options). */
    public List<UserAccount> eligibleUsers() {
        return users.findAllByOrderByEmailAsc().stream().filter(access::eligibleReviewer).toList();
    }

    /**
     * Candidatos a nivel de configuración (sin solicitud concreta).
     * LISTA: revisores configurados y activos, en orden determinista.
     * JEFATURA: la resolución depende del área de cada solicitud; el flujo base se considera siempre disponible
     * y una etapa JEFATURA no base exige que exista al menos una jefatura activa.
     */
    public List<UserAccount> candidates(FlujoEtapa stage) {
        if (isDynamicBase(stage)) return users.findAllByOrderByEmailAsc().stream().filter(UserAccount::isEnabled).toList();
        if (isJefatura(stage)) {
            List<UUID> ids=jdbc.queryForList("select distinct j.usuario_id from area_jefatura j join usuario u on u.id=j.usuario_id and u.activo",UUID.class);
            return ids.isEmpty() ? List.of() : users.findAllById(ids).stream().filter(UserAccount::isEnabled)
                    .sorted(FlujoEtapa.ORDEN_REVISOR).toList();
        }
        return stage.getRevisoresOrdenados().stream().filter(access::eligibleReviewer).toList();
    }

    /** Revisores efectivos de la etapa para una solicitud concreta. */
    public List<UserAccount> forRequest(Solicitud request, FlujoEtapa stage) {
        if (isJefatura(stage)) return jefaturaFor(request);
        List<UserAccount> candidates=candidates(stage);
        if (candidates.isEmpty()) return List.of();
        // Los revisores de la etapa se precargan una vez: canOperateAtStage ya no consulta por candidato.
        Set<UUID> reviewerIds=access.stageReviewerIds(stage);
        return candidates.stream().filter(user->access.canOperateAtStage(user,request,stage,reviewerIds)).toList();
    }

    /** Etapa sin revisor resoluble a nivel de configuración → 422 FLUJO_ETAPA_HUERFANA. */
    public void requireAvailable(FlujoEtapa stage) {
        if (candidates(stage).isEmpty()) throw orphan("La etapa '"+stage.getNombre()+"' no tiene revisores activos disponibles.");
    }

    /** Etapa sin revisor resoluble para la solicitud → 422 FLUJO_ETAPA_HUERFANA. */
    public void requireForRequest(Solicitud request, FlujoEtapa stage) {
        if (forRequest(request,stage).isEmpty()) {
            String detail=isJefatura(stage)
                    ? "La etapa '"+stage.getNombre()+"' no tiene una jefatura activa en el área de la solicitud ni en sus áreas superiores."
                    : "La etapa '"+stage.getNombre()+"' no tiene revisores activos autorizados para la solicitud "+request.getCorrelativo()+".";
            throw orphan(detail);
        }
    }

    /**
     * Normaliza la lista pedida: {@code revisorIds} tiene prioridad; si viene vacía o nula y hay {@code revisorId},
     * se usa como lista de un elemento. Conserva el orden de llegada y rechaza duplicados (400).
     */
    public static List<UUID> requestedReviewers(List<UUID> revisorIds, UUID revisorId) {
        List<UUID> source=revisorIds!=null && !revisorIds.isEmpty() ? revisorIds : (revisorId!=null ? List.of(revisorId) : List.of());
        Set<UUID> unique=new LinkedHashSet<>();
        for (UUID id:source) {
            if (id==null) throw RbacException.invalid("La lista de revisores no admite valores vacíos.");
            if (!unique.add(id)) throw RbacException.invalid("La lista de revisores contiene usuarios duplicados.");
        }
        if (revisorId!=null && revisorIds!=null && !revisorIds.isEmpty() && !unique.contains(revisorId)) {
            throw RbacException.invalid("revisorId debe pertenecer a revisorIds cuando se envían ambos.");
        }
        return List.copyOf(unique);
    }

    /**
     * Asigna la lista completa de revisores de una etapa LISTA (reemplazo atómico en FLUJO_ETAPA_REVISOR).
     * <ul>
     *   <li>Lista vacía → 422 FLUJO_ETAPA_HUERFANA.</li>
     *   <li>Duplicados o usuario inexistente → 400 RBAC_DATOS_INVALIDOS.</li>
     *   <li>Usuario inactivo → 422 USUARIO_INACTIVO.</li>
     * </ul>
     */
    public void assign(FlujoEtapa stage, TipoAsignacionRevisor type, List<UUID> reviewerIds) {
        if (isJefatura(stage)) {
            throw RbacException.conflict("FLUJO_BASE_PROTEGIDO","Una etapa con revisión por jefatura no admite una lista de revisores.");
        }
        List<UUID> ids=reviewerIds==null?List.of():reviewerIds;
        if (ids.isEmpty()) throw orphan("Seleccione al menos un usuario revisor para la etapa '"+stage.getNombre()+"'.");
        if (new LinkedHashSet<>(ids).size()!=ids.size()) throw RbacException.invalid("La lista de revisores contiene usuarios duplicados.");
        List<UserAccount> selected=new ArrayList<>();
        for (UUID id:ids) {
            UserAccount user=users.findById(id).orElseThrow(()->RbacException.invalid("El usuario indicado no existe: "+id));
            if (!access.eligibleReviewer(user)) throw inactiveUser("El usuario "+user.getEmail()+" está inactivo y no puede ser revisor.");
            selected.add(user);
        }
        stage.setTipoAsignacion(TipoAsignacionRevisor.USUARIO);
        stage.setModoRevisor(ModoRevisor.LISTA);
        stage.reemplazarRevisores(selected);
        requireAvailable(stage);
    }

    public static boolean isJefatura(FlujoEtapa stage) {
        return stage.getModoRevisor()==ModoRevisor.JEFATURA_AREA_SOLICITUD;
    }

    public static boolean isDynamicBase(FlujoEtapa stage) {
        FlujoDefinicion flow=stage.getFlujoDefinicion();
        return Long.valueOf(1).equals(flow.getId()) && FlujoIntegrityService.BASE_NAME.equals(flow.getNombre())
                && flow.getArea()==null && flow.getEtapas().size()==1 && stage.getOrden()==1
                && stage.getTipoAccion()==TipoAccionEtapa.REVISION && stage.getTipoAsignacion()==TipoAsignacionRevisor.USUARIO
                && stage.getRevisor()==null;
    }

    public static RbacException orphan(String detail) {
        return new RbacException(HttpStatus.UNPROCESSABLE_ENTITY,"FLUJO_ETAPA_HUERFANA",detail);
    }

    public static RbacException inactiveUser(String detail) {
        return new RbacException(HttpStatus.UNPROCESSABLE_ENTITY,"USUARIO_INACTIVO",detail);
    }

    private List<UserAccount> jefaturaFor(Solicitud request) {
        Long areaId=request.getAreaOrigenId();
        if (areaId==null) return List.of();
        List<UUID> ids=jdbc.queryForList(SQL_JEFATURA_AREA,UUID.class,areaId);
        if (ids.isEmpty()) return List.of();
        return users.findAllById(ids).stream().filter(Objects::nonNull).filter(UserAccount::isEnabled)
                .sorted(FlujoEtapa.ORDEN_REVISOR).toList();
    }
}
