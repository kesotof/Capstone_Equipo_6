package com.capstone.sistema.ia.repository;

import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * A-09 / F6: acceso a ia_tarea, consultas de evaluación, chat, republicación y concurrencia.
 */
@Repository
public interface IaTareaRepository extends JpaRepository<IaTarea, UUID> {

    @Query(value = "SELECT pg_try_advisory_xact_lock(41030, 4)", nativeQuery = true)
    Boolean tryAdvisoryLockRepublicacion();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT t FROM IaTarea t WHERE t.id = :id")
    Optional<IaTarea> findByIdForUpdate(@Param("id") UUID id);

    Optional<IaTarea> findBySolicitudIdAndId(UUID solicitudId, UUID id);

    @Query(value = """
            SELECT * FROM ia_tarea
             WHERE estado = 'PENDIENTE'
               AND publicado_en < :umbral
             ORDER BY publicado_en ASC
             LIMIT :limite
             FOR UPDATE SKIP LOCKED
            """, nativeQuery = true)
    List<IaTarea> pendientesDeRepublicacion(@Param("umbral") Instant umbral, @Param("limite") int limite);

    @Query("SELECT t FROM IaTarea t WHERE t.solicitud.id = :solicitudId AND t.tipo = com.capstone.sistema.model.enums.TipoTareaIa.EVALUACION ORDER BY t.createdAt DESC")
    List<IaTarea> findEvaluaciones(@Param("solicitudId") UUID solicitudId);

    @Query("SELECT t FROM IaTarea t WHERE t.solicitud.id = :solicitudId AND t.tipo = com.capstone.sistema.model.enums.TipoTareaIa.CHAT ORDER BY t.createdAt ASC")
    List<IaTarea> findChatThread(@Param("solicitudId") UUID solicitudId);

    @Query("SELECT t FROM IaTarea t WHERE t.solicitud.id = :solicitudId AND t.tipo = com.capstone.sistema.model.enums.TipoTareaIa.CHAT AND t.estado = com.capstone.sistema.model.enums.EstadoTareaIa.COMPLETADA ORDER BY t.createdAt DESC")
    List<IaTarea> findUltimosChatCompletados(@Param("solicitudId") UUID solicitudId, Pageable pageable);

    @Query("SELECT count(t) FROM IaTarea t WHERE t.solicitud.id = :solicitudId AND t.tipo = com.capstone.sistema.model.enums.TipoTareaIa.CHAT AND t.createdAt >= :inicioDia")
    long countPreguntasChatDesde(@Param("solicitudId") UUID solicitudId, @Param("inicioDia") Instant inicioDia);

    boolean existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
            UUID solicitudId,
            TipoTareaIa tipo,
            UUID solicitadoPorId,
            EstadoTareaIa estado
    );
}
