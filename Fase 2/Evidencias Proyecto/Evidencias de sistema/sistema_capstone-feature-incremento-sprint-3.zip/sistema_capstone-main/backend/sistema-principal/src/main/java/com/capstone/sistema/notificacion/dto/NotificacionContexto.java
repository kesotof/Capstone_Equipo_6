package com.capstone.sistema.notificacion.dto;

import java.time.Instant;
import java.util.UUID;

/**
 * F3 (§6.1): contexto que alimenta {@code NotificacionMensajeFactory}. Lo construye
 * {@code NotificacionTransicionListener} a partir del {@code TransicionSolicitudEvent} y la
 * solicitud ya actualizada (etapas, plazo y actor).
 *
 * <p>Además de los campos listados en el plan, lleva {@code solicitudId} (los enlaces son
 * {@code /solicitudes/{id}…}) y {@code accion} (para elegir la variante de texto y el verbo
 * de {@code DECISION_ADMIN_GLOBAL}); se documenta como extensión mínima del contexto.</p>
 *
 * @param accion REGISTRAR | APROBAR | RECHAZAR | SOLICITAR_CORRECCION | CORREGIR
 */
public record NotificacionContexto(
        UUID solicitudId,
        Long historialId,
        String correlativo,
        String tituloSolicitud,
        String tipoDocumento,
        String etapaOrigen,
        String etapaDestino,
        String nombreActor,
        String nombreEmisor,
        UUID actorId,
        Instant deadline,
        String observacion,
        String accion
) {
}
