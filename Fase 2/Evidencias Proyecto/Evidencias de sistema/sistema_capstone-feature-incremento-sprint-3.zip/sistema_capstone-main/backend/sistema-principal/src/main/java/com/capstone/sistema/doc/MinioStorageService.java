package com.capstone.sistema.doc;

import com.capstone.sistema.flow.exception.AlmacenamientoNoDisponibleException;

import io.minio.*;
import io.minio.messages.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
public class MinioStorageService {

    private static final Logger log = LoggerFactory.getLogger(MinioStorageService.class);

    private final MinioClient minioClient;
    private final String bucketName;

    public record MinioUploadResult(
            String storageKey,
            String storageVersionId,
            String checksumSha256,
            long sizeBytes,
            String contentType
    ) {}

    public MinioStorageService(
            @Value("${minio.endpoint}") String endpoint,
            @Value("${minio.access-key}") String accessKey,
            @Value("${minio.secret-key}") String secretKey,
            @Value("${minio.bucket}") String bucketName) {
        this.minioClient = MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
        this.bucketName = bucketName;
    }

    public static String buildStorageKey(UUID solicitudId, int version, String originalFilename) {
        String cleanName = cleanFilename(originalFilename);
        return "solicitudes/" + solicitudId + "/v" + version + "/" + cleanName;
    }

    public static String cleanFilename(String filename) {
        if (filename == null || filename.isBlank()) {
            return "documento.bin";
        }
        String name = filename.substring(Math.max(filename.lastIndexOf('/'), filename.lastIndexOf('\\')) + 1);
        name = name.replaceAll("[\\p{Cntrl}\\p{Cf}\\\\/:*?\"<>|\\s]", "_").strip();
        name = name.replaceAll("[. _]+$", "");
        return name.isBlank() ? "documento.bin" : name;
    }

    public static String buildTemplateStorageKey(Long plantillaId, int version, String originalFilename) {
        String cleanName = cleanFilename(originalFilename);
        return "plantillas/" + plantillaId + "/v" + version + "/" + cleanName;
    }

    public MinioUploadResult uploadTemplate(Long plantillaId, int version, String originalFilename, byte[] bytes) throws Exception {
        ensureBucketExists();
        String storageKey = buildTemplateStorageKey(plantillaId, version, originalFilename);
        String contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(bytes);
        String checksumSha256 = HexFormat.of().formatHex(hash);

        ObjectWriteResponse response = minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(storageKey)
                        .stream(new ByteArrayInputStream(bytes), bytes.length, -1)
                        .contentType(contentType)
                        .build()
        );

        String versionId = response.versionId();
        log.info("Plantilla almacenada en MinIO: key={}, size={}, sha256={}, versionId={}",
                storageKey, bytes.length, checksumSha256, versionId);

        return new MinioUploadResult(storageKey, versionId, checksumSha256, bytes.length, contentType);
    }

    public MinioUploadResult uploadDocument(UUID solicitudId, int version, MultipartFile file) throws Exception {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("El archivo es obligatorio.");
        }
        byte[] bytes = file.getBytes();
        String contentType = file.getContentType() != null ? file.getContentType() : "application/octet-stream";
        return uploadDocument(solicitudId, version, file.getOriginalFilename(), contentType, new ByteArrayInputStream(bytes), bytes.length);
    }

    public MinioUploadResult uploadDocument(
            UUID solicitudId,
            int version,
            String originalFilename,
            String contentType,
            InputStream inputStream,
            long sizeBytes
    ) throws Exception {
        ensureBucketExists();
        return guardar(buildStorageKey(solicitudId, version, originalFilename), contentType, inputStream.readAllBytes());
    }

    /** Anexo de una solicitud: usa una carpeta propia para no pisar el documento vigente ni sus versiones. */
    public MinioUploadResult uploadAnexo(UUID solicitudId, int indice, String originalFilename, String contentType, byte[] bytes) throws Exception {
        ensureBucketExists();
        return guardar("solicitudes/" + solicitudId + "/anexos/" + indice + "-" + cleanFilename(originalFilename), contentType, bytes);
    }

    /** Documento de origen del autocompletado con IA: carpeta temporal, se elimina al recibir el resultado. */
    public MinioUploadResult uploadAutocompletado(String originalFilename, String contentType, byte[] bytes) throws Exception {
        ensureBucketExists();
        return guardar("temporal/autocompletado/" + UUID.randomUUID() + "/" + cleanFilename(originalFilename), contentType, bytes);
    }

    /** Documento Word de un borrador del editor de plantillas: se sobrescribe en cada guardado. */
    public MinioUploadResult uploadBorrador(UUID borradorId, byte[] bytes) throws Exception {
        ensureBucketExists();
        return guardar("borradores/" + borradorId + "/documento.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document", bytes);
    }

    /** Elimina el objeto si la transacción actual se revierte, para no dejar archivos sin registro en la base. */
    public void deleteOnRollback(String storageKey) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            return;
        }
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status != STATUS_ROLLED_BACK) {
                    return;
                }
                try {
                    deleteFile(storageKey);
                } catch (Exception ex) {
                    log.warn("No se pudo eliminar {} de MinIO tras el rollback: {}", storageKey, ex.getMessage());
                }
            }
        });
    }

    private MinioUploadResult guardar(String storageKey, String contentType, byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        String checksumSha256 = HexFormat.of().formatHex(hash);

        ObjectWriteResponse response = minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(storageKey)
                        .stream(new ByteArrayInputStream(data), data.length, -1)
                        .contentType(contentType)
                        .build()
        );

        String versionId = response.versionId();
        log.info("Archivo almacenado en MinIO: key={}, size={}, sha256={}, versionId={}",
                storageKey, data.length, checksumSha256, versionId);

        return new MinioUploadResult(storageKey, versionId, checksumSha256, data.length, contentType);
    }

    public void removeObject(String bucket, String objectKey) throws Exception {
        if (objectKey == null || objectKey.isBlank()) {
            return;
        }
        minioClient.removeObject(
                RemoveObjectArgs.builder()
                        .bucket(bucket)
                        .object(objectKey)
                        .build()
        );
    }

    public MinioUploadResult uploadToBucket(String bucket, String storageKey, String originalFilename, String contentType, byte[] data) throws Exception {
        boolean bucketExiste;
        try {
            bucketExiste = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucket).build());
        } catch (Exception e) {
            throw new AlmacenamientoNoDisponibleException("No se pudo verificar el bucket '" + bucket + "' en MinIO", e);
        }
        if (!bucketExiste) {
            throw new AlmacenamientoNoDisponibleException("El bucket '" + bucket + "' no existe en MinIO. Ejecute minio-init.", null);
        }

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        String checksumSha256 = HexFormat.of().formatHex(hash);

        ObjectWriteResponse response = minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(bucket)
                        .object(storageKey)
                        .stream(new ByteArrayInputStream(data), data.length, -1)
                        .contentType(contentType != null ? contentType : "application/octet-stream")
                        .build()
        );

        String versionId = response.versionId();
        log.info("Archivo almacenado en MinIO (bucket={}): key={}, size={}, sha256={}",
                bucket, storageKey, data.length, checksumSha256);
        return new MinioUploadResult(storageKey, versionId, checksumSha256, data.length, contentType);
    }

    public String uploadFile(MultipartFile file) throws Exception {
        ensureBucketExists();
        String filename = System.currentTimeMillis() + "_" + cleanFilename(file.getOriginalFilename());
        minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(filename)
                        .stream(file.getInputStream(), file.getSize(), -1)
                        .contentType(file.getContentType())
                        .build()
        );
        return filename;
    }

    public InputStream downloadFile(String filename) throws Exception {
        return openDownload(filename);
    }

    public GetObjectResponse openDownload(String filename) throws Exception {
        return minioClient.getObject(
                GetObjectArgs.builder()
                        .bucket(bucketName)
                        .object(filename)
                        .build()
        );
    }

    public void deleteFile(String filename) throws Exception {
        if (filename == null || filename.isBlank()) {
            return;
        }

        minioClient.removeObject(
                RemoveObjectArgs.builder()
                        .bucket(bucketName)
                        .object(filename)
                        .build()
        );
    }

    public List<String> listOrphanKeys(Set<String> knownDbKeys) {
        List<String> orphans = new ArrayList<>();
        try {
            Iterable<Result<Item>> results = minioClient.listObjects(
                    ListObjectsArgs.builder().bucket(bucketName).recursive(true).build()
            );
            for (Result<Item> result : results) {
                Item item = result.get();
                String objectName = item.objectName();
                if (knownDbKeys != null && !knownDbKeys.contains(objectName)) {
                    orphans.add(objectName);
                }
            }
        } catch (Exception ex) {
            log.warn("Error al listar objetos huérfanos en MinIO: {}", ex.getMessage());
        }
        return orphans;
    }

    private void ensureBucketExists() throws Exception {
        boolean exists = minioClient.bucketExists(
                BucketExistsArgs.builder().bucket(bucketName).build()
        );
        if (!exists) {
            minioClient.makeBucket(
                    MakeBucketArgs.builder().bucket(bucketName).build()
            );
        }
    }
}
