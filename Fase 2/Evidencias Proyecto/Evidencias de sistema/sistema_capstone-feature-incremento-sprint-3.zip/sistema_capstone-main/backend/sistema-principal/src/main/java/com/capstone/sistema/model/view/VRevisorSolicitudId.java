package com.capstone.sistema.model.view;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class VRevisorSolicitudId implements Serializable {

    private UUID solicitudId;
    private Long flujoEtapaId;
    private UUID usuarioId;

    public VRevisorSolicitudId() {
    }

    public VRevisorSolicitudId(UUID solicitudId, Long flujoEtapaId, UUID usuarioId) {
        this.solicitudId = solicitudId;
        this.flujoEtapaId = flujoEtapaId;
        this.usuarioId = usuarioId;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public Long getFlujoEtapaId() {
        return flujoEtapaId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VRevisorSolicitudId that = (VRevisorSolicitudId) o;
        return Objects.equals(solicitudId, that.solicitudId) &&
                Objects.equals(flujoEtapaId, that.flujoEtapaId) &&
                Objects.equals(usuarioId, that.usuarioId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(solicitudId, flujoEtapaId, usuarioId);
    }
}
