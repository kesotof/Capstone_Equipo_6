package com.capstone.sistema.ia.dto;

/**
 * F6 (§7.2): catálogo de mensajes amigables al usuario para errores de IA.
 */
public final class IaErrorMensajes {

    private IaErrorMensajes() {}

    public static String mensajeAmigable(String codigo) {
        if (codigo == null) {
            return "Ocurrió un error inesperado al consultar el asistente de IA.";
        }
        return switch (codigo) {
            case "IA_NO_DISPONIBLE", "SIN_RESPUESTA" ->
                    "El asistente de IA no está disponible. Puedes revisar normalmente.";
            case "DOCUMENTO_ILEGIBLE" ->
                    "No se pudo leer el texto del documento.";
            case "DOCUMENTO_NO_ENCONTRADO" ->
                    "No se encontró el archivo del documento en el almacenamiento.";
            case "RESPUESTA_INVALIDA", "RESULTADO_RECHAZADO" ->
                    "La IA entregó una respuesta que no se pudo interpretar. Intenta de nuevo.";
            case "ERROR_INTERNO" ->
                    "Ocurrió un error interno al procesar la solicitud de IA.";
            default ->
                    "El asistente de IA no pudo completar la tarea (" + codigo + "). Puedes continuar normalmente.";
        };
    }
}
