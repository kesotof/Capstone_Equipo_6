package com.capstone.sistema.doc.model;

import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Tarea de autocompletado con IA del formulario de una versión de plantilla, solicitada por un emisor. */
@Entity
@Table(name = "ia_autocompletado")
public class IaAutocompletado {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "plantilla_version_id", nullable = false, updatable = false)
    private PlantillaVersion plantillaVersion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false, updatable = false)
    private UserAccount usuario;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private EstadoAnalisis estado = EstadoAnalisis.PENDIENTE;

    @Column(name = "nombre_archivo", length = 255, updatable = false)
    private String nombreArchivo;

    @Column(name = "storage_key", length = 500, updatable = false)
    private String storageKey;

    @Column(columnDefinition = "TEXT", updatable = false)
    private String indicaciones;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private String sugerencias;

    @Column(columnDefinition = "TEXT")
    private String mensaje;

    @Column(name = "modelo_usado", length = 100)
    private String modeloUsado;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    protected IaAutocompletado() {
    }

    public IaAutocompletado(PlantillaVersion plantillaVersion, UserAccount usuario, String nombreArchivo,
                            String storageKey, String indicaciones) {
        this.plantillaVersion = plantillaVersion;
        this.usuario = usuario;
        this.nombreArchivo = nombreArchivo;
        this.storageKey = storageKey;
        this.indicaciones = indicaciones;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public void completar(EstadoAnalisis estado, String sugerencias, String mensaje, String modeloUsado) {
        this.estado = estado;
        this.sugerencias = sugerencias;
        this.mensaje = mensaje;
        this.modeloUsado = modeloUsado;
        this.completedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public PlantillaVersion getPlantillaVersion() {
        return plantillaVersion;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public EstadoAnalisis getEstado() {
        return estado;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public String getIndicaciones() {
        return indicaciones;
    }

    public String getSugerencias() {
        return sugerencias;
    }

    public String getMensaje() {
        return mensaje;
    }

    public String getModeloUsado() {
        return modeloUsado;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        return id != null && Objects.equals(id, ((IaAutocompletado) o).id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
