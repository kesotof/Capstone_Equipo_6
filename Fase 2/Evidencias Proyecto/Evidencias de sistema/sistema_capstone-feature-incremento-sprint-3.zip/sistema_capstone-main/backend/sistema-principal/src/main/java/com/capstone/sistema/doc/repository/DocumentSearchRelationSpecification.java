package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria.MiDecision;
import com.capstone.sistema.doc.dto.DocumentSearchCriteria.Relacion;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.model.view.VAccesoSolicitud;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Filtro de relación del usuario autenticado con la solicitud. Solo restringe: siempre se compone con
 * {@code RbacAccessService.visible(...)}, de modo que nunca amplía lo que el usuario puede ver.
 */
public class DocumentSearchRelationSpecification implements Specification<Solicitud> {
    /** Motivos de V_ACCESO_SOLICITUD que provienen de jefatura o de un rol con SOLICITUD.VER (incluye subáreas). */
    static final List<String> MOTIVOS_MIS_AREAS = List.of("JEFATURA", "ROL", "ROL_GLOBAL");

    private final Relacion relacion;
    private final MiDecision miDecision;
    private final UUID usuarioId;

    public DocumentSearchRelationSpecification(Relacion relacion, MiDecision miDecision, UUID usuarioId) {
        this.relacion = relacion == null ? Relacion.TODAS : relacion;
        this.miDecision = miDecision;
        this.usuarioId = Objects.requireNonNull(usuarioId, "usuarioId");
    }

    @Override
    public Predicate toPredicate(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        return switch (relacion) {
            case TODAS -> builder.conjunction();
            case CREADAS -> builder.equal(root.get("usuario").get("id"), usuarioId);
            case REVISADAS -> reviewed(root, query, builder);
            case MIS_AREAS -> myAreas(root, query, builder);
        };
    }

    private Predicate reviewed(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        var decided = query.subquery(Long.class);
        Root<HistorialTransicion> history = decided.from(HistorialTransicion.class);
        List<Predicate> filters = new ArrayList<>();
        filters.add(builder.equal(history.get("solicitud").get("id"), root.get("id")));
        filters.add(builder.equal(history.get("usuario").get("id"), usuarioId));
        if (miDecision == null) {
            filters.add(history.get("accion").get("codigo").in(MiDecision.ACCIONES));
        } else {
            // La fila debe ser la ÚLTIMA decisión del usuario en la solicitud (created_at y, ante empate, id).
            filters.add(builder.equal(history.get("accion").get("codigo"), miDecision.accion()));
            var later = query.subquery(Long.class);
            Root<HistorialTransicion> next = later.from(HistorialTransicion.class);
            later.select(next.<Long>get("id")).where(
                    builder.equal(next.get("solicitud").get("id"), root.get("id")),
                    builder.equal(next.get("usuario").get("id"), usuarioId),
                    next.get("accion").get("codigo").in(MiDecision.ACCIONES),
                    builder.or(
                            builder.greaterThan(next.<Instant>get("createdAt"), history.<Instant>get("createdAt")),
                            builder.and(
                                    builder.equal(next.<Instant>get("createdAt"), history.<Instant>get("createdAt")),
                                    builder.greaterThan(next.<Long>get("id"), history.<Long>get("id")))));
            filters.add(builder.not(builder.exists(later)));
        }
        decided.select(history.<Long>get("id")).where(filters.toArray(Predicate[]::new));
        return builder.exists(decided);
    }

    private Predicate myAreas(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        var access = query.subquery(UUID.class);
        Root<VAccesoSolicitud> row = access.from(VAccesoSolicitud.class);
        access.select(row.<UUID>get("solicitudId")).where(
                builder.equal(row.get("solicitudId"), root.get("id")),
                builder.equal(row.get("usuarioId"), usuarioId),
                row.get("motivo").in(MOTIVOS_MIS_AREAS));
        return builder.exists(access);
    }
}
