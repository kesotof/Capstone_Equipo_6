package com.capstone.sistema.audit.controller;

import com.capstone.sistema.audit.dto.AuditEventResponse;
import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Auditoría", description = "Registro y consulta de eventos de auditoría y sesiones")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/audit")
@PreAuthorize("isAuthenticated()")
public class AuditController {

    private final AuditService auditService;
    private final RbacAccessService access;

    public AuditController(AuditService auditService, RbacAccessService access) {
        this.auditService = auditService;
        this.access = access;
    }

    @PostMapping("/login")
    public ResponseEntity<AuditEventResponse> registerLogin(
            @AuthenticationPrincipal Jwt jwt,
            HttpServletRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auditService.registerLogin(jwt, request));
    }

    @PostMapping("/logout")
    public ResponseEntity<AuditEventResponse> registerLogout(
            @AuthenticationPrincipal Jwt jwt,
            HttpServletRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auditService.registerLogout(jwt, request));
    }

    /** Requiere AUDITORIA.VER (Permiso.AUDITORIA_CONSULTAR): administrador del sistema o rol AUDITOR. */
    @org.springframework.web.bind.annotation.GetMapping("/events")
    public ResponseEntity<java.util.List<AuditEventResponse>> listRecentEvents(
            @org.springframework.web.bind.annotation.RequestParam(value = "limit", defaultValue = "50") int limit
    ) {
        access.require(Permiso.AUDITORIA_CONSULTAR);
        return ResponseEntity.ok(auditService.listRecentEvents(limit));
    }
}
