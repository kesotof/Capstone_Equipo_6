-- Documentos adjuntos (anexos) de una solicitud. Se guardan aparte de 'documento', que mantiene un único
-- documento vigente por solicitud con su cadena de versiones.
CREATE TABLE solicitud_anexo (
    id              UUID         DEFAULT gen_random_uuid() PRIMARY KEY,
    solicitud_id    UUID         NOT NULL REFERENCES solicitud(id),
    nombre_archivo  VARCHAR(255) NOT NULL,
    content_type    VARCHAR(100) NOT NULL CHECK (content_type IN (
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/xml', 'text/xml',
        'text/plain')),
    storage_key     VARCHAR(500) NOT NULL UNIQUE,
    size_bytes      BIGINT       NOT NULL CHECK (size_bytes >= 0),
    checksum_sha256 VARCHAR(64)  NOT NULL CHECK (char_length(checksum_sha256) = 64),
    subido_por      UUID         NOT NULL REFERENCES usuario(id),
    created_at      TIMESTAMPTZ  DEFAULT now() NOT NULL
);
CREATE INDEX idx_anexo_solicitud ON solicitud_anexo (solicitud_id);
CREATE INDEX idx_anexo_subido_por ON solicitud_anexo (subido_por);
