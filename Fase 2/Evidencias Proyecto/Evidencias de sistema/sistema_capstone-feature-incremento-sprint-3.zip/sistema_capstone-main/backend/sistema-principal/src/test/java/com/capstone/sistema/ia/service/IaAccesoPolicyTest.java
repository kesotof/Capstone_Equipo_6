package com.capstone.sistema.ia.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IaAccesoPolicyTest {

    @Mock
    private JdbcTemplate jdbc;

    @InjectMocks
    private IaAccesoPolicy policy;

    private final UUID usuarioId = UUID.randomUUID();
    private final UUID solicitudId = UUID.randomUUID();

    @Test
    @DisplayName("puedeVer devuelve true si el query retorna true (revisor, participante o admin global)")
    void puedeVer_true() {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq(solicitudId), eq(usuarioId), eq(usuarioId)))
                .thenReturn(Boolean.TRUE);

        assertThat(policy.puedeVer(usuarioId, solicitudId)).isTrue();
    }

    @Test
    @DisplayName("puedeVer devuelve false si no cumple motivo ni admin global")
    void puedeVer_false() {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq(solicitudId), eq(usuarioId), eq(usuarioId)))
                .thenReturn(Boolean.FALSE);

        assertThat(policy.puedeVer(usuarioId, solicitudId)).isFalse();
    }

    @Test
    @DisplayName("puedePreguntar devuelve true si es revisor actual/admin y solicitud en PENDIENTE_REVISION")
    void puedePreguntar_true() {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq(solicitudId), eq(usuarioId), eq(usuarioId)))
                .thenReturn(Boolean.TRUE);

        assertThat(policy.puedePreguntar(usuarioId, solicitudId)).isTrue();
    }

    @Test
    @DisplayName("puedePreguntar devuelve false si solicitud no está en revisión o no es revisor")
    void puedePreguntar_false() {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq(solicitudId), eq(usuarioId), eq(usuarioId)))
                .thenReturn(Boolean.FALSE);

        assertThat(policy.puedePreguntar(usuarioId, solicitudId)).isFalse();
    }

    @Test
    @DisplayName("Parámetros nulos devuelven false inmediatamente sin llamar a BD")
    void parametrosNulos() {
        assertThat(policy.puedeVer(null, solicitudId)).isFalse();
        assertThat(policy.puedeVer(usuarioId, null)).isFalse();
        assertThat(policy.puedePreguntar(null, solicitudId)).isFalse();
        assertThat(policy.puedePreguntar(usuarioId, null)).isFalse();
    }
}
