package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.contrato.ResultadoCorreo;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.notificacion.repository.NotificacionEnvioRepository;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

/**
 * F3 (§6.4): aplica un {@code ResultadoCorreo} (§5.2, uno por intento) a la notificación.
 *
 * <ul>
 *   <li>Valida el payload (versión 1 y campos obligatorios); inválido →
 *       {@link AmqpRejectAndDontRequeueException} (sin reenqueue, §3.1).</li>
 *   <li>La notificación ausente no rompe el consumo: WARN y ack.</li>
 *   <li>Registra el intento en {@code notificacion_envio} (dedup por notificación/canal/intento,
 *       CB004).</li>
 *   <li>{@code ENVIADO} gana siempre (aunque llegue tarde); {@code FALLIDO} con
 *       {@code final=true} solo aplica si el estado era {@code PENDIENTE}.</li>
 * </ul>
 */
@Service
public class ResultadoCorreoService {

    private static final Logger log = LoggerFactory.getLogger(ResultadoCorreoService.class);
    private static final String CANAL_EMAIL = "EMAIL";
    private static final Set<String> RESULTADOS_VALIDOS = Set.of("ENVIADO", "FALLIDO");

    private final NotificacionRepository notificacionRepository;
    private final NotificacionEnvioRepository envioRepository;

    public ResultadoCorreoService(NotificacionRepository notificacionRepository,
                                  NotificacionEnvioRepository envioRepository) {
        this.notificacionRepository = notificacionRepository;
        this.envioRepository = envioRepository;
    }

    @Transactional
    public void aplicar(ResultadoCorreo resultado) {
        validar(resultado);

        Notificacion notificacion = notificacionRepository.buscarParaActualizar(resultado.notificacionId())
                .orElse(null);
        if (notificacion == null) {
            log.warn("Resultado de correo para notificación inexistente {} (mensaje {}); se ignora",
                    resultado.notificacionId(), resultado.mensajeId());
            return;
        }

        Long envioId = envioRepository.insertarIntento(
                notificacion.getId(),
                CANAL_EMAIL,
                resultado.destino(),
                resultado.intento(),
                resultado.resultado(),
                resultado.errorDetalle(),
                resultado.proveedorId(),
                resultado.codigoError());
        if (envioId == null) {
            log.debug("Intento {} duplicado para notificación {}; se ignora (idempotencia CB004)",
                    resultado.intento(), notificacion.getId());
        }

        EstadoCorreo antes = notificacion.getEstadoCorreo();
        if ("ENVIADO".equals(resultado.resultado())) {
            // §6.4: ENVIADO gana siempre, aunque el resultado llegue tarde.
            notificacion.setEstadoCorreo(EstadoCorreo.ENVIADO);
        } else if (resultado.resultadoFinal() && antes == EstadoCorreo.PENDIENTE) {
            notificacion.setEstadoCorreo(EstadoCorreo.FALLIDO);
        } else {
            // FALLIDO no final (o resultado tardío sobre un estado ya resuelto): sin cambios.
            return;
        }
        notificacionRepository.save(notificacion);
        log.info("Notificación {}: {} → {} (intentos={})", notificacion.getId(), antes,
                notificacion.getEstadoCorreo(), resultado.intento());
    }

    /** Contrato §5.2 (§6.4): versión y campos obligatorios; inválido → sin reenqueue. */
    private void validar(ResultadoCorreo r) {
        if (r.version() != MensajePublicador.CONTRATO_VERSION
                || r.mensajeId() == null
                || r.notificacionId() == null
                || r.intento() < 1
                || !RESULTADOS_VALIDOS.contains(r.resultado())
                || r.destino() == null || r.destino().isBlank()) {
            log.warn("Resultado de correo inválido (mensaje {}); se rechaza sin reenqueue", r.mensajeId());
            throw new AmqpRejectAndDontRequeueException(
                    "Resultado de correo inválido: versión, mensajeId, notificacionId, intento, resultado y destino son obligatorios");
        }
    }
}
