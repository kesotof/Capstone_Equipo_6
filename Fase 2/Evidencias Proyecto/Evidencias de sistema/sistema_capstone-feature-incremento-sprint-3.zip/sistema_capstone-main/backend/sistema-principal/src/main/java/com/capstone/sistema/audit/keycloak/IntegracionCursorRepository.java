package com.capstone.sistema.audit.keycloak;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/** US-27: acceso al cursor de integración (lectura con bloqueo al avanzar). */
@Repository
public interface IntegracionCursorRepository extends JpaRepository<IntegracionCursor, String> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<IntegracionCursor> findByNombre(String nombre);
}
