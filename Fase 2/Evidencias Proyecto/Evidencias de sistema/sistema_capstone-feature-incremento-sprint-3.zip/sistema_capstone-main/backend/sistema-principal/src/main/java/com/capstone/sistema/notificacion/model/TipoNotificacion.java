package com.capstone.sistema.notificacion.model;

import com.capstone.sistema.model.enums.CategoriaNotificacion;
import com.capstone.sistema.model.enums.RolDestinatario;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import java.util.Objects;

@Entity
@Table(name = "tipo_notificacion")
public class TipoNotificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "codigo", nullable = false, unique = true, length = 50)
    private String codigo;

    @Column(name = "descripcion", length = 255)
    private String descripcion;

    /** US-36: categoría del catálogo ( columna con default, nunca nula). */
    @Enumerated(EnumType.STRING)
    @Column(name = "categoria", nullable = false, length = 20)
    private CategoriaNotificacion categoria = CategoriaNotificacion.INFORMATIVA;

    /** US-36: rol destinatario del catálogo. */
    @Enumerated(EnumType.STRING)
    @Column(name = "rol_destinatario", nullable = false, length = 12)
    private RolDestinatario rolDestinatario = RolDestinatario.CUALQUIERA;

    /** US-36/D3-01: si este tipo dispara correo (regla editable por el PO). */
    @Column(name = "envia_correo", nullable = false)
    private boolean enviaCorreo = false;

    protected TipoNotificacion() {
    }

    public TipoNotificacion(String codigo) {
        this.codigo = codigo;
    }

    public TipoNotificacion(Long id, String codigo) {
        this.id = id;
        this.codigo = codigo;
    }

    public TipoNotificacion(String codigo, String descripcion) {
        this.codigo = codigo;
        this.descripcion = descripcion;
    }

    public Long getId() {
        return id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public CategoriaNotificacion getCategoria() {
        return categoria;
    }

    public RolDestinatario getRolDestinatario() {
        return rolDestinatario;
    }

    public boolean isEnviaCorreo() {
        return enviaCorreo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Transient
    public String getTipo() {
        return codigo;
    }

    public void setTipo(String tipo) {
        this.codigo = tipo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoNotificacion that = (TipoNotificacion) o;
        return Objects.equals(codigo, that.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
