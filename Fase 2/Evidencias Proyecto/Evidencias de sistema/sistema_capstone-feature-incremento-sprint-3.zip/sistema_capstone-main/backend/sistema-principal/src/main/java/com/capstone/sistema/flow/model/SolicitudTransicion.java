package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;

import java.time.Instant;
import java.util.Objects;

public class SolicitudTransicion {

    private Long id;
    private Solicitud solicitud;
    private Transicion transicion;
    private EstadoSolicitud estadoOrigen;
    private EstadoSolicitud estadoDestino;
    private AccionUsuario accionUsuario;
    private UserAccount usuario;
    private String comentario;
    private String metadata = "{}";
    private Instant createdAt = Instant.now();
    private Boolean dentroSla;
    private FlujoEtapa etapaOrigen;
    private FlujoEtapa etapaDestino;

    public FlujoEtapa getEtapaOrigen() {
        return etapaOrigen;
    }

    public FlujoEtapa getEtapaDestino() {
        return etapaDestino;
    }

    public void captureEtapas(FlujoEtapa origen, FlujoEtapa destino) {
        etapaOrigen = origen;
        etapaDestino = destino;
    }

    public SolicitudTransicion() {
    }

    public SolicitudTransicion(
            Solicitud solicitud,
            Transicion transicion,
            EstadoSolicitud estadoOrigen,
            EstadoSolicitud estadoDestino,
            AccionUsuario accionUsuario,
            UserAccount usuario,
            String comentario,
            String metadata
    ) {
        this.solicitud = solicitud;
        this.transicion = transicion;
        this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.accionUsuario = accionUsuario;
        this.usuario = usuario;
        this.comentario = comentario;
        this.metadata = metadata != null ? metadata : "{}";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public Transicion getTransicion() {
        return transicion;
    }

    public void setTransicion(Transicion transicion) {
        this.transicion = transicion;
    }

    public EstadoSolicitud getEstadoOrigen() {
        return estadoOrigen;
    }

    public void setEstadoOrigen(EstadoSolicitud estadoOrigen) {
        this.estadoOrigen = estadoOrigen;
    }

    public EstadoSolicitud getEstadoDestino() {
        return estadoDestino;
    }

    public void setEstadoDestino(EstadoSolicitud estadoDestino) {
        this.estadoDestino = estadoDestino;
    }

    public AccionUsuario getAccionUsuario() {
        return accionUsuario;
    }

    public void setAccionUsuario(AccionUsuario accionUsuario) {
        this.accionUsuario = accionUsuario;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getDentroSla() {
        return dentroSla;
    }

    public void setDentroSla(Boolean dentroSla) {
        this.dentroSla = dentroSla;
    }

    public void captureTimestamp(Instant now) {
        this.createdAt = now;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SolicitudTransicion that = (SolicitudTransicion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
