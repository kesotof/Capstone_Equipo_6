package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.flow.service.FlujoReviewerResolver;
import com.capstone.sistema.mensajeria.NotificacionesCorreoProperties;
import com.capstone.sistema.model.enums.CategoriaNotificacion;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.model.view.VRevisorSolicitud;
import com.capstone.sistema.model.view.VRevisorSolicitudRepository;
import com.capstone.sistema.notificacion.dto.CorreoEstadoDto;
import com.capstone.sistema.notificacion.dto.MensajeNotificacion;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import com.capstone.sistema.notificacion.dto.NotificacionResponse;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.notificacion.model.TipoNotificacion;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import com.capstone.sistema.notificacion.repository.TipoNotificacionRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * F3: bandeja de notificaciones y creación por catálogo (US-35/36). El núcleo es
 * {@link #crear}: persiste con idempotencia por {@code clave_dedup} (ON CONFLICT) y decide el
 * correo con la regla D3-01 — {@code tipo_notificacion.envia_correo && notificaciones.correo.habilitado
 * && destinatario.activo} — dejando la notificación en PENDIENTE y publicando el
 * {@code ComandoEnviarCorreo} (§5.1) vía {@link CorreoNotificacionService}. Los textos salen
 * siempre de {@link NotificacionMensajeFactory} (§6.1); los compositores por evento arman la
 * misma lógica de destinatarios de la tabla §6.1 y nunca notifican al actor.
 */
@Service
public class NotificacionService {

    private static final Logger log = LoggerFactory.getLogger(NotificacionService.class);

    private final NotificacionRepository notificacionRepository;
    private final TipoNotificacionRepository tipoNotificacionRepository;
    private final RbacAccessService access;
    private final FlujoReviewerResolver reviewers;
    private final VRevisorSolicitudRepository vRevisorSolicitudRepository;
    private final UserAccountRepository userAccountRepository;
    private final HistorialTransicionRepository historialTransicionRepository;
    private final NotificacionMensajeFactory factory;
    private final CorreoNotificacionService correos;
    private final NotificacionesCorreoProperties correo;

    public NotificacionService(
            NotificacionRepository notificacionRepository,
            TipoNotificacionRepository tipoNotificacionRepository,
            RbacAccessService access,
            FlujoReviewerResolver reviewers,
            VRevisorSolicitudRepository vRevisorSolicitudRepository,
            UserAccountRepository userAccountRepository,
            HistorialTransicionRepository historialTransicionRepository,
            NotificacionMensajeFactory factory,
            CorreoNotificacionService correos,
            NotificacionesCorreoProperties correo
    ) {
        this.notificacionRepository = notificacionRepository;
        this.tipoNotificacionRepository = tipoNotificacionRepository;
        this.access = access;
        this.reviewers = reviewers;
        this.vRevisorSolicitudRepository = vRevisorSolicitudRepository;
        this.userAccountRepository = userAccountRepository;
        this.historialTransicionRepository = historialTransicionRepository;
        this.factory = factory;
        this.correos = correos;
        this.correo = correo;
    }

    // ------------------------------------------------------------------ núcleo (§6.2)

    /**
     * F3 (§6.2): crea una notificación del catálogo para un destinatario concreto.
     *
     * <ol>
     *   <li>INSERT con {@code ON CONFLICT (clave_dedup) DO NOTHING}; si la fila ya existía,
     *       devuelve {@code null} (idempotencia).</li>
     *   <li>Si el tipo envía correo, la bandera global está activa y el destinatario está
     *       activo: estado PENDIENTE, {@code correo_publicado_en} y publicaciones = 1, y
     *       publica el comando con intento 1 (tras commit; broker caído no rompe — CA 09.4).</li>
     *   <li>En cualquier otro caso queda NO_APLICA.</li>
     * </ol>
     */
    @Transactional
    public Notificacion crear(String tipoCodigo, UserAccount destinatario, Solicitud solicitud,
                              Long historialId, MensajeNotificacion mensaje, String claveDedup) {
        TipoNotificacion tipo = getTipoNotificacion(tipoCodigo);
        HistorialTransicion historial = historialId != null && historialTransicionRepository != null
                ? historialTransicionRepository.findById(historialId).orElse(null)
                : null;
        Long id = notificacionRepository.insertarIgnorandoDedup(
                destinatario.getId(),
                solicitud != null ? solicitud.getId() : null,
                historial != null ? historial.getId() : null,
                tipo.getId(),
                mensaje.titulo(),
                mensaje.mensaje(),
                mensaje.enlace(),
                claveDedup);
        if (id == null) {
            log.debug("Notificación {} duplicada para destinatario {} (clave_dedup={}); se ignora",
                    tipoCodigo, destinatario.getEmail(), claveDedup);
            return null;
        }
        if (!debeEnviarCorreo(tipo, destinatario)) {
            return notificacionRepository.findById(id).orElse(null);
        }
        // §6.2: la publicación es afterCommit; el estado se fija dentro de esta transacción.
        notificacionRepository.marcarCorreoPendiente(id, Instant.now());
        Notificacion pendiente = notificacionRepository.findById(id).orElse(null);
        if (pendiente != null) {
            correos.publicar(pendiente, 1);
        }
        return pendiente;
    }

    /** D3-01 + §6.1 (usuarios inactivos): la única regla de elegibilidad de correo. */
    private boolean debeEnviarCorreo(TipoNotificacion tipo, UserAccount destinatario) {
        return tipo.isEnviaCorreo()
                && correo != null && correo.habilitado()
                && destinatario.isActivo();
    }

    // ------------------------------------------------------- compositores por evento (§6.1)

    /** REVISION_ASIGNADA → revisores de la etapa destino (v_revisor_solicitud), salvo el actor. */
    public void notificarRevisionAsignada(Solicitud solicitud, NotificacionContexto ctx) {
        int creadas = 0;
        for (UserAccount destinatario : responsablesActuales(solicitud)) {
            if (esActor(destinatario, ctx)) {
                continue;
            }
            if (crear("REVISION_ASIGNADA", destinatario, solicitud, ctx.historialId(),
                    factory.construir("REVISION_ASIGNADA", ctx), null) != null) {
                creadas++;
            }
        }
        log.info("REVISION_ASIGNADA: {} notificación(es) para solicitud {}", creadas, solicitud.getId());
    }

    /** SOLICITUD_AVANZA → emisor, salvo que sea el actor (correo apagado por catálogo). */
    public void notificarSolicitudAvanza(Solicitud solicitud, NotificacionContexto ctx) {
        notificarEmisor("SOLICITUD_AVANZA", solicitud, ctx);
    }

    /** SOLICITUD_APROBADA → emisor. */
    public void notificarSolicitudAprobada(Solicitud solicitud, NotificacionContexto ctx) {
        notificarEmisor("SOLICITUD_APROBADA", solicitud, ctx);
    }

    /** SOLICITUD_RECHAZADA → emisor. */
    public void notificarSolicitudRechazada(Solicitud solicitud, NotificacionContexto ctx) {
        notificarEmisor("SOLICITUD_RECHAZADA", solicitud, ctx);
    }

    /** CORRECCION_REQUERIDA → emisor. */
    public void notificarCorreccionRequerida(Solicitud solicitud, NotificacionContexto ctx) {
        notificarEmisor("CORRECCION_REQUERIDA", solicitud, ctx);
    }

    /**
     * DECISION_ADMIN_GLOBAL (US-37/CA 37.4) → revisores asignados de la etapa origen que el
     * motor capturó antes de avanzar, salvo el actor.
     */
    public void notificarDecisionAdmin(Solicitud solicitud, NotificacionContexto ctx, Collection<UUID> revisorIds) {
        if (revisorIds == null || revisorIds.isEmpty() || userAccountRepository == null) {
            return;
        }
        int creadas = 0;
        for (UserAccount destinatario : userAccountRepository.findAllById(revisorIds)) {
            if (esActor(destinatario, ctx)) {
                continue;
            }
            if (crear("DECISION_ADMIN_GLOBAL", destinatario, solicitud, ctx.historialId(),
                    factory.construir("DECISION_ADMIN_GLOBAL", ctx), null) != null) {
                creadas++;
            }
        }
        log.info("DECISION_ADMIN_GLOBAL: {} notificación(es) para solicitud {}", creadas, solicitud.getId());
    }

    /**
     * Reasignación de revisores por gestión de flujos (FlujoResponsableService): avisa a los
     * responsables que no eran responsables antes, con el texto del catálogo REVISION_ASIGNADA.
     */
    @Transactional
    public void notificarReasignacion(Solicitud request, Set<UUID> previousRecipients) {
        NotificacionContexto ctx = contextoReasignacion(request);
        int creadas = 0;
        for (UserAccount destinatario : responsablesActuales(request)) {
            if (previousRecipients != null && previousRecipients.contains(destinatario.getId())) {
                continue;
            }
            if (crear("REVISION_ASIGNADA", destinatario, request, null,
                    factory.construir("REVISION_ASIGNADA", ctx), null) != null) {
                creadas++;
            }
        }
        log.info("Reasignación: {} notificación(es) REVISION_ASIGNADA para solicitud {}", creadas, request.getId());
    }

    private void notificarEmisor(String tipoCodigo, Solicitud solicitud, NotificacionContexto ctx) {
        if (solicitud == null || solicitud.getEmisor() == null) {
            return;
        }
        if (esActor(solicitud.getEmisor(), ctx)) {
            log.debug("El actor es el emisor; se omite {} para solicitud {}", tipoCodigo, solicitud.getId());
            return;
        }
        // Defensa RBAC heredada de Sprint 2: solo si el emisor puede leer su propia solicitud.
        if (access != null && !access.canRead(solicitud.getEmisor(), solicitud.getId())) {
            return;
        }
        if (crear(tipoCodigo, solicitud.getEmisor(), solicitud, ctx.historialId(),
                factory.construir(tipoCodigo, ctx), null) != null) {
            log.info("{}: notificación creada para emisor {} en solicitud {}",
                    tipoCodigo, solicitud.getEmisor().getEmail(), solicitud.getId());
        }
    }

    /** §6.1 (D-08): nadie se notifica sobre su propia acción. */
    private boolean esActor(UserAccount destinatario, NotificacionContexto ctx) {
        return destinatario != null && ctx != null && ctx.actorId() != null
                && ctx.actorId().equals(destinatario.getId());
    }

    private NotificacionContexto contextoReasignacion(Solicitud request) {
        return new NotificacionContexto(
                request.getId(),
                null,
                request.getCorrelativo(),
                request.getTitulo(),
                request.getTipoDocumento(),
                null,
                request.getFlujoEtapa() != null ? request.getFlujoEtapa().getNombre() : null,
                "Administración de flujos",
                getNombreCompleto(request.getEmisor()),
                null,
                request.getDeadline(),
                null,
                "REGISTRAR"
        );
    }

    private List<UserAccount> responsablesActuales(Solicitud solicitud) {
        if (solicitud == null || solicitud.getId() == null) {
            return List.of();
        }
        if (vRevisorSolicitudRepository != null && userAccountRepository != null) {
            List<VRevisorSolicitud> revisores = vRevisorSolicitudRepository.findBySolicitudId(solicitud.getId());
            if (revisores != null && !revisores.isEmpty()) {
                List<UUID> userIds = revisores.stream().map(VRevisorSolicitud::getUsuarioId).toList();
                return userAccountRepository.findAllById(userIds);
            }
        }
        if (reviewers != null && solicitud.getFlujoEtapa() != null) {
            return reviewers.forRequest(solicitud, solicitud.getFlujoEtapa());
        }
        return List.of();
    }

    // ------------------------------------------------------------------ bandeja (§6.3)

    /** F3 (§6.3): filtros opcionales {@code categoria} y {@code soloNoLeidas}. */
    @Transactional(readOnly = true)
    public List<NotificacionResponse> listarMisNotificaciones(UserAccount user, CategoriaNotificacion categoria,
                                                              boolean soloNoLeidas) {
        List<Notificacion> base;
        if (categoria != null && soloNoLeidas) {
            base = notificacionRepository.findByDestinatario_IdAndCategoriaAndLeidaFalse(user.getId(), categoria);
        } else if (categoria != null) {
            base = notificacionRepository.findByDestinatario_IdAndCategoria(user.getId(), categoria);
        } else if (soloNoLeidas) {
            base = notificacionRepository.findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(user.getId());
        } else {
            base = notificacionRepository.findByDestinatario_IdOrderByCreatedEnDesc(user.getId());
        }
        return base.stream().map(this::toDto).toList();
    }

    @Transactional(readOnly = true)
    public long contarNoLeidas(UserAccount user) {
        return notificacionRepository.countByDestinatario_IdAndLeidaFalse(user.getId());
    }

    @Transactional
    public NotificacionResponse marcarComoLeida(Long notificacionId, UserAccount user) {
        Notificacion notificacion = notificacionRepository.findById(notificacionId)
                .orElseThrow(com.capstone.sistema.rbac.exception.RbacException::missing);

        if (!notificacion.getDestinatario().getId().equals(user.getId())) {
            throw com.capstone.sistema.rbac.exception.RbacException.missing();
        }

        notificacion.setLeida(true);
        notificacionRepository.save(notificacion);
        return toDto(notificacion);
    }

    @Transactional
    public int marcarTodasComoLeidas(UserAccount user) {
        List<Notificacion> noLeidas = notificacionRepository.findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(user.getId());
        for (Notificacion n : noLeidas) {
            n.setLeida(true);
        }
        notificacionRepository.saveAll(noLeidas);
        log.info("Marcadas como leídas {} notificaciones para usuario {}", noLeidas.size(), user.getEmail());
        return noLeidas.size();
    }

    // ------------------------------------------------------------------ correos (§6.4/§7.1)

    /** F3 (§7.1): bandeja admin de correos por estado (PENDIENTE/FALLIDO). */
    @Transactional(readOnly = true)
    public com.capstone.sistema.notificacion.dto.CorreoEstadoPageResponse correosPorEstado(EstadoCorreo estado,
                                                                                            int pagina, int tamano) {
        int tam = Math.min(Math.max(tamano, 1), 100);
        Page<CorreoEstadoDto> page = notificacionRepository
                .findByEstadoCorreo(estado, PageRequest.of(Math.max(pagina, 0), tam))
                .map(this::toCorreoDto);
        return new com.capstone.sistema.notificacion.dto.CorreoEstadoPageResponse(
                page.getContent(), page.getNumber(), page.getSize(), page.getTotalElements(), page.getTotalPages());
    }

    /**
     * F3 (§7.1): reenvío manual de un correo FALLIDO — vuelve a PENDIENTE con
     * {@code correo_publicaciones = 1} y lo retoma el re-publicador tras el umbral.
     *
     * @throws IllegalStateException si la notificación no está FALLIDO (el caller responde 409).
     */
    @Transactional
    public Notificacion reenviarCorreo(Long notificacionId) {
        Notificacion notificacion = notificacionRepository.buscarParaActualizar(notificacionId)
                .orElseThrow(com.capstone.sistema.rbac.exception.RbacException::missing);
        if (notificacion.getEstadoCorreo() != EstadoCorreo.FALLIDO) {
            throw new IllegalStateException("Solo los correos FALLIDO admiten reenvío: notificación "
                    + notificacionId + " está en " + notificacion.getEstadoCorreo());
        }
        notificacion.setEstadoCorreo(EstadoCorreo.PENDIENTE);
        notificacion.setCorreoPublicadoEn(Instant.now());
        notificacion.setCorreoPublicaciones(1);
        notificacionRepository.save(notificacion);
        log.info("Correo de notificación {} devuelto a PENDIENTE por reenvío manual", notificacionId);
        return notificacion;
    }

    // ------------------------------------------------------------------ mapeos

    private NotificacionResponse toDto(Notificacion n) {
        return new NotificacionResponse(
                n.getId(),
                n.getTitulo(),
                n.getMensaje(),
                n.getTipoNotificacion().getTipo(),
                n.getTipoNotificacion().getCategoria(),
                n.getTipoNotificacion().getRolDestinatario(),
                n.getEnlace(),
                n.getSolicitud() != null ? n.getSolicitud().getCorrelativo() : null,
                n.getSolicitud() != null ? n.getSolicitud().getId() : null,
                n.isLeida(),
                n.getCreatedEn(),
                n.getLeidaEn(),
                n.getEstadoCorreo()
        );
    }

    private CorreoEstadoDto toCorreoDto(Notificacion n) {
        return new CorreoEstadoDto(
                n.getId(),
                n.getSolicitud() != null ? n.getSolicitud().getId() : null,
                n.getSolicitud() != null ? n.getSolicitud().getCorrelativo() : null,
                n.getDestinatario() != null ? n.getDestinatario().getEmail() : null,
                n.getTitulo(),
                n.getEstadoCorreo(),
                n.getCorreoPublicaciones(),
                n.getCorreoPublicadoEn(),
                n.getCreatedEn()
        );
    }

    private TipoNotificacion getTipoNotificacion(String codigo) {
        return tipoNotificacionRepository.findByTipoIgnoreCase(codigo)
                .orElseGet(() -> tipoNotificacionRepository.save(new TipoNotificacion(codigo)));
    }

    private String getNombreCompleto(UserAccount user) {
        if (user == null) {
            return "Usuario";
        }
        String nombre = user.getFirstName() != null ? user.getFirstName() : "";
        String apellido = user.getLastName() != null ? user.getLastName() : "";
        String full = (nombre + " " + apellido).trim();
        return full.isEmpty() ? user.getEmail() : full;
    }
}
