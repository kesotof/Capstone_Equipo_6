package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Transicion;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TransicionRepository {

    public Transicion save(Transicion transicion) {
        return transicion;
    }
}
