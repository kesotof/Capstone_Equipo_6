package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlujoConfigServiceTest {

    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;

    @Mock
    private SolicitudRepository solicitudRepository;

    @Mock
    private AreaRepository areaRepository;

    @Mock
    private AuditService auditService;

    @Mock
    private RbacAccessService rbacAccessService;

    @Mock
    private FlujoReviewerResolver flujoReviewerResolver;

    private FlujoConfigService flujoConfigService;

    private Area finanzas;
    private UserAccount adminUser;
    private UserAccount revisorUser;

    @BeforeEach
    void setUp() {
        adminUser = new UserAccount("kc-admin", "admin@empresa.cl", "Admin", "General", true);
        revisorUser = new UserAccount("kc-rev", "revisor@otra-area.cl", "Revisor", "Uno", true);
        finanzas = new Area(1L, "Finanzas", true);

        flujoConfigService = new FlujoConfigService(
                flujoDefinicionRepository,
                solicitudRepository,
                areaRepository,
                auditService,
                rbacAccessService,
                null,
                null,
                null,
                flujoReviewerResolver,
                null
        );
    }

    @Test
    @DisplayName("Admin crea flujo asociado a un área exitosamente con estado completo=false")
    void crearFlujo_conArea_retornaCreadoIncompleto() {
        CrearFlujoRequest request = new CrearFlujoRequest("Aprobación Gastos", "Flujo para gastos", 1L);

        when(flujoDefinicionRepository.existsNormalizedName("Aprobación Gastos", null)).thenReturn(false);
        when(areaRepository.findById(1L)).thenReturn(Optional.of(finanzas));
        when(flujoDefinicionRepository.saveAndFlush(any(FlujoDefinicion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        FlujoResponse response = flujoConfigService.crearFlujo(request);

        assertThat(response.nombre()).isEqualTo("Aprobación Gastos");
        assertThat(response.areaId()).isEqualTo(1L);
        assertThat(response.areaNombre()).isEqualTo("Finanzas");
        assertThat(response.activo()).isTrue();
        assertThat(response.completo()).isFalse();

        verify(auditService).registerUserManagementEvent(eq("CREAR_FLUJO"), contains("Aprobación Gastos"));
    }

    @Test
    @DisplayName("Rechaza crear flujo con nombre duplicado")
    void crearFlujo_nombreDuplicado_lanzaConflicto() {
        CrearFlujoRequest request = new CrearFlujoRequest("Flujo Existente", "Desc", null);
        when(flujoDefinicionRepository.existsNormalizedName("Flujo Existente", null)).thenReturn(true);

        assertThatThrownBy(() -> flujoConfigService.crearFlujo(request))
                .isInstanceOf(FlujoConflictException.class)
                .hasMessageContaining("Ya existe un flujo");
    }

    @Test
    @DisplayName("Configurar etapas atómicamente con revisores marca flujo como completo=true")
    void configurarEtapas_conRevisores_marcaCompletoTrue() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Flujo Legal", finanzas);

        UUID revId = UUID.randomUUID();
        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(rbacAccessService.canManageFlow(1L)).thenReturn(true);
        when(flujoDefinicionRepository.saveAndFlush(any(FlujoDefinicion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        doAnswer(invocation -> {
            FlujoEtapa stage = invocation.getArgument(0);
            stage.setRevisor(revisorUser);
            return null;
        }).when(flujoReviewerResolver).assign(any(FlujoEtapa.class), any(), any());

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Revisión Jefatura", revId),
                new EtapaConfigItem(2, "Visado Final", revId)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        FlujoResponse response = flujoConfigService.configurarEtapas(flujoId, req);

        assertThat(response.completo()).isTrue();
        assertThat(response.etapas()).hasSize(2);
        assertThat(response.etapas().get(0).orden()).isEqualTo(1);
        assertThat(response.etapas().get(0).revisorEmail()).isEqualTo("revisor@otra-area.cl");
        assertThat(response.etapas().get(1).orden()).isEqualTo(2);

        verify(auditService).registerAuditEvent(
                eq("CONFIGURAR_ETAPAS_FLUJO"), eq("flujo"), eq("10"), eq("EXITO"),
                contains("\"flujoId\":10"));
    }

    @Test
    @DisplayName("Configurar etapas donde una no tiene revisor asignado marca completo=false")
    void configurarEtapas_revisorPendiente_marcaCompletoFalse() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Flujo Legal", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(flujoDefinicionRepository.saveAndFlush(any(FlujoDefinicion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Revisión Preliminar", null)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        FlujoResponse response = flujoConfigService.configurarEtapas(flujoId, req);

        assertThat(response.completo()).isFalse();
        assertThat(response.etapas().get(0).revisorId()).isNull();
    }

    @Test
    @DisplayName("Configurar etapas con orden no correlativo lanza excepción")
    void configurarEtapas_ordenInvalido_lanzaIllegalArgument() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));

        List<EtapaConfigItem> items = List.of(
                new EtapaConfigItem(1, "Etapa 1", null),
                new EtapaConfigItem(3, "Etapa 3", null)
        );
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        assertThatThrownBy(() -> flujoConfigService.configurarEtapas(flujoId, req))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("consecutivo");
    }

    @Test
    @DisplayName("Revisor inactivo en etapa lanza excepción orphan FLUJO_ETAPA_HUERFANA")
    void configurarEtapas_revisorInactivo_lanzaRbacException() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);
        UUID revId = UUID.randomUUID();

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        doThrow(FlujoReviewerResolver.orphan("La etapa 'Etapa 1' necesita un usuario disponible o un rol con revisores en el área del flujo."))
                .when(flujoReviewerResolver).assign(any(FlujoEtapa.class), any(), anyList());

        List<EtapaConfigItem> items = List.of(new EtapaConfigItem(1, "Etapa 1", revId));
        ConfigurarEtapasRequest req = new ConfigurarEtapasRequest(items);

        assertThatThrownBy(() -> flujoConfigService.configurarEtapas(flujoId, req))
                .isInstanceOf(RbacException.class)
                .hasMessageContaining("necesita un usuario disponible");
    }

    @Test
    @DisplayName("Usuario sin permisos para gestionar flujos recibe RbacException")
    void gestionarFlujo_usuarioSinPermisos_lanzaRbacException() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        doThrow(RbacException.denied())
                .when(rbacAccessService).manageFlow(eq(1L));

        ActualizarFlujoRequest request = new ActualizarFlujoRequest("Nuevo Nombre", "Desc", 1L, true);

        assertThatThrownBy(() -> flujoConfigService.actualizarFlujo(flujoId, request))
                .isInstanceOf(RbacException.class)
                .hasMessageContaining("No tiene permiso");
    }

    @Test
    @DisplayName("Eliminar flujo con solicitudes activas lo desactiva en vez de borrar físicamente")
    void eliminarFlujo_conSolicitudes_desactivaFlujo() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("Contratos", "Desc", finanzas);
        flujo.setActivo(true);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(solicitudRepository.existsByFlujoDefinicion_Id(flujoId)).thenReturn(true);

        flujoConfigService.eliminarFlujo(flujoId);

        assertThat(flujo.isActivo()).isFalse();
        verify(flujoDefinicionRepository).save(flujo);
        verify(flujoDefinicionRepository, never()).delete(any());
        verify(auditService).registerUserManagementEvent(eq("DESACTIVAR_FLUJO"), contains("desactivado conservando solicitudes"));
    }

    @Test
    @DisplayName("Eliminar flujo sin solicitudes lo elimina permanentemente")
    void eliminarFlujo_sinSolicitudes_eliminaPermanente() {
        Long flujoId = 10L;
        FlujoDefinicion flujo = new FlujoDefinicion("SinUso", "Desc", finanzas);

        when(flujoDefinicionRepository.findById(flujoId)).thenReturn(Optional.of(flujo));
        when(solicitudRepository.existsByFlujoDefinicion_Id(flujoId)).thenReturn(false);

        flujoConfigService.eliminarFlujo(flujoId);

        verify(flujoDefinicionRepository).delete(flujo);
        verify(auditService).registerUserManagementEvent(eq("ELIMINAR_FLUJO"), contains("eliminado sin solicitudes"));
    }
}
