package com.capstone.sistema.flow.service;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.exception.AiAnalysisNotFoundException;
import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.service.IaTareaService;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Adaptador de compatibilidad para el panel visual de evaluación de IA (/api/solicitudes/{id}/ai-analysis).
 * Conecta las llamadas del frontend con el motor asíncrono y resiliente de IaTareaService (Sprint 3).
 */
@Service
public class AiAnalysisService {

    private static final Logger log = LoggerFactory.getLogger(AiAnalysisService.class);

    private final IaTareaService iaTareaService;
    private final CurrentUserResolver currentUserResolver;

    public AiAnalysisService(
            IaTareaService iaTareaService,
            CurrentUserResolver currentUserResolver
    ) {
        this.iaTareaService = iaTareaService;
        this.currentUserResolver = currentUserResolver;
    }

    public AiAnalysisResponse solicitarAnalisis(UUID solicitudId, String customPrompt, boolean force) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new IllegalStateException("Usuario no autenticado para solicitar análisis de IA"));

        IaEvaluacionDto dto = iaTareaService.crearEvaluacionManual(solicitudId, actor, customPrompt, true);
        return mapToResponse(dto, solicitudId, false);
    }

    public AiAnalysisResponse obtenerUltimoAnalisis(UUID solicitudId) {
        UserAccount actor = currentUserResolver.resolveCurrentUser().orElse(null);
        UUID actorId = actor != null ? actor.getId() : null;

        List<IaEvaluacionDto> evaluaciones = iaTareaService.consultarEvaluaciones(solicitudId, actorId);
        if (evaluaciones.isEmpty()) {
            throw new AiAnalysisNotFoundException(solicitudId);
        }

        IaEvaluacionDto latest = evaluaciones.get(0);
        return mapToResponse(latest, solicitudId, true);
    }

    public void evaluarDocumentoVigente(Solicitud solicitud) {
        // En Sprint 3, la evaluación automática se dispara por el evento TransicionSolicitudEvent
        // capturado en IaEvaluacionAutomaticaListener. Este método se conserva como no-op seguro.
        log.debug("evaluarDocumentoVigente delegado al motor de eventos para solicitud {}", solicitud.getId());
    }

    private AiAnalysisResponse mapToResponse(IaEvaluacionDto dto, UUID solicitudId, boolean cached) {
        EstadoAnalisis estado;
        if ("COMPLETADA".equalsIgnoreCase(dto.estado())) {
            estado = EstadoAnalisis.COMPLETADO;
        } else if ("FALLIDA".equalsIgnoreCase(dto.estado())) {
            estado = EstadoAnalisis.ERROR;
        } else {
            estado = EstadoAnalisis.PENDIENTE;
        }

        Integer puntaje = null;
        Boolean valido = true;
        String observaciones = null;
        List<String> recomendaciones = new ArrayList<>();

        if (dto.resultado() != null && !dto.resultado().isNull()) {
            JsonNode res = dto.resultado();
            if (res.hasNonNull("puntaje")) {
                puntaje = res.get("puntaje").asInt();
            }
            if (res.hasNonNull("veredictoSugerido")) {
                valido = "CUMPLE".equalsIgnoreCase(res.get("veredictoSugerido").asText());
            } else if (res.hasNonNull("cumple")) {
                valido = res.get("cumple").asBoolean();
            } else if (res.hasNonNull("valido")) {
                valido = res.get("valido").asBoolean();
            }
            if (res.hasNonNull("resumen")) {
                observaciones = res.get("resumen").asText();
            } else if (res.hasNonNull("observaciones") && res.get("observaciones").isTextual()) {
                observaciones = res.get("observaciones").asText();
            }
            if (res.has("recomendaciones") && res.get("recomendaciones").isArray()) {
                for (JsonNode item : res.get("recomendaciones")) {
                    if (item.isTextual() && !item.asText().isBlank()) {
                        recomendaciones.add(item.asText());
                    }
                }
            }
            if (recomendaciones.isEmpty() && res.has("observaciones") && res.get("observaciones").isArray()) {
                for (JsonNode item : res.get("observaciones")) {
                    if (item.isTextual() && !item.asText().isBlank()) {
                        recomendaciones.add(item.asText());
                    }
                }
            }
            if (recomendaciones.isEmpty() && res.has("hallazgos") && res.get("hallazgos").isArray()) {
                for (JsonNode item : res.get("hallazgos")) {
                    String detalle = item.hasNonNull("detalle") ? item.get("detalle").asText()
                            : (item.hasNonNull("descripcion") ? item.get("descripcion").asText() : null);
                    if (detalle != null && !detalle.isBlank()) {
                        recomendaciones.add(detalle);
                    }
                }
            }
        } else if (dto.error() != null) {
            observaciones = dto.error().mensaje();
        }

        UUID docId = dto.documento() != null ? dto.documento().id() : null;
        Integer docVersion = dto.documento() != null ? dto.documento().version() : 1;
        String docNombre = dto.documento() != null ? dto.documento().nombreArchivo() : "";

        return new AiAnalysisResponse(
                dto.id(),
                solicitudId,
                docId,
                estado,
                puntaje,
                valido,
                observaciones,
                recomendaciones,
                dto.modelo(),
                dto.criterio(),
                cached,
                dto.createdAt() != null ? dto.createdAt() : Instant.now(),
                dto.completedAt(),
                docVersion,
                docNombre,
                dto.vigente()
        );
    }
}
