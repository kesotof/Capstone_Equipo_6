package com.capstone.sistema.template.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.PlaceholderAnalysisResult;
import com.capstone.sistema.template.dto.PlantillaDtos.*;
import com.capstone.sistema.template.service.AutocompletadoIaService;
import com.capstone.sistema.template.service.GeneracionDesdePlantillaService;
import com.capstone.sistema.template.service.PlantillaService;
import com.capstone.sistema.template.service.SugerenciaCamposService;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Tag(name = "Plantillas DOCX", description = "Gestión de plantillas DOCX, detección de marcadores, publicación de versiones y generación documental")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/plantillas")
public class PlantillaController {

    private final PlantillaService plantillaService;
    private final GeneracionDesdePlantillaService generacionService;
    private final AutocompletadoIaService autocompletadoService;
    private final SugerenciaCamposService sugerenciaCamposService;
    private final CurrentUserResolver currentUserResolver;
    private final ObjectMapper objectMapper;

    public PlantillaController(
            PlantillaService plantillaService,
            GeneracionDesdePlantillaService generacionService,
            AutocompletadoIaService autocompletadoService,
            SugerenciaCamposService sugerenciaCamposService,
            CurrentUserResolver currentUserResolver,
            ObjectMapper objectMapper
    ) {
        this.plantillaService = plantillaService;
        this.generacionService = generacionService;
        this.autocompletadoService = autocompletadoService;
        this.sugerenciaCamposService = sugerenciaCamposService;
        this.currentUserResolver = currentUserResolver;
        this.objectMapper = objectMapper;
    }

    @Operation(summary = "Analizar archivo DOCX para detectar marcadores y sugerir campos")
    @PostMapping(value = "/analizar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlaceholderAnalysisResult> analizar(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(plantillaService.analizar(file));
    }

    @Operation(summary = "Vista HTML del DOCX con sus marcadores, para el editor de plantillas")
    @PostMapping(value = "/documento/vista", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentoPlantillaDto> vistaDocumento(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(plantillaService.vistaDocumento(file));
    }

    @Operation(summary = "Convertir textos del DOCX en marcadores {{clave}}; devuelve el DOCX modificado (Base64) y su vista")
    @PostMapping(value = "/documento/convertir", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentoPlantillaDto> convertirDocumento(
            @RequestParam("file") MultipartFile file,
            @RequestParam("conversiones") String conversionesJson
    ) {
        List<ConversionTexto> conversiones;
        try {
            conversiones = objectMapper.readValue(conversionesJson, new TypeReference<List<ConversionTexto>>() {});
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato JSON de conversiones inválido: " + e.getMessage());
        }
        return ResponseEntity.ok(plantillaService.convertirDocumento(file, conversiones));
    }

    @Operation(summary = "Quitar del DOCX los marcadores de campos eliminados; devuelve el DOCX modificado (Base64) y su vista")
    @PostMapping(value = "/documento/quitar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentoPlantillaDto> quitarMarcadores(
            @RequestParam("file") MultipartFile file,
            @RequestParam("claves") String clavesJson
    ) {
        List<String> claves;
        try {
            claves = objectMapper.readValue(clavesJson, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato JSON de claves inválido: " + e.getMessage());
        }
        return ResponseEntity.ok(plantillaService.quitarMarcadores(file, claves));
    }

    @Operation(summary = "Pedir a la IA qué textos del DOCX convertir en campos (tarea asíncrona)")
    @PostMapping(value = "/documento/sugerencias", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<SugerenciasCamposDto> sugerirCampos(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "existentes", required = false) String existentesJson
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        List<String> existentes = List.of();
        if (existentesJson != null && !existentesJson.isBlank()) {
            try {
                existentes = objectMapper.readValue(existentesJson, new TypeReference<List<String>>() {});
            } catch (Exception e) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato JSON de campos existentes inválido.");
            }
        }
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(sugerenciaCamposService.solicitar(file, existentes, actor));
    }

    @Operation(summary = "Consultar el estado de una sugerencia de campos con IA propia")
    @GetMapping("/documento/sugerencias/{sugerenciaId}")
    public ResponseEntity<SugerenciasCamposDto> obtenerSugerencias(@PathVariable UUID sugerenciaId) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.ok(sugerenciaCamposService.obtener(sugerenciaId, actor));
    }

    @Operation(summary = "Word de prueba: el DOCX en edición rellenado con los datos del formulario de prueba")
    @PostMapping(value = "/documento/prueba", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<byte[]> documentoDePrueba(
            @RequestParam("file") MultipartFile file,
            @RequestParam("campos") String camposJson,
            @RequestParam(value = "datos", required = false) String datosJson
    ) {
        Map<String, Object> datos;
        byte[] docx;
        try {
            datos = datosJson == null || datosJson.isBlank() ? Map.of() : objectMapper.readValue(datosJson, new TypeReference<Map<String, Object>>() {});
            docx = file.getBytes();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Datos de prueba inválidos: " + e.getMessage());
        }
        List<FieldDefinition> campos = parsearCampos(camposJson);
        byte[] resultado;
        try {
            resultado = generacionService.generarPrueba(docx, campos == null ? List.of() : campos, datos);
        } catch (IllegalStateException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible generar el Word de prueba: " + e.getMessage());
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"prueba.docx\"")
                .body(resultado);
    }

    @Operation(summary = "Listar plantillas paginadas")
    @GetMapping
    public ResponseEntity<Page<PlantillaSummaryDto>> listar(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) Long areaId,
            @RequestParam(required = false) Long tipoDocumentoId,
            @RequestParam(required = false) Boolean activo
    ) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return ResponseEntity.ok(plantillaService.listar(pageable, q, areaId, tipoDocumentoId, activo));
    }

    @Operation(summary = "Listar plantillas activas disponibles para el usuario actual")
    @GetMapping("/disponibles")
    public ResponseEntity<List<PlantillaSummaryDto>> listarDisponibles(
            @RequestParam(required = false) Long tipoDocumentoId
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser().orElse(null);
        return ResponseEntity.ok(plantillaService.listarDisponibles(tipoDocumentoId, actor));
    }

    @Operation(summary = "Crear nueva plantilla y publicar versión 1")
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlantillaDetailDto> crear(
            @RequestParam("file") MultipartFile file,
            @RequestParam("nombre") String nombre,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam("tipoDocumentoId") Long tipoDocumentoId,
            @RequestParam(value = "areaId", required = false) Long areaId,
            @RequestParam(value = "campos", required = false) String camposJson
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        CrearPlantillaRequest req = new CrearPlantillaRequest(nombre, descripcion, tipoDocumentoId, areaId, parsearCampos(camposJson));
        PlantillaDetailDto dto = plantillaService.crearPlantilla(req, file, actor);
        return ResponseEntity.created(URI.create("/api/plantillas/" + dto.id())).body(dto);
    }

    @Operation(summary = "Obtener detalle de plantilla por ID")
    @GetMapping("/{id}")
    public ResponseEntity<PlantillaDetailDto> obtener(@PathVariable Long id) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.ok(plantillaService.obtenerPlantilla(id, actor));
    }

    @Operation(summary = "Actualizar metadatos de plantilla")
    @PutMapping("/{id}")
    public ResponseEntity<PlantillaDetailDto> actualizar(
            @PathVariable Long id,
            @RequestBody ActualizarPlantillaRequest req
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.ok(plantillaService.actualizarPlantilla(id, req, actor));
    }

    @Operation(summary = "Cambiar estado activo/inactivo de plantilla")
    @PatchMapping("/{id}/status")
    public ResponseEntity<PlantillaDetailDto> cambiarEstado(
            @PathVariable Long id,
            @RequestBody StatusPlantillaRequest req
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.ok(plantillaService.cambiarEstado(id, req.activo(), actor));
    }

    @Operation(summary = "Publicar nueva versión de plantilla (sin archivo se reutiliza el DOCX vigente)")
    @PostMapping(value = "/{id}/versiones", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlantillaDetailDto> publicarVersion(
            @PathVariable Long id,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "campos", required = false) String camposJson,
            @RequestParam(value = "versionBase", required = false) Integer versionBase
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(plantillaService.publicarNuevaVersion(id, parsearCampos(camposJson), file, versionBase, actor));
    }

    @Operation(summary = "Eliminar plantilla (solo si nunca fue usada en documentos)")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        plantillaService.eliminarPlantilla(id, actor);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Obtener definición de formulario de la versión activa de la plantilla")
    @GetMapping("/{id}/formulario")
    public ResponseEntity<FormularioPlantillaDto> obtenerFormulario(@PathVariable Long id) {
        return ResponseEntity.ok(plantillaService.obtenerFormulario(id));
    }

    @Operation(summary = "Generar vista previa DOCX en memoria a partir de plantilla y datos")
    @PostMapping("/{id}/vista-previa")
    public ResponseEntity<byte[]> vistaPrevia(
            @PathVariable Long id,
            @RequestBody VistaPreviaRequest req
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser().orElse(null);
        byte[] docxBytes = generacionService.generarVistaPrevia(id, req.version(), req.datos(), actor);

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"vista_previa.docx\"")
                .body(docxBytes);
    }

    @Operation(summary = "Pedir a la IA valores para los campos de la plantilla a partir de un documento (PDF, Word o TXT) y/o indicaciones")
    @PostMapping(value = "/{id}/autocompletar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<AutocompletadoIaDto> autocompletar(
            @PathVariable Long id,
            @RequestParam(value = "archivo", required = false) MultipartFile archivo,
            @RequestParam(value = "indicaciones", required = false) String indicaciones
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(autocompletadoService.solicitar(id, archivo, indicaciones, actor));
    }

    @Operation(summary = "Consultar el estado y las sugerencias de un autocompletado con IA propio")
    @GetMapping("/autocompletados/{autocompletadoId}")
    public ResponseEntity<AutocompletadoIaDto> obtenerAutocompletado(@PathVariable UUID autocompletadoId) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
        return ResponseEntity.ok(autocompletadoService.obtener(autocompletadoId, actor));
    }

    @Operation(summary = "Descargar archivo DOCX original de una versión de plantilla")
    @GetMapping("/{id}/versiones/{version}/archivo")
    public ResponseEntity<byte[]> descargarArchivoVersion(
            @PathVariable Long id,
            @PathVariable Integer version
    ) {
        byte[] bytes = plantillaService.obtenerArchivoVersion(id, version);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"plantilla_" + id + "_v" + version + ".docx\"")
                .body(bytes);
    }

    private List<FieldDefinition> parsearCampos(String camposJson) {
        if (camposJson == null || camposJson.isBlank()) {
            return null;
        }
        try {
            return objectMapper.readValue(camposJson, new TypeReference<List<FieldDefinition>>() {});
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato JSON de campos inválido: " + e.getMessage());
        }
    }
}
