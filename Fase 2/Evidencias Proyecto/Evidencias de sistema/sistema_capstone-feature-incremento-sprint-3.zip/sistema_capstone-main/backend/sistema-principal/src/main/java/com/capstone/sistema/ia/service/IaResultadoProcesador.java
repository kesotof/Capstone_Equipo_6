package com.capstone.sistema.ia.service;

import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.contrato.ResultadoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldValidationError;
import com.capstone.sistema.template.schema.FieldSchemaBuilder;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * F6/F8 (§6.10): procesador transaccional e idempotente de resultados de IA (A-05).
 * Valida la estructura del resultado con los records de contrato; si no cumple, marca FALLIDA
 * con {@code RESULTADO_RECHAZADO}. Un resultado sobre una tarea ya completada/fallida se ignora.
 */
@Service
public class IaResultadoProcesador {

    private static final Logger log = LoggerFactory.getLogger(IaResultadoProcesador.class);

    private static final Set<String> VEREDICTOS_VALIDOS = Set.of("CUMPLE", "CUMPLE_PARCIAL", "NO_CUMPLE", "INDETERMINADO");

    private final IaTareaRepository iaTareaRepository;
    private final ObjectMapper objectMapper;
    private final FieldSchemaBuilder schemaBuilder;

    public IaResultadoProcesador(
            IaTareaRepository iaTareaRepository,
            ObjectMapper objectMapper,
            FieldSchemaBuilder schemaBuilder
    ) {
        this.iaTareaRepository = iaTareaRepository;
        this.objectMapper = objectMapper;
        this.schemaBuilder = schemaBuilder;
    }

    @Transactional
    public void aplicar(ResultadoTareaIa r) {
        if (r == null || r.tareaId() == null) {
            log.warn("Resultado de IA nulo o sin tareaId");
            return;
        }

        Optional<IaTarea> opt = iaTareaRepository.findByIdForUpdate(r.tareaId());
        if (opt.isEmpty()) {
            log.warn("Resultado de IA recibido para tarea inexistente: {}", r.tareaId());
            return;
        }

        IaTarea tarea = opt.get();
        if (tarea.getEstado() != EstadoTareaIa.PENDIENTE) {
            log.info("Ignorando resultado tardío o duplicado para tarea {} con estado {}", tarea.getId(), tarea.getEstado());
            return;
        }

        if ("COMPLETADA".equalsIgnoreCase(r.estado())) {
            procesarCompletada(tarea, r);
        } else {
            String codigo = r.codigoError() != null && !r.codigoError().isBlank() ? r.codigoError() : "ERROR_INTERNO";
            tarea.fallar(codigo, r.errorDetalle());
            iaTareaRepository.save(tarea);
            log.info("Tarea de IA {} marcada como FALLIDA ({})", tarea.getId(), codigo);
        }
    }

    private void procesarCompletada(IaTarea tarea, ResultadoTareaIa r) {
        if (r.resultado() == null || r.resultado().isNull()) {
            tarea.fallar("RESULTADO_RECHAZADO", "El resultado recibido es nulo");
            iaTareaRepository.save(tarea);
            return;
        }

        TipoTareaIa tipo = tarea.getTipo();
        try {
            if (tipo == TipoTareaIa.EVALUACION) {
                ResultadoTareaIa.ResultadoEvaluacion eval = objectMapper.treeToValue(
                        r.resultado(), ResultadoTareaIa.ResultadoEvaluacion.class
                );
                if (eval == null) {
                    tarea.fallar("RESULTADO_RECHAZADO", "No se pudo interpretar el resultado de evaluación");
                    iaTareaRepository.save(tarea);
                    return;
                }
                if (eval.puntaje() == null || eval.puntaje() < 0 || eval.puntaje() > 100) {
                    tarea.fallar("RESULTADO_RECHAZADO", "Puntaje fuera de rango [0-100]: " + eval.puntaje());
                    iaTareaRepository.save(tarea);
                    return;
                }
                if (eval.veredictoSugerido() == null || !VEREDICTOS_VALIDOS.contains(eval.veredictoSugerido().trim().toUpperCase())) {
                    tarea.fallar("RESULTADO_RECHAZADO", "Veredicto sugerido no reconocido: " + eval.veredictoSugerido());
                    iaTareaRepository.save(tarea);
                    return;
                }
                if (eval.resumen() == null || eval.resumen().isBlank()) {
                    tarea.fallar("RESULTADO_RECHAZADO", "El resumen de evaluación es obligatorio");
                    iaTareaRepository.save(tarea);
                    return;
                }
                if (eval.hallazgos() != null && eval.hallazgos().size() > 10) {
                    tarea.fallar("RESULTADO_RECHAZADO", "Exceso de hallazgos (máximo 10)");
                    iaTareaRepository.save(tarea);
                    return;
                }
                if (eval.recomendaciones() != null && eval.recomendaciones().size() > 10) {
                    tarea.fallar("RESULTADO_RECHAZADO", "Exceso de recomendaciones (máximo 10)");
                    iaTareaRepository.save(tarea);
                    return;
                }

                JsonNode normalizado = objectMapper.valueToTree(eval);
                tarea.completar(normalizado, r.modelo());
                iaTareaRepository.save(tarea);
                log.info("Evaluación de IA {} completada con éxito (modelo={})", tarea.getId(), r.modelo());

            } else if (tipo == TipoTareaIa.CHAT) {
                ResultadoTareaIa.ResultadoChat chat = objectMapper.treeToValue(
                        r.resultado(), ResultadoTareaIa.ResultadoChat.class
                );
                if (chat == null || chat.respuesta() == null || chat.respuesta().isBlank()) {
                    tarea.fallar("RESULTADO_RECHAZADO", "La respuesta del chat no puede estar vacía");
                    iaTareaRepository.save(tarea);
                    return;
                }

                JsonNode normalizado = objectMapper.valueToTree(chat);
                tarea.completar(normalizado, r.modelo());
                iaTareaRepository.save(tarea);
                log.info("Chat de IA {} completado con éxito (modelo={})", tarea.getId(), r.modelo());

            } else if (tipo == TipoTareaIa.AUTOCOMPLETAR) {
                JsonNode normalizado = normalizarAutocompletado(tarea, r.resultado());
                tarea.completar(normalizado, r.modelo());
                iaTareaRepository.save(tarea);
                log.info("Autocompletado de IA {} completado con éxito", tarea.getId());
            }
        } catch (Exception ex) {
            log.warn("Error al deserializar/validar resultado de tarea IA {}: {}", tarea.getId(), ex.getMessage());
            tarea.fallar("RESULTADO_RECHAZADO", "Error de validación: " + ex.getMessage());
            iaTareaRepository.save(tarea);
        }
    }

    private JsonNode normalizarAutocompletado(IaTarea tarea, JsonNode raw) {
        if (raw == null || !raw.isObject()) {
            throw new IllegalArgumentException("El resultado de autocompletado debe ser un objeto JSON");
        }

        List<FieldDefinition> fieldDefs = (tarea.getPlantillaVersion() != null && tarea.getPlantillaVersion().getEsquemaCampos() != null)
                ? schemaBuilder.parseFields(tarea.getPlantillaVersion().getEsquemaCampos())
                : List.of();

        Map<String, FieldDefinition> defsMap = new LinkedHashMap<>();
        for (FieldDefinition def : fieldDefs) {
            defsMap.put(def.key(), def);
        }

        ObjectNode normalizado = objectMapper.createObjectNode();
        ObjectNode sugerenciasNormalizadas = normalizado.putObject("sugerencias");
        Set<String> noEncontrados = new LinkedHashSet<>();

        JsonNode sugerenciasNode = raw.get("sugerencias");
        if (sugerenciasNode != null && sugerenciasNode.isObject()) {
            sugerenciasNode.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                JsonNode sug = entry.getValue();
                if (!defsMap.containsKey(key)) {
                    // Se descartan las claves que no existen en el esquema (§6.9)
                    return;
                }
                FieldDefinition def = defsMap.get(key);
                JsonNode valorNode = sug != null ? sug.get("valor") : null;
                Object valorObj = valorNode != null && !valorNode.isNull()
                        ? objectMapper.convertValue(valorNode, Object.class)
                        : null;

                List<FieldValidationError> errors = (valorObj != null)
                        ? schemaBuilder.validateData(List.of(def), Map.of(key, valorObj))
                        : List.of(new FieldValidationError(key, "Valor nulo", null));

                if (errors.isEmpty()) {
                    sugerenciasNormalizadas.set(key, sug);
                } else {
                    // Si no es válido, la clave pasa a noEncontrados (§6.9)
                    noEncontrados.add(key);
                }
            });
        }

        JsonNode rawNoEncontrados = raw.get("noEncontrados");
        if (rawNoEncontrados != null && rawNoEncontrados.isArray()) {
            for (JsonNode item : rawNoEncontrados) {
                String key = item.asText();
                if (defsMap.containsKey(key) && !sugerenciasNormalizadas.has(key)) {
                    noEncontrados.add(key);
                }
            }
        }

        // Las claves del esquema sin propuesta se agregan a noEncontrados (§6.9 / CA 03.5)
        for (String key : defsMap.keySet()) {
            if (!sugerenciasNormalizadas.has(key)) {
                noEncontrados.add(key);
            }
        }

        ArrayNode noEncontradosArray = normalizado.putArray("noEncontrados");
        noEncontrados.forEach(noEncontradosArray::add);

        return normalizado;
    }
}
