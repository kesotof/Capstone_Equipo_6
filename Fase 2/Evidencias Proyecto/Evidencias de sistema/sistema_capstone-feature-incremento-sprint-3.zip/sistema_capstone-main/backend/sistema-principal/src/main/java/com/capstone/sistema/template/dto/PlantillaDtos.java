package com.capstone.sistema.template.dto;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PlantillaDtos {

    public record PlantillaSummaryDto(
            Long id,
            String nombre,
            String descripcion,
            Long tipoDocumentoId,
            String tipoDocumentoNombre,
            Long areaId,
            String areaNombre,
            boolean activo,
            long version, // lock_version
            Integer versionVigente,
            Instant createdAt,
            Instant updatedAt, // último cambio: datos de la plantilla o publicación de su versión vigente
            long usos // documentos generados con cualquiera de sus versiones
    ) {}

    public record PlantillaDetailDto(
            Long id,
            String nombre,
            String descripcion,
            Long tipoDocumentoId,
            String tipoDocumentoNombre,
            Long areaId,
            String areaNombre,
            boolean activo,
            long version, // lock_version
            Integer versionVigente,
            List<FieldDefinition> camposVigentes,
            String esquemaCamposVigente,
            List<PlantillaVersionDto> versiones,
            Instant createdAt,
            Instant updatedAt
    ) {}

    public record PlantillaVersionDto(
            Long id,
            Long plantillaId,
            int version,
            String storageKey,
            String checksumSha256,
            String esquemaCampos,
            List<FieldDefinition> campos,
            UUID creadoPorId,
            String creadoPorNombre,
            Instant createdAt,
            long usos // documentos generados con esta versión
    ) {}

    public record CrearPlantillaRequest(
            String nombre,
            String descripcion,
            Long tipoDocumentoId,
            Long areaId, // null = global
            List<FieldDefinition> campos
    ) {}

    public record ActualizarPlantillaRequest(
            String nombre,
            String descripcion,
            Long tipoDocumentoId,
            Long areaId,
            Long version // lock_version
    ) {}

    public record StatusPlantillaRequest(
            boolean activo
    ) {}

    public record FormularioPlantillaDto(
            Long plantillaId,
            int version,
            String nombre,
            Long tipoDocumentoId,
            String tipoDocumentoNombre,
            List<FieldDefinition> campos,
            String jsonSchema
    ) {}

    public record VistaPreviaRequest(
            Map<String, Object> datos,
            Integer version // versión de la plantilla (opcional); sin ella se usa la vigente
    ) {}

    public record CrearSolicitudDesdePlantillaRequest(
            Long plantillaId,
            Integer plantillaVersion, // versión con la que se completó el formulario (opcional)
            Long flujoId,
            String titulo,
            String descripcion,
            Map<String, Object> datos,
            UUID autocompletadoId
    ) {
        public CrearSolicitudDesdePlantillaRequest(Long plantillaId, Long flujoId, String titulo, String descripcion, Map<String, Object> datos) {
            this(plantillaId, null, flujoId, titulo, descripcion, datos, null);
        }

        public CrearSolicitudDesdePlantillaRequest(Long plantillaId, Integer plantillaVersion, Long flujoId, String titulo, String descripcion, Map<String, Object> datos) {
            this(plantillaId, plantillaVersion, flujoId, titulo, descripcion, datos, null);
        }

        public CrearSolicitudDesdePlantillaRequest(Long plantillaId, Long flujoId, String titulo, String descripcion, Map<String, Object> datos, UUID autocompletadoId) {
            this(plantillaId, null, flujoId, titulo, descripcion, datos, autocompletadoId);
        }
    }

    /** Estado de una tarea de autocompletado con IA; {@code noIdentificados} son las claves sin sugerencia. */
    public record AutocompletadoIaDto(
            UUID id,
            String estado,
            String nombreArchivo,
            Map<String, Object> sugerencias,
            List<String> noIdentificados,
            String mensaje,
            String modeloUsado,
            Instant createdAt,
            Instant completedAt
    ) {}

    /** DOCX del editor de plantillas: su vista HTML y sus marcadores; {@code archivo} (Base64) solo si el backend lo modificó. */
    public record DocumentoPlantillaDto(
            String archivo,
            String html,
            PlaceholderAnalysisResult analisis
    ) {}

    /** Texto del DOCX a convertir en {{clave}}: una selección (párrafo, inicio, fin) o, con {@code todas}, cada aparición. */
    public record ConversionTexto(
            String parrafo,
            Integer inicio,
            Integer fin,
            String texto,
            String clave,
            boolean todas
    ) {}

    /** Tarea de la IA que sugiere qué textos del DOCX convertir en campos; {@code sugerencias} llega al completarse. */
    public record SugerenciasCamposDto(
            UUID id,
            String estado,
            List<?> sugerencias,
            String modelo,
            String mensaje,
            Instant createdAt
    ) {}

    /** Borrador del editor de plantillas; {@code datos} (el estado del editor) solo viene al abrir uno. */
    public record BorradorPlantillaDto(
            UUID id,
            Long plantillaId,
            String plantillaNombre,
            Integer versionBase,
            String nombre,
            String nombreArchivo,
            JsonNode datos,
            Instant createdAt,
            Instant updatedAt
    ) {}

    public record CorregirSolicitudDesdePlantillaRequest(
            Map<String, Object> datos,
            String comentario,
            Long version, // lock_version de la solicitud
            UUID autocompletadoId,
            String titulo, // opcional, como al reenviar con archivo
            String descripcion // opcional, como al reenviar con archivo
    ) {
        public CorregirSolicitudDesdePlantillaRequest(Map<String, Object> datos, String comentario, Long version) {
            this(datos, comentario, version, null, null, null);
        }
    }
}
