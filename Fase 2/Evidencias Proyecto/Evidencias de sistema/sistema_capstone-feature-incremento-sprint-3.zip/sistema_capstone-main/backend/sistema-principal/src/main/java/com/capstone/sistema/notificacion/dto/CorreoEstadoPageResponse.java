package com.capstone.sistema.notificacion.dto;

import java.util.List;

/** F3 (§7.1): página simple de la bandeja admin de correos (evita serializar Page directo). */
public record CorreoEstadoPageResponse(
        List<CorreoEstadoDto> contenido,
        int pagina,
        int tamano,
        long totalElements,
        int totalPaginas
) {
}
