package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.mensajeria.NotificacionesCorreoProperties;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import com.capstone.sistema.notificacion.model.TipoNotificacion;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import com.capstone.sistema.notificacion.repository.TipoNotificacionRepository;
import com.capstone.sistema.notificacion.service.CorreoNotificacionService;
import com.capstone.sistema.notificacion.service.NotificacionMensajeFactory;
import com.capstone.sistema.notificacion.service.NotificacionService;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.model.view.VRevisorSolicitudRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * F3/US-37 (CA 37.4): DECISION_ADMIN_GLOBAL notifica a los revisores de la etapa origen que el
 * motor capturó, salvo al propio administrador (D-08).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class NotificacionServiceAdminGlobalTest {

    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private TipoNotificacionRepository tipoNotificacionRepository;
    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private RbacAccessService access;
    @Mock
    private FlujoReviewerResolver reviewers;
    @Mock
    private VRevisorSolicitudRepository vRevisorSolicitudRepository;
    @Mock
    private HistorialTransicionRepository historialTransicionRepository;
    @Mock
    private CorreoNotificacionService correos;

    private NotificacionService notificacionService;

    private UserAccount admin;
    private UserAccount revisor1;
    private UserAccount revisor2;
    private Solicitud solicitud;

    @BeforeEach
    void setUp() {
        notificacionService = new NotificacionService(
                notificacionRepository,
                tipoNotificacionRepository,
                access,
                reviewers,
                vRevisorSolicitudRepository,
                userAccountRepository,
                historialTransicionRepository,
                new NotificacionMensajeFactory(),
                correos,
                new NotificacionesCorreoProperties(true)
        );

        admin = usuario("kc-admin", "admin@test.local", "Super", "Admin");
        revisor1 = usuario("kc-r1", "r1@test.local", "Carlos", "Revisor");
        revisor2 = usuario("kc-r2", "r2@test.local", "Ana", "Revisora");

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc");
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        EstadoSolicitud estado = new EstadoSolicitud("PENDIENTE_REVISION", "Pendiente de revisión", 1, false);
        solicitud = new Solicitud(flujo, admin, "Documento Prueba", "Desc", estado, etapa);
        ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());
        ReflectionTestUtils.setField(solicitud, "correlativo", "CONT-007");

        TipoNotificacion tipo = new TipoNotificacion("DECISION_ADMIN_GLOBAL");
        ReflectionTestUtils.setField(tipo, "id", 8L);
        when(tipoNotificacionRepository.findByTipoIgnoreCase("DECISION_ADMIN_GLOBAL"))
                .thenReturn(Optional.of(tipo));
    }

    private UserAccount usuario(String keycloakId, String email, String nombre, String apellido) {
        UserAccount u = new UserAccount(keycloakId, email, nombre, apellido, true);
        ReflectionTestUtils.setField(u, "id", UUID.randomUUID());
        return u;
    }

    private NotificacionContexto ctx(String accion, UUID actorId) {
        return new NotificacionContexto(
                solicitud.getId(), null, "CONT-007", "Documento Prueba", "PDF",
                "Etapa 1", "Etapa 1", "Super Admin", "Super Admin", actorId,
                null, null, accion);
    }

    @Test
    @DisplayName("[US-37] La notificación de decisión del admin no se envía al propio admin")
    void noNotificaAlPropioAdmin() {
        List<UUID> ids = List.of(admin.getId(), revisor1.getId(), revisor2.getId());
        when(userAccountRepository.findAllById(ids)).thenReturn(List.of(admin, revisor1, revisor2));

        notificacionService.notificarDecisionAdmin(solicitud, ctx("APROBAR", admin.getId()), ids);

        ArgumentCaptor<UUID> destinatarios = ArgumentCaptor.forClass(UUID.class);
        verify(notificacionRepository, times(2)).insertarIgnorandoDedup(
                destinatarios.capture(), any(), any(), any(), any(), any(), any(), any());
        assertThat(destinatarios.getAllValues())
                .containsExactly(revisor1.getId(), revisor2.getId())
                .doesNotContain(admin.getId());
    }

    @Test
    @DisplayName("[US-37] Guarda una notificación por cada revisor restante con el título y mensaje de decisión")
    void guardaUnaNotificacionPorRevisorConMensaje() {
        List<UUID> ids = List.of(revisor1.getId(), revisor2.getId());
        when(userAccountRepository.findAllById(ids)).thenReturn(List.of(revisor1, revisor2));

        notificacionService.notificarDecisionAdmin(solicitud, ctx("RECHAZAR", admin.getId()), ids);

        ArgumentCaptor<String> titulos = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> mensajes = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> enlaces = ArgumentCaptor.forClass(String.class);
        verify(notificacionRepository, times(2)).insertarIgnorandoDedup(
                any(UUID.class), any(), any(), any(),
                titulos.capture(), mensajes.capture(), enlaces.capture(), any());

        assertThat(titulos.getAllValues()).allSatisfy(t ->
                assertThat(t).isEqualTo("El administrador decidió sobre CONT-007"));
        assertThat(mensajes.getAllValues()).allSatisfy(m ->
                assertThat(m).contains("Super Admin", "rechazó", "Documento Prueba", "en tu lugar."));
        assertThat(enlaces.getAllValues()).allSatisfy(e ->
                assertThat(e).isEqualTo("/solicitudes/" + solicitud.getId()));
    }

    @Test
    @DisplayName("[US-37] Sin revisores asignados no se guarda ninguna notificación")
    void sinRevisoresNoGuardaNotificaciones() {
        notificacionService.notificarDecisionAdmin(solicitud, ctx("APROBAR", admin.getId()), List.of());

        verify(notificacionRepository, never()).insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any());
        verify(userAccountRepository, never()).findAllById(anyList());
    }
}
