package com.capstone.sistema.template.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Plantilla;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.PlantillaRepository;
import com.capstone.sistema.doc.repository.PlantillaVersionRepository;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldType;
import com.capstone.sistema.template.dto.PlaceholderAnalysisResult;
import com.capstone.sistema.template.dto.PlantillaDtos.*;
import com.capstone.sistema.template.render.DocxVista;
import com.capstone.sistema.template.scanner.DocxPlaceholderScanner;
import com.capstone.sistema.template.schema.FieldSchemaBuilder;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import jakarta.persistence.criteria.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.InputStream;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

@Service
@Transactional(readOnly = true)
public class PlantillaService {

    private static final Logger log = LoggerFactory.getLogger(PlantillaService.class);

    // Límites alineados con las columnas de 'plantilla' (nombre 150, descripcion 500).
    private static final int MAX_NOMBRE = 150;
    private static final int MAX_DESCRIPCION = 500;
    private static final int MAX_ETIQUETA = 150;
    private static final int MAX_CLAVE = 100;
    private static final int MAX_SECCION = 80;
    private static final Set<String> OPERACIONES = Set.of("SUMA", "RESTA", "MULTIPLICACION", "PORCENTAJE");
    private static final Set<FieldType> NUMERICOS = EnumSet.of(FieldType.NUMERO, FieldType.MONTO);
    // Mismo juego de caracteres que reconoce DocxPlaceholderScanner en los marcadores {{...}}.
    private static final Pattern CLAVE_CAMPO = Pattern.compile("[a-zA-Z0-9_\\-.]{1," + MAX_CLAVE + "}");

    private final PlantillaRepository plantillaRepository;
    private final PlantillaVersionRepository plantillaVersionRepository;
    private final DocumentoRepository documentoRepository;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final AreaRepository areaRepository;
    private final MinioStorageService minioStorageService;
    private final DocxPlaceholderScanner scanner;
    private final FieldSchemaBuilder schemaBuilder;
    private final RbacAccessService rbacAccessService;
    private final AuditService auditService;
    private final DocxVista docxVista;

    public PlantillaService(
            PlantillaRepository plantillaRepository,
            PlantillaVersionRepository plantillaVersionRepository,
            DocumentoRepository documentoRepository,
            TipoDocumentoRepository tipoDocumentoRepository,
            AreaRepository areaRepository,
            MinioStorageService minioStorageService,
            DocxPlaceholderScanner scanner,
            FieldSchemaBuilder schemaBuilder,
            RbacAccessService rbacAccessService,
            AuditService auditService,
            DocxVista docxVista
    ) {
        this.plantillaRepository = plantillaRepository;
        this.plantillaVersionRepository = plantillaVersionRepository;
        this.documentoRepository = documentoRepository;
        this.tipoDocumentoRepository = tipoDocumentoRepository;
        this.areaRepository = areaRepository;
        this.minioStorageService = minioStorageService;
        this.scanner = scanner;
        this.schemaBuilder = schemaBuilder;
        this.rbacAccessService = rbacAccessService;
        this.auditService = auditService;
        this.docxVista = docxVista;
    }

    /**
     * Analiza un archivo DOCX y retorna los marcadores y campos sugeridos.
     */
    public PlaceholderAnalysisResult analizar(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) de la plantilla.");
        }
        return escanear(leerArchivo(file));
    }

    /** Vista HTML del DOCX y sus marcadores, para mostrar el documento en el editor de plantillas. */
    public DocumentoPlantillaDto vistaDocumento(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) de la plantilla.");
        }
        return documento(leerArchivo(file), false);
    }

    /** Quita del DOCX los marcadores de campos eliminados y devuelve el archivo modificado junto con su vista. */
    public DocumentoPlantillaDto quitarMarcadores(MultipartFile file, List<String> claves) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) de la plantilla.");
        }
        if (claves == null || claves.isEmpty() || claves.size() > 50 || claves.stream().anyMatch(c -> c == null || !CLAVE_CAMPO.matcher(c).matches())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La clave del campo no es válida.");
        }
        byte[] docxBytes = leerArchivo(file);
        escanear(docxBytes);
        try {
            return documento(docxVista.quitar(docxBytes, claves), true);
        } catch (Exception e) {
            log.warn("No se pudo quitar el marcador del DOCX: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible quitar el espacio del documento. Intente de nuevo.");
        }
    }

    /** Convierte textos del DOCX en marcadores {{clave}} y devuelve el archivo modificado junto con su vista. */
    public DocumentoPlantillaDto convertirDocumento(MultipartFile file, List<ConversionTexto> conversiones) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) de la plantilla.");
        }
        if (conversiones == null || conversiones.isEmpty() || conversiones.size() > 50) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Indique entre 1 y 50 textos para convertir en campos.");
        }
        for (ConversionTexto c : conversiones) {
            if (c == null || c.clave() == null || !CLAVE_CAMPO.matcher(c.clave()).matches()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "La clave del campo debe tener entre 1 y " + MAX_CLAVE + " caracteres y usar solo letras, números, '_', '-' o '.'.");
            }
            if (c.texto() == null || c.texto().isBlank() || c.texto().length() > MAX_DESCRIPCION) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Seleccione un texto de hasta " + MAX_DESCRIPCION + " caracteres.");
            }
        }
        byte[] docxBytes = leerArchivo(file);
        escanear(docxBytes);
        try {
            return documento(docxVista.convertir(docxBytes, conversiones), true);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            log.warn("No se pudo convertir el texto del DOCX: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible convertir el texto en campo. Intente de nuevo o seleccione otro texto.");
        }
    }

    /**
     * Crea una nueva plantilla y publica su versión 1.
     */
    @Transactional
    public PlantillaDetailDto crearPlantilla(CrearPlantillaRequest req, MultipartFile file, UserAccount actor) {
        String nombre = normalizarNombre(req.nombre());
        String descripcion = normalizarDescripcion(req.descripcion());
        if (req.tipoDocumentoId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El tipo de documento es obligatorio.");
        }
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El archivo DOCX de la plantilla es obligatorio.");
        }

        validarPermisoCrear(actor, req.areaId());

        if (plantillaRepository.existsByNombreIgnoreCase(nombre)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ya existe una plantilla con el nombre '" + nombre + "'.");
        }

        TipoDocumento tipoDoc = tipoDocumentoRepository.findById(req.tipoDocumentoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tipo de documento no encontrado."));

        Area area = null;
        if (req.areaId() != null) {
            area = areaRepository.findById(req.areaId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Área corporativa no encontrada."));
        }

        // Se valida el DOCX y los campos antes de guardar nada en BD o MinIO.
        byte[] docxBytes = leerArchivo(file);
        List<FieldDefinition> campos = resolverCampos(req.campos(), docxBytes);

        Plantilla plantilla = new Plantilla(nombre, descripcion, tipoDoc, area);
        plantilla = plantillaRepository.saveAndFlush(plantilla);

        String jsonSchema = schemaBuilder.toJsonSchema(plantilla.getNombre(), plantilla.getDescripcion(), campos);

        MinioStorageService.MinioUploadResult uploadResult;
        try {
            uploadResult = minioStorageService.uploadTemplate(plantilla.getId(), 1, file.getOriginalFilename(), docxBytes);
        } catch (Exception e) {
            log.error("Error al almacenar plantilla en MinIO: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al guardar el archivo de la plantilla en el almacenamiento.");
        }

        PlantillaVersion version1 = new PlantillaVersion(
                plantilla,
                1,
                uploadResult.storageKey(),
                uploadResult.checksumSha256(),
                actor
        );
        version1.setEsquemaCampos(jsonSchema);
        version1 = plantillaVersionRepository.saveAndFlush(version1);

        auditService.registerEvent("PLANTILLA_CREADA", actor, "Plantilla creada: " + plantilla.getNombre());
        auditService.registerEvent("PLANTILLA_VERSION_PUBLICADA", actor, "Versión 1 publicada para plantilla: " + plantilla.getNombre());

        return toDetailDto(plantilla, List.of(version1), version1);
    }

    /**
     * Obtiene el detalle de una plantilla por ID.
     */
    public PlantillaDetailDto obtenerPlantilla(Long id, UserAccount actor) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        validarVisibilidadPlantilla(actor, plantilla);

        List<PlantillaVersion> versiones = plantillaVersionRepository.findByPlantilla_IdOrderByVersionDesc(id);
        PlantillaVersion vigente = versiones.isEmpty() ? null : versiones.get(0);

        return toDetailDto(plantilla, versiones, vigente);
    }

    /**
     * Reemplaza los datos de la plantilla sin crear versión. Recibe todos los datos:
     * descripción vacía la quita y areaId null deja la plantilla para toda la organización.
     */
    @Transactional
    public PlantillaDetailDto actualizarPlantilla(Long id, ActualizarPlantillaRequest req, UserAccount actor) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        Long areaActualId = plantilla.getArea() != null ? plantilla.getArea().getId() : null;
        validarPermisoEditar(actor, areaActualId);

        if (req.version() != null && plantilla.getLockVersion() != req.version()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Otra persona modificó la plantilla mientras la editaba. Recárguela y vuelva a aplicar sus cambios.");
        }

        String nombre = normalizarNombre(req.nombre());
        String descripcion = normalizarDescripcion(req.descripcion());
        if (req.tipoDocumentoId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El tipo de documento es obligatorio.");
        }
        if (plantillaRepository.existsByNombreIgnoreCaseAndIdNot(nombre, id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ya existe otra plantilla con el nombre '" + nombre + "'.");
        }

        TipoDocumento tipoDoc = tipoDocumentoRepository.findById(req.tipoDocumentoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tipo de documento no encontrado."));
        Area area = null;
        if (req.areaId() != null) {
            area = areaRepository.findById(req.areaId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Área corporativa no encontrada."));
        }
        // Mover la plantilla de ámbito exige poder editarla también en el ámbito de destino.
        if (!Objects.equals(areaActualId, req.areaId())) {
            validarPermisoEditar(actor, req.areaId());
        }

        plantilla.setNombre(nombre);
        plantilla.setDescripcion(descripcion);
        plantilla.setTipoDocumento(tipoDoc);
        plantilla.setArea(area);

        plantilla = plantillaRepository.saveAndFlush(plantilla);
        auditService.registerEvent("PLANTILLA_EDITADA", actor, "Metadatos editados para plantilla: " + plantilla.getNombre());

        List<PlantillaVersion> versiones = plantillaVersionRepository.findByPlantilla_IdOrderByVersionDesc(id);
        PlantillaVersion vigente = versiones.isEmpty() ? null : versiones.get(0);
        return toDetailDto(plantilla, versiones, vigente);
    }

    /**
     * Activa o desactiva una plantilla.
     */
    @Transactional
    public PlantillaDetailDto cambiarEstado(Long id, boolean activo, UserAccount actor) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        validarPermisoEditar(actor, plantilla.getArea() != null ? plantilla.getArea().getId() : null);

        plantilla.setActivo(activo);
        plantilla = plantillaRepository.saveAndFlush(plantilla);

        String evento = activo ? "PLANTILLA_ACTIVADA" : "PLANTILLA_DESACTIVADA";
        auditService.registerEvent(evento, actor, "Plantilla " + plantilla.getNombre() + (activo ? " activada" : " desactivada"));

        List<PlantillaVersion> versiones = plantillaVersionRepository.findByPlantilla_IdOrderByVersionDesc(id);
        PlantillaVersion vigente = versiones.isEmpty() ? null : versiones.get(0);
        return toDetailDto(plantilla, versiones, vigente);
    }

    /**
     * Publica una nueva versión de la plantilla. Sin archivo, la versión nueva reutiliza el DOCX vigente
     * y solo cambian los campos. versionBase (opcional) es la versión con la que se abrió el editor:
     * si ya no es la vigente responde 409 para no pisar una versión publicada por otra persona.
     */
    @Transactional
    public PlantillaDetailDto publicarNuevaVersion(Long id, List<FieldDefinition> campos, MultipartFile file,
                                                   Integer versionBase, UserAccount actor) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        validarPermisoEditar(actor, plantilla.getArea() != null ? plantilla.getArea().getId() : null);

        List<PlantillaVersion> versionesExistentes = plantillaVersionRepository.findByPlantilla_IdOrderByVersionDesc(id);
        PlantillaVersion vigente = versionesExistentes.isEmpty() ? null : versionesExistentes.get(0);
        if (versionBase != null && vigente != null && vigente.getVersion() != versionBase) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Mientras editaba se publicó la versión " + vigente.getVersion()
                    + " de la plantilla. Recárguela y vuelva a aplicar sus cambios.");
        }
        int nuevaVersionNum = vigente == null ? 1 : vigente.getVersion() + 1;

        boolean archivoNuevo = file != null && !file.isEmpty();
        byte[] docxBytes;
        String nombreArchivo;
        if (archivoNuevo) {
            docxBytes = leerArchivo(file);
            nombreArchivo = file.getOriginalFilename();
        } else {
            if (vigente == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) para publicar la plantilla.");
            }
            if (campos == null || campos.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Indique los campos de la nueva versión o reemplace el documento Word.");
            }
            docxBytes = descargar(vigente.getStorageKey());
            nombreArchivo = vigente.getStorageKey().substring(vigente.getStorageKey().lastIndexOf('/') + 1);
        }

        campos = resolverCampos(campos, docxBytes);
        if (!archivoNuevo && campos.equals(schemaBuilder.parseFields(vigente.getEsquemaCampos()))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "La nueva versión no tiene cambios. Modifique los campos o reemplace el documento Word.");
        }

        String jsonSchema = schemaBuilder.toJsonSchema(plantilla.getNombre(), plantilla.getDescripcion(), campos);

        MinioStorageService.MinioUploadResult uploadResult;
        try {
            uploadResult = minioStorageService.uploadTemplate(plantilla.getId(), nuevaVersionNum, nombreArchivo, docxBytes);
        } catch (Exception e) {
            log.error("Error al almacenar nueva versión de plantilla en MinIO: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al guardar el archivo de la plantilla en el almacenamiento.");
        }

        PlantillaVersion nuevaVersion = new PlantillaVersion(
                plantilla,
                nuevaVersionNum,
                uploadResult.storageKey(),
                uploadResult.checksumSha256(),
                actor
        );
        nuevaVersion.setEsquemaCampos(jsonSchema);
        nuevaVersion = plantillaVersionRepository.saveAndFlush(nuevaVersion);

        auditService.registerEvent("PLANTILLA_VERSION_PUBLICADA", actor, "Versión " + nuevaVersionNum + " publicada para plantilla: " + plantilla.getNombre());

        List<PlantillaVersion> todas = new ArrayList<>();
        todas.add(nuevaVersion);
        todas.addAll(versionesExistentes);

        return toDetailDto(plantilla, todas, nuevaVersion);
    }

    /**
     * Elimina una plantilla si no ha sido usada en ningún documento.
     * Regla de negocio crítica: Una plantilla usada solo puede ser desactivada (HTTP 409).
     */
    @Transactional
    public void eliminarPlantilla(Long id, UserAccount actor) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        validarPermisoEliminar(actor, plantilla.getArea() != null ? plantilla.getArea().getId() : null);

        // Validar si existe algún documento generado a partir de esta plantilla
        boolean enUso = documentoRepository.existsByPlantillaVersion_Plantilla_Id(id);
        if (enUso) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "La plantilla no puede ser eliminada porque ya ha sido utilizada en solicitudes emitidas. Solo puede ser desactivada."
            );
        }

        String nombre = plantilla.getNombre();
        plantillaRepository.delete(plantilla);
        auditService.registerEvent("PLANTILLA_ELIMINADA", actor, "Plantilla eliminada: " + nombre);
    }

    /**
     * Obtiene el formulario (definiciones de campos y JSON Schema) de la versión activa de la plantilla.
     */
    public FormularioPlantillaDto obtenerFormulario(Long id) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));

        if (!plantilla.isActivo()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "La plantilla se encuentra desactivada.");
        }

        PlantillaVersion vigente = plantillaVersionRepository.findFirstByPlantilla_IdOrderByVersionDesc(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La plantilla no tiene versiones publicadas."));

        List<FieldDefinition> campos = schemaBuilder.parseFields(vigente.getEsquemaCampos());

        return new FormularioPlantillaDto(
                plantilla.getId(),
                vigente.getVersion(),
                plantilla.getNombre(),
                plantilla.getTipoDocumento().getId(),
                plantilla.getTipoDocumento().getNombre(),
                campos,
                vigente.getEsquemaCampos()
        );
    }

    /**
     * Descarga el archivo DOCX original de una versión de plantilla.
     */
    public byte[] obtenerArchivoVersion(Long id, Integer versionNum) {
        PlantillaVersion version;
        if (versionNum != null) {
            version = plantillaVersionRepository.findByPlantilla_IdAndVersion(id, versionNum)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Versión " + versionNum + " de la plantilla no encontrada."));
        } else {
            version = plantillaVersionRepository.findFirstByPlantilla_IdOrderByVersionDesc(id)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Versión de plantilla no encontrada."));
        }

        return descargar(version.getStorageKey());
    }

    /**
     * Lista plantillas activas disponibles para emisión por parte del usuario.
     */
    public List<PlantillaSummaryDto> listarDisponibles(Long tipoDocumentoId, UserAccount user) {
        List<Plantilla> list;
        if (user != null && user.getArea() != null) {
            list = plantillaRepository.findDisponiblesParaUsuario(user.getArea().getId(), tipoDocumentoId);
        } else {
            list = plantillaRepository.findDisponiblesGlobales(tipoDocumentoId);
        }

        return list.stream()
                .map(this::toSummaryDto)
                .toList();
    }

    /**
     * Listado paginado de plantillas con filtros y búsqueda.
     */
    public Page<PlantillaSummaryDto> listar(Pageable pageable, String q, Long areaId, Long tipoDocId, Boolean activo) {
        Specification<Plantilla> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (q != null && !q.isBlank()) {
                String pattern = "%" + q.trim().toLowerCase(Locale.ROOT) + "%";
                predicates.add(cb.or(
                        cb.like(cb.lower(root.get("nombre")), pattern),
                        cb.like(cb.lower(root.get("descripcion")), pattern)
                ));
            }

            if (areaId != null) {
                predicates.add(cb.equal(root.get("area").get("id"), areaId));
            }

            if (tipoDocId != null) {
                predicates.add(cb.equal(root.get("tipoDocumento").get("id"), tipoDocId));
            }

            if (activo != null) {
                predicates.add(cb.equal(root.get("activo"), activo));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        return plantillaRepository.findAll(spec, pageable)
                .map(this::toSummaryDto);
    }

    public PlantillaVersion obtenerVersionVigente(Long plantillaId) {
        return plantillaVersionRepository.findFirstByPlantilla_IdOrderByVersionDesc(plantillaId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La plantilla no tiene versiones publicadas."));
    }

    public PlantillaVersion obtenerVersion(Long plantillaId, int version) {
        return plantillaVersionRepository.findByPlantilla_IdAndVersion(plantillaId, version)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Versión " + version + " de la plantilla no encontrada."));
    }

    private byte[] leerArchivo(MultipartFile file) {
        try {
            return file.getBytes();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se pudo leer el archivo cargado: " + e.getMessage());
        }
    }

    private byte[] descargar(String storageKey) {
        try (InputStream in = minioStorageService.downloadFile(storageKey)) {
            return in.readAllBytes();
        } catch (Exception e) {
            log.error("Error al descargar archivo de plantilla desde MinIO: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "No se pudo recuperar el archivo de la plantilla desde el almacenamiento.");
        }
    }

    private PlaceholderAnalysisResult escanear(byte[] docxBytes) {
        try {
            return scanner.scan(docxBytes);
        } catch (Exception e) {
            log.warn("Fallo al analizar archivo DOCX: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "No se pudo leer el documento Word. Revise que sea un archivo .docx que se abra bien en Word e intente de nuevo.");
        }
    }

    private DocumentoPlantillaDto documento(byte[] docxBytes, boolean conArchivo) {
        PlaceholderAnalysisResult analisis = escanear(docxBytes);
        try {
            return new DocumentoPlantillaDto(conArchivo ? Base64.getEncoder().encodeToString(docxBytes) : null, docxVista.html(docxBytes), analisis);
        } catch (Exception e) {
            log.warn("No se pudo armar la vista del DOCX: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "No fue posible mostrar el documento Word. Revise que se abra bien en Word e intente de nuevo.");
        }
    }

    /**
     * Usa los campos recibidos o, si no vienen, los sugeridos por el escáner; en ambos casos los valida.
     * El escaneo se hace siempre para rechazar archivos que no son DOCX válidos.
     */
    private List<FieldDefinition> resolverCampos(List<FieldDefinition> campos, byte[] docxBytes) {
        PlaceholderAnalysisResult analysis = escanear(docxBytes);
        return normalizarCampos(campos == null || campos.isEmpty() ? analysis.camposSugeridos() : campos);
    }

    /**
     * Valida la definición de campos (información mínima de la plantilla) y la devuelve
     * ordenada con 'orden' 1..n. Reúne todos los problemas en un único 400.
     */
    private List<FieldDefinition> normalizarCampos(List<FieldDefinition> campos) {
        if (campos == null || campos.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "La plantilla debe tener al menos un campo. Créelos en el paso «Campos» del editor.");
        }

        List<FieldDefinition> ordenados = new ArrayList<>(campos);
        ordenados.sort(Comparator.nullsLast(Comparator.comparingInt(FieldDefinition::orden)));

        List<String> errores = new ArrayList<>();
        Set<String> claves = new HashSet<>();
        List<FieldDefinition> normalizados = new ArrayList<>();
        for (int i = 0; i < ordenados.size(); i++) {
            FieldDefinition f = ordenados.get(i);
            if (f == null) {
                errores.add("Campo " + (i + 1) + ": la definición está vacía.");
                continue;
            }
            String clave = f.key() == null ? "" : f.key().trim();
            String etiqueta = f.label() == null ? "" : f.label().trim();
            String ref = etiqueta.isEmpty() ? "Campo " + (i + 1) : "Campo '" + etiqueta + "'";

            if (!CLAVE_CAMPO.matcher(clave).matches()) {
                errores.add(ref + ": la clave debe tener entre 1 y " + MAX_CLAVE + " caracteres y usar solo letras, números, '_', '-' o '.'.");
            } else if (!claves.add(clave)) {
                errores.add(ref + ": la clave '" + clave + "' está repetida.");
            }
            if (etiqueta.isEmpty()) {
                errores.add(ref + ": la etiqueta es obligatoria.");
            } else if (etiqueta.length() > MAX_ETIQUETA) {
                errores.add(ref + ": la etiqueta no puede superar los " + MAX_ETIQUETA + " caracteres.");
            }
            if (f.tipo() == null) {
                errores.add(ref + ": el tipo de campo es obligatorio.");
            }
            String ayuda = f.descripcion() == null || f.descripcion().isBlank() ? null : f.descripcion().trim();
            if (ayuda != null && ayuda.length() > MAX_DESCRIPCION) {
                errores.add(ref + ": la ayuda no puede superar los " + MAX_DESCRIPCION + " caracteres.");
            }

            List<String> opciones = List.of();
            if (f.tipo() == FieldType.SELECCION) {
                opciones = f.opciones().stream().map(o -> o == null ? "" : o.trim()).toList();
                if (opciones.isEmpty()) {
                    errores.add(ref + ": la lista de opciones necesita al menos una opción.");
                } else if (opciones.contains("")) {
                    errores.add(ref + ": hay opciones vacías.");
                } else if (new HashSet<>(opciones).size() != opciones.size()) {
                    errores.add(ref + ": hay opciones repetidas.");
                }
            }

            String seccion = f.seccion() == null || f.seccion().isBlank() ? null : f.seccion().trim();
            if (seccion != null && seccion.length() > MAX_SECCION) {
                errores.add(ref + ": el nombre de la sección no puede superar los " + MAX_SECCION + " caracteres.");
            }

            // Un campo calculado nunca lo completa una persona, así que no puede ser obligatorio.
            normalizados.add(new FieldDefinition(clave, etiqueta, f.tipo(), f.obligatorio() && f.calculo() == null, opciones, i + 1,
                    ayuda, f.valorPorDefecto(), seccion, f.condicion(), f.calculo()));
        }
        errores.addAll(validarReglas(normalizados));

        if (!errores.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Revise los campos de la plantilla. " + String.join(" ", errores));
        }
        return normalizados;
    }

    /** Condiciones y cálculos solo pueden usar campos anteriores en el formulario: así nunca forman ciclos. */
    private List<String> validarReglas(List<FieldDefinition> campos) {
        List<String> errores = new ArrayList<>();
        Map<String, FieldDefinition> anteriores = new HashMap<>();
        for (FieldDefinition f : campos) {
            String ref = "Campo '" + f.label() + "'";
            FieldDefinition.Condicion condicion = f.condicion();
            if (condicion != null) {
                FieldDefinition origen = anteriores.get(condicion.campo());
                if (origen == null || (origen.tipo() != FieldType.BOOLEANO && origen.tipo() != FieldType.SELECCION)) {
                    errores.add(ref + ": la condición debe usar un campo Sí/No o de lista de opciones que esté antes en el formulario.");
                } else if (origen.tipo() == FieldType.BOOLEANO
                        ? !List.of("true", "false").contains(condicion.valor()) : !origen.opciones().contains(condicion.valor())) {
                    errores.add(ref + ": el valor de la condición no es una opción de '" + origen.label() + "'.");
                }
            }
            FieldDefinition.Calculo calculo = f.calculo();
            if (calculo != null) {
                List<String> usados = calculo.campos() == null ? List.of() : calculo.campos();
                boolean porcentaje = "PORCENTAJE".equals(calculo.operacion());
                if (!NUMERICOS.contains(f.tipo())) {
                    errores.add(ref + ": solo los campos de número o monto se pueden calcular.");
                } else if (!OPERACIONES.contains(calculo.operacion())) {
                    errores.add(ref + ": la operación del cálculo no es válida.");
                } else if (porcentaje ? usados.size() != 1 || calculo.factor() == null : usados.size() < 2) {
                    errores.add(ref + (porcentaje ? ": el porcentaje necesita un campo base y el % a aplicar." : ": el cálculo necesita al menos dos campos."));
                } else if (usados.stream().anyMatch(u -> anteriores.get(u) == null || !NUMERICOS.contains(anteriores.get(u).tipo()))) {
                    errores.add(ref + ": el cálculo solo puede usar campos de número o monto que estén antes en el formulario.");
                }
            }
            anteriores.put(f.key(), f);
        }
        return errores;
    }

    private String normalizarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El nombre de la plantilla es obligatorio.");
        }
        String valor = nombre.trim();
        if (valor.length() > MAX_NOMBRE) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El nombre de la plantilla no puede superar los " + MAX_NOMBRE + " caracteres.");
        }
        return valor;
    }

    private String normalizarDescripcion(String descripcion) {
        if (descripcion == null || descripcion.isBlank()) {
            return null;
        }
        String valor = descripcion.trim();
        if (valor.length() > MAX_DESCRIPCION) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La descripción de la plantilla no puede superar los " + MAX_DESCRIPCION + " caracteres.");
        }
        return valor;
    }

    /** Configurar plantillas (editor, borradores, sugerencias de la IA): crear o editar en general o en el área propia. */
    public void validarPermisoConfigurar(UserAccount actor) {
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }
        for (String accion : List.of("CREAR", "EDITAR")) {
            if (rbacAccessService.tienePermisoGlobal(actor.getId(), "PLANTILLA", accion)
                    || (actor.getArea() != null && rbacAccessService.tienePermiso(actor.getId(), "PLANTILLA", accion, actor.getArea().getId()))) {
                return;
            }
        }
        throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para configurar plantillas.");
    }

    /**
     * C6: Obtiene la versión vigente de la plantilla validando que esté activa y disponible para el usuario.
     * Reutiliza exactamente el mismo criterio de disponibilidad que listarDisponibles.
     * Si está inactiva o no disponible, lanza 404 NOT_FOUND.
     */
    public PlantillaVersion obtenerVersionVigenteDisponible(Long plantillaId, UserAccount usuario) {
        if (plantillaId == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada: id nulo.");
        }
        Plantilla plantilla = plantillaRepository.findById(plantillaId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada: " + plantillaId));

        if (!plantilla.isActivo()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no disponible o inactiva: " + plantillaId);
        }

        boolean disponible = listarDisponibles(null, usuario).stream()
                .anyMatch(dto -> dto.id().equals(plantillaId));

        if (!disponible) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no disponible para el usuario: " + plantillaId);
        }

        return obtenerVersionVigente(plantillaId);
    }

    private void validarPermisoCrear(UserAccount actor, Long areaId) {
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }
        if (areaId == null) {
            if (!rbacAccessService.tienePermisoGlobal(actor.getId(), "PLANTILLA", "CREAR")) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para crear plantillas globales.");
            }
        } else {
            if (!rbacAccessService.tienePermiso(actor.getId(), "PLANTILLA", "CREAR", areaId)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para crear plantillas en el área seleccionada.");
            }
        }
    }

    private void validarPermisoEditar(UserAccount actor, Long areaId) {
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }
        if (areaId == null) {
            if (!rbacAccessService.tienePermisoGlobal(actor.getId(), "PLANTILLA", "EDITAR")) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para editar plantillas globales.");
            }
        } else {
            if (!rbacAccessService.tienePermiso(actor.getId(), "PLANTILLA", "EDITAR", areaId)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para editar plantillas en esta área.");
            }
        }
    }

    private void validarPermisoEliminar(UserAccount actor, Long areaId) {
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }
        if (areaId == null) {
            if (!rbacAccessService.tienePermisoGlobal(actor.getId(), "PLANTILLA", "ELIMINAR")) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para eliminar plantillas globales.");
            }
        } else {
            if (!rbacAccessService.tienePermiso(actor.getId(), "PLANTILLA", "ELIMINAR", areaId)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permisos para eliminar plantillas en esta área.");
            }
        }
    }

    private void validarVisibilidadPlantilla(UserAccount actor, Plantilla plantilla) {
        // Todo usuario puede ver plantillas globales y de su área si está autenticado
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }
    }

    private PlantillaSummaryDto toSummaryDto(Plantilla p) {
        Optional<PlantillaVersion> vig = plantillaVersionRepository.findFirstByPlantilla_IdOrderByVersionDesc(p.getId());
        return new PlantillaSummaryDto(
                p.getId(),
                p.getNombre(),
                p.getDescripcion(),
                p.getTipoDocumento() != null ? p.getTipoDocumento().getId() : null,
                p.getTipoDocumento() != null ? p.getTipoDocumento().getNombre() : null,
                p.getArea() != null ? p.getArea().getId() : null,
                p.getArea() != null ? p.getArea().getNombre() : "Toda la organización",
                p.isActivo(),
                p.getLockVersion(),
                vig.map(PlantillaVersion::getVersion).orElse(null),
                p.getCreatedAt(),
                ultimoCambio(p, vig.orElse(null)),
                documentoRepository.countByPlantillaVersion_Plantilla_Id(p.getId())
        );
    }

    private PlantillaDetailDto toDetailDto(Plantilla p, List<PlantillaVersion> versiones, PlantillaVersion vigente) {
        List<FieldDefinition> camposVigentes = vigente != null ? schemaBuilder.parseFields(vigente.getEsquemaCampos()) : List.of();
        String esquemaVigente = vigente != null ? vigente.getEsquemaCampos() : null;

        List<PlantillaVersionDto> versionDtos = versiones.stream()
                .map(v -> new PlantillaVersionDto(
                        v.getId(),
                        p.getId(),
                        v.getVersion(),
                        v.getStorageKey(),
                        v.getChecksumSha256(),
                        v.getEsquemaCampos(),
                        schemaBuilder.parseFields(v.getEsquemaCampos()),
                        v.getCreadoPor() != null ? v.getCreadoPor().getId() : null,
                        v.getCreadoPor() != null ? v.getCreadoPor().getNombre() : null,
                        v.getCreatedAt(),
                        documentoRepository.countByPlantillaVersion_Id(v.getId())
                ))
                .toList();

        return new PlantillaDetailDto(
                p.getId(),
                p.getNombre(),
                p.getDescripcion(),
                p.getTipoDocumento() != null ? p.getTipoDocumento().getId() : null,
                p.getTipoDocumento() != null ? p.getTipoDocumento().getNombre() : null,
                p.getArea() != null ? p.getArea().getId() : null,
                p.getArea() != null ? p.getArea().getNombre() : "Toda la organización",
                p.isActivo(),
                p.getLockVersion(),
                vigente != null ? vigente.getVersion() : null,
                camposVigentes,
                esquemaVigente,
                versionDtos,
                p.getCreatedAt(),
                ultimoCambio(p, vigente)
        );
    }

    private static Instant ultimoCambio(Plantilla p, PlantillaVersion vigente) {
        return vigente != null && vigente.getCreatedAt() != null && vigente.getCreatedAt().isAfter(p.getUpdatedAt())
                ? vigente.getCreatedAt() : p.getUpdatedAt();
    }
}
