package com.capstone.sistema.notificacion.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "notificacion_envio")
@Immutable
public class NotificacionEnvio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "notificacion_id", nullable = false)
    private Notificacion notificacion;

    @Column(nullable = false, length = 20)
    private String canal = "EMAIL";

    @Column(nullable = false, length = 255)
    private String destino;

    @Column(nullable = false)
    private Integer intento = 1;

    @Column(nullable = false, length = 10)
    private String resultado;

    @Column(name = "error_detalle", length = 2000)
    private String errorDetalle;

    @Column(name = "proveedor_id", length = 255)
    private String proveedorId;

    /** US-35: código de error clasificado del proveedor (§5.2). */
    @Column(name = "codigo_error", length = 50)
    private String codigoError;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected NotificacionEnvio() {
    }

    public NotificacionEnvio(
            Notificacion notificacion,
            String canal,
            String destino,
            Integer intento,
            String resultado,
            String errorDetalle,
            String proveedorId
    ) {
        this.notificacion = notificacion;
        this.canal = canal != null ? canal : "EMAIL";
        this.destino = destino;
        this.intento = intento != null ? intento : 1;
        this.resultado = resultado;
        this.errorDetalle = errorDetalle;
        this.proveedorId = proveedorId;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (canal == null) {
            canal = "EMAIL";
        }
        if (intento == null) {
            intento = 1;
        }
    }

    public Long getId() {
        return id;
    }

    public Notificacion getNotificacion() {
        return notificacion;
    }

    public String getCanal() {
        return canal;
    }

    public String getDestino() {
        return destino;
    }

    public Integer getIntento() {
        return intento;
    }

    public String getResultado() {
        return resultado;
    }

    public String getErrorDetalle() {
        return errorDetalle;
    }

    public String getProveedorId() {
        return proveedorId;
    }

    public String getCodigoError() {
        return codigoError;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NotificacionEnvio that = (NotificacionEnvio) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
