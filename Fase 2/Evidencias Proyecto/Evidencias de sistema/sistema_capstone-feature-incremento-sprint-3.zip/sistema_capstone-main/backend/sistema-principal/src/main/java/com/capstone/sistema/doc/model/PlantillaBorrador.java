package com.capstone.sistema.doc.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.UUID;

/**
 * Trabajo sin publicar del editor de plantillas. Sin plantilla es una plantilla nueva; con plantilla, la próxima
 * versión de esa plantilla a partir de {@code versionBase}. {@code datos} guarda el estado del editor tal cual.
 */
@Entity
@Table(name = "plantilla_borrador")
public class PlantillaBorrador {

    // El id se asigna aquí porque la ruta del Word en MinIO lo usa antes de guardar la fila.
    @Id
    private UUID id = UUID.randomUUID();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plantilla_id", updatable = false)
    private Plantilla plantilla;

    @Column(name = "version_base")
    private Integer versionBase;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false, updatable = false)
    private UserAccount usuario;

    @Column(nullable = false, length = 150)
    private String nombre;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(nullable = false, columnDefinition = "jsonb")
    private String datos;

    @Column(name = "nombre_archivo", nullable = false, length = 255)
    private String nombreArchivo;

    @Column(name = "storage_key", nullable = false, length = 500)
    private String storageKey;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected PlantillaBorrador() {
    }

    public PlantillaBorrador(Plantilla plantilla, Integer versionBase, UserAccount usuario) {
        this.plantilla = plantilla;
        this.versionBase = versionBase;
        this.usuario = usuario;
    }

    @PrePersist
    void onPrePersist() {
        createdAt = Instant.now();
        updatedAt = createdAt;
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    /** Marca el guardado aunque solo haya cambiado el Word (que no está en la fila). */
    public void marcarGuardado() {
        updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public Plantilla getPlantilla() {
        return plantilla;
    }

    public Integer getVersionBase() {
        return versionBase;
    }

    public void setVersionBase(Integer versionBase) {
        this.versionBase = versionBase;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDatos() {
        return datos;
    }

    public void setDatos(String datos) {
        this.datos = datos;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public void setStorageKey(String storageKey) {
        this.storageKey = storageKey;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
