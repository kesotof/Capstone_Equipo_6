package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.HistorialTransicion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.UUID;

public interface HistorialTransicionRepository extends JpaRepository<HistorialTransicion, Long>, JpaSpecificationExecutor<HistorialTransicion> {

    List<HistorialTransicion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId);

    List<HistorialTransicion> findBySolicitud_IdOrderByCreatedAtAscIdAsc(UUID solicitudId);
}
