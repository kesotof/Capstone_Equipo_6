package com.capstone.sistema.flow.exception;

public class FlujoNotFoundException extends RuntimeException {
    public FlujoNotFoundException() {
        super("Flujo no encontrado");
    }

    public FlujoNotFoundException(String message) {
        super(message);
    }
}
