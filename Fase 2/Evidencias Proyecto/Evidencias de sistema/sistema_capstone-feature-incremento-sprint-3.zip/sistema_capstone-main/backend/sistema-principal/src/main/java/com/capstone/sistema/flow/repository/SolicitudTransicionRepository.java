package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.SolicitudTransicion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class SolicitudTransicionRepository {

    private final HistorialTransicionRepository historialTransicionRepository;

    public SolicitudTransicionRepository() {
        this.historialTransicionRepository = null;
    }

    @Autowired
    public SolicitudTransicionRepository(@Autowired(required = false) HistorialTransicionRepository historialTransicionRepository) {
        this.historialTransicionRepository = historialTransicionRepository;
    }

    public List<SolicitudTransicion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId) {
        return new ArrayList<>();
    }

    public List<SolicitudTransicion> findBySolicitud_IdOrderByCreatedAtAscIdAsc(UUID solicitudId) {
        return new ArrayList<>();
    }

    public long countByDentroSlaTrue() {
        return 0L;
    }

    public long countByDentroSlaFalse() {
        return 0L;
    }

    public long count(Specification<SolicitudTransicion> spec) {
        return 0L;
    }

    public SolicitudTransicion save(SolicitudTransicion transicion) {
        if (transicion.getId() == null) {
            transicion.setId(1L);
        }
        return transicion;
    }

    public Optional<SolicitudTransicion> findById(Long id) {
        return Optional.empty();
    }

    public List<Detalle> consultarDetalle(UUID solicitudId, boolean comentariosVisibles) {
        if (historialTransicionRepository != null) {
            List<HistorialTransicion> list = historialTransicionRepository.findBySolicitud_IdOrderByCreatedAtAscIdAsc(solicitudId);
            return list.stream().map(h -> (Detalle) new DetalleRecord(
                    h.getId(),
                    h.getEstadoOrigen() != null ? h.getEstadoOrigen().getCodigo() : null,
                    h.getEstadoDestino() != null ? h.getEstadoDestino().getCodigo() : null,
                    h.getAccion() != null ? h.getAccion().getCodigo() : null,
                    h.getUsuario() != null ? h.getUsuario().getFirstName() : "",
                    h.getUsuario() != null ? h.getUsuario().getLastName() : "",
                    comentariosVisibles ? h.getObservacion() : null,
                    h.getDentroSla(),
                    h.getCreatedAt(),
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getId() : null,
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getOrden() : null,
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getNombre() : null,
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getId() : null,
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getOrden() : null,
                    h.getFlujoEtapa() != null ? h.getFlujoEtapa().getNombre() : null,
                    h.getMetadata() != null && h.getMetadata().replace(" ", "").contains("\"actuoComoAdmin\":true")
            )).toList();
        }
        return new ArrayList<>();
    }

    private record DetalleRecord(
            Long id,
            String estadoOrigen,
            String estadoDestino,
            String accion,
            String usuarioNombre,
            String usuarioApellido,
            String comentario,
            Boolean dentroSla,
            Instant createdAt,
            Long etapaOrigenId,
            Integer etapaOrigenOrden,
            String etapaOrigenNombre,
            Long etapaDestinoId,
            Integer etapaDestinoOrden,
            String etapaDestinoNombre,
            boolean actuoComoAdmin
    ) implements Detalle {
        @Override public boolean getActuoComoAdmin() { return actuoComoAdmin; }
        @Override public Long getId() { return id; }
        @Override public String getEstadoOrigen() { return estadoOrigen; }
        @Override public String getEstadoDestino() { return estadoDestino; }
        @Override public String getAccion() { return accion; }
        @Override public String getUsuarioNombre() { return usuarioNombre; }
        @Override public String getUsuarioApellido() { return usuarioApellido; }
        @Override public String getComentario() { return comentario; }
        @Override public Boolean getDentroSla() { return dentroSla; }
        @Override public Instant getCreatedAt() { return createdAt; }
        @Override public Long getEtapaOrigenId() { return etapaOrigenId; }
        @Override public Integer getEtapaOrigenOrden() { return etapaOrigenOrden; }
        @Override public String getEtapaOrigenNombre() { return etapaOrigenNombre; }
        @Override public Long getEtapaDestinoId() { return etapaDestinoId; }
        @Override public Integer getEtapaDestinoOrden() { return etapaDestinoOrden; }
        @Override public String getEtapaDestinoNombre() { return etapaDestinoNombre; }
    }

    public interface Detalle {
        Long getId();
        String getEstadoOrigen();
        String getEstadoDestino();
        String getAccion();
        String getUsuarioNombre();
        String getUsuarioApellido();
        String getComentario();
        Boolean getDentroSla();
        Instant getCreatedAt();
        Long getEtapaOrigenId();
        Integer getEtapaOrigenOrden();
        String getEtapaOrigenNombre();
        Long getEtapaDestinoId();
        Integer getEtapaDestinoOrden();
        String getEtapaDestinoNombre();
        default boolean getActuoComoAdmin() { return false; }
    }
}
