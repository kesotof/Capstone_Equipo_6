package com.capstone.sistema.template.service;

import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Plantilla;
import com.capstone.sistema.doc.model.PlantillaBorrador;
import com.capstone.sistema.doc.repository.PlantillaBorradorRepository;
import com.capstone.sistema.doc.repository.PlantillaRepository;
import com.capstone.sistema.template.dto.PlantillaDtos.BorradorPlantillaDto;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Borradores del editor de plantillas: guardan el Word y el estado del editor (campos y datos) para seguir otro día.
 * Cada borrador es de quien lo guardó. Al publicar, el editor lo descarta.
 * shortcut: si se elimina la plantilla, la base borra sus borradores pero sus Word quedan en MinIO; limpiarlos si crece.
 */
@Service
@Transactional(readOnly = true)
public class PlantillaBorradorService {

    private static final Logger log = LoggerFactory.getLogger(PlantillaBorradorService.class);
    private static final int MAX_DATOS = 1_000_000;
    private static final int MAX_NOMBRE = 150;

    private final PlantillaBorradorRepository repository;
    private final PlantillaRepository plantillaRepository;
    private final MinioStorageService storage;
    private final PlantillaService plantillaService;
    private final ObjectMapper objectMapper;

    public PlantillaBorradorService(PlantillaBorradorRepository repository, PlantillaRepository plantillaRepository,
                                    MinioStorageService storage, PlantillaService plantillaService, ObjectMapper objectMapper) {
        this.repository = repository;
        this.plantillaRepository = plantillaRepository;
        this.storage = storage;
        this.plantillaService = plantillaService;
        this.objectMapper = objectMapper;
    }

    public List<BorradorPlantillaDto> listar(UserAccount actor) {
        plantillaService.validarPermisoConfigurar(actor);
        return repository.findByUsuario_IdOrderByUpdatedAtDesc(actor.getId()).stream().map(b -> toDto(b, false)).toList();
    }

    public BorradorPlantillaDto obtener(UUID id, UserAccount actor) {
        return toDto(propio(id, actor), true);
    }

    public byte[] archivo(UUID id, UserAccount actor) {
        PlantillaBorrador borrador = propio(id, actor);
        try (InputStream in = storage.downloadFile(borrador.getStorageKey())) {
            return in.readAllBytes();
        } catch (Exception e) {
            log.error("No se pudo leer el Word del borrador {}: {}", id, e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "No se pudo recuperar el documento del borrador.");
        }
    }

    /**
     * Guarda un borrador: el indicado por id, el que la persona ya tenga para esa plantilla o uno nuevo.
     * El Word es obligatorio la primera vez; después solo se envía si cambió.
     */
    @Transactional
    public BorradorPlantillaDto guardar(UUID id, MultipartFile file, String nombre, String datosJson,
                                        Long plantillaId, Integer versionBase, UserAccount actor) {
        plantillaService.validarPermisoConfigurar(actor);
        PlantillaBorrador borrador;
        if (id != null) {
            borrador = propio(id, actor);
        } else if (plantillaId != null) {
            Plantilla plantilla = plantillaRepository.findById(plantillaId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Plantilla no encontrada."));
            borrador = repository.findByPlantilla_IdAndUsuario_Id(plantillaId, actor.getId())
                    .orElseGet(() -> new PlantillaBorrador(plantilla, versionBase, actor));
        } else {
            borrador = new PlantillaBorrador(null, null, actor);
        }

        boolean conArchivo = file != null && !file.isEmpty();
        if (borrador.getStorageKey() == null && !conArchivo) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word para guardar el borrador.");
        }
        if (conArchivo && (file.getOriginalFilename() == null || !file.getOriginalFilename().toLowerCase(Locale.ROOT).endsWith(".docx"))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El borrador solo admite documentos Word (.docx).");
        }
        borrador.setDatos(validarDatos(datosJson));
        String titulo = nombre == null || nombre.isBlank() ? "Plantilla sin nombre" : nombre.trim();
        borrador.setNombre(titulo.length() > MAX_NOMBRE ? titulo.substring(0, MAX_NOMBRE) : titulo);
        if (versionBase != null && borrador.getPlantilla() != null) {
            borrador.setVersionBase(versionBase);
        }
        borrador.marcarGuardado();

        if (conArchivo) {
            try {
                String key = storage.uploadBorrador(borrador.getId(), file.getBytes()).storageKey();
                if (borrador.getStorageKey() == null) {
                    storage.deleteOnRollback(key);
                }
                borrador.setStorageKey(key);
                borrador.setNombreArchivo(MinioStorageService.cleanFilename(file.getOriginalFilename()));
            } catch (Exception e) {
                log.error("No se pudo guardar el Word del borrador {}: {}", borrador.getId(), e.getMessage());
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "No se pudo guardar el documento del borrador. Intente nuevamente.");
            }
        }
        return toDto(repository.save(borrador), false);
    }

    @Transactional
    public void eliminar(UUID id, UserAccount actor) {
        PlantillaBorrador borrador = propio(id, actor);
        repository.delete(borrador);
        repository.flush();
        try {
            storage.deleteFile(borrador.getStorageKey());
        } catch (Exception e) {
            log.warn("No se pudo eliminar el Word del borrador {}: {}", id, e.getMessage());
        }
    }

    private PlantillaBorrador propio(UUID id, UserAccount actor) {
        plantillaService.validarPermisoConfigurar(actor);
        return repository.findById(id)
                .filter(b -> b.getUsuario().getId().equals(actor.getId()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "El borrador no existe o ya fue descartado."));
    }

    private String validarDatos(String datosJson) {
        if (datosJson == null || datosJson.isBlank() || datosJson.length() > MAX_DATOS) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El contenido del borrador no es válido.");
        }
        try {
            if (!objectMapper.readTree(datosJson).isObject()) {
                throw new IllegalArgumentException();
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El contenido del borrador no es válido.");
        }
        return datosJson;
    }

    private BorradorPlantillaDto toDto(PlantillaBorrador b, boolean conDatos) {
        JsonNode datos = null;
        if (conDatos) {
            try {
                datos = objectMapper.readTree(b.getDatos());
            } catch (Exception e) {
                log.warn("Borrador {} con datos ilegibles: {}", b.getId(), e.getMessage());
            }
        }
        Plantilla plantilla = b.getPlantilla();
        return new BorradorPlantillaDto(b.getId(), plantilla != null ? plantilla.getId() : null,
                plantilla != null ? plantilla.getNombre() : null, b.getVersionBase(), b.getNombre(), b.getNombreArchivo(),
                datos, b.getCreatedAt(), b.getUpdatedAt());
    }
}
