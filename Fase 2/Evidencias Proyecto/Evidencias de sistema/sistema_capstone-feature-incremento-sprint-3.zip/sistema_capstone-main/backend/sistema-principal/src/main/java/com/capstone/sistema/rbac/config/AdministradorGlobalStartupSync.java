package com.capstone.sistema.rbac.config;

import com.capstone.sistema.rbac.service.AdministradorGlobalService;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Reconciliación al arranque del administrador global (decisión D-A / Fase 3).
 *
 * <p>Asigna {@code ADMIN_SISTEMA} a los miembros del rol de realm de Keycloak y lo revoca a quienes ya
 * no pertenecen. Corre <b>después</b> de {@link com.capstone.sistema.users.config.ExistingKeycloakUsersSynchronizer}
 * (que tiene {@code @Order(0)}) para que las cuentas locales ya existan. Si Keycloak no responde registra
 * un {@code warn} y continúa: la sincronización al autenticar cubre el caso.</p>
 */
@Component
@Order(10)
public class AdministradorGlobalStartupSync implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(AdministradorGlobalStartupSync.class);

    private final Keycloak keycloak;
    private final KeycloakAdminProperties properties;
    private final AdministradorGlobalService administradorGlobalService;
    private final UserAccountRepository userAccountRepository;

    public AdministradorGlobalStartupSync(
            Keycloak keycloak,
            KeycloakAdminProperties properties,
            AdministradorGlobalService administradorGlobalService,
            UserAccountRepository userAccountRepository) {
        this.keycloak = keycloak;
        this.properties = properties;
        this.administradorGlobalService = administradorGlobalService;
        this.userAccountRepository = userAccountRepository;
    }

    @Override
    public void run(ApplicationArguments args) {
        Set<String> keycloakIds;
        try {
            keycloakIds = keycloak.realm(properties.targetRealm())
                    .roles().get(administradorGlobalService.keycloakRole())
                    .getUserMembers().stream()
                    .map(UserRepresentation::getId)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
        } catch (RuntimeException error) {
            log.warn("AdministradorGlobalStartupSync: Keycloak no respondió; se omite la reconciliación "
                    + "al arranque (la sincronización al autenticar la cubrirá).");
            return;
        }

        for (String keycloakId : keycloakIds) {
            userAccountRepository.findByKeycloakUserId(keycloakId)
                    .filter(UserAccount::isEnabled)
                    .ifPresent(usuario -> administradorGlobalService.reflejar(usuario, true));
        }

        for (UserAccount usuario : administradorGlobalService.usuariosConAdminGlobal()) {
            if (!keycloakIds.contains(usuario.getKeycloakUserId())) {
                administradorGlobalService.reflejar(usuario, false);
            }
        }

        log.info("AdministradorGlobalStartupSync: {} miembro(s) del rol {} en Keycloak.",
                keycloakIds.size(), administradorGlobalService.keycloakRole());
    }
}
