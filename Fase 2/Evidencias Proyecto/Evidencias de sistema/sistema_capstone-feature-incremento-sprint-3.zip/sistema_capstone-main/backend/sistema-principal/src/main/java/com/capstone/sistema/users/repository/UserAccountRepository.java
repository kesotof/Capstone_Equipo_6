package com.capstone.sistema.users.repository;

import com.capstone.sistema.users.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserAccountRepository extends JpaRepository<UserAccount, UUID> {

    boolean existsByEmailIgnoreCase(String email);

    boolean existsByRut(String rut);

    @org.springframework.data.jpa.repository.Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM UserAccount u WHERE REPLACE(REPLACE(UPPER(u.rut), '.', ''), '-', '') = :rutLimpio")
    boolean existsByRutLimpio(@org.springframework.data.repository.query.Param("rutLimpio") String rutLimpio);

    boolean existsByKeycloakUserId(String keycloakUserId);

    boolean existsByIdAndKeycloakUserIdAndEnabledTrue(UUID id, String keycloakUserId);

    Optional<UserAccount> findByEmailIgnoreCase(String email);

    Optional<UserAccount> findByRut(String rut);

    Optional<UserAccount> findByKeycloakUserId(String keycloakUserId);

    List<UserAccount> findAllByOrderByEmailAsc();

    @org.springframework.data.jpa.repository.Query("SELECT u.area.id, COUNT(u) FROM UserAccount u WHERE u.area.id IN :areaIds GROUP BY u.area.id")
    List<Object[]> countUsersByAreaIds(@org.springframework.data.repository.query.Param("areaIds") List<Long> areaIds);

    List<UserAccount> findByAreaIdOrderByEmailAsc(Long areaId);
}
