package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.AccionTransicion;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.mensajeria.AppProperties;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaProperties;
import com.capstone.sistema.mensajeria.NotificacionesCorreoProperties;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.model.view.VRevisorSolicitud;
import com.capstone.sistema.model.view.VRevisorSolicitudRepository;
import com.capstone.sistema.notificacion.dto.MensajeNotificacion;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import com.capstone.sistema.notificacion.dto.NotificacionResponse;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.notificacion.model.TipoNotificacion;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import com.capstone.sistema.notificacion.repository.TipoNotificacionRepository;
import com.capstone.sistema.notificacion.service.CorreoNotificacionService;
import com.capstone.sistema.notificacion.service.NotificacionMensajeFactory;
import com.capstone.sistema.notificacion.service.NotificacionService;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * F3: núcleo {@code crear} (§6.2), compositores por evento (§6.1), elegibilidad de correo
 * (D3-01) y resistencia a broker caído (CA 09.4). Los textos salen de la fábrica del catálogo.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private TipoNotificacionRepository tipoNotificacionRepository;
    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private RbacAccessService access;
    @Mock
    private FlujoReviewerResolver reviewers;
    @Mock
    private VRevisorSolicitudRepository vRevisorSolicitudRepository;
    @Mock
    private HistorialTransicionRepository historialTransicionRepository;
    @Mock
    private CorreoNotificacionService correos;

    private NotificacionService notificacionService;

    private UserAccount emisor;
    private UserAccount revisor;
    private UserAccount revisor2;
    private Solicitud solicitud;
    private HistorialTransicion transicion;

    @BeforeEach
    void setUp() {
        NotificacionMensajeFactory factory = new NotificacionMensajeFactory();
        NotificacionesCorreoProperties correoHabilitado = new NotificacionesCorreoProperties(true);
        notificacionService = new NotificacionService(
                notificacionRepository,
                tipoNotificacionRepository,
                access,
                reviewers,
                vRevisorSolicitudRepository,
                userAccountRepository,
                historialTransicionRepository,
                factory,
                correos,
                correoHabilitado
        );

        emisor = usuario("emisor@test.local", "Juan", "Emisor");
        revisor = usuario("revisor@test.local", "Ana", "Revisora");
        revisor2 = usuario("revisor2@test.local", "Carlos", "Revisor");

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc");
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        EstadoSolicitud estado = new EstadoSolicitud("PENDIENTE_REVISION", "Pendiente de revisión", 1, false);

        solicitud = new Solicitud(flujo, emisor, "Documento Prueba", "Desc", estado, etapa);
        ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());
        ReflectionTestUtils.setField(solicitud, "correlativo", "CONT-001");
        ReflectionTestUtils.setField(solicitud, "deadline", Instant.parse("2026-10-30T15:00:00Z"));

        transicion = new HistorialTransicion(
                solicitud, etapa, new AccionTransicion("REGISTRAR", "Registrar"), null, estado, emisor, "Crear", true, "{}"
        );
        ReflectionTestUtils.setField(transicion, "id", 55L);

        when(historialTransicionRepository.findById(any(Long.class))).thenReturn(Optional.of(transicion));
    }

    private UserAccount usuario(String email, String nombre, String apellido) {
        UserAccount u = new UserAccount("kc-" + email, email, nombre, apellido, true);
        ReflectionTestUtils.setField(u, "id", UUID.randomUUID());
        return u;
    }

    private NotificacionContexto ctx(String accion) {
        return new NotificacionContexto(
                solicitud.getId(), 55L, "CONT-001", "Documento Prueba", "PDF",
                "Revisión", "Revisión", "Ana Revisora", "Juan Emisor", null,
                Instant.parse("2026-10-30T15:00:00Z"), "Observación de prueba", accion);
    }

    private TipoNotificacion tipo(String codigo, boolean enviaCorreo) {
        TipoNotificacion t = new TipoNotificacion(codigo);
        ReflectionTestUtils.setField(t, "id", 7L);
        ReflectionTestUtils.setField(t, "enviaCorreo", enviaCorreo);
        when(tipoNotificacionRepository.findByTipoIgnoreCase(codigo)).thenReturn(Optional.of(t));
        return t;
    }

    // ------------------------------------------------------------------ crear (§6.2)

    @Test
    void crear_publicaCorreoCuandoCatalogoHabilitadoYActivo() {
        tipo("CORRECCION_REQUERIDA", true);
        Notificacion fila = notificacionPersistida();
        when(notificacionRepository.insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(42L);
        when(notificacionRepository.findById(42L)).thenReturn(Optional.of(fila));

        Notificacion creada = notificacionService.crear("CORRECCION_REQUERIDA", emisor, solicitud, 55L,
                new NotificacionMensajeFactory().construir("CORRECCION_REQUERIDA", ctx("SOLICITAR_CORRECCION")), null);

        assertThat(creada).isSameAs(fila);
        verify(notificacionRepository).marcarCorreoPendiente(eq(42L), any(Instant.class));
        verify(correos).publicar(fila, 1);
    }

    @Test
    void crear_duplicado_noPublicaCorreoNiRompe() {
        tipo("CORRECCION_REQUERIDA", true);
        when(notificacionRepository.insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(null); // ON CONFLICT DO NOTHING

        Notificacion creada = notificacionService.crear("CORRECCION_REQUERIDA", emisor, solicitud, null,
                new MensajeNotificacion("T", "M", "/solicitudes/x", "Corregir solicitud"), "dedup-1");

        assertThat(creada).isNull();
        verify(notificacionRepository, never()).marcarCorreoPendiente(any(), any());
        verify(correos, never()).publicar(any(), anyInt());
    }

    @Test
    void crear_tipoSinCorreoEnCatalogo_quedaSinAplca() {
        tipo("SOLICITUD_AVANZA", false); // D3-01
        Notificacion fila = notificacionPersistida();
        when(notificacionRepository.insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(7L);
        when(notificacionRepository.findById(7L)).thenReturn(Optional.of(fila));

        Notificacion creada = notificacionService.crear("SOLICITUD_AVANZA", emisor, solicitud, null,
                new MensajeNotificacion("T", "M", "/solicitudes/x", "Ver solicitud"), null);

        assertThat(creada).isNotNull();
        verify(notificacionRepository, never()).marcarCorreoPendiente(any(), any());
        verify(correos, never()).publicar(any(), anyInt());
    }

    @Test
    void crear_destinatarioInactivo_noPublicaCorreo() {
        tipo("CORRECCION_REQUERIDA", true);
        UserAccount inactivo = usuario("inactivo@test.local", "Luis", "Inactivo");
        inactivo.setActivo(false);
        Notificacion fila = notificacionPersistida();
        when(notificacionRepository.insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(9L);
        when(notificacionRepository.findById(9L)).thenReturn(Optional.of(fila));

        notificacionService.crear("CORRECCION_REQUERIDA", inactivo, solicitud, null,
                new MensajeNotificacion("T", "M", "/solicitudes/x", "Corregir solicitud"), null);

        verify(notificacionRepository, never()).marcarCorreoPendiente(any(), any());
        verify(correos, never()).publicar(any(), anyInt());
    }

    @Test
    void crear_brokerCaido_noRompeLaCreacion() {
        // CA 09.4: RabbitTemplate lanza; el publicador lo traga y la notificación sale PENDIENTE.
        RabbitTemplate rabbit = org.mockito.Mockito.mock(RabbitTemplate.class);
        org.mockito.Mockito.doThrow(new RuntimeException("broker caído"))
                .when(rabbit).convertAndSend(any(), any(), any(), any(org.springframework.amqp.core.MessagePostProcessor.class));
        MensajeriaProperties props = new MensajeriaProperties("capstone.exchange", "capstone.dlx",
                new MensajeriaProperties.Republicador(Duration.ofMinutes(2), Duration.ofMinutes(10),
                        Duration.ofMinutes(5), 3));
        NotificacionService servicioReal = new NotificacionService(
                notificacionRepository, tipoNotificacionRepository, access, reviewers,
                vRevisorSolicitudRepository, userAccountRepository, historialTransicionRepository,
                new NotificacionMensajeFactory(),
                new CorreoNotificacionService(new MensajePublicador(rabbit, props),
                        new AppProperties("http://localhost:3000", new AppProperties.Scheduling(true))),
                new NotificacionesCorreoProperties(true));

        tipo("CORRECCION_REQUERIDA", true);
        Notificacion fila = notificacionPersistida();
        // Simula el UPDATE nativo marcarCorreoPendiente que el mock no ejecuta.
        ReflectionTestUtils.setField(fila, "estadoCorreo", EstadoCorreo.PENDIENTE);
        when(notificacionRepository.insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(11L);
        when(notificacionRepository.findById(11L)).thenReturn(Optional.of(fila));

        Notificacion creada = servicioReal.crear("CORRECCION_REQUERIDA", emisor, solicitud, null,
                new MensajeNotificacion("T", "M", "/solicitudes/x", "Corregir solicitud"), null);

        assertThat(creada).isNotNull();
        assertThat(creada.getEstadoCorreo()).isEqualTo(EstadoCorreo.PENDIENTE);
        verify(notificacionRepository).marcarCorreoPendiente(eq(11L), any(Instant.class));
    }

    // ------------------------------------------------------------- compositores (§6.1)

    @Test
    void notificarRevisionAsignada_notificaRevisores_salvoElActor() {
        tipo("REVISION_ASIGNADA", false);
        when(vRevisorSolicitudRepository.findBySolicitudId(solicitud.getId()))
                .thenReturn(List.of(
                        new VRevisorSolicitud(solicitud.getId(), 1L, revisor.getId()),
                        new VRevisorSolicitud(solicitud.getId(), 1L, revisor2.getId())));
        when(userAccountRepository.findAllById(List.of(revisor.getId(), revisor2.getId())))
                .thenReturn(List.of(revisor, revisor2));

        NotificacionContexto ctx = ctx("REGISTRAR");
        NotificacionContexto conActor = new NotificacionContexto(ctx.solicitudId(), ctx.historialId(),
                ctx.correlativo(), ctx.tituloSolicitud(), ctx.tipoDocumento(), ctx.etapaOrigen(),
                ctx.etapaDestino(), ctx.nombreActor(), ctx.nombreEmisor(), revisor.getId(),
                ctx.deadline(), ctx.observacion(), ctx.accion());
        notificacionService.notificarRevisionAsignada(solicitud, conActor);

        // Solo revisor2 (revisor es el actor → D-08).
        ArgumentCaptor<UUID> destinatario = ArgumentCaptor.forClass(UUID.class);
        ArgumentCaptor<String> titulo = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> enlace = ArgumentCaptor.forClass(String.class);
        verify(notificacionRepository).insertarIgnorandoDedup(
                destinatario.capture(), eq(solicitud.getId()), eq(55L), eq(7L),
                titulo.capture(), any(String.class), enlace.capture(), isNull());

        assertThat(destinatario.getValue()).isEqualTo(revisor2.getId());
        assertThat(titulo.getValue()).isEqualTo("Tienes una solicitud por revisar: CONT-001");
        assertThat(enlace.getValue()).isEqualTo("/solicitudes/" + solicitud.getId() + "?accion=revisar");
    }

    @Test
    void notificarRevisionAsignada_CORREGIR_usaTextoDeCorreccion() {
        tipo("REVISION_ASIGNADA", false);
        when(vRevisorSolicitudRepository.findBySolicitudId(solicitud.getId()))
                .thenReturn(List.of(new VRevisorSolicitud(solicitud.getId(), 1L, revisor.getId())));
        when(userAccountRepository.findAllById(List.of(revisor.getId()))).thenReturn(List.of(revisor));

        notificacionService.notificarRevisionAsignada(solicitud, ctx("CORREGIR"));

        ArgumentCaptor<String> mensaje = ArgumentCaptor.forClass(String.class);
        verify(notificacionRepository).insertarIgnorandoDedup(
                eq(revisor.getId()), any(), any(), any(), any(), mensaje.capture(), any(), any());
        assertThat(mensaje.getValue()).contains("Juan Emisor corrigió «Documento Prueba» y vuelve a tu revisión.")
                .contains("Plazo: 30-10-2026 12:00"); // America/Santiago (UTC-3)
    }

    @Test
    void notificarSolicitudAprobada_notificaAlEmisor_conTextoDeCatalogo() {
        tipo("SOLICITUD_APROBADA", true);
        when(access.canRead(any(), any())).thenReturn(true);

        notificacionService.notificarSolicitudAprobada(solicitud, ctx("APROBAR"));

        ArgumentCaptor<String> titulo = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> mensaje = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> enlace = ArgumentCaptor.forClass(String.class);
        verify(notificacionRepository).insertarIgnorandoDedup(
                eq(emisor.getId()), eq(solicitud.getId()), eq(55L), eq(7L),
                titulo.capture(), mensaje.capture(), enlace.capture(), isNull());

        assertThat(titulo.getValue()).isEqualTo("CONT-001 fue aprobada");
        assertThat(mensaje.getValue()).isEqualTo("«Documento Prueba» completó su flujo de aprobación.");
        assertThat(enlace.getValue()).isEqualTo("/solicitudes/" + solicitud.getId());
    }

    @Test
    void notificarSolicitudAvanza_sinCorreoPorCatalogo() {
        // §6.1: SOLICITUD_AVANZA envia_correo = false → sin publicación de correo.
        tipo("SOLICITUD_AVANZA", false);
        when(access.canRead(any(), any())).thenReturn(true);

        notificacionService.notificarSolicitudAvanza(solicitud, ctx("APROBAR"));

        verify(notificacionRepository).insertarIgnorandoDedup(
                eq(emisor.getId()), any(), any(), any(), any(), any(), any(), isNull());
        verify(notificacionRepository, never()).marcarCorreoPendiente(any(), any());
        verify(correos, never()).publicar(any(), anyInt());
    }

    @Test
    void notificarSolicitudAprobada_cuandoElActorEsElEmisor_noNotifica() {
        tipo("SOLICITUD_APROBADA", true);
        NotificacionContexto ctx = ctx("APROBAR");
        NotificacionContexto conActor = new NotificacionContexto(ctx.solicitudId(), ctx.historialId(),
                ctx.correlativo(), ctx.tituloSolicitud(), ctx.tipoDocumento(), ctx.etapaOrigen(),
                ctx.etapaDestino(), ctx.nombreActor(), ctx.nombreEmisor(), emisor.getId(),
                ctx.deadline(), ctx.observacion(), ctx.accion());

        notificacionService.notificarSolicitudAprobada(solicitud, conActor);

        verify(notificacionRepository, never()).insertarIgnorandoDedup(any(), any(), any(), any(), any(), any(), any(), any());
    }

    @Test
    void notificarDecisionAdmin_notificaRevisoresDeEtapaOrigen() {
        tipo("DECISION_ADMIN_GLOBAL", false);
        when(userAccountRepository.findAllById(List.of(revisor.getId(), revisor2.getId())))
                .thenReturn(List.of(revisor, revisor2));

        notificacionService.notificarDecisionAdmin(solicitud, ctx("APROBAR"),
                List.of(revisor.getId(), revisor2.getId()));

        verify(notificacionRepository, org.mockito.Mockito.times(2)).insertarIgnorandoDedup(
                any(UUID.class), eq(solicitud.getId()), eq(55L), eq(7L),
                eq("El administrador decidió sobre CONT-001"),
                eq("Ana Revisora aprobó «Documento Prueba» en tu lugar."),
                eq("/solicitudes/" + solicitud.getId()), isNull());
    }

    // ------------------------------------------------------------------ bandeja (§6.3)

    @Test
    void testMarcarComoLeida_Success() {
        Notificacion notif = notificacionPersistida();
        ReflectionTestUtils.setField(notif, "id", 100L);

        when(notificacionRepository.findById(100L)).thenReturn(Optional.of(notif));
        when(notificacionRepository.save(any(Notificacion.class))).thenAnswer(i -> i.getArgument(0));

        NotificacionResponse res = notificacionService.marcarComoLeida(100L, emisor);

        assertThat(res.leida()).isTrue();
        assertThat(notif.isLeida()).isTrue();
        assertThat(notif.getLeidaEn()).isNotNull();
    }

    @Test
    void testContarNoLeidas() {
        when(notificacionRepository.countByDestinatario_IdAndLeidaFalse(emisor.getId())).thenReturn(3L);

        long count = notificacionService.contarNoLeidas(emisor);
        assertThat(count).isEqualTo(3L);
    }

    @Test
    void testMarcarComoLeida_UsuarioNoEsDestinatario_LanzaAccessDeniedException() {
        Notificacion notif = notificacionPersistida();
        ReflectionTestUtils.setField(notif, "id", 101L);

        when(notificacionRepository.findById(101L)).thenReturn(Optional.of(notif));

        org.junit.jupiter.api.Assertions.assertThrows(
                com.capstone.sistema.rbac.exception.RbacException.class,
                () -> notificacionService.marcarComoLeida(101L, revisor)
        );
        verify(notificacionRepository, never()).save(any());
    }

    @Test
    void testMarcarTodasComoLeidas_ActualizaTodasANoLeidas() {
        Notificacion n1 = notificacionPersistida();
        Notificacion n2 = notificacionPersistida();
        when(notificacionRepository.findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(emisor.getId()))
                .thenReturn(List.of(n1, n2));

        int actualizadas = notificacionService.marcarTodasComoLeidas(emisor);

        assertThat(actualizadas).isEqualTo(2);
        assertThat(n1.isLeida()).isTrue();
        assertThat(n2.isLeida()).isTrue();
        verify(notificacionRepository).saveAll(List.of(n1, n2));
    }

    private Notificacion notificacionPersistida() {
        Notificacion n = new Notificacion(emisor, solicitud, transicion,
                new TipoNotificacion("X"), "T", "M");
        ReflectionTestUtils.setField(n, "id", 42L);
        return n;
    }
}
