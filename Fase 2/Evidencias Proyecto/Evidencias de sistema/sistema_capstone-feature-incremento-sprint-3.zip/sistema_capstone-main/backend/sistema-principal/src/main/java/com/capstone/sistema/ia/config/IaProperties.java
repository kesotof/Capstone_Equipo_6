package com.capstone.sistema.ia.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * F6 (§6.0): propiedades del subsistema de IA en sistema-principal (US-30, US-29).
 */
@ConfigurationProperties(prefix = "ia")
public record IaProperties(
        boolean habilitada,
        boolean evaluacionAutomatica,
        Chat chat,
        Autocompletado autocompletado
) {
    public IaProperties {
        if (chat == null) {
            chat = new Chat(1000, 50);
        }
        if (autocompletado == null) {
            autocompletado = new Autocompletado("ia-temporal", 10485760L);
        }
    }

    public record Chat(int maxPregunta, int maxPreguntasDiaSolicitud) {
        public Chat {
            if (maxPregunta <= 0) maxPregunta = 1000;
            if (maxPreguntasDiaSolicitud <= 0) maxPreguntasDiaSolicitud = 50;
        }
    }

    public record Autocompletado(String bucket, long maxBytes) {
        public Autocompletado {
            if (bucket == null || bucket.isBlank()) bucket = "ia-temporal";
            if (maxBytes <= 0) maxBytes = 10485760L;
        }
    }
}
