package com.capstone.sistema.doc.dto;

import java.time.Instant;
import java.util.UUID;

/** Documento adjunto de una solicitud; descargaUrl es null si el usuario no puede descargarlo. */
public record AnexoResponse(
        UUID id,
        String nombreArchivo,
        String contentType,
        Long sizeBytes,
        Instant createdAt,
        String descargaUrl
) {}
