package com.capstone.sistema.flow.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import java.util.Objects;

@Entity
@Table(name = "estado_solicitud")
public class EstadoSolicitud {

    @Id
    @Column(name = "codigo", length = 30)
    private String codigo;

    @Column(name = "etiqueta", nullable = false, length = 100)
    private String etiqueta;

    @Column(name = "orden", nullable = false)
    private Integer orden;

    @Column(name = "es_final", nullable = false)
    private boolean esFinal;

    protected EstadoSolicitud() {
    }

    public EstadoSolicitud(String codigo) {
        this.codigo = codigo;
        this.etiqueta = codigo;
        this.orden = 1;
        this.esFinal = false;
    }

    public EstadoSolicitud(String codigo, String etiqueta, Integer orden, boolean esFinal) {
        this.codigo = codigo;
        this.etiqueta = etiqueta;
        this.orden = orden;
        this.esFinal = esFinal;
    }

    public EstadoSolicitud(Long id, String codigo) {
        this.codigo = codigo;
        this.etiqueta = codigo;
        this.orden = id != null ? id.intValue() : 1;
        this.esFinal = false;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public boolean isEsFinal() {
        return esFinal;
    }

    public void setEsFinal(boolean esFinal) {
        this.esFinal = esFinal;
    }

    @Transient
    public Long getId() {
        return orden != null ? orden.longValue() : null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EstadoSolicitud that = (EstadoSolicitud) o;
        return Objects.equals(codigo, that.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
