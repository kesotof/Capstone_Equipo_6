package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.TipoAsignacionRevisor;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.UUID;

/**
 * Body de {@code PUT /api/flujos/{id}/etapas/{stepId}/responsable}: {@code {revisorIds, version}}.
 * {@code revisorId} se mantiene por compatibilidad (lista de un elemento). {@code tipoAsignacion} es opcional
 * y solo admite USUARIO (D-05).
 */
public record AsignarResponsableRequest(
        @NotNull @Min(0) Long version,
        TipoAsignacionRevisor tipoAsignacion,
        UUID revisorId,
        @Size(max = 100, message = "Una etapa admite hasta 100 revisores")
        List<UUID> revisorIds
) {
    public AsignarResponsableRequest {
        if (tipoAsignacion == null) tipoAsignacion = TipoAsignacionRevisor.USUARIO;
    }
}
