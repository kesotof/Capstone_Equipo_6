package com.capstone.sistema.doc.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import com.capstone.sistema.doc.exception.DocumentDownloadException;
import com.capstone.sistema.doc.repository.DocumentDownloadRepository;
import com.capstone.sistema.model.view.VAccesoDescarga;
import com.capstone.sistema.model.view.VAccesoDescargaRepository;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
public class DocumentDownloadResolver {
    private final DocumentDownloadRepository documents;
    private final RbacAccessService access;
    private final AuditService audit;
    private final VAccesoDescargaRepository accesoDescargaRepository;

    public DocumentDownloadResolver(
            DocumentDownloadRepository documents,
            RbacAccessService access,
            AuditService audit,
            VAccesoDescargaRepository accesoDescargaRepository
    ) {
        this.documents = documents;
        this.access = access;
        this.audit = audit;
        this.accesoDescargaRepository = accesoDescargaRepository;
    }

    public DocumentDownloadTarget byId(UUID id) {
        access.clearContext();
        List<DocumentDownloadTarget> matches = documents.byId(id);
        return resolveAndAuthorize(matches);
    }

    public DocumentDownloadTarget current(UUID solicitudId) {
        access.clearContext();
        List<DocumentDownloadTarget> matches = documents.current(solicitudId);
        if (matches.isEmpty()) {
            UUID usuarioId = access.context().usuarioId();
            boolean canView = access.context().admin() || access.puedeAccederSolicitud(usuarioId, solicitudId);
            if (!canView) {
                throw DocumentDownloadException.missing();
            }
            throw DocumentDownloadException.missing();
        }
        return resolveAndAuthorize(matches);
    }

    public DocumentDownloadTarget byKey(String key) {
        access.clearContext();
        List<DocumentDownloadTarget> matches = documents.byKey(key);
        return resolveAndAuthorize(matches);
    }

    /** Los anexos se descargan con la misma regla que el documento de su solicitud. */
    public DocumentDownloadTarget anexo(UUID id) {
        access.clearContext();
        return resolveAndAuthorize(documents.anexo(id));
    }

    private DocumentDownloadTarget resolveAndAuthorize(List<DocumentDownloadTarget> matches) {
        if (matches.isEmpty()) {
            throw DocumentDownloadException.missing();
        }
        if (matches.size() != 1) {
            throw DocumentDownloadException.inconsistent();
        }
        DocumentDownloadTarget target = matches.getFirst();
        if (target.storageKey() == null || target.storageKey().isBlank()) {
            throw DocumentDownloadException.missing();
        }

        UUID solicitudId = target.solicitudId();
        UUID usuarioId = access.context().usuarioId();
        boolean isAdmin = access.context().admin();

        // 1. Verificación de visibilidad: si no ve la solicitud -> 404
        boolean canView = isAdmin || access.puedeAccederSolicitud(usuarioId, solicitudId);
        if (!canView) {
            throw DocumentDownloadException.missing();
        }

        // 2. Verificación de descarga: si ve la solicitud pero no puede descargar -> 403 DOCUMENTO_DESCARGA_DENEGADA
        boolean canDownload = isAdmin || access.puedeDescargar(usuarioId, solicitudId);
        if (!canDownload) {
            audit.registerAuditEvent(
                    "ACCESO_DENEGADO",
                    "documento",
                    target.id() != null ? target.id().toString() : null,
                    "DENEGADO",
                    "{\"solicitudId\":\"" + solicitudId + "\",\"codigo\":\"DOCUMENTO_DESCARGA_DENEGADA\"}"
            );
            throw DocumentDownloadException.downloadDenied();
        }

        // 3. Obtener motivo para auditoría
        String motivo = "ADMIN_SISTEMA";
        if (!isAdmin && usuarioId != null) {
            List<VAccesoDescarga> descargas = accesoDescargaRepository.findBySolicitudId(solicitudId);
            motivo = descargas.stream()
                    .filter(d -> usuarioId.equals(d.getUsuarioId()))
                    .map(VAccesoDescarga::getMotivo)
                    .findFirst()
                    .orElse("AUTORIZADO");
        }

        return new DocumentDownloadTarget(
                target.id(),
                target.solicitudId(),
                target.nombreArchivo(),
                target.contentType(),
                target.storageKey(),
                target.sizeBytes(),
                target.version(),
                motivo
        );
    }
}
