package com.capstone.sistema.doc.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.dto.TipoDocumentoDtos.*;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TipoDocumentoServiceTest {

    @Mock
    private TipoDocumentoRepository tipoDocumentoRepository;

    @Mock
    private SolicitudRepository solicitudRepository;

    @Mock
    private AuditService auditService;

    private TipoDocumentoService tipoDocumentoService;

    @BeforeEach
    void setUp() {
        tipoDocumentoService = new TipoDocumentoService(
                tipoDocumentoRepository,
                solicitudRepository,
                auditService
        );
    }

    @Test
    void createValidatesUniqueNameAndPrefix() {
        when(tipoDocumentoRepository.existsByNombreIgnoreCase("Factura")).thenReturn(true);

        CrearTipoDocumentoRequest req = new CrearTipoDocumentoRequest("Factura", "Desc", "FAC", 5);

        assertThatThrownBy(() -> tipoDocumentoService.create(req))
                .isInstanceOf(RbacException.class)
                .hasMessageContaining("Ya existe un tipo de documento con el nombre especificado");
    }

    @Test
    void createPersistsTipoDocumentoAndAudits() {
        when(tipoDocumentoRepository.existsByNombreIgnoreCase("Orden de Compra")).thenReturn(false);
        when(tipoDocumentoRepository.existsByPrefijoIgnoreCase("OC")).thenReturn(false);
        when(tipoDocumentoRepository.save(any(TipoDocumento.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CrearTipoDocumentoRequest req = new CrearTipoDocumentoRequest("Orden de Compra", "Desc", "OC", 3);
        TipoDocumentoResponse res = tipoDocumentoService.create(req);

        assertThat(res).isNotNull();
        assertThat(res.nombre()).isEqualTo("Orden de Compra");
        assertThat(res.prefijo()).isEqualTo("OC");
        assertThat(res.plazoDiasHabiles()).isEqualTo(3);
        verify(auditService).registerUserManagementEvent(eq("TIPO_DOCUMENTO_CREADO"), anyString());
    }

    @Test
    void deletePreventsRemovingTipoDocumentoWithExistingRequests() {
        TipoDocumento td = new TipoDocumento("Contrato", "Desc", "CON", 10);
        when(tipoDocumentoRepository.findById(1L)).thenReturn(Optional.of(td));
        when(solicitudRepository.existsByTipoDocumento_Id(1L)).thenReturn(true);

        assertThatThrownBy(() -> tipoDocumentoService.delete(1L))
                .isInstanceOf(RbacException.class)
                .hasMessageContaining("No se puede eliminar el tipo de documento porque posee solicitudes registradas");
    }
}
