package com.capstone.sistema.ia.exception;

import org.springframework.http.HttpStatus;

/**
 * F6 (§6.6–6.8, §7): excepciones de negocio del subsistema de IA con código RFC 7807 explícito.
 */
public class IaException extends RuntimeException {

    private final HttpStatus status;
    private final String code;

    public IaException(HttpStatus status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public HttpStatus status() {
        return status;
    }

    public String code() {
        return code;
    }

    public static IaException accesoDenegado() {
        return new IaException(HttpStatus.FORBIDDEN, "IA_ACCESO_DENEGADO",
                "No tienes acceso a las funciones de IA para esta solicitud.");
    }

    public static IaException deshabilitada() {
        return new IaException(HttpStatus.SERVICE_UNAVAILABLE, "IA_DESHABILITADA",
                "El servicio de IA está temporalmente deshabilitado.");
    }

    public static IaException sinCriterio() {
        return new IaException(HttpStatus.UNPROCESSABLE_ENTITY, "IA_SIN_CRITERIO",
                "La etapa actual de la solicitud no tiene criterio de IA configurado.");
    }

    public static IaException solicitudNoEnRevision() {
        return new IaException(HttpStatus.UNPROCESSABLE_ENTITY, "IA_SOLICITUD_NO_EN_REVISION",
                "La solicitud no se encuentra en estado PENDIENTE_REVISION.");
    }

    public static IaException tareaEnCurso() {
        return new IaException(HttpStatus.CONFLICT, "IA_TAREA_EN_CURSO",
                "Ya existe una tarea de IA en curso para esta solicitud.");
    }

    public static IaException preguntaInvalida(String detalle) {
        return new IaException(HttpStatus.BAD_REQUEST, "IA_PREGUNTA_INVALIDA", detalle);
    }

    public static IaException limiteDiario() {
        return new IaException(HttpStatus.TOO_MANY_REQUESTS, "IA_LIMITE_DIARIO",
                "Se ha alcanzado el límite diario de preguntas de IA para esta solicitud.");
    }

    public static IaException noEncontrada(String detalle) {
        return new IaException(HttpStatus.NOT_FOUND, "IA_NO_ENCONTRADA", detalle);
    }

    public static IaException formatoNoSoportado(String detalle) {
        return new IaException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "IA_FORMATO_NO_SOPORTADO", detalle);
    }

    public static IaException autocompletadoNoAplicable(String detalle) {
        return new IaException(HttpStatus.CONFLICT, "AUTOCOMPLETADO_NO_APLICABLE", detalle);
    }

    public static IaException archivoExcedeTamano(String detalle) {
        return new IaException(HttpStatus.BAD_REQUEST, "IA_ARCHIVO_EXCEDE_TAMANO", detalle);
    }

    public static IaException noDisponible(String detalle) {
        return new IaException(HttpStatus.SERVICE_UNAVAILABLE, "IA_NO_DISPONIBLE", detalle);
    }
}
