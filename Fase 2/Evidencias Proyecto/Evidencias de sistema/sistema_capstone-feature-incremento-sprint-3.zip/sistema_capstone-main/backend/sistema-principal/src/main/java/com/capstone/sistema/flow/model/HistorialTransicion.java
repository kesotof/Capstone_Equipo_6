package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "historial_transicion")
@Immutable
public class HistorialTransicion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_etapa_id", nullable = false)
    private FlujoEtapa flujoEtapa;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "accion", referencedColumnName = "codigo", nullable = false)
    private AccionTransicion accion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "estado_origen", referencedColumnName = "codigo")
    private EstadoSolicitud estadoOrigen;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "estado_destino", referencedColumnName = "codigo", nullable = false)
    private EstadoSolicitud estadoDestino;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount usuario;

    @Column(columnDefinition = "TEXT")
    private String observacion;

    @Column(name = "dentro_sla")
    private Boolean dentroSla;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "metadata", nullable = false, columnDefinition = "jsonb")
    private String metadata = "{}";

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected HistorialTransicion() {
    }

    public HistorialTransicion(
            Solicitud solicitud,
            FlujoEtapa flujoEtapa,
            AccionTransicion accion,
            EstadoSolicitud estadoOrigen,
            EstadoSolicitud estadoDestino,
            UserAccount usuario,
            String observacion,
            Boolean dentroSla,
            String metadata
    ) {
        this.solicitud = solicitud;
        this.flujoEtapa = flujoEtapa;
        this.accion = accion;
        this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.usuario = usuario;
        this.observacion = observacion;
        this.dentroSla = dentroSla;
        this.metadata = metadata != null ? metadata : "{}";
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (metadata == null) {
            metadata = "{}";
        }
    }

    public Long getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public FlujoEtapa getFlujoEtapa() {
        return flujoEtapa;
    }

    public AccionTransicion getAccion() {
        return accion;
    }

    public EstadoSolicitud getEstadoOrigen() {
        return estadoOrigen;
    }

    public EstadoSolicitud getEstadoDestino() {
        return estadoDestino;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public String getObservacion() {
        return observacion;
    }

    public Boolean getDentroSla() {
        return dentroSla;
    }

    public String getMetadata() {
        return metadata;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HistorialTransicion that = (HistorialTransicion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
