package com.capstone.sistema.flow.service;
import com.capstone.sistema.notificacion.service.NotificacionService;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.doc.service.CorrelativoService;
import com.capstone.sistema.flow.exception.DatabaseRuleViolationTranslator;
import com.capstone.sistema.flow.model.AccionTransicion;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.model.enums.AccionTransicionEnum;
import com.capstone.sistema.model.enums.EstadoSolicitudEnum;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.flow.repository.AccionTransicionRepository;
import com.capstone.sistema.flow.repository.EstadoSolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.model.view.VFlujoDisponibleUsuarioRepository;
import com.capstone.sistema.model.view.VRevisorSolicitud;
import com.capstone.sistema.model.view.VRevisorSolicitudRepository;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
public class SolicitudWorkflowService {

    private static final Logger log = LoggerFactory.getLogger(SolicitudWorkflowService.class);

    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final HistorialTransicionRepository historialTransicionRepository;
    private final EstadoSolicitudRepository estadoSolicitudRepository;
    private final AccionTransicionRepository accionTransicionRepository;
    private final FlujoDefinicionRepository flujoDefinicionRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final VRevisorSolicitudRepository revisorSolicitudRepository;
    private final VFlujoDisponibleUsuarioRepository flujoDisponibleUsuarioRepository;
    private final CorrelativoService correlativoService;
    private final SlaService slaService;
    private final NotificacionService notificacionService;
    private final org.springframework.context.ApplicationEventPublisher eventPublisher;
    private final AuditService auditService;
    private final DatabaseRuleViolationTranslator ruleTranslator;
    private final JdbcTemplate jdbcTemplate;
    private final Clock clock;

    public SolicitudWorkflowService(
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            HistorialTransicionRepository historialTransicionRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionTransicionRepository accionTransicionRepository,
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            TipoDocumentoRepository tipoDocumentoRepository,
            VRevisorSolicitudRepository revisorSolicitudRepository,
            VFlujoDisponibleUsuarioRepository flujoDisponibleUsuarioRepository,
            CorrelativoService correlativoService,
            SlaService slaService,
            NotificacionService notificacionService,
            AuditService auditService,
            DatabaseRuleViolationTranslator ruleTranslator,
            JdbcTemplate jdbcTemplate,
            Clock clock
    ) {
        this(solicitudRepository, documentoRepository, historialTransicionRepository,
                estadoSolicitudRepository, accionTransicionRepository, flujoDefinicionRepository,
                flujoEtapaRepository, tipoDocumentoRepository, revisorSolicitudRepository,
                flujoDisponibleUsuarioRepository, correlativoService, slaService, notificacionService,
                auditService, ruleTranslator, jdbcTemplate, clock, null);
    }

    @org.springframework.beans.factory.annotation.Autowired
    public SolicitudWorkflowService(
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            HistorialTransicionRepository historialTransicionRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionTransicionRepository accionTransicionRepository,
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            TipoDocumentoRepository tipoDocumentoRepository,
            VRevisorSolicitudRepository revisorSolicitudRepository,
            VFlujoDisponibleUsuarioRepository flujoDisponibleUsuarioRepository,
            CorrelativoService correlativoService,
            SlaService slaService,
            NotificacionService notificacionService,
            AuditService auditService,
            DatabaseRuleViolationTranslator ruleTranslator,
            JdbcTemplate jdbcTemplate,
            Clock clock,
            org.springframework.context.ApplicationEventPublisher eventPublisher
    ) {
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.historialTransicionRepository = historialTransicionRepository;
        this.estadoSolicitudRepository = estadoSolicitudRepository;
        this.accionTransicionRepository = accionTransicionRepository;
        this.flujoDefinicionRepository = flujoDefinicionRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.tipoDocumentoRepository = tipoDocumentoRepository;
        this.revisorSolicitudRepository = revisorSolicitudRepository;
        this.flujoDisponibleUsuarioRepository = flujoDisponibleUsuarioRepository;
        this.correlativoService = correlativoService;
        this.slaService = slaService;
        this.notificacionService = notificacionService;
        this.auditService = auditService;
        this.ruleTranslator = ruleTranslator;
        this.jdbcTemplate = jdbcTemplate;
        this.clock = clock;
        this.eventPublisher = eventPublisher;
    }

    public record RegistrarCommand(
            String titulo,
            String descripcion,
            Long flujoDefinicionId,
            Long tipoDocumentoId,
            UserAccount emisor,
            String nombreArchivo,
            String contentType,
            String storageKey,
            Long sizeBytes,
            String checksumSha256,
            String storageVersionId,
            PlantillaVersion plantillaVersion,
            String datosPlantilla,
            java.util.Map<String, Object> metadataExtra
    ) {
        public RegistrarCommand(
                String titulo,
                String descripcion,
                Long flujoDefinicionId,
                Long tipoDocumentoId,
                UserAccount emisor,
                String nombreArchivo,
                String contentType,
                String storageKey,
                Long sizeBytes,
                String checksumSha256,
                String storageVersionId,
                PlantillaVersion plantillaVersion,
                String datosPlantilla
        ) {
            this(titulo, descripcion, flujoDefinicionId, tipoDocumentoId, emisor, nombreArchivo, contentType,
                    storageKey, sizeBytes, checksumSha256, storageVersionId, plantillaVersion, datosPlantilla, null);
        }
    }

    @Transactional
    public Solicitud registrar(RegistrarCommand cmd) {
        UserAccount emisor = cmd.emisor();
        if (emisor == null || emisor.getArea() == null) {
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "El usuario emisor no pertenece a ninguna área corporativa.");
        }

        FlujoDefinicion flujo = flujoDefinicionRepository.findById(cmd.flujoDefinicionId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Definición de flujo no encontrada."));

        if (!flujo.isActivo()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El flujo seleccionado no se encuentra activo.");
        }

        TipoDocumento tipoDoc = tipoDocumentoRepository.findById(cmd.tipoDocumentoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tipo de documento no encontrado."));

        FlujoEtapa etapa1 = flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(flujo.getId(), 1)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "El flujo no tiene configurada la primera etapa."));

        // Validar si la etapa 1 tiene revisores resolubles (prevención de etapa huérfana)
        validarRevisoresDisponibles(etapa1, emisor.getArea());

        String correlativo = correlativoService.siguienteCorrelativo(tipoDoc.getId());
        Instant deadline = slaService.calculateDeadline(tipoDoc, clock.instant());

        EstadoSolicitud estadoInicial = estadoSolicitudRepository.findById(EstadoSolicitudEnum.PENDIENTE_REVISION.name())
                .orElseGet(() -> new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name(), "Pendiente de revisión", 1, false));

        Solicitud solicitud = new Solicitud(flujo, emisor, cmd.titulo(), cmd.descripcion(), estadoInicial, etapa1);
        solicitud.setCorrelativo(correlativo);
        solicitud.setTipoDocumento(tipoDoc);
        solicitud.setArea(emisor.getArea());
        solicitud.setDeadline(deadline);

        solicitud = solicitudRepository.saveAndFlush(solicitud);

        AccionTransicion accion = accionTransicionRepository.findById(AccionTransicionEnum.REGISTRAR.name())
                .orElseGet(() -> new AccionTransicion(AccionTransicionEnum.REGISTRAR.name(), "Registrar"));

        HistorialTransicion historial = new HistorialTransicion(
                solicitud,
                etapa1,
                accion,
                null,
                estadoInicial,
                emisor,
                "Registro inicial de solicitud",
                true,
                serializarMetadata(cmd.metadataExtra())
        );
        historial = historialTransicionRepository.saveAndFlush(historial);

        if (cmd.nombreArchivo() != null && !cmd.nombreArchivo().isBlank()) {
            Documento doc = new Documento(
                    historial,
                    null,
                    1,
                    cmd.nombreArchivo(),
                    cmd.contentType() != null ? cmd.contentType() : "application/octet-stream",
                    cmd.storageKey(),
                    cmd.sizeBytes() != null ? cmd.sizeBytes() : 0L,
                    cmd.checksumSha256() != null ? cmd.checksumSha256() : "0000000000000000000000000000000000000000000000000000000000000000",
                    cmd.storageVersionId(),
                    cmd.plantillaVersion(),
                    cmd.datosPlantilla()
            );
            documentoRepository.save(doc);
        }

        auditService.registerEvent("SOLICITUD_CREADA", emisor, "Solicitud creada: " + correlativo);

        // F2 (A-11): los consumidores (notificaciones US-36, IA US-30) escuchan el evento de dominio
        publicarTransicion(solicitud, historial, "REGISTRAR", emisor, "Registro inicial de solicitud");

        return solicitud;
    }

    @Transactional
    public Solicitud aprobar(UUID solicitudId, UserAccount actor, String comentario, Long expectedVersion) {
        Solicitud solicitud = obtenerYValidarVersion(solicitudId, expectedVersion);
        validarActorEsRevisor(solicitud, actor);

        int ordenActual = solicitud.getFlujoEtapa().getOrden();
        Optional<FlujoEtapa> siguienteEtapaOpt = flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(
                solicitud.getFlujoDefinicion().getId(),
                ordenActual + 1
        );

        EstadoSolicitud estadoDestino;
        FlujoEtapa etapaDestino;
        boolean esFinal = siguienteEtapaOpt.isEmpty();

        if (!esFinal) {
            etapaDestino = siguienteEtapaOpt.get();
            estadoDestino = solicitud.getEstadoSolicitud(); // Permanece PENDIENTE_REVISION
        } else {
            etapaDestino = solicitud.getFlujoEtapa();
            estadoDestino = estadoSolicitudRepository.findById(EstadoSolicitudEnum.APROBADO.name())
                    .orElseGet(() -> new EstadoSolicitud(EstadoSolicitudEnum.APROBADO.name(), "Aprobado", 3, true));
        }

        boolean dentroSla = slaService.isDentroSla(solicitud.getDeadline(), clock.instant());
        AccionTransicion accion = accionTransicionRepository.findById(AccionTransicionEnum.APROBAR.name())
                .orElseGet(() -> new AccionTransicion(AccionTransicionEnum.APROBAR.name(), "Aprobar"));

        HistorialTransicion hist = new HistorialTransicion(
                solicitud,
                solicitud.getFlujoEtapa(),
                accion,
                solicitud.getEstadoSolicitud(),
                estadoDestino,
                actor,
                comentario,
                dentroSla,
                "{}"
        );
        historialTransicionRepository.saveAndFlush(hist);

        solicitud.setEstadoSolicitud(estadoDestino);
        solicitud.setFlujoEtapa(etapaDestino);
        solicitud = solicitudRepository.save(solicitud);

        auditService.registerEvent("SOLICITUD_APROBADA", actor, "Solicitud " + solicitud.getCorrelativo() + " aprobada en etapa " + ordenActual);

        publicarTransicion(solicitud, hist, "APROBAR", actor, comentario);

        return solicitud;
    }

    @Transactional
    public Solicitud rechazar(UUID solicitudId, UserAccount actor, String observacion, Long expectedVersion) {
        if (observacion == null || observacion.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Es obligatorio indicar una observación o motivo para rechazar.");
        }

        Solicitud solicitud = obtenerYValidarVersion(solicitudId, expectedVersion);
        validarActorEsRevisor(solicitud, actor);

        EstadoSolicitud estadoDestino = estadoSolicitudRepository.findById(EstadoSolicitudEnum.RECHAZADO.name())
                .orElseGet(() -> new EstadoSolicitud(EstadoSolicitudEnum.RECHAZADO.name(), "Rechazado", 4, true));

        boolean dentroSla = slaService.isDentroSla(solicitud.getDeadline(), clock.instant());
        AccionTransicion accion = accionTransicionRepository.findById(AccionTransicionEnum.RECHAZAR.name())
                .orElseGet(() -> new AccionTransicion(AccionTransicionEnum.RECHAZAR.name(), "Rechazar"));

        HistorialTransicion hist = new HistorialTransicion(
                solicitud,
                solicitud.getFlujoEtapa(),
                accion,
                solicitud.getEstadoSolicitud(),
                estadoDestino,
                actor,
                observacion,
                dentroSla,
                "{}"
        );
        historialTransicionRepository.saveAndFlush(hist);

        solicitud.setEstadoSolicitud(estadoDestino);
        solicitud = solicitudRepository.save(solicitud);

        auditService.registerEvent("SOLICITUD_RECHAZADA", actor, "Solicitud " + solicitud.getCorrelativo() + " rechazada");
        publicarTransicion(solicitud, hist, "RECHAZAR", actor, observacion);

        return solicitud;
    }

    @Transactional
    public Solicitud solicitarCorreccion(UUID solicitudId, UserAccount actor, String observacion, Long expectedVersion) {
        if (observacion == null || observacion.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Es obligatorio indicar las observaciones para solicitar corrección.");
        }

        Solicitud solicitud = obtenerYValidarVersion(solicitudId, expectedVersion);
        validarActorEsRevisor(solicitud, actor);

        EstadoSolicitud estadoDestino = estadoSolicitudRepository.findById(EstadoSolicitudEnum.CORRECCION_REQUERIDA.name())
                .orElseGet(() -> new EstadoSolicitud(EstadoSolicitudEnum.CORRECCION_REQUERIDA.name(), "Corrección requerida", 2, false));

        boolean dentroSla = slaService.isDentroSla(solicitud.getDeadline(), clock.instant());
        AccionTransicion accion = accionTransicionRepository.findById(AccionTransicionEnum.SOLICITAR_CORRECCION.name())
                .orElseGet(() -> new AccionTransicion(AccionTransicionEnum.SOLICITAR_CORRECCION.name(), "Solicitar corrección"));

        HistorialTransicion hist = new HistorialTransicion(
                solicitud,
                solicitud.getFlujoEtapa(),
                accion,
                solicitud.getEstadoSolicitud(),
                estadoDestino,
                actor,
                observacion,
                dentroSla,
                "{}"
        );
        historialTransicionRepository.saveAndFlush(hist);

        solicitud.setEstadoSolicitud(estadoDestino);
        solicitud = solicitudRepository.save(solicitud);

        auditService.registerEvent("SOLICITUD_CORRECCION_PEDIDA", actor, "Solicitud " + solicitud.getCorrelativo() + " devuelta con observaciones");
        publicarTransicion(solicitud, hist, "SOLICITAR_CORRECCION", actor, observacion);

        return solicitud;
    }

    public record CorregirCommand(
            UUID solicitudId,
            UserAccount actor,
            String comentario,
            String nuevoNombreArchivo,
            String nuevoContentType,
            String nuevoStorageKey,
            Long nuevoSizeBytes,
            String nuevoChecksumSha256,
            String nuevoStorageVersionId,
            PlantillaVersion plantillaVersion,
            String datosPlantilla,
            Long expectedVersion,
            java.util.Map<String, Object> metadataExtra
    ) {
        public CorregirCommand(
                UUID solicitudId,
                UserAccount actor,
                String comentario,
                String nuevoNombreArchivo,
                String nuevoContentType,
                String nuevoStorageKey,
                Long nuevoSizeBytes,
                String nuevoChecksumSha256,
                String nuevoStorageVersionId,
                PlantillaVersion plantillaVersion,
                String datosPlantilla,
                Long expectedVersion
        ) {
            this(solicitudId, actor, comentario, nuevoNombreArchivo, nuevoContentType, nuevoStorageKey, nuevoSizeBytes,
                    nuevoChecksumSha256, nuevoStorageVersionId, plantillaVersion, datosPlantilla, expectedVersion, null);
        }
    }

    @Transactional
    public Solicitud corregir(CorregirCommand cmd) {
        Solicitud solicitud = obtenerYValidarVersion(cmd.solicitudId(), cmd.expectedVersion());
        UserAccount actor = cmd.actor();

        if (solicitud.getUsuario() != null && !Objects.equals(solicitud.getUsuario().getId(), actor.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Solo el emisor original puede corregir la solicitud.");
        }

        if (!Objects.equals(solicitud.getEstadoSolicitud().getCodigo(), EstadoSolicitudEnum.CORRECCION_REQUERIDA.name())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "La solicitud no está en estado de corrección requerida.");
        }

        EstadoSolicitud estadoDestino = estadoSolicitudRepository.findById(EstadoSolicitudEnum.PENDIENTE_REVISION.name())
                .orElseGet(() -> new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name(), "Pendiente de revisión", 1, false));

        AccionTransicion accion = accionTransicionRepository.findById(AccionTransicionEnum.CORREGIR.name())
                .orElseGet(() -> new AccionTransicion(AccionTransicionEnum.CORREGIR.name(), "Corregir"));

        HistorialTransicion hist = new HistorialTransicion(
                solicitud,
                solicitud.getFlujoEtapa(),
                accion,
                solicitud.getEstadoSolicitud(),
                estadoDestino,
                actor,
                cmd.comentario() != null ? cmd.comentario() : "Corrección efectuada por emisor",
                true,
                serializarMetadata(cmd.metadataExtra())
        );
        hist = historialTransicionRepository.saveAndFlush(hist);

        // Documento corregido reemplaza al vigente
        List<Documento> docs = documentoRepository.findBySolicitud_IdOrderByVersionDesc(solicitud.getId());
        Documento anterior = docs.isEmpty() ? null : docs.get(0);
        int nuevaVersion = anterior != null ? anterior.getVersion() + 1 : 2;

        if (cmd.nuevoNombreArchivo() != null && !cmd.nuevoNombreArchivo().isBlank()) {
            Documento nuevoDoc = new Documento(
                    hist,
                    anterior,
                    nuevaVersion,
                    cmd.nuevoNombreArchivo(),
                    cmd.nuevoContentType() != null ? cmd.nuevoContentType() : (anterior != null ? anterior.getContentType() : "application/octet-stream"),
                    cmd.nuevoStorageKey(),
                    cmd.nuevoSizeBytes() != null ? cmd.nuevoSizeBytes() : 0L,
                    cmd.nuevoChecksumSha256() != null ? cmd.nuevoChecksumSha256() : "0000000000000000000000000000000000000000000000000000000000000000",
                    cmd.nuevoStorageVersionId(),
                    cmd.plantillaVersion(),
                    cmd.datosPlantilla()
            );
            documentoRepository.save(nuevoDoc);
        }

        // El deadline se mantiene intacto según regla E6
        solicitud.setEstadoSolicitud(estadoDestino);
        solicitud = solicitudRepository.save(solicitud);

        auditService.registerEvent("SOLICITUD_CORREGIDA", actor, "Solicitud " + solicitud.getCorrelativo() + " reenviada v" + nuevaVersion);
        publicarTransicion(solicitud, hist, "CORREGIR", actor, cmd.comentario() != null ? cmd.comentario() : "Corrección efectuada por emisor");

        return solicitud;
    }

    private Solicitud obtenerYValidarVersion(UUID solicitudId, Long expectedVersion) {
        Solicitud solicitud = solicitudRepository.findById(solicitudId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Solicitud no encontrada: " + solicitudId));

        if (expectedVersion != null && solicitud.getLockVersion() != expectedVersion) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Conflicto de versión. La solicitud ha sido modificada por otro usuario.");
        }
        return solicitud;
    }

    private void validarActorEsRevisor(Solicitud solicitud, UserAccount actor) {
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado.");
        }

        // Validación con la función nativa es_revisor en base de datos
        try {
            Boolean esRevisor = jdbcTemplate.queryForObject(
                    "SELECT es_revisor(?, ?, ?)",
                    Boolean.class,
                    solicitud.getId(),
                    solicitud.getFlujoEtapa().getId(),
                    actor.getId()
            );
            if (Boolean.TRUE.equals(esRevisor)) {
                return;
            }
        } catch (Exception e) {
            log.debug("Error consultando es_revisor nativo: {}", e.getMessage());
        }

        // Fallback a VRevisorSolicitud
        boolean enVista = revisorSolicitudRepository.existsBySolicitudIdAndUsuarioId(solicitud.getId(), actor.getId());
        if (!enVista) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "El usuario no tiene atribuciones válidas de revisor para esta solicitud.");
        }
    }

    private void validarRevisoresDisponibles(FlujoEtapa etapa, Area areaEmisor) {
        if (etapa.getModoRevisor() == ModoRevisor.LISTA) {
            boolean tieneRevisores = etapa.getRevisores().stream().anyMatch(UserAccount::isEnabled);
            if (!tieneRevisores) {
                throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "La etapa 1 no cuenta con revisores activos en su lista.");
            }
        } else if (etapa.getModoRevisor() == ModoRevisor.JEFATURA_AREA_SOLICITUD) {
            if (areaEmisor == null) {
                throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "No se puede determinar jefatura sin área corporativa.");
            }
            try {
                String sql = """
                    WITH RECURSIVE rama AS (
                        SELECT a.id, a.area_padre_id, 1 AS nivel
                        FROM area a WHERE a.id = ?
                        UNION ALL
                        SELECT p.id, p.area_padre_id, r.nivel + 1
                        FROM area p JOIN rama r ON r.area_padre_id = p.id
                    )
                    SELECT EXISTS (
                        SELECT 1 FROM rama r
                        JOIN area_jefatura aj ON aj.area_id = r.id
                        JOIN usuario u ON u.id = aj.usuario_id
                        WHERE u.activo = true
                    )
                """;
                Boolean tieneJefatura = jdbcTemplate.queryForObject(sql, Boolean.class, areaEmisor.getId());
                if (!Boolean.TRUE.equals(tieneJefatura)) {
                    throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "El área del emisor o sus ancestros no cuentan con jefaturas activas configuradas.");
                }
            } catch (Exception e) {
                log.warn("Error evaluando jefatura para área {}: {}", areaEmisor.getId(), e.getMessage());
            }
        }
    }

    /**
     * F2 (A-11): publica {@link TransicionSolicitudEvent} dentro de la transacción, después
     * del INSERT del historial y del UPDATE de la solicitud (plan §6.0.2). En el motor v5 las
     * decisiones las toman revisores asignados (no hay actuación de admin global, F3: la
     * elegibilidad de correo la decide el catálogo D3-01, no el evento).
     */
    private void publicarTransicion(Solicitud solicitud, HistorialTransicion hist, String accion,
                                    UserAccount actor, String observacion) {
        if (eventPublisher == null) {
            return;
        }
        UUID documentoVigenteId = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitud.getId())
                .map(com.capstone.sistema.doc.model.Documento::getId)
                .orElse(null);
        eventPublisher.publishEvent(new com.capstone.sistema.flow.event.TransicionSolicitudEvent(
                solicitud.getId(),
                hist.getId(),
                accion,
                hist.getEstadoOrigen() != null ? hist.getEstadoOrigen().getCodigo() : null,
                hist.getEstadoDestino() != null ? hist.getEstadoDestino().getCodigo() : null,
                hist.getFlujoEtapa() != null ? hist.getFlujoEtapa().getId() : null,
                solicitud.getFlujoEtapa() != null ? solicitud.getFlujoEtapa().getId() : null,
                documentoVigenteId,
                actor != null ? actor.getId() : null,
                false,
                java.util.List.of(),
                observacion
        ));
    }

    private String serializarMetadata(java.util.Map<String, Object> extra) {
        if (extra == null || extra.isEmpty()) {
            return "{}";
        }
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(extra);
        } catch (Exception e) {
            return "{}";
        }
    }
}

