package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Observacion;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class ObservacionRepository {

    private final HistorialTransicionRepository historialTransicionRepository;

    public ObservacionRepository(@Lazy HistorialTransicionRepository historialTransicionRepository) {
        this.historialTransicionRepository = historialTransicionRepository;
    }

    public List<Observacion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId) {
        if (historialTransicionRepository == null) return new ArrayList<>();
        List<HistorialTransicion> list = historialTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solicitudId);
        List<Observacion> result = new ArrayList<>();
        for (HistorialTransicion h : list) {
            if (h.getObservacion() != null && !h.getObservacion().trim().isEmpty()
                    && h.getAccion() != null
                    && ("SOLICITAR_CORRECCION".equals(h.getAccion().getCodigo()) || "PEDIR_CORRECCION".equals(h.getAccion().getCodigo()))) {
                Observacion obs = new Observacion();
                obs.setId(h.getId());
                obs.setSolicitud(h.getSolicitud());
                obs.setUsuario(h.getUsuario());
                obs.setContenido(h.getObservacion());
                obs.setResuelta(false);
                obs.setCreatedAt(h.getCreatedAt());
                result.add(obs);
            }
        }
        return result;
    }

    public List<Observacion> findBySolicitud_IdAndResueltaFalse(UUID solicitudId) {
        return findBySolicitud_IdOrderByCreatedAtAsc(solicitudId);
    }

    public List<Detalle> consultarDetalle(UUID solicitudId) {
        if (historialTransicionRepository == null) return new ArrayList<>();
        List<HistorialTransicion> list = historialTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solicitudId);
        List<Detalle> result = new ArrayList<>();
        for (HistorialTransicion h : list) {
            if (h.getObservacion() != null && !h.getObservacion().trim().isEmpty()
                    && h.getAccion() != null
                    && ("SOLICITAR_CORRECCION".equals(h.getAccion().getCodigo()) || "PEDIR_CORRECCION".equals(h.getAccion().getCodigo()))) {
                result.add(new Detalle() {
                    @Override public Long getId() { return h.getId(); }
                    @Override public String getContenido() { return h.getObservacion(); }
                    @Override public boolean getResuelta() { return false; }
                    @Override public String getUsuarioNombre() { return h.getUsuario() != null ? (h.getUsuario().getFirstName() != null ? h.getUsuario().getFirstName() : h.getUsuario().getNombre()) : ""; }
                    @Override public String getUsuarioApellido() { return h.getUsuario() != null ? h.getUsuario().getLastName() : ""; }
                    @Override public Instant getCreatedAt() { return h.getCreatedAt(); }
                    @Override public Long getTransicionId() { return h.getId(); }
                    @Override public Long getEtapaId() { return h.getFlujoEtapa() != null ? h.getFlujoEtapa().getId() : null; }
                    @Override public Integer getEtapaOrden() { return h.getFlujoEtapa() != null ? h.getFlujoEtapa().getOrden() : null; }
                    @Override public String getEtapaNombre() { return h.getFlujoEtapa() != null ? h.getFlujoEtapa().getNombre() : null; }
                });
            }
        }
        return result;
    }

    public Observacion save(Observacion obs) {
        return obs;
    }

    public <S extends Observacion> List<S> saveAll(Iterable<S> entities) {
        List<S> result = new ArrayList<>();
        entities.forEach(result::add);
        return result;
    }

    public interface Detalle {
        Long getId();
        String getContenido();
        boolean getResuelta();
        String getUsuarioNombre();
        String getUsuarioApellido();
        Instant getCreatedAt();
        Long getTransicionId();
        Long getEtapaId();
        Integer getEtapaOrden();
        String getEtapaNombre();
    }
}
