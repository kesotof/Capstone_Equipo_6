package com.capstone.sistema.notificacion.dto;

/**
 * F3 (§6.1): mensaje armado por {@code NotificacionMensajeFactory} para una notificación.
 *
 * @param titulo      asunto visible en la bandeja y del correo (máx. 255 caracteres)
 * @param mensaje     cuerpo en español de la notificación
 * @param enlace      ruta relativa de navegación; la URL absoluta es
 *                    {@code app.frontend-base-url + enlace} (CA 10.4)
 * @param accionTexto etiqueta del botón del correo (p. ej. «Revisar solicitud»)
 */
public record MensajeNotificacion(
        String titulo,
        String mensaje,
        String enlace,
        String accionTexto
) {
}
