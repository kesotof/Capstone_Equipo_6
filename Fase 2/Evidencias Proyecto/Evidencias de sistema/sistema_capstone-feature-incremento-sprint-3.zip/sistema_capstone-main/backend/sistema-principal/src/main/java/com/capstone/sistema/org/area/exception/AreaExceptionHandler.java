package com.capstone.sistema.org.area.exception;

import com.capstone.sistema.org.area.controller.AreaController;
import com.capstone.sistema.users.repository.AreaRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.net.URI;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(assignableTypes = AreaController.class)
public class AreaExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(AreaExceptionHandler.class);

    /** Índice único real en V1; se acepta el nombre legado por compatibilidad. */
    private static final Set<String> AREA_NAME_CONSTRAINTS = Set.of("uq_area_nombre", "uq_area_nombre_normalizado");

    private final AreaRepository areaRepository;

    public AreaExceptionHandler(@org.springframework.beans.factory.annotation.Autowired(required = false) AreaRepository areaRepository) {
        this.areaRepository = areaRepository;
    }

    @ExceptionHandler(AreaException.class)
    public ProblemDetail handleArea(AreaException exception, HttpServletRequest request) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(exception.getStatus(), exception.getMessage());
        problem.setTitle(exception.getTitle());
        problem.setProperty("codigo", exception.getCodigo());
        problem.setProperty("code", exception.getCodigo());
        problem.setProperty("mensaje", exception.getMessage());
        problem.setProperty("message", exception.getMessage());
        exception.getProperties().forEach(problem::setProperty);
        problem.setInstance(URI.create(request.getRequestURI()));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleParameter(MethodArgumentTypeMismatchException exception,
                                         HttpServletRequest request) {
        return handleArea(AreaException.invalidField(exception.getName(),
                "El parámetro tiene un formato inválido."), request);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(MethodArgumentNotValidException exception,
                                         HttpServletRequest request) {
        Map<String, String> fields = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error ->
                fields.putIfAbsent(error.getField(), error.getDefaultMessage()));
        return handleArea(new AreaException(HttpStatus.BAD_REQUEST, "AREA_DATOS_INVALIDOS",
                "Datos de área inválidos", "Revisa los campos enviados e inténtalo nuevamente.",
                Map.of("invalidFields", fields)), request);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ProblemDetail handleBody(HttpMessageNotReadableException exception, HttpServletRequest request) {
        return handleArea(new AreaException(HttpStatus.BAD_REQUEST, "AREA_DATOS_INVALIDOS",
                "Datos de área inválidos", "Envía un cuerpo JSON válido con los tipos de datos indicados.",
                Map.of()), request);
    }

    /**
     * Alta/edición concurrente con el mismo nombre: la carrera la resuelve el índice único
     * {@code uq_area_nombre} de V1 ({@code lower(btrim(nombre))}) → 409 AREA_NOMBRE_DUPLICADO.
     * Otras violaciones de integridad → 409 AREA_CONFLICTO (nunca se relanzan: eso produce un 500).
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ProblemDetail handleIntegrity(DataIntegrityViolationException exception, HttpServletRequest request) {
        if (isAreaNameViolation(exception)) {
            return handleArea(AreaException.duplicateName(), request);
        }
        log.warn("Violación de integridad no prevista en {}: {}", request.getRequestURI(),
                exception.getMostSpecificCause().getMessage());
        return handleArea(AreaException.conflict(
                "La operación entra en conflicto con datos existentes. Recarga la información e inténtalo nuevamente."),
                request);
    }

    private static boolean isAreaNameViolation(Throwable exception) {
        for (Throwable cause = exception; cause != null; cause = cause.getCause()) {
            String constraint = cause instanceof ConstraintViolationException violation
                    ? violation.getConstraintName() : null;
            if (constraint != null && AREA_NAME_CONSTRAINTS.contains(constraint.toLowerCase(Locale.ROOT))) {
                return true;
            }
            // Respaldo si el dialecto no extrae el nombre: el mensaje de PostgreSQL lo incluye entre comillas.
            String message = cause.getMessage();
            if (message != null && AREA_NAME_CONSTRAINTS.stream().anyMatch(name -> message.contains("\"" + name + "\""))) {
                return true;
            }
        }
        return false;
    }

    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
    public ProblemDetail handleConcurrentWrite(ObjectOptimisticLockingFailureException exception,
                                              HttpServletRequest request) {
        Map<String, Object> properties = new LinkedHashMap<>();
        // La transacción fallida ya fue revertida antes de entrar al advice.
        if (areaRepository != null && exception.getIdentifier() instanceof Long id) {
            areaRepository.findById(id).ifPresent(area -> properties.put("versionActual", area.getVersion()));
        }
        return handleArea(new AreaException(HttpStatus.CONFLICT, "AREA_MODIFICADA", "Área modificada",
                "El área cambió durante la operación. Recarga sus datos antes de editarla.", properties), request);
    }
}
