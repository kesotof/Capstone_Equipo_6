package com.capstone.sistema.notificacion.repository;

import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.notificacion.model.Notificacion;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

    @Query("SELECT n FROM Notificacion n WHERE n.destinatario.id = :destinatarioId ORDER BY n.createdAt DESC")
    List<Notificacion> findByDestinatario_IdOrderByCreatedEnDesc(@Param("destinatarioId") UUID destinatarioId);

    @Query("SELECT n FROM Notificacion n WHERE n.destinatario.id = :destinatarioId AND n.leidaEn IS NULL ORDER BY n.createdAt DESC")
    List<Notificacion> findByDestinatario_IdAndLeidaFalseOrderByCreatedEnDesc(@Param("destinatarioId") UUID destinatarioId);

    @Query("SELECT COUNT(n) FROM Notificacion n WHERE n.destinatario.id = :destinatarioId AND n.leidaEn IS NULL")
    long countByDestinatario_IdAndLeidaFalse(@Param("destinatarioId") UUID destinatarioId);

    /** F3 (§6.3): filtro opcional por categoría (US-36/CA 10.1-10.2), solo las no leídas. */
    @Query("SELECT n FROM Notificacion n WHERE n.destinatario.id = :destinatarioId AND n.tipoNotificacion.categoria = :categoria AND n.leidaEn IS NULL ORDER BY n.createdAt DESC")
    List<Notificacion> findByDestinatario_IdAndCategoriaAndLeidaFalse(@Param("destinatarioId") UUID destinatarioId,
                                                                      @Param("categoria") com.capstone.sistema.model.enums.CategoriaNotificacion categoria);

    /** F3 (§6.3): filtro opcional por categoría, todas. */
    @Query("SELECT n FROM Notificacion n WHERE n.destinatario.id = :destinatarioId AND n.tipoNotificacion.categoria = :categoria ORDER BY n.createdAt DESC")
    List<Notificacion> findByDestinatario_IdAndCategoria(@Param("destinatarioId") UUID destinatarioId,
                                                          @Param("categoria") com.capstone.sistema.model.enums.CategoriaNotificacion categoria);

    /**
     * F3 (§6.2): INSERT de una notificación con idempotencia por {@code clave_dedup}; devuelve
     * el id insertado o {@code null} cuando el ON CONFLICT descartó la fila. El SQL vive en
     * {@link #INSERTAR_IGNORANDO_DEDUP} como única fuente (los tests de F5 lo ejecutan a
     * través de JDBC contra la misma consulta).
     */
    @Query(value = INSERTAR_IGNORANDO_DEDUP, nativeQuery = true)
    Long insertarIgnorandoDedup(@Param("usuarioId") UUID usuarioId,
                                @Param("solicitudId") UUID solicitudId,
                                @Param("historialId") Long historialId,
                                @Param("tipoId") Long tipoId,
                                @Param("titulo") String titulo,
                                @Param("mensaje") String mensaje,
                                @Param("enlace") String enlace,
                                @Param("claveDedup") String claveDedup);

    /** F3 (§6.2): PENDIENTE + correo_publicado_en + correo_publicaciones = 1 en la misma transacción. */
    @Modifying
    @Query(value = """
            UPDATE notificacion
               SET estado_correo = 'PENDIENTE', correo_publicado_en = :ahora, correo_publicaciones = 1
             WHERE id = :id
            """, nativeQuery = true)
    void marcarCorreoPendiente(@Param("id") Long id, @Param("ahora") Instant ahora);

    /** F3 (§6.2/§6.4): bloqueo pesimista del estado del correo (la fila se toca solo por id). */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT n FROM Notificacion n WHERE n.id = :id")
    Optional<Notificacion> buscarParaActualizar(@Param("id") Long id);

    /** F3 (§6.4): cola del re-publicador; SKIP LOCKED permite varias instancias sin duplicar. */
    @Query(value = """
            SELECT * FROM notificacion
             WHERE estado_correo = 'PENDIENTE'
               AND (correo_publicado_en IS NULL OR correo_publicado_en < :umbral)
             ORDER BY id
             LIMIT :limite
             FOR UPDATE SKIP LOCKED
            """, nativeQuery = true)
    List<Notificacion> pendientesDeRepublicacion(@Param("umbral") Instant umbral, @Param("limite") int limite);

    /** F3 (§7.1): bandeja admin de correos por estado (FALLIDO/PENDIENTE). */
    Page<Notificacion> findByEstadoCorreo(EstadoCorreo estadoCorreo, Pageable pageable);

    /** F3 (§6.4): advisory lock de instancia única para el re-publicador de correos (41030, 1). */
    @Query(value = "SELECT pg_try_advisory_xact_lock(41030, 1)", nativeQuery = true)
    Boolean tryAdvisoryLockRepublicacion();

    // ---------------------------------------------------------------------------------
    // F5 (§6.4) — alertas de plazo
    // ---------------------------------------------------------------------------------

    /**
     * F3 (§6.2): INSERT idempotente con {@code clave_dedup}; única fuente del SQL (el test de
     * F5 lo ejecuta vía JDBC para probar el «segunda ejecución no duplica» sobre la consulta
     * real).
     */
    String INSERTAR_IGNORANDO_DEDUP = """
            INSERT INTO notificacion (usuario_id, solicitud_id, historial_transicion_id, tipo_notificacion_id,
                                      titulo, mensaje, created_at, enlace, clave_dedup)
            VALUES (:usuarioId, :solicitudId, :historialId, :tipoId, :titulo, :mensaje, now(), :enlace, :claveDedup)
            ON CONFLICT (clave_dedup) WHERE clave_dedup IS NOT NULL DO NOTHING
            RETURNING id
            """;

    /**
     * F5 (§6.4): candidatas a alerta de plazo — revisores de la <strong>etapa actual</strong>
     * ({@code v_revisor_solicitud} filtrada por {@code flujo_etapa_id} de la solicitud; los
     * revisores de etapas anteriores no aparecen), paginadas de a 200 por id. El umbral viene
     * del reloj inyectado ({@code deadline <= ahora + 24 h}: por vencer o ya vencidas), no de
     * {@code now()} de la BD, para que el job sea testeable con reloj fijo.
     */
    String CANDIDATAS_PLAZO = """
            SELECT s.id, s.deadline, rs.usuario_id
              FROM solicitud s
              JOIN v_revisor_solicitud rs ON rs.solicitud_id = s.id AND rs.flujo_etapa_id = s.flujo_etapa_id
             WHERE s.estado = 'PENDIENTE_REVISION'
               AND s.deadline IS NOT NULL
               AND s.deadline <= :umbral
               AND (:ultimoId IS NULL OR s.id > CAST(:ultimoId AS uuid))
             ORDER BY s.id
             LIMIT :limite
            """;

    @Query(value = CANDIDATAS_PLAZO, nativeQuery = true)
    List<Object[]> candidatasDePlazo(@Param("umbral") Instant umbral,
                                     @Param("ultimoId") UUID ultimoId,
                                     @Param("limite") int limite);

    /** F5 (§6.4): advisory lock de instancia única para el job de alertas de plazo (41030, 2). */
    @Query(value = "SELECT pg_try_advisory_xact_lock(41030, 2)", nativeQuery = true)
    Boolean tryAdvisoryLockPlazos();
}
