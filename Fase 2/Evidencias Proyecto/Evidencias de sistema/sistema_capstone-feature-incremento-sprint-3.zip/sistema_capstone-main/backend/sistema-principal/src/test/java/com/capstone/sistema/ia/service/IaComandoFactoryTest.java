package com.capstone.sistema.ia.service;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IaComandoFactoryTest {

    @Mock
    private IaTareaRepository iaTareaRepository;

    @InjectMocks
    private IaComandoFactory comandoFactory;

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    @DisplayName("crearComando para EVALUACION incluye documento, contexto e instrucción de criterio")
    void crearComando_evaluacion() {
        Solicitud s = mock(Solicitud.class);
        when(s.getCorrelativo()).thenReturn("SOL-001");
        when(s.getTitulo()).thenReturn("Solicitud de compras");
        when(s.getTipoDocumento()).thenReturn("Contrato");

        FlujoEtapa etapa = new FlujoEtapa(null, 1, "Revisión técnica");

        Documento doc = mock(Documento.class);
        when(doc.getStorageKey()).thenReturn("solicitudes/1/v1/contrato.pdf");
        when(doc.getNombreArchivo()).thenReturn("contrato.pdf");
        when(doc.getContentType()).thenReturn("application/pdf");
        when(doc.getVersion()).thenReturn(1);

        IaTarea tarea = new IaTarea(
                TipoTareaIa.EVALUACION,
                OrigenTareaIa.AUTOMATICO,
                s,
                doc,
                etapa,
                null,
                null,
                null,
                null,
                null,
                "Verificar cláusulas técnicas",
                "sha256fake",
                null
        );

        ComandoTareaIa comando = comandoFactory.crearComando(tarea);

        assertThat(comando.version()).isEqualTo(1);
        assertThat(comando.tipo()).isEqualTo("EVALUACION");
        assertThat(comando.instruccion()).isEqualTo("Verificar cláusulas técnicas");
        assertThat(comando.documento()).isNotNull();
        assertThat(comando.documento().bucket()).isEqualTo("documentos");
        assertThat(comando.documento().storageKey()).isEqualTo("solicitudes/1/v1/contrato.pdf");
        assertThat(comando.documento().nombreArchivo()).isEqualTo("contrato.pdf");
        assertThat(comando.documento().contentType()).isEqualTo("application/pdf");
        assertThat(comando.contexto()).isNotNull();
        assertThat(comando.contexto().correlativo()).isEqualTo("SOL-001");
        assertThat(comando.contexto().tipoDocumento()).isEqualTo("Contrato");
        assertThat(comando.contexto().etapa()).isEqualTo("Revisión técnica");
        assertThat(comando.historial()).isEmpty();
    }

    @Test
    @DisplayName("crearComando para CHAT incluye historial de hasta 6 pares en orden cronológico (antiguo a nuevo)")
    void crearComando_chat_historial() {
        Solicitud s = mock(Solicitud.class);
        when(s.getCorrelativo()).thenReturn("SOL-002");
        UUID solId = UUID.randomUUID();
        when(s.getId()).thenReturn(solId);

        Documento doc = mock(Documento.class);
        when(doc.getStorageKey()).thenReturn("solicitudes/2/v2/doc.pdf");
        when(doc.getNombreArchivo()).thenReturn("doc.pdf");
        when(doc.getContentType()).thenReturn("application/pdf");
        when(doc.getVersion()).thenReturn(2);

        UserAccount user = new UserAccount("kc-u", "u@test.cl", "Revisor", "Uno", true);

        IaTarea tActual = new IaTarea(
                TipoTareaIa.CHAT,
                OrigenTareaIa.MANUAL,
                s,
                doc,
                null,
                null,
                null,
                null,
                null,
                null,
                "¿Cuál es la vigencia?",
                "sha256pregunta",
                user
        );

        IaTarea t1 = new IaTarea(TipoTareaIa.CHAT, OrigenTareaIa.MANUAL, s, doc, null, null, null, null, null, null,
                "P1", "sha", user);
        t1.completar(mapper.createObjectNode().put("respuesta", "R1"), "modelo");

        IaTarea t2 = new IaTarea(TipoTareaIa.CHAT, OrigenTareaIa.MANUAL, s, doc, null, null, null, null, null, null,
                "P2", "sha", user);
        t2.completar(mapper.createObjectNode().put("respuesta", "R2"), "modelo");

        when(iaTareaRepository.findUltimosChatCompletados(eq(solId), any(Pageable.class)))
                .thenReturn(List.of(t2, t1));

        ComandoTareaIa comando = comandoFactory.crearComando(tActual);

        assertThat(comando.tipo()).isEqualTo("CHAT");
        assertThat(comando.instruccion()).isEqualTo("¿Cuál es la vigencia?");
        assertThat(comando.historial()).hasSize(2);
        assertThat(comando.historial().get(0).pregunta()).isEqualTo("P1");
        assertThat(comando.historial().get(0).respuesta()).isEqualTo("R1");
        assertThat(comando.historial().get(1).pregunta()).isEqualTo("P2");
        assertThat(comando.historial().get(1).respuesta()).isEqualTo("R2");
    }
}
