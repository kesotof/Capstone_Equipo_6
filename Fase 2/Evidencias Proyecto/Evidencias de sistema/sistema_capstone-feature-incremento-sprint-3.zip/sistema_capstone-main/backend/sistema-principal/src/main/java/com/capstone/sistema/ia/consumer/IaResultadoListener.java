package com.capstone.sistema.ia.consumer;

import com.capstone.sistema.ia.service.IaResultadoProcesador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ResultadoTareaIa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * F6 (§3.1, §6.10): consumidor de la cola {@code ia.tarea.resultado.q}.
 * Si el payload es estructuralmente inválido, lo rechaza sin re-encolar (va a DLQ).
 */
@Component
public class IaResultadoListener {

    private static final Logger log = LoggerFactory.getLogger(IaResultadoListener.class);

    private final IaResultadoProcesador procesador;

    public IaResultadoListener(IaResultadoProcesador procesador) {
        this.procesador = procesador;
    }

    @RabbitListener(queues = MensajeriaConfig.COLA_IA_RESULTADO)
    public void onResultado(ResultadoTareaIa resultado) {
        if (resultado == null || resultado.version() != 1 || resultado.tareaId() == null || resultado.estado() == null) {
            log.error("Mensaje inválido en cola de resultados de IA → rechazo a DLQ: {}", resultado);
            throw new AmqpRejectAndDontRequeueException("Payload inválido de ResultadoTareaIa");
        }
        try {
            procesador.aplicar(resultado);
        } catch (Exception e) {
            log.error("Error al procesar resultado de tarea IA {}: {}", resultado.tareaId(), e.getMessage(), e);
            throw e;
        }
    }
}
