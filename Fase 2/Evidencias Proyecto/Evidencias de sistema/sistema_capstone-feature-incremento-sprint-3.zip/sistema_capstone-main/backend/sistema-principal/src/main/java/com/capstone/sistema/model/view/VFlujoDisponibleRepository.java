package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VFlujoDisponibleRepository extends JpaRepository<VFlujoDisponible, Long> {

    List<VFlujoDisponible> findByAreaId(Long areaId);

    List<VFlujoDisponible> findByAreaIdIsNull();
}
