package com.capstone.sistema.mensajeria;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * F2: propiedades de infraestructura de mensajería (plan §6.0).
 * `exchange` y `dlx` son los nombres declarados en {@link MensajeriaConfig};
 * el bloque `republicador` lo usará {@code RepublicadorPendientes} (F5/F7).
 */
@ConfigurationProperties(prefix = "mensajeria")
public record MensajeriaProperties(
        String exchange,
        String dlx,
        Republicador republicador
) {

    public record Republicador(
            Duration intervalo,
            Duration umbralCorreo,
            Duration umbralIa,
            int maxPublicaciones
    ) {
    }
}
