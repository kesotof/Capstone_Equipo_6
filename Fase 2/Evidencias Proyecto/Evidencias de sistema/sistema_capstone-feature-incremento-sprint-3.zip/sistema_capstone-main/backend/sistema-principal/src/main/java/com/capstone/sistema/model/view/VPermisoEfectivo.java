package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.util.UUID;

@Entity
@Table(name = "v_permiso_efectivo")
@Immutable
public class VPermisoEfectivo {

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "usuario_id")
    private UUID usuarioId;

    @Column(name = "recurso")
    private String recurso;

    @Column(name = "accion")
    private String accion;

    @Column(name = "area_id")
    private Long areaId;

    @Column(name = "origen")
    private String origen;

    @Column(name = "rol_id")
    private Long rolId;

    @Column(name = "area_asignada_id")
    private Long areaAsignadaId;

    protected VPermisoEfectivo() {
    }

    public VPermisoEfectivo(String id, UUID usuarioId, String recurso, String accion, Long areaId, String origen, Long rolId, Long areaAsignadaId) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.recurso = recurso;
        this.accion = accion;
        this.areaId = areaId;
        this.origen = origen;
        this.rolId = rolId;
        this.areaAsignadaId = areaAsignadaId;
    }

    public VPermisoEfectivo(UUID usuarioId, String recurso, String accion, Long areaId, String origen, Long rolId, Long areaAsignadaId) {
        this(java.util.UUID.randomUUID().toString(), usuarioId, recurso, accion, areaId, origen, rolId, areaAsignadaId);
    }

    public String getId() {
        return id;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public String getRecurso() {
        return recurso;
    }

    public String getAccion() {
        return accion;
    }

    public Long getAreaId() {
        return areaId;
    }

    public String getOrigen() {
        return origen;
    }

    public Long getRolId() {
        return rolId;
    }

    public Long getAreaAsignadaId() {
        return areaAsignadaId;
    }
}
