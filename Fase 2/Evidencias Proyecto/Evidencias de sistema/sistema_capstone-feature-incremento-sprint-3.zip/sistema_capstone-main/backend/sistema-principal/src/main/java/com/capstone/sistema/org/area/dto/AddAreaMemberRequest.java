package com.capstone.sistema.org.area.dto;

import jakarta.validation.constraints.NotNull;
import java.util.UUID;

public record AddAreaMemberRequest(
        @NotNull(message = "El id del usuario es obligatorio.")
        UUID usuarioId,
        boolean esJefeArea
) {}
