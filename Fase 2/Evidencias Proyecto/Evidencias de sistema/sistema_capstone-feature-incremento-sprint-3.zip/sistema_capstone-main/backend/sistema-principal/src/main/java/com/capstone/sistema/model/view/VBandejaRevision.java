package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "v_bandeja_revision")
@IdClass(VBandejaRevisionId.class)
@Immutable
public class VBandejaRevision {

    @Id
    @Column(name = "revisor_id")
    private UUID revisorId;

    @Id
    @Column(name = "solicitud_id")
    private UUID solicitudId;

    @Column(name = "correlativo")
    private String correlativo;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "emisor_id")
    private UUID emisorId;

    @Column(name = "area_id")
    private Long areaId;

    @Column(name = "tipo_documento_id")
    private Long tipoDocumentoId;

    @Column(name = "flujo_etapa_id")
    private Long flujoEtapaId;

    @Column(name = "deadline")
    private Instant deadline;

    @Column(name = "created_at")
    private Instant createdAt;

    protected VBandejaRevision() {
    }

    public UUID getRevisorId() {
        return revisorId;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public String getCorrelativo() {
        return correlativo;
    }

    public String getTitulo() {
        return titulo;
    }

    public UUID getEmisorId() {
        return emisorId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public Long getTipoDocumentoId() {
        return tipoDocumentoId;
    }

    public Long getFlujoEtapaId() {
        return flujoEtapaId;
    }

    public Instant getDeadline() {
        return deadline;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
