package com.capstone.sistema.flow.repository;

import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.flow.model.SlaConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class SlaConfigRepository {

    private final TipoDocumentoRepository tipoDocumentoRepository;

    public SlaConfigRepository(@Autowired(required = false) TipoDocumentoRepository tipoDocumentoRepository) {
        this.tipoDocumentoRepository = tipoDocumentoRepository;
    }

    public Optional<SlaConfig> findByTipoDocumentoIgnoreCase(String tipoDocumento) {
        if (tipoDocumento == null || tipoDocumento.isBlank()) return Optional.empty();
        if (tipoDocumentoRepository != null) {
            return tipoDocumentoRepository.findByNombreIgnoreCaseAndActivoTrue(tipoDocumento.trim())
                    .map(this::toModel);
        }
        return Optional.of(new SlaConfig(1L, tipoDocumento, 5));
    }

    public boolean existsByTipoDocumentoIgnoreCase(String tipoDocumento) {
        if (tipoDocumento == null || tipoDocumento.isBlank()) return false;
        if (tipoDocumentoRepository != null) {
            return tipoDocumentoRepository.existsByNombreIgnoreCaseAndActivoTrue(tipoDocumento.trim());
        }
        return false;
    }

    public boolean existsByTipoDocumentoIgnoreCaseAndIdNot(String tipoDocumento, Long id) {
        if (tipoDocumento == null || tipoDocumento.isBlank()) return false;
        if (tipoDocumentoRepository != null && id != null) {
            return tipoDocumentoRepository.existsByNombreIgnoreCaseAndActivoTrueAndIdNot(tipoDocumento.trim(), id);
        }
        return false;
    }

    public List<SlaConfig> findAll() {
        if (tipoDocumentoRepository != null) {
            return tipoDocumentoRepository.findAll().stream()
                    .filter(TipoDocumento::isActivo)
                    .map(this::toModel)
                    .toList();
        }
        return new ArrayList<>();
    }

    public Optional<SlaConfig> findById(Long id) {
        if (id == null) return Optional.empty();
        if (tipoDocumentoRepository != null) {
            return tipoDocumentoRepository.findById(id).map(this::toModel);
        }
        return Optional.empty();
    }

    public SlaConfig save(SlaConfig config) {
        return saveAndFlush(config);
    }

    public SlaConfig saveAndFlush(SlaConfig config) {
        if (tipoDocumentoRepository != null) {
            TipoDocumento td;
            if (config.getId() != null) {
                td = tipoDocumentoRepository.findById(config.getId())
                        .orElseGet(() -> createFromConfig(config));
                td.setNombre(config.getTipoDocumento());
                td.setPlazoDiasHabiles(config.getPlazoDias());
                td.setActivo(true);
            } else {
                Optional<TipoDocumento> existing = tipoDocumentoRepository.findByNombreIgnoreCase(config.getTipoDocumento().trim());
                if (existing.isPresent()) {
                    td = existing.get();
                    td.setActivo(true);
                    td.setPlazoDiasHabiles(config.getPlazoDias());
                } else {
                    td = createFromConfig(config);
                }
            }
            TipoDocumento saved = tipoDocumentoRepository.saveAndFlush(td);
            return toModel(saved);
        }
        return config;
    }

    public void deleteById(Long id) {
        if (tipoDocumentoRepository != null && id != null) {
            tipoDocumentoRepository.findById(id).ifPresent(td -> {
                td.setActivo(false);
                tipoDocumentoRepository.saveAndFlush(td);
            });
        }
    }

    public void delete(SlaConfig entity) {
        if (entity != null && entity.getId() != null) {
            deleteById(entity.getId());
        }
    }

    private SlaConfig toModel(TipoDocumento td) {
        SlaConfig c = new SlaConfig(td.getId(), td.getNombre(), td.getPlazoDiasHabiles());
        if (td.getCreatedAt() != null) c.setCreatedAt(td.getCreatedAt());
        if (td.getUpdatedAt() != null) c.setUpdatedAt(td.getUpdatedAt());
        return c;
    }

    private TipoDocumento createFromConfig(SlaConfig config) {
        String prefijo = generatePrefijo(config.getTipoDocumento());
        return new TipoDocumento(config.getTipoDocumento(), config.getTipoDocumento(), prefijo, config.getPlazoDias());
    }

    private String generatePrefijo(String nombre) {
        if (nombre == null || nombre.isBlank()) return "DOC";
        String clean = nombre.replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
        if (clean.length() > 5) clean = clean.substring(0, 5);
        if (clean.length() < 3) clean = (clean + "DOC").substring(0, 3);
        String candidate = clean;
        int count = 1;
        while (tipoDocumentoRepository != null && tipoDocumentoRepository.existsByPrefijoIgnoreCase(candidate)) {
            candidate = clean.substring(0, Math.min(clean.length(), 3)) + count;
            count++;
        }
        return candidate;
    }
}
