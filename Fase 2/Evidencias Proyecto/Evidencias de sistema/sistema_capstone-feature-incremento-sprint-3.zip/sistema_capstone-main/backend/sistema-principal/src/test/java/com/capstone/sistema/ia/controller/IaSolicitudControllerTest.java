package com.capstone.sistema.ia.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.dto.IaMensajeChatDto;
import com.capstone.sistema.ia.dto.PreguntaChatRequest;
import com.capstone.sistema.ia.exception.IaExceptionHandler;
import com.capstone.sistema.ia.service.IaChatService;
import com.capstone.sistema.ia.service.IaTareaService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(IaSolicitudController.class)
@Import({SecurityConfig.class, IaExceptionHandler.class})
class IaSolicitudControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IaTareaService iaTareaService;

    @MockBean
    private IaChatService iaChatService;

    @MockBean
    private CurrentUserResolver currentUserResolver;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    private final UUID solicitudId = UUID.randomUUID();
    private final UUID tareaId = UUID.randomUUID();
    private final UserAccount usuario = new UserAccount("kc-user", "user@test.cl", "Usuario", "Test", true);

    @BeforeEach
    void setUp() {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuario));
    }

    @Test
    @DisplayName("GET /api/solicitudes/{id}/ia/evaluaciones retorna 200 con lista")
    void listarEvaluaciones() throws Exception {
        IaEvaluacionDto dto = new IaEvaluacionDto(
                tareaId, "COMPLETADA", "AUTOMATICO",
                new IaEvaluacionDto.EtapaDto(1L, "Etapa 1"),
                new IaEvaluacionDto.DocumentoDto(UUID.randomUUID(), 1, "doc.pdf"),
                "Criterio", null, null, null, "modelo", true,
                Instant.now(), Instant.now(), IaEvaluacionDto.AVISO_LEGAL
        );
        when(iaTareaService.consultarEvaluaciones(eq(solicitudId), any())).thenReturn(List.of(dto));

        mockMvc.perform(get("/api/solicitudes/{id}/ia/evaluaciones", solicitudId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(tareaId.toString()))
                .andExpect(jsonPath("$[0].estado").value("COMPLETADA"))
                .andExpect(jsonPath("$[0].vigente").value(true));
    }

    @Test
    @DisplayName("POST /api/solicitudes/{id}/ia/evaluaciones retorna 202 Accepted")
    void reejecutarEvaluacion() throws Exception {
        IaEvaluacionDto dto = new IaEvaluacionDto(
                tareaId, "PENDIENTE", "MANUAL",
                null, null, "Criterio", null, null, null, null, true,
                Instant.now(), null, IaEvaluacionDto.AVISO_LEGAL
        );
        when(iaTareaService.crearEvaluacionManual(eq(solicitudId), any())).thenReturn(dto);

        mockMvc.perform(post("/api/solicitudes/{id}/ia/evaluaciones", solicitudId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.id").value(tareaId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.origen").value("MANUAL"));
    }

    @Test
    @DisplayName("GET /api/solicitudes/{id}/ia/chat retorna 200 con mensajes")
    void listarChat() throws Exception {
        IaMensajeChatDto msg = new IaMensajeChatDto(
                tareaId, "COMPLETADA", "¿Pregunta?", "Respuesta",
                new IaMensajeChatDto.AutorDto(usuario.getId(), "Usuario Test"),
                1, null, Instant.now(), Instant.now()
        );
        when(iaChatService.consultarChat(eq(solicitudId), any())).thenReturn(List.of(msg));

        mockMvc.perform(get("/api/solicitudes/{id}/ia/chat", solicitudId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(tareaId.toString()))
                .andExpect(jsonPath("$[0].pregunta").value("¿Pregunta?"))
                .andExpect(jsonPath("$[0].respuesta").value("Respuesta"));
    }

    @Test
    @DisplayName("POST /api/solicitudes/{id}/ia/chat retorna 202 Accepted")
    void enviarPregunta() throws Exception {
        PreguntaChatRequest req = new PreguntaChatRequest("¿Cuál es el monto?");
        IaMensajeChatDto msg = new IaMensajeChatDto(
                tareaId, "PENDIENTE", "¿Cuál es el monto?", null,
                new IaMensajeChatDto.AutorDto(usuario.getId(), "Usuario Test"),
                1, null, Instant.now(), null
        );
        when(iaChatService.crearChat(eq(solicitudId), any(), eq("¿Cuál es el monto?"))).thenReturn(msg);

        mockMvc.perform(post("/api/solicitudes/{id}/ia/chat", solicitudId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER")))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.id").value(tareaId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.pregunta").value("¿Cuál es el monto?"));
    }

    @Test
    @DisplayName("GET /api/solicitudes/{id}/ia/tareas/{tareaId} retorna 200")
    void consultarTarea() throws Exception {
        IaEvaluacionDto dto = new IaEvaluacionDto(
                tareaId, "COMPLETADA", "AUTOMATICO",
                null, null, "Criterio", null, null, null, "modelo", true,
                Instant.now(), Instant.now(), IaEvaluacionDto.AVISO_LEGAL
        );
        when(iaTareaService.consultarTarea(eq(solicitudId), eq(tareaId), any())).thenReturn(dto);

        mockMvc.perform(get("/api/solicitudes/{id}/ia/tareas/{tareaId}", solicitudId, tareaId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(tareaId.toString()))
                .andExpect(jsonPath("$.estado").value("COMPLETADA"));
    }
}
