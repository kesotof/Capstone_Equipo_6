package com.capstone.sistema.org.area.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.org.area.dto.AddAreaMemberRequest;
import com.capstone.sistema.org.area.dto.AreaMemberResponse;
import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.CreateAreaRequest;
import com.capstone.sistema.org.area.dto.PaginaAreasResponse;
import com.capstone.sistema.org.area.dto.ToggleAreaStatusRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaMemberRoleRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.exception.AreaException;
import com.capstone.sistema.org.area.model.AreaJefatura;
import com.capstone.sistema.org.area.repository.AreaJefaturaRepository;
import com.capstone.sistema.rbac.dto.RbacDtos.JefaturaItem;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Catálogo de áreas, miembros y jefaturas (AREA_JEFATURA).
 *
 * <p>Auditoría: un evento por acción de negocio, con nombres legibles en el detalle.
 * <ul>
 *   <li>CREAR_AREA / ACTUALIZAR_AREA / ACTIVAR_AREA / DESACTIVAR_AREA — entidad 'area'.</li>
 *   <li>ASIGNAR_ADMIN_AREA — campo legado {@code administradorId} (alta/edición del área), entidad 'area'.</li>
 *   <li>JEFATURA_ASIGNADA / JEFATURA_REMOVIDA — una por usuario afectado, entidad 'area'.</li>
 *   <li>CAMBIAR_AREA_USUARIO — cambio de área de un usuario (miembros), entidad 'usuario'.</li>
 * </ul>
 * Los eventos con resultado EXITO se escriben solo si la transacción confirma (ver {@link AuditService}).
 *
 * <p>Autorización: la aplica {@code AreaController} con permisos v5 (AREA.GESTIONAR / USUARIO.GESTIONAR, D-15).
 */
@Service
public class AreaService {

    private static final String SIN_AREA = "Sin área";

    private final AreaRepository areaRepository;
    private final UserAccountRepository userAccountRepository;
    private final AreaCatalogLock catalogLock;
    private final AreaUsageChecker usageChecker;
    private final AuditService auditService;
    private final EntityManager entityManager;
    private final RbacManagementService rbac;
    private final AreaJefaturaRepository areaJefaturaRepository;

    public AreaService(AreaRepository areaRepository, UserAccountRepository userAccountRepository,
                       AreaCatalogLock catalogLock, AreaUsageChecker usageChecker,
                       AuditService auditService, EntityManager entityManager,
                       RbacManagementService rbac, AreaJefaturaRepository areaJefaturaRepository) {
        this.areaRepository = areaRepository;
        this.userAccountRepository = userAccountRepository;
        this.catalogLock = catalogLock;
        this.usageChecker = usageChecker;
        this.auditService = auditService;
        this.entityManager = entityManager;
        this.rbac = rbac;
        this.areaJefaturaRepository = areaJefaturaRepository;
    }

    @Transactional(readOnly = true)
    public PaginaAreasResponse list(int page, int size, Boolean activo, String q) {
        if (page < 0) {
            throw AreaException.invalidField("page", "La página no puede ser negativa.");
        }
        if (size < 1 || size > 100) {
            throw AreaException.invalidField("size", "El tamaño de página debe estar entre 1 y 100.");
        }
        if (q != null && (length(q) > 100 || q.indexOf('\0') >= 0)) {
            throw AreaException.invalidField("q",
                    "La búsqueda admite hasta 100 caracteres y no admite el carácter nulo.");
        }
        String pattern = q == null || q.isBlank() ? "%"
                : "%" + q.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%";
        // JPA limita el offset a int, aunque el contrato permite cualquier página int positiva.
        if ((long) page * size > Integer.MAX_VALUE) {
            long total = areaRepository.countCatalog(activo, pattern);
            int totalPages = (int) Math.min(Integer.MAX_VALUE, (total + size - 1) / size);
            return new PaginaAreasResponse(List.of(), page, size, total, totalPages, false, true);
        }
        var result = areaRepository.findCatalogPage(activo, pattern, PageRequest.of(page, size));
        List<Long> areaIds = result.getContent().stream().map(Area::getId).toList();
        Map<Long, Long> counts = new HashMap<>();
        Map<Long, UserAccount> admins = new HashMap<>();
        if (!areaIds.isEmpty()) {
            List<Object[]> rows = userAccountRepository.countUsersByAreaIds(areaIds);
            for (Object[] row : rows) {
                counts.put((Long) row[0], ((Number) row[1]).longValue());
            }
            for (Long aid : areaIds) {
                UserAccount jefe = primeraJefatura(aid);
                if (jefe != null) {
                    admins.put(aid, jefe);
                }
            }
        }
        return new PaginaAreasResponse(
                result.getContent().stream()
                        .map(a -> toResponse(a, counts.getOrDefault(a.getId(), 0L), admins.get(a.getId())))
                        .toList(),
                result.getNumber(), result.getSize(), result.getTotalElements(), result.getTotalPages(),
                result.isFirst(), result.isLast());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse create(CreateAreaRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        String name = normalizeName(request.nombre());
        String description = normalizeDescription(request.descripcion());
        validateParentId(request.areaPadreId());
        if (areaRepository.existsNombreNormalizado(name)) {
            throw AreaException.duplicateName();
        }
        Area parent = findParent(request.areaPadreId());
        validateHierarchy(null, parent, true);
        UserAccount admin = request.administradorId() != null ? findAdminUser(request.administradorId()) : null;

        Area area = new Area(name);
        area.setDescripcion(description);
        area.setAreaPadre(parent);
        areaRepository.saveAndFlush(area);
        entityManager.refresh(area);

        String movimientoAdmin = null;
        if (admin != null) {
            addJefatura(area, admin);
            movimientoAdmin = moverUsuarioSiCorresponde(admin, area);
            admin.bumpVersionAcceso();
            userAccountRepository.save(admin);
        }
        rbac.finishMutation(securityBefore);

        auditService.registerAuditEvent("CREAR_AREA", "area", String.valueOf(area.getId()), "EXITO",
                "Área '" + area.getNombre() + "' creada"
                        + (parent != null ? " bajo '" + parent.getNombre() + "'" : "") + ".");
        if (admin != null) {
            auditService.registerAuditEvent("ASIGNAR_ADMIN_AREA", "area", String.valueOf(area.getId()), "EXITO",
                    "Área '" + area.getNombre() + "': administrador " + etiqueta(null) + " → " + etiqueta(admin)
                            + (movimientoAdmin != null ? "; " + movimientoAdmin : "") + ".");
        }
        area.setAdministrador(admin);
        return toResponse(area, 0L, admin);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse update(Long id, UpdateAreaRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(id);
        validateVersion(area, request.version());
        String name = normalizeName(request.nombre());
        String description = normalizeDescription(request.descripcion());
        validateParentId(request.areaPadreId());
        if (areaRepository.existsNombreNormalizadoExcluding(name, id)) {
            throw AreaException.duplicateName();
        }
        Area parent = findParent(request.areaPadreId());
        boolean parentChanged = !Objects.equals(parentId(area), request.areaPadreId());
        validateHierarchy(id, parent, area.isActivo() || parentChanged);

        var changedFields = new ArrayList<String>();
        if (!Objects.equals(area.getNombre(), name)) {
            area.setNombre(name);
            changedFields.add("nombre");
        }
        if (!Objects.equals(area.getDescripcion(), description)) {
            area.setDescripcion(description);
            changedFields.add("descripcion");
        }
        if (parentChanged) {
            area.setAreaPadre(parent);
            changedFields.add("areaPadreId");
        }

        // administradorId (legado): reemplaza las jefaturas del área por el usuario indicado (o ninguna).
        List<AreaJefatura> jefaturasActuales = areaJefaturaRepository.findByAreaId(id);
        UserAccount currentAdmin = jefaturasActuales.isEmpty() ? null : jefaturasActuales.get(0).getUsuario();
        UUID currentAdminId = currentAdmin != null ? currentAdmin.getId() : null;
        UserAccount finalAdmin = currentAdmin;
        String detalleAdmin = null;
        if (!Objects.equals(currentAdminId, request.administradorId())) {
            UserAccount newAdmin = request.administradorId() != null ? findAdminUser(request.administradorId()) : null;
            Set<UUID> conservar = newAdmin != null ? Set.of(newAdmin.getId()) : Set.of();
            for (AreaJefatura jefatura : jefaturasActuales) {
                if (!conservar.contains(jefatura.getUsuarioId())) {
                    areaJefaturaRepository.delete(jefatura);
                    bumpAcceso(jefatura.getUsuario());
                }
            }
            String movimientoAdmin = null;
            if (newAdmin != null) {
                if (jefaturasActuales.stream().noneMatch(j -> newAdmin.getId().equals(j.getUsuarioId()))) {
                    addJefatura(area, newAdmin);
                }
                movimientoAdmin = moverUsuarioSiCorresponde(newAdmin, area);
                bumpAcceso(newAdmin);
            }
            finalAdmin = newAdmin;
            changedFields.add("administradorId");
            detalleAdmin = "Área '" + name + "': administrador " + etiqueta(currentAdmin) + " → " + etiqueta(newAdmin)
                    + (movimientoAdmin != null ? "; " + movimientoAdmin : "") + ".";
        }

        if (!changedFields.isEmpty()) {
            flushAndRefresh(area);
        }
        rbac.finishMutation(securityBefore);

        List<String> camposArea = changedFields.stream().filter(f -> !"administradorId".equals(f)).toList();
        if (!camposArea.isEmpty()) {
            auditService.registerAuditEvent("ACTUALIZAR_AREA", "area", String.valueOf(id), "EXITO",
                    "Área '" + area.getNombre() + "' actualizada; campos: " + String.join(", ", camposArea) + ".");
        }
        if (detalleAdmin != null) {
            auditService.registerAuditEvent("ASIGNAR_ADMIN_AREA", "area", String.valueOf(id), "EXITO", detalleAdmin);
        }
        area.setAdministrador(finalAdmin);
        return toResponse(area, 0L, finalAdmin);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaResponse changeStatus(Long id, ToggleAreaStatusRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(id);
        validateVersion(area, request.version());
        if (request.activo() == null) {
            throw AreaException.invalidField("activo", "El estado activo es obligatorio.");
        }
        if (area.isActivo() == request.activo()) {
            return toResponse(area);
        }
        if (request.activo()) {
            validateHierarchy(id, area.getAreaPadre(), true);
        } else {
            var dependencies = usageChecker.findDependencies(id);
            if (dependencies.isInUse()) {
                throw new AreaException(HttpStatus.CONFLICT, "AREA_EN_USO", "Área en uso",
                        "Resuelve las dependencias del área antes de desactivarla.",
                        Map.of("dependencias", dependencies.asMap()));
            }
        }
        area.setActivo(request.activo());
        flushAndRefresh(area);
        rbac.finishMutation(securityBefore);
        auditService.registerAuditEvent(request.activo() ? "ACTIVAR_AREA" : "DESACTIVAR_AREA", "area",
                String.valueOf(id), "EXITO",
                "Área '" + area.getNombre() + "' " + (request.activo() ? "activada" : "desactivada") + ".");
        return toResponse(area);
    }

    private void flushAndRefresh(Area area) {
        areaRepository.flush();
        // La respuesta usa la precisión real persistida, incluso en tablas legacy.
        entityManager.refresh(area);
    }

    private Area findArea(Long id) {
        if (id == null || id <= 0) {
            throw AreaException.invalidField("id", "El ID del área debe ser positivo.");
        }
        return areaRepository.findById(id).orElseThrow(() -> new AreaException(HttpStatus.NOT_FOUND,
                "AREA_NO_ENCONTRADA", "Área no encontrada", "No existe el área indicada.", Map.of()));
    }

    private Area findParent(Long id) {
        return id == null ? null : areaRepository.findById(id).orElseThrow(() -> new AreaException(
                HttpStatus.NOT_FOUND, "AREA_PADRE_NO_ENCONTRADA", "Área padre no encontrada",
                "No existe el área padre indicada.", Map.of()));
    }

    private void validateHierarchy(Long areaId, Area parent, boolean requireActive) {
        Set<Long> visited = new HashSet<>();
        boolean inactiveAncestor = false;
        for (Area ancestor = parent; ancestor != null; ancestor = ancestor.getAreaPadre()) {
            if (Objects.equals(ancestor.getId(), areaId) || !visited.add(ancestor.getId())) {
                throw AreaException.invalidHierarchy();
            }
            inactiveAncestor |= !ancestor.isActivo();
        }
        if (requireActive && inactiveAncestor) {
            throw new AreaException(HttpStatus.CONFLICT, "AREA_PADRE_INACTIVA", "Área padre inactiva",
                    "El padre y todos sus ancestros deben estar activos.", Map.of());
        }
    }

    private void validateVersion(Area area, Long version) {
        if (version == null || version < 0) {
            throw AreaException.invalidField("version", "Envía una versión no negativa.");
        }
        if (!Objects.equals(area.getVersion(), version)) {
            throw new AreaException(HttpStatus.CONFLICT, "AREA_MODIFICADA", "Área modificada",
                    "El área cambió desde tu última consulta. Recarga sus datos antes de editarla.",
                    Map.of("versionActual", area.getVersion()));
        }
    }

    private void validateParentId(Long id) {
        if (id != null && id <= 0) {
            throw AreaException.invalidField("areaPadreId", "El ID del padre debe ser positivo.");
        }
    }

    private String normalizeName(String input) {
        String name = trimSpaces(input);
        if (name == null || name.isEmpty() || length(name) > 100
                || name.codePoints().anyMatch(Character::isISOControl)) {
            throw AreaException.invalidField("nombre",
                    "El nombre debe tener entre 1 y 100 caracteres, sin caracteres de control.");
        }
        return name;
    }

    private String normalizeDescription(String input) {
        String description = trimSpaces(input);
        if (description != null && (length(description) > 1000 || description.indexOf('\0') >= 0)) {
            throw AreaException.invalidField("descripcion",
                    "La descripción admite hasta 1000 caracteres y no admite el carácter nulo.");
        }
        return description == null || description.isEmpty() ? null : description;
    }

    private static String trimSpaces(String value) {
        if (value == null) {
            return null;
        }
        int start = 0;
        int end = value.length();
        while (start < end && value.charAt(start) == ' ') {
            start++;
        }
        while (end > start && value.charAt(end - 1) == ' ') {
            end--;
        }
        return value.substring(start, end);
    }

    private static int length(String value) {
        return value.codePointCount(0, value.length());
    }

    private UserAccount findAdminUser(UUID id) {
        UserAccount user = userAccountRepository.findById(id).orElseThrow(() ->
                AreaException.invalidField("administradorId", "El usuario indicado para administrador no existe."));
        if (!user.isEnabled()) {
            throw AreaException.usuarioInactivo();
        }
        return user;
    }

    private static Long parentId(Area area) {
        return area.getAreaPadre() == null ? null : area.getAreaPadre().getId();
    }

    @Transactional(readOnly = true)
    public List<AreaMemberResponse> listMembers(Long areaId) {
        findArea(areaId);
        List<UserAccount> members = userAccountRepository.findByAreaIdOrderByEmailAsc(areaId);
        Set<UUID> jefaturaIds = jefaturaIds(areaId);
        Set<UUID> memberIds = new HashSet<>();
        List<AreaMemberResponse> responses = new ArrayList<>();

        for (UserAccount u : members) {
            memberIds.add(u.getId());
            responses.add(toMemberResponse(u, jefaturaIds.contains(u.getId())));
        }
        // Las jefaturas no exigen membresía (S-07): se listan aunque pertenezcan a otra área.
        for (AreaJefatura jefatura : areaJefaturaRepository.findByAreaId(areaId)) {
            UserAccount jefe = jefatura.getUsuario();
            if (jefe != null && !memberIds.contains(jefe.getId())) {
                responses.add(toMemberResponse(jefe, true));
            }
        }

        responses.sort((a, b) -> {
            if (a.esJefeArea() != b.esJefeArea()) return Boolean.compare(b.esJefeArea(), a.esJefeArea());
            return a.nombre().compareToIgnoreCase(b.nombre());
        });
        return responses;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaMemberResponse addMember(Long areaId, AddAreaMemberRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(areaId);
        if (!area.isActivo()) {
            throw AreaException.invalidField("areaId", "No se pueden agregar miembros a un área inactiva.");
        }
        UserAccount user = userAccountRepository.findById(request.usuarioId()).orElseThrow(() ->
                AreaException.invalidField("usuarioId", "El usuario especificado no existe."));
        if (!user.isEnabled()) {
            throw AreaException.usuarioInactivo();
        }

        Area previousArea = user.getArea();
        boolean areaChanged = previousArea == null || !Objects.equals(previousArea.getId(), area.getId());
        String previousAreaName = nombreArea(previousArea);
        boolean esJefe = request.esJefeArea();
        boolean jefaturaNueva = esJefe && !esJefatura(areaId, user.getId());

        if (areaChanged) {
            user.setArea(area);
        }
        if (jefaturaNueva) {
            addJefatura(area, user);
        }
        if (areaChanged || jefaturaNueva) {
            user.bumpVersionAcceso();
            userAccountRepository.save(user);
        }
        rbac.finishMutation(securityBefore);

        if (areaChanged) {
            auditCambioArea(user, previousAreaName, area.getNombre());
        }
        if (jefaturaNueva) {
            auditJefatura("JEFATURA_ASIGNADA", area, user);
        }
        return toMemberResponse(user, esJefe || esJefatura(areaId, user.getId()));
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AreaMemberResponse updateMemberRole(Long areaId, UUID usuarioId, UpdateAreaMemberRoleRequest request) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(areaId);
        UserAccount user = userAccountRepository.findById(usuarioId).orElseThrow(() ->
                AreaException.invalidField("usuarioId", "El usuario especificado no existe."));
        if (!user.isEnabled()) {
            throw AreaException.usuarioInactivo();
        }
        if (user.getArea() == null || !user.getArea().getId().equals(areaId)) {
            throw AreaException.invalidField("usuarioId", "El usuario no pertenece a esta área.");
        }

        boolean currentIsJefe = esJefatura(areaId, usuarioId);
        String evento = null;
        if (request.esJefeArea() && !currentIsJefe) {
            addJefatura(area, user);
            evento = "JEFATURA_ASIGNADA";
        } else if (!request.esJefeArea() && currentIsJefe) {
            removeJefatura(areaId, usuarioId);
            evento = "JEFATURA_REMOVIDA";
        }
        if (evento != null) {
            user.bumpVersionAcceso();
            userAccountRepository.save(user);
        }
        rbac.finishMutation(securityBefore);

        if (evento != null) {
            auditJefatura(evento, area, user);
        }
        return toMemberResponse(user, request.esJefeArea());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeMember(Long areaId, UUID usuarioId) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(areaId);
        UserAccount user = userAccountRepository.findById(usuarioId).orElseThrow(() ->
                AreaException.invalidField("usuarioId", "El usuario especificado no existe."));
        if (user.getArea() == null || !user.getArea().getId().equals(areaId)) {
            throw AreaException.invalidField("usuarioId", "El usuario no pertenece a esta área.");
        }

        boolean eraJefe = esJefatura(areaId, usuarioId);
        if (eraJefe) {
            removeJefatura(areaId, usuarioId);
        }
        user.setArea(null);
        user.bumpVersionAcceso();
        userAccountRepository.save(user);
        rbac.finishMutation(securityBefore);

        if (eraJefe) {
            auditJefatura("JEFATURA_REMOVIDA", area, user);
        }
        auditCambioArea(user, area.getNombre(), SIN_AREA);
    }

    /**
     * PUT /api/areas/{id}/jefaturas: reemplaza la lista de jefaturas del área (no exige membresía, S-07).
     * Usuario inexistente → 400 AREA_DATOS_INVALIDOS; usuario inactivo → 422 USUARIO_INACTIVO;
     * versión desactualizada → 409 AREA_CONFLICTO.
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public List<JefaturaItem> updateJefaturas(Long areaId, List<UUID> usuarioIds, Long requestedVersion) {
        catalogLock.acquire();
        var securityBefore = rbac.prepareMutation();
        Area area = findArea(areaId);
        if (requestedVersion != null && !Objects.equals(area.getLockVersion(), requestedVersion)) {
            throw AreaException.conflict("La versión del área está desactualizada.");
        }
        Map<UUID, UserAccount> solicitados = new LinkedHashMap<>();
        if (usuarioIds != null) {
            for (UUID uid : new LinkedHashSet<>(usuarioIds)) {
                UserAccount u = userAccountRepository.findById(uid).orElseThrow(() ->
                        AreaException.invalidField("usuarioIds", "El usuario especificado no existe."));
                if (!u.isEnabled()) {
                    throw AreaException.usuarioInactivo();
                }
                solicitados.put(uid, u);
            }
        }

        List<UserAccount> removidos = new ArrayList<>();
        Set<UUID> actuales = new HashSet<>();
        for (AreaJefatura jefatura : areaJefaturaRepository.findByAreaId(areaId)) {
            actuales.add(jefatura.getUsuarioId());
            if (!solicitados.containsKey(jefatura.getUsuarioId())) {
                areaJefaturaRepository.delete(jefatura);
                if (jefatura.getUsuario() != null) {
                    removidos.add(jefatura.getUsuario());
                }
            }
        }
        List<UserAccount> asignados = new ArrayList<>();
        for (UserAccount u : solicitados.values()) {
            if (!actuales.contains(u.getId())) {
                addJefatura(area, u);
                asignados.add(u);
            }
        }
        removidos.forEach(this::bumpAcceso);
        asignados.forEach(this::bumpAcceso);
        rbac.finishMutation(securityBefore);

        removidos.forEach(u -> auditJefatura("JEFATURA_REMOVIDA", area, u));
        asignados.forEach(u -> auditJefatura("JEFATURA_ASIGNADA", area, u));

        return solicitados.values().stream()
                .map(u -> new JefaturaItem(areaId, area.getNombre()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getJefaturas(Long areaId) {
        findArea(areaId);
        List<UserAccount> users = areaJefaturaRepository.findByAreaId(areaId).stream()
                .map(AreaJefatura::getUsuario)
                .filter(Objects::nonNull)
                .toList();
        return users.stream().map(u -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", u.getId());
            map.put("usuarioId", u.getId());
            map.put("userId", u.getId());
            map.put("nombre", nombrePersona(u));
            map.put("email", u.getEmail());
            map.put("areaId", areaId);
            return map;
        }).toList();
    }

    // ---------------------------------------------------------------------------------------------
    // Jefaturas (AREA_JEFATURA). Se usan borrados por entidad (sin @Modifying + clear) para no
    // desacoplar las entidades cargadas en la transacción.
    // ---------------------------------------------------------------------------------------------

    private Set<UUID> jefaturaIds(Long areaId) {
        Set<UUID> ids = new HashSet<>();
        for (AreaJefatura jefatura : areaJefaturaRepository.findByAreaId(areaId)) {
            ids.add(jefatura.getUsuarioId());
        }
        return ids;
    }

    private UserAccount primeraJefatura(Long areaId) {
        return areaJefaturaRepository.findByAreaId(areaId).stream()
                .map(AreaJefatura::getUsuario)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null);
    }

    private boolean esJefatura(Long areaId, UUID usuarioId) {
        return areaJefaturaRepository.existsById_AreaIdAndId_UsuarioId(areaId, usuarioId);
    }

    private void addJefatura(Area area, UserAccount user) {
        entityManager.persist(new AreaJefatura(area, user));
    }

    private void removeJefatura(Long areaId, UUID usuarioId) {
        for (AreaJefatura jefatura : areaJefaturaRepository.findByAreaId(areaId)) {
            if (usuarioId.equals(jefatura.getUsuarioId())) {
                areaJefaturaRepository.delete(jefatura);
            }
        }
    }

    private void bumpAcceso(UserAccount user) {
        if (user != null) {
            user.bumpVersionAcceso();
            userAccountRepository.save(user);
        }
    }

    /**
     * Compatibilidad con {@code administradorId}: el administrador pasa a ser miembro del área.
     * Devuelve la descripción del movimiento para el detalle de ASIGNAR_ADMIN_AREA, o null si no cambió.
     */
    private String moverUsuarioSiCorresponde(UserAccount user, Area area) {
        Area previous = user.getArea();
        if (previous != null && Objects.equals(previous.getId(), area.getId())) {
            return null;
        }
        String previousName = nombreArea(previous);
        user.setArea(area);
        return "área de " + user.getEmail() + ": " + previousName + " → " + area.getNombre();
    }

    // ---------------------------------------------------------------------------------------------
    // Auditoría
    // ---------------------------------------------------------------------------------------------

    private void auditCambioArea(UserAccount user, String areaAnterior, String areaNueva) {
        auditService.registerAuditEvent("CAMBIAR_AREA_USUARIO", "usuario", String.valueOf(user.getId()), "EXITO",
                "Usuario " + user.getEmail() + ": " + areaAnterior + " → " + areaNueva);
    }

    private void auditJefatura(String tipo, Area area, UserAccount user) {
        String accion = "JEFATURA_ASIGNADA".equals(tipo) ? "jefatura asignada a " : "jefatura removida de ";
        auditService.registerAuditEvent(tipo, "area", String.valueOf(area.getId()), "EXITO",
                "Área '" + area.getNombre() + "': " + accion + etiqueta(user));
    }

    private static String nombreArea(Area area) {
        return area != null ? area.getNombre() : SIN_AREA;
    }

    private static String etiqueta(UserAccount user) {
        return user == null ? "(ninguno)" : nombrePersona(user) + " <" + user.getEmail() + ">";
    }

    private static String nombrePersona(UserAccount u) {
        String f = u.getFirstName() != null ? u.getFirstName() : "";
        String l = u.getLastName() != null ? u.getLastName() : "";
        String nombre = (f + " " + l).trim();
        return nombre.isEmpty() ? u.getEmail() : nombre;
    }

    private static AreaMemberResponse toMemberResponse(UserAccount u, boolean esJefe) {
        return new AreaMemberResponse(u.getId(), u.getEmail(), nombrePersona(u), u.getRut(), u.isEnabled(), esJefe);
    }

    private AreaResponse toResponse(Area area) {
        UserAccount admin = area.getAdministrador();
        if (admin == null && area.getId() != null) {
            admin = primeraJefatura(area.getId());
        }
        return toResponse(area, 0L, admin);
    }

    private static AreaResponse toResponse(Area area, long totalUsuarios, UserAccount admin) {
        Area parent = area.getAreaPadre();
        UUID adminId = null;
        String adminNombre = null;
        String adminEmail = null;
        if (admin != null) {
            adminId = admin.getId();
            adminEmail = admin.getEmail();
            adminNombre = nombrePersona(admin);
        }

        return new AreaResponse(area.getId(), area.getNombre(), area.getDescripcion(), area.isActivo(),
                parent == null ? null : parent.getId(), parent == null ? null : parent.getNombre(),
                adminId, adminNombre, adminEmail,
                area.getCreatedAt(), area.getUpdatedAt(), area.getVersion(), totalUsuarios);
    }
}
