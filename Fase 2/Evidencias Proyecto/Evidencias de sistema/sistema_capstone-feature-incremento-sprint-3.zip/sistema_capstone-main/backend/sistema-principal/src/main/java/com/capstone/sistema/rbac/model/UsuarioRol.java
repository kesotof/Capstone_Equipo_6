package com.capstone.sistema.rbac.model;

import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "usuario_rol")
public class UsuarioRol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount usuario;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "rol_id", nullable = false)
    private Rol rol;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id")
    private Area area;

    @Column(name = "vigente_hasta")
    private Instant vigenteHasta;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "otorgado_por", nullable = false)
    private UserAccount otorgadoPor;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected UsuarioRol() {
    }

    public UsuarioRol(UserAccount usuario, Rol rol, Area area, Instant vigenteHasta, UserAccount otorgadoPor) {
        this.usuario = usuario;
        this.rol = rol;
        this.area = area;
        this.vigenteHasta = vigenteHasta;
        this.otorgadoPor = otorgadoPor;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Instant getVigenteHasta() {
        return vigenteHasta;
    }

    public void setVigenteHasta(Instant vigenteHasta) {
        this.vigenteHasta = vigenteHasta;
    }

    public UserAccount getOtorgadoPor() {
        return otorgadoPor;
    }

    public void setOtorgadoPor(UserAccount otorgadoPor) {
        this.otorgadoPor = otorgadoPor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public boolean isVigente() {
        return vigenteHasta == null || vigenteHasta.isAfter(Instant.now());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UsuarioRol that = (UsuarioRol) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
