package com.capstone.sistema.template.dto;

public enum FieldType {
    TEXTO,
    TEXTO_LARGO,
    NUMERO,
    /** Monto en pesos chilenos, sin decimales: en el documento se imprime como $1.250.000. */
    MONTO,
    FECHA,
    HORA,
    BOOLEANO,
    SELECCION,
    RUT
}
