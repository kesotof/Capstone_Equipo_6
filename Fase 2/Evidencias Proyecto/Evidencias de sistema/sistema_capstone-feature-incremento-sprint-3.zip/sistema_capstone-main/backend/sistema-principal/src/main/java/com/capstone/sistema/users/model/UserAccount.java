package com.capstone.sistema.users.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.Version;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "usuario")
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "keycloak_id", unique = true, length = 255)
    private String keycloakUserId;

    @Column(nullable = false, unique = true, length = 255)
    private String email;

    @Column(name = "rut", unique = true, length = 12)
    private String rut;

    @Column(name = "nombre", nullable = false, length = 100)
    private String firstName;

    @Column(name = "apellido", nullable = false, length = 100)
    private String lastName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id")
    private Area area;

    @Column(name = "activo", nullable = false)
    private boolean enabled = true;

    @Version
    @Column(name = "lock_version", nullable = false)
    private long lockVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    // Campos transitorios para mantener compatibilidad con código existente durante la migración
    @Transient
    private UserAccount jefaturaDirecta;

    protected UserAccount() {
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String firstName,
            String lastName,
            boolean enabled
    ) {
        this.keycloakUserId = keycloakUserId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.enabled = enabled;
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String firstName,
            String lastName,
            Area area,
            boolean enabled
    ) {
        this.keycloakUserId = keycloakUserId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.area = area;
        this.enabled = enabled;
    }

    public UserAccount(
            String keycloakUserId,
            String email,
            String rut,
            String firstName,
            String lastName,
            Area area,
            boolean enabled
    ) {
        this.keycloakUserId = keycloakUserId;
        this.email = email;
        this.rut = rut;
        this.firstName = firstName;
        this.lastName = lastName;
        this.area = area;
        this.enabled = enabled;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        updatedAt = createdAt;
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getKeycloakUserId() {
        return keycloakUserId;
    }

    public void setKeycloakUserId(String keycloakUserId) {
        this.keycloakUserId = keycloakUserId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNombre() {
        if (firstName == null && lastName == null) {
            return email != null ? email : "";
        }
        return ((firstName != null ? firstName : "") + (lastName != null && !lastName.isBlank() ? " " + lastName : "")).trim();
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isActivo() {
        return enabled;
    }

    public void setActivo(boolean activo) {
        this.enabled = activo;
    }

    public long getLockVersion() {
        return lockVersion;
    }

    public void setLockVersion(long lockVersion) {
        this.lockVersion = lockVersion;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public UserAccount getJefaturaDirecta() {
        return jefaturaDirecta;
    }

    public void setJefaturaDirecta(UserAccount jefaturaDirecta) {
        this.jefaturaDirecta = jefaturaDirecta;
    }

    /**
     * Versión de acceso del usuario (plan v5 §8: {@code UserAccount} usa {@code lock_version}).
     * Es el mismo valor que {@link #getLockVersion()}; se expone con este nombre por el contrato
     * {@code versionAcceso} de los DTO.
     */
    public long getVersionAcceso() {
        return lockVersion;
    }

    /**
     * Único mecanismo para subir la versión de acceso cuando cambian sus accesos sin que cambie
     * ninguna columna propia (asignaciones en USUARIO_ROL, jefaturas, área). Marca la entidad como
     * modificada tocando {@code updated_at}; al hacer flush, Hibernate incrementa {@code lock_version}
     * (@Version). La entidad debe estar gestionada (o guardarse) y el nuevo valor solo es visible
     * en {@link #getVersionAcceso()} después del flush.
     */
    public void bumpVersionAcceso() {
        Instant now = Instant.now();
        this.updatedAt = updatedAt != null && !now.isAfter(updatedAt) ? updatedAt.plusNanos(1_000) : now;
    }

    public String getNombreCompleto() {
        return (firstName != null ? firstName : "") + " " + (lastName != null ? lastName : "");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserAccount that = (UserAccount) o;
        return Objects.equals(id, that.id) || Objects.equals(email, that.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id != null ? id : email);
    }
}
