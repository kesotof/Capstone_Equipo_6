package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface VRevisorSolicitudRepository extends JpaRepository<VRevisorSolicitud, VRevisorSolicitudId> {

    List<VRevisorSolicitud> findBySolicitudId(UUID solicitudId);

    List<VRevisorSolicitud> findByUsuarioId(UUID usuarioId);

    boolean existsBySolicitudIdAndUsuarioId(UUID solicitudId, UUID usuarioId);
}
