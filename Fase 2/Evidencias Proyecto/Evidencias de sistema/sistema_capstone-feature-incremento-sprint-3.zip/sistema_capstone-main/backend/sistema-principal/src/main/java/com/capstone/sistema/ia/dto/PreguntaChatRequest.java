package com.capstone.sistema.ia.dto;

public record PreguntaChatRequest(String pregunta) {
}
