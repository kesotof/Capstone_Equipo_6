package com.capstone.sistema.ia.model;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.UuidGenerator;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * A-09: registro genérico de tareas de IA (US-30 evaluaciones y chat, US-29 autocompletado).
 * Una fila por tarea, con {@code estado} y {@code resultado JSONB} validado por tipo en Java.
 * Una tarea terminada es inmutable y nunca se borra (trigger trg_ia_tarea_transicion, CB015).
 */
@Entity
@Table(name = "ia_tarea", indexes = {
        @Index(name = "idx_ia_solicitud", columnList = "solicitud_id, tipo, created_at"),
        @Index(name = "idx_ia_solicitante", columnList = "solicitado_por"),
        @Index(name = "idx_ia_documento", columnList = "documento_id")
})
public class IaTarea {

    @Id
    @UuidGenerator
    private UUID id;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo", nullable = false, length = 15, updatable = false)
    private TipoTareaIa tipo;

    @Enumerated(EnumType.STRING)
    @Column(name = "origen", nullable = false, length = 12, updatable = false)
    private OrigenTareaIa origen;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false, length = 12)
    private EstadoTareaIa estado = EstadoTareaIa.PENDIENTE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitud_id", updatable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "documento_id", updatable = false)
    private Documento documento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flujo_etapa_id", updatable = false)
    private FlujoEtapa flujoEtapa;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plantilla_version_id", updatable = false)
    private PlantillaVersion plantillaVersion;

    @Column(name = "fuente_bucket", updatable = false, length = 63)
    private String fuenteBucket;

    @Column(name = "fuente_storage_key", updatable = false, length = 500)
    private String fuenteStorageKey;

    @Column(name = "fuente_nombre_archivo", updatable = false, length = 255)
    private String fuenteNombreArchivo;

    @Column(name = "fuente_content_type", updatable = false, length = 100)
    private String fuenteContentType;

    /** Instrucción enviada al modelo; copia inmutable (el criterio vigente puede cambiar después). */
    @Column(name = "instruccion", nullable = false, columnDefinition = "text", updatable = false)
    private String instruccion;

    @Column(name = "instruccion_sha256", nullable = false, length = 64, updatable = false)
    private String instruccionSha256;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private JsonNode resultado;

    @Column(name = "modelo", length = 100)
    private String modelo;

    @Column(name = "codigo_error", length = 50)
    private String codigoError;

    @Column(name = "error_detalle", length = 2000)
    private String errorDetalle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitado_por", updatable = false)
    private UserAccount solicitadoPor;

    /** Instante del último intento de publicación del comando. */
    @Column(name = "publicado_en", nullable = false)
    private Instant publicadoEn;

    @Column(name = "publicaciones", nullable = false)
    private short publicaciones = 1;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    protected IaTarea() {
    }

    /** Constructor canónico para tareas nuevas (estado PENDIENTE, publicaciones 1). */
    public IaTarea(
            TipoTareaIa tipo,
            OrigenTareaIa origen,
            Solicitud solicitud,
            Documento documento,
            FlujoEtapa flujoEtapa,
            PlantillaVersion plantillaVersion,
            String fuenteBucket,
            String fuenteStorageKey,
            String fuenteNombreArchivo,
            String fuenteContentType,
            String instruccion,
            String instruccionSha256,
            UserAccount solicitadoPor
    ) {
        this.tipo = Objects.requireNonNull(tipo, "tipo");
        this.origen = Objects.requireNonNull(origen, "origen");
        this.solicitud = solicitud;
        this.documento = documento;
        this.flujoEtapa = flujoEtapa;
        this.plantillaVersion = plantillaVersion;
        this.fuenteBucket = fuenteBucket;
        this.fuenteStorageKey = fuenteStorageKey;
        this.fuenteNombreArchivo = fuenteNombreArchivo;
        this.fuenteContentType = fuenteContentType;
        this.instruccion = Objects.requireNonNull(instruccion, "instruccion");
        this.instruccionSha256 = Objects.requireNonNull(instruccionSha256, "instruccionSha256");
        this.solicitadoPor = solicitadoPor;
        this.estado = EstadoTareaIa.PENDIENTE;
        this.publicadoEn = Instant.now();
        this.createdAt = this.publicadoEn;
        this.publicaciones = 1;
    }

    @jakarta.persistence.PrePersist
    void onPrePersist() {
        Instant now = Instant.now();
        if (createdAt == null) {
            createdAt = now;
        }
        if (publicadoEn == null) {
            publicadoEn = now;
        }
    }

    /** Transición a COMPLETADA (inmutable a partir de este punto por DB trigger CB015). */
    public void completar(JsonNode resultado, String modelo) {
        this.estado = EstadoTareaIa.COMPLETADA;
        this.resultado = resultado;
        this.modelo = modelo;
        this.completedAt = Instant.now();
    }

    /** Transición a FALLIDA (inmutable a partir de este punto por DB trigger CB015). */
    public void fallar(String codigoError, String errorDetalle) {
        this.estado = EstadoTareaIa.FALLIDA;
        this.codigoError = codigoError;
        this.errorDetalle = errorDetalle != null && errorDetalle.length() > 2000
                ? errorDetalle.substring(0, 2000)
                : errorDetalle;
        this.completedAt = Instant.now();
    }

    /** Re-publicación por el scheduler (§6.10): incrementa publicaciones y actualiza publicadoEn. */
    public void republicar(Instant ahora) {
        this.publicadoEn = ahora;
        this.publicaciones = (short) (this.publicaciones + 1);
    }

    public UUID getId() {
        return id;
    }

    public TipoTareaIa getTipo() {
        return tipo;
    }

    public OrigenTareaIa getOrigen() {
        return origen;
    }

    public EstadoTareaIa getEstado() {
        return estado;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public Documento getDocumento() {
        return documento;
    }

    public FlujoEtapa getFlujoEtapa() {
        return flujoEtapa;
    }

    public PlantillaVersion getPlantillaVersion() {
        return plantillaVersion;
    }

    public String getFuenteBucket() {
        return fuenteBucket;
    }

    public String getFuenteStorageKey() {
        return fuenteStorageKey;
    }

    public String getFuenteNombreArchivo() {
        return fuenteNombreArchivo;
    }

    public String getFuenteContentType() {
        return fuenteContentType;
    }

    public String getInstruccion() {
        return instruccion;
    }

    public String getInstruccionSha256() {
        return instruccionSha256;
    }

    public JsonNode getResultado() {
        return resultado;
    }

    public void setResultado(JsonNode resultado) {
        this.resultado = resultado;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCodigoError() {
        return codigoError;
    }

    public void setCodigoError(String codigoError) {
        this.codigoError = codigoError;
    }

    public String getErrorDetalle() {
        return errorDetalle;
    }

    public void setErrorDetalle(String errorDetalle) {
        this.errorDetalle = errorDetalle;
    }

    public UserAccount getSolicitadoPor() {
        return solicitadoPor;
    }

    public Instant getPublicadoEn() {
        return publicadoEn;
    }

    public void setPublicadoEn(Instant publicadoEn) {
        this.publicadoEn = publicadoEn;
    }

    public short getPublicaciones() {
        return publicaciones;
    }

    public void setPublicaciones(short publicaciones) {
        this.publicaciones = publicaciones;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }

    public void setEstado(EstadoTareaIa estado) {
        this.estado = estado;
    }
}
