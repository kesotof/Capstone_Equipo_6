package com.capstone.sistema.mensajeria;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.UUID;

/**
 * F2 (§6.0.1): único punto de publicación de mensajes hacia Rabbit.
 *
 * <ul>
 *   <li>Con transacción activa: registra {@code afterCommit}; sin transacción publica al instante.</li>
 *   <li>Nunca propaga fallos del broker: {@code WARN} con mensajeId y routingKey y sigue.
 *       El re-publicador recupera el mensaje pendiente.</li>
 *   <li>Fija {@code messageId}, {@code contentType} y header {@code x-contrato-version}.</li>
 *   <li>NO escribe en la base después del commit: `publicado_en`/`publicaciones` se fijan en la
 *       transacción de negocio.</li>
 * </ul>
 */
@Component
public class MensajePublicador {

    public static final String HEADER_CONTRATO_VERSION = "x-contrato-version";
    public static final int CONTRATO_VERSION = 1;

    private static final Logger log = LoggerFactory.getLogger(MensajePublicador.class);

    private final RabbitTemplate rabbitTemplate;
    private final String exchange;

    public MensajePublicador(RabbitTemplate rabbitTemplate, MensajeriaProperties properties) {
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = properties.exchange() != null ? properties.exchange() : MensajeriaConfig.EXCHANGE_NAME;
    }

    public void publicarTrasCommit(String routingKey, Object payload, UUID mensajeId) {
        String mensajeIdTexto = mensajeId != null ? mensajeId.toString() : UUID.randomUUID().toString();
        Runnable publicar = () -> enviar(routingKey, payload, mensajeIdTexto);
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    publicar.run();
                }
            });
        } else {
            publicar.run();
        }
    }

    private void enviar(String routingKey, Object payload, String mensajeIdTexto) {
        try {
            MessagePostProcessor post = message -> {
                message.getMessageProperties().setMessageId(mensajeIdTexto);
                message.getMessageProperties().setHeader(HEADER_CONTRATO_VERSION, CONTRATO_VERSION);
                return message;
            };
            rabbitTemplate.convertAndSend(exchange, routingKey, payload, post);
            log.debug("Mensaje {} publicado ({})", mensajeIdTexto, routingKey);
        } catch (RuntimeException ex) {
            log.warn("No fue posible publicar el mensaje {} en {}: {}", mensajeIdTexto, routingKey, ex.getMessage());
        }
    }
}
