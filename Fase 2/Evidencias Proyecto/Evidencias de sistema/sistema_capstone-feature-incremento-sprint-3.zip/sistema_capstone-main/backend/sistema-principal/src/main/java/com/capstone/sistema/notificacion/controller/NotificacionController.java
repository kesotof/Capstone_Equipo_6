package com.capstone.sistema.notificacion.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.model.enums.CategoriaNotificacion;
import com.capstone.sistema.notificacion.dto.NotificacionResponse;
import com.capstone.sistema.notificacion.service.NotificacionService;
import com.capstone.sistema.users.model.UserAccount;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "Notificaciones", description = "Bandeja de notificaciones in-app y marcado de lectura")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/notificaciones")
@PreAuthorize("isAuthenticated()")
public class NotificacionController {

    private final NotificacionService notificacionService;
    private final CurrentUserResolver currentUserResolver;

    public NotificacionController(
            NotificacionService notificacionService,
            CurrentUserResolver currentUserResolver
    ) {
        this.notificacionService = notificacionService;
        this.currentUserResolver = currentUserResolver;
    }

    @GetMapping
    public ResponseEntity<List<NotificacionResponse>> listarMisNotificaciones(
            @RequestParam(value = "categoria", required = false) String categoria,
            @RequestParam(value = "soloNoLeidas", defaultValue = "false") boolean soloNoLeidas
    ) {
        UserAccount user = getAuthenticatedUser();
        // F3 (§6.3): «ACCION_REQUERIDA» (CA 10.1/10.2) o «INFORMATIVA»; valor desconocido → 400.
        CategoriaNotificacion categoriaEnum = categoria == null || categoria.isBlank()
                ? null
                : CategoriaNotificacion.valueOf(categoria.trim().toUpperCase());
        return ResponseEntity.ok(notificacionService.listarMisNotificaciones(user, categoriaEnum, soloNoLeidas));
    }

    @GetMapping("/no-leidas/count")
    public ResponseEntity<Map<String, Long>> contarNoLeidas() {
        UserAccount user = getAuthenticatedUser();
        long count = notificacionService.contarNoLeidas(user);
        return ResponseEntity.ok(Map.of("count", count));
    }

    @PatchMapping("/{id}/leer")
    public ResponseEntity<NotificacionResponse> marcarComoLeida(@PathVariable Long id) {
        UserAccount user = getAuthenticatedUser();
        return ResponseEntity.ok(notificacionService.marcarComoLeida(id, user));
    }

    @PatchMapping("/marcar-todas-leidas")
    public ResponseEntity<Map<String, Object>> marcarTodasComoLeidas() {
        UserAccount user = getAuthenticatedUser();
        int count = notificacionService.marcarTodasComoLeidas(user);
        return ResponseEntity.ok(Map.of("actualizadas", count));
    }

    private UserAccount getAuthenticatedUser() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new org.springframework.security.access.AccessDeniedException("Usuario no autenticado"));
    }
}
