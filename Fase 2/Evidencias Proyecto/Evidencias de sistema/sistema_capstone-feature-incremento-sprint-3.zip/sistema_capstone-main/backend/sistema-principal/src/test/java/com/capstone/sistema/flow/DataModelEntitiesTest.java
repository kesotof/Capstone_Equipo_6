package com.capstone.sistema.flow;

import com.capstone.sistema.audit.model.LogEvento;
import com.capstone.sistema.audit.model.TipoEvento;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.Plantilla;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.flow.model.AccionTransicion;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.notificacion.model.Notificacion;
import com.capstone.sistema.notificacion.model.NotificacionEnvio;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.model.SolicitudCompartida;
import com.capstone.sistema.notificacion.model.TipoNotificacion;
import com.capstone.sistema.model.enums.AccionTransicionEnum;
import com.capstone.sistema.model.enums.AmbitoRol;
import com.capstone.sistema.model.enums.EstadoSolicitudEnum;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.model.enums.TipoAsignacionRol;
import com.capstone.sistema.model.view.VAccesoDescarga;
import com.capstone.sistema.model.view.VAccesoDescargaId;
import com.capstone.sistema.model.view.VAccesoSolicitud;
import com.capstone.sistema.model.view.VAccesoSolicitudId;
import com.capstone.sistema.model.view.VAreaDescendiente;
import com.capstone.sistema.model.view.VAreaDescendienteId;
import com.capstone.sistema.model.view.VBandejaRevision;
import com.capstone.sistema.model.view.VBandejaRevisionId;
import com.capstone.sistema.model.view.VDocumentoVigente;
import com.capstone.sistema.model.view.VFlujoDisponible;
import com.capstone.sistema.model.view.VFlujoDisponibleUsuario;
import com.capstone.sistema.model.view.VFlujoDisponibleUsuarioId;
import com.capstone.sistema.model.view.VPermisoEfectivo;
import com.capstone.sistema.model.view.VPermisoEfectivoId;
import com.capstone.sistema.model.view.VPlantillaVigente;
import com.capstone.sistema.model.view.VRevisorSolicitud;
import com.capstone.sistema.model.view.VRevisorSolicitudId;
import com.capstone.sistema.org.area.model.AreaJefatura;
import com.capstone.sistema.rbac.model.ControlPolitica;
import com.capstone.sistema.rbac.model.PermisoEntity;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.model.UsuarioRol;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import org.flywaydb.core.Flyway;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class DataModelEntitiesTest {

    @Test
    @DisplayName("F2-01: Debe instanciar y relacionar correctamente entidades de Organización, Usuario y RBAC v5")
    void testOrganizacionYUsuarioV5() {
        Area gerencia = new Area(1L, "Gerencia General", true);
        gerencia.setDescripcion("Gerencia Principal");
        Area finanzas = new Area(2L, "Finanzas", true);
        finanzas.setDescripcion("Área Financiera");
        finanzas.setAreaPadre(gerencia);

        assertThat(finanzas.getNombre()).isEqualTo("Finanzas");
        assertThat(finanzas.getAreaPadre().getNombre()).isEqualTo("Gerencia General");
        assertThat(finanzas.isActivo()).isTrue();

        UserAccount user = new UserAccount(
                "kc-uuid-123",
                "juan.perez@capstone.local",
                "12345678-5",
                "Juan",
                "Pérez",
                finanzas,
                true
        );

        assertThat(user.getRut()).isEqualTo("12345678-5");
        assertThat(user.getEmail()).isEqualTo("juan.perez@capstone.local");
        assertThat(user.getArea().getNombre()).isEqualTo("Finanzas");

        PermisoEntity permisoCrear = new PermisoEntity("solicitud", "crear", "Crear solicitudes", AmbitoRol.AREA_O_GLOBAL);
        Rol rolSolicitante = new Rol("SOLICITANTE", "Rol solicitante", "Rol solicitante", false, TipoAsignacionRol.MANUAL, AmbitoRol.AREA_O_GLOBAL);
        rolSolicitante.getPermisos().add(permisoCrear);

        UsuarioRol usuarioRol = new UsuarioRol(user, rolSolicitante, finanzas, Instant.now().plus(30, ChronoUnit.DAYS), user);
        assertThat(usuarioRol.getUsuario()).isEqualTo(user);
        assertThat(usuarioRol.getRol().getCodigo()).isEqualTo("SOLICITANTE");
        assertThat(usuarioRol.getArea()).isEqualTo(finanzas);

        AreaJefatura jefatura = new AreaJefatura(finanzas, user);
        assertThat(jefatura.getAreaId()).isEqualTo(finanzas.getId());
        assertThat(jefatura.getUsuarioId()).isEqualTo(user.getId());

        ControlPolitica politica = new ControlPolitica(1L);
        politica.incrementVersion();
        assertThat(politica.getVersion()).isEqualTo(2L);
    }

    @Test
    @DisplayName("F2-02: Debe validar FlujoDefinicion, FlujoEtapa y Máquina de Estados v5")
    void testFlujoEtapasTransicionesV5() {
        Area area = new Area(1L, "Operaciones", true);
        UserAccount revisor = new UserAccount("kc-rev-1", "revisor@capstone.local", "Carlos", "Revisor", area, true);

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Compras v5", "Aprobación de compras v5", area);
        flujo.setNumeroVersion(1);
        flujo.setActivo(true);

        FlujoEtapa etapa1 = new FlujoEtapa(flujo, 1, "Revisión Técnica");
        etapa1.setModoRevisor(ModoRevisor.LISTA);
        etapa1.getRevisores().add(revisor);
        flujo.addEtapa(etapa1);

        assertThat(flujo.getNombre()).isEqualTo("Flujo Compras v5");
        assertThat(flujo.getEtapas()).hasSize(1);
        assertThat(etapa1.getModoRevisor()).isEqualTo(ModoRevisor.LISTA);
        assertThat(etapa1.getRevisores()).contains(revisor);

        EstadoSolicitud pendiente = new EstadoSolicitud(EstadoSolicitudEnum.PENDIENTE_REVISION.name(), "Pendiente", 1, false);
        EstadoSolicitud aprobada = new EstadoSolicitud(EstadoSolicitudEnum.APROBADO.name(), "Aprobado", 3, true);
        AccionTransicion accionAprobar = new AccionTransicion(AccionTransicionEnum.APROBAR.name(), "Aprobar");

        assertThat(pendiente.getCodigo()).isEqualTo("PENDIENTE_REVISION");
        assertThat(pendiente.isEsFinal()).isFalse();
        assertThat(aprobada.isEsFinal()).isTrue();
        assertThat(accionAprobar.getCodigo()).isEqualTo("APROBAR");
    }

    @Test
    @DisplayName("F2-03: Debe validar Tipos de Documento, Plantillas, Solicitud y Documento v5")
    void testDocumentosYPlantillasV5() {
        Area area = new Area(1L, "Finanzas", true);
        UserAccount emisor = new UserAccount("kc-emisor", "emisor@capstone.local", "Emisor", "Doc", area, true);
        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Finanzas", "Flujo Finanzas", area);
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa Inicial");
        EstadoSolicitud estado = new EstadoSolicitud("BORRADOR", "Borrador", 0, false);
        AccionTransicion accionCrear = new AccionTransicion("REGISTRAR", "Registrar");

        TipoDocumento tipoDoc = new TipoDocumento("Factura Proveedor", "Facturas de compras", "FAC", 10);
        tipoDoc.setUltimoCorrelativo(5);
        assertThat(tipoDoc.getPrefijo()).isEqualTo("FAC");
        assertThat(tipoDoc.getPlazoDiasHabiles()).isEqualTo(10);
        assertThat(tipoDoc.getUltimoCorrelativo()).isEqualTo(5);

        Plantilla plantilla = new Plantilla("Plantilla Factura", "Plantilla DOCX para facturas", tipoDoc);
        PlantillaVersion version1 = new PlantillaVersion(plantilla, 1, "plantillas/fac-v1.docx", "abc123sha", emisor);

        assertThat(version1.getPlantilla()).isEqualTo(plantilla);
        assertThat(version1.getStorageKey()).isEqualTo("plantillas/fac-v1.docx");

        Solicitud solicitud = new Solicitud(flujo, emisor, "Factura #101", "Pago de insumos", estado, etapa);
        solicitud.setCorrelativo("FAC-2026-00001");
        solicitud.setTipoDocumento(tipoDoc);
        solicitud.setArea(area);

        HistorialTransicion histInit = new HistorialTransicion(solicitud, etapa, accionCrear, null, estado, emisor, "Creación", true, "{}");
        Documento doc = new Documento(
                histInit,
                "factura_101.pdf",
                "application/pdf",
                "documentos/2026/fac_101.pdf",
                2048L,
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );

        assertThat(solicitud.getCorrelativo()).isEqualTo("FAC-2026-00001");
        assertThat(solicitud.getTipoDocumento()).isEqualTo("Factura Proveedor");
        assertThat(solicitud.getTipoDocumentoEntity()).isEqualTo(tipoDoc);
        assertThat(doc.getChecksumSha256()).isNotEmpty();
        assertThat(doc.getContentType()).isEqualTo("application/pdf");

        SolicitudCompartida compartida = new SolicitudCompartida(solicitud, emisor, emisor);
        assertThat(compartida.getUsuario()).isEqualTo(emisor);
        assertThat(compartida.getCompartidoPor()).isEqualTo(emisor);
    }

    @Test
    @DisplayName("F2-04: Debe instanciar HistorialTransicion, Notificaciones, LogEvento e IaTarea v5")
    void testHistorialNotificacionesYAuditoriaV5() {
        Area area = new Area(1L, "Logística", true);
        UserAccount usuario = new UserAccount("kc-audit", "audit@capstone.local", "Audit", "User", area, true);
        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Base", "Flujo Base", area);
        FlujoEtapa etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        EstadoSolicitud estadoBorrador = new EstadoSolicitud("BORRADOR", "Borrador", 0, false);
        EstadoSolicitud estadoEnRevision = new EstadoSolicitud("EN_REVISION", "En Revisión", 1, false);
        AccionTransicion accionEnviar = new AccionTransicion("ENVIAR", "Enviar");
        Solicitud solicitud = new Solicitud(flujo, usuario, "Sol Base", "Desc", estadoEnRevision, etapa);

        HistorialTransicion historial = new HistorialTransicion(
                solicitud,
                etapa,
                accionEnviar,
                estadoBorrador,
                estadoEnRevision,
                usuario,
                "Envío para revisión",
                true,
                "{\"ip\":\"127.0.0.1\"}"
        );
        assertThat(historial.getFlujoEtapa()).isEqualTo(etapa);
        assertThat(historial.getEstadoOrigen().getCodigo()).isEqualTo("BORRADOR");
        assertThat(historial.getEstadoDestino().getCodigo()).isEqualTo("EN_REVISION");
        assertThat(historial.getAccion().getCodigo()).isEqualTo("ENVIAR");

        TipoNotificacion tipoNotif = new TipoNotificacion("SOLICITUD_ASIGNADA", "Asignación de solicitud");
        Notificacion notificacion = new Notificacion(usuario, solicitud, historial, tipoNotif, "Nueva Solicitud", "Tienes una nueva solicitud pendiente.");
        NotificacionEnvio envio = new NotificacionEnvio(notificacion, "EMAIL", "audit@capstone.local", 1, "ENVIADO", null, null);

        assertThat(notificacion.getTitulo()).isEqualTo("Nueva Solicitud");
        assertThat(notificacion.getHistorialTransicion()).isEqualTo(historial);
        assertThat(envio.getCanal()).isEqualTo("EMAIL");
        assertThat(envio.getResultado()).isEqualTo("ENVIADO");

        TipoEvento tipoLogin = new TipoEvento("LOGIN", "SEGURIDAD", "Inicio de sesión");
        LogEvento log = new LogEvento(tipoLogin, usuario, "192.168.1.100", "Login exitoso");
        log.setDatosAntes("{\"status\":\"ok\"}");
        log.setDatosDespues("{\"sessionId\":\"s1\"}");
        assertThat(log.getTipoEvento().getCodigo()).isEqualTo("LOGIN");
        assertThat(log.getIpAddress()).isEqualTo("192.168.1.100");
        assertThat(log.getDatosAntes()).isEqualTo("{\"status\":\"ok\"}");

        IaTarea iaTarea = new IaTarea(
                TipoTareaIa.EVALUACION,
                OrigenTareaIa.AUTOMATICO,
                solicitud,
                null,
                null,
                null,
                null, null, null, null,
                "Verificar cláusulas de confidencialidad y vigencia del contrato.",
                "aa".repeat(32),
                usuario
        );
        iaTarea.setCodigoError("IA_NO_DISPONIBLE");
        assertThat(iaTarea.getTipo()).isEqualTo(TipoTareaIa.EVALUACION);
        assertThat(iaTarea.getOrigen()).isEqualTo(OrigenTareaIa.AUTOMATICO);
        assertThat(iaTarea.getInstruccionSha256()).hasSize(64);
    }

    @Test
    @DisplayName("F2-05: Debe instanciar y validar IDs de las 10 entidades de Vistas v5")
    void testVistasV5() {
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();

        VAreaDescendienteId vAreaId = new VAreaDescendienteId(1L, 2L);
        assertThat(vAreaId.getAncestroId()).isEqualTo(1L);
        assertThat(vAreaId.getAreaId()).isEqualTo(2L);

        VPermisoEfectivoId vPermId = new VPermisoEfectivoId(id1, "solicitud", "crear", 1L, "DIRECTA", 1L, 1L);
        assertThat(vPermId).isNotNull();

        VRevisorSolicitudId vRevId = new VRevisorSolicitudId(id1, 1L, id2);
        assertThat(vRevId.getSolicitudId()).isEqualTo(id1);
        assertThat(vRevId.getFlujoEtapaId()).isEqualTo(1L);
        assertThat(vRevId.getUsuarioId()).isEqualTo(id2);

        VAccesoSolicitudId vAccSolId = new VAccesoSolicitudId(id1, id2, "CREADOR");
        assertThat(vAccSolId.getSolicitudId()).isEqualTo(id1);
        assertThat(vAccSolId.getUsuarioId()).isEqualTo(id2);
        assertThat(vAccSolId.getMotivo()).isEqualTo("CREADOR");

        VAccesoDescargaId vAccDescId = new VAccesoDescargaId(id1, id2, "REVISOR");
        assertThat(vAccDescId.getSolicitudId()).isEqualTo(id1);
        assertThat(vAccDescId.getUsuarioId()).isEqualTo(id2);
        assertThat(vAccDescId.getMotivo()).isEqualTo("REVISOR");

        VFlujoDisponibleUsuarioId vFluUsId = new VFlujoDisponibleUsuarioId(1L, id1);
        assertThat(vFluUsId.getFlujoId()).isEqualTo(1L);
        assertThat(vFluUsId.getUsuarioId()).isEqualTo(id1);

        VBandejaRevisionId vBandejaId = new VBandejaRevisionId(id1, id2);
        assertThat(vBandejaId.getRevisorId()).isEqualTo(id1);
        assertThat(vBandejaId.getSolicitudId()).isEqualTo(id2);

        VFlujoDisponible vFlujoDisp = new VFlujoDisponible();
        assertThat(vFlujoDisp.getId()).isNull();

        VDocumentoVigente vDocVigente = new VDocumentoVigente();
        assertThat(vDocVigente.getId()).isNull();

        VPlantillaVigente vPlantillaVigente = new VPlantillaVigente();
        assertThat(vPlantillaVigente.getPlantillaId()).isNull();
    }

    @Test
    @DisplayName("F2-06: Debe validar Hibernate DDL Validate de todas las entidades y vistas contra Postgres v5")
    void testHibernateDdlValidateContraPostgresV5() {
        DataSource ds = resolveDataSource();
        if (ds == null) {
            System.out.println("Salteando validación de Hibernate: Base PostgreSQL no disponible en entorno de prueba.");
            return;
        }

        Flyway flyway = Flyway.configure()
                .dataSource(ds)
                .locations("classpath:db/migration")
                .cleanDisabled(false)
                .load();

        flyway.clean();
        flyway.migrate();

        StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .applySetting("hibernate.connection.datasource", ds)
                .applySetting("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect")
                .applySetting("hibernate.hbm2ddl.auto", "validate")
                .build();

        try {
            MetadataSources sources = new MetadataSources(registry);
            // Core & RBAC
            sources.addAnnotatedClass(Area.class);
            sources.addAnnotatedClass(AreaJefatura.class);
            sources.addAnnotatedClass(UserAccount.class);
            sources.addAnnotatedClass(PermisoEntity.class);
            sources.addAnnotatedClass(Rol.class);
            sources.addAnnotatedClass(UsuarioRol.class);
            sources.addAnnotatedClass(ControlPolitica.class);
            // Doc & Catalog
            sources.addAnnotatedClass(TipoDocumento.class);
            sources.addAnnotatedClass(Plantilla.class);
            sources.addAnnotatedClass(PlantillaVersion.class);
            sources.addAnnotatedClass(Documento.class);
            // Flow & Transitions
            sources.addAnnotatedClass(AccionTransicion.class);
            sources.addAnnotatedClass(EstadoSolicitud.class);
            sources.addAnnotatedClass(FlujoDefinicion.class);
            sources.addAnnotatedClass(FlujoEtapa.class);
            sources.addAnnotatedClass(HistorialTransicion.class);
            sources.addAnnotatedClass(Solicitud.class);
            sources.addAnnotatedClass(SolicitudCompartida.class);
            // Notifications & Audit & AI
            sources.addAnnotatedClass(TipoNotificacion.class);
            sources.addAnnotatedClass(Notificacion.class);
            sources.addAnnotatedClass(NotificacionEnvio.class);
            sources.addAnnotatedClass(TipoEvento.class);
            sources.addAnnotatedClass(LogEvento.class);
            // IA (A-09)
            sources.addAnnotatedClass(IaTarea.class);
            // 10 Views
            sources.addAnnotatedClass(VAreaDescendiente.class);
            sources.addAnnotatedClass(VPermisoEfectivo.class);
            sources.addAnnotatedClass(VRevisorSolicitud.class);
            sources.addAnnotatedClass(VAccesoSolicitud.class);
            sources.addAnnotatedClass(VAccesoDescarga.class);
            sources.addAnnotatedClass(VFlujoDisponible.class);
            sources.addAnnotatedClass(VFlujoDisponibleUsuario.class);
            sources.addAnnotatedClass(VBandejaRevision.class);
            sources.addAnnotatedClass(VDocumentoVigente.class);
            sources.addAnnotatedClass(VPlantillaVigente.class);

            Metadata metadata = sources.getMetadataBuilder().build();
            try (SessionFactory sessionFactory = metadata.buildSessionFactory()) {
                assertThat(sessionFactory).isNotNull();
                assertThat(sessionFactory.isOpen()).isTrue();
            }
        } finally {
            StandardServiceRegistryBuilder.destroy(registry);
        }
    }

    private DataSource resolveDataSource() {
        String customUrl = System.getenv("TEST_DATASOURCE_URL");
        if (customUrl != null && !customUrl.isBlank()) {
            DriverManagerDataSource ds = new DriverManagerDataSource();
            ds.setDriverClassName("org.postgresql.Driver");
            ds.setUrl(customUrl);
            ds.setUsername(System.getenv().getOrDefault("TEST_DATASOURCE_USER", "sistema_user"));
            ds.setPassword(System.getenv().getOrDefault("TEST_DATASOURCE_PASS", "sistema_secure_pass"));
            return ds;
        }

        String[] candidateHosts = new String[]{"host.docker.internal", "localhost", "postgres"};
        for (String host : candidateHosts) {
            try {
                DriverManagerDataSource ds = new DriverManagerDataSource();
                ds.setDriverClassName("org.postgresql.Driver");
                ds.setUrl("jdbc:postgresql://" + host + ":5432/sistema_v5_test");
                ds.setUsername("sistema_user");
                ds.setPassword("sistema_secure_pass");
                try (Connection conn = ds.getConnection()) {
                    return ds;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
