package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.PlantillaVersion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PlantillaVersionRepository extends JpaRepository<PlantillaVersion, Long> {

    List<PlantillaVersion> findByPlantilla_IdOrderByVersionDesc(Long plantillaId);

    Optional<PlantillaVersion> findByPlantilla_IdAndVersion(Long plantillaId, Integer version);

    Optional<PlantillaVersion> findFirstByPlantilla_IdOrderByVersionDesc(Long plantillaId);
}
