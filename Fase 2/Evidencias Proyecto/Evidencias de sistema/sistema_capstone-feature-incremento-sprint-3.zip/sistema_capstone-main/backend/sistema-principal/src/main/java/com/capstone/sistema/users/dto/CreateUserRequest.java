package com.capstone.sistema.users.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * Alta de usuario. Los roles se eligen exclusivamente como {@code roleIds} (roles v5);
 * el administrador global no se gestiona desde la plataforma (se define en Keycloak).
 */
public record CreateUserRequest(
        @NotBlank(message = "El correo electrónico es obligatorio")
        @Email(message = "El correo electrónico no tiene un formato válido")
        @Size(max = 254, message = "El correo electrónico no puede superar 254 caracteres")
        String email,

        @NotBlank(message = "El RUT es obligatorio")
        @Size(max = 12, message = "El RUT no puede superar 12 caracteres")
        String rut,

        @NotBlank(message = "El nombre es obligatorio")
        @Size(max = 100, message = "El nombre no puede superar 100 caracteres")
        String firstName,

        @NotBlank(message = "El apellido es obligatorio")
        @Size(max = 100, message = "El apellido no puede superar 100 caracteres")
        String lastName,

        @NotBlank(message = "La contraseña inicial es obligatoria")
        @Size(min = 8, max = 128, message = "La contraseña debe tener entre 8 y 128 caracteres")
        String password,

        Long areaId,

        boolean requirePasswordChange,

        List<@NotNull(message = "El rol no puede ser nulo") @Positive Long> roleIds
) {
    public CreateUserRequest(String email, String rut, String firstName, String lastName, String password,
                             Long areaId, boolean requirePasswordChange) {
        this(email, rut, firstName, lastName, password, areaId, requirePasswordChange, null);
    }

    @Override
    public String toString() {
        return "CreateUserRequest[email=" + email
                + ", rut=" + rut
                + ", firstName=" + firstName
                + ", lastName=" + lastName
                + ", password=[PROTECTED]"
                + ", areaId=" + areaId
                + ", requirePasswordChange=" + requirePasswordChange + "]";
    }
}
