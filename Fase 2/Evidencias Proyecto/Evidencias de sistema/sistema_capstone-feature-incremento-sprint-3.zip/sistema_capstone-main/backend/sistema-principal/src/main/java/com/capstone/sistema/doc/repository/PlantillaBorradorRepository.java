package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.PlantillaBorrador;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PlantillaBorradorRepository extends JpaRepository<PlantillaBorrador, UUID> {

    List<PlantillaBorrador> findByUsuario_IdOrderByUpdatedAtDesc(UUID usuarioId);

    Optional<PlantillaBorrador> findByPlantilla_IdAndUsuario_Id(Long plantillaId, UUID usuarioId);
}
