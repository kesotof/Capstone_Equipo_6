package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.Documento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DocumentoRepository extends JpaRepository<Documento, UUID> {

    Optional<Documento> findFirstByStorageKey(String storageKey);

    @Query("SELECT d FROM Documento d WHERE d.storageKey = :storageKey")
    Optional<Documento> findFirstByStorageKeyOrderByCreatedAtDesc(@Param("storageKey") String storageKey);

    @Query("SELECT d FROM Documento d WHERE d.historialTransicion.solicitud.id = :solicitudId ORDER BY d.version DESC")
    List<Documento> findBySolicitud_IdOrderByVersionDesc(@Param("solicitudId") UUID solicitudId);

    @Query("SELECT d FROM Documento d WHERE d.historialTransicion.solicitud.id = :solicitudId ORDER BY d.version DESC, d.id ASC")
    List<Documento> findBySolicitud_IdOrderByVersionDescCreatedAtDescIdAsc(@Param("solicitudId") UUID solicitudId);

    @Query("SELECT d FROM Documento d WHERE d.historialTransicion.solicitud.id = :solicitudId AND NOT EXISTS (SELECT 1 FROM Documento r WHERE r.reemplazaDocumento.id = d.id)")
    Optional<Documento> findBySolicitud_IdAndVigenteTrue(@Param("solicitudId") UUID solicitudId);

    @Query("SELECT d FROM Documento d WHERE d.historialTransicion.solicitud.id IN :solicitudIds AND NOT EXISTS (SELECT 1 FROM Documento r WHERE r.reemplazaDocumento.id = d.id)")
    List<Documento> findBySolicitud_IdInAndVigenteTrue(@Param("solicitudIds") List<UUID> solicitudIds);

    boolean existsByPlantillaVersion_Plantilla_Id(Long plantillaId);

    long countByPlantillaVersion_Id(Long plantillaVersionId);

    long countByPlantillaVersion_Plantilla_Id(Long plantillaId);
}
