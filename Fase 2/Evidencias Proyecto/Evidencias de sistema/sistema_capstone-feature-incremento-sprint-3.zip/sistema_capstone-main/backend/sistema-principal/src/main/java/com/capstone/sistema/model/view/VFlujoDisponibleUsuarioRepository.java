package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface VFlujoDisponibleUsuarioRepository extends JpaRepository<VFlujoDisponibleUsuario, VFlujoDisponibleUsuarioId> {

    List<VFlujoDisponibleUsuario> findByUsuarioId(UUID usuarioId);

    boolean existsByFlujoIdAndUsuarioId(Long flujoId, UUID usuarioId);
}
