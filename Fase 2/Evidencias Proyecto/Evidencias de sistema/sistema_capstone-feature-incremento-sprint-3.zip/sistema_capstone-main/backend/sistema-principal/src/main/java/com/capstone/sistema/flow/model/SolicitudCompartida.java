package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "solicitud_compartida")
public class SolicitudCompartida {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private UserAccount usuario;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "compartido_por", nullable = false)
    private UserAccount compartidoPor;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected SolicitudCompartida() {
    }

    public SolicitudCompartida(Solicitud solicitud, Area area, UserAccount compartidoPor) {
        this.solicitud = solicitud;
        this.area = area;
        this.compartidoPor = compartidoPor;
    }

    public SolicitudCompartida(Solicitud solicitud, UserAccount usuario, UserAccount compartidoPor) {
        this.solicitud = solicitud;
        this.usuario = usuario;
        this.compartidoPor = compartidoPor;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public Area getArea() {
        return area;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public UserAccount getCompartidoPor() {
        return compartidoPor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SolicitudCompartida that = (SolicitudCompartida) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
