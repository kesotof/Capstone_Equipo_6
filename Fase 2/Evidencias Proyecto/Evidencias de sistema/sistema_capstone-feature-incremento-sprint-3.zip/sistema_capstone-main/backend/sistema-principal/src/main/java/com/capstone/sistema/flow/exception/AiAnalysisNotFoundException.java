package com.capstone.sistema.flow.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.UUID;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AiAnalysisNotFoundException extends RuntimeException {

    public AiAnalysisNotFoundException(UUID solicitudId) {
        super("No se encontró un análisis de IA para la solicitud con ID: " + solicitudId);
    }

    public AiAnalysisNotFoundException(String message) {
        super(message);
    }
}
