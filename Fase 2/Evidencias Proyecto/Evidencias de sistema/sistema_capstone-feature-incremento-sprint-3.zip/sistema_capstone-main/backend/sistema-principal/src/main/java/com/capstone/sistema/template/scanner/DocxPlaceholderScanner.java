package com.capstone.sistema.template.scanner;

import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldType;
import com.capstone.sistema.template.dto.PlaceholderAnalysisResult;
import com.capstone.sistema.template.dto.PlaceholderDetail;
import org.apache.poi.xwpf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Escáner de marcadores {{...}} en documentos DOCX (Apache POI).
 * Identifica marcadores en párrafos, celdas de tablas, encabezados y pies de página.
 * Detecta marcadores partidos entre múltiples runs y marcadores duplicados.
 */
@Component
public class DocxPlaceholderScanner {

    private static final Logger log = LoggerFactory.getLogger(DocxPlaceholderScanner.class);

    // Soporta marcadores de poi-tl: {{variable}}, {{?seccion}}, {{#tabla}}, etc.
    public static final Pattern PLACEHOLDER_PATTERN = Pattern.compile("\\{\\{\\s*([?#@*&]?)([a-zA-Z0-9_\\-.]+)\\s*\\}\\}");

    public PlaceholderAnalysisResult scan(byte[] docxBytes) {
        if (docxBytes == null || docxBytes.length == 0) {
            throw new IllegalArgumentException("El archivo DOCX no puede estar vacío");
        }
        try (InputStream in = new ByteArrayInputStream(docxBytes)) {
            return scan(in);
        } catch (Exception e) {
            log.error("Error al escanear archivo DOCX: {}", e.getMessage());
            throw new IllegalArgumentException("No se pudo analizar el archivo DOCX: " + e.getMessage(), e);
        }
    }

    public PlaceholderAnalysisResult scan(InputStream docxInputStream) {
        List<PlaceholderDetail> details = new ArrayList<>();
        Map<String, Integer> counts = new LinkedHashMap<>();
        Set<String> splitKeys = new LinkedHashSet<>();

        try (XWPFDocument doc = new XWPFDocument(docxInputStream)) {
            // 1. Escanear párrafos del cuerpo principal
            int pIndex = 1;
            for (XWPFParagraph p : doc.getParagraphs()) {
                scanParagraph(p, "Párrafo " + pIndex, details, counts, splitKeys);
                pIndex++;
            }

            // 2. Escanear tablas
            int tIndex = 1;
            for (XWPFTable table : doc.getTables()) {
                int rIndex = 1;
                for (XWPFTableRow row : table.getRows()) {
                    int cIndex = 1;
                    for (XWPFTableCell cell : row.getTableCells()) {
                        String locPrefix = "Tabla " + tIndex + ", Fila " + rIndex + ", Celda " + cIndex;
                        int cpIndex = 1;
                        for (XWPFParagraph cp : cell.getParagraphs()) {
                            scanParagraph(cp, locPrefix + " (P" + cpIndex + ")", details, counts, splitKeys);
                            cpIndex++;
                        }
                        cIndex++;
                    }
                    rIndex++;
                }
                tIndex++;
            }

            // 3. Escanear encabezados
            for (XWPFHeader header : doc.getHeaderList()) {
                int hpIndex = 1;
                for (XWPFParagraph hp : header.getParagraphs()) {
                    scanParagraph(hp, "Encabezado (P" + hpIndex + ")", details, counts, splitKeys);
                    hpIndex++;
                }
            }

            // 4. Escanear pies de página
            for (XWPFFooter footer : doc.getFooterList()) {
                int fpIndex = 1;
                for (XWPFParagraph fp : footer.getParagraphs()) {
                    scanParagraph(fp, "Pie de página (P" + fpIndex + ")", details, counts, splitKeys);
                    fpIndex++;
                }
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("El archivo no es un documento DOCX válido o está corrupto: " + e.getMessage(), e);
        }

        List<String> distinctKeys = new ArrayList<>(counts.keySet());
        List<String> duplicateKeys = counts.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .map(Map.Entry::getKey)
                .toList();

        List<String> warnings = new ArrayList<>();
        for (String dup : duplicateKeys) {
            warnings.add("El marcador '" + dup + "' aparece " + counts.get(dup) + " veces en el documento.");
        }
        for (String split : splitKeys) {
            warnings.add("El marcador '" + split + "' está dividido entre múltiples fragmentos de texto (runs) en el archivo Word.");
        }
        if (distinctKeys.isEmpty()) {
            warnings.add("No se encontraron marcadores con formato {{nombre}} en el documento.");
        }

        int totalOccurrences = details.size();
        List<FieldDefinition> suggestedFields = buildSuggestedFields(distinctKeys);

        return new PlaceholderAnalysisResult(
                distinctKeys,
                details,
                duplicateKeys,
                new ArrayList<>(splitKeys),
                warnings,
                totalOccurrences,
                suggestedFields
        );
    }

    private void scanParagraph(
            XWPFParagraph paragraph,
            String location,
            List<PlaceholderDetail> details,
            Map<String, Integer> counts,
            Set<String> splitKeys
    ) {
        String text = paragraph.getText();
        if (text == null || text.isBlank()) {
            return;
        }

        List<XWPFRun> runs = paragraph.getRuns();
        List<RunSpan> runSpans = buildRunSpans(runs);

        Matcher matcher = PLACEHOLDER_PATTERN.matcher(text);
        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            String prefix = matcher.group(1); // ?, #, etc.
            String key = matcher.group(2); // nombre_campo

            boolean isSplit = isSpanSplitAcrossRuns(runSpans, start, end);
            if (isSplit) {
                splitKeys.add(key);
            }

            int snippetStart = Math.max(0, start - 15);
            int snippetEnd = Math.min(text.length(), end + 15);
            String snippet = text.substring(snippetStart, snippetEnd);

            details.add(new PlaceholderDetail(key, location, isSplit, snippet));
            counts.put(key, counts.getOrDefault(key, 0) + 1);
        }
    }

    private record RunSpan(int start, int end, String text) {}

    private List<RunSpan> buildRunSpans(List<XWPFRun> runs) {
        List<RunSpan> spans = new ArrayList<>();
        if (runs == null) return spans;
        int current = 0;
        for (XWPFRun run : runs) {
            String rt = run.text();
            if (rt == null) {
                rt = "";
            }
            int len = rt.length();
            spans.add(new RunSpan(current, current + len, rt));
            current += len;
        }
        return spans;
    }

    private boolean isSpanSplitAcrossRuns(List<RunSpan> spans, int start, int end) {
        if (spans.isEmpty()) return false;
        int startRunIndex = -1;
        int endRunIndex = -1;

        for (int i = 0; i < spans.size(); i++) {
            RunSpan span = spans.get(i);
            if (startRunIndex == -1 && start >= span.start() && start < span.end()) {
                startRunIndex = i;
            }
            // el tag termina en 'end', que cae antes o en span.end()
            if (endRunIndex == -1 && end > span.start() && end <= span.end()) {
                endRunIndex = i;
            }
        }

        if (startRunIndex != -1 && endRunIndex != -1 && startRunIndex != endRunIndex) {
            return true;
        }
        return false;
    }

    private List<FieldDefinition> buildSuggestedFields(List<String> keys) {
        List<FieldDefinition> list = new ArrayList<>();
        int order = 1;
        for (String key : keys) {
            String label = toHumanLabel(key);
            FieldType type = inferFieldType(key);
            list.add(new FieldDefinition(
                    key,
                    label,
                    type,
                    true, // por defecto obligatorio
                    type == FieldType.SELECCION ? List.of("Opción 1", "Opción 2") : List.of(),
                    order++,
                    null,
                    null
            ));
        }
        return list;
    }

    private String toHumanLabel(String key) {
        if (key == null || key.isBlank()) return "";
        String[] parts = key.split("[_\\-.]");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isBlank()) continue;
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(Character.toUpperCase(p.charAt(0)));
            if (p.length() > 1) {
                sb.append(p.substring(1));
            }
        }
        return sb.toString();
    }

    private FieldType inferFieldType(String key) {
        String lower = key.toLowerCase(Locale.ROOT);
        if (lower.contains("rut") || lower.contains("run")) {
            return FieldType.RUT;
        }
        if (lower.contains("fecha") || lower.contains("date") || lower.contains("nacimiento") || lower.contains("vencimiento") || lower.contains("plazo")) {
            return FieldType.FECHA;
        }
        if (lower.contains("hora") || lower.contains("time")) {
            return FieldType.HORA;
        }
        if (lower.contains("monto") || lower.contains("total") || lower.contains("precio") || lower.contains("cantidad")
                || lower.contains("numero") || lower.contains("num") || lower.contains("valor")
                || lower.contains("porcentaje") || lower.contains("dias") || lower.contains("edad")
                || lower.contains("ano") || lower.contains("anio")) {
            return FieldType.NUMERO;
        }
        if (lower.startsWith("es_") || lower.startsWith("tiene_") || lower.equals("activo")
                || lower.equals("aprobado") || lower.equals("confirmar") || lower.equals("valido")) {
            return FieldType.BOOLEANO;
        }
        if (lower.contains("descripcion") || lower.contains("observaciones") || lower.contains("comentario")
                || lower.contains("detalle") || lower.contains("motivo") || lower.contains("justificacion")) {
            return FieldType.TEXTO_LARGO;
        }
        return FieldType.TEXTO;
    }
}
