package com.capstone.sistema.template.dto;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.List;

/**
 * Campo del formulario de una plantilla. {@code seccion} agrupa campos en el formulario; {@code condicion} muestra
 * el campo solo cuando otro campo anterior tiene cierto valor; {@code calculo} lo completa con una operación sobre
 * campos numéricos anteriores (el valor lo calcula el backend al generar el documento).
 */
public record FieldDefinition(
        String key,
        String label,
        FieldType tipo,
        boolean obligatorio,
        List<String> opciones,
        int orden,
        String descripcion,
        Object valorPorDefecto,
        String seccion,
        Condicion condicion,
        Calculo calculo
) {
    /** Valor que debe tener el campo {@code campo} ("true"/"false" en Sí/No, o una de sus opciones). */
    public record Condicion(String campo, String valor) {}

    /** SUMA, RESTA (el primero menos los demás), MULTIPLICACION o PORCENTAJE ({@code factor} % del único campo). */
    public record Calculo(String operacion, List<String> campos, Double factor) {}

    @JsonCreator
    public FieldDefinition {
        if (opciones == null) {
            opciones = List.of();
        }
    }

    public FieldDefinition(String key, String label, FieldType tipo, boolean obligatorio, List<String> opciones,
                           int orden, String descripcion, Object valorPorDefecto) {
        this(key, label, tipo, obligatorio, opciones, orden, descripcion, valorPorDefecto, null, null, null);
    }

    public static FieldDefinition of(String key, String label, FieldType tipo, boolean obligatorio, int orden) {
        return new FieldDefinition(key, label, tipo, obligatorio, List.of(), orden, null, null);
    }
}
