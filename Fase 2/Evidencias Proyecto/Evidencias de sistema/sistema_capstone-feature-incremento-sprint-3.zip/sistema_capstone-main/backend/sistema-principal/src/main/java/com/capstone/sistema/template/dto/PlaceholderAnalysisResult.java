package com.capstone.sistema.template.dto;

import java.util.List;

public record PlaceholderAnalysisResult(
        List<String> marcadores,
        List<PlaceholderDetail> detalles,
        List<String> duplicados,
        List<String> partidos,
        List<String> advertencias,
        int totalOcurrencias,
        List<FieldDefinition> camposSugeridos
) {
    public PlaceholderAnalysisResult {
        if (marcadores == null) marcadores = List.of();
        if (detalles == null) detalles = List.of();
        if (duplicados == null) duplicados = List.of();
        if (partidos == null) partidos = List.of();
        if (advertencias == null) advertencias = List.of();
        if (camposSugeridos == null) camposSugeridos = List.of();
    }
}
