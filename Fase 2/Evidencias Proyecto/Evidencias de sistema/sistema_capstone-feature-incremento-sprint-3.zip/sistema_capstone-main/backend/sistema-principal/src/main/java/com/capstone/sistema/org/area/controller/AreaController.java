package com.capstone.sistema.org.area.controller;

import com.capstone.sistema.org.area.dto.AddAreaMemberRequest;
import com.capstone.sistema.org.area.dto.AreaMemberResponse;
import com.capstone.sistema.org.area.dto.AreaResponse;
import com.capstone.sistema.org.area.dto.CreateAreaRequest;
import com.capstone.sistema.org.area.dto.PaginaAreasResponse;
import com.capstone.sistema.org.area.dto.ToggleAreaStatusRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaMemberRoleRequest;
import com.capstone.sistema.org.area.dto.UpdateAreaRequest;
import com.capstone.sistema.org.area.service.AreaService;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/areas")
@PreAuthorize("isAuthenticated()")
public class AreaController {

    private final AreaService areaService;
    private final RbacAccessService access;
    private final com.capstone.sistema.rbac.service.AccesoUsuarioService accesoUsuarioService;

    public AreaController(
            AreaService areaService,
            RbacAccessService access,
            @org.springframework.beans.factory.annotation.Autowired(required = false) com.capstone.sistema.rbac.service.AccesoUsuarioService accesoUsuarioService
    ) {
        this.areaService = areaService;
        this.access = access;
        this.accesoUsuarioService = accesoUsuarioService;
    }

    /** Mutaciones de áreas, miembros y jefaturas: AREA.GESTIONAR. */
    private void requireGestionAreas() {
        access.require(Permiso.AREA_GESTIONAR);
    }

    /** Lecturas: AREA.GESTIONAR o USUARIO.GESTIONAR (la pantalla de usuarios carga el catálogo de áreas). */
    private void requireLecturaAreas() {
        access.requireAny(Permiso.AREA_GESTIONAR, Permiso.USUARIO_GESTIONAR);
    }

    @GetMapping("/{id}/accesos")
    public List<com.capstone.sistema.rbac.dto.RbacDtos.AsignacionAccesoDto> listAccesos(@PathVariable Long id) {
        requireLecturaAreas();
        if (accesoUsuarioService == null) {
            throw new RbacException(HttpStatus.SERVICE_UNAVAILABLE, "SERVICIO_NO_DISPONIBLE",
                    "El servicio de accesos no está disponible. Intente nuevamente más tarde.");
        }
        return accesoUsuarioService.getAccesosPorArea(id);
    }

    @GetMapping("/{id}/jefaturas")
    public List<Map<String, Object>> getJefaturas(@PathVariable Long id) {
        requireLecturaAreas();
        return areaService.getJefaturas(id);
    }

    @PutMapping("/{id}/jefaturas")
    public List<com.capstone.sistema.rbac.dto.RbacDtos.JefaturaItem> updateJefaturas(
            @PathVariable Long id,
            @Valid @RequestBody com.capstone.sistema.rbac.dto.RbacDtos.AreaJefaturasRequest request
    ) {
        requireGestionAreas();
        return areaService.updateJefaturas(id, request.usuarioIds(), request.version());
    }

    @PostMapping
    public ResponseEntity<AreaResponse> create(@Valid @RequestBody CreateAreaRequest request) {
        requireGestionAreas();
        return ResponseEntity.status(HttpStatus.CREATED).body(areaService.create(request));
    }

    @GetMapping
    public PaginaAreasResponse list(@RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "20") int size,
                                    @RequestParam(required = false) Boolean activo,
                                    @RequestParam(required = false) String q) {
        requireLecturaAreas();
        return areaService.list(page, size, activo, q);
    }

    @PutMapping("/{id}")
    public AreaResponse update(@PathVariable Long id, @Valid @RequestBody UpdateAreaRequest request) {
        requireGestionAreas();
        return areaService.update(id, request);
    }

    @PatchMapping("/{id}/status")
    public AreaResponse changeStatus(@PathVariable Long id,
                                     @Valid @RequestBody ToggleAreaStatusRequest request) {
        requireGestionAreas();
        return areaService.changeStatus(id, request);
    }

    @GetMapping("/{id}/miembros")
    public List<AreaMemberResponse> listMembers(@PathVariable Long id) {
        requireLecturaAreas();
        return areaService.listMembers(id);
    }

    @PostMapping("/{id}/miembros")
    public ResponseEntity<AreaMemberResponse> addMember(@PathVariable Long id,
                                                        @Valid @RequestBody AddAreaMemberRequest request) {
        requireGestionAreas();
        return ResponseEntity.status(HttpStatus.CREATED).body(areaService.addMember(id, request));
    }

    @PatchMapping("/{id}/miembros/{usuarioId}")
    public AreaMemberResponse updateMemberRole(@PathVariable Long id,
                                               @PathVariable UUID usuarioId,
                                               @Valid @RequestBody UpdateAreaMemberRoleRequest request) {
        requireGestionAreas();
        return areaService.updateMemberRole(id, usuarioId, request);
    }

    @DeleteMapping("/{id}/miembros/{usuarioId}")
    public ResponseEntity<Void> removeMember(@PathVariable Long id,
                                             @PathVariable UUID usuarioId) {
        requireGestionAreas();
        areaService.removeMember(id, usuarioId);
        return ResponseEntity.noContent().build();
    }
}
