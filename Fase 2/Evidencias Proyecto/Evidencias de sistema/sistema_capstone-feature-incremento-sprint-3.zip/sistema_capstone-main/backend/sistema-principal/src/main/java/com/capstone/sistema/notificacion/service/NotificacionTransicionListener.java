package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.flow.event.TransicionSolicitudEvent;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * F2/F3 + C2: puente único entre el motor de estados y las notificaciones (§6.1, US-36). Traduce
 * {@link TransicionSolicitudEvent} a los compositores de {@link NotificacionService} con los
 * códigos del catálogo V2: REGISTRAR/CORREGIR → REVISION_ASIGNADA a los revisores; APROBAR
 * intermedio → SOLICITUD_AVANZA al emisor + REVISION_ASIGNADA a los revisores; APROBAR final →
 * SOLICITUD_APROBADA; RECHAZAR → SOLICITUD_RECHAZADA; SOLICITAR_CORRECCION →
 * CORRECCION_REQUERIDA; y cuando el administrador global decidió en etapa ajena,
 * DECISION_ADMIN_GLOBAL a los revisores de la etapa origen (CA 37.4).
 *
 * <p>Los textos y enlaces salen del catálogo (§6.1) y la elegibilidad de correo la decide
 * {@code NotificacionService.crear} (D3-01). Las notificaciones son parte atómica de la
 * transición (A-11); los efectos externos (correo) ocurren tras el commit y nunca la rompen.</p>
 */
@Component
public class NotificacionTransicionListener {

    private static final Logger log = LoggerFactory.getLogger(NotificacionTransicionListener.class);

    private final NotificacionService notificacionService;
    private final SolicitudRepository solicitudRepository;
    private final UserAccountRepository userAccountRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;

    public NotificacionTransicionListener(
            NotificacionService notificacionService,
            SolicitudRepository solicitudRepository,
            UserAccountRepository userAccountRepository,
            FlujoEtapaRepository flujoEtapaRepository
    ) {
        this.notificacionService = notificacionService;
        this.solicitudRepository = solicitudRepository;
        this.userAccountRepository = userAccountRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
    }

    @EventListener
    public void onTransicion(TransicionSolicitudEvent evento) {
        Solicitud solicitud = solicitudRepository.findById(evento.solicitudId()).orElse(null);
        if (solicitud == null) {
            log.warn("Solicitud {} no encontrada al notificar transición; se ignoran avisos",
                    evento.solicitudId());
            return;
        }
        UserAccount actor = evento.actorId() != null
                ? userAccountRepository.findById(evento.actorId()).orElse(null)
                : null;
        NotificacionContexto ctx = construirContexto(solicitud, evento, actor);

        switch (evento.accion()) {
            case "REGISTRAR" -> notificacionService.notificarRevisionAsignada(solicitud, ctx);
            case "APROBAR" -> {
                if ("APROBADO".equals(evento.estadoDestino())) {
                    notificacionService.notificarSolicitudAprobada(solicitud, ctx);
                } else {
                    notificacionService.notificarSolicitudAvanza(solicitud, ctx);
                    notificacionService.notificarRevisionAsignada(solicitud, ctx);
                }
            }
            case "RECHAZAR" -> notificacionService.notificarSolicitudRechazada(solicitud, ctx);
            case "SOLICITAR_CORRECCION" -> notificacionService.notificarCorreccionRequerida(solicitud, ctx);
            case "CORREGIR" -> notificacionService.notificarRevisionAsignada(solicitud, ctx);
            default -> log.debug("Acción {} sin notificaciones de catálogo", evento.accion());
        }

        if (evento.actuoComoAdmin() && evento.revisoresEtapaOrigen() != null
                && !evento.revisoresEtapaOrigen().isEmpty()) {
            notificacionService.notificarDecisionAdmin(solicitud, ctx, evento.revisoresEtapaOrigen());
        }
    }

    /** §6.1: contexto con etapas (por nombre), plazo, actor, emisor y observación de la transición. */
    private NotificacionContexto construirContexto(Solicitud solicitud, TransicionSolicitudEvent evento,
                                                   UserAccount actor) {
        return new NotificacionContexto(
                solicitud.getId(),
                evento.historialId(),
                solicitud.getCorrelativo(),
                solicitud.getTitulo(),
                solicitud.getTipoDocumento(),
                nombreEtapa(evento.etapaOrigenId()),
                nombreEtapa(evento.etapaDestinoId()),
                nombreCompleto(actor),
                nombreCompleto(solicitud.getEmisor()),
                evento.actorId(),
                solicitud.getDeadline(),
                evento.observacion(),
                evento.accion()
        );
    }

    private String nombreEtapa(Long etapaId) {
        if (etapaId == null || flujoEtapaRepository == null) {
            return null;
        }
        return flujoEtapaRepository.findById(etapaId).map(FlujoEtapa::getNombre).orElse(null);
    }

    private String nombreCompleto(UserAccount user) {
        if (user == null) {
            return "Sistema";
        }
        String nombre = user.getFirstName() != null ? user.getFirstName() : "";
        String apellido = user.getLastName() != null ? user.getLastName() : "";
        String full = (nombre + " " + apellido).trim();
        return full.isEmpty() ? user.getEmail() : full;
    }
}
