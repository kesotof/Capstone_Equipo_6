package com.capstone.sistema.rbac.service;

import com.capstone.sistema.model.view.VPermisoEfectivo;
import com.capstone.sistema.model.view.VPermisoEfectivoRepository;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.repository.RolRepository;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional(readOnly = true)
public class AccesoEfectivoService {

    private final VPermisoEfectivoRepository permisoEfectivoRepository;
    private final UserAccountRepository userAccountRepository;
    private final AreaRepository areaRepository;
    private final RolRepository rolRepository;
    private final JdbcTemplate jdbc;
    private final RbacAccessService accessService;

    public AccesoEfectivoService(
            VPermisoEfectivoRepository permisoEfectivoRepository,
            UserAccountRepository userAccountRepository,
            AreaRepository areaRepository,
            RolRepository rolRepository,
            JdbcTemplate jdbc,
            RbacAccessService accessService
    ) {
        this.permisoEfectivoRepository = permisoEfectivoRepository;
        this.userAccountRepository = userAccountRepository;
        this.areaRepository = areaRepository;
        this.rolRepository = rolRepository;
        this.jdbc = jdbc;
        this.accessService = accessService;
    }

    public AccesoEfectivoResponse getAccesoEfectivo(UUID usuarioId) {
        // El propio usuario puede leer su acceso efectivo; el de otro exige gestión de accesos o AUDITORIA.VER
        accessService.requireSelfOrAny(usuarioId, Permiso.USUARIO_GESTIONAR, Permiso.ROL_GESTIONAR, Permiso.AUDITORIA_CONSULTAR);
        UserAccount user = userAccountRepository.findById(usuarioId)
                .orElseThrow(RbacException::missing);

        List<VPermisoEfectivo> permisosEfectivos = permisoEfectivoRepository.findByUsuarioId(usuarioId);

        // Agrupar por código de permiso (RECURSO.ACCION)
        Map<String, PermisoBuilder> groups = new LinkedHashMap<>();
        Map<Long, Area> areaCache = new HashMap<>();
        Map<Long, Rol> rolCache = new HashMap<>();

        for (VPermisoEfectivo pe : permisosEfectivos) {
            String code = pe.getRecurso().toUpperCase() + "." + pe.getAccion().toUpperCase();
            PermisoBuilder builder = groups.computeIfAbsent(code, k -> new PermisoBuilder(code));

            if (pe.getAreaId() == null) {
                builder.global = true;
            } else {
                Area area = areaCache.computeIfAbsent(pe.getAreaId(), id -> areaRepository.findById(id).orElse(null));
                builder.areas.put(pe.getAreaId(), area != null ? area.getNombre() : "Área #" + pe.getAreaId());
            }

            Rol rol = null;
            if (pe.getRolId() != null) {
                rol = rolCache.computeIfAbsent(pe.getRolId(), id -> rolRepository.findById(id).orElse(null));
            }
            Area areaAsignada = null;
            if (pe.getAreaAsignadaId() != null) {
                areaAsignada = areaCache.computeIfAbsent(pe.getAreaAsignadaId(), id -> areaRepository.findById(id).orElse(null));
            }

            builder.motivos.add(new MotivoAcceso(
                    pe.getOrigen(),
                    pe.getRolId(),
                    rol != null ? rol.getCodigo() : null,
                    rol != null ? rol.getNombre() : null,
                    pe.getAreaAsignadaId(),
                    areaAsignada != null ? areaAsignada.getNombre() : null
            ));
        }

        List<PermisoEfectivoItem> items = new ArrayList<>();
        for (PermisoBuilder b : groups.values()) {
            List<AreaRef> areasList = b.global ? List.of() : b.areas.entrySet().stream()
                    .map(e -> new AreaRef(e.getKey(), e.getValue()))
                    .sorted(Comparator.comparing(AreaRef::nombre))
                    .toList();
            items.add(new PermisoEfectivoItem(b.codigo, b.global, areasList, b.motivos));
        }

        // Resumen de hechos
        int revisorEtapas = 0;
        try {
            Integer count = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM flujo_etapa_revisor WHERE usuario_id = ?", Integer.class, usuarioId);
            if (count != null) revisorEtapas = count;
        } catch (Exception ignored) {
        }

        boolean esJefatura = false;
        try {
            Integer count = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM area_jefatura WHERE usuario_id = ?", Integer.class, usuarioId);
            if (count != null && count > 0) esJefatura = true;
        } catch (Exception ignored) {
        }

        int flujosDisponibles = 0;
        try {
            Integer count = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM v_flujo_disponible_usuario WHERE usuario_id = ?", Integer.class, usuarioId);
            if (count != null) flujosDisponibles = count;
        } catch (Exception ignored) {
        }
        boolean puedeEmitir = user.getArea() != null && flujosDisponibles > 0;

        ResumenHechos resumen = new ResumenHechos(revisorEtapas, esJefatura, puedeEmitir, flujosDisponibles);

        return new AccesoEfectivoResponse(
                user.getId(),
                user.getNombreCompleto() != null ? user.getNombreCompleto() : user.getEmail(),
                items,
                resumen
        );
    }

    private static class PermisoBuilder {
        final String codigo;
        boolean global = false;
        final Map<Long, String> areas = new LinkedHashMap<>();
        final List<MotivoAcceso> motivos = new ArrayList<>();

        PermisoBuilder(String codigo) {
            this.codigo = codigo;
        }
    }
}
