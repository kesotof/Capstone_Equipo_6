package com.capstone.sistema.org.area.dto;

import java.util.UUID;

public record AreaMemberResponse(
        UUID id,
        String email,
        String nombre,
        String rut,
        boolean activo,
        boolean esJefeArea
) {}
