package com.capstone.sistema.org.area.repository;

import com.capstone.sistema.org.area.model.AreaJefatura;
import com.capstone.sistema.org.area.model.AreaJefaturaId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface AreaJefaturaRepository extends JpaRepository<AreaJefatura, AreaJefaturaId> {

    @Query("SELECT aj FROM AreaJefatura aj LEFT JOIN FETCH aj.usuario WHERE aj.areaId = :areaId")
    List<AreaJefatura> findByAreaId(@Param("areaId") Long areaId);

    List<AreaJefatura> findByUsuarioId(UUID usuarioId);

    boolean existsByAreaIdAndUsuarioId(Long areaId, UUID usuarioId);

    void deleteByAreaIdAndUsuarioId(Long areaId, UUID usuarioId);

    @Query("SELECT aj FROM AreaJefatura aj WHERE aj.areaId = :areaId")
    List<AreaJefatura> findById_AreaId(@Param("areaId") Long areaId);

    @Query("SELECT aj FROM AreaJefatura aj WHERE aj.usuarioId = :usuarioId")
    List<AreaJefatura> findById_UsuarioId(@Param("usuarioId") UUID usuarioId);

    @Query("SELECT COUNT(aj) > 0 FROM AreaJefatura aj WHERE aj.areaId = :areaId AND aj.usuarioId = :usuarioId")
    boolean existsById_AreaIdAndId_UsuarioId(@Param("areaId") Long areaId, @Param("usuarioId") UUID usuarioId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("DELETE FROM AreaJefatura aj WHERE aj.areaId = :areaId AND aj.usuarioId = :usuarioId")
    void deleteById_AreaIdAndId_UsuarioId(@Param("areaId") Long areaId, @Param("usuarioId") UUID usuarioId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("DELETE FROM AreaJefatura aj WHERE aj.areaId = :areaId")
    void deleteByAreaId(@Param("areaId") Long areaId);
}
