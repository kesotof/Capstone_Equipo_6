package com.capstone.sistema.doc.model;

import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "documento", indexes = {
        @Index(name = "idx_doc_transicion", columnList = "historial_transicion_id"),
        @Index(name = "idx_doc_plantilla", columnList = "plantilla_version_id")
})
@Immutable
public class Documento {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "historial_transicion_id", nullable = false)
    private HistorialTransicion historialTransicion;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reemplaza_documento_id", unique = true)
    private Documento reemplazaDocumento;

    @Column(nullable = false)
    private int version = 1;

    @Column(name = "nombre_archivo", nullable = false, length = 255)
    private String nombreArchivo;

    @Column(name = "content_type", nullable = false, length = 100)
    private String contentType;

    @Column(name = "storage_key", nullable = false, unique = true, length = 500)
    private String storageKey;

    @Column(name = "size_bytes", nullable = false)
    private Long sizeBytes;

    @Column(name = "checksum_sha256", nullable = false, length = 64)
    private String checksumSha256;

    @Column(name = "storage_version_id", length = 100)
    private String storageVersionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plantilla_version_id")
    private PlantillaVersion plantillaVersion;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "datos_plantilla", columnDefinition = "jsonb")
    private String datosPlantilla;

    protected Documento() {
    }

    public Documento(
            HistorialTransicion historialTransicion,
            Documento reemplazaDocumento,
            int version,
            String nombreArchivo,
            String contentType,
            String storageKey,
            Long sizeBytes,
            String checksumSha256,
            String storageVersionId,
            PlantillaVersion plantillaVersion,
            String datosPlantilla
    ) {
        this.historialTransicion = historialTransicion;
        this.reemplazaDocumento = reemplazaDocumento;
        this.version = version;
        this.nombreArchivo = nombreArchivo;
        this.contentType = contentType;
        this.storageKey = storageKey;
        this.sizeBytes = sizeBytes;
        this.checksumSha256 = checksumSha256;
        this.storageVersionId = storageVersionId;
        this.plantillaVersion = plantillaVersion;
        this.datosPlantilla = datosPlantilla;
    }

    public Documento(
            HistorialTransicion historialTransicion,
            String nombreArchivo,
            String contentType,
            String storageKey,
            Long sizeBytes,
            String checksumSha256
    ) {
        this(historialTransicion, null, 1, nombreArchivo, contentType, storageKey, sizeBytes, checksumSha256, null, null, null);
    }

    public Documento(
            Solicitud solicitud,
            FormatoDocumento formatoDocumento,
            String nombreArchivo,
            String contentType,
            String storageKey,
            Long sizeBytes,
            int version,
            boolean vigente
    ) {
        this.solicitudShim = solicitud;
        this.nombreArchivo = nombreArchivo;
        this.contentType = contentType;
        this.storageKey = storageKey;
        this.sizeBytes = sizeBytes;
        this.version = version;
        this.checksumSha256 = "0000000000000000000000000000000000000000000000000000000000000000";
    }

    public UUID getId() {
        return id;
    }

    public HistorialTransicion getHistorialTransicion() {
        return historialTransicion;
    }

    public Documento getReemplazaDocumento() {
        return reemplazaDocumento;
    }

    public int getVersion() {
        return version;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getContentType() {
        return contentType;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public Long getSizeBytes() {
        return sizeBytes;
    }

    public String getChecksumSha256() {
        return checksumSha256;
    }

    public String getStorageVersionId() {
        return storageVersionId;
    }

    public PlantillaVersion getPlantillaVersion() {
        return plantillaVersion;
    }

    public String getDatosPlantilla() {
        return datosPlantilla;
    }

    public void setHistorialTransicion(HistorialTransicion historialTransicion) {
        this.historialTransicion = historialTransicion;
    }

    public void setReemplazaDocumento(Documento reemplazaDocumento) {
        this.reemplazaDocumento = reemplazaDocumento;
    }

    // Shims de compatibilidad con código existente
    @Transient
    private Boolean vigenteShim;

    @Transient
    private Solicitud solicitudShim;

    @Transient
    public Solicitud getSolicitud() {
        if (historialTransicion != null && historialTransicion.getSolicitud() != null) {
            return historialTransicion.getSolicitud();
        }
        return solicitudShim;
    }

    @Transient
    public Instant getCreatedAt() {
        return historialTransicion != null ? historialTransicion.getCreatedAt() : Instant.now();
    }

    @Transient
    public boolean isVigente() {
        return vigenteShim != null ? vigenteShim : true;
    }

    public void setVigente(boolean vigente) {
        this.vigenteShim = vigente;
    }

    @Transient
    public FormatoDocumento getFormatoDocumento() {
        String ext = "pdf";
        if (contentType != null) {
            if (contentType.contains("wordprocessingml") || contentType.contains("docx")) ext = "docx";
            else if (contentType.contains("msword") || contentType.contains("doc")) ext = "doc";
            else if (contentType.contains("xml")) ext = "xml";
            else if (contentType.contains("text/plain")) ext = "txt";
        }
        return new FormatoDocumento(1L, ext);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Documento that = (Documento) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
