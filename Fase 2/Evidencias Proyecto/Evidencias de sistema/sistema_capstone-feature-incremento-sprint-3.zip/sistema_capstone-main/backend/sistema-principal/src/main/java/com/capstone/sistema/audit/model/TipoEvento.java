package com.capstone.sistema.audit.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

/**
 * Catálogo TIPO_EVENTO (V1). Los tipos se siembran por migración (V2, V4); la aplicación no los crea.
 * Acceso por campo: el único atributo persistente del código es {@code codigo}; {@link #getTipo()} es
 * un alias de lectura (no mapeado) que se conserva por compatibilidad con los DTO de auditoría.
 */
@Entity
@Table(name = "tipo_evento")
public class TipoEvento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "codigo", nullable = false, unique = true, length = 50)
    private String codigo;

    /** AUTENTICACION | ADMINISTRACION | FLUJO | ACCESO (CHECK de V1). */
    @Column(name = "categoria", nullable = false, length = 30)
    private String categoria;

    @Column(name = "descripcion", length = 255)
    private String descripcion;

    protected TipoEvento() {
    }

    public TipoEvento(String codigo, String categoria, String descripcion) {
        this.codigo = codigo;
        this.categoria = categoria;
        this.descripcion = descripcion;
    }

    public Long getId() {
        return id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /** Alias de {@link #getCodigo()} (no es una columna). */
    public String getTipo() {
        return codigo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoEvento that = (TipoEvento) o;
        return Objects.equals(codigo, that.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
