package com.capstone.sistema.ia.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.dto.IaErrorMensajes;
import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.dto.IaMensajeChatDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * F6 (§6.6, §6.8, §7): gestión de evaluaciones y tareas de IA.
 */
@Service
public class IaTareaService {

    private static final Logger log = LoggerFactory.getLogger(IaTareaService.class);
    private static final String CRITERIO_GENERAL_POR_DEFECTO =
            "Validar coherencia general, datos completos y ausencia de errores evidentes.";

    private final IaProperties iaProperties;
    private final IaTareaRepository iaTareaRepository;
    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final IaAccesoPolicy accesoPolicy;
    private final IaComandoFactory comandoFactory;
    private final MensajePublicador publicador;
    private final AuditService auditService;

    public IaTareaService(
            IaProperties iaProperties,
            IaTareaRepository iaTareaRepository,
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            IaAccesoPolicy accesoPolicy,
            IaComandoFactory comandoFactory,
            MensajePublicador publicador,
            AuditService auditService
    ) {
        this.iaProperties = iaProperties;
        this.iaTareaRepository = iaTareaRepository;
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.accesoPolicy = accesoPolicy;
        this.comandoFactory = comandoFactory;
        this.publicador = publicador;
        this.auditService = auditService;
    }

    @Transactional(readOnly = true)
    public List<IaEvaluacionDto> consultarEvaluaciones(UUID solicitudId, UUID usuarioId) {
        validarVisibilidad(solicitudId, usuarioId);

        Solicitud solicitud = solicitudRepository.findById(solicitudId)
                .orElseThrow(() -> IaException.noEncontrada("Solicitud no encontrada"));
        UUID docVigenteId = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .map(Documento::getId).orElse(null);
        Long etapaActualId = solicitud.getFlujoEtapa() != null ? solicitud.getFlujoEtapa().getId() : null;

        List<IaTarea> tareas = iaTareaRepository.findEvaluaciones(solicitudId);
        return tareas.stream()
                .map(t -> toEvaluacionDto(t, docVigenteId, etapaActualId))
                .toList();
    }

    @Transactional
    public IaEvaluacionDto crearEvaluacionManual(UUID solicitudId, UserAccount usuario) {
        return crearEvaluacionManual(solicitudId, usuario, null, false);
    }

    @Transactional
    public IaEvaluacionDto crearEvaluacionManual(
            UUID solicitudId,
            UserAccount usuario,
            String instruccionPersonalizada,
            boolean permitirCriterioGeneral
    ) {
        if (!iaProperties.habilitada()) {
            throw IaException.deshabilitada();
        }
        if (!accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)) {
            throw IaException.noEncontrada("Solicitud no encontrada");
        }
        if (!accesoPolicy.puedeVer(usuario.getId(), solicitudId)) {
            throw IaException.accesoDenegado();
        }
        if (!accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)) {
            throw IaException.accesoDenegado();
        }

        Solicitud solicitud = solicitudRepository.findById(solicitudId)
                .orElseThrow(() -> IaException.noEncontrada("Solicitud no encontrada"));

        String estado = solicitud.getEstadoSolicitud() != null ? solicitud.getEstadoSolicitud().getCodigo() : null;
        if (!"PENDIENTE_REVISION".equals(estado)) {
            throw IaException.solicitudNoEnRevision();
        }

        FlujoEtapa etapa = solicitud.getFlujoEtapa();
        String criterioEtapa = (etapa != null && etapa.getCriterioIa() != null && !etapa.getCriterioIa().trim().isEmpty())
                ? etapa.getCriterioIa().trim()
                : null;
        String criterioPersonalizado = (instruccionPersonalizada != null && !instruccionPersonalizada.trim().isEmpty())
                ? instruccionPersonalizada.trim()
                : null;

        String criterio;
        if (criterioPersonalizado != null) {
            criterio = criterioPersonalizado;
        } else if (criterioEtapa != null) {
            criterio = criterioEtapa;
        } else if (permitirCriterioGeneral && etapa != null) {
            criterio = CRITERIO_GENERAL_POR_DEFECTO;
        } else {
            throw IaException.sinCriterio();
        }

        // Una evaluación manual pendiente por usuario en esta solicitud (§6.6 / índice único)
        boolean enCurso = iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
                solicitudId, TipoTareaIa.EVALUACION, usuario.getId(), EstadoTareaIa.PENDIENTE
        );
        if (enCurso) {
            throw IaException.tareaEnCurso();
        }

        Documento docVigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> IaException.noEncontrada("No se encontró documento vigente para la solicitud"));

        String sha256 = IaEvaluacionAutomaticaListener.calcularSha256(criterio);

        IaTarea tarea = new IaTarea(
                TipoTareaIa.EVALUACION,
                OrigenTareaIa.MANUAL,
                solicitud,
                docVigente,
                etapa,
                null,
                null,
                null,
                null,
                null,
                criterio,
                sha256,
                usuario
        );
        try {
            iaTareaRepository.saveAndFlush(tarea);
        } catch (DataIntegrityViolationException e) {
            log.warn("Violación de integridad al guardar evaluación manual (carrera concurrente): {}", e.getMessage());
            throw IaException.tareaEnCurso();
        }

        ComandoTareaIa comando = comandoFactory.crearComando(tarea);
        publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_IA_EJECUTAR, comando, comando.mensajeId());

        String datosDespues = "{\"tareaId\":\"" + tarea.getId() + "\",\"origen\":\"MANUAL\"}";
        auditService.registerAuditEvent("ANALISIS_IA_SOLICITADO", "solicitud", solicitudId.toString(), "EXITO", datosDespues);
        log.info("Evaluación manual de IA solicitada: tarea={} solicitud={} usuario={}",
                tarea.getId(), solicitudId, usuario.getEmail());

        return toEvaluacionDto(tarea, docVigente.getId(), etapa != null ? etapa.getId() : null);
    }

    @Transactional(readOnly = true)
    public Object consultarTarea(UUID solicitudId, UUID tareaId, UUID usuarioId) {
        validarVisibilidad(solicitudId, usuarioId);

        IaTarea tarea = iaTareaRepository.findBySolicitudIdAndId(solicitudId, tareaId)
                .orElseThrow(() -> IaException.noEncontrada("Tarea de IA no encontrada"));

        if (tarea.getTipo() == TipoTareaIa.EVALUACION) {
            Solicitud solicitud = tarea.getSolicitud();
            UUID docVigenteId = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                    .map(Documento::getId).orElse(null);
            Long etapaActualId = solicitud != null && solicitud.getFlujoEtapa() != null
                    ? solicitud.getFlujoEtapa().getId() : null;
            return toEvaluacionDto(tarea, docVigenteId, etapaActualId);
        } else if (tarea.getTipo() == TipoTareaIa.CHAT) {
            return toChatDto(tarea);
        }

        throw IaException.noEncontrada("Tipo de tarea no consultable vía este endpoint");
    }

    private void validarVisibilidad(UUID solicitudId, UUID usuarioId) {
        if (!accesoPolicy.existeSolicitudConAcceso(usuarioId, solicitudId)) {
            throw IaException.noEncontrada("Solicitud no encontrada");
        }
        if (!accesoPolicy.puedeVer(usuarioId, solicitudId)) {
            throw IaException.accesoDenegado();
        }
    }

    public static IaEvaluacionDto toEvaluacionDto(IaTarea t, UUID docVigenteId, Long etapaActualId) {
        boolean vigente = t.getDocumento() != null
                && Objects.equals(t.getDocumento().getId(), docVigenteId)
                && t.getFlujoEtapa() != null
                && Objects.equals(t.getFlujoEtapa().getId(), etapaActualId);

        IaEvaluacionDto.EtapaDto etapaDto = t.getFlujoEtapa() != null
                ? new IaEvaluacionDto.EtapaDto(t.getFlujoEtapa().getId(), t.getFlujoEtapa().getNombre())
                : null;
        IaEvaluacionDto.DocumentoDto docDto = t.getDocumento() != null
                ? new IaEvaluacionDto.DocumentoDto(t.getDocumento().getId(), t.getDocumento().getVersion(), t.getDocumento().getNombreArchivo())
                : null;
        IaEvaluacionDto.SolicitadoPorDto autorDto = t.getSolicitadoPor() != null
                ? new IaEvaluacionDto.SolicitadoPorDto(t.getSolicitadoPor().getId(), t.getSolicitadoPor().getNombreCompleto())
                : null;
        IaEvaluacionDto.ErrorDto errorDto = t.getEstado() == EstadoTareaIa.FALLIDA
                ? new IaEvaluacionDto.ErrorDto(t.getCodigoError(), IaErrorMensajes.mensajeAmigable(t.getCodigoError()))
                : null;

        return new IaEvaluacionDto(
                t.getId(),
                t.getEstado().name(),
                t.getOrigen().name(),
                etapaDto,
                docDto,
                t.getInstruccion(),
                t.getResultado(),
                errorDto,
                autorDto,
                t.getModelo(),
                vigente,
                t.getCreatedAt(),
                t.getCompletedAt(),
                IaEvaluacionDto.AVISO_LEGAL
        );
    }

    public static IaMensajeChatDto toChatDto(IaTarea t) {
        String respuesta = t.getResultado() != null && t.getResultado().has("respuesta")
                ? t.getResultado().get("respuesta").asText()
                : null;
        IaMensajeChatDto.AutorDto autorDto = t.getSolicitadoPor() != null
                ? new IaMensajeChatDto.AutorDto(t.getSolicitadoPor().getId(), t.getSolicitadoPor().getNombreCompleto())
                : null;
        Integer docVersion = t.getDocumento() != null ? t.getDocumento().getVersion() : null;
        IaEvaluacionDto.ErrorDto errorDto = t.getEstado() == EstadoTareaIa.FALLIDA
                ? new IaEvaluacionDto.ErrorDto(t.getCodigoError(), IaErrorMensajes.mensajeAmigable(t.getCodigoError()))
                : null;

        return new IaMensajeChatDto(
                t.getId(),
                t.getEstado().name(),
                t.getInstruccion(),
                respuesta,
                autorDto,
                docVersion,
                errorDto,
                t.getCreatedAt(),
                t.getCompletedAt()
        );
    }
}
