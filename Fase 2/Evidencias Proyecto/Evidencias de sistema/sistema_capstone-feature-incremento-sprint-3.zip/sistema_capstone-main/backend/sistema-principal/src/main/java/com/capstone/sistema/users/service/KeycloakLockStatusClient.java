package com.capstone.sistema.users.service;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import org.keycloak.admin.client.Keycloak;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import java.time.Duration;

@Component
public class KeycloakLockStatusClient {

    private static final Logger log = LoggerFactory.getLogger(KeycloakLockStatusClient.class);

    private final RestClient restClient;
    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties keycloakProperties;

    public KeycloakLockStatusClient(
            RestClient.Builder restClientBuilder,
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties keycloakProperties
    ) {
        var requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(Duration.ofSeconds(3));
        requestFactory.setReadTimeout(Duration.ofSeconds(10));
        this.restClient = restClientBuilder.requestFactory(requestFactory).baseUrl(keycloakProperties.serverUrl()).build();
        this.keycloakAdminClient = keycloakAdminClient;
        this.keycloakProperties = keycloakProperties;
    }

    public record BruteForceStatus(boolean disabled, int numFailures) {
    }

    public BruteForceStatus getBruteForceStatus(String keycloakUserId) {
        if (keycloakUserId == null || keycloakUserId.isBlank()) {
            return null;
        }
        try {
            return restClient.get()
                    .uri(
                            "/admin/realms/{realm}/attack-detection/brute-force/users/{userId}",
                            keycloakProperties.targetRealm(),
                            keycloakUserId
                    )
                    .headers(headers -> headers.setBearerAuth(
                            keycloakAdminClient.tokenManager().getAccessToken().getToken()
                    ))
                    .retrieve()
                    .body(BruteForceStatus.class);
        } catch (RuntimeException exception) {
            log.warn("No fue posible consultar el estado brute force de la cuenta {}", keycloakUserId, exception);
            return null;
        }
    }

    public boolean isTemporarilyLocked(String keycloakUserId) {
        BruteForceStatus status = getBruteForceStatus(keycloakUserId);
        return status != null && status.disabled();
    }

    public void unlockUser(String keycloakUserId) {
        if (keycloakUserId == null || keycloakUserId.isBlank()) {
            return;
        }
        try {
            restClient.delete()
                    .uri(
                            "/admin/realms/{realm}/attack-detection/brute-force/users/{userId}",
                            keycloakProperties.targetRealm(),
                            keycloakUserId
                    )
                    .headers(headers -> headers.setBearerAuth(
                            keycloakAdminClient.tokenManager().getAccessToken().getToken()
                    ))
                    .retrieve()
                    .toBodilessEntity();
            log.info("Bloqueo temporal eliminado en Keycloak para usuario {}", keycloakUserId);
        } catch (RuntimeException exception) {
            log.error("No fue posible desbloquear la cuenta {} en Keycloak", keycloakUserId, exception);
            throw new RuntimeException("No fue posible desbloquear la cuenta en Keycloak: " + exception.getMessage(), exception);
        }
    }
}
