package com.capstone.sistema.doc.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.dto.TipoDocumentoDtos.*;
import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.doc.repository.TipoDocumentoRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional(readOnly = true)
public class TipoDocumentoService {

    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final SolicitudRepository solicitudRepository;
    private final AuditService auditService;

    public TipoDocumentoService(
            TipoDocumentoRepository tipoDocumentoRepository,
            SolicitudRepository solicitudRepository,
            AuditService auditService
    ) {
        this.tipoDocumentoRepository = tipoDocumentoRepository;
        this.solicitudRepository = solicitudRepository;
        this.auditService = auditService;
    }

    public List<TipoDocumentoResponse> list(Boolean activo, String q) {
        List<TipoDocumento> all = tipoDocumentoRepository.findAll();
        return all.stream()
                .filter(td -> activo == null || td.isActivo() == activo)
                .filter(td -> {
                    if (q == null || q.isBlank()) return true;
                    String pattern = q.trim().toLowerCase();
                    return td.getNombre().toLowerCase().contains(pattern) ||
                            td.getPrefijo().toLowerCase().contains(pattern);
                })
                .sorted((a, b) -> a.getNombre().compareToIgnoreCase(b.getNombre()))
                .map(this::toResponse)
                .toList();
    }

    public TipoDocumentoResponse get(Long id) {
        TipoDocumento td = tipoDocumentoRepository.findById(id)
                .orElseThrow(RbacException::missing);
        return toResponse(td);
    }

    @Transactional
    public TipoDocumentoResponse create(CrearTipoDocumentoRequest request) {
        String cleanName = validateName(request.nombre());
        String cleanPrefix = validatePrefix(request.prefijo());
        String cleanDesc = validateDescription(request.descripcion());

        if (tipoDocumentoRepository.existsByNombreIgnoreCase(cleanName)) {
            throw RbacException.conflict("TIPO_DOCUMENTO_DUPLICADO", "Ya existe un tipo de documento con el nombre especificado.");
        }
        if (tipoDocumentoRepository.existsByPrefijoIgnoreCase(cleanPrefix)) {
            throw RbacException.conflict("TIPO_DOCUMENTO_PREFIJO_DUPLICADO", "Ya existe un tipo de documento con el prefijo especificado.");
        }

        TipoDocumento td = new TipoDocumento(cleanName, cleanDesc, cleanPrefix, request.plazoDiasHabiles());
        TipoDocumento saved = tipoDocumentoRepository.save(td);

        auditService.registerUserManagementEvent("TIPO_DOCUMENTO_CREADO",
                "Tipo de documento creado: " + saved.getNombre() + " (" + saved.getPrefijo() + ")");

        return toResponse(saved);
    }

    @Transactional
    public TipoDocumentoResponse update(Long id, ActualizarTipoDocumentoRequest request) {
        TipoDocumento td = tipoDocumentoRepository.findById(id)
                .orElseThrow(RbacException::missing);
        checkVersion(td.getLockVersion(), request.version());

        String cleanName = validateName(request.nombre());
        String cleanPrefix = validatePrefix(request.prefijo());
        String cleanDesc = validateDescription(request.descripcion());

        if (tipoDocumentoRepository.existsByNombreIgnoreCaseAndIdNot(cleanName, id)) {
            throw RbacException.conflict("TIPO_DOCUMENTO_DUPLICADO", "Ya existe un tipo de documento con el nombre especificado.");
        }
        if (tipoDocumentoRepository.existsByPrefijoIgnoreCaseAndIdNot(cleanPrefix, id)) {
            throw RbacException.conflict("TIPO_DOCUMENTO_PREFIJO_DUPLICADO", "Ya existe un tipo de documento con el prefijo especificado.");
        }

        td.setNombre(cleanName);
        td.setDescripcion(cleanDesc);
        td.setPrefijo(cleanPrefix);
        td.setPlazoDiasHabiles(request.plazoDiasHabiles());

        TipoDocumento updated = tipoDocumentoRepository.save(td);

        auditService.registerUserManagementEvent("TIPO_DOCUMENTO_EDITADO",
                "Tipo de documento actualizado: " + updated.getNombre() + " (" + updated.getPrefijo() + ")");

        return toResponse(updated);
    }

    @Transactional
    public TipoDocumentoResponse status(Long id, ToggleStatusTipoDocumentoRequest request) {
        TipoDocumento td = tipoDocumentoRepository.findById(id)
                .orElseThrow(RbacException::missing);
        checkVersion(td.getLockVersion(), request.version());

        td.setActivo(request.activo());
        TipoDocumento updated = tipoDocumentoRepository.save(td);

        auditService.registerUserManagementEvent(request.activo() ? "TIPO_DOCUMENTO_ACTIVADO" : "TIPO_DOCUMENTO_DESACTIVADO",
                "Estado de tipo de documento " + updated.getNombre() + " modificado a activo=" + request.activo());

        return toResponse(updated);
    }

    @Transactional
    public void delete(Long id) {
        TipoDocumento td = tipoDocumentoRepository.findById(id)
                .orElseThrow(RbacException::missing);

        if (solicitudRepository.existsByTipoDocumento_Id(id)) {
            throw RbacException.conflict("TIPO_DOCUMENTO_EN_USO",
                    "No se puede eliminar el tipo de documento porque posee solicitudes registradas.");
        }

        tipoDocumentoRepository.delete(td);

        auditService.registerUserManagementEvent("TIPO_DOCUMENTO_ELIMINADO",
                "Tipo de documento eliminado: " + td.getNombre() + " (" + td.getPrefijo() + ")");
    }

    private TipoDocumentoResponse toResponse(TipoDocumento td) {
        return new TipoDocumentoResponse(
                td.getId(),
                td.getNombre(),
                td.getDescripcion(),
                td.getPrefijo(),
                td.getPlazoDiasHabiles(),
                td.getUltimoCorrelativo(),
                td.isActivo(),
                td.getLockVersion(),
                td.getCreatedAt(),
                td.getUpdatedAt()
        );
    }

    private static String validateName(String value) {
        if (value == null) throw RbacException.invalid("El nombre es obligatorio.");
        String name = value.trim();
        if (name.isBlank() || name.length() > 100) throw RbacException.invalid("Nombre inválido (1-100 caracteres).");
        return name;
    }

    private static String validatePrefix(String value) {
        if (value == null) throw RbacException.invalid("El prefijo es obligatorio.");
        String prefix = value.trim().toUpperCase();
        if (!prefix.matches("^[A-Z0-9]{2,10}$")) {
            throw RbacException.invalid("El prefijo debe tener entre 2 y 10 caracteres alfanuméricos.");
        }
        return prefix;
    }

    private static String validateDescription(String value) {
        if (value == null) return null;
        String desc = value.trim();
        if (desc.length() > 500) throw RbacException.invalid("La descripción admite hasta 500 caracteres.");
        return desc.isEmpty() ? null : desc;
    }

    private static void checkVersion(long current, Long requested) {
        if (requested == null || requested < 0) throw RbacException.invalid("Envíe una versión válida.");
        if (current != requested) throw RbacException.conflict("RBAC_VERSION_DESACTUALIZADA", "Los datos cambiaron. Recargue antes de editar.");
    }
}
