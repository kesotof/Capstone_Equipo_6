package com.capstone.sistema.flow.service;
import com.capstone.sistema.notificacion.service.NotificacionService;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.EntityManager;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

/**
 * Responsables de etapa (D-05: lista de usuarios por etapa).
 * Ruta canónica: {@code PUT /api/flujos/{id}/etapas/{stepId}/responsable} con {@code {revisorIds, version}}.
 * Se permite con solicitudes en curso: aplica a las pendientes porque V_REVISOR_SOLICITUD lee FLUJO_ETAPA_REVISOR.
 */
@Service
@Transactional(readOnly = true)
public class FlujoResponsableService {
    private final FlujoDefinicionRepository definitions;
    private final SolicitudRepository requests;
    private final FlujoReviewerResolver reviewers;
    private final FlujoIntegrityService integrity;
    private final FlujoConcurrencyService concurrency;
    private final FlujoConfigService config;
    private final RbacAccessService access;
    private final RbacManagementService security;
    private final NotificacionService notifications;
    private final AuditService audit;
    private final JdbcTemplate jdbc;
    private final EntityManager entityManager;

    public FlujoResponsableService(FlujoDefinicionRepository definitions, SolicitudRepository requests,
            FlujoReviewerResolver reviewers, FlujoIntegrityService integrity,
            FlujoConcurrencyService concurrency, FlujoConfigService config, RbacAccessService access,
            RbacManagementService security, NotificacionService notifications, AuditService audit,
            JdbcTemplate jdbc, EntityManager entityManager) {
        this.definitions=definitions; this.requests=requests; this.reviewers=reviewers;
        this.integrity=integrity; this.concurrency=concurrency; this.config=config; this.access=access;
        this.security=security; this.notifications=notifications; this.audit=audit; this.jdbc=jdbc;
        this.entityManager=entityManager;
    }

    /**
     * Usuarios activos ofrecibles como revisores. {@code roles} queda vacío: D-05 elimina ROL_DEPARTAMENTAL.
     * Con {@code stepId}, solo usuarios compatibles con las solicitudes abiertas de la etapa.
     */
    public ResponsableOptionsResponse options(Long flowId, Long stepId) {
        FlujoDefinicion flow=definitions.findById(flowId).orElseThrow(RbacException::missing);
        access.manageFlow(areaId(flow));
        protectedBase(flow);
        FlujoEtapa current=stepId==null?null:step(flow,stepId);
        List<Solicitud> affected=current==null?List.of():affected(flow,current);
        List<UserAccount> eligible=reviewers.eligibleUsers().stream().filter(UserAccount::isEnabled).toList();
        // Un administrador global es apto sin recorrer las solicitudes abiertas; sus ids se resuelven en una
        // sola consulta. Calcular el perfil RBAC completo de cada candidato era el coste dominante aquí.
        Set<UUID> admins=access.administradorSistemaIds(eligible.stream().map(UserAccount::getId).toList());
        List<ResponsableOptionsResponse.Usuario> users=eligible.stream()
                .filter(user->{
                    if (admins.contains(user.getId())) return true;
                    FlujoEtapa proposal=new FlujoEtapa(flow,current==null?1:current.getOrden(),"Revisión",user);
                    return affected.stream().allMatch(request->access.canOperateAtStage(user,request,proposal));
                })
                .sorted(FlujoEtapa.ORDEN_REVISOR)
                .map(FlujoResponsableService::userOption).toList();
        return new ResponsableOptionsResponse(users,List.of(),flow.getVersion());
    }

    @Transactional
    public FlujoResponse assign(Long flowId, Long stepId, AsignarResponsableRequest request) {
        Set<String> dependencies=security.prepareMutation();
        FlujoDefinicion flow=concurrency.lockDefinition(flowId);
        access.manageFlow(areaId(flow));
        concurrency.checkVersion(flow.getVersion(),request.version(),"FLUJO_VERSION_CONFLICTO");
        protectedBase(flow);
        FlujoEtapa stage=step(flow,stepId);
        List<UUID> requested=FlujoReviewerResolver.requestedReviewers(request.revisorIds(),request.revisorId());
        List<String> previousEmails=FlujoConfigService.reviewerEmails(stage);
        Set<UUID> previousIds=reviewerIds(stage);
        List<Solicitud> affected=affected(flow,stage);
        for (Solicitud pending:affected) {
            jdbc.queryForObject("select id from solicitud where id=? for update",UUID.class,pending.getId());
            entityManager.refresh(pending);
        }
        if (!requested.isEmpty() && previousIds.equals(new HashSet<>(requested))) {
            // Sin cambios: solo se revalida que la etapa siga siendo resoluble.
            reviewers.requireAvailable(stage);
            affected.forEach(pending->reviewers.requireForRequest(pending,stage));
            return config.toResponse(flow);
        }
        Map<UUID,Set<UUID>> previousRecipients=new HashMap<>();
        for (Solicitud pending:affected) {
            if (pending.getFlujoEtapa().getId().equals(stepId)) previousRecipients.put(pending.getId(),
                    new HashSet<>(reviewers.forRequest(pending,stage).stream().map(UserAccount::getId).toList()));
        }
        reviewers.assign(stage,request.tipoAsignacion(),requested);
        entityManager.flush();
        affected.forEach(pending->reviewers.requireForRequest(pending,stage));
        long current=0;
        for (Solicitud pending:affected) {
            if (!pending.getFlujoEtapa().getId().equals(stepId)) continue;
            pending.touch();
            requests.saveAndFlush(pending);
            current++;
            if ("PENDIENTE_REVISION".equalsIgnoreCase(pending.getEstadoSolicitud().getCodigo()))
                notifications.notificarReasignacion(pending,previousRecipients.getOrDefault(pending.getId(),Set.of()));
        }
        flow.setCompleto(integrity.complete(flow));
        flow.touch();
        definitions.saveAndFlush(flow);
        security.finishMutation(dependencies);
        Map<String,Object> detail=new LinkedHashMap<>();
        detail.put("flujoId",flowId);
        detail.put("etapaId",stepId);
        detail.put("etapa",stage.getNombre());
        detail.put("revisoresAntes",previousEmails);
        detail.put("revisoresDespues",FlujoConfigService.reviewerEmails(stage));
        detail.put("solicitudesActuales",current);
        detail.put("version",flow.getVersion());
        audit.registerAuditEvent("ASIGNAR_RESPONSABLE_ETAPA","flujo",String.valueOf(flowId),"EXITO",FlujoConfigService.toJson(detail));
        return config.toResponse(flow);
    }

    private List<Solicitud> affected(FlujoDefinicion flow, FlujoEtapa stage) {
        return requests.findOpenByFlow(flow.getId()).stream()
                .filter(request->request.getFlujoEtapa()!=null && request.getFlujoEtapa().getOrden()<=stage.getOrden()).toList();
    }
    private static FlujoEtapa step(FlujoDefinicion flow, Long id) {
        return flow.getEtapas().stream().filter(stage->Objects.equals(stage.getId(),id)).findFirst().orElseThrow(RbacException::missing);
    }
    private static void protectedBase(FlujoDefinicion flow) {
        if (Long.valueOf(1).equals(flow.getId())) throw RbacException.conflict("FLUJO_BASE_PROTEGIDO","El flujo base conserva su resolución de responsables y no admite reasignación explícita.");
    }
    private static Long areaId(FlujoDefinicion flow) { return flow.getArea()==null?null:flow.getArea().getId(); }
    private static Set<UUID> reviewerIds(FlujoEtapa stage) {
        Set<UUID> ids=new HashSet<>();
        stage.getRevisores().forEach(user->ids.add(user.getId()));
        return ids;
    }
    private static ResponsableOptionsResponse.Usuario userOption(UserAccount user) {
        String name=(Objects.toString(user.getFirstName(),"")+" "+Objects.toString(user.getLastName(),"")).trim();
        return new ResponsableOptionsResponse.Usuario(user.getId(),name.isEmpty()?user.getEmail():name,user.getEmail(),
                user.getArea()==null?null:user.getArea().getNombre());
    }
}
