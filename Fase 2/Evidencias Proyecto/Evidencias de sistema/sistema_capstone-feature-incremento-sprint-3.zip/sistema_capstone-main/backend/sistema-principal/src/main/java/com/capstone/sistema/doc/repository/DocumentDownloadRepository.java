package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class DocumentDownloadRepository {
    private static final String SELECT = """
            select d.id, h.solicitud_id, d.nombre_archivo, d.content_type, d.storage_key, d.size_bytes, d.version
            from documento d
            join historial_transicion h on h.id = d.historial_transicion_id
            """;
    private final JdbcTemplate jdbc;

    public DocumentDownloadRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<DocumentDownloadTarget> byId(UUID id) {
        return query(SELECT + " where d.id = ?", id);
    }

    public List<DocumentDownloadTarget> current(UUID solicitudId) {
        return query("""
            select d.id, d.solicitud_id, d.nombre_archivo, d.content_type, d.storage_key, d.size_bytes, d.version
            from v_documento_vigente d
            where d.solicitud_id = ?
            order by d.id limit 2
            """, solicitudId);
    }

    public List<DocumentDownloadTarget> byKey(String key) {
        return query(SELECT + " where d.storage_key = ? order by d.id limit 2", key);
    }

    public List<DocumentDownloadTarget> anexo(UUID id) {
        return query("""
            select a.id, a.solicitud_id, a.nombre_archivo, a.content_type, a.storage_key, a.size_bytes, 1 as version
            from solicitud_anexo a
            where a.id = ?
            """, id);
    }

    private List<DocumentDownloadTarget> query(String sql, Object parameter) {
        return jdbc.query(sql, (rs, row) -> new DocumentDownloadTarget(
                rs.getObject("id", UUID.class), rs.getObject("solicitud_id", UUID.class),
                rs.getString("nombre_archivo"), rs.getString("content_type"), rs.getString("storage_key"),
                rs.getObject("size_bytes", Long.class), rs.getInt("version")), parameter);
    }
}
