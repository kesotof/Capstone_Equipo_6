package com.capstone.sistema.flow.service;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.dto.AiAnalysisResponse;
import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.service.IaTareaService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AiAnalysisServiceTest {

    private static final UUID SOLICITUD = UUID.randomUUID();

    @Mock
    private IaTareaService iaTareaService;

    @Mock
    private CurrentUserResolver currentUserResolver;

    @InjectMocks
    private AiAnalysisService service;

    @ParameterizedTest
    @CsvSource({"CUMPLE,true", "CUMPLE_PARCIAL,false", "NO_CUMPLE,false", "INDETERMINADO,false"})
    void soloElVeredictoCumpleEsValido(String veredicto, boolean valido) throws Exception {
        AiAnalysisResponse respuesta = analisisCon("""
                {"puntaje": 25, "veredictoSugerido": "%s", "resumen": "Faltan firmas", "hallazgos": [], "recomendaciones": []}
                """.formatted(veredicto));

        assertThat(respuesta.estado()).isEqualTo(EstadoAnalisis.COMPLETADO);
        assertThat(respuesta.valido()).isEqualTo(valido);
        assertThat(respuesta.puntaje()).isEqualTo(25);
        assertThat(respuesta.observaciones()).isEqualTo("Faltan firmas");
    }

    @Test
    void sinRecomendacionesMuestraLosHallazgos() throws Exception {
        AiAnalysisResponse respuesta = analisisCon("""
                {"puntaje": 40, "veredictoSugerido": "NO_CUMPLE", "resumen": "Incompleto",
                 "hallazgos": [{"descripcion": "No hay firma del proveedor", "severidad": "ALTA"}],
                 "recomendaciones": []}
                """);

        assertThat(respuesta.recomendaciones()).containsExactly("No hay firma del proveedor");
    }

    private AiAnalysisResponse analisisCon(String resultadoJson) throws Exception {
        JsonNode resultado = new ObjectMapper().readTree(resultadoJson);
        IaEvaluacionDto evaluacion = new IaEvaluacionDto(UUID.randomUUID(), "COMPLETADA", "MANUAL", null,
                new IaEvaluacionDto.DocumentoDto(UUID.randomUUID(), 1, "contrato.docx"), "Criterio", resultado,
                null, null, "modelo", true, Instant.now(), Instant.now(), IaEvaluacionDto.AVISO_LEGAL);
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.empty());
        when(iaTareaService.consultarEvaluaciones(SOLICITUD, null)).thenReturn(List.of(evaluacion));

        return service.obtenerUltimoAnalisis(SOLICITUD);
    }
}
