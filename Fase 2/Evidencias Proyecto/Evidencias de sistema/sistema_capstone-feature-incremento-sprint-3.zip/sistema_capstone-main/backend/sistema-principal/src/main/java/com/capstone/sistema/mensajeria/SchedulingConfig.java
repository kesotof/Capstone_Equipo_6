package com.capstone.sistema.mensajeria;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * F2 (§6.0): activa el motor de tareas en el principal únicamente si
 * {@code app.scheduling.enabled=true}. Lo consumen RepublicadorPendientes (F5/F7),
 * PlazoAlertaScheduler (F5) y KeycloakEventosImporter (F9).
 */
@Configuration
@EnableScheduling
@ConditionalOnProperty(prefix = "app.scheduling", name = "enabled", havingValue = "true", matchIfMissing = true)
public class SchedulingConfig {
}
