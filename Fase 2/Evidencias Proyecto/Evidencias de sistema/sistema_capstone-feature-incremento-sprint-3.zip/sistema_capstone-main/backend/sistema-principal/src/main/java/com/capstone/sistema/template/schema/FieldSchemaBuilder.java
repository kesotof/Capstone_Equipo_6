package com.capstone.sistema.template.schema;

import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldType;
import com.capstone.sistema.template.dto.FieldValidationError;
import com.capstone.sistema.users.util.RutValidator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Constructor, conversor y validador de esquemas JSON Schema para plantillas DOCX.
 */
@Component
public class FieldSchemaBuilder {

    private static final Logger log = LoggerFactory.getLogger(FieldSchemaBuilder.class);
    private final ObjectMapper objectMapper;

    public FieldSchemaBuilder(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Construye un JSON Schema estándar a partir de las definiciones de campos.
     */
    public String toJsonSchema(String title, String description, List<FieldDefinition> fields) {
        try {
            ObjectNode root = objectMapper.createObjectNode();
            root.put("$schema", "https://json-schema.org/draft/2020-12/schema");
            root.put("type", "object");
            if (title != null && !title.isBlank()) {
                root.put("title", title);
            }
            if (description != null && !description.isBlank()) {
                root.put("description", description);
            }

            ObjectNode properties = root.putObject("properties");
            ArrayNode required = root.putArray("required");
            ArrayNode orderArray = root.putArray("x-field-order");

            // Ordenar por 'orden'
            List<FieldDefinition> sortedFields = new ArrayList<>(fields != null ? fields : List.of());
            sortedFields.sort(Comparator.comparingInt(FieldDefinition::orden));

            for (FieldDefinition f : sortedFields) {
                ObjectNode prop = properties.putObject(f.key());
                prop.put("title", f.label() != null ? f.label() : f.key());
                if (f.descripcion() != null && !f.descripcion().isBlank()) {
                    prop.put("description", f.descripcion());
                }
                prop.put("x-field-type", f.tipo().name());
                prop.put("x-field-order", f.orden());

                switch (f.tipo()) {
                    case TEXTO -> prop.put("type", "string");
                    case TEXTO_LARGO -> {
                        prop.put("type", "string");
                        prop.put("format", "textarea");
                    }
                    case NUMERO -> prop.put("type", "number");
                    case MONTO -> prop.put("type", "integer");
                    case FECHA -> {
                        prop.put("type", "string");
                        prop.put("format", "date");
                    }
                    case HORA -> {
                        prop.put("type", "string");
                        prop.put("format", "time");
                    }
                    case BOOLEANO -> prop.put("type", "boolean");
                    case SELECCION -> {
                        prop.put("type", "string");
                        ArrayNode enumNode = prop.putArray("enum");
                        if (f.opciones() != null) {
                            for (String opt : f.opciones()) {
                                enumNode.add(opt);
                            }
                        }
                    }
                    case RUT -> {
                        prop.put("type", "string");
                        prop.put("format", "rut");
                    }
                }

                if (f.obligatorio()) {
                    required.add(f.key());
                }
                orderArray.add(f.key());
            }

            // Metadatos enriquecidos directos en 'x-fields' para el frontend dinámico
            root.set("x-fields", objectMapper.valueToTree(sortedFields));

            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(root);
        } catch (Exception e) {
            log.error("Error al construir JSON Schema: {}", e.getMessage());
            throw new IllegalStateException("Error al serializar esquema de campos: " + e.getMessage(), e);
        }
    }

    /**
     * Parsea un JSON Schema y extrae la lista ordenada de FieldDefinition.
     */
    public List<FieldDefinition> parseFields(String schemaJson) {
        if (schemaJson == null || schemaJson.isBlank()) {
            return List.of();
        }
        try {
            JsonNode root = objectMapper.readTree(schemaJson);

            // Si contiene x-fields estructurado
            if (root.has("x-fields") && root.get("x-fields").isArray()) {
                return objectMapper.readValue(
                        root.get("x-fields").traverse(),
                        new TypeReference<List<FieldDefinition>>() {}
                );
            }

            // Fallback: extraer desde properties y required
            List<FieldDefinition> fields = new ArrayList<>();
            Set<String> requiredSet = new HashSet<>();
            if (root.has("required") && root.get("required").isArray()) {
                for (JsonNode req : root.get("required")) {
                    requiredSet.add(req.asText());
                }
            }

            JsonNode props = root.get("properties");
            if (props != null && props.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> it = props.fields();
                int order = 1;
                while (it.hasNext()) {
                    Map.Entry<String, JsonNode> entry = it.next();
                    String key = entry.getKey();
                    JsonNode node = entry.getValue();

                    String label = node.has("title") ? node.get("title").asText() : key;
                    String desc = node.has("description") ? node.get("description").asText() : null;
                    boolean mandatory = requiredSet.contains(key);

                    FieldType type = FieldType.TEXTO;
                    if (node.has("x-field-type")) {
                        try {
                            type = FieldType.valueOf(node.get("x-field-type").asText());
                        } catch (Exception ignored) {}
                    } else if (node.has("format")) {
                        String fmt = node.get("format").asText();
                        if ("date".equalsIgnoreCase(fmt)) type = FieldType.FECHA;
                        else if ("time".equalsIgnoreCase(fmt)) type = FieldType.HORA;
                        else if ("textarea".equalsIgnoreCase(fmt)) type = FieldType.TEXTO_LARGO;
                        else if ("rut".equalsIgnoreCase(fmt)) type = FieldType.RUT;
                    } else if (node.has("type") && "number".equalsIgnoreCase(node.get("type").asText())) {
                        type = FieldType.NUMERO;
                    } else if (node.has("type") && "boolean".equalsIgnoreCase(node.get("type").asText())) {
                        type = FieldType.BOOLEANO;
                    } else if (node.has("enum")) {
                        type = FieldType.SELECCION;
                    }

                    List<String> opciones = new ArrayList<>();
                    if (node.has("enum") && node.get("enum").isArray()) {
                        for (JsonNode opt : node.get("enum")) {
                            opciones.add(opt.asText());
                        }
                    }

                    int fieldOrder = node.has("x-field-order") ? node.get("x-field-order").asInt() : order++;
                    fields.add(new FieldDefinition(key, label, type, mandatory, opciones, fieldOrder, desc, null));
                }
            }
            fields.sort(Comparator.comparingInt(FieldDefinition::orden));
            return fields;
        } catch (Exception e) {
            log.error("Error al parsear esquema JSON: {}", e.getMessage());
            throw new IllegalArgumentException("El esquema de campos no es un JSON válido: " + e.getMessage(), e);
        }
    }

    /** Datos del formulario guardados como JSON junto al documento generado; vacío si no hay o no se pueden leer. */
    public Map<String, Object> parseDatos(String datosJson) {
        if (datosJson == null || datosJson.isBlank()) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(datosJson, new TypeReference<LinkedHashMap<String, Object>>() {});
        } catch (Exception e) {
            log.warn("Datos de plantilla ilegibles: {}", e.getMessage());
            return Map.of();
        }
    }

    /**
     * Aplica las reglas del formulario, en su orden: quita el valor de los campos ocultos por su condición y
     * calcula los campos calculados. Se usa antes de validar, generar el documento y guardar los datos.
     */
    public static Map<String, Object> aplicarReglas(List<FieldDefinition> campos, Map<String, Object> datos) {
        Map<String, Object> resultado = new LinkedHashMap<>(datos != null ? datos : Map.of());
        for (FieldDefinition f : campos) {
            if (!visible(f, resultado)) {
                resultado.remove(f.key());
            } else if (f.calculo() != null) {
                Double valor = calcular(f.calculo(), resultado);
                if (valor == null) resultado.remove(f.key());
                else resultado.put(f.key(), valor);
            }
        }
        return resultado;
    }

    /** Un campo con condición se muestra solo si el campo del que depende tiene el valor indicado. */
    public static boolean visible(FieldDefinition f, Map<String, Object> datos) {
        return f.condicion() == null || String.valueOf(datos.get(f.condicion().campo())).equals(f.condicion().valor());
    }

    /** Los vacíos cuentan como 0 al sumar o restar; multiplicar o sacar porcentaje exige todos los valores. */
    private static Double calcular(FieldDefinition.Calculo calculo, Map<String, Object> datos) {
        List<Double> valores = calculo.campos().stream().map(clave -> numero(datos.get(clave))).toList();
        if (valores.stream().allMatch(Objects::isNull)) return null;
        Double resultado = switch (calculo.operacion()) {
            case "SUMA" -> valores.stream().mapToDouble(v -> v == null ? 0 : v).sum();
            case "RESTA" -> valores.get(0) == null ? null
                    : valores.get(0) - valores.stream().skip(1).mapToDouble(v -> v == null ? 0 : v).sum();
            case "MULTIPLICACION" -> valores.contains(null) ? null : valores.stream().reduce(1.0, (a, b) -> a * b);
            case "PORCENTAJE" -> valores.get(0) == null || calculo.factor() == null ? null : valores.get(0) * calculo.factor() / 100;
            default -> null;
        };
        return resultado == null ? null : Math.round(resultado * 100) / 100.0;
    }

    /** Pesos enteros y no negativos: 1250000 o "1250000" (sin puntos de miles, como los envía el formulario). */
    private static boolean montoValido(Object valor) {
        try {
            BigDecimal monto = new BigDecimal(valor.toString().trim()).stripTrailingZeros();
            return monto.signum() >= 0 && monto.scale() <= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static Double numero(Object valor) {
        if (valor instanceof Number n) return n.doubleValue();
        if (valor == null || valor.toString().isBlank()) return null;
        try {
            return Double.parseDouble(valor.toString().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Valida los datos ingresados por el usuario contra las definiciones de campos. Los campos ocultos por su
     * condición y los calculados no se validan: se espera que los datos ya pasaron por {@link #aplicarReglas}.
     */
    public List<FieldValidationError> validateData(List<FieldDefinition> fields, Map<String, Object> data) {
        List<FieldValidationError> errors = new ArrayList<>();
        Map<String, Object> safeData = data != null ? data : Map.of();

        for (FieldDefinition f : fields) {
            if (f.calculo() != null || !visible(f, safeData)) {
                continue;
            }
            Object rawVal = safeData.get(f.key());
            boolean isPresent = rawVal != null && (!(rawVal instanceof String s) || !s.trim().isEmpty());

            if (f.obligatorio() && !isPresent) {
                errors.add(new FieldValidationError(
                        f.key(),
                        "El campo «" + f.label() + "» es obligatorio.",
                        rawVal
                ));
                continue;
            }

            if (!isPresent) {
                continue; // campo no obligatorio y no presente
            }

            // Validar tipos específicos
            switch (f.tipo()) {
                case NUMERO -> {
                    if (!(rawVal instanceof Number)) {
                        try {
                            Double.parseDouble(rawVal.toString().trim().replace(",", "."));
                        } catch (NumberFormatException e) {
                            errors.add(new FieldValidationError(
                                    f.key(),
                                    "El campo «" + f.label() + "» debe ser un valor numérico válido.",
                                    rawVal
                            ));
                        }
                    }
                }
                case MONTO -> {
                    if (!montoValido(rawVal)) {
                        errors.add(new FieldValidationError(
                                f.key(),
                                "El campo «" + f.label() + "» debe ser un monto en pesos, sin decimales.",
                                rawVal
                        ));
                    }
                }
                case FECHA -> {
                    String strDate = rawVal.toString().trim();
                    try {
                        LocalDate.parse(strDate);
                    } catch (DateTimeParseException e) {
                        errors.add(new FieldValidationError(
                                f.key(),
                                "El campo «" + f.label() + "» debe ser una fecha válida (AAAA-MM-DD).",
                                rawVal
                        ));
                    }
                }
                case HORA -> {
                    String strTime = rawVal.toString().trim();
                    try {
                        LocalTime.parse(strTime);
                    } catch (DateTimeParseException e) {
                        errors.add(new FieldValidationError(
                                f.key(),
                                "El campo «" + f.label() + "» debe ser una hora válida, por ejemplo 09:30.",
                                rawVal
                        ));
                    }
                }
                case BOOLEANO -> {
                    if (!(rawVal instanceof Boolean)) {
                        String s = rawVal.toString().trim().toLowerCase(Locale.ROOT);
                        if (!s.equals("true") && !s.equals("false") && !s.equals("1") && !s.equals("0") && !s.equals("si") && !s.equals("no")) {
                            errors.add(new FieldValidationError(
                                    f.key(),
                                    "El campo «" + f.label() + "» debe ser Sí o No.",
                                    rawVal
                            ));
                        }
                    }
                }
                case SELECCION -> {
                    String strOpt = rawVal.toString().trim();
                    if (f.opciones() != null && !f.opciones().isEmpty() && !f.opciones().contains(strOpt)) {
                        errors.add(new FieldValidationError(
                                f.key(),
                                "El valor «" + strOpt + "» no es una opción válida para «" + f.label() + "». Elija una de la lista.",
                                rawVal
                        ));
                    }
                }
                case RUT -> {
                    String strRut = rawVal.toString().trim();
                    if (!RutValidator.esValido(strRut)) {
                        errors.add(new FieldValidationError(
                                f.key(),
                                "El RUT ingresado en «" + f.label() + "» (" + strRut + ") no es válido. Revise el dígito verificador.",
                                rawVal
                        ));
                    }
                }
                case TEXTO, TEXTO_LARGO -> {
                    // Cadenas válidas
                }
            }
        }

        return errors;
    }
}
