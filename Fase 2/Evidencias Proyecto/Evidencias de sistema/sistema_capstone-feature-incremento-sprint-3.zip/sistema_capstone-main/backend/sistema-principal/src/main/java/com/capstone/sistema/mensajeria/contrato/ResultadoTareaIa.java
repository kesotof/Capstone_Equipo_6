package com.capstone.sistema.mensajeria.contrato;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * §5.4 — resultado de service-ia al principal (routing «ia.tarea.resultado»).
 * `resultado` se valida por tipo con los records {@link ResultadoEvaluacion},
 * {@link ResultadoChat} y {@link ResultadoAutocompletado} (IaResultadoProcesador, F6).
 */
public record ResultadoTareaIa(
        int version,
        UUID mensajeId,
        UUID tareaId,
        String tipo,
        String estado,
        JsonNode resultado,
        String modelo,
        String codigoError,
        String errorDetalle,
        Instant ocurridoEn
) {

    public record ResultadoEvaluacion(Integer puntaje, String veredictoSugerido, String resumen,
                                      List<Hallazgo> hallazgos, List<String> recomendaciones) {

        public record Hallazgo(String descripcion, String severidad) {
        }
    }

    public record ResultadoChat(String respuesta) {
    }

    public record ResultadoAutocompletado(Map<String, CampoPropuesto> sugerencias, List<String> noEncontrados) {

        public record CampoPropuesto(JsonNode valor, Double confianza, String fuente) {
        }
    }
}
