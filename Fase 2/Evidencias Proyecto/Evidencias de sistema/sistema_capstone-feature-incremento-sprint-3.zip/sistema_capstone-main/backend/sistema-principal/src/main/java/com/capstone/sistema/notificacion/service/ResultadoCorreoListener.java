package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ResultadoCorreo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * F3 (§3.1/§6.4): consumidor de {@code notificacion.correo.resultado.q} (uno por intento,
 * §5.2). Los payloads inválidos se rechazan sin reenqueue ({@link AmqpRejectAndDontRequeueException});
 * la cola declara DLX en {@link MensajeriaConfig}.
 */
@Component
public class ResultadoCorreoListener {

    private static final Logger log = LoggerFactory.getLogger(ResultadoCorreoListener.class);

    private final ResultadoCorreoService resultadoCorreoService;

    public ResultadoCorreoListener(ResultadoCorreoService resultadoCorreoService) {
        this.resultadoCorreoService = resultadoCorreoService;
    }

    @RabbitListener(queues = MensajeriaConfig.COLA_CORREO_RESULTADO)
    public void onResultado(ResultadoCorreo resultado) {
        log.debug("Resultado de correo recibido: notificación {} intento {} ({})",
                resultado.notificacionId(), resultado.intento(), resultado.resultado());
        resultadoCorreoService.aplicar(resultado);
    }
}
