package com.capstone.sistema.flow.dto;

import com.capstone.sistema.flow.model.TipoAccionEtapa;
import com.capstone.sistema.flow.model.TipoAsignacionRevisor;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;
import java.util.UUID;

/**
 * Etapa de {@code PUT /api/flujos/{id}/etapas}.
 * {@code revisorIds} es la lista de revisores (D-05). {@code revisorId} se mantiene por compatibilidad:
 * si llega solo él, equivale a una lista de un elemento; si llegan ambos, debe estar contenido en la lista.
 */
public record EtapaConfigItem(
        @NotNull(message = "El orden de la etapa es obligatorio")
        @Min(value = 1, message = "El orden debe ser mayor o igual a 1")
        Integer orden,

        @NotBlank(message = "El nombre de la etapa es obligatorio")
        @Size(max = 150, message = "El nombre no puede exceder los 150 caracteres")
        String nombre,

        UUID revisorId,
        TipoAccionEtapa tipoAccion,
        TipoAsignacionRevisor tipoAsignacion,
        @Size(max = 100, message = "Una etapa admite hasta 100 revisores")
        List<UUID> revisorIds,

        /** F6 (§6.5, D3-03): criterio de IA opcional (10–4000 tras trim; vacío → null). */
        String criterioIa
) {
    public EtapaConfigItem {
        if (tipoAccion == null) tipoAccion = TipoAccionEtapa.REVISION;
        if (tipoAsignacion == null) tipoAsignacion = TipoAsignacionRevisor.USUARIO;
    }
    public EtapaConfigItem(Integer orden, String nombre, UUID revisorId, TipoAccionEtapa tipoAccion,
                           TipoAsignacionRevisor tipoAsignacion, List<UUID> revisorIds) {
        this(orden, nombre, revisorId, tipoAccion, tipoAsignacion, revisorIds, null);
    }
    public EtapaConfigItem(Integer orden, String nombre, UUID revisorId, TipoAccionEtapa tipoAccion) {
        this(orden, nombre, revisorId, tipoAccion, TipoAsignacionRevisor.USUARIO, null, null);
    }
    public EtapaConfigItem(Integer orden, String nombre, UUID revisorId) {
        this(orden, nombre, revisorId, TipoAccionEtapa.REVISION);
    }
}
