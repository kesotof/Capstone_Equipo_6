package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface VPlantillaVigenteRepository extends JpaRepository<VPlantillaVigente, Long> {

    List<VPlantillaVigente> findByAreaId(Long areaId);

    List<VPlantillaVigente> findByAreaIdIsNull();

    List<VPlantillaVigente> findByTipoDocumentoId(Long tipoDocumentoId);
}
