package com.capstone.sistema.model.enums;

/** A-09: tipo de tarea de IA registrada en ia_tarea. */
public enum TipoTareaIa {
    EVALUACION,
    CHAT,
    AUTOCOMPLETAR
}
