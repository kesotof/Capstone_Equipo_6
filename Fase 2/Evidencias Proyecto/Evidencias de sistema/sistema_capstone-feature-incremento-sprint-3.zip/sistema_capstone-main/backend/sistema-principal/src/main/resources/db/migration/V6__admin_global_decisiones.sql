-- =============================================================================
-- V6__admin_global_decisiones.sql
-- US-37 (HU-PB-11), aprobada por Eduardo el 19-10-2026: el administrador global
-- (rol ADMIN_SISTEMA vigente, reflejo del rol de realm ADMIN de Keycloak, decisión D-A)
-- puede aprobar, rechazar o pedir corrección en cualquier etapa aunque no sea revisor.
--
-- Cambios:
--   1. Función es_admin_global(usuario): mismo criterio que RbacAccessService
--      (roles ADMIN / ADMIN_SISTEMA con vigencia abierta o futura).
--   2. fn_historial_actor_valido: las decisiones aceptan revisor asignado O admin global.
--      REGISTRAR y CORREGIR siguen siendo exclusivas del emisor (sin cambio).
-- La marca "actuó como administrador global" se guarda en historial_transicion.metadata
-- ({"actuoComoAdmin": true}); no requiere columnas nuevas.
-- =============================================================================

CREATE OR REPLACE FUNCTION es_admin_global(p_usuario UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
          FROM usuario_rol ur
          JOIN rol r ON r.id = ur.rol_id
         WHERE ur.usuario_id = p_usuario
           AND r.codigo IN ('ADMIN', 'ADMIN_SISTEMA')
           AND (ur.vigente_hasta IS NULL OR ur.vigente_hasta > now())
    );
$$;

CREATE OR REPLACE FUNCTION fn_historial_actor_valido()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    v_emisor       UUID;
    v_flujo_sol    BIGINT;
    v_flujo_etapa  BIGINT;
BEGIN
    SELECT usuario_id, flujo_definicion_id
      INTO v_emisor, v_flujo_sol
      FROM solicitud
     WHERE id = NEW.solicitud_id;

    SELECT flujo_definicion_id
      INTO v_flujo_etapa
      FROM flujo_etapa
     WHERE id = NEW.flujo_etapa_id;

    IF v_flujo_etapa IS DISTINCT FROM v_flujo_sol THEN
        RAISE EXCEPTION 'La etapa no pertenece al flujo de la solicitud' USING ERRCODE = 'CB010';
    END IF;

    IF NEW.accion IN ('REGISTRAR', 'CORREGIR') THEN
        IF NEW.usuario_id IS DISTINCT FROM v_emisor THEN
            RAISE EXCEPTION 'Solo el emisor puede registrar o corregir la solicitud' USING ERRCODE = 'CB011';
        END IF;
    ELSE
        IF NOT es_revisor(NEW.solicitud_id, NEW.flujo_etapa_id, NEW.usuario_id)
           AND NOT es_admin_global(NEW.usuario_id) THEN
            RAISE EXCEPTION 'El usuario no es revisor asignado de esta etapa' USING ERRCODE = 'CB012';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

-- Tipo de notificación para avisar a los revisores asignados (CA 37.4).
INSERT INTO tipo_notificacion (codigo, descripcion) VALUES
    ('DECISION_ADMIN_GLOBAL', 'Revisor: el administrador global decidió en su lugar')
ON CONFLICT (codigo) DO NOTHING;
