package com.capstone.sistema.rbac.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.model.UsuarioRol;
import com.capstone.sistema.rbac.repository.RolRepository;
import com.capstone.sistema.rbac.repository.UsuarioRolRepository;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Administrador global definido en Keycloak (decisión D-A / Fase 3).
 *
 * <p>Keycloak es la única fuente de verdad: el usuario que tiene el rol de realm configurado
 * ({@code rbac.admin-global.keycloak-role}, por defecto {@code ADMIN}) es el administrador global.
 * El backend lo <b>refleja</b> como una asignación global de {@code ADMIN_SISTEMA} en {@code usuario_rol}
 * —porque {@code v_permiso_efectivo} y {@code RbacAccessService} la leen desde ahí— pero nunca la crea
 * ni la quita por pedido de un usuario.</p>
 */
@Service
public class AdministradorGlobalService {

    private static final Logger log = LoggerFactory.getLogger(AdministradorGlobalService.class);
    private static final String ADMIN_SISTEMA = "ADMIN_SISTEMA";
    private static final String DETALLE = "Sincronizado desde Keycloak";

    private final String keycloakRole;
    private final RolRepository rolRepository;
    private final UsuarioRolRepository usuarioRolRepository;
    private final UserAccountRepository userAccountRepository;
    private final AuditService auditService;
    private final JdbcTemplate jdbc;

    public AdministradorGlobalService(
            @Value("${rbac.admin-global.keycloak-role:ADMIN}") String keycloakRole,
            RolRepository rolRepository,
            UsuarioRolRepository usuarioRolRepository,
            UserAccountRepository userAccountRepository,
            AuditService auditService,
            JdbcTemplate jdbc) {
        this.keycloakRole = keycloakRole;
        this.rolRepository = rolRepository;
        this.usuarioRolRepository = usuarioRolRepository;
        this.userAccountRepository = userAccountRepository;
        this.auditService = auditService;
        this.jdbc = jdbc;
    }

    /** Nombre del rol de realm que define al administrador global. */
    public String keycloakRole() {
        return keycloakRole;
    }

    /** {@code true} si el token trae el rol de realm configurado en {@code realm_access.roles}. */
    public boolean esAdminSegunToken(Jwt jwt) {
        if (jwt == null || keycloakRole == null || keycloakRole.isBlank()) {
            return false;
        }
        Map<String, Object> realmAccess = jwt.getClaimAsMap("realm_access");
        if (realmAccess == null || !(realmAccess.get("roles") instanceof Collection<?> roles)) {
            return false;
        }
        return roles.stream()
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .anyMatch(rol -> keycloakRole.equalsIgnoreCase(rol));
    }

    /**
     * Refleja en {@code usuario_rol} la pertenencia al rol de realm. Si no hay diferencia no escribe,
     * no registra evento y no cambia la versión de acceso. Usa {@code REQUIRES_NEW} para aislar la
     * escritura; el choque de dos peticiones simultáneas se resuelve con {@code ON CONFLICT DO NOTHING}.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void reflejar(UserAccount usuario, boolean esAdmin) {
        if (usuario == null || usuario.getId() == null) {
            return;
        }
        Rol rol = rolRepository.findByCodigoIgnoreCase(ADMIN_SISTEMA).orElse(null);
        if (rol == null) {
            log.warn("AdministradorGlobalService: rol {} no encontrado; no se pudo sincronizar a {}.",
                    ADMIN_SISTEMA, usuario.getEmail());
            return;
        }

        UsuarioRol existente = adminGlobalDe(usuario.getId());
        if (esAdmin && existente == null) {
            int inserted = jdbc.update(
                    "insert into usuario_rol(usuario_id, rol_id, area_id, otorgado_por) values(?,?,null,?) on conflict do nothing",
                    usuario.getId(), rol.getId(), usuario.getId());
            if (inserted == 0) {
                return; // Carrera: otra petición ya asignó la fila.
            }
            bumpYAuditar(usuario, "ADMIN_GLOBAL_ASIGNADO");
        } else if (!esAdmin && existente != null) {
            usuarioRolRepository.delete(existente);
            bumpYAuditar(usuario, "ADMIN_GLOBAL_REVOCADO");
        }
    }

    /** Usuarios con {@code ADMIN_SISTEMA} global vigente (para la reconciliación al arrancar). */
    @Transactional(readOnly = true)
    public List<UserAccount> usuariosConAdminGlobal() {
        return usuarioRolRepository.findUsuariosGlobalesByRolCodigo(ADMIN_SISTEMA);
    }

    private UsuarioRol adminGlobalDe(UUID usuarioId) {
        return usuarioRolRepository.findByUsuario_Id(usuarioId).stream()
                .filter(ur -> ur.getArea() == null && ur.getRol() != null
                        && ADMIN_SISTEMA.equalsIgnoreCase(ur.getRol().getCodigo())
                        && ur.isVigente())
                .findFirst().orElse(null);
    }

    private void bumpYAuditar(UserAccount usuario, String tipo) {
        usuario.bumpVersionAcceso();
        userAccountRepository.save(usuario);
        auditService.registerAuditEvent(tipo, "usuario", String.valueOf(usuario.getId()), "EXITO", DETALLE);
    }
}
