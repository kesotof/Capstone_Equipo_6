package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.IaAutocompletado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface IaAutocompletadoRepository extends JpaRepository<IaAutocompletado, UUID> {

    Optional<IaAutocompletado> findByIdAndUsuario_Id(UUID id, UUID usuarioId);
}
