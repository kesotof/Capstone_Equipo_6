package com.capstone.sistema.audit.repository;

import com.capstone.sistema.audit.model.LogEvento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface LogEventoRepository extends JpaRepository<LogEvento, Long> {

    @Query("SELECT l FROM LogEvento l WHERE LOWER(l.tipoEvento.codigo) = LOWER(:tipo) ORDER BY l.createdAt DESC")
    List<LogEvento> findByTipoEvento_TipoIgnoreCaseOrderByCreatedAtDesc(@Param("tipo") String tipo);

    List<LogEvento> findByUsuario_IdOrderByCreatedAtDesc(UUID usuarioId);

    List<LogEvento> findAllByOrderByCreatedAtDesc();
}
