package com.capstone.sistema.rbac.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.model.enums.AmbitoRol;
import com.capstone.sistema.model.enums.TipoAsignacionRol;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.model.PermisoEntity;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.repository.ControlPoliticaRepository;
import com.capstone.sistema.rbac.repository.PermisoEntityRepository;
import com.capstone.sistema.rbac.repository.RolRepository;
import com.capstone.sistema.rbac.repository.UsuarioRolRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional(readOnly = true)
public class RolService {

    private final RolRepository rolRepository;
    private final PermisoEntityRepository permisoRepository;
    private final UsuarioRolRepository usuarioRolRepository;
    private final ControlPoliticaRepository controlPoliticaRepository;
    private final AuditService auditService;
    private final RbacAccessService accessService;

    public RolService(
            RolRepository rolRepository,
            PermisoEntityRepository permisoRepository,
            UsuarioRolRepository usuarioRolRepository,
            ControlPoliticaRepository controlPoliticaRepository,
            AuditService auditService,
            RbacAccessService accessService
    ) {
        this.rolRepository = rolRepository;
        this.permisoRepository = permisoRepository;
        this.usuarioRolRepository = usuarioRolRepository;
        this.controlPoliticaRepository = controlPoliticaRepository;
        this.auditService = auditService;
        this.accessService = accessService;
    }

    public Page<RoleDtoV5> list(int page, int size, String q, Boolean active) {
        if (page < 0 || size < 1 || size > 100) {
            throw RbacException.invalid("Paginación inválida.");
        }

        Specification<Rol> spec = Specification.where(null);
        if (active != null) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("activo"), active));
        }
        if (q != null && !q.isBlank()) {
            String pattern = "%" + q.trim().toLowerCase() + "%";
            spec = spec.and((root, query, cb) -> cb.or(
                    cb.like(cb.lower(root.get("nombre")), pattern),
                    cb.like(cb.lower(root.get("codigo")), pattern)
            ));
        }

        var pageRequest = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "nombre"));
        var resultPage = rolRepository.findAll(spec, pageRequest);

        List<RoleDtoV5> content = resultPage.getContent().stream()
                .map(this::toDtoV5)
                .toList();

        return new Page<>(
                content,
                page,
                size,
                resultPage.getTotalElements(),
                resultPage.getTotalPages(),
                resultPage.isFirst(),
                resultPage.isLast()
        );
    }

    public RoleDtoV5 get(Long id) {
        Rol rol = rolRepository.findById(id).orElseThrow(RbacException::missing);
        return toDtoV5(rol);
    }

    /** Crear, editar o cambiar estado de roles exige ROL.GESTIONAR (403 RBAC_ACCION_DENEGADA). */
    private void assertPuedeGestionarRoles() {
        if (accessService == null) {
            throw RbacException.denied();
        }
        accessService.require(Permiso.ROL_GESTIONAR);
    }

    @Transactional
    public RoleDtoV5 create(String codigo, String nombre, String descripcion, List<String> permisoCodigos) {
        assertPuedeGestionarRoles();
        String cleanName = validateName(nombre);
        String cleanCode = validateCode(codigo);
        String cleanDesc = validateDescription(descripcion);

        if (rolRepository.existsByCodigoIgnoreCase(cleanCode)) {
            throw RbacException.conflict("RBAC_ROL_DUPLICADO", "El código de rol ya existe.");
        }
        if (rolRepository.existsByNombreIgnoreCase(cleanName)) {
            throw RbacException.conflict("RBAC_ROL_DUPLICADO", "El nombre del rol ya existe.");
        }

        Set<PermisoEntity> resolvedPermisos = resolvePermisos(permisoCodigos);
        AmbitoRol calculatedAmbito = calculateAmbito(resolvedPermisos);

        Rol rol = new Rol(cleanCode, cleanName, cleanDesc, false, TipoAsignacionRol.MANUAL, calculatedAmbito);
        rol.getPermisos().addAll(resolvedPermisos);

        Rol saved = rolRepository.save(rol);
        controlPoliticaRepository.incrementarVersion();

        auditService.registerAuditEvent("ROL_CREADO", "rol", String.valueOf(saved.getId()), "EXITO",
                "Rol creado: " + saved.getCodigo() + " - " + saved.getNombre());

        return toDtoV5(saved);
    }

    @Transactional
    public RoleDtoV5 update(Long id, String nombre, String descripcion, List<String> permisoCodigos, Long requestedVersion) {
        assertPuedeGestionarRoles();
        Rol rol = rolRepository.findById(id).orElseThrow(RbacException::missing);
        String nombreAnterior = rol.getNombre();
        String descripcionAnterior = rol.getDescripcion();
        checkVersion(rol.getLockVersion(), requestedVersion);

        if (rol.isSistema() || rol.isPermisosBloqueados()) {
            throw RbacException.conflict("RBAC_ROL_PROTEGIDO", "Este rol tiene una política protegida y no puede ser modificado.");
        }

        String cleanName = validateName(nombre);
        String cleanDesc = validateDescription(descripcion);

        if (rolRepository.existsByNombreIgnoreCaseAndIdNot(cleanName, id)) {
            throw RbacException.conflict("RBAC_ROL_DUPLICADO", "El nombre de rol ya está en uso por otro registro.");
        }

        Set<PermisoEntity> resolvedPermisos = resolvePermisos(permisoCodigos);
        AmbitoRol newAmbito = calculateAmbito(resolvedPermisos);

        // Si cambia a SOLO_GLOBAL, validar que no tenga asignaciones a áreas
        if (newAmbito == AmbitoRol.SOLO_GLOBAL && usuarioRolRepository.existsByRol_IdAndAreaIsNotNull(id)) {
            throw RbacException.conflict("ROL_AMBITO_INCOMPATIBLE",
                    "El rol incluye permisos de ámbito global y posee asignaciones vinculadas a áreas específicas. Retire esas asignaciones antes de actualizar.");
        }

        rol.setNombre(cleanName);
        rol.setDescripcion(cleanDesc);
        rol.setAmbito(newAmbito);
        rol.getPermisos().clear();
        rol.getPermisos().addAll(resolvedPermisos);

        Rol updated = rolRepository.save(rol);
        controlPoliticaRepository.incrementarVersion();

        auditService.registerAuditEvent("ROL_EDITADO", "rol", String.valueOf(updated.getId()), "EXITO",
                "Rol " + updated.getCodigo()
                        + ". Nombre: '" + nombreAnterior + "' -> '" + updated.getNombre() + "'"
                        + ". Descripción: '" + (descripcionAnterior != null ? descripcionAnterior : "")
                        + "' -> '" + (updated.getDescripcion() != null ? updated.getDescripcion() : "") + "'");

        return toDtoV5(updated);
    }

    @Transactional
    public RoleDtoV5 status(Long id, boolean activo, Long requestedVersion) {
        assertPuedeGestionarRoles();
        Rol rol = rolRepository.findById(id).orElseThrow(RbacException::missing);
        checkVersion(rol.getLockVersion(), requestedVersion);

        if (rol.isSistema()) {
            throw RbacException.conflict("RBAC_ROL_PROTEGIDO", "No se puede cambiar el estado de un rol del sistema.");
        }

        if (!activo) {
            long activeAssignments = usuarioRolRepository.countActiveByRolId(id);
            if (activeAssignments > 0) {
                throw RbacException.conflict("RBAC_ROL_EN_USO",
                        "Retire o reasigne las asignaciones vigentes antes de desactivar el rol.");
            }
        }

        rol.setActivo(activo);
        Rol updated = rolRepository.save(rol);
        controlPoliticaRepository.incrementarVersion();

        auditService.registerAuditEvent(activo ? "ROL_ACTIVADO" : "ROL_DESACTIVADO", "rol", String.valueOf(updated.getId()), "EXITO",
                "Rol " + updated.getCodigo() + " - " + updated.getNombre() + (activo ? " activado" : " desactivado"));

        return toDtoV5(updated);
    }

    public MatrizRolPermiso matriz() {
        List<Rol> activeRoles = rolRepository.findByActivoTrue();
        List<PermisoEntity> allPermisos = permisoRepository.findAll(Sort.by("recurso", "accion"));

        List<RoleRef> rolesRef = activeRoles.stream()
                .map(r -> new RoleRef(r.getId(), r.getCodigo(), r.getNombre(), r.getAmbito().name(), r.isSistema()))
                .toList();

        List<PermissionDto> permisosDto = allPermisos.stream()
                .map(this::toPermissionDto)
                .toList();

        Map<String, List<String>> rolesPermisos = new LinkedHashMap<>();
        for (Rol r : activeRoles) {
            List<String> list = r.getPermisos().stream()
                    .map(PermisoEntity::getCodigo)
                    .sorted()
                    .toList();
            rolesPermisos.put(r.getCodigo(), list);
        }

        return new MatrizRolPermiso(rolesRef, permisosDto, rolesPermisos);
    }

    public List<PermissionDto> permisos() {
        return permisoRepository.findAll(Sort.by("recurso", "accion")).stream()
                .map(this::toPermissionDto)
                .toList();
    }

    private RoleDtoV5 toDtoV5(Rol rol) {
        List<String> permCodes = rol.getPermisos().stream()
                .map(PermisoEntity::getCodigo)
                .sorted()
                .toList();
        long activeCount = usuarioRolRepository.countActiveByRolId(rol.getId());

        return new RoleDtoV5(
                rol.getId(),
                rol.getCodigo(),
                rol.getNombre(),
                rol.getDescripcion(),
                rol.isActivo(),
                rol.isSistema(),
                rol.getAsignacion() != null ? rol.getAsignacion().name() : "MANUAL",
                rol.getAmbito() != null ? rol.getAmbito().name() : "AREA_O_GLOBAL",
                rol.isPermisosBloqueados(),
                rol.getLockVersion(),
                permCodes,
                activeCount,
                rol.getCreatedAt(),
                rol.getUpdatedAt()
        );
    }

    private PermissionDto toPermissionDto(PermisoEntity p) {
        return new PermissionDto(
                p.getCodigo(),
                p.getRecurso(),
                p.getAccion(),
                p.getRecurso() + " - " + p.getAccion(),
                p.getDescripcion(),
                p.getAmbito() != null ? p.getAmbito().name() : "AREA_O_GLOBAL"
        );
    }

    private Set<PermisoEntity> resolvePermisos(List<String> codes) {
        if (codes == null || codes.isEmpty()) {
            return new LinkedHashSet<>();
        }
        Set<PermisoEntity> result = new LinkedHashSet<>();
        for (String code : codes) {
            if (code == null || code.isBlank()) {
                throw RbacException.invalid("Código de permiso inválido: " + code);
            }
            String clean = code.trim();
            // RECURSO.ACCION (o RECURSO:ACCION); el recurso puede contener '_' (p. ej. TIPO_DOCUMENTO.GESTIONAR).
            // Sin '.' ni ':' se acepta RECURSO_ACCION separando por el último '_'.
            int sep = Math.max(clean.lastIndexOf('.'), clean.lastIndexOf(':'));
            if (sep < 0) sep = clean.lastIndexOf('_');
            if (sep <= 0 || sep >= clean.length() - 1) {
                throw RbacException.invalid("Código de permiso inválido: " + code);
            }
            String recurso = clean.substring(0, sep);
            String accion = clean.substring(sep + 1);
            PermisoEntity entity = permisoRepository.findByRecursoIgnoreCaseAndAccionIgnoreCase(recurso, accion)
                    .orElseThrow(() -> RbacException.invalid("Permiso desconocido: " + code));
            result.add(entity);
        }
        return result;
    }

    private AmbitoRol calculateAmbito(Set<PermisoEntity> permisos) {
        boolean hasSoloGlobal = permisos.stream()
                .anyMatch(p -> p.getAmbito() == AmbitoRol.SOLO_GLOBAL);
        return hasSoloGlobal ? AmbitoRol.SOLO_GLOBAL : AmbitoRol.AREA_O_GLOBAL;
    }

    private static String validateName(String value) {
        if (value == null) throw RbacException.invalid("El nombre del rol es obligatorio.");
        String name = value.trim();
        if (name.isBlank() || name.length() > 100) throw RbacException.invalid("Nombre de rol inválido (1-100 caracteres).");
        return name;
    }

    private static String validateCode(String value) {
        if (value == null) throw RbacException.invalid("El código del rol es obligatorio.");
        String code = value.trim().toUpperCase();
        if (!code.matches("^[A-Z][A-Z0-9_]{2,49}$")) {
            throw RbacException.invalid("El código del rol debe iniciar con letra mayúscula y tener entre 3 y 50 caracteres alfanuméricos.");
        }
        return code;
    }

    private static String validateDescription(String value) {
        if (value == null) return null;
        String desc = value.trim();
        if (desc.length() > 1000) throw RbacException.invalid("La descripción admite hasta 1000 caracteres.");
        return desc.isEmpty() ? null : desc;
    }

    private static void checkVersion(long current, Long requested) {
        if (requested == null || requested < 0) throw RbacException.invalid("Envíe una versión válida.");
        if (current != requested) throw RbacException.conflict("RBAC_VERSION_DESACTUALIZADA", "Los datos cambiaron. Recargue antes de editar.");
    }
}
