package com.capstone.sistema.doc.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "plantilla_version")
@Immutable
public class PlantillaVersion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "plantilla_id", nullable = false, updatable = false)
    private Plantilla plantilla;

    @Column(nullable = false, updatable = false)
    private int version;

    @Column(name = "storage_key", nullable = false, unique = true, length = 500, updatable = false)
    private String storageKey;

    @Column(name = "content_type", nullable = false, length = 100, updatable = false)
    private String contentType;

    @Column(name = "checksum_sha256", nullable = false, length = 64, updatable = false)
    private String checksumSha256;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "esquema_campos", nullable = false, columnDefinition = "jsonb", updatable = false)
    private String esquemaCampos;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "creado_por", nullable = false, updatable = false)
    private UserAccount creadoPor;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected PlantillaVersion() {
    }

    public PlantillaVersion(Plantilla plantilla, int version, String storageKey, String checksumSha256, UserAccount creadoPor) {
        this(plantilla, version, storageKey, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", checksumSha256, "{}", creadoPor);
    }

    public PlantillaVersion(Plantilla plantilla, int version, String storageKey, String contentType, String checksumSha256, String esquemaCampos, UserAccount creadoPor) {
        this.plantilla = plantilla;
        this.version = version;
        this.storageKey = storageKey;
        this.contentType = contentType;
        this.checksumSha256 = checksumSha256;
        this.esquemaCampos = esquemaCampos;
        this.creadoPor = creadoPor;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public Plantilla getPlantilla() {
        return plantilla;
    }

    public int getVersion() {
        return version;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public String getContentType() {
        return contentType;
    }

    public String getChecksumSha256() {
        return checksumSha256;
    }

    public String getEsquemaCampos() {
        return esquemaCampos;
    }

    public UserAccount getCreadoPor() {
        return creadoPor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setEsquemaCampos(String esquemaCampos) {
        this.esquemaCampos = esquemaCampos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlantillaVersion that = (PlantillaVersion) o;
        return Objects.equals(id, that.id) || (Objects.equals(plantilla, that.plantilla) && version == that.version);
    }

    @Override
    public int hashCode() {
        return Objects.hash(storageKey);
    }
}
