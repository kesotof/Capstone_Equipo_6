package com.capstone.sistema.notificacion.controller;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.notificacion.dto.CorreoEstadoPageResponse;
import com.capstone.sistema.notificacion.service.NotificacionService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * F3 (§7.1): bandeja y reenvío manual de correos.
 *
 * <ul>
 *   <li>{@code GET /correos} exige AUDITORIA.VER ({@link Permiso#AUDITORIA_CONSULTAR}).</li>
 *   <li>{@code POST /{id}/reenviar-correo} solo el administrador global; audita
 *       {@code CORREO_REENVIADO} (catálogo V7).</li>
 * </ul>
 */
@Tag(name = "Administración de notificaciones", description = "Correos FALLIDO/PENDIENTE y reenvío manual (admin)")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/admin/notificaciones")
@PreAuthorize("isAuthenticated()")
public class NotificacionAdminController {

    private final NotificacionService notificacionService;
    private final RbacAccessService access;
    private final CurrentUserResolver currentUserResolver;
    private final AuditService auditService;

    public NotificacionAdminController(
            NotificacionService notificacionService,
            RbacAccessService access,
            CurrentUserResolver currentUserResolver,
            AuditService auditService
    ) {
        this.notificacionService = notificacionService;
        this.access = access;
        this.currentUserResolver = currentUserResolver;
        this.auditService = auditService;
    }

    @GetMapping("/correos")
    public ResponseEntity<CorreoEstadoPageResponse> correos(
            @RequestParam("estado") String estado,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "20") int size
    ) {
        access.require(Permiso.AUDITORIA_CONSULTAR);
        // Valor desconocido → IllegalArgumentException → 400 vía NotificacionExceptionHandler.
        EstadoCorreo estadoEnum = EstadoCorreo.valueOf(estado.trim().toUpperCase());
        return ResponseEntity.ok(notificacionService.correosPorEstado(estadoEnum, page, size));
    }

    @PostMapping("/{id}/reenviar-correo")
    public ResponseEntity<Void> reenviarCorreo(@PathVariable Long id) {
        UserAccount admin = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("Usuario no autenticado"));
        if (!access.context().admin()) {
            throw new AccessDeniedException("Solo el administrador global puede reenviar correos");
        }
        notificacionService.reenviarCorreo(id);
        auditService.registerEvent("CORREO_REENVIADO", admin,
                "Reenvío manual del correo de la notificación " + id);
        return ResponseEntity.accepted().build();
    }
}
