package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.util.UUID;

@Entity
@Table(name = "v_revisor_solicitud")
@IdClass(VRevisorSolicitudId.class)
@Immutable
public class VRevisorSolicitud {

    @Id
    @Column(name = "solicitud_id")
    private UUID solicitudId;

    @Id
    @Column(name = "flujo_etapa_id")
    private Long flujoEtapaId;

    @Id
    @Column(name = "usuario_id")
    private UUID usuarioId;

    protected VRevisorSolicitud() {
    }

    public VRevisorSolicitud(UUID solicitudId, Long flujoEtapaId, UUID usuarioId) {
        this.solicitudId = solicitudId;
        this.flujoEtapaId = flujoEtapaId;
        this.usuarioId = usuarioId;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public Long getFlujoEtapaId() {
        return flujoEtapaId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }
}
