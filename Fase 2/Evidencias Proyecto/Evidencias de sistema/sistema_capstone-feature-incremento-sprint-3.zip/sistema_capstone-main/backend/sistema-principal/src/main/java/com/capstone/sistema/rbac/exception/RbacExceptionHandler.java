package com.capstone.sistema.rbac.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RbacExceptionHandler {
    @ExceptionHandler(RbacException.class)
    public ResponseEntity<ProblemDetail> handle(RbacException e) {
        ProblemDetail detail = ProblemDetail.forStatusAndDetail(e.status(), e.getMessage());
        detail.setTitle("Control de acceso");
        detail.setProperty("codigo", e.codigo());
        detail.setProperty("code", e.codigo());
        detail.setProperty("mensaje", e.getMessage());
        detail.setProperty("message", e.getMessage());
        return ResponseEntity.status(e.status()).body(detail);
    }

    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> handleAccessDenied(org.springframework.security.access.AccessDeniedException e) {
        ProblemDetail detail = ProblemDetail.forStatusAndDetail(org.springframework.http.HttpStatus.FORBIDDEN, "Acceso denegado");
        detail.setTitle("Control de acceso");
        detail.setProperty("codigo", "RBAC_ACCION_DENEGADA");
        detail.setProperty("code", "RBAC_ACCION_DENEGADA");
        detail.setProperty("mensaje", "Acceso denegado");
        detail.setProperty("message", "Acceso denegado");
        detail.setProperty("timestamp", java.time.Instant.now());
        return ResponseEntity.status(org.springframework.http.HttpStatus.FORBIDDEN).body(detail);
    }
}

