package com.capstone.sistema.model.enums;

/**
 * US-36: categoría de una notificación según el catálogo (D3-01).
 * <ul>
 *   <li>{@link #ACCION_REQUERIDA}: exige una acción del destinatario (revisar, corregir…).</li>
 *   <li>{@link #INFORMATIVA}: solo informa un resultado o avance.</li>
 * </ul>
 */
public enum CategoriaNotificacion {
    ACCION_REQUERIDA,
    INFORMATIVA
}
