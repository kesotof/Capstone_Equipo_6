package com.capstone.sistema.model.enums;

public enum EstadoSolicitudEnum {
    PENDIENTE_REVISION("Pendiente de revisión", 1, false),
    CORRECCION_REQUERIDA("Corrección requerida", 2, false),
    APROBADO("Aprobado", 3, true),
    RECHAZADO("Rechazado", 4, true);

    private final String etiqueta;
    private final int orden;
    private final boolean esFinal;

    EstadoSolicitudEnum(String etiqueta, int orden, boolean esFinal) {
        this.etiqueta = etiqueta;
        this.orden = orden;
        this.esFinal = esFinal;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public int getOrden() {
        return orden;
    }

    public boolean isEsFinal() {
        return esFinal;
    }
}
