package com.capstone.sistema.model.enums;

public enum TipoAsignacionRol {
    MANUAL,
    AUTO_JEFATURA
}
