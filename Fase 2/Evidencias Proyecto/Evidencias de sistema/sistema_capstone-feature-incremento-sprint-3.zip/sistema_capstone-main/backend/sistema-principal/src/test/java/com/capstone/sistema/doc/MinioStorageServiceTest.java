package com.capstone.sistema.doc;

import io.minio.MinioClient;
import io.minio.ObjectWriteResponse;
import io.minio.PutObjectArgs;
import io.minio.Result;
import io.minio.messages.Item;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MinioStorageServiceTest {

    @Mock
    private MinioClient minioClient;

    private MinioStorageService storageService;

    @BeforeEach
    void setUp() {
        storageService = new MinioStorageService(
                "http://localhost:9000",
                "test-key",
                "test-secret",
                "documentos"
        );
        ReflectionTestUtils.setField(storageService, "minioClient", minioClient);
    }

    @Test
    void testBuildStorageKeyAndCleanFilename() {
        UUID solicitudId = UUID.fromString("11111111-1111-1111-1111-111111111111");

        String key1 = MinioStorageService.buildStorageKey(solicitudId, 1, "mi contrato final.pdf");
        assertThat(key1).isEqualTo("solicitudes/11111111-1111-1111-1111-111111111111/v1/mi_contrato_final.pdf");

        String key2 = MinioStorageService.buildStorageKey(solicitudId, 2, "../../etc/passwd");
        assertThat(key2).isEqualTo("solicitudes/11111111-1111-1111-1111-111111111111/v2/passwd");

        String key3 = MinioStorageService.buildStorageKey(solicitudId, 1, null);
        assertThat(key3).isEqualTo("solicitudes/11111111-1111-1111-1111-111111111111/v1/documento.bin");
    }

    @Test
    void testUploadDocumentComputesSha256AndReturnsMetadata() throws Exception {
        UUID solicitudId = UUID.randomUUID();
        byte[] content = "Contenido confidencial de prueba para hash SHA-256".getBytes(StandardCharsets.UTF_8);

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        String expectedSha256 = HexFormat.of().formatHex(digest.digest(content));

        when(minioClient.bucketExists(any())).thenReturn(true);
        ObjectWriteResponse mockResponse = mock(ObjectWriteResponse.class);
        when(mockResponse.versionId()).thenReturn("v-minio-12345");
        when(minioClient.putObject(any(PutObjectArgs.class))).thenReturn(mockResponse);

        MinioStorageService.MinioUploadResult result = storageService.uploadDocument(
                solicitudId,
                1,
                "anexo.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                new ByteArrayInputStream(content),
                content.length
        );

        assertThat(result.storageKey()).isEqualTo("solicitudes/" + solicitudId + "/v1/anexo.docx");
        assertThat(result.checksumSha256()).isEqualTo(expectedSha256);
        assertThat(result.storageVersionId()).isEqualTo("v-minio-12345");
        assertThat(result.sizeBytes()).isEqualTo(content.length);
    }

    @Test
    void testListOrphanKeys() throws Exception {
        Item item1 = mock(Item.class);
        when(item1.objectName()).thenReturn("solicitudes/s1/v1/activo.pdf");

        Item item2 = mock(Item.class);
        when(item2.objectName()).thenReturn("solicitudes/s2/v1/huerfano.pdf");

        Result<Item> res1 = new Result<>(item1);
        Result<Item> res2 = new Result<>(item2);

        when(minioClient.listObjects(any())).thenReturn(List.of(res1, res2));

        Set<String> knownDbKeys = Set.of("solicitudes/s1/v1/activo.pdf");
        List<String> orphans = storageService.listOrphanKeys(knownDbKeys);

        assertThat(orphans).containsExactly("solicitudes/s2/v1/huerfano.pdf");
    }
}
