package com.capstone.sistema.flow.model;

import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "flujo_etapa", uniqueConstraints = {
        @UniqueConstraint(name = "unq_flujo_orden", columnNames = {"flujo_definicion_id", "orden"}),
        @UniqueConstraint(name = "unq_flujo_etapa_id", columnNames = {"flujo_definicion_id", "id"})
})
public class FlujoEtapa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_definicion_id", nullable = false)
    private FlujoDefinicion flujoDefinicion;

    @Column(nullable = false)
    private int orden;

    @Column(nullable = false, length = 150)
    private String nombre;

    @Enumerated(EnumType.STRING)
    @Column(name = "modo_revisor", nullable = false, length = 30)
    private ModoRevisor modoRevisor = ModoRevisor.LISTA;

    /** D3-03/US-30: criterio opcional de evaluación con IA (10–4000 caracteres; vacío → null). */
    @Column(name = "criterio_ia")
    private String criterioIa;

    /**
     * Revisores de la etapa (modo LISTA, D-05): cualquiera de ellos puede decidir.
     * Orden determinista al cargar (nombre, apellido, email); las altas en memoria se
     * reordenan en {@link #getRevisoresOrdenados()}.
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "flujo_etapa_revisor",
            joinColumns = @JoinColumn(name = "flujo_etapa_id"),
            inverseJoinColumns = @JoinColumn(name = "usuario_id")
    )
    @OrderBy("firstName ASC, lastName ASC, email ASC")
    private Set<UserAccount> revisores = new LinkedHashSet<>();

    /** Orden de presentación de revisores: nombre completo (sin distinguir mayúsculas), email e id. */
    public static final Comparator<UserAccount> ORDEN_REVISOR = Comparator
            .comparing((UserAccount u) -> nombreCompleto(u), String.CASE_INSENSITIVE_ORDER)
            .thenComparing(u -> Objects.toString(u.getEmail(), ""), String.CASE_INSENSITIVE_ORDER)
            .thenComparing(u -> Objects.toString(u.getId(), ""));

    protected FlujoEtapa() {
    }

    public FlujoEtapa(FlujoDefinicion flujoDefinicion, int orden, String nombre) {
        this.flujoDefinicion = flujoDefinicion;
        this.orden = orden;
        this.nombre = nombre;
        this.modoRevisor = ModoRevisor.LISTA;
    }

    public FlujoEtapa(FlujoDefinicion flujoDefinicion, int orden, String nombre, ModoRevisor modoRevisor) {
        this.flujoDefinicion = flujoDefinicion;
        this.orden = orden;
        this.nombre = nombre;
        this.modoRevisor = modoRevisor != null ? modoRevisor : ModoRevisor.LISTA;
    }

    public FlujoEtapa(FlujoDefinicion flujoDefinicion, int orden, String nombre, UserAccount revisor) {
        this(flujoDefinicion, orden, nombre);
        if (revisor != null) {
            this.revisores.add(revisor);
        }
    }

    public Long getId() {
        return id;
    }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ModoRevisor getModoRevisor() {
        return modoRevisor;
    }

    public void setModoRevisor(ModoRevisor modoRevisor) {
        this.modoRevisor = modoRevisor;
    }

    public String getCriterioIa() {
        return criterioIa;
    }

    public void setCriterioIa(String criterioIa) {
        this.criterioIa = criterioIa;
    }

    public Set<UserAccount> getRevisores() {
        return revisores;
    }

    public void setRevisores(Set<UserAccount> revisores) {
        this.revisores = revisores != null ? revisores : new LinkedHashSet<>();
    }

    /** Revisores en orden determinista ({@link #ORDEN_REVISOR}). */
    public List<UserAccount> getRevisoresOrdenados() {
        List<UserAccount> ordenados = new ArrayList<>(revisores);
        ordenados.sort(ORDEN_REVISOR);
        return ordenados;
    }

    /** Reemplaza la lista completa de revisores (la persistencia sincroniza FLUJO_ETAPA_REVISOR). */
    public void reemplazarRevisores(Collection<UserAccount> nuevos) {
        this.revisores.clear();
        if (nuevos != null) {
            nuevos.stream().filter(Objects::nonNull).sorted(ORDEN_REVISOR).forEach(this.revisores::add);
        }
    }

    private static String nombreCompleto(UserAccount u) {
        return (Objects.toString(u.getFirstName(), "") + " " + Objects.toString(u.getLastName(), "")).trim();
    }

    public void addRevisor(UserAccount revisor) {
        if (revisor != null) {
            this.revisores.add(revisor);
        }
    }

    public void removeRevisor(UserAccount revisor) {
        if (revisor != null) {
            this.revisores.remove(revisor);
        }
    }

    // Shims de compatibilidad con código existente: primer revisor según ORDEN_REVISOR.
    @Transient
    public UserAccount getRevisor() {
        return revisores.isEmpty() ? null : getRevisoresOrdenados().get(0);
    }

    public void setRevisor(UserAccount revisor) {
        this.revisores.clear();
        if (revisor != null) {
            this.revisores.add(revisor);
        }
    }

    public void asignarUsuario(UserAccount usuario) {
        setRevisor(usuario);
    }

    @Transient
    private TipoAccionEtapa tipoAccion = TipoAccionEtapa.REVISION;

    @Transient
    private TipoAsignacionRevisor tipoAsignacion = TipoAsignacionRevisor.USUARIO;

    public TipoAccionEtapa getTipoAccion() {
        return tipoAccion;
    }

    public void setTipoAccion(TipoAccionEtapa tipoAccion) {
        this.tipoAccion = tipoAccion;
    }

    public TipoAsignacionRevisor getTipoAsignacion() {
        return tipoAsignacion;
    }

    public void setTipoAsignacion(TipoAsignacionRevisor tipoAsignacion) {
        this.tipoAsignacion = tipoAsignacion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FlujoEtapa that = (FlujoEtapa) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
