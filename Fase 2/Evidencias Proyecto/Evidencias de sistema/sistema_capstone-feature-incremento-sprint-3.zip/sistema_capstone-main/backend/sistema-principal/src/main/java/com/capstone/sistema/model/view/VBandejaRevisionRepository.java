package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface VBandejaRevisionRepository extends JpaRepository<VBandejaRevision, VBandejaRevisionId> {

    List<VBandejaRevision> findByRevisorIdOrderByCreatedAtDesc(UUID revisorId);
}
