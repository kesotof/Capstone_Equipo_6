package com.capstone.sistema.rbac.exception;

import org.springframework.http.HttpStatus;

public class RbacException extends RuntimeException {
    private final HttpStatus status;
    private final String codigo;
    public RbacException(HttpStatus status, String codigo, String detalle) {
        super(detalle);
        this.status = status;
        this.codigo = codigo;
    }
    public HttpStatus status() { return status; }
    public String codigo() { return codigo; }
    public static RbacException invalid(String detail) { return new RbacException(HttpStatus.BAD_REQUEST, "RBAC_DATOS_INVALIDOS", detail); }
    public static RbacException conflict(String code, String detail) { return new RbacException(HttpStatus.CONFLICT, code, detail); }
    public static RbacException denied() { return new RbacException(HttpStatus.FORBIDDEN, "RBAC_ACCION_DENEGADA", "No tiene permiso para realizar esta acción."); }
    public static RbacException missing() { return new RbacException(HttpStatus.NOT_FOUND, "RECURSO_NO_ENCONTRADO", "No se encontró el recurso indicado."); }
    /** El administrador global se define en Keycloak y no se gestiona desde la plataforma (decisión D-A). */
    public static RbacException adminGlobalNoAsignable() {
        return new RbacException(HttpStatus.UNPROCESSABLE_ENTITY, "ROL_ADMIN_GLOBAL_NO_ASIGNABLE",
                "El administrador global se gestiona en Keycloak; no puede asignarse ni revocarse desde la plataforma.");
    }
}

