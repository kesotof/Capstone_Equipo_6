package com.capstone.sistema.notificacion.dto;

import com.capstone.sistema.model.enums.CategoriaNotificacion;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.model.enums.RolDestinatario;

import java.time.Instant;
import java.util.UUID;

/**
 * F3 (§6.3): contrato inmutable de la bandeja; agrega {@code categoria} (CA 10.1/10.2),
 * {@code enlace} (CA 10.4), {@code correlativo} y {@code estadoCorreo} (US-35).
 */
public record NotificacionResponse(
        Long id,
        String titulo,
        String mensaje,
        String tipo,
        CategoriaNotificacion categoria,
        RolDestinatario rolDestinatario,
        String enlace,
        String correlativo,
        UUID solicitudId,
        boolean leida,
        Instant createdEn,
        Instant leidaEn,
        EstadoCorreo estadoCorreo
) {
}
