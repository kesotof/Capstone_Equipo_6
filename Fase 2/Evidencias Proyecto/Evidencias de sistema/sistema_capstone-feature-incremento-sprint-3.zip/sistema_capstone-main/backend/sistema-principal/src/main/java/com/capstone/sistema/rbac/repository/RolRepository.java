package com.capstone.sistema.rbac.repository;

import com.capstone.sistema.model.enums.TipoAsignacionRol;
import com.capstone.sistema.rbac.model.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface RolRepository extends JpaRepository<Rol, Long>, JpaSpecificationExecutor<Rol> {

    Optional<Rol> findByCodigoIgnoreCase(String codigo);

    Optional<Rol> findByNombreIgnoreCase(String nombre);

    boolean existsByCodigoIgnoreCase(String codigo);

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

    boolean existsByCodigoIgnoreCaseAndIdNot(String codigo, Long id);

    List<Rol> findByActivoTrue();

    Optional<Rol> findByAsignacion(TipoAsignacionRol asignacion);
}
