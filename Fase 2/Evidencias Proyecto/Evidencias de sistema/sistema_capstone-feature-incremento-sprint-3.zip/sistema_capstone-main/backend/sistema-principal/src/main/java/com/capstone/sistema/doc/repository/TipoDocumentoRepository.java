package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.TipoDocumento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TipoDocumentoRepository extends JpaRepository<TipoDocumento, Long> {

    Optional<TipoDocumento> findByNombreIgnoreCase(String nombre);

    Optional<TipoDocumento> findByNombreIgnoreCaseAndActivoTrue(String nombre);

    Optional<TipoDocumento> findByPrefijoIgnoreCase(String prefijo);

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndActivoTrue(String nombre);

    boolean existsByPrefijoIgnoreCase(String prefijo);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

    boolean existsByNombreIgnoreCaseAndActivoTrueAndIdNot(String nombre, Long id);

    boolean existsByPrefijoIgnoreCaseAndIdNot(String prefijo, Long id);

    List<TipoDocumento> findByActivoTrueOrderByNombreAsc();
}
