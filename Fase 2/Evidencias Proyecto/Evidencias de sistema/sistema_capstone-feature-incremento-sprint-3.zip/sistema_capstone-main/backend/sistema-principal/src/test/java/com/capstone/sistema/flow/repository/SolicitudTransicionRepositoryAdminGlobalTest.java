package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.AccionTransicion;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SolicitudTransicionRepositoryAdminGlobalTest {

    @Mock
    private HistorialTransicionRepository historialTransicionRepository;

    private SolicitudTransicionRepository repository;
    private UUID solicitudId;
    private Solicitud solicitud;
    private UserAccount usuario;
    private FlujoEtapa etapa;
    private EstadoSolicitud estado;

    @BeforeEach
    void setUp() {
        repository = new SolicitudTransicionRepository(historialTransicionRepository);

        usuario = new UserAccount("kc-admin", "admin@test.local", "Super", "Admin", true);
        ReflectionTestUtils.setField(usuario, "id", UUID.randomUUID());

        FlujoDefinicion flujo = new FlujoDefinicion("Flujo Test", "Desc");
        etapa = new FlujoEtapa(flujo, 1, "Etapa 1");
        estado = new EstadoSolicitud("PENDIENTE_REVISION", "Pendiente de revisión", 1, false);

        solicitudId = UUID.randomUUID();
        solicitud = new Solicitud(flujo, usuario, "Documento", "Desc", estado, etapa);
        ReflectionTestUtils.setField(solicitud, "id", solicitudId);
    }

    private SolicitudTransicionRepository.Detalle detalleConMetadata(String metadata) {
        HistorialTransicion h = new HistorialTransicion(
                solicitud, etapa, new AccionTransicion("APROBAR", "Aprobar"), estado, estado, usuario,
                "Aprobado", true, metadata
        );
        when(historialTransicionRepository.findBySolicitud_IdOrderByCreatedAtAscIdAsc(solicitudId))
                .thenReturn(List.of(h));
        List<SolicitudTransicionRepository.Detalle> detalles = repository.consultarDetalle(solicitudId, true);
        assertThat(detalles).hasSize(1);
        return detalles.get(0);
    }

    @Test
    @DisplayName("[US-37] consultarDetalle mapea metadata actuoComoAdmin con espacio a getActuoComoAdmin() true")
    void metadataConEspacioMapeaActuoComoAdminVerdadero() {
        assertThat(detalleConMetadata("{\"actuoComoAdmin\": true}").getActuoComoAdmin()).isTrue();
    }

    @Test
    @DisplayName("[US-37] consultarDetalle mapea metadata actuoComoAdmin sin espacios a true")
    void metadataSinEspaciosMapeaVerdadero() {
        assertThat(detalleConMetadata("{\"actuoComoAdmin\":true}").getActuoComoAdmin()).isTrue();
    }

    @ParameterizedTest(name = "[US-37] metadata {0} produce actuoComoAdmin=false")
    @ValueSource(strings = {"{}", "{\"actuoComoAdmin\":false}", "{\"otro\":true}"})
    void metadataSinActuacionAdminMapeaFalso(String metadata) {
        assertThat(detalleConMetadata(metadata).getActuoComoAdmin()).isFalse();
    }
}
