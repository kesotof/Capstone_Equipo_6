package com.capstone.sistema.model.enums;

public enum ModoRevisor {
    LISTA,
    JEFATURA_AREA_SOLICITUD
}
