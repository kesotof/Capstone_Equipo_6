package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "v_plantilla_vigente")
@Immutable
public class VPlantillaVigente {

    @Id
    @Column(name = "plantilla_id")
    private Long plantillaId;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "tipo_documento_id")
    private Long tipoDocumentoId;

    @Column(name = "area_id")
    private Long areaId;

    @Column(name = "plantilla_version_id")
    private Long plantillaVersionId;

    @Column(name = "version")
    private Integer version;

    @Column(name = "storage_key")
    private String storageKey;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "esquema_campos", columnDefinition = "jsonb")
    private String esquemaCampos;

    public VPlantillaVigente() {
    }

    public Long getPlantillaId() {
        return plantillaId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Long getTipoDocumentoId() {
        return tipoDocumentoId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public Long getPlantillaVersionId() {
        return plantillaVersionId;
    }

    public Integer getVersion() {
        return version;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public String getEsquemaCampos() {
        return esquemaCampos;
    }
}
