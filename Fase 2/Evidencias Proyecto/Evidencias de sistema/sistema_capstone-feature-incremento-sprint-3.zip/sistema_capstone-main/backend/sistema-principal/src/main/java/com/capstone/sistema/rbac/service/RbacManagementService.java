package com.capstone.sistema.rbac.service;

import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.service.FlujoReviewerResolver;
import com.capstone.sistema.org.area.service.AreaCatalogLock;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.*;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.mapper.UserMapper;
import com.capstone.sistema.users.model.*;
import com.capstone.sistema.users.repository.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

/**
 * Servicios transversales de RBAC: bloqueo y versión de política (CONTROL_POLITICA), verificación de
 * dependencias de revisión, asignación de roles globales al crear usuarios y protección del último
 * administrador. Las consultas usan las tablas de V1: ROL, USUARIO_ROL, AREA_JEFATURA, CONTROL_POLITICA.
 * El CRUD de roles vive en {@code RolService} y las asignaciones en {@code AccesoUsuarioService}.
 */
@Service
@Transactional(readOnly = true)
public class RbacManagementService {

    /** Rol de administración global sembrado en V2. */
    public static final String ROL_ADMIN_SISTEMA = "ADMIN_SISTEMA";

    /** Rol elegido para una asignación global (id, código y nombre visibles en auditoría). */
    public record RolSeleccionado(Long id, String codigo, String nombre) {}

    private final JdbcTemplate jdbc;
    private final RbacAccessService access;
    private final AreaCatalogLock areaLock;
    private final UserAccountRepository users;
    private final SolicitudRepository solicitudes;
    private final FlujoEtapaRepository stages;
    private final FlujoReviewerResolver reviewers;
    private final jakarta.persistence.EntityManager entityManager;

    public RbacManagementService(JdbcTemplate jdbc, RbacAccessService access, AreaCatalogLock areaLock,
            UserAccountRepository users, SolicitudRepository solicitudes,
            jakarta.persistence.EntityManager entityManager,
            FlujoEtapaRepository stages, FlujoReviewerResolver reviewers) {
        this.jdbc=jdbc; this.access=access; this.areaLock=areaLock; this.users=users;
        this.solicitudes=solicitudes;
        this.entityManager=entityManager; this.stages=stages; this.reviewers=reviewers;
    }

    /** Orden común: catálogo de áreas, control RBAC, entidades. El lock vive hasta el commit. */
    @Transactional
    public Set<String> prepareMutation() {
        lockPolicy();
        return dependencyViolations();
    }

    @Transactional
    public void lockPolicy() {
        areaLock.acquire();
        jdbc.queryForObject("select version from control_politica where id=1 for update", Long.class);
        access.clearContext();
    }
    @Transactional
    public void finishMutation(Set<String> previous) {
        entityManager.flush();
        // La política cambió dentro de esta transacción: se recalculan los contextos con los datos nuevos.
        access.clearContext();
        Set<String> violations=dependencyViolations();
        violations.removeAll(previous);
        if (!violations.isEmpty()) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "El cambio dejaría flujos activos o revisiones pendientes sin un revisor autorizado.");
        jdbc.update("update control_politica set version=version+1, updated_at=now() where id=1");
    }
    private Set<String> dependencyViolations() {
        Set<String> result = new HashSet<>();
        var reviewerIds = jdbc.query(
                "select distinct r.usuario_id from flujo_etapa_revisor r join flujo_etapa e on e.id=r.flujo_etapa_id join flujo_definicion f on f.id=e.flujo_definicion_id where f.activo=true",
                (rs, n) -> (UUID) rs.getObject(1)
        );
        Map<UUID, UserAccount> reviewerAccountCache = new HashMap<>();
        Map<UUID, AccessContext> reviewerContextCache = new HashMap<>();
        // Cuentas de todos los revisores en una sola consulta (antes: un findById por revisor).
        for (UserAccount reviewer : users.findAllById(reviewerIds)) {
            reviewerAccountCache.put(reviewer.getId(), reviewer);
        }

        for (UUID id : reviewerIds) {
            UserAccount user = reviewerAccountCache.get(id);
            if (user == null) {
                result.add("FLOW:" + id + ":CUENTA");
                continue;
            }
            AccessContext c = reviewerContextCache.computeIfAbsent(id, uId -> access.forUser(user));
            if (!user.isEnabled()) result.add("FLOW:" + id + ":CUENTA");
            if (!c.jerarquiaValida()) result.add("FLOW:" + id + ":JERARQUIA");
            for (Permiso p : List.of(Permiso.SOLICITUD_CONSULTAR, Permiso.REVISION_CONSULTAR,
                    Permiso.SOLICITUD_APROBAR, Permiso.SOLICITUD_RECHAZAR, Permiso.SOLICITUD_PEDIR_CORRECCION)) {
                boolean allowed = c.has(p);
                if (p == Permiso.SOLICITUD_CONSULTAR) {
                    allowed = c.scopes(p).contains(Alcance.ASIGNADAS)
                            || (c.admin() && c.scopes(p).contains(Alcance.GLOBAL));
                }
                if (!allowed) result.add("FLOW:" + id + ":" + p);
            }
        }

        var pending = jdbc.query(
                "select s.id, r.usuario_id from solicitud s join flujo_etapa_revisor r on r.flujo_etapa_id=s.flujo_etapa_id where upper(s.estado) in ('PENDIENTE_REVISION','CORRECCION_REQUERIDA','REQUIERE_AJUSTES')",
                (rs, n) -> Map.entry((UUID) rs.getObject(1), (UUID) rs.getObject(2))
        );
        // Pares (solicitud, revisor) pendientes que SÍ tienen acceso: una sola consulta en vez de
        // puedeAccederSolicitud() por cada par (esa era una de las causas del costo de cada mutación).
        Map<UUID, Set<UUID>> pendingWithAccess = new HashMap<>();
        jdbc.query(
                "select s.id, r.usuario_id from solicitud s " +
                "join flujo_etapa_revisor r on r.flujo_etapa_id=s.flujo_etapa_id " +
                "join v_acceso_solicitud v on v.solicitud_id=s.id and v.usuario_id=r.usuario_id " +
                "where upper(s.estado) in ('PENDIENTE_REVISION','CORRECCION_REQUERIDA','REQUIERE_AJUSTES')",
                rs -> {
                    pendingWithAccess.computeIfAbsent((UUID) rs.getObject(1), k -> new HashSet<>())
                            .add((UUID) rs.getObject(2));
                }
        );
        for (var entry : pending) {
            UUID reviewerId = entry.getValue();
            UserAccount reviewer = reviewerAccountCache.computeIfAbsent(reviewerId, uId -> users.findById(uId).orElse(null));
            if (reviewer == null || !reviewer.isEnabled()) {
                result.add("REQUEST:" + entry.getKey() + ":CUENTA");
                continue;
            }
            AccessContext c = reviewerContextCache.computeIfAbsent(reviewerId, uId -> access.forUser(reviewer));
            if (c.admin()) {
                continue;
            }
            boolean canAccess = pendingWithAccess.getOrDefault(entry.getKey(), Set.of()).contains(reviewerId);
            for (Permiso p : List.of(Permiso.SOLICITUD_APROBAR, Permiso.SOLICITUD_RECHAZAR, Permiso.SOLICITUD_PEDIR_CORRECCION)) {
                if (!c.has(p) || !canAccess) {
                    result.add("REQUEST:" + entry.getKey() + ":" + p);
                }
            }
        }

        for (var stage : stages.findAll()) {
            if (stage.getFlujoDefinicion().isActivo() && !FlujoReviewerResolver.isDynamicBase(stage)
                    && reviewers.candidates(stage).isEmpty()) {
                result.add("STEP:" + stage.getId() + ":RESPONSABLE");
            }
        }
        Map<Long, List<UserAccount>> stageCandidatesCache = new HashMap<>();
        Map<Long, Set<UUID>> stageReviewerIdsCache = new HashMap<>();
        // Pares (solicitud abierta, usuario) con acceso, en una sola consulta: canOperateAtStage ya no
        // consulta v_acceso_solicitud por cada candidato × solicitud (era el coste dominante del punto 4).
        Map<UUID, Set<UUID>> accesoPorSolicitud = new HashMap<>();
        jdbc.query(
                "select v.solicitud_id, v.usuario_id from v_acceso_solicitud v " +
                "join solicitud s on s.id=v.solicitud_id " +
                "where upper(s.estado) not in ('APROBADO','RECHAZADO')",
                rs -> {
                    accesoPorSolicitud
                            .computeIfAbsent((UUID) rs.getObject(1), k -> new HashSet<>())
                            .add((UUID) rs.getObject(2));
                }
        );
        for (var request : solicitudes.findOpenByFlow(null)) {
            if (request.getFlujoEtapa() == null) {
                result.add("REQUEST:" + request.getId() + ":ETAPA");
                continue;
            }
            for (var stage : request.getFlujoDefinicion().getEtapas()) {
                if (stage.getOrden() >= request.getFlujoEtapa().getOrden()) {
                    List<UserAccount> candidates = stageCandidatesCache.computeIfAbsent(stage.getId(), sId -> reviewers.candidates(stage));
                    Set<UUID> stageReviewers = stage.getId() == null ? null
                            : stageReviewerIdsCache.computeIfAbsent(stage.getId(), sId -> access.stageReviewerIds(stage));
                    Set<UUID> conAcceso = accesoPorSolicitud.getOrDefault(request.getId(), Set.of());
                    boolean hasReviewer = candidates.stream().anyMatch(user -> access.canOperateAtStage(user, request, stage, stageReviewers, conAcceso));
                    if (!hasReviewer) {
                        result.add("REQUEST:" + request.getId() + ":STEP:" + stage.getId());
                    }
                }
            }
        }
        return result;
    }
    // ---------------------------------------------------------------------------------------------
    // Asignaciones globales (USUARIO_ROL con area_id NULL)
    // ---------------------------------------------------------------------------------------------

    /** Valida ids de roles asignables manualmente (existen, activos, asignación MANUAL). */
    public List<RolSeleccionado> explicitRoles(List<Long> ids) {
        if(ids==null || ids.stream().anyMatch(i->i==null || i<=0) || new HashSet<>(ids).size()!=ids.size()) throw RbacException.invalid("Los roles deben tener IDs positivos y únicos.");
        List<RolSeleccionado> result=new ArrayList<>();
        for(Long id:ids) {
            List<Map<String,Object>> rows=jdbc.queryForList("select id,codigo,nombre,activo,asignacion from rol where id=?",id);
            if(rows.isEmpty()) throw RbacException.missing();
            Map<String,Object> row=rows.get(0);
            if(!Boolean.TRUE.equals(row.get("activo"))) throw RbacException.invalid("No puede asignar un rol inactivo.");
            if(!"MANUAL".equals(row.get("asignacion"))) throw RbacException.invalid("Este rol no admite asignación explícita.");
            result.add(new RolSeleccionado(((Number)row.get("id")).longValue(),(String)row.get("codigo"),(String)row.get("nombre")));
        }
        return result;
    }

    @Transactional
    public void assignGlobalRoles(UUID usuarioId, List<RolSeleccionado> roles, UUID otorgadoPor) {
        for(RolSeleccionado rol:roles) {
            jdbc.update("insert into usuario_rol(usuario_id,rol_id,area_id,otorgado_por) values(?,?,null,?) on conflict do nothing",
                    usuarioId,rol.id(),otorgadoPor);
        }
    }

    /** Impide dejar el sistema sin un ADMIN_SISTEMA global activo. */
    public void protectLastAdmin(UserAccount user) {
        if(!user.isEnabled()) return;
        String vigente=" and r.activo=true and r.codigo=? and ur.area_id is null and (ur.vigente_hasta is null or ur.vigente_hasta>now())";
        Long own=jdbc.queryForObject("select count(*) from usuario_rol ur join rol r on r.id=ur.rol_id where ur.usuario_id=?"+vigente,
                Long.class,user.getId(),ROL_ADMIN_SISTEMA);
        if(own==null || own==0) return;
        Long total=jdbc.queryForObject("select count(distinct u.id) from usuario u join usuario_rol ur on ur.usuario_id=u.id join rol r on r.id=ur.rol_id where u.activo=true"+vigente,
                Long.class,ROL_ADMIN_SISTEMA);
        if(total!=null && total<=1)
            throw RbacException.conflict("RBAC_ULTIMO_ADMIN","Debe conservar al menos un administrador general activo.");
    }
    public void protectAccountRemoval(UserAccount user) {
        protectLastAdmin(user);
        List<String> areas = jdbc.query("select a.nombre from area a join area_jefatura aj on aj.area_id=a.id where aj.usuario_id=? and a.activo=true order by a.nombre",
                (rs, n) -> rs.getString("nombre"), user.getId());
        if (!areas.isEmpty()) {
            throw RbacException.conflict("RBAC_USUARIO_ADMIN_AREA",
                    "No se puede desactivar al usuario porque es jefatura del área: " + String.join(", ", areas) + ". Primero debe quitarle o reasignar ese cargo en Áreas corporativas.");
        }
    }
    public void protectAccountDeletion(UserAccount user) {
        protectAccountRemoval(user);
        if(user.getId().equals(access.context().usuarioId())) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "No puede eliminar la cuenta de la sesión actual; su identidad debe conservarse en la auditoría.");
        for (String reference : List.of("solicitud:usuario_id","historial_transicion:usuario_id",
                "notificacion:usuario_id","ai_analysis:solicitado_por_id","flujo_etapa_revisor:usuario_id",
                "area_jefatura:usuario_id")) {
            String[] parts=reference.split(":");
            Long count=jdbc.queryForObject("select count(*) from "+parts[0]+" where "+parts[1]+"=?",Long.class,user.getId());
            if(count>0) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                    "La cuenta conserva referencias operativas o históricas. Reasigne sus responsabilidades y desactívela para preservar la trazabilidad.");
        }
    }
    public UserResponse response(UserAccount user,boolean locked) {
        return UserMapper.toResponse(user,locked,access.forUser(user).roles());
    }
}
