package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** La raíz es Solicitud para componer directamente la política RBAC vigente. */
public class DocumentSearchSpecification implements Specification<Solicitud> {
    private final DocumentSearchCriteria filters;

    public DocumentSearchSpecification(DocumentSearchCriteria filters) {
        this.filters = filters;
    }

    @Override
    public Predicate toPredicate(Root<Solicitud> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        List<Predicate> predicates = new ArrayList<>();

        var current = query.subquery(Integer.class);
        Root<Documento> document = current.from(Documento.class);
        List<Predicate> currentFilters = new ArrayList<>();
        currentFilters.add(builder.equal(document.get("historialTransicion").get("solicitud").get("id"), root.get("id")));

        var replaced = query.subquery(Integer.class);
        Root<Documento> replacer = replaced.from(Documento.class);
        replaced.select(builder.literal(1)).where(builder.equal(replacer.get("reemplazaDocumento").get("id"), document.get("id")));
        currentFilters.add(builder.not(builder.exists(replaced)));

        if (filters.documentType() != null) {
            String targetType = filters.documentType().toUpperCase(Locale.ROOT);
            currentFilters.add(builder.or(
                    builder.equal(builder.upper(root.get("tipoDocumento").get("nombre")), targetType),
                    builder.equal(builder.upper(root.get("tipoDocumento").get("prefijo")), targetType)
            ));
        }

        if (filters.query() != null) {
            String pattern = literalPattern(filters.query());
            Join<Solicitud, UserAccount> emisor = root.join("usuario", JoinType.LEFT);
            var name = builder.concat(builder.concat(builder.coalesce(emisor.get("firstName"), ""), " "),
                    builder.coalesce(emisor.get("lastName"), ""));
            currentFilters.add(builder.or(
                    builder.like(builder.lower(root.get("titulo")), pattern, '\\'),
                    builder.like(builder.lower(root.get("descripcion")), pattern, '\\'),
                    builder.like(builder.lower(root.get("correlativo")), pattern, '\\'),
                    builder.like(builder.lower(name), pattern, '\\'),
                    builder.like(builder.lower(document.get("nombreArchivo")), pattern, '\\')));
        }

        current.select(builder.literal(1)).where(currentFilters.toArray(Predicate[]::new));
        predicates.add(builder.exists(current));

        if (filters.status() != null) {
            predicates.add(builder.equal(builder.upper(root.get("estado").get("codigo")), filters.status()));
        }

        if (filters.areaId() != null) {
            predicates.add(builder.or(
                    builder.equal(root.get("area").get("id"), filters.areaId()),
                    builder.equal(root.get("flujoDefinicion").get("area").get("id"), filters.areaId())));
        }

        if (filters.dateFrom() != null) {
            predicates.add(builder.greaterThanOrEqualTo(root.get("createdAt"), filters.dateFrom()));
        }

        if (filters.dateTo() != null) {
            predicates.add(filters.dateToExclusive()
                    ? builder.lessThan(root.get("createdAt"), filters.dateTo())
                    : builder.lessThanOrEqualTo(root.get("createdAt"), filters.dateTo()));
        }

        return builder.and(predicates.toArray(Predicate[]::new));
    }

    private String literalPattern(String value) {
        return "%" + value.toLowerCase(Locale.ROOT).replace("\\", "\\\\")
                .replace("%", "\\%").replace("_", "\\_") + "%";
    }
}
