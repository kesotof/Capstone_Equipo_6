package com.capstone.sistema.flow.dto;

import com.capstone.sistema.template.dto.FieldDefinition;

import java.util.List;

/**
 * Plantilla con que se generó el documento vigente y los datos del formulario, en el orden de sus campos.
 * Los valores solo se entregan a quien puede descargar el documento ({@code datosAccesibles}).
 */
public record PlantillaDetalleResponse(
        Long id,
        String nombre,
        int version,
        boolean datosAccesibles,
        List<Campo> campos,
        List<FieldDefinition> definiciones
) {
    public PlantillaDetalleResponse {
        campos = List.copyOf(campos);
        definiciones = List.copyOf(definiciones);
    }

    public record Campo(String key, String label, String tipo, Object valor) {}
}
