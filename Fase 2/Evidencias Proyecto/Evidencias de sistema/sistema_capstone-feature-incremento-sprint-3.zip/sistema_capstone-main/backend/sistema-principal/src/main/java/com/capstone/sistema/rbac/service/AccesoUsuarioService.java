package com.capstone.sistema.rbac.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.model.enums.AmbitoRol;
import com.capstone.sistema.org.area.model.AreaJefatura;
import com.capstone.sistema.org.area.repository.AreaJefaturaRepository;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.model.Rol;
import com.capstone.sistema.rbac.model.UsuarioRol;
import com.capstone.sistema.rbac.repository.ControlPoliticaRepository;
import com.capstone.sistema.rbac.repository.RolRepository;
import com.capstone.sistema.rbac.repository.UsuarioRolRepository;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class AccesoUsuarioService {

    private final UsuarioRolRepository usuarioRolRepository;
    private final UserAccountRepository userAccountRepository;
    private final RolRepository rolRepository;
    private final AreaRepository areaRepository;
    private final AreaJefaturaRepository areaJefaturaRepository;
    private final ControlPoliticaRepository controlPoliticaRepository;
    private final AuditService auditService;
    private final CurrentUserResolver currentUserResolver;
    private final RbacAccessService accessService;

    public AccesoUsuarioService(
            UsuarioRolRepository usuarioRolRepository,
            UserAccountRepository userAccountRepository,
            RolRepository rolRepository,
            AreaRepository areaRepository,
            AreaJefaturaRepository areaJefaturaRepository,
            ControlPoliticaRepository controlPoliticaRepository,
            AuditService auditService,
            CurrentUserResolver currentUserResolver
    ) {
        this(usuarioRolRepository, userAccountRepository, rolRepository, areaRepository,
                areaJefaturaRepository, controlPoliticaRepository, auditService, currentUserResolver, null);
    }

    @Autowired
    public AccesoUsuarioService(
            UsuarioRolRepository usuarioRolRepository,
            UserAccountRepository userAccountRepository,
            RolRepository rolRepository,
            AreaRepository areaRepository,
            AreaJefaturaRepository areaJefaturaRepository,
            ControlPoliticaRepository controlPoliticaRepository,
            AuditService auditService,
            CurrentUserResolver currentUserResolver,
            RbacAccessService accessService
    ) {
        this.usuarioRolRepository = usuarioRolRepository;
        this.userAccountRepository = userAccountRepository;
        this.rolRepository = rolRepository;
        this.areaRepository = areaRepository;
        this.areaJefaturaRepository = areaJefaturaRepository;
        this.controlPoliticaRepository = controlPoliticaRepository;
        this.auditService = auditService;
        this.currentUserResolver = currentUserResolver;
        this.accessService = accessService;
    }

    /** Gestión de accesos: USUARIO.GESTIONAR o ROL.GESTIONAR ("asignar accesos" según V2 seed). */
    private void requireGestionAccesos() {
        if (accessService == null) throw RbacException.denied();
        accessService.requireAny(Permiso.USUARIO_GESTIONAR, Permiso.ROL_GESTIONAR);
    }

    /** Lectura de accesos de otro usuario: gestión de accesos o AUDITORIA.VER; el propio usuario siempre. */
    private void requireLecturaAccesos(UUID usuarioId) {
        if (accessService == null) throw RbacException.denied();
        accessService.requireSelfOrAny(usuarioId, Permiso.USUARIO_GESTIONAR, Permiso.ROL_GESTIONAR, Permiso.AUDITORIA_CONSULTAR);
    }

    /** El administrador global se define en Keycloak: no se asigna ni revoca desde la plataforma (422). */
    private void rechazarAdminGlobal(Rol rol) {
        if (rol == null) return;
        String code = rol.getCodigo();
        if ("ADMIN_SISTEMA".equalsIgnoreCase(code) || "ADMIN".equalsIgnoreCase(code)) {
            throw RbacException.adminGlobalNoAsignable();
        }
    }

    /** Asignar o retirar un rol con permisos bloqueados solo lo puede hacer un administrador del sistema. */
    private void requireAdminSiRolBloqueado(Rol rol) {
        if (rol == null || !rol.isPermisosBloqueados()) return;
        if (accessService == null || !accessService.context().admin()) {
            throw RbacException.denied();
        }
    }

    public UserAccesosResponse getAccesos(UUID usuarioId) {
        requireLecturaAccesos(usuarioId);
        UserAccount user = userAccountRepository.findById(usuarioId)
                .orElseThrow(RbacException::missing);

        List<UsuarioRol> userRoles = usuarioRolRepository.findByUsuario_Id(usuarioId);
        List<AsignacionAccesoDto> asignaciones = userRoles.stream()
                .map(this::toAsignacionDto)
                .toList();

        List<AreaJefatura> jefaturas = areaJefaturaRepository.findById_UsuarioId(usuarioId);
        List<JefaturaItem> jefaturaItems = jefaturas.stream()
                .map(j -> {
                    Area a = areaRepository.findById(j.getAreaId()).orElse(null);
                    return new JefaturaItem(j.getAreaId(), a != null ? a.getNombre() : "Área #" + j.getAreaId());
                })
                .sorted(Comparator.comparing(JefaturaItem::nombre))
                .toList();

        return new UserAccesosResponse(
                user.getId(),
                user.getNombreCompleto() != null ? user.getNombreCompleto() : user.getEmail(),
                asignaciones,
                jefaturaItems,
                user.getLockVersion()
        );
    }

    @Transactional
    public AsignacionAccesoDto asignarAcceso(UUID usuarioId, AsignarAccesoRequest request, UUID actorId) {
        requireGestionAccesos();
        UserAccount user = userAccountRepository.findById(usuarioId)
                .orElseThrow(RbacException::missing);
        checkVersion(user.getLockVersion(), request.versionAcceso());

        Rol rol = rolRepository.findById(request.rolId())
                .orElseThrow(() -> RbacException.invalid("El rol especificado no existe."));
        rechazarAdminGlobal(rol);
        requireAdminSiRolBloqueado(rol);
        if (!rol.isActivo()) {
            throw RbacException.conflict("RBAC_ROL_INACTIVO", "No se puede asignar un rol inactivo.");
        }

        Area area = null;
        if (request.areaId() != null) {
            if (rol.getAmbito() == AmbitoRol.SOLO_GLOBAL) {
                throw RbacException.conflict("ROL_AMBITO_INCOMPATIBLE",
                        "El rol tiene ámbito estrictamente global y no puede ser asignado a un área específica.");
            }
            area = areaRepository.findById(request.areaId())
                    .orElseThrow(() -> RbacException.invalid("El área especificada no existe."));
            if (!area.isActivo()) {
                throw RbacException.conflict("RBAC_AREA_INACTIVA", "No se puede asignar un rol en un área inactiva.");
            }
        }

        UserAccount otorgadoPor = null;
        if (actorId != null) {
            otorgadoPor = userAccountRepository.findById(actorId).orElse(null);
        }
        if (otorgadoPor == null) {
            otorgadoPor = currentUserResolver.resolveCurrentUser().orElse(user);
        }

        UsuarioRol nuevaAsignacion = new UsuarioRol(user, rol, area, request.vigenteHasta(), otorgadoPor);
        UsuarioRol saved = usuarioRolRepository.save(nuevaAsignacion);

        controlPoliticaRepository.incrementarVersion();
        user.bumpVersionAcceso();
        userAccountRepository.saveAndFlush(user);

        auditService.registerAuditEvent("ROL_ASIGNADO", "rol", String.valueOf(rol.getId()), "EXITO",
                detalleAsignacion("asignado a", rol, user, area, request.vigenteHasta()));

        return toAsignacionDto(saved);
    }

    @Transactional
    public void revocarAcceso(UUID usuarioId, Long asignacionId, Long requestedVersion) {
        requireGestionAccesos();
        UserAccount user = userAccountRepository.findById(usuarioId)
                .orElseThrow(RbacException::missing);
        checkVersion(user.getLockVersion(), requestedVersion);

        UsuarioRol asignacion = usuarioRolRepository.findById(asignacionId)
                .orElseThrow(RbacException::missing);

        if (!asignacion.getUsuario().getId().equals(usuarioId)) {
            throw RbacException.denied();
        }
        rechazarAdminGlobal(asignacion.getRol());
        requireAdminSiRolBloqueado(asignacion.getRol());

        Rol rolRevocado = asignacion.getRol();
        Area areaRevocada = asignacion.getArea();
        Instant vigenciaRevocada = asignacion.getVigenteHasta();
        usuarioRolRepository.delete(asignacion);
        controlPoliticaRepository.incrementarVersion();
        user.bumpVersionAcceso();
        userAccountRepository.saveAndFlush(user);

        auditService.registerAuditEvent("ROL_REVOCADO", "rol", String.valueOf(rolRevocado.getId()), "EXITO",
                detalleAsignacion("revocado de", rolRevocado, user, areaRevocada, vigenciaRevocada));
    }

    /** Detalle de auditoría de una asignación: rol, email del usuario, área (o "global") y vigencia. */
    private static String detalleAsignacion(String accion, Rol rol, UserAccount user, Area area, Instant vigenteHasta) {
        return "Rol " + rol.getCodigo() + " (" + rol.getNombre() + ") " + accion + " usuario " + user.getEmail()
                + ". Área: " + (area != null ? area.getNombre() : "global")
                + ". Vigencia: " + (vigenteHasta != null ? "hasta " + vigenteHasta : "indefinida");
    }

    public List<AsignacionAccesoDto> getAccesosPorArea(Long areaId) {
        if (accessService == null) throw RbacException.denied();
        accessService.requireAny(Permiso.AREA_GESTIONAR, Permiso.USUARIO_GESTIONAR, Permiso.ROL_GESTIONAR, Permiso.AUDITORIA_CONSULTAR);
        return usuarioRolRepository.findByArea_Id(areaId).stream()
                .filter(ur -> ur.getVigenteHasta() == null || ur.getVigenteHasta().isAfter(Instant.now()))
                .map(this::toAsignacionDto)
                .toList();
    }

    private AsignacionAccesoDto toAsignacionDto(UsuarioRol ur) {
        RolItemRef rolRef = new RolItemRef(ur.getRol().getId(), ur.getRol().getCodigo(), ur.getRol().getNombre());
        AreaRef areaRef = ur.getArea() != null ? new AreaRef(ur.getArea().getId(), ur.getArea().getNombre()) : null;
        UserAccount op = ur.getOtorgadoPor();
        OtorgadoPorRef opRef = op != null ? new OtorgadoPorRef(op.getId(), op.getNombreCompleto(), op.getEmail()) : null;

        return new AsignacionAccesoDto(
                ur.getId(),
                rolRef,
                areaRef,
                ur.getVigenteHasta(),
                opRef,
                ur.getCreatedAt()
        );
    }

    private static void checkVersion(long current, Long requested) {
        if (requested == null || requested < 0) throw RbacException.invalid("Envíe una versión válida.");
        if (current != requested) throw RbacException.conflict("RBAC_VERSION_DESACTUALIZADA", "Los datos cambiaron. Recargue antes de editar.");
    }
}
