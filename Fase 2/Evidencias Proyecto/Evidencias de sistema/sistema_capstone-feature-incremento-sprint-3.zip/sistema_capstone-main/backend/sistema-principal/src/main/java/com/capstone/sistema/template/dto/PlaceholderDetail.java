package com.capstone.sistema.template.dto;

public record PlaceholderDetail(
        String key,
        String location,
        boolean splitRun,
        String contextSnippet
) {}
