package com.capstone.sistema.doc.controller;

import com.capstone.sistema.doc.dto.TipoDocumentoDtos.*;
import com.capstone.sistema.doc.service.TipoDocumentoService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@Tag(name = "Tipos de Documento", description = "Gestión de tipos de documento, prefijos correlativos y plazos SLA")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/tipos-documento")
public class TipoDocumentoController {

    private final TipoDocumentoService tipoDocumentoService;
    private final RbacAccessService accessService;

    public TipoDocumentoController(TipoDocumentoService tipoDocumentoService, RbacAccessService accessService) {
        this.tipoDocumentoService = tipoDocumentoService;
        this.accessService = accessService;
    }

    /** Mutaciones: TIPO_DOCUMENTO.GESTIONAR (enum SLA_GESTIONAR); 403 RBAC_ACCION_DENEGADA si no lo tiene. */
    private void requireGestion() {
        accessService.requireAny(Permiso.SLA_GESTIONAR);
    }

    @Operation(summary = "Listar tipos de documento")
    @GetMapping
    public ResponseEntity<List<TipoDocumentoResponse>> list(
            @RequestParam(required = false) Boolean activo,
            @RequestParam(required = false) String q
    ) {
        return ResponseEntity.ok(tipoDocumentoService.list(activo, q));
    }

    @Operation(summary = "Obtener tipo de documento por ID")
    @GetMapping("/{id}")
    public ResponseEntity<TipoDocumentoResponse> get(@PathVariable Long id) {
        return ResponseEntity.ok(tipoDocumentoService.get(id));
    }

    @Operation(summary = "Crear nuevo tipo de documento")
    @PostMapping
    public ResponseEntity<TipoDocumentoResponse> create(@Valid @RequestBody CrearTipoDocumentoRequest request) {
        requireGestion();
        TipoDocumentoResponse created = tipoDocumentoService.create(request);
        return ResponseEntity.created(URI.create("/api/tipos-documento/" + created.id())).body(created);
    }

    @Operation(summary = "Actualizar tipo de documento")
    @PutMapping("/{id}")
    public ResponseEntity<TipoDocumentoResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody ActualizarTipoDocumentoRequest request
    ) {
        requireGestion();
        return ResponseEntity.ok(tipoDocumentoService.update(id, request));
    }

    @Operation(summary = "Cambiar estado de activación de tipo de documento")
    @PatchMapping("/{id}/status")
    public ResponseEntity<TipoDocumentoResponse> status(
            @PathVariable Long id,
            @Valid @RequestBody ToggleStatusTipoDocumentoRequest request
    ) {
        requireGestion();
        return ResponseEntity.ok(tipoDocumentoService.status(id, request));
    }

    @Operation(summary = "Eliminar tipo de documento sin solicitudes asociadas")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        requireGestion();
        tipoDocumentoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
