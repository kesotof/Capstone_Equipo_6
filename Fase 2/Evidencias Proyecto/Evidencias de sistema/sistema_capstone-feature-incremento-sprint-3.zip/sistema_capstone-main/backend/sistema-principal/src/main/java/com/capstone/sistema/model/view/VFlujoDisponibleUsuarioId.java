package com.capstone.sistema.model.view;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class VFlujoDisponibleUsuarioId implements Serializable {

    private Long flujoId;
    private UUID usuarioId;

    public VFlujoDisponibleUsuarioId() {
    }

    public VFlujoDisponibleUsuarioId(Long flujoId, UUID usuarioId) {
        this.flujoId = flujoId;
        this.usuarioId = usuarioId;
    }

    public Long getFlujoId() {
        return flujoId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VFlujoDisponibleUsuarioId that = (VFlujoDisponibleUsuarioId) o;
        return Objects.equals(flujoId, that.flujoId) && Objects.equals(usuarioId, that.usuarioId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(flujoId, usuarioId);
    }
}
