package com.capstone.sistema.doc.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDate;
import java.util.Map;

@Service
public class CorrelativoService {

    private final JdbcTemplate jdbcTemplate;
    private final Clock clock;

    public CorrelativoService(JdbcTemplate jdbcTemplate, Clock clock) {
        this.jdbcTemplate = jdbcTemplate;
        this.clock = clock;
    }

    /**
     * Incrementa atómicamente el correlativo en base de datos sin alterar lock_version
     * para evitar contención concurrente según regla P8 del Modelo v5.
     * Retorna el código formateado {PREFIJO}-{YYYY}-{00001}.
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public String siguienteCorrelativo(Long tipoDocumentoId) {
        String sql = "UPDATE tipo_documento SET ultimo_correlativo = ultimo_correlativo + 1 WHERE id = ? RETURNING prefijo, ultimo_correlativo";
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, tipoDocumentoId);
        
        String prefijo = (String) result.get("prefijo");
        Number ultimo = (Number) result.get("ultimo_correlativo");
        int year = LocalDate.now(clock).getYear();

        return String.format("%s-%d-%05d", prefijo != null ? prefijo.trim() : "DOC", year, ultimo.longValue());
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public String siguienteCorrelativoPorPrefijo(String prefijo) {
        String sql = "UPDATE tipo_documento SET ultimo_correlativo = ultimo_correlativo + 1 WHERE upper(prefijo) = upper(?) RETURNING prefijo, ultimo_correlativo";
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, prefijo);

        String pref = (String) result.get("prefijo");
        Number ultimo = (Number) result.get("ultimo_correlativo");
        int year = LocalDate.now(clock).getYear();

        return String.format("%s-%d-%05d", pref != null ? pref.trim() : "DOC", year, ultimo.longValue());
    }
}
