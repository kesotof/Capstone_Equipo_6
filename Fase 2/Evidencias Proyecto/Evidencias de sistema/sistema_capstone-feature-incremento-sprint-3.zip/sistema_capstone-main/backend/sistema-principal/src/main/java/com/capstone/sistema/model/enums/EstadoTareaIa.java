package com.capstone.sistema.model.enums;

/** A-09: estado de la tarea de IA en el principal (el worker nunca consulta la base, §6). */
public enum EstadoTareaIa {
    PENDIENTE,
    COMPLETADA,
    FALLIDA
}
