package com.capstone.sistema.audit.dto;

import java.time.Instant;

public record AuditEventResponse(
        Long id,
        String email,
        String eventType,
        String ipAddress,
        String detalle,
        Instant occurredAt,
        String entidad,
        String entidadId,
        Instant fecha
) {
    public AuditEventResponse(Long id, String email, String eventType, String ipAddress, String detalle, Instant occurredAt) {
        this(id, email, eventType, ipAddress, detalle, occurredAt, null, null, occurredAt);
    }
}
