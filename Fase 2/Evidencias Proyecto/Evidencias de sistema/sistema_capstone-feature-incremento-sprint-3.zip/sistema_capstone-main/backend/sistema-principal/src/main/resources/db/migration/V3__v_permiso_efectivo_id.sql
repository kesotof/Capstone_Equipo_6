CREATE OR REPLACE VIEW v_permiso_efectivo AS
-- Roles asignados sobre un área (se expanden a las subáreas)
SELECT ur.usuario_id, p.recurso, p.accion, d.area_id,
       'ROL'::varchar(20) AS origen, r.id AS rol_id, ur.area_id AS area_asignada_id,
       md5(concat_ws(':', ur.usuario_id, p.recurso, p.accion, coalesce(d.area_id, 0), 'ROL', r.id, coalesce(ur.area_id, 0))) AS id
  FROM usuario_rol ur
  JOIN rol r          ON r.id = ur.rol_id AND r.activo
  JOIN rol_permiso rp ON rp.rol_id = r.id
  JOIN permiso p      ON p.id = rp.permiso_id
  JOIN v_area_descendiente d ON d.ancestro_id = ur.area_id
 WHERE ur.vigente_hasta IS NULL OR ur.vigente_hasta > now()
UNION ALL
-- Roles asignados globalmente
SELECT ur.usuario_id, p.recurso, p.accion, NULL::bigint AS area_id,
       'ROL_GLOBAL'::varchar(20) AS origen, r.id AS rol_id, NULL::bigint AS area_asignada_id,
       md5(concat_ws(':', ur.usuario_id, p.recurso, p.accion, 0, 'ROL_GLOBAL', r.id, 0)) AS id
  FROM usuario_rol ur
  JOIN rol r          ON r.id = ur.rol_id AND r.activo
  JOIN rol_permiso rp ON rp.rol_id = r.id
  JOIN permiso p      ON p.id = rp.permiso_id
 WHERE ur.area_id IS NULL AND (ur.vigente_hasta IS NULL OR ur.vigente_hasta > now())
UNION ALL
-- Jefaturas: el rol AUTO_JEFATURA se aplica sobre el área que dirigen y sus subáreas
SELECT j.usuario_id, p.recurso, p.accion, d.area_id,
       'JEFATURA'::varchar(20) AS origen, r.id AS rol_id, j.area_id AS area_asignada_id,
       md5(concat_ws(':', j.usuario_id, p.recurso, p.accion, coalesce(d.area_id, 0), 'JEFATURA', r.id, coalesce(j.area_id, 0))) AS id
  FROM area_jefatura j
  JOIN usuario u      ON u.id = j.usuario_id AND u.activo
  JOIN rol r          ON r.asignacion = 'AUTO_JEFATURA' AND r.activo
  JOIN rol_permiso rp ON rp.rol_id = r.id
  JOIN permiso p      ON p.id = rp.permiso_id
  JOIN v_area_descendiente d ON d.ancestro_id = j.area_id;
