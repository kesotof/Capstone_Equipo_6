package com.capstone.sistema.rbac.model;

import com.capstone.sistema.model.enums.AmbitoRol;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "permiso")
public class PermisoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String recurso;

    @Column(nullable = false, length = 30)
    private String accion;

    @Column(length = 255)
    private String descripcion;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AmbitoRol ambito;

    protected PermisoEntity() {
    }

    public PermisoEntity(String recurso, String accion, String descripcion, AmbitoRol ambito) {
        this.recurso = recurso;
        this.accion = accion;
        this.descripcion = descripcion;
        this.ambito = ambito;
    }

    public Long getId() {
        return id;
    }

    public String getRecurso() {
        return recurso;
    }

    public void setRecurso(String recurso) {
        this.recurso = recurso;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public AmbitoRol getAmbito() {
        return ambito;
    }

    public void setAmbito(AmbitoRol ambito) {
        this.ambito = ambito;
    }

    public String getCodigo() {
        return recurso + "." + accion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PermisoEntity that = (PermisoEntity) o;
        return Objects.equals(recurso, that.recurso) && Objects.equals(accion, that.accion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(recurso, accion);
    }
}
