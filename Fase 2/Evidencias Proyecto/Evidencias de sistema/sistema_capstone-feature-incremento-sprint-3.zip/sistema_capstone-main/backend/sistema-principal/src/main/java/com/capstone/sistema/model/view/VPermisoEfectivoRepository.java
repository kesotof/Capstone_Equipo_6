package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface VPermisoEfectivoRepository extends JpaRepository<VPermisoEfectivo, String> {

    List<VPermisoEfectivo> findByUsuarioId(UUID usuarioId);

    @Query("SELECT p FROM VPermisoEfectivo p WHERE p.usuarioId = :usuarioId AND p.recurso = :recurso AND p.accion = :accion")
    List<VPermisoEfectivo> findByUsuarioIdAndRecursoAndAccion(
            @Param("usuarioId") UUID usuarioId,
            @Param("recurso") String recurso,
            @Param("accion") String accion
    );

    @Query("SELECT COUNT(p) > 0 FROM VPermisoEfectivo p WHERE p.usuarioId = :usuarioId AND p.recurso = :recurso AND p.accion = :accion AND (p.areaId IS NULL OR p.areaId = :areaId)")
    boolean existsByUsuarioIdAndRecursoAndAccionAndArea(
            @Param("usuarioId") UUID usuarioId,
            @Param("recurso") String recurso,
            @Param("accion") String accion,
            @Param("areaId") Long areaId
    );

    @Query("SELECT COUNT(p) > 0 FROM VPermisoEfectivo p WHERE p.usuarioId = :usuarioId AND p.recurso = :recurso AND p.accion = :accion")
    boolean existsByUsuarioIdAndRecursoAndAccion(
            @Param("usuarioId") UUID usuarioId,
            @Param("recurso") String recurso,
            @Param("accion") String accion
    );

    @Query("SELECT COUNT(p) > 0 FROM VPermisoEfectivo p WHERE p.usuarioId = :usuarioId AND p.recurso = :recurso AND p.accion = :accion AND p.areaId IS NULL")
    boolean existsByUsuarioIdAndRecursoAndAccionGlobally(
            @Param("usuarioId") UUID usuarioId,
            @Param("recurso") String recurso,
            @Param("accion") String accion
    );
}
