package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlujoConflictException;
import com.capstone.sistema.flow.exception.FlujoNotFoundException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Service
@Transactional(readOnly = true)
public class FlujoConfigService {
    private static final ObjectMapper JSON = new ObjectMapper();
    private final FlujoDefinicionRepository definitions;
    private final SolicitudRepository requests;
    private final AreaRepository areas;
    private final AuditService audit;
    private final RbacAccessService access;
    private final RbacManagementService security;
    private final FlujoConcurrencyService concurrency;
    private final FlujoIntegrityService integrity;
    private final FlujoReviewerResolver reviewers;
    private final com.capstone.sistema.model.view.VFlujoDisponibleUsuarioRepository vFlujoDisponibleUsuarioRepository;

    @org.springframework.beans.factory.annotation.Autowired
    public FlujoConfigService(
            FlujoDefinicionRepository definitions,
            SolicitudRepository requests,
            AreaRepository areas,
            AuditService audit,
            RbacAccessService access,
            @org.springframework.beans.factory.annotation.Autowired(required = false) RbacManagementService security,
            @org.springframework.beans.factory.annotation.Autowired(required = false) FlujoConcurrencyService concurrency,
            @org.springframework.beans.factory.annotation.Autowired(required = false) FlujoIntegrityService integrity,
            @org.springframework.beans.factory.annotation.Autowired(required = false) FlujoReviewerResolver reviewers,
            @org.springframework.beans.factory.annotation.Autowired(required = false) com.capstone.sistema.model.view.VFlujoDisponibleUsuarioRepository vFlujoDisponibleUsuarioRepository
    ) {
        this.definitions = definitions;
        this.requests = requests;
        this.areas = areas;
        this.audit = audit;
        this.access = access;
        this.security = security;
        this.concurrency = concurrency;
        this.integrity = integrity;
        this.reviewers = reviewers;
        this.vFlujoDisponibleUsuarioRepository = vFlujoDisponibleUsuarioRepository;
    }

    public FlujoConfigService(FlujoDefinicionRepository definitions, SolicitudRepository requests,
            AreaRepository areas, AuditService audit, RbacAccessService access,
            RbacManagementService security, FlujoConcurrencyService concurrency, FlujoIntegrityService integrity, FlujoReviewerResolver reviewers) {
        this(definitions, requests, areas, audit, access, security, concurrency, integrity, reviewers, null);
    }

    private Set<String> prepareMutation() {
        return security != null ? security.prepareMutation() : Set.of();
    }

    private void finishMutation(Set<String> before) {
        if (security != null) {
            security.finishMutation(before);
        }
    }

    @Transactional
    public FlujoResponse crearFlujo(CrearFlujoRequest request) {
        Set<String> before=prepareMutation();
        if (access != null) access.manageFlow(request.areaId());
        String name=validateName(request.nombre());
        if (FlujoIntegrityService.BASE_NAME.equalsIgnoreCase(name)) throw protectedFlow();
        checkUnique(name,null);
        FlujoDefinicion flow=new FlujoDefinicion(name,validateDescription(request.descripcion()),activeArea(request.areaId()));
        FlujoDefinicion saved=definitions.saveAndFlush(flow);
        if (saved != null) flow = saved;
        finishMutation(before);
        audit.registerUserManagementEvent("CREAR_FLUJO","Flujo creado inactivo e incompleto: " + flow.getId() + " — " + name);
        return toResponse(flow);
    }

    @Transactional
    public FlujoResponse actualizarFlujo(Long id, ActualizarFlujoRequest request) {
        Set<String> before=prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        if (access != null) access.manageFlow(request.areaId());
        String name=validateName(request.nombre());
        Long previousArea=areaId(flow);
        boolean base=integrity != null && integrity.isBase(flow);
        if (base && (!FlujoIntegrityService.BASE_NAME.equals(name) || request.areaId()!=null)) throw protectedFlow();
        if (!base && FlujoIntegrityService.BASE_NAME.equalsIgnoreCase(name)) throw protectedFlow();
        if (!Objects.equals(previousArea,request.areaId()) && requests.existsByFlujoDefinicion_Id(id)) {
            throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION","Un flujo con solicitudes vinculadas conserva su área. Cree otra definición para el nuevo destino.");
        }
        checkUnique(name,id);
        flow.setNombre(name);
        flow.setDescripcion(validateDescription(request.descripcion()));
        // Conservar metadata de áreas históricas inactivas si no hay traslado ni activación.
        if (!Objects.equals(previousArea,request.areaId())) flow.setArea(activeArea(request.areaId()));
        if (request.activo()!=null) setStatus(flow,request.activo());
        else if (flow.isActivo()) validateActivation(flow);
        else flow.setCompleto(integrity != null ? integrity.complete(flow) : true);
        flow.touch();
        definitions.saveAndFlush(flow);
        finishMutation(before);
        audit.registerUserManagementEvent("ACTUALIZAR_FLUJO","Metadatos del flujo " + id + " actualizados; versión " + flow.getVersion());
        return toResponse(flow);
    }

    @Transactional
    public FlujoResponse cambiarEstado(Long id, EstadoFlujoRequest request) {
        Set<String> before=prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        if (request.activo()==null) throw new IllegalArgumentException("El estado activo es obligatorio.");
        setStatus(flow,request.activo());
        flow.touch();
        definitions.saveAndFlush(flow);
        finishMutation(before);
        audit.registerUserManagementEvent("CAMBIAR_ESTADO_FLUJO","Flujo " + id + ": activo=" + flow.isActivo() + ", versión=" + flow.getVersion());
        return toResponse(flow);
    }

    public FlujoResponse obtenerFlujo(Long id) {
        FlujoDefinicion flow=definitions.findById(id).orElseThrow(()->new FlujoNotFoundException("Flujo no encontrado"));
        if (access != null && !access.canManageFlow(areaId(flow)) && !selectable(flow)) throw RbacException.missing();
        return toResponse(flow);
    }

    public List<FlujoResponse> listarFlujos(Long areaId, Boolean activo) { return listarFlujos(areaId,activo,null); }

    public List<FlujoResponse> listarFlujos(Long areaId, Boolean activo, Boolean completo) {
        if (areaId!=null && areaId<=0) throw new IllegalArgumentException("El ID del área debe ser positivo.");
        List<FlujoDefinicion> flows=areaId!=null ? definitions.findByArea_Id(areaId) : definitions.findAll();
        return flows.stream()
                .filter(f->access == null || access.canManageFlow(areaId(f)) || selectable(f))
                .filter(f->activo==null || f.isActivo()==activo)
                .filter(f->completo==null || (integrity != null ? integrity.complete(f) : true)==completo)
                .sorted(Comparator.comparing(FlujoDefinicion::getNombre,String.CASE_INSENSITIVE_ORDER).thenComparing(FlujoDefinicion::getId))
                .map(this::toResponse).toList();
    }

    @Transactional
    public FlujoResponse configurarEtapas(Long id, ConfigurarEtapasRequest request) {
        Set<String> dependencies=prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,request.version());
        if (Long.valueOf(1).equals(id)) throw protectedFlow();
        if (requests.existsByFlujoDefinicion_Id(id)) throw RbacException.conflict("RBAC_DEPENDENCIA_REVISION",
                "No puede reemplazar las etapas de un flujo con solicitudes vinculadas.");
        List<EtapaConfigItem> items=request.etapas();
        if (items==null || items.isEmpty() || items.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Debe configurar al menos una etapa válida.");
        }
        List<EtapaConfigItem> ordered=items.stream().sorted(Comparator.comparing(EtapaConfigItem::orden,
                Comparator.nullsLast(Comparator.naturalOrder()))).toList();
        List<Map<String,Object>> before=auditStages(flow.getEtapas());
        List<FlujoEtapa> stages=new ArrayList<>();
        for (int i=0;i<ordered.size();i++) {
            EtapaConfigItem item=ordered.get(i);
            if (item.orden()==null || item.orden()!=i+1) throw new IllegalArgumentException("Las etapas deben tener orden consecutivo desde 1, sin duplicados ni saltos.");
            if (item.tipoAccion()!=TipoAccionEtapa.REVISION) throw new IllegalArgumentException("El tipo de acción soportado es REVISION.");
            FlujoEtapa stage=new FlujoEtapa(flow,item.orden(),validateName(item.nombre()));
            stage.setCriterioIa(normalizarCriterioIa(item.criterioIa()));
            List<UUID> reviewerIds=FlujoReviewerResolver.requestedReviewers(item.revisorIds(),item.revisorId());
            if (reviewers != null) reviewers.assign(stage,item.tipoAsignacion(),reviewerIds);
            stages.add(stage);
        }
        flow.getEtapas().clear();
        definitions.flush();
        stages.forEach(flow::addEtapa);
        boolean complete = integrity != null
                ? integrity.complete(flow)
                : stages.stream().noneMatch(s -> s.getRevisor() == null);
        flow.setCompleto(complete);
        if (flow.isActivo() && complete) validateActivation(flow);
        flow.touch();
        definitions.saveAndFlush(flow);
        finishMutation(dependencies);
        Map<String,Object> detail=new LinkedHashMap<>();
        detail.put("flujoId",id);
        detail.put("etapas",stages.size());
        detail.put("completo",complete);
        detail.put("version",flow.getVersion());
        detail.put("antes",before);
        detail.put("despues",auditStages(stages));
        audit.registerAuditEvent("CONFIGURAR_ETAPAS_FLUJO", "flujo", String.valueOf(id), "EXITO", toJson(detail));
        return toResponse(flow);
    }

    /**
     * F6 (§6.5, D3-03): actualiza el criterio de IA de una etapa. A diferencia de
     * {@code configurarEtapas}, se permite también en flujos con solicitudes (un cambio de
     * criterio rige para las próximas entradas a la etapa). Mismo permiso y control de versión
     * que la reasignación de responsables: {@code FLUJO.GESTIONAR} sobre el área del flujo y
     * {@code FLUJO_VERSION_CONFLICTO}. Audita {@code CRITERIO_IA_ACTUALIZADO} con el texto
     * anterior y el nuevo.
     */
    @Transactional
    public FlujoResponse actualizarCriterioIa(Long id, Long etapaId, CriterioIaRequest request) {
        Set<String> dependencies = prepareMutation();
        FlujoDefinicion flow = concurrency.lockDefinition(id);
        if (access != null) access.manageFlow(areaId(flow));
        concurrency.checkVersion(flow.getVersion(), request.version(), "FLUJO_VERSION_CONFLICTO");
        FlujoEtapa stage = flow.getEtapas().stream()
                .filter(s -> Objects.equals(s.getId(), etapaId))
                .findFirst()
                .orElseThrow(RbacException::missing);
        String anterior = stage.getCriterioIa();
        String nuevo = normalizarCriterioIa(request.criterioIa());
        if (!Objects.equals(anterior, nuevo)) {
            stage.setCriterioIa(nuevo);
            flow.touch();
            definitions.saveAndFlush(flow);
            Map<String, Object> detail = new LinkedHashMap<>();
            detail.put("flujoId", id);
            detail.put("etapaId", etapaId);
            detail.put("etapa", stage.getNombre());
            detail.put("criterioAnterior", anterior);
            detail.put("criterioNuevo", nuevo);
            detail.put("version", flow.getVersion());
            audit.registerAuditEvent("CRITERIO_IA_ACTUALIZADO", "flujo", String.valueOf(id), "EXITO", toJson(detail));
        }
        finishMutation(dependencies);
        return toResponse(flow);
    }

    /**
     * F6 (§6.5): normalización del criterio de IA (D3-03). Trim; vacío o solo espacios pasa a
     * {@code null} (etapa sin criterio); entre 10 y 4000 caracteres, si no → 400
     * {@code CRITERIO_IA_INVALIDO}.
     */
    static String normalizarCriterioIa(String texto) {
        if (texto == null) return null;
        String limpio = texto.trim();
        if (limpio.isEmpty()) return null;
        if (limpio.length() < 10 || limpio.length() > 4000) {
            throw new RbacException(org.springframework.http.HttpStatus.BAD_REQUEST, "CRITERIO_IA_INVALIDO",
                    "El criterio de IA debe tener entre 10 y 4000 caracteres (recibido: " + limpio.length() + ").");
        }
        return limpio;
    }

    /** Resumen auditable de etapas: orden, nombre, modo y emails de revisores en orden determinista. */
    static List<Map<String,Object>> auditStages(java.util.Collection<FlujoEtapa> stages) {
        return stages.stream().sorted(Comparator.comparingInt(FlujoEtapa::getOrden)).map(stage->{
            Map<String,Object> item=new LinkedHashMap<>();
            item.put("etapaId",stage.getId());
            item.put("orden",stage.getOrden());
            item.put("nombre",stage.getNombre());
            item.put("modoRevisor",stage.getModoRevisor()!=null?stage.getModoRevisor().name():ModoRevisor.LISTA.name());
            item.put("revisores",reviewerEmails(stage));
            return item;
        }).toList();
    }

    static List<String> reviewerEmails(FlujoEtapa stage) {
        return stage.getRevisoresOrdenados().stream().map(UserAccount::getEmail).toList();
    }

    static String toJson(Object value) {
        try {
            return JSON.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("No fue posible serializar el detalle de auditoría del flujo", e);
        }
    }

    @Transactional
    public void eliminarFlujo(Long id, Long version) {
        Set<String> before=prepareMutation();
        FlujoDefinicion flow=managedDefinition(id,version);
        if (Long.valueOf(1).equals(id)) throw protectedFlow();
        boolean used=requests.existsByFlujoDefinicion_Id(id);
        if (used) { flow.setActivo(false); flow.touch(); definitions.save(flow); }
        else definitions.delete(flow);
        definitions.flush();
        finishMutation(before);
        audit.registerUserManagementEvent(used?"DESACTIVAR_FLUJO":"ELIMINAR_FLUJO",
                "Flujo " + id + (used?" desactivado conservando solicitudes y etapas.":" eliminado sin solicitudes vinculadas."));
    }

    @Transactional
    public void eliminarFlujo(Long id) { eliminarFlujo(id,null); }

    private FlujoDefinicion managedDefinition(Long id, Long version) {
        FlujoDefinicion flow = concurrency != null ? concurrency.lockDefinition(id) : definitions.findById(id).orElseThrow(() -> new FlujoNotFoundException("Flujo no encontrado"));
        if (access != null) access.manageFlow(areaId(flow));
        if (concurrency != null) concurrency.checkVersion(flow.getVersion(),version,"FLUJO_VERSION_CONFLICTO");
        return flow;
    }

    private void setStatus(FlujoDefinicion flow, boolean active) {
        if (active) validateActivation(flow);
        else flow.setCompleto(integrity.complete(flow));
        flow.setActivo(active);
    }

    private void validateActivation(FlujoDefinicion flow) {
        if (flow.getArea()!=null && !flow.getArea().isActivo()) throw RbacException.conflict("AREA_INACTIVA","El área del flujo está inactiva.");
        if (integrity != null) {
            integrity.orderedStages(flow);
            if (!integrity.isBase(flow) && reviewers != null) flow.getEtapas().forEach(reviewers::requireAvailable);
        }
        flow.setCompleto(true);
    }

    private boolean selectable(FlujoDefinicion flow) {
        return (access == null || access.canEmitFlow(flow)) && (integrity == null || integrity.complete(flow))
                && (flow.getArea()==null || flow.getArea().isActivo());
    }

    private Area activeArea(Long id) {
        if (id==null) return null;
        if (id<=0) throw new IllegalArgumentException("El ID del área debe ser positivo.");
        Area area=areas.findById(id).orElseThrow(()->new IllegalArgumentException("El área indicada no existe."));
        if (!area.isActivo()) throw RbacException.conflict("AREA_INACTIVA","No puede asociar el flujo a un área inactiva.");
        return area;
    }

    private void checkUnique(String name,Long id) {
        if (definitions.existsNormalizedName(name,id)) throw new FlujoConflictException("FLUJO_NOMBRE_DUPLICADO","Ya existe un flujo con ese nombre.");
    }

    private static String validateName(String value) {
        if (value==null) throw new IllegalArgumentException("El nombre es obligatorio.");
        String name=value.trim();
        if (name.isBlank() || name.length()>150 || name.codePoints().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException("El nombre admite entre 1 y 150 caracteres, sin caracteres de control.");
        }
        return name;
    }

    private static String validateDescription(String value) {
        if (value==null) return null;
        if (value.length()>2000 || value.indexOf(0)>=0) throw new IllegalArgumentException("La descripción admite hasta 2000 caracteres, sin el carácter nulo.");
        return value.trim();
    }

    private static Long areaId(FlujoDefinicion flow) { return flow.getArea()==null?null:flow.getArea().getId(); }
    private static RbacException protectedFlow() { return RbacException.conflict("FLUJO_BASE_PROTEGIDO","La identidad y estructura del flujo base están protegidas."); }

    public FlujoResponse toResponse(FlujoDefinicion flow) {
        boolean manage = access != null ? access.canManageFlow(areaId(flow)) : true;
        boolean base = integrity != null ? integrity.isBase(flow) : Long.valueOf(1).equals(flow.getId());
        boolean complete = integrity != null ? integrity.complete(flow) : flow.isCompleto();
        List<FlujoEtapaResponse> stages=flow.getEtapas().stream().sorted(Comparator.comparingInt(FlujoEtapa::getOrden))
                .map(e->{
                    // Los revisores solo se exponen a quien gestiona el flujo (igual que revisorId antes de D-05).
                    List<FlujoEtapaResponse.Revisor> stageReviewers=manage
                            ? e.getRevisoresOrdenados().stream().map(FlujoConfigService::reviewerItem).toList()
                            : List.of();
                    FlujoEtapaResponse.Revisor first=stageReviewers.isEmpty()?null:stageReviewers.get(0);
                    Integer candidatesCount = reviewers != null ? reviewers.candidates(e).size() : null;
                    boolean hasCandidates = base || candidatesCount == null || candidatesCount > 0;
                    String modo = e.getModoRevisor() != null ? e.getModoRevisor().name() : ModoRevisor.LISTA.name();
                    return new FlujoEtapaResponse(e.getId(),e.getOrden(),e.getNombre(),first==null?null:first.id(),
                            first==null?null:first.nombre(),first==null?null:first.email(),e.getTipoAccion(),
                            e.getTipoAsignacion(),
                            hasCandidates,
                            manage && !base?candidatesCount:null,
                            modo,
                            stageReviewers, null, e.getCriterioIa());
                }).toList();
        return new FlujoResponse(flow.getId(),flow.getNombre(),flow.getDescripcion(),areaId(flow),
                flow.getArea()==null?null:flow.getArea().getNombre(),flow.isActivo(),complete,stages,
                flow.getCreatedAt(),flow.getUpdatedAt(),flow.getVersion(),
                manage && !Long.valueOf(1).equals(flow.getId()) && requests != null && !requests.existsByFlujoDefinicion_Id(flow.getId()),
                flow.getNumeroVersion());
    }

    static FlujoEtapaResponse.Revisor reviewerItem(UserAccount user) {
        String name=(Objects.toString(user.getFirstName(),"") + " " + Objects.toString(user.getLastName(),"")).trim();
        String display=name.isEmpty()?user.getEmail():name;
        return new FlujoEtapaResponse.Revisor(user.getId(),display,display,user.getEmail(),user.isEnabled());
    }

    public List<FlujoResponse> listarFlujosDisponibles() {
        UUID uid = access.context() != null ? access.context().usuarioId() : null;
        if (uid == null) {
            return listarFlujos(null, true);
        }
        if (vFlujoDisponibleUsuarioRepository != null) {
            List<Long> ids = vFlujoDisponibleUsuarioRepository.findByUsuarioId(uid).stream()
                    .map(com.capstone.sistema.model.view.VFlujoDisponibleUsuario::getFlujoId)
                    .toList();
            if (ids.isEmpty()) {
                return List.of();
            }
            return definitions.findAllById(ids).stream()
                    .filter(FlujoDefinicion::isActivo)
                    .map(this::toResponse)
                    .toList();
        }
        return listarFlujos(null, true);
    }

    @Transactional
    public FlujoResponse crearNuevaVersion(Long id) {
        FlujoDefinicion flow = definitions.findById(id)
                .orElseThrow(() -> new FlujoNotFoundException("Flujo con id " + id + " no encontrado"));
        if (integrity.isBase(flow)) {
            throw protectedFlow();
        }
        access.manageFlow(areaId(flow));

        int nextVersion = (flow.getNumeroVersion() != null ? flow.getNumeroVersion() : 1) + 1;
        FlujoDefinicion newFlow = new FlujoDefinicion(flow.getNombre(), flow.getDescripcion(), flow.getArea());
        newFlow.setNumeroVersion(nextVersion);
        newFlow.setActivo(true);

        for (FlujoEtapa e : flow.getEtapas()) {
            FlujoEtapa newEtapa = new FlujoEtapa(newFlow, e.getOrden(), e.getNombre(), e.getModoRevisor());
            newEtapa.setRevisor(e.getRevisor());
            newEtapa.setCriterioIa(e.getCriterioIa());   // F6 (§6.5): la versión nueva hereda el criterio de IA
            if (e.getRevisores() != null) {
                newEtapa.getRevisores().addAll(e.getRevisores());
            }
            newFlow.getEtapas().add(newEtapa);
        }

        flow.setActivo(false);
        definitions.save(flow);
        FlujoDefinicion saved = definitions.saveAndFlush(newFlow);

        audit.registerUserManagementEvent("FLUJO_VERSION_CREADA",
                "Nueva versión v" + nextVersion + " creada para flujo " + flow.getNombre() + " (id=" + saved.getId() + ")");

        return toResponse(saved);
    }
}
