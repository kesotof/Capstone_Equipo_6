package com.capstone.sistema.flow.exception;

/** Conflicto de negocio en la definición de un flujo (409). {@code codigo} viaja en el body de error. */
public class FlujoConflictException extends RuntimeException {
    public static final String DEFAULT_CODE = "FLUJO_CONFLICTO";
    private final String codigo;

    public FlujoConflictException(String message) {
        this(DEFAULT_CODE, message);
    }

    public FlujoConflictException(String codigo, String message) {
        super(message);
        this.codigo = codigo != null && !codigo.isBlank() ? codigo : DEFAULT_CODE;
    }

    public String getCodigo() {
        return codigo;
    }
}
