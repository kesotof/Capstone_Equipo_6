package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.dto.DocumentSearchPageResponse;
import com.capstone.sistema.doc.repository.DocumentDownloadCapabilityRepository;
import com.capstone.sistema.doc.repository.DocumentSearchCatalogRepository;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.rbac.model.AccessContext;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocumentSearchServiceTest {

    @Mock
    private SolicitudRepository solicitudes;

    @Mock
    private DocumentoRepository documentos;

    @Mock
    private AreaRepository areas;

    @Mock
    private DocumentSearchCatalogRepository catalogo;

    @Mock
    private DocumentSearchQueryNormalizer normalizer;

    @Mock
    private RbacAccessService rbac;

    @Mock
    private DocumentDownloadCapabilityRepository downloadCapabilities;

    private DocumentSearchService service;
    private UUID userId;

    @BeforeEach
    void setUp() {
        service = new DocumentSearchService(solicitudes, documentos, areas, catalogo, normalizer, rbac,
                downloadCapabilities);
        userId = UUID.randomUUID();
    }

    @Test
    void searchIncluyeContadoresPorRelacion() {
        DocumentSearchCriteria filters = new DocumentSearchCriteria(null, null, null, null, null, null, false,
                0, 10, "createdAt", Sort.Direction.DESC, DocumentSearchCriteria.Relacion.TODAS, null);
        when(normalizer.normalize(any())).thenReturn(filters);

        AccessContext context = new AccessContext(userId, null, null, true, Set.of(), true,
                List.of(), List.of(), Map.of(), 0L, 0L);
        when(rbac.context()).thenReturn(context);

        Specification<Solicitud> visible = (root, query, cb) -> cb.conjunction();
        when(rbac.visible(any(Permiso.class))).thenReturn(visible);

        when(solicitudes.findAll(any(Specification.class), any(Pageable.class)))
                .thenReturn(new PageImpl<>(List.of(), PageRequest.of(0, 10), 0L));
        when(solicitudes.count(any(Specification.class))).thenReturn(0L);
        when(catalogo.lastDecisions(anyList(), eq(userId))).thenReturn(Map.of());
        when(downloadCapabilities.authorizedIds(anyList(), any(Specification.class))).thenReturn(Set.of());

        DocumentSearchPageResponse response = service.search(Map.of());

        assertThat(response.contenido()).isEmpty();
        assertThat(response.totalElementos()).isZero();
        assertThat(response.contadores()).isNotNull();
        assertThat(response.contadores().todas()).isZero();
        assertThat(response.contadores().creadas()).isZero();
        assertThat(response.contadores().revisadas()).isZero();
        assertThat(response.contadores().misAreas()).isZero();
    }
}
