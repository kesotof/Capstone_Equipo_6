package com.capstone.sistema.rbac.dto;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import com.capstone.sistema.rbac.model.Alcance;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public final class RbacDtos {
    private RbacDtos() {}
    public record Grant(@NotBlank String codigo, @NotEmpty List<@NotNull Alcance> alcances) {}
    public record RoleCreate(@NotBlank @Pattern(regexp = "^[A-Z][A-Z0-9_]{2,49}$") String codigo,
                             @NotBlank String nombre, String descripcion,
                             @NotNull List<@NotNull @Valid Grant> permisos) {}
    public record RoleUpdate(@NotBlank String nombre, String descripcion,
                             @NotNull List<@NotNull @Valid Grant> permisos, @NotNull @PositiveOrZero Long version) {}
    public record Status(@NotNull Boolean activo, @NotNull @PositiveOrZero Long version) {}
    public record Role(Long id, String codigo, String nombre, String descripcion, boolean activo, boolean sistema,
                       String asignacion, long version, List<Grant> permisos, Instant createdAt, Instant updatedAt) {}
    public record Permission(String codigo, String nombre, String descripcion, boolean reservado, Set<Alcance> alcancesPermitidos) {}
    public record AreaItem(Long id, String nombre) {}
    public record Reviewer(UUID id, String nombre, Long areaId, String areaNombre) {}
    public record ContextRole(Long id, String codigo, String nombre, String origen) {}
    public record Me(UUID usuarioId, Long areaId, String areaNombre, UUID jefaturaDirectaId, boolean administradorGlobal,
                     List<ContextRole> roles, List<AreaItem> areasAdministradas, List<Grant> permisos,
                     long versionAcceso, long versionPolitica) {
        public Me(UUID usuarioId, Long areaId, UUID jefaturaDirectaId, boolean administradorGlobal,
                  List<ContextRole> roles, List<AreaItem> areasAdministradas, List<Grant> permisos,
                  long versionAcceso, long versionPolitica) {
            this(usuarioId, areaId, null, jefaturaDirectaId, administradorGlobal, roles, areasAdministradas, permisos, versionAcceso, versionPolitica);
        }
    }
    public record Page<T>(List<T> contenido, int pagina, int tamanio, long totalElementos, long totalPaginas,
                          boolean primera, boolean ultima) {}

    // DTOs para v2 (/api/rbac/me?v=2) según Fase F4 / Sección 7.2
    public record AreaRef(Long id, String nombre) {}
    public record JefaturaItem(Long areaId, String nombre) {}
    public record RolItemV2(Long rolId, String codigo, String nombre, AreaRef area, String origen, Instant vigenteHasta) {}
    public record PermisoItemV2(String codigo, List<Long> areas) {}
    public record Capacidades(
            boolean puedeEmitir,
            boolean esRevisor,
            boolean emitir,
            boolean revisar,
            boolean administrarFlujos,
            boolean administrarAreas,
            boolean administrarUsuarios,
            boolean administrarTiposDocumento,
            boolean administrarPlantillas,
            boolean auditar
    ) {
        public Capacidades(boolean puedeEmitir, boolean esRevisor) {
            this(puedeEmitir, esRevisor, puedeEmitir, esRevisor, false, false, false, false, false, false);
        }
    }
    public record MeV2(
            UUID usuarioId,
            String nombre,
            AreaRef area,
            boolean administradorSistema,
            List<JefaturaItem> jefaturas,
            List<RolItemV2> roles,
            List<PermisoItemV2> permisos,
            Capacidades capacidades,
            String etiqueta,
            long versionAcceso,
            long versionPolitica
    ) {}

    // DTOs para Fase F5 / Sección 7.1
    public record PermissionDto(String codigo, String recurso, String accion, String nombre, String descripcion, String ambito, List<String> alcancesPermitidos) {
        public PermissionDto(String codigo, String recurso, String accion, String nombre, String descripcion, String ambito) {
            this(codigo, recurso, accion, nombre, descripcion, ambito,
                    "SOLO_GLOBAL".equalsIgnoreCase(ambito)
                            ? List.of("GLOBAL")
                            : List.of("PROPIO", "SUBORDINADOS", "AREA", "GLOBAL"));
        }
    }
    public record RoleDtoV5(
            Long id,
            String codigo,
            String nombre,
            String descripcion,
            boolean activo,
            boolean sistema,
            String asignacion,
            String ambito,
            boolean permisosBloqueados,
            long version,
            List<String> permisos,
            long asignacionesVigentes,
            Instant createdAt,
            Instant updatedAt
    ) {}
    public record RoleRef(Long id, String codigo, String nombre, String ambito, boolean sistema) {}
    public record MatrizRolPermiso(List<RoleRef> roles, List<PermissionDto> permisos, Map<String, List<String>> rolesPermisos) {}
    public record RolItemRef(Long id, String codigo, String nombre) {}
    public record OtorgadoPorRef(UUID id, String nombre, String email) {}
    public record AsignacionAccesoDto(Long id, RolItemRef rol, AreaRef area, Instant vigenteHasta, OtorgadoPorRef otorgadoPor, Instant createdAt) {}
    public record UserAccesosResponse(UUID usuarioId, String nombre, List<AsignacionAccesoDto> asignaciones, List<JefaturaItem> jefaturas, long versionAcceso) {}
    public record AsignarAccesoRequest(
            @NotNull Long rolId,
            Long areaId,
            Instant vigenteHasta,
            @NotNull @PositiveOrZero Long versionAcceso
    ) {}
    public record MotivoAcceso(String tipo, Long rolId, String rolCodigo, String rolNombre, Long areaAsignadaId, String areaAsignadaNombre) {}
    public record PermisoEfectivoItem(String permiso, boolean global, List<AreaRef> areas, List<MotivoAcceso> motivos) {}
    public record ResumenHechos(int revisorEtapasCount, boolean esJefatura, boolean puedeEmitir, int flujosDisponiblesCount) {}
    public record AccesoEfectivoResponse(UUID usuarioId, String nombre, List<PermisoEfectivoItem> permisos, ResumenHechos resumen) {}
    public record AreaJefaturasRequest(
            @NotNull List<@NotNull UUID> usuarioIds,
            @NotNull @PositiveOrZero Long version
    ) {}
    public record AreaAccesosResponse(Long areaId, String areaNombre, List<AsignacionAccesoDto> accesos) {}
}

