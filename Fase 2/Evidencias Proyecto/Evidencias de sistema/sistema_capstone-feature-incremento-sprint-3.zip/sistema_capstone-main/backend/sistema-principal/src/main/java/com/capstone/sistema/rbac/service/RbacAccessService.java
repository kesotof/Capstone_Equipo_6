package com.capstone.sistema.rbac.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.service.FlujoReviewerResolver;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.model.view.VAccesoDescarga;
import com.capstone.sistema.model.view.VAccesoDescargaRepository;
import com.capstone.sistema.model.view.VAccesoSolicitud;
import com.capstone.sistema.model.view.VAccesoSolicitudRepository;
import com.capstone.sistema.model.view.VPermisoEfectivo;
import com.capstone.sistema.model.view.VPermisoEfectivoRepository;
import com.capstone.sistema.rbac.dto.RbacDtos.*;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.AccessContext;
import com.capstone.sistema.rbac.model.Alcance;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.*;

/**
 * Servicio de acceso y autorización RBAC v5 según Fase F4.
 * Resuelve permisos a través de las vistas v5 (v_permiso_efectivo, v_acceso_solicitud, v_acceso_descarga),
 * manteniendo compatibilidad de contratos con clientes v1 mediante LegacyAccessTranslator.
 */
@Service
@Transactional(readOnly = true)
public class RbacAccessService {

    private static final String CACHE = RbacAccessService.class.getName();

    /**
     * Caché de {@link AccessContext} por usuario dentro de la petición web. Evita recalcular el perfil
     * RBAC completo (varias consultas SQL) cuando un mismo usuario se evalúa muchas veces en la misma
     * petición: {@code dependencyViolations()} y {@code assignee-options} lo hacen cientos de veces.
     * Fuera de una petición (tests, jobs) se calcula sin caché. {@link #clearContext()} limpia ambas.
     */
    private static final String CACHE_USUARIOS = RbacAccessService.class.getName() + ".USUARIOS";

    /**
     * Permisos base (v5 §3, fuente 1 "Ser colaborador") que /api/rbac/me?v=2 entrega a todo usuario activo.
     * Se expresan con los códigos que exige el frontend (rutas de App.jsx y llamadas a can(...)).
     * El alcance real son las solicitudes propias o vistas por hechos (participación/revisión): por eso se
     * publican con {@code areas: []} (ninguna área completa), nunca con {@code null} (toda la organización).
     * No incluye SOLICITUD.VER ni DASHBOARD.VER: son permisos de rol con alcance de área.
     * DOCUMENTO.DESCARGAR pertenece a "descargar es ver": el emisor descarga sus propios documentos
     * (US-24) y el revisor de la etapa actual descarga los de las solicitudes que revisa. El permiso
     * global solo habilita el botón; la autorización real sigue siendo por solicitud
     * ({@link #authorize(Object, Permiso)} contra {@code v_acceso_descarga}).
     */
    public static final List<String> PERMISOS_BASE_V2 = List.of(
            "SOLICITUD.CONSULTAR",
            "SOLICITUD_CONSULTAR",
            "HISTORIAL_CONSULTAR",
            "OBSERVACION_CONSULTAR",
            "METRICAS_CONSULTAR",
            "SOLICITUD_REENVIAR",
            "DOCUMENTO.DESCARGAR",
            "DOCUMENTO_DESCARGAR"
    );

    /** Equivalente de {@link #PERMISOS_BASE_V2} en el enum usado por {@link #require(Permiso)} (alcance PROPIAS). */
    private static final List<Permiso> PERMISOS_BASE = List.of(
            Permiso.SOLICITUD_CONSULTAR,
            Permiso.HISTORIAL_CONSULTAR,
            Permiso.OBSERVACION_CONSULTAR,
            Permiso.METRICAS_CONSULTAR,
            Permiso.SOLICITUD_REENVIAR,
            Permiso.DOCUMENTO_DESCARGAR
    );

    private final CurrentUserResolver resolver;
    private final JdbcTemplate jdbc;
    private final SolicitudRepository solicitudes;
    private final VPermisoEfectivoRepository vPermisoEfectivoRepository;
    private final VAccesoSolicitudRepository vAccesoSolicitudRepository;
    private final VAccesoDescargaRepository vAccesoDescargaRepository;
    private final LegacyAccessTranslator legacyAccessTranslator;
    private final AuditService auditService;

    public RbacAccessService(
            CurrentUserResolver resolver,
            JdbcTemplate jdbc,
            SolicitudRepository solicitudes,
            VPermisoEfectivoRepository vPermisoEfectivoRepository,
            VAccesoSolicitudRepository vAccesoSolicitudRepository,
            VAccesoDescargaRepository vAccesoDescargaRepository,
            LegacyAccessTranslator legacyAccessTranslator
    ) {
        this(resolver, jdbc, solicitudes, vPermisoEfectivoRepository, vAccesoSolicitudRepository, vAccesoDescargaRepository, legacyAccessTranslator, null);
    }

    @Autowired
    public RbacAccessService(
            CurrentUserResolver resolver,
            JdbcTemplate jdbc,
            SolicitudRepository solicitudes,
            VPermisoEfectivoRepository vPermisoEfectivoRepository,
            VAccesoSolicitudRepository vAccesoSolicitudRepository,
            VAccesoDescargaRepository vAccesoDescargaRepository,
            LegacyAccessTranslator legacyAccessTranslator,
            @Autowired(required = false) AuditService auditService
    ) {
        this.resolver = resolver;
        this.jdbc = jdbc;
        this.solicitudes = solicitudes;
        this.vPermisoEfectivoRepository = vPermisoEfectivoRepository;
        this.vAccesoSolicitudRepository = vAccesoSolicitudRepository;
        this.vAccesoDescargaRepository = vAccesoDescargaRepository;
        this.legacyAccessTranslator = legacyAccessTranslator;
        this.auditService = auditService;
    }

    public AccessContext context() {
        var attrs = RequestContextHolder.getRequestAttributes();
        if (attrs instanceof ServletRequestAttributes web) {
            Object existing = web.getRequest().getAttribute(CACHE);
            if (existing instanceof AccessContext context) return context;
            AccessContext context = forUser(resolver.resolveCurrentUser().orElseThrow(RbacException::denied));
            web.getRequest().setAttribute(CACHE, context);
            return context;
        }
        return forUser(resolver.resolveCurrentUser().orElseThrow(RbacException::denied));
    }

    public void clearContext() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes web) {
            web.getRequest().removeAttribute(CACHE);
            web.getRequest().removeAttribute(CACHE_USUARIOS);
        }
    }

    /**
     * Caché de contextos por usuario de la petición en curso, o {@code null} fuera de una petición web.
     * Con {@code createIfMissing} falso solo consulta (no crea el atributo si aún no existe).
     */
    @SuppressWarnings("unchecked")
    private Map<UUID, AccessContext> userContextCache(boolean createIfMissing) {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes web) {
            HttpServletRequest request = web.getRequest();
            Object existing = request.getAttribute(CACHE_USUARIOS);
            if (existing instanceof Map<?, ?> map) return (Map<UUID, AccessContext>) map;
            if (createIfMissing) {
                Map<UUID, AccessContext> created = new HashMap<>();
                request.setAttribute(CACHE_USUARIOS, created);
                return created;
            }
        }
        return null;
    }

    public Me me() {
        return legacyAccessTranslator.translate(meV2());
    }

    public MeV2 meV2() {
        return forUserV2(resolver.resolveCurrentUser().orElseThrow(RbacException::denied));
    }

    public boolean tienePermiso(UUID usuarioId, String recurso, String accion, Long areaId) {
        if (usuarioId == null || recurso == null || accion == null) {
            return false;
        }
        if (areaId == null) {
            return vPermisoEfectivoRepository.existsByUsuarioIdAndRecursoAndAccion(usuarioId, recurso, accion);
        }
        return vPermisoEfectivoRepository.existsByUsuarioIdAndRecursoAndAccionAndArea(usuarioId, recurso, accion, areaId);
    }

    public boolean tienePermisoGlobal(UUID usuarioId, String recurso, String accion) {
        if (usuarioId == null || recurso == null || accion == null) {
            return false;
        }
        return vPermisoEfectivoRepository.existsByUsuarioIdAndRecursoAndAccionGlobally(usuarioId, recurso, accion);
    }

    /**
     * Ids, entre los indicados, que tienen un rol ADMIN o ADMIN_SISTEMA vigente (misma regla que
     * {@link #forUserV2} usa para {@code administradorSistema}), en una sola consulta. Evita calcular el
     * perfil RBAC completo de cada candidato en {@code assignee-options}.
     */
    public Set<UUID> administradorSistemaIds(Collection<UUID> usuarioIds) {
        if (usuarioIds == null || usuarioIds.isEmpty()) return Set.of();
        String placeholders = String.join(",", usuarioIds.stream().map(id -> "?").toList());
        return new HashSet<>(jdbc.queryForList(
                "select distinct ur.usuario_id from usuario_rol ur join rol r on r.id=ur.rol_id " +
                "where r.codigo in ('ADMIN','ADMIN_SISTEMA') " +
                "and (ur.vigente_hasta is null or ur.vigente_hasta > now()) " +
                "and ur.usuario_id in (" + placeholders + ")",
                UUID.class, usuarioIds.toArray()));
    }

    public boolean puedeAccederSolicitud(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        return vAccesoSolicitudRepository.existsBySolicitudIdAndUsuarioId(solicitudId, usuarioId);
    }

    public boolean puedeDescargar(UUID usuarioId, UUID solicitudId) {
        if (usuarioId == null || solicitudId == null) {
            return false;
        }
        return vAccesoDescargaRepository.existsBySolicitudIdAndUsuarioId(solicitudId, usuarioId);
    }

    public List<VPermisoEfectivo> obtenerPermisosUsuario(UUID usuarioId) {
        if (usuarioId == null) {
            return List.of();
        }
        return vPermisoEfectivoRepository.findByUsuarioId(usuarioId);
    }

    public MeV2 forUserV2(UserAccount user) {
        Long areaId = user.getArea() != null ? user.getArea().getId() : null;
        String areaNombre = user.getArea() != null ? user.getArea().getNombre() : null;
        AreaRef areaRef = areaId != null ? new AreaRef(areaId, areaNombre) : null;

        // Jefaturas asignadas en tabla area_jefatura
        List<JefaturaItem> jefaturas = jdbc.query(
                "SELECT aj.area_id, a.nombre FROM area_jefatura aj " +
                "JOIN area a ON a.id = aj.area_id " +
                "WHERE aj.usuario_id = ? AND a.activo = true ORDER BY a.nombre",
                (rs, n) -> new JefaturaItem(rs.getLong("area_id"), rs.getString("nombre")),
                user.getId()
        );

        // Roles asignados en usuario_rol
        List<RolItemV2> rolesV2 = jdbc.query(
                "SELECT ur.id, r.id AS rol_id, r.codigo, r.nombre, ur.area_id, a.nombre AS area_nombre, r.asignacion, ur.vigente_hasta " +
                "FROM usuario_rol ur " +
                "JOIN rol r ON r.id = ur.rol_id " +
                "LEFT JOIN area a ON a.id = ur.area_id " +
                "WHERE ur.usuario_id = ? AND (ur.vigente_hasta IS NULL OR ur.vigente_hasta > now()) " +
                "ORDER BY r.codigo",
                (rs, n) -> {
                    Long rAreaId = rs.getObject("area_id") != null ? rs.getLong("area_id") : null;
                    String rAreaNombre = rs.getString("area_nombre");
                    AreaRef rArea = rAreaId != null ? new AreaRef(rAreaId, rAreaNombre) : null;
                    java.sql.Timestamp ts = rs.getTimestamp("vigente_hasta");
                    return new RolItemV2(
                            rs.getLong("rol_id"),
                            rs.getString("codigo"),
                            rs.getString("nombre"),
                            rArea,
                            rs.getString("asignacion"),
                            ts != null ? ts.toInstant() : null
                    );
                },
                user.getId()
        );

        boolean administradorSistema = rolesV2.stream().anyMatch(r -> "ADMIN".equalsIgnoreCase(r.codigo()) || "ADMIN_SISTEMA".equalsIgnoreCase(r.codigo()));

        // Permisos efectivos de la vista v_permiso_efectivo
        List<VPermisoEfectivo> permisosEfectivos = vPermisoEfectivoRepository.findByUsuarioId(user.getId());
        Map<String, Set<Long>> permisoAreasMap = new LinkedHashMap<>();
        Map<String, Boolean> permisoGlobalMap = new HashMap<>();

        for (VPermisoEfectivo pe : permisosEfectivos) {
            String code = pe.getRecurso().toUpperCase() + "." + pe.getAccion().toUpperCase();
            if (pe.getAreaId() == null || administradorSistema) {
                permisoGlobalMap.put(code, true);
            } else {
                permisoAreasMap.computeIfAbsent(code, k -> new LinkedHashSet<>()).add(pe.getAreaId());
            }
        }

        // Capacidades
        Integer flujosDisponibles = 0;
        try {
            flujosDisponibles = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM v_flujo_disponible_usuario WHERE usuario_id = ?", Integer.class, user.getId());
        } catch (Exception ignored) {
        }
        boolean puedeEmitir = administradorSistema || (areaId != null && flujosDisponibles != null && flujosDisponibles > 0);

        Integer revisorCount = 0;
        try {
            revisorCount = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM (" +
                    "  SELECT 1 FROM flujo_etapa_revisor WHERE usuario_id = ? " +
                    "  UNION ALL " +
                    "  SELECT 1 FROM area_jefatura WHERE usuario_id = ?" +
                    ") t", Integer.class, user.getId(), user.getId());
        } catch (Exception ignored) {
        }
        boolean esRevisor = administradorSistema || (revisorCount != null && revisorCount > 0);

        if (administradorSistema) {
            permisoGlobalMap.put("SOLICITUD.REVISAR", true);
            permisoGlobalMap.put("REVISION_CONSULTAR", true);
            permisoGlobalMap.put("SOLICITUD.CREAR", true);
            permisoGlobalMap.put("SOLICITUD_CREAR", true);
            permisoGlobalMap.put("SOLICITUD.CONSULTAR", true);
        }
        if (esRevisor) {
            // Bandeja de revisión: solo revisores de alguna etapa o jefaturas (la consulta va por permisos base)
            permisoGlobalMap.put("SOLICITUD.REVISAR", true);
            permisoGlobalMap.put("REVISION_CONSULTAR", true);
        }
        if (puedeEmitir && !permisoAreasMap.containsKey("SOLICITUD.CREAR")) {
            permisoGlobalMap.put("SOLICITUD.CREAR", true);
            permisoGlobalMap.put("SOLICITUD_CREAR", true);
        }

        List<PermisoItemV2> permisosV2 = new ArrayList<>();
        for (String code : permisoGlobalMap.keySet()) {
            permisosV2.add(new PermisoItemV2(code, null));
        }
        for (Map.Entry<String, Set<Long>> entry : permisoAreasMap.entrySet()) {
            if (!permisoGlobalMap.containsKey(entry.getKey())) {
                permisosV2.add(new PermisoItemV2(entry.getKey(), new ArrayList<>(entry.getValue())));
            }
        }
        // Permisos base de todo usuario activo (propias / por hechos): areas = [] (ninguna área completa)
        if (user.isEnabled()) {
            for (String code : PERMISOS_BASE_V2) {
                if (!permisoGlobalMap.containsKey(code) && !permisoAreasMap.containsKey(code)) {
                    permisosV2.add(new PermisoItemV2(code, List.of()));
                }
            }
        }

        Capacidades capacidades = new Capacidades(
                puedeEmitir,
                esRevisor,
                puedeEmitir,
                esRevisor,
                administradorSistema || permisoGlobalMap.containsKey("FLUJO.GESTIONAR"),
                administradorSistema || permisoGlobalMap.containsKey("AREA.GESTIONAR"),
                administradorSistema || permisoGlobalMap.containsKey("USUARIO.GESTIONAR"),
                administradorSistema || permisoGlobalMap.containsKey("TIPO_DOCUMENTO.GESTIONAR") || permisoGlobalMap.containsKey("SLA.GESTIONAR"),
                administradorSistema || permisoGlobalMap.containsKey("PLANTILLA.CREAR"),
                administradorSistema || permisoGlobalMap.containsKey("AUDITORIA.VER")
        );

        // Etiqueta visual
        String etiqueta;
        if (administradorSistema) {
            etiqueta = "Administrador del sistema";
        } else if (!jefaturas.isEmpty()) {
            etiqueta = "Jefatura · " + jefaturas.get(0).nombre();
        } else if (!rolesV2.isEmpty()) {
            RolItemV2 topRole = rolesV2.get(0);
            etiqueta = topRole.nombre() + (areaNombre != null ? " · " + areaNombre : "");
        } else {
            etiqueta = "Colaborador · " + (areaNombre != null ? areaNombre : "Sin área");
        }

        Long versionPolitica = 1L;
        try {
            Long vp = jdbc.queryForObject("SELECT version FROM control_politica WHERE id = 1", Long.class);
            if (vp != null) versionPolitica = vp;
        } catch (Exception ignored) {
        }

        long versionAcceso = user.getLockVersion();

        return new MeV2(
                user.getId(),
                user.getNombreCompleto() != null ? user.getNombreCompleto() : user.getEmail(),
                areaRef,
                administradorSistema,
                jefaturas,
                rolesV2,
                permisosV2,
                capacidades,
                etiqueta,
                versionAcceso,
                versionPolitica
        );
    }

    public AccessContext forUser(UserAccount user) {
        Map<UUID, AccessContext> cache = user.getId() == null ? null : userContextCache(true);
        if (cache != null) {
            AccessContext cached = cache.get(user.getId());
            if (cached != null) return cached;
        }
        AccessContext context = computeForUser(user);
        if (cache != null) cache.put(user.getId(), context);
        return context;
    }

    private AccessContext computeForUser(UserAccount user) {
        MeV2 v2 = forUserV2(user);
        Me legacy = legacyAccessTranslator.translate(v2);

        Map<Permiso, Set<Alcance>> permisosMap = new EnumMap<>(Permiso.class);
        for (Grant g : legacy.permisos()) {
            try {
                Permiso p = Permiso.valueOf(g.codigo());
                permisosMap.put(p, new HashSet<>(g.alcances()));
            } catch (Exception ignored) {
            }
        }
        // Coherencia con /api/rbac/me?v=2: los permisos base valen para require(...) con alcance PROPIAS
        if (user.isEnabled()) {
            for (Permiso base : PERMISOS_BASE) {
                permisosMap.computeIfAbsent(base, k -> new HashSet<>()).add(Alcance.PROPIAS);
            }
        }

        return new AccessContext(
                v2.usuarioId(),
                v2.area() != null ? v2.area().id() : null,
                v2.area() != null ? v2.area().nombre() : null,
                null,
                v2.administradorSistema(),
                Set.of(),
                true,
                legacy.roles(),
                legacy.areasAdministradas(),
                permisosMap,
                v2.versionAcceso(),
                v2.versionPolitica()
        );
    }

    public void require(Permiso permission) {
        if (!context().has(permission)) throw RbacException.denied();
    }

    /** Exige al menos uno de los permisos indicados (403 RBAC_ACCION_DENEGADA si no tiene ninguno). */
    public void requireAny(Permiso... permissions) {
        AccessContext c = context();
        if (c.admin()) return;
        for (Permiso p : permissions) {
            if (c.has(p)) return;
        }
        throw RbacException.denied();
    }

    /**
     * Permite la operación si el usuario actual es {@code usuarioId}; si no, exige alguno de los permisos.
     */
    public void requireSelfOrAny(UUID usuarioId, Permiso... permissions) {
        AccessContext c = context();
        if (usuarioId != null && usuarioId.equals(c.usuarioId())) return;
        requireAny(permissions);
    }

    public Specification<Solicitud> visible(Permiso permission) {
        return visible(context(), permission);
    }

    public Specification<Solicitud> visible(AccessContext c, Permiso permission) {
        return visible(c, permission, null);
    }

    public Specification<Solicitud> visible(AccessContext c, Permiso permission, FlujoEtapa targetStage) {
        if (c.admin()) {
            return (root, query, cb) -> cb.conjunction();
        }

        UUID usuarioId = c.usuarioId();
        return (root, query, cb) -> {
            Subquery<UUID> sub = query.subquery(UUID.class);
            if (permission == Permiso.DOCUMENTO_DESCARGAR) {
                Root<VAccesoDescarga> acc = sub.from(VAccesoDescarga.class);
                sub.select(acc.get("solicitudId")).where(cb.equal(acc.get("usuarioId"), usuarioId));
            } else {
                Root<VAccesoSolicitud> acc = sub.from(VAccesoSolicitud.class);
                sub.select(acc.get("solicitudId")).where(cb.equal(acc.get("usuarioId"), usuarioId));
            }
            return root.get("id").in(sub);
        };
    }

    public static boolean isDecision(Permiso p) {
        return p == Permiso.SOLICITUD_APROBAR || p == Permiso.SOLICITUD_RECHAZAR || p == Permiso.SOLICITUD_PEDIR_CORRECCION;
    }

    public boolean can(UUID id, Permiso permission) {
        if (id == null) return false;
        AccessContext c = context();
        // Reenviar (CORREGIR) es exclusivo del emisor, también para el admin (invariante CB011 en BD).
        if (permission == Permiso.SOLICITUD_REENVIAR) return esEmisor(id, c.usuarioId());
        // US-37: el administrador global puede ejecutar cualquier otra acción, incluidas las decisiones.
        if (c.admin()) return true;

        if (permission == Permiso.DOCUMENTO_DESCARGAR) {
            return puedeDescargar(c.usuarioId(), id);
        }
        // R23: solo el revisor asignado de la etapa actual decide (mismo criterio que el trigger CB012).
        if (isDecision(permission)) {
            return puedeAccederSolicitud(c.usuarioId(), id) && esRevisorEtapaActual(id, c.usuarioId());
        }
        return puedeAccederSolicitud(c.usuarioId(), id);
    }

    /** true si el usuario es revisor asignado de la etapa actual de la solicitud (función SQL es_revisor). */
    public boolean esRevisorEtapaActual(UUID solicitudId, UUID usuarioId) {
        if (solicitudId == null || usuarioId == null || jdbc == null) return false;
        List<Boolean> r = jdbc.query(
                "select coalesce(es_revisor(s.id, s.flujo_etapa_id, ?), false) from solicitud s where s.id = ?",
                (rs, i) -> rs.getBoolean(1), usuarioId, solicitudId);
        return r != null && !r.isEmpty() && Boolean.TRUE.equals(r.get(0));
    }

    /** true si el usuario es el emisor de la solicitud. */
    public boolean esEmisor(UUID solicitudId, UUID usuarioId) {
        if (solicitudId == null || usuarioId == null) return false;
        return solicitudes.findById(solicitudId)
                .map(s -> s.getEmisor() != null && usuarioId.equals(s.getEmisor().getId()))
                .orElse(false);
    }

    /** Usuarios revisores asignados a la etapa actual de la solicitud. */
    public List<UUID> revisoresEtapaActual(UUID solicitudId) {
        if (solicitudId == null || jdbc == null) return List.of();
        List<UUID> r = jdbc.query(
                "select distinct rs.usuario_id from v_revisor_solicitud rs join solicitud s " +
                "on s.id = rs.solicitud_id and s.flujo_etapa_id = rs.flujo_etapa_id where s.id = ?",
                (rs, i) -> rs.getObject(1, UUID.class), solicitudId);
        return r == null ? List.of() : r;
    }

    /** Nombres completos de los revisores asignados a la etapa actual (para el diálogo de US-37). */
    public List<String> nombresRevisoresEtapaActual(UUID solicitudId) {
        if (solicitudId == null || jdbc == null) return List.of();
        List<String> r = jdbc.query(
                "select distinct u.nombre || ' ' || u.apellido as nombre from v_revisor_solicitud rs " +
                "join solicitud s on s.id = rs.solicitud_id and s.flujo_etapa_id = rs.flujo_etapa_id " +
                "join usuario u on u.id = rs.usuario_id where s.id = ? order by nombre",
                (rs, i) -> rs.getString(1), solicitudId);
        return r == null ? List.of() : r;
    }

    public Solicitud readable(UUID id) {
        return solicitudes.findOne(visible(Permiso.SOLICITUD_CONSULTAR).and((r, q, b) -> b.equal(r.get("id"), id)))
                .orElseThrow(RbacException::missing);
    }

    public Solicitud authorize(UUID id, Permiso permission) {
        Solicitud request = readable(id);
        if (!can(id, permission)) {
            if (permission == Permiso.DOCUMENTO_DESCARGAR) {
                if (auditService != null) {
                    auditService.registerAuditEvent(
                            "ACCESO_DENEGADO",
                            "solicitud",
                            id.toString(),
                            "DENEGADO",
                            "{\"solicitudId\":\"" + id + "\",\"codigo\":\"DOCUMENTO_DESCARGA_DENEGADA\"}"
                    );
                }
                throw new RbacException(HttpStatus.FORBIDDEN, "DOCUMENTO_DESCARGA_DENEGADA", "No tiene autorización para descargar documentos de esta solicitud.");
            }
            if (isDecision(permission)) {
                throw new RbacException(HttpStatus.FORBIDDEN, "REVISOR_NO_ASIGNADO",
                        "El usuario no tiene atribuciones válidas de revisor para ejecutar esta acción en la etapa actual.");
            }
            if (permission == Permiso.SOLICITUD_REENVIAR) {
                throw new RbacException(HttpStatus.FORBIDDEN, "SOLO_EMISOR_REENVIA",
                        "Solo el emisor original puede reenviar la solicitud corregida");
            }
            throw RbacException.denied();
        }
        return request;
    }

    public void manageFlow(Long areaId) {
        AccessContext c = context();
        if (c.admin()) return;
        if (!c.has(Permiso.FLUJO_GESTIONAR)) throw RbacException.denied();
        if (areaId != null && !c.managedAreas().contains(areaId)) throw RbacException.denied();
    }

    public boolean canManageFlow(Long areaId) {
        try {
            manageFlow(areaId);
            return true;
        } catch (RbacException e) {
            return false;
        }
    }

    public boolean canEmitFlow(FlujoDefinicion flow) {
        if (flow == null || !flow.isActivo()) return false;
        AccessContext c = context();
        if (c.admin()) return true;
        if (c.areaId() == null) return false;
        if (flow.getId() != null && flow.getId() == 1L) return true; // Flujo base
        return flow.getArea() != null && flow.getArea().isActivo() && c.areaId().equals(flow.getArea().getId());
    }

    public boolean eligibleReviewer(UserAccount user) {
        return user != null && user.isEnabled();
    }

    public void requireFlowEmissionScope(FlujoDefinicion flow) {
        if (!canEmitFlow(flow)) throw RbacException.denied();
    }

    public boolean canOperateAtStage(UserAccount user, Solicitud request, FlujoEtapa stage) {
        return canOperateAtStage(user, request, stage, null, null);
    }

    /**
     * Variante con los revisores de la etapa precargados: si {@code revisoresEtapa} no es {@code null} no
     * se consulta FLUJO_ETAPA_REVISOR por cada usuario (evita una consulta por candidato × solicitud).
     */
    public boolean canOperateAtStage(UserAccount user, Solicitud request, FlujoEtapa stage, Set<UUID> revisoresEtapa) {
        return canOperateAtStage(user, request, stage, revisoresEtapa, null);
    }

    /**
     * Variante con revisores de etapa y el conjunto de usuarios con acceso a la solicitud precargados.
     * Con {@code usuariosConAcceso} no nulo no se consulta la vista v_acceso_solicitud (evita una consulta
     * por candidato × solicitud cuando quien invoca ya conoce los pares (solicitud, usuario) con acceso).
     */
    public boolean canOperateAtStage(UserAccount user, Solicitud request, FlujoEtapa stage,
            Set<UUID> revisoresEtapa, Set<UUID> usuariosConAcceso) {
        if (user == null || !user.isEnabled() || request == null || stage == null) return false;
        if (request.getFlujoDefinicion() != null && stage.getFlujoDefinicion() != null
                && !Objects.equals(request.getFlujoDefinicion().getId(), stage.getFlujoDefinicion().getId())) {
            return false;
        }

        // Comprobaciones baratas (sin AccessContext): revisor configurado, revisor de la etapa o flujo base.
        // Son disyuntivas con el resto de la regla, así que el resultado no cambia al evaluarlas primero.
        if (stage.getId() != null && revisoresEtapa != null && revisoresEtapa.contains(user.getId())) return true;
        if (stage.getRevisor() != null && user.getId().equals(stage.getRevisor().getId())) return true;
        if (FlujoReviewerResolver.isDynamicBase(stage)) return true;

        // A partir de aquí hace falta el contexto (administrador global) o consultar la etapa.
        AccessContext c = forUser(user);
        if (c.admin()) {
            return true;
        }

        if (stage.getId() != null && revisoresEtapa == null) {
            try {
                Integer count = jdbc.queryForObject(
                        "SELECT count(*) FROM flujo_etapa_revisor WHERE flujo_etapa_id = ? AND usuario_id = ?",
                        Integer.class, stage.getId(), user.getId()
                );
                if (count != null && count > 0) {
                    return true;
                }
            } catch (Exception ignored) {
            }
        }

        if (request.getFlujoEtapa() != null && Objects.equals(request.getFlujoEtapa().getId(), stage.getId())) {
            return usuariosConAcceso != null
                    ? usuariosConAcceso.contains(user.getId())
                    : puedeAccederSolicitud(user.getId(), request.getId());
        }
        return false;
    }

    /** Revisores configurados de una etapa persistida (una consulta reutilizable por varios candidatos). */
    public Set<UUID> stageReviewerIds(FlujoEtapa stage) {
        if (stage == null || stage.getId() == null) return Set.of();
        return new HashSet<>(jdbc.queryForList(
                "SELECT usuario_id FROM flujo_etapa_revisor WHERE flujo_etapa_id = ?", UUID.class, stage.getId()));
    }

    public boolean canRead(UserAccount user, UUID requestId) {
        if (user == null || !user.isEnabled() || requestId == null) return false;
        AccessContext c = forUser(user);
        if (c.admin()) return true;
        return puedeAccederSolicitud(user.getId(), requestId);
    }
}
