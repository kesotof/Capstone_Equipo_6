package com.capstone.sistema.ia.service;

import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.MensajeriaProperties;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Instant;
import java.util.List;

/**
 * F6 (§6.10) + C4: re-publicador de tareas de IA pendientes sin respuesta.
 * Ejecuta cada {@code mensajeria.republicador.intervalo} con advisory lock (41030, 4) dentro de {@link TransactionTemplate}.
 * Si supera {@code max-publicaciones}, marca la tarea como FALLIDA con código {@code SIN_RESPUESTA}.
 */
@Component
@ConditionalOnProperty(prefix = "app.scheduling", name = "enabled", havingValue = "true")
public class RepublicadorIaPendientes {

    private static final Logger log = LoggerFactory.getLogger(RepublicadorIaPendientes.class);
    private static final int LOTE_MAXIMO = 100;

    private final IaTareaRepository iaTareaRepository;
    private final IaComandoFactory comandoFactory;
    private final MensajePublicador publicador;
    private final MensajeriaProperties propiedades;
    private final TransactionTemplate transactionTemplate;

    public RepublicadorIaPendientes(
            IaTareaRepository iaTareaRepository,
            IaComandoFactory comandoFactory,
            MensajePublicador publicador,
            MensajeriaProperties propiedades,
            TransactionTemplate transactionTemplate
    ) {
        this.iaTareaRepository = iaTareaRepository;
        this.comandoFactory = comandoFactory;
        this.publicador = publicador;
        this.propiedades = propiedades;
        this.transactionTemplate = transactionTemplate;
    }

    @Scheduled(fixedDelayString = "${mensajeria.republicador.intervalo:PT2M}")
    public void programado() {
        Integer republicados = transactionTemplate.execute(status -> republicar());
        if (republicados != null && republicados > 0) {
            log.info("Re-publicador de IA: {} comando(s) re-publicado(s)", republicados);
        }
    }

    public int republicar() {
        Boolean lock = iaTareaRepository.tryAdvisoryLockRepublicacion();
        if (!Boolean.TRUE.equals(lock)) {
            return 0;
        }

        Instant umbral = Instant.now().minus(propiedades.republicador().umbralIa());
        List<IaTarea> pendientes = iaTareaRepository.pendientesDeRepublicacion(umbral, LOTE_MAXIMO);
        int republicados = 0;
        int maxPublicaciones = propiedades.republicador().maxPublicaciones();

        for (IaTarea tarea : pendientes) {
            if (tarea.getPublicaciones() >= maxPublicaciones) {
                tarea.fallar("SIN_RESPUESTA",
                        "No se recibió respuesta del servicio de IA tras " + maxPublicaciones + " publicaciones");
                iaTareaRepository.save(tarea);
                log.warn("Tarea de IA {} agotó las {} publicaciones → FALLIDA SIN_RESPUESTA",
                        tarea.getId(), maxPublicaciones);
                continue;
            }

            tarea.republicar(Instant.now());
            iaTareaRepository.save(tarea);
            try {
                ComandoTareaIa comando = comandoFactory.crearComando(tarea);
                publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_IA_EJECUTAR, comando, comando.mensajeId());
                republicados++;
            } catch (Exception e) {
                log.warn("Error al re-publicar comando de tarea IA {}: {}", tarea.getId(), e.getMessage());
            }
        }
        return republicados;
    }
}
