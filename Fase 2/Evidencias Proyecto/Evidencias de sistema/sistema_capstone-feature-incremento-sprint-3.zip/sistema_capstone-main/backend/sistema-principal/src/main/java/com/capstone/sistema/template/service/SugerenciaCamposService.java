package com.capstone.sistema.template.service;

import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.template.dto.PlantillaDtos.SugerenciasCamposDto;
import com.capstone.sistema.template.render.DocxVista;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sugerencias de la IA sobre qué textos de un Word convertir en campos de la plantilla. Es una tarea asíncrona:
 * se envía el texto del documento a service-ia y su respuesta llega por ai.fields.result.
 * shortcut: el estado vive en memoria (una sola instancia; al reiniciar se pierde y la vista deja de esperar a los
 * 3 minutos). Pasarlo a una tabla si el sistema principal corre en más de una instancia.
 */
@Service
public class SugerenciaCamposService {

    private static final Logger log = LoggerFactory.getLogger(SugerenciaCamposService.class);
    private static final Duration VIGENCIA = Duration.ofMinutes(15);

    private record Tarea(UUID usuarioId, SugerenciasCamposDto estado) {}

    private final Map<UUID, Tarea> tareas = new ConcurrentHashMap<>();
    private final DocxVista docxVista;
    private final RabbitTemplate rabbitTemplate;
    private final PlantillaService plantillaService;

    public SugerenciaCamposService(DocxVista docxVista, RabbitTemplate rabbitTemplate, PlantillaService plantillaService) {
        this.docxVista = docxVista;
        this.rabbitTemplate = rabbitTemplate;
        this.plantillaService = plantillaService;
    }

    /** {@code existentes}: etiquetas de los campos que la plantilla ya tiene, para que la IA no los repita. */
    public SugerenciasCamposDto solicitar(MultipartFile file, List<String> existentes, UserAccount actor) {
        plantillaService.validarPermisoConfigurar(actor);
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Suba el documento Word (.docx) de la plantilla.");
        }
        String texto;
        try {
            texto = docxVista.texto(file.getBytes());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible leer el documento Word: " + e.getMessage());
        }
        if (texto.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El documento no tiene texto para analizar.");
        }

        Instant ahora = Instant.now();
        tareas.values().removeIf(t -> t.estado().createdAt().isBefore(ahora.minus(VIGENCIA)));
        UUID id = UUID.randomUUID();
        SugerenciasCamposDto pendiente = new SugerenciasCamposDto(id, "PENDIENTE", List.of(), null, null, ahora);
        tareas.put(id, new Tarea(actor.getId(), pendiente));
        try {
            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_FIELDS_ROUTING_KEY,
                    Map.of("sugerenciaId", id.toString(), "texto", texto, "existentes", existentes == null ? List.of() : existentes));
        } catch (AmqpException e) {
            tareas.remove(id);
            log.error("No se pudo encolar la sugerencia de campos: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "El servicio de IA no está disponible. Intente nuevamente.");
        }
        return pendiente;
    }

    public SugerenciasCamposDto obtener(UUID id, UserAccount actor) {
        Tarea tarea = tareas.get(id);
        if (tarea == null || actor == null || !tarea.usuarioId().equals(actor.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "La sugerencia no existe o ya expiró.");
        }
        return tarea.estado();
    }

    public void registrarResultado(Map<String, Object> resultado) {
        UUID id;
        try {
            id = UUID.fromString(String.valueOf(resultado.get("sugerenciaId")));
        } catch (IllegalArgumentException e) {
            log.warn("Resultado de sugerencia de campos sin id válido: {}", resultado.get("sugerenciaId"));
            return;
        }
        String estado = "COMPLETADO".equals(resultado.get("status")) ? "COMPLETADO" : "ERROR";
        List<?> sugerencias = resultado.get("sugerencias") instanceof List<?> lista ? lista : List.of();
        tareas.computeIfPresent(id, (clave, tarea) -> new Tarea(tarea.usuarioId(), new SugerenciasCamposDto(id, estado, sugerencias,
                (String) resultado.get("modelo"), (String) resultado.get("mensaje"), tarea.estado().createdAt())));
    }
}
