package com.capstone.sistema.doc.model;

import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Documento adjunto a una solicitud, separado del documento vigente y sus versiones. */
@Entity
@Table(name = "solicitud_anexo")
@Immutable
public class SolicitudAnexo {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false, updatable = false)
    private Solicitud solicitud;

    @Column(name = "nombre_archivo", nullable = false, length = 255, updatable = false)
    private String nombreArchivo;

    @Column(name = "content_type", nullable = false, length = 100, updatable = false)
    private String contentType;

    @Column(name = "storage_key", nullable = false, unique = true, length = 500, updatable = false)
    private String storageKey;

    @Column(name = "size_bytes", nullable = false, updatable = false)
    private Long sizeBytes;

    @Column(name = "checksum_sha256", nullable = false, length = 64, updatable = false)
    private String checksumSha256;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subido_por", nullable = false, updatable = false)
    private UserAccount subidoPor;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected SolicitudAnexo() {
    }

    public SolicitudAnexo(Solicitud solicitud, String nombreArchivo, String contentType, String storageKey,
                          Long sizeBytes, String checksumSha256, UserAccount subidoPor) {
        this.solicitud = solicitud;
        this.nombreArchivo = nombreArchivo;
        this.contentType = contentType;
        this.storageKey = storageKey;
        this.sizeBytes = sizeBytes;
        this.checksumSha256 = checksumSha256;
        this.subidoPor = subidoPor;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getContentType() {
        return contentType;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public Long getSizeBytes() {
        return sizeBytes;
    }

    public String getChecksumSha256() {
        return checksumSha256;
    }

    public UserAccount getSubidoPor() {
        return subidoPor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        return id != null && Objects.equals(id, ((SolicitudAnexo) o).id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(storageKey);
    }
}
