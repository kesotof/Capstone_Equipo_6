package com.capstone.sistema.flow.service;

import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.model.enums.ModoRevisor;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class FlujoIntegrityServiceTest {

    @Mock
    private FlujoReviewerResolver reviewers;

    private static FlujoDefinicion flow(Long id) {
        FlujoDefinicion flow = new FlujoDefinicion("Contratos", "Flujo de prueba");
        ReflectionTestUtils.setField(flow, "id", id);
        return flow;
    }

    private static UserAccount usuario(String email) {
        UserAccount u = new UserAccount("kc-" + email, email, "Nom", "Ape", true);
        u.setId(UUID.randomUUID());
        return u;
    }

    @Test
    void requireExecutableSinEtapasLanzaFlujoIncompleto() {
        FlujoDefinicion flow = flow(9L);
        FlujoIntegrityService service = new FlujoIntegrityService(reviewers);

        assertThatThrownBy(() -> service.requireExecutable(flow, true))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("FLUJO_INCOMPLETO"))
                .hasMessageContaining("al menos una etapa");
    }

    @Test
    void requireExecutableFlujoInactivoLanzaFlujoInactivo() {
        FlujoDefinicion flow = flow(9L);
        flow.getEtapas().add(new FlujoEtapa(flow, 1, "Revisión", ModoRevisor.JEFATURA_AREA_SOLICITUD));
        flow.setActivo(false);
        FlujoIntegrityService service = new FlujoIntegrityService(reviewers);

        assertThatThrownBy(() -> service.requireExecutable(flow, true))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("FLUJO_INACTIVO"))
                .hasMessageContaining("deben estar activos");
    }

    @Test
    void requireExecutableEtapaSinRevisoresActivosLanzaFlujoEtapaHuerfana() {
        FlujoDefinicion flow = flow(9L);
        flow.getEtapas().add(new FlujoEtapa(flow, 1, "Revisión", usuario("revisor@capstone.local")));
        doThrow(FlujoReviewerResolver.orphan("La etapa no tiene revisores activos disponibles."))
                .when(reviewers).requireAvailable(any());
        FlujoIntegrityService service = new FlujoIntegrityService(reviewers);

        assertThatThrownBy(() -> service.requireExecutable(flow, false))
                .isInstanceOf(RbacException.class)
                .satisfies(ex -> assertThat(((RbacException) ex).codigo()).isEqualTo("FLUJO_ETAPA_HUERFANA"));
    }
}
