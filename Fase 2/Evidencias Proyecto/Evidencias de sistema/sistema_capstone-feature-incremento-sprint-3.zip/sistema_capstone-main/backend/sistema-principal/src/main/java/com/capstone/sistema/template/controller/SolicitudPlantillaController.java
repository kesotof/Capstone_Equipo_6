package com.capstone.sistema.template.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.flow.dto.CrearSolicitudResponse;
import com.capstone.sistema.flow.dto.EtapaSolicitudResponse;
import com.capstone.sistema.flow.dto.SolicitudResponse;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.template.dto.PlantillaDtos.CorregirSolicitudDesdePlantillaRequest;
import com.capstone.sistema.template.dto.PlantillaDtos.CrearSolicitudDesdePlantillaRequest;
import com.capstone.sistema.template.service.GeneracionDesdePlantillaService;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Tag(name = "Solicitudes desde Plantilla", description = "Emisión y corrección de solicitudes generadas a partir de plantillas DOCX")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/solicitudes")
public class SolicitudPlantillaController {

    private final GeneracionDesdePlantillaService generacionService;
    private final CurrentUserResolver currentUserResolver;
    private final ObjectMapper objectMapper;

    public SolicitudPlantillaController(
            GeneracionDesdePlantillaService generacionService,
            CurrentUserResolver currentUserResolver,
            ObjectMapper objectMapper
    ) {
        this.generacionService = generacionService;
        this.currentUserResolver = currentUserResolver;
        this.objectMapper = objectMapper;
    }

    @Operation(summary = "Crear nueva solicitud a partir de una plantilla DOCX completada (sin documentos adjuntos)")
    @PostMapping(value = "/desde-plantilla", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CrearSolicitudResponse> crearDesdePlantilla(
            @RequestBody CrearSolicitudDesdePlantillaRequest request
    ) {
        return crear(request, List.of());
    }

    @Operation(summary = "Crear nueva solicitud a partir de una plantilla DOCX completada, con documentos adjuntos")
    @PostMapping(value = "/desde-plantilla", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CrearSolicitudResponse> crearDesdePlantillaConAnexos(
            @RequestParam("plantillaId") Long plantillaId,
            @RequestParam(value = "plantillaVersion", required = false) Integer plantillaVersion,
            @RequestParam("flujoId") Long flujoId,
            @RequestParam("titulo") String titulo,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam("datos") String datosJson,
            @RequestParam(value = "anexos", required = false) List<MultipartFile> anexos
    ) {
        Map<String, Object> datos;
        try {
            datos = objectMapper.readValue(datosJson, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato JSON de los datos del formulario inválido.");
        }
        return crear(new CrearSolicitudDesdePlantillaRequest(plantillaId, plantillaVersion, flujoId, titulo, descripcion, datos), anexos);
    }

    private ResponseEntity<CrearSolicitudResponse> crear(CrearSolicitudDesdePlantillaRequest request, List<MultipartFile> anexos) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        Solicitud solicitud = generacionService.crearSolicitudDesdePlantilla(request, anexos, actor);

        CrearSolicitudResponse response = new CrearSolicitudResponse(
                solicitud.getId(),
                null,
                solicitud.getEstadoSolicitud().getCodigo(),
                "Solicitud registrada a partir de la plantilla y enviada a revisión.",
                solicitud.getCorrelativo(),
                solicitud.getDeadline()
        );

        return ResponseEntity.created(URI.create("/api/solicitudes/" + solicitud.getId())).body(response);
    }

    @Operation(summary = "Corregir solicitud generada desde plantilla con nuevos datos")
    @PostMapping("/{id}/corregir-desde-plantilla")
    public ResponseEntity<SolicitudResponse> corregirDesdePlantilla(
            @PathVariable UUID id,
            @RequestBody CorregirSolicitudDesdePlantillaRequest request
    ) {
        UserAccount actor = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        Solicitud solicitud = generacionService.corregirSolicitudDesdePlantilla(id, request, actor);

        SolicitudResponse response = new SolicitudResponse(
                solicitud.getId(),
                solicitud.getCorrelativo(),
                solicitud.getTitulo(),
                solicitud.getDescripcion(),
                solicitud.getEstadoSolicitud().getCodigo(),
                solicitud.getUsuario() != null ? solicitud.getUsuario().getId() : null,
                solicitud.getUsuario() != null ? solicitud.getUsuario().getNombre() : null,
                solicitud.getUsuario() != null ? solicitud.getUsuario().getEmail() : null,
                null,
                solicitud.getDeadline(),
                null,
                solicitud.getCreatedAt(),
                solicitud.getUpdatedAt(),
                java.util.List.of(),
                solicitud.getLockVersion(),
                EtapaSolicitudResponse.from(solicitud.getFlujoEtapa())
        );

        return ResponseEntity.ok(response);
    }
}
