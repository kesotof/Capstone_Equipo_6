package com.capstone.sistema.flow.model;

import com.capstone.sistema.doc.model.TipoDocumento;
import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.Version;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "solicitud", indexes = {
        @Index(name = "idx_solicitud_emisor", columnList = "usuario_id"),
        @Index(name = "idx_solicitud_area", columnList = "area_id, estado"),
        @Index(name = "idx_solicitud_estado", columnList = "estado"),
        @Index(name = "idx_solicitud_deadline", columnList = "deadline"),
        @Index(name = "idx_solicitud_tipodoc", columnList = "tipo_documento_id"),
        @Index(name = "idx_solicitud_flujo_etapa", columnList = "flujo_definicion_id, flujo_etapa_id"),
        @Index(name = "idx_solicitud_etapa", columnList = "flujo_etapa_id")
})
public class Solicitud {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "correlativo", length = 30, unique = true, nullable = false, updatable = false)
    private String correlativo;

    @ManyToOne(fetch = FetchType.LAZY, optional = false, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "tipo_documento_id", nullable = false, updatable = false)
    private TipoDocumento tipoDocumento;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_definicion_id", nullable = false, updatable = false)
    private FlujoDefinicion flujoDefinicion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_etapa_id", nullable = false)
    private FlujoEtapa flujoEtapa;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false, updatable = false)
    private UserAccount usuario;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "area_id", nullable = false, updatable = false)
    private Area area;

    @Column(nullable = false, length = 255)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "estado", referencedColumnName = "codigo", nullable = false)
    private EstadoSolicitud estado;

    @Column(name = "deadline")
    private Instant deadline;

    @Version
    @Column(name = "lock_version", nullable = false)
    private Long lockVersion = 0L;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected Solicitud() {
    }

    public Solicitud(
            String correlativo,
            TipoDocumento tipoDocumento,
            FlujoDefinicion flujoDefinicion,
            FlujoEtapa flujoEtapa,
            UserAccount usuario,
            Area area,
            String titulo,
            String descripcion,
            EstadoSolicitud estado,
            Instant deadline
    ) {
        this.correlativo = correlativo;
        this.tipoDocumento = tipoDocumento;
        this.flujoDefinicion = flujoDefinicion;
        this.flujoEtapa = flujoEtapa;
        this.usuario = usuario;
        this.area = area;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.estado = estado;
        this.deadline = deadline;
    }

    // Constructor de conveniencia / retrocompatibilidad
    public Solicitud(
            FlujoDefinicion flujoDefinicion,
            UserAccount emisor,
            String titulo,
            String descripcion,
            EstadoSolicitud estadoSolicitud,
            FlujoEtapa flujoEtapa
    ) {
        this.flujoDefinicion = flujoDefinicion;
        this.usuario = emisor;
        this.area = emisor != null ? emisor.getArea() : (flujoDefinicion != null ? flujoDefinicion.getArea() : null);
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.estado = estadoSolicitud;
        this.flujoEtapa = flujoEtapa;
        this.correlativo = "PENDIENTE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (updatedAt == null) {
            updatedAt = createdAt;
        }
        if (correlativo == null || correlativo.isBlank()) {
            correlativo = "CORR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        }
        if (area == null && usuario != null) {
            area = usuario.getArea();
        }
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public String getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(String correlativo) {
        this.correlativo = correlativo;
    }

    public TipoDocumento getTipoDocumentoEntity() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public void setTipoDocumento(String nombre) {
        if (this.tipoDocumento == null) {
            this.tipoDocumento = new TipoDocumento(nombre, "DOC", 5);
        } else {
            this.tipoDocumento.setNombre(nombre);
        }
    }

    public void captureRegistration(Instant now) {
        this.createdAt = now;
        this.updatedAt = now;
    }

    public String getTipoDocumento() {
        return tipoDocumento != null ? tipoDocumento.getNombre() : null;
    }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public FlujoEtapa getFlujoEtapa() {
        return flujoEtapa;
    }

    public void setFlujoEtapa(FlujoEtapa flujoEtapa) {
        this.flujoEtapa = flujoEtapa;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public EstadoSolicitud getEstado() {
        return estado;
    }

    public void setEstado(EstadoSolicitud estado) {
        this.estado = estado;
    }

    public Instant getDeadline() {
        return deadline;
    }

    public void setDeadline(Instant deadline) {
        this.deadline = deadline;
    }

    public void touch() {
        this.updatedAt = Instant.now();
    }

    public Long getLockVersion() {
        return lockVersion;
    }

    public void setLockVersion(Long lockVersion) {
        this.lockVersion = lockVersion;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    // Shims de compatibilidad
    @Transient
    public UserAccount getEmisor() {
        return usuario;
    }

    public void setEmisor(UserAccount emisor) {
        this.usuario = emisor;
        if (this.area == null && emisor != null) {
            this.area = emisor.getArea();
        }
    }

    @Transient
    public EstadoSolicitud getEstadoSolicitud() {
        return estado;
    }

    public void setEstadoSolicitud(EstadoSolicitud estadoSolicitud) {
        this.estado = estadoSolicitud;
    }

    @Transient
    public Long getVersion() {
        return lockVersion;
    }

    public void setVersion(Long version) {
        this.lockVersion = version;
    }

    @Transient
    public Long getAreaOrigenId() {
        return area != null ? area.getId() : null;
    }

    @Transient
    public Long getAreaFlujoId() {
        return flujoDefinicion != null && flujoDefinicion.getArea() != null ? flujoDefinicion.getArea().getId() : null;
    }

    public void captureAreas(Long origen, Long flujo) {
        // no-op compatible
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Solicitud that = (Solicitud) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
