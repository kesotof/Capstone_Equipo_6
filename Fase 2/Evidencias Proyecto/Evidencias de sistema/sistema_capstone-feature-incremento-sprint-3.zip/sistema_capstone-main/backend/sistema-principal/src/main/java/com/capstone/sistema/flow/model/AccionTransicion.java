package com.capstone.sistema.flow.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name = "accion_transicion")
public class AccionTransicion {

    @Id
    @Column(name = "codigo", length = 30)
    private String codigo;

    @Column(name = "etiqueta", nullable = false, length = 100)
    private String etiqueta;

    protected AccionTransicion() {
    }

    public AccionTransicion(String codigo) {
        this.codigo = codigo;
        this.etiqueta = codigo;
    }

    public AccionTransicion(String codigo, String etiqueta) {
        this.codigo = codigo;
        this.etiqueta = etiqueta;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccionTransicion that = (AccionTransicion) o;
        return Objects.equals(codigo, that.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
