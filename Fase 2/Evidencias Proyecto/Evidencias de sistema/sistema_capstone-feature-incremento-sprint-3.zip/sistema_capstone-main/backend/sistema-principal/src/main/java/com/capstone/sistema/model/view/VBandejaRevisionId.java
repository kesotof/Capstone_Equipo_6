package com.capstone.sistema.model.view;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class VBandejaRevisionId implements Serializable {

    private UUID revisorId;
    private UUID solicitudId;

    public VBandejaRevisionId() {
    }

    public VBandejaRevisionId(UUID revisorId, UUID solicitudId) {
        this.revisorId = revisorId;
        this.solicitudId = solicitudId;
    }

    public UUID getRevisorId() {
        return revisorId;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VBandejaRevisionId that = (VBandejaRevisionId) o;
        return Objects.equals(revisorId, that.revisorId) && Objects.equals(solicitudId, that.solicitudId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(revisorId, solicitudId);
    }
}
