package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.AccionTransicion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccionTransicionRepository extends JpaRepository<AccionTransicion, String> {

    Optional<AccionTransicion> findByCodigoIgnoreCase(String codigo);
}
