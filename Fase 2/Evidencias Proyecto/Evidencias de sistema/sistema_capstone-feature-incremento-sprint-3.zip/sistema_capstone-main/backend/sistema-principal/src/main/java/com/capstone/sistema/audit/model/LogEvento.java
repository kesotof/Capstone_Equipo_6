package com.capstone.sistema.audit.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "log_evento", indexes = {
        @Index(name = "idx_log_tipo", columnList = "tipo_evento_id"),
        @Index(name = "idx_log_usuario", columnList = "usuario_id"),
        @Index(name = "idx_log_usuario_email", columnList = "usuario_email"),
        @Index(name = "idx_log_entidad", columnList = "entidad, entidad_id"),
        @Index(name = "idx_log_created", columnList = "created_at")
})
public class LogEvento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "tipo_evento_id", nullable = false)
    private TipoEvento tipoEvento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private UserAccount usuario;

    @Column(name = "usuario_email", length = 255)
    private String usuarioEmail;

    @Column(name = "entidad", length = 50)
    private String entidad;

    @Column(name = "entidad_id", length = 36)
    private String entidadId;

    @Column(name = "resultado", nullable = false, length = 10)
    private String resultado = "EXITO";

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "datos_antes", columnDefinition = "jsonb")
    private String datosAntes;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "datos_despues", columnDefinition = "jsonb")
    private String datosDespues;

    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Column(name = "user_agent", length = 500)
    private String userAgent;

    @Column(name = "request_id", length = 36)
    private String requestId;

    /** US-27: clave de deduplicación de eventos importados de sistemas externos ('kc:time:type:id'). */
    @Column(name = "clave_externa", length = 150, updatable = false)
    private String claveExterna;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected LogEvento() {
    }

    private static String ensureJson(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String trimmed = value.trim();
        if ((trimmed.startsWith("{") && trimmed.endsWith("}")) || (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
            return trimmed;
        }
        return "{\"detalle\":\"" + escapeJson(trimmed) + "\"}";
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public LogEvento(TipoEvento tipoEvento, UserAccount usuario, String ipAddress, String detalle) {
        this.tipoEvento = tipoEvento;
        this.usuario = usuario;
        this.usuarioEmail = usuario != null ? usuario.getEmail() : null;
        this.ipAddress = ipAddress;
        this.resultado = "EXITO";
        this.datosDespues = ensureJson(detalle);
    }

    public LogEvento(TipoEvento tipoEvento, UserAccount usuario, String usuarioEmail, String ipAddress, String detalle) {
        this.tipoEvento = tipoEvento;
        this.usuario = usuario;
        this.usuarioEmail = usuarioEmail != null ? usuarioEmail : (usuario != null ? usuario.getEmail() : null);
        this.ipAddress = ipAddress;
        this.resultado = "EXITO";
        this.datosDespues = ensureJson(detalle);
    }

    public LogEvento(
            TipoEvento tipoEvento,
            UserAccount usuario,
            String usuarioEmail,
            String entidad,
            String entidadId,
            String resultado,
            String datosAntes,
            String datosDespues,
            String ipAddress,
            String userAgent,
            String requestId
    ) {
        this.tipoEvento = tipoEvento;
        this.usuario = usuario;
        this.usuarioEmail = usuarioEmail != null ? usuarioEmail : (usuario != null ? usuario.getEmail() : null);
        this.entidad = entidad;
        this.entidadId = entidadId;
        this.resultado = resultado != null ? resultado : "EXITO";
        this.datosAntes = ensureJson(datosAntes);
        this.datosDespues = ensureJson(datosDespues);
        this.ipAddress = ipAddress;
        this.userAgent = userAgent;
        this.requestId = requestId;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        if (resultado == null) {
            resultado = "EXITO";
        }
    }

    public Long getId() {
        return id;
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(TipoEvento tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getUsuarioEmail() {
        return usuarioEmail;
    }

    public void setUsuarioEmail(String usuarioEmail) {
        this.usuarioEmail = usuarioEmail;
    }

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    public String getEntidadId() {
        return entidadId;
    }

    public void setEntidadId(String entidadId) {
        this.entidadId = entidadId;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getDatosAntes() {
        return datosAntes;
    }

    public void setDatosAntes(String datosAntes) {
        this.datosAntes = ensureJson(datosAntes);
    }

    public String getDatosDespues() {
        return datosDespues;
    }

    public void setDatosDespues(String datosDespues) {
        this.datosDespues = ensureJson(datosDespues);
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getClaveExterna() {
        return claveExterna;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    // Shim para compatibilidad con getDetalle()
    @Transient
    public String getDetalle() {
        return datosDespues;
    }

    public void setDetalle(String detalle) {
        this.datosDespues = ensureJson(detalle);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LogEvento that = (LogEvento) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
