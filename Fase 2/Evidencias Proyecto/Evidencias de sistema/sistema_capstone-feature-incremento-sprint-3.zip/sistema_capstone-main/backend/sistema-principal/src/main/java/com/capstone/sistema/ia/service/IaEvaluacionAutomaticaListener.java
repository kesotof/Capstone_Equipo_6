package com.capstone.sistema.ia.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.event.TransicionSolicitudEvent;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.UUID;

/**
 * F6 (§6.6, US-30, D3-03) + C2: evaluación automática de IA al entrar a una etapa con criterio.
 * Escucha {@link TransicionSolicitudEvent} en la misma transacción (A-11).
 * Si la etapa tiene criterio_ia, inserta la tarea y publica el comando tras commit.
 * Los consumidores del evento son parte atómica de la transición; cualquier error aborta la operación.
 */
@Component
public class IaEvaluacionAutomaticaListener {

    private static final Logger log = LoggerFactory.getLogger(IaEvaluacionAutomaticaListener.class);

    private final IaProperties iaProperties;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final IaTareaRepository iaTareaRepository;
    private final IaComandoFactory comandoFactory;
    private final MensajePublicador publicador;
    private final AuditService auditService;
    private final JdbcTemplate jdbc;

    public IaEvaluacionAutomaticaListener(
            IaProperties iaProperties,
            FlujoEtapaRepository flujoEtapaRepository,
            IaTareaRepository iaTareaRepository,
            IaComandoFactory comandoFactory,
            MensajePublicador publicador,
            AuditService auditService,
            JdbcTemplate jdbc
    ) {
        this.iaProperties = iaProperties;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.iaTareaRepository = iaTareaRepository;
        this.comandoFactory = comandoFactory;
        this.publicador = publicador;
        this.auditService = auditService;
        this.jdbc = jdbc;
    }

    @EventListener
    public void onTransicion(TransicionSolicitudEvent e) {
        if (!iaProperties.habilitada() || !iaProperties.evaluacionAutomatica()) {
            return;
        }
        if (!"PENDIENTE_REVISION".equals(e.estadoDestino())) {
            return;
        }
        if (e.etapaDestinoId() == null || e.documentoVigenteId() == null) {
            return;
        }

        FlujoEtapa etapa = flujoEtapaRepository.findById(e.etapaDestinoId()).orElse(null);
        if (etapa == null || etapa.getCriterioIa() == null || etapa.getCriterioIa().trim().isEmpty()) {
            return;
        }

        String criterio = etapa.getCriterioIa().trim();
        String sha256 = calcularSha256(criterio);

        // Idempotencia por (documento_id, flujo_etapa_id, instruccion_sha256) según índice único
        List<UUID> insertados = jdbc.query(
                """
                INSERT INTO ia_tarea (id, tipo, origen, estado, solicitud_id, documento_id, flujo_etapa_id,
                                      instruccion, instruccion_sha256, publicado_en, publicaciones, created_at)
                VALUES (gen_random_uuid(), 'EVALUACION', 'AUTOMATICO', 'PENDIENTE', ?, ?, ?, ?, ?, now(), 1, now())
                ON CONFLICT (documento_id, flujo_etapa_id, instruccion_sha256)
                WHERE tipo = 'EVALUACION' AND origen = 'AUTOMATICO'
                DO NOTHING
                RETURNING id
                """,
                (rs, rowNum) -> rs.getObject(1, UUID.class),
                e.solicitudId(), e.documentoVigenteId(), e.etapaDestinoId(), criterio, sha256
        );

        if (insertados.isEmpty()) {
            log.debug("Evaluación automática de IA ya existente para doc={}, etapa={}",
                    e.documentoVigenteId(), e.etapaDestinoId());
            return;
        }

        UUID tareaId = insertados.get(0);
        IaTarea tarea = iaTareaRepository.findById(tareaId).orElse(null);
        if (tarea == null) {
            return;
        }

        ComandoTareaIa comando = comandoFactory.crearComando(tarea);
        publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_IA_EJECUTAR, comando, comando.mensajeId());

        String datosDespues = "{\"tareaId\":\"" + tareaId + "\",\"origen\":\"AUTOMATICO\"}";
        auditService.registerAuditEvent("ANALISIS_IA_SOLICITADO", "solicitud", e.solicitudId().toString(), "EXITO", datosDespues);
        log.info("Evaluación automática de IA registrada: tarea={} solicitud={}", tareaId, e.solicitudId());
    }

    public static String calcularSha256(String texto) {
        if (texto == null) return null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(texto.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 no disponible", ex);
        }
    }
}
