package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.Plantilla;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PlantillaRepository extends JpaRepository<Plantilla, Long>, JpaSpecificationExecutor<Plantilla> {

    Optional<Plantilla> findByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

    List<Plantilla> findByArea_Id(Long areaId);

    List<Plantilla> findByTipoDocumento_Id(Long tipoDocumentoId);

    List<Plantilla> findByActivoTrue();

    @Query("SELECT p FROM Plantilla p WHERE p.activo = true AND (p.area IS NULL OR p.area.id = :areaId)" +
            " AND (:tipoDocId IS NULL OR p.tipoDocumento.id = :tipoDocId)")
    List<Plantilla> findDisponiblesParaUsuario(
            @Param("areaId") Long areaId,
            @Param("tipoDocId") Long tipoDocId
    );

    @Query("SELECT p FROM Plantilla p WHERE p.activo = true AND p.area IS NULL" +
            " AND (:tipoDocId IS NULL OR p.tipoDocumento.id = :tipoDocId)")
    List<Plantilla> findDisponiblesGlobales(
            @Param("tipoDocId") Long tipoDocId
    );
}
