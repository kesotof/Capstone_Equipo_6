package com.capstone.sistema.doc.dto;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.Instant;
import java.util.List;
import java.util.Locale;

/** Filtros normalizados de consulta; no representa una entidad persistida. */
public record DocumentSearchCriteria(String query, String documentType, String status, Long areaId,
                                     Instant dateFrom, Instant dateTo, boolean dateToExclusive,
                                     int page, int size, String sortField, Sort.Direction sortDirection,
                                     Relacion relacion, MiDecision miDecision) {
    public DocumentSearchCriteria {
        if (relacion == null) relacion = Relacion.TODAS;
    }

    public Pageable pageable() {
        return PageRequest.of(page, size, Sort.by(sortDirection, sortField).and(Sort.by("id")));
    }

    public String order() {
        return sortField + "," + sortDirection.name().toLowerCase(Locale.ROOT) + ";id,asc";
    }

    /** Relación del usuario autenticado con la solicitud (§3.4 del plan de diseño, dependencia D6). */
    public enum Relacion {
        TODAS("todas"), CREADAS("creadas"), REVISADAS("revisadas"), MIS_AREAS("mis-areas");

        private final String valor;

        Relacion(String valor) { this.valor = valor; }

        public String valor() { return valor; }

        /** Acepta el valor del contrato ("mis-areas") y la forma en mayúsculas del plan ("MIS_AREAS"). */
        public static Relacion parse(String raw) {
            String normalized = raw.toLowerCase(Locale.ROOT).replace('_', '-');
            for (Relacion relacion : values()) {
                if (relacion.valor.equals(normalized)) return relacion;
            }
            return null;
        }
    }

    /** Última decisión registrada por el usuario en HISTORIAL_TRANSICION.accion. */
    public enum MiDecision {
        APROBE("APROBAR"), RECHACE("RECHAZAR"), PEDI_CORRECCION("SOLICITAR_CORRECCION");

        /** Acciones de HISTORIAL_TRANSICION que cuentan como decisión de revisión. */
        public static final List<String> ACCIONES = List.of("APROBAR", "RECHAZAR", "SOLICITAR_CORRECCION");

        private final String accion;

        MiDecision(String accion) { this.accion = accion; }

        public String accion() { return accion; }

        /** Acepta APROBE/RECHACE/PEDI_CORRECCION y, por compatibilidad con el plan, el código de acción. */
        public static MiDecision parse(String raw) {
            String normalized = raw.toUpperCase(Locale.ROOT).replace('-', '_');
            for (MiDecision decision : values()) {
                if (decision.name().equals(normalized) || decision.accion.equals(normalized)) return decision;
            }
            return null;
        }

        public static MiDecision fromAccion(String accion) {
            for (MiDecision decision : values()) {
                if (decision.accion.equals(accion)) return decision;
            }
            return null;
        }
    }
}
