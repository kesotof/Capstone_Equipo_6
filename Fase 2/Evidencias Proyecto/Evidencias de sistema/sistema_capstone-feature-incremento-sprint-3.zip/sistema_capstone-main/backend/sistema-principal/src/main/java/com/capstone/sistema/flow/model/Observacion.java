package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;

import java.time.Instant;
import java.util.Objects;

public class Observacion {

    private Long id;
    private Solicitud solicitud;
    private SolicitudTransicion solicitudTransicion;
    private UserAccount usuario;
    private String contenido;
    private boolean resuelta = false;
    private Instant createdAt = Instant.now();

    public Observacion() {
    }

    public Observacion(Solicitud solicitud, SolicitudTransicion solicitudTransicion, UserAccount usuario, String contenido) {
        this.solicitud = solicitud;
        this.solicitudTransicion = solicitudTransicion;
        this.usuario = usuario;
        this.contenido = contenido;
        this.resuelta = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public SolicitudTransicion getSolicitudTransicion() {
        return solicitudTransicion;
    }

    public void setSolicitudTransicion(SolicitudTransicion solicitudTransicion) {
        this.solicitudTransicion = solicitudTransicion;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public boolean isResuelta() {
        return resuelta;
    }

    public void setResuelta(boolean resuelta) {
        this.resuelta = resuelta;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Observacion that = (Observacion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
