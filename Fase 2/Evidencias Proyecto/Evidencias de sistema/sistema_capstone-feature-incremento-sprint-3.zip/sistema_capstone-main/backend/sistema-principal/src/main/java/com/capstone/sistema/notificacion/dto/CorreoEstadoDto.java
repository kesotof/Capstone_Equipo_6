package com.capstone.sistema.notificacion.dto;

import com.capstone.sistema.model.enums.EstadoCorreo;

import java.time.Instant;
import java.util.UUID;

/**
 * F3 (§7.1): fila de la bandeja admin de correos
 * ({@code GET /api/admin/notificaciones/correos}).
 *
 * @param correoPublicaciones publicaciones del comando (inicial + re-publicaciones)
 * @param correoPublicadoEn   instante de la última publicación
 */
public record CorreoEstadoDto(
        Long notificacionId,
        UUID solicitudId,
        String correlativo,
        String destinatarioEmail,
        String titulo,
        EstadoCorreo estadoCorreo,
        int correoPublicaciones,
        Instant correoPublicadoEn,
        Instant createdEn
) {
}
