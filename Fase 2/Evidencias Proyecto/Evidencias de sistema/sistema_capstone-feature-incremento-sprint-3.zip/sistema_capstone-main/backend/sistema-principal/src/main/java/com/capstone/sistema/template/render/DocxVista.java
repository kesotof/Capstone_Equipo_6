package com.capstone.sistema.template.render;

import com.capstone.sistema.template.dto.PlantillaDtos.ConversionTexto;
import com.capstone.sistema.template.scanner.DocxPlaceholderScanner;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Vista HTML de un DOCX para el editor de plantillas. Cada párrafo lleva su ruta en el documento (data-p) y cada
 * tramo de texto su posición dentro del párrafo (data-o), para ubicar en el Word lo que se selecciona en la vista.
 * Los marcadores {{clave}} se muestran como fichas (data-key).
 */
@Component
public class DocxVista {

    private static final Pattern COLOR = Pattern.compile("[0-9A-Fa-f]{6}");
    private static final Set<String> IMAGENES = Set.of("image/png", "image/jpeg", "image/gif");
    // shortcut: las imágenes de más de 1 MB no se incrustan en la vista; servirlas por URL si hiciera falta.
    private static final int MAX_IMAGEN = 1024 * 1024;

    record Marca(int inicio, int fin, String clave) {}

    /** HTML del encabezado, el cuerpo y el pie de página principales del documento. */
    public String html(byte[] docx) throws IOException {
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(docx))) {
            StringBuilder html = new StringBuilder();
            Map<String, Integer> numeracion = new HashMap<>();
            XWPFHeaderFooterPolicy politica = doc.getHeaderFooterPolicy();
            XWPFHeader encabezado = politica != null && politica.getDefaultHeader() != null
                    ? politica.getDefaultHeader() : doc.getHeaderList().stream().findFirst().orElse(null);
            XWPFFooter pie = politica != null && politica.getDefaultFooter() != null
                    ? politica.getDefaultFooter() : doc.getFooterList().stream().findFirst().orElse(null);
            if (encabezado != null) {
                html.append("<div class=\"docx-encabezado\">");
                cuerpo(encabezado, "h" + doc.getHeaderList().indexOf(encabezado), html, numeracion);
                html.append("</div>");
            }
            html.append("<div class=\"docx-cuerpo\">");
            cuerpo(doc, "d", html, numeracion);
            html.append("</div>");
            if (pie != null) {
                html.append("<div class=\"docx-pie\">");
                cuerpo(pie, "f" + doc.getFooterList().indexOf(pie), html, numeracion);
                html.append("</div>");
            }
            return html.toString();
        }
    }

    /**
     * Reemplaza textos del documento por marcadores {{clave}}: la selección indicada (párrafo y posiciones) o, con
     * {@code todas} o sin párrafo, cada aparición del texto. El marcador conserva el formato del texto que reemplaza.
     */
    public byte[] convertir(byte[] docx, List<ConversionTexto> conversiones) throws IOException {
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(docx))) {
            for (ConversionTexto c : conversiones) {
                String marcador = "{{" + c.clave() + "}}";
                if (c.todas() || c.parrafo() == null) {
                    int total = 0;
                    for (XWPFParagraph p : parrafos(doc)) {
                        total += reemplazarTodas(p, c.texto(), marcador);
                    }
                    // Sin párrafo (sugerencias de la IA) un texto que ya no está se omite; con selección es un error.
                    if (total == 0 && c.parrafo() != null) {
                        throw new IllegalArgumentException("No se encontró «" + c.texto() + "» en el documento.");
                    }
                    continue;
                }
                XWPFParagraph p = ubicar(doc, c.parrafo());
                String texto = textoDe(p);
                int inicio = c.inicio() == null ? -1 : c.inicio();
                int fin = c.fin() == null ? -1 : c.fin();
                if (inicio < 0 || fin > texto.length() || inicio >= fin || !texto.substring(inicio, fin).equals(c.texto())) {
                    throw new IllegalArgumentException("El texto seleccionado ya no coincide con el documento. Vuelva a seleccionarlo.");
                }
                if (marcas(texto).stream().anyMatch(m -> m.inicio() < fin && inicio < m.fin())) {
                    throw new IllegalArgumentException("La selección incluye un campo existente. Seleccione solo texto.");
                }
                reemplazar(p, inicio, fin, marcador);
            }
            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            doc.write(salida);
            return salida.toByteArray();
        }
    }

    /** Quita del documento los marcadores {{clave}} de campos eliminados: el espacio queda vacío. */
    public byte[] quitar(byte[] docx, List<String> claves) throws IOException {
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(docx))) {
            for (XWPFParagraph p : parrafos(doc)) {
                List<Marca> marcas = marcas(textoDe(p));
                // De atrás hacia adelante, para que las posiciones pendientes sigan siendo válidas.
                for (int k = marcas.size() - 1; k >= 0; k--) {
                    Marca m = marcas.get(k);
                    if (claves.contains(m.clave())) reemplazar(p, m.inicio(), m.fin(), "");
                }
            }
            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            doc.write(salida);
            return salida.toByteArray();
        }
    }

    /** Evita tomar parte de una palabra o número, como "Juan" dentro de "Juana". */
    static boolean palabraCompleta(String texto, int inicio, int fin) {
        return (inicio == 0 || !Character.isLetterOrDigit(texto.charAt(inicio - 1)) || !Character.isLetterOrDigit(texto.charAt(inicio)))
                && (fin == texto.length() || !Character.isLetterOrDigit(texto.charAt(fin)) || !Character.isLetterOrDigit(texto.charAt(fin - 1)));
    }

    private int reemplazarTodas(XWPFParagraph p, String buscado, String marcador) {
        String texto = textoDe(p);
        List<Marca> marcas = marcas(texto);
        List<Integer> inicios = new ArrayList<>();
        for (int i = texto.indexOf(buscado); i >= 0; i = texto.indexOf(buscado, i + buscado.length())) {
            int inicio = i;
            int fin = i + buscado.length();
            if (palabraCompleta(texto, inicio, fin) && marcas.stream().noneMatch(m -> m.inicio() < fin && inicio < m.fin())) {
                inicios.add(inicio);
            }
        }
        // De atrás hacia adelante, para que las posiciones pendientes sigan siendo válidas.
        for (int k = inicios.size() - 1; k >= 0; k--) {
            reemplazar(p, inicios.get(k), inicios.get(k) + buscado.length(), marcador);
        }
        return inicios.size();
    }

    /** El nuevo texto queda en el primer run de la selección (con su formato); el resto de la selección se borra. */
    private void reemplazar(XWPFParagraph p, int inicio, int fin, String nuevo) {
        int pos = 0;
        boolean insertado = false;
        for (XWPFRun run : p.getRuns()) {
            String texto = textoDe(run);
            int desde = pos;
            pos += texto.length();
            if (pos <= inicio || desde >= fin) continue;
            reescribir(run, texto.substring(0, Math.max(inicio, desde) - desde) + (insertado ? "" : nuevo) + texto.substring(Math.min(fin, pos) - desde));
            insertado = true;
        }
    }

    /** Cambia el texto de un run conservando sus propiedades; tabulaciones y saltos de línea se vuelven a crear. */
    private static void reescribir(XWPFRun run, String texto) {
        CTR ctr = run.getCTR();
        for (int i = ctr.sizeOfTArray() - 1; i >= 0; i--) ctr.removeT(i);
        for (int i = ctr.sizeOfTabArray() - 1; i >= 0; i--) ctr.removeTab(i);
        for (int i = ctr.sizeOfBrArray() - 1; i >= 0; i--) ctr.removeBr(i);
        for (int i = ctr.sizeOfCrArray() - 1; i >= 0; i--) ctr.removeCr(i);
        String[] lineas = texto.split("\n", -1);
        for (int l = 0; l < lineas.length; l++) {
            if (l > 0) run.addBreak();
            String[] partes = lineas[l].split("\t", -1);
            for (int t = 0; t < partes.length; t++) {
                if (t > 0) run.addTab();
                if (!partes[t].isEmpty()) run.setText(partes[t], ctr.sizeOfTArray());
            }
        }
    }

    private static List<XWPFParagraph> parrafos(XWPFDocument doc) {
        List<XWPFParagraph> lista = new ArrayList<>();
        agregarParrafos(doc, lista);
        doc.getHeaderList().forEach(h -> agregarParrafos(h, lista));
        doc.getFooterList().forEach(f -> agregarParrafos(f, lista));
        return lista;
    }

    private static void agregarParrafos(IBody body, List<XWPFParagraph> lista) {
        for (IBodyElement el : body.getBodyElements()) {
            if (el instanceof XWPFParagraph p) lista.add(p);
            else if (el instanceof XWPFTable t) t.getRows().forEach(r -> r.getTableCells().forEach(c -> agregarParrafos(c, lista)));
        }
    }

    /** Ruta "d.3" (párrafo 3 del cuerpo) o "d.5.1.2.0" (tabla 5, fila 1, celda 2, párrafo 0); "h0"/"f0" para encabezado y pie. */
    private static XWPFParagraph ubicar(XWPFDocument doc, String ruta) {
        try {
            String[] partes = ruta.split("\\.");
            IBody body = switch (partes[0].charAt(0)) {
                case 'd' -> doc;
                case 'h' -> doc.getHeaderList().get(Integer.parseInt(partes[0].substring(1)));
                case 'f' -> doc.getFooterList().get(Integer.parseInt(partes[0].substring(1)));
                default -> throw new IllegalArgumentException(ruta);
            };
            for (int i = 1; ; i += 3) {
                IBodyElement el = body.getBodyElements().get(Integer.parseInt(partes[i]));
                if (i == partes.length - 1) return (XWPFParagraph) el;
                body = ((XWPFTable) el).getRow(Integer.parseInt(partes[i + 1])).getCell(Integer.parseInt(partes[i + 2]));
            }
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("El párrafo seleccionado ya no existe en el documento. Vuelva a seleccionarlo.");
        }
    }

    static String textoDe(XWPFParagraph p) {
        StringBuilder texto = new StringBuilder();
        p.getRuns().forEach(run -> texto.append(textoDe(run)));
        return texto.toString();
    }

    /**
     * Texto del documento para la IA: un párrafo por línea y las celdas de cada fila de tabla separadas por " | ".
     * El separador distingue una fila "Rótulo | Valor" de un párrafo con tabulaciones (por ejemplo, un encabezado).
     */
    public String texto(byte[] docx) throws IOException {
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(docx))) {
            StringBuilder texto = new StringBuilder();
            doc.getHeaderList().forEach(h -> lineas(h, texto));
            lineas(doc, texto);
            doc.getFooterList().forEach(f -> lineas(f, texto));
            return texto.toString();
        }
    }

    private static void lineas(IBody body, StringBuilder texto) {
        for (IBodyElement el : body.getBodyElements()) {
            if (el instanceof XWPFParagraph p) {
                texto.append(textoDe(p)).append('\n');
            } else if (el instanceof XWPFTable t) {
                for (XWPFTableRow fila : t.getRows()) {
                    List<String> celdas = new ArrayList<>();
                    fila.getTableCells().forEach(c -> celdas.add(String.join(" ", c.getParagraphs().stream().map(DocxVista::textoDe).toList())));
                    texto.append(String.join(" | ", celdas)).append('\n');
                }
            }
        }
    }

    static List<Marca> marcas(CharSequence texto) {
        List<Marca> marcas = new ArrayList<>();
        Matcher m = DocxPlaceholderScanner.PLACEHOLDER_PATTERN.matcher(texto);
        while (m.find()) {
            marcas.add(new Marca(m.start(), m.end(), m.group(2)));
        }
        return marcas;
    }

    static String textoDe(XWPFRun run) {
        String texto = run.text();
        return texto == null ? "" : texto;
    }

    private void cuerpo(IBody body, String ruta, StringBuilder html, Map<String, Integer> numeracion) {
        List<IBodyElement> elementos = body.getBodyElements();
        for (int i = 0; i < elementos.size(); i++) {
            String id = ruta + "." + i;
            if (elementos.get(i) instanceof XWPFParagraph p) {
                parrafo(p, id, html, numeracion);
            } else if (elementos.get(i) instanceof XWPFTable tabla) {
                html.append("<table><tbody>");
                for (int r = 0; r < tabla.getRows().size(); r++) {
                    html.append("<tr>");
                    List<XWPFTableCell> celdas = tabla.getRow(r).getTableCells();
                    for (int c = 0; c < celdas.size(); c++) {
                        CTTcPr pr = celdas.get(c).getCTTc().getTcPr();
                        int span = pr != null && pr.isSetGridSpan() ? pr.getGridSpan().getVal().intValue() : 1;
                        html.append(span > 1 ? "<td colspan=\"" + span + "\">" : "<td>");
                        cuerpo(celdas.get(c), id + "." + r + "." + c, html, numeracion);
                        html.append("</td>");
                    }
                    html.append("</tr>");
                }
                html.append("</tbody></table>");
            }
        }
    }

    private void parrafo(XWPFParagraph p, String ruta, StringBuilder html, Map<String, Integer> numeracion) {
        List<XWPFRun> runs = p.getRuns();
        int[] inicio = new int[runs.size() + 1];
        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < runs.size(); i++) {
            inicio[i] = texto.length();
            texto.append(textoDe(runs.get(i)));
        }
        inicio[runs.size()] = texto.length();
        List<Marca> marcas = marcas(texto);

        html.append("<p data-p=\"").append(ruta).append('"').append(clase(p)).append(estilo(p)).append('>');
        String vineta = vineta(p, numeracion);
        if (vineta != null) {
            html.append("<span class=\"docx-vineta\" aria-hidden=\"true\">").append(vineta).append("</span>");
        }
        boolean vacio = texto.isEmpty();
        int k = 0;
        for (int r = 0; r < runs.size(); r++) {
            XWPFRun run = runs.get(r);
            vacio &= !imagenes(run, html);
            int pos = inicio[r];
            int fin = inicio[r + 1];
            while (pos < fin) {
                while (k < marcas.size() && marcas.get(k).fin() <= pos) k++;
                Marca m = k < marcas.size() ? marcas.get(k) : null;
                if (m != null && m.inicio() <= pos) {
                    // Un marcador partido entre varios runs se muestra una sola vez, donde empieza.
                    if (m.inicio() == pos) {
                        html.append("<span class=\"docx-campo\" data-key=\"").append(HtmlUtils.htmlEscape(m.clave()))
                                .append("\" data-o=\"").append(m.inicio()).append("\" data-l=\"").append(m.fin() - m.inicio())
                                .append("\" contenteditable=\"false\">").append(HtmlUtils.htmlEscape(m.clave())).append("</span>");
                    }
                    pos = Math.min(m.fin(), fin);
                } else {
                    int corte = m == null ? fin : Math.min(m.inicio(), fin);
                    html.append("<span data-o=\"").append(pos).append('"').append(estilo(run)).append('>')
                            .append(HtmlUtils.htmlEscape(texto.substring(pos, corte))).append("</span>");
                    pos = corte;
                }
            }
        }
        html.append(vacio ? "<br></p>" : "</p>");
    }

    private String clase(XWPFParagraph p) {
        XWPFStyles estilos = p.getDocument().getStyles();
        XWPFStyle estilo = p.getStyleID() == null || estilos == null ? null : estilos.getStyle(p.getStyleID());
        String nombre = estilo == null || estilo.getName() == null ? "" : estilo.getName().toLowerCase(Locale.ROOT);
        if (nombre.equals("title") || nombre.equals("heading 1")) return " class=\"docx-t1\"";
        if (nombre.equals("subtitle") || nombre.equals("heading 2")) return " class=\"docx-t2\"";
        return nombre.startsWith("heading") ? " class=\"docx-t3\"" : "";
    }

    private String estilo(XWPFParagraph p) {
        String alineacion = switch (p.getAlignment()) {
            case CENTER -> "center";
            case RIGHT, END -> "right";
            case BOTH, DISTRIBUTE -> "justify";
            default -> null;
        };
        StringBuilder css = new StringBuilder();
        if (alineacion != null) css.append("text-align:").append(alineacion).append(';');
        if (p.getIndentationLeft() > 0) css.append("margin-left:").append(p.getIndentationLeft() / 20).append("pt;");
        return css.isEmpty() ? "" : " style=\"" + css + "\"";
    }

    private String estilo(XWPFRun run) {
        StringBuilder css = new StringBuilder();
        if (run.isBold()) css.append("font-weight:700;");
        if (run.isItalic()) css.append("font-style:italic;");
        if (run.getUnderline() != UnderlinePatterns.NONE) css.append("text-decoration:underline;");
        String color = run.getColor();
        if (color != null && COLOR.matcher(color).matches()) css.append("color:#").append(color).append(';');
        Double tamano = run.getFontSizeAsDouble();
        if (tamano != null && tamano >= 6 && tamano <= 40) css.append("font-size:").append(tamano).append("pt;");
        return css.isEmpty() ? "" : " style=\"" + css + "\"";
    }

    /** Viñeta o número de las listas; la numeración se lleva por lista y nivel, reiniciando los niveles internos. */
    private String vineta(XWPFParagraph p, Map<String, Integer> numeracion) {
        BigInteger lista = p.getNumID();
        if (lista == null) return null;
        if ("bullet".equals(p.getNumFmt())) return "•";
        int nivel = p.getNumIlvl() == null ? 0 : p.getNumIlvl().intValue();
        String prefijo = lista + ":";
        numeracion.keySet().removeIf(k -> k.startsWith(prefijo) && Integer.parseInt(k.substring(prefijo.length())) > nivel);
        return numeracion.merge(prefijo + nivel, 1, Integer::sum) + ".";
    }

    private boolean imagenes(XWPFRun run, StringBuilder html) {
        boolean alguna = false;
        for (XWPFPicture imagen : run.getEmbeddedPictures()) {
            XWPFPictureData datos = imagen.getPictureData();
            if (datos == null) continue;
            String tipo = datos.getPackagePart().getContentType();
            byte[] bytes = datos.getData();
            if (!IMAGENES.contains(tipo) || bytes.length > MAX_IMAGEN) continue;
            html.append("<img alt=\"\" src=\"data:").append(tipo).append(";base64,").append(Base64.getEncoder().encodeToString(bytes)).append('"');
            if (imagen.getWidth() > 0) html.append(" style=\"width:").append(Math.round(Math.min(imagen.getWidth(), 450))).append("pt\"");
            html.append('>');
            alguna = true;
        }
        return alguna;
    }
}
