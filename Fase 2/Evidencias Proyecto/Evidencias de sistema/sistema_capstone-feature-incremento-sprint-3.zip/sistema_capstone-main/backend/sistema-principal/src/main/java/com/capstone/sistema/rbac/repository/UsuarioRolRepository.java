package com.capstone.sistema.rbac.repository;

import com.capstone.sistema.rbac.model.UsuarioRol;
import com.capstone.sistema.users.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface UsuarioRolRepository extends JpaRepository<UsuarioRol, Long> {

    @Query("SELECT ur FROM UsuarioRol ur JOIN FETCH ur.rol WHERE ur.usuario.id = :usuarioId")
    List<UsuarioRol> findByUsuario_Id(@Param("usuarioId") UUID usuarioId);

    List<UsuarioRol> findByRol_Id(Long rolId);

    List<UsuarioRol> findByArea_Id(Long areaId);

    long countByRol_Id(Long rolId);

    @Query("SELECT COUNT(ur) FROM UsuarioRol ur WHERE ur.rol.id = :rolId AND (ur.vigenteHasta IS NULL OR ur.vigenteHasta > CURRENT_TIMESTAMP)")
    long countActiveByRolId(@Param("rolId") Long rolId);

    @Query("SELECT COUNT(ur) FROM UsuarioRol ur WHERE ur.rol.codigo = :codigo AND ur.area IS NULL AND (ur.vigenteHasta IS NULL OR ur.vigenteHasta > CURRENT_TIMESTAMP) AND ur.usuario.enabled = true")
    long countActiveGlobalByRolCodigo(@Param("codigo") String codigo);

    @Query("SELECT DISTINCT ur.usuario FROM UsuarioRol ur WHERE ur.rol.codigo = :codigo AND ur.area IS NULL AND (ur.vigenteHasta IS NULL OR ur.vigenteHasta > CURRENT_TIMESTAMP)")
    List<UserAccount> findUsuariosGlobalesByRolCodigo(@Param("codigo") String codigo);

    boolean existsByRol_IdAndAreaIsNotNull(Long rolId);
}
