package com.capstone.sistema.model.enums;

public enum AccionTransicionEnum {
    REGISTRAR("Registrar"),
    APROBAR("Aprobar"),
    RECHAZAR("Rechazar"),
    SOLICITAR_CORRECCION("Solicitar corrección"),
    CORREGIR("Corregir");

    private final String etiqueta;

    AccionTransicionEnum(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }
}
