package com.capstone.sistema.model.enums;

/**
 * US-36: rol destinatario de un tipo de notificación del catálogo.
 */
public enum RolDestinatario {
    EMISOR,
    REVISOR,
    CUALQUIERA
}
