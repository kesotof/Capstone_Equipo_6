package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VAreaDescendienteRepository extends JpaRepository<VAreaDescendiente, VAreaDescendienteId> {

    List<VAreaDescendiente> findById_AncestroId(Long ancestroId);

    List<VAreaDescendiente> findById_AreaId(Long areaId);

    boolean existsById_AncestroIdAndId_AreaId(Long ancestroId, Long areaId);
}
