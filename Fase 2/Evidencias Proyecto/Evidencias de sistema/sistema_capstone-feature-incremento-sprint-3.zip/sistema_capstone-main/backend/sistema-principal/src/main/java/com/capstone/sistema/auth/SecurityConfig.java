package com.capstone.sistema.auth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter
    ) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            // Keycloak solo autentica (D-15): aquí no hay reglas por rol; la autorización de negocio
            // se resuelve con permisos v5 en RbacAccessService.
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                        "/actuator/**",
                        "/api/public/**",
                        "/error",
                        "/v3/api-docs/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html"
                ).permitAll()
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(keycloakJwtAuthenticationConverter))
                .authenticationEntryPoint((request, response, authException) ->
                        writeProblem(response, org.springframework.http.HttpStatus.UNAUTHORIZED,
                                "NO_AUTENTICADO", "Debe iniciar sesión para continuar."))
            )
            .exceptionHandling(exceptions -> exceptions
                .authenticationEntryPoint((request, response, authException) ->
                        writeProblem(response, org.springframework.http.HttpStatus.UNAUTHORIZED,
                                "NO_AUTENTICADO", "Debe iniciar sesión para continuar."))
                .accessDeniedHandler((request, response, accessDeniedException) ->
                        writeProblem(response, org.springframework.http.HttpStatus.FORBIDDEN,
                                "RBAC_ACCION_DENEGADA", "No tiene permiso para realizar esta acción."))
            );

        return http.build();
    }

    /** Respuesta JSON (problem+json) con {@code codigo}/{@code code} y {@code mensaje}/{@code message}. */
    private static void writeProblem(jakarta.servlet.http.HttpServletResponse response,
                                     org.springframework.http.HttpStatus status,
                                     String codigo,
                                     String mensaje) throws java.io.IOException {
        response.setStatus(status.value());
        response.setCharacterEncoding(java.nio.charset.StandardCharsets.UTF_8.name());
        response.setContentType(org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        if (status == org.springframework.http.HttpStatus.UNAUTHORIZED) {
            response.setHeader("WWW-Authenticate", "Bearer");
        }
        // Se serializa un mapa plano: un ObjectMapper sin el mixin de Spring anidaría las propiedades de
        // ProblemDetail bajo "properties" y el cliente no encontraría "codigo" en la raíz.
        java.util.Map<String, Object> body = new java.util.LinkedHashMap<>();
        body.put("type", "about:blank");
        body.put("title", "Control de acceso");
        body.put("status", status.value());
        body.put("detail", mensaje);
        body.put("codigo", codigo);
        body.put("code", codigo);
        body.put("mensaje", mensaje);
        body.put("message", mensaje);
        body.put("timestamp", java.time.Instant.now().toString());
        new com.fasterxml.jackson.databind.ObjectMapper().writeValue(response.getOutputStream(), body);
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of(
                "http://localhost:3000",
                "http://localhost:5173",
                "http://127.0.0.1:3000",
                "http://127.0.0.1:5173",
                "http://192.168.2.100:3000",
                "http://192.168.2.100:5173"
        ));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type", "Accept"));
        configuration.setExposedHeaders(List.of("Content-Disposition", "Content-Length", "Content-Type"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
