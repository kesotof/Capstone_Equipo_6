package com.capstone.sistema.doc.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "tipo_documento")
public class TipoDocumento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(length = 500)
    private String descripcion;

    @Column(nullable = false, unique = true, length = 10)
    private String prefijo;

    @Column(name = "plazo_dias_habiles", nullable = false)
    private int plazoDiasHabiles;

    @Column(name = "ultimo_correlativo", nullable = false)
    private long ultimoCorrelativo = 0;

    @Column(nullable = false)
    private boolean activo = true;

    @Version
    @Column(name = "lock_version", nullable = false)
    private long lockVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected TipoDocumento() {
    }

    public TipoDocumento(String nombre, String prefijo, int plazoDiasHabiles) {
        this(nombre, null, prefijo, plazoDiasHabiles);
    }

    public TipoDocumento(String nombre, String descripcion, String prefijo, int plazoDiasHabiles) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.prefijo = prefijo;
        this.plazoDiasHabiles = plazoDiasHabiles;
        this.activo = true;
    }

    public TipoDocumento(Long id, String nombre, String descripcion, String prefijo, int plazoDiasHabiles) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.prefijo = prefijo;
        this.plazoDiasHabiles = plazoDiasHabiles;
        this.activo = true;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
        updatedAt = createdAt;
    }

    @PreUpdate
    void onPreUpdate() {
        updatedAt = Instant.now();
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrefijo() {
        return prefijo;
    }

    public void setPrefijo(String prefijo) {
        this.prefijo = prefijo;
    }

    public int getPlazoDiasHabiles() {
        return plazoDiasHabiles;
    }

    public void setPlazoDiasHabiles(int plazoDiasHabiles) {
        this.plazoDiasHabiles = plazoDiasHabiles;
    }

    public long getUltimoCorrelativo() {
        return ultimoCorrelativo;
    }

    public void setUltimoCorrelativo(long ultimoCorrelativo) {
        this.ultimoCorrelativo = ultimoCorrelativo;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public long getLockVersion() {
        return lockVersion;
    }

    public void setLockVersion(long lockVersion) {
        this.lockVersion = lockVersion;
    }

    public long getVersion() {
        return lockVersion;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoDocumento that = (TipoDocumento) o;
        return Objects.equals(id, that.id) || Objects.equals(prefijo, that.prefijo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prefijo);
    }
}
