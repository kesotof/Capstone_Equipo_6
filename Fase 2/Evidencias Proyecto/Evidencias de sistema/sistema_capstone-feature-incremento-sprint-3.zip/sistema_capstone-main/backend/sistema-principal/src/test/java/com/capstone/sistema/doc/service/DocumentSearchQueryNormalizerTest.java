package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.exception.DocumentSearchException;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class DocumentSearchQueryNormalizerTest {

    private final DocumentSearchQueryNormalizer normalizer = new DocumentSearchQueryNormalizer();

    @Test
    void miDecisionSinRelacionRevisadasEsRechazadoCon400() {
        Map<String, List<String>> parameters = Map.of("miDecision", List.of("APROBE"));

        assertThatThrownBy(() -> normalizer.normalize(parameters))
                .isInstanceOf(DocumentSearchException.class)
                .satisfies(ex -> assertThat(((DocumentSearchException) ex).status().value()).isEqualTo(400))
                .hasMessageContaining("miDecision solo se admite con relacion=revisadas");
    }

    @Test
    void miDecisionConRelacionRevisadasSeNormaliza() {
        Map<String, List<String>> parameters = Map.of(
                "relacion", List.of("revisadas"),
                "miDecision", List.of("APROBE"));

        DocumentSearchCriteria criteria = normalizer.normalize(parameters);

        assertThat(criteria.relacion()).isEqualTo(DocumentSearchCriteria.Relacion.REVISADAS);
        assertThat(criteria.miDecision()).isEqualTo(DocumentSearchCriteria.MiDecision.APROBE);
    }
}
