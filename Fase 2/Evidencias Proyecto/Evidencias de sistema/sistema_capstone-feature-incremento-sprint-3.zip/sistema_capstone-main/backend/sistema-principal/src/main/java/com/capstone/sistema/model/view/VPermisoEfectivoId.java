package com.capstone.sistema.model.view;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class VPermisoEfectivoId implements Serializable {

    private UUID usuarioId;
    private String recurso;
    private String accion;
    private Long areaId;
    private String origen;
    private Long rolId;
    private Long areaAsignadaId;

    public VPermisoEfectivoId() {
    }

    public VPermisoEfectivoId(UUID usuarioId, String recurso, String accion, Long areaId, String origen, Long rolId, Long areaAsignadaId) {
        this.usuarioId = usuarioId;
        this.recurso = recurso;
        this.accion = accion;
        this.areaId = areaId;
        this.origen = origen;
        this.rolId = rolId;
        this.areaAsignadaId = areaAsignadaId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VPermisoEfectivoId that = (VPermisoEfectivoId) o;
        return Objects.equals(usuarioId, that.usuarioId) &&
                Objects.equals(recurso, that.recurso) &&
                Objects.equals(accion, that.accion) &&
                Objects.equals(areaId, that.areaId) &&
                Objects.equals(origen, that.origen) &&
                Objects.equals(rolId, that.rolId) &&
                Objects.equals(areaAsignadaId, that.areaAsignadaId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(usuarioId, recurso, accion, areaId, origen, rolId, areaAsignadaId);
    }
}
