package com.capstone.sistema.doc.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.time.Instant;

public final class TipoDocumentoDtos {

    private TipoDocumentoDtos() {
    }

    public record TipoDocumentoResponse(
            Long id,
            String nombre,
            String descripcion,
            String prefijo,
            int plazoDiasHabiles,
            long ultimoCorrelativo,
            boolean activo,
            long version,
            Instant createdAt,
            Instant updatedAt
    ) {
    }

    public record CrearTipoDocumentoRequest(
            @NotBlank String nombre,
            String descripcion,
            @NotBlank @Pattern(regexp = "^[A-Z0-9]{2,10}$", message = "El prefijo debe tener entre 2 y 10 caracteres alfanuméricos en mayúsculas.") String prefijo,
            @Min(value = 1, message = "El plazo debe ser de al menos 1 día hábil.") int plazoDiasHabiles
    ) {
    }

    public record ActualizarTipoDocumentoRequest(
            @NotBlank String nombre,
            String descripcion,
            @NotBlank @Pattern(regexp = "^[A-Z0-9]{2,10}$", message = "El prefijo debe tener entre 2 y 10 caracteres alfanuméricos en mayúsculas.") String prefijo,
            @Min(value = 1, message = "El plazo debe ser de al menos 1 día hábil.") int plazoDiasHabiles,
            @NotNull Long version
    ) {
    }

    public record ToggleStatusTipoDocumentoRequest(
            @NotNull Boolean activo,
            @NotNull Long version
    ) {
    }
}
