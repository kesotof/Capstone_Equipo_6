package com.capstone.sistema.ia.controller;

import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.dto.IaMensajeChatDto;
import com.capstone.sistema.ia.dto.PreguntaChatRequest;
import com.capstone.sistema.ia.service.IaChatService;
import com.capstone.sistema.ia.service.IaTareaService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.auth.CurrentUserResolver;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/**
 * F6 (§7.1): endpoints REST para evaluación de IA y chat sobre solicitudes (US-30).
 */
@RestController
@RequestMapping("/api/solicitudes/{id}/ia")
@Tag(name = "IA - Evaluaciones y Chat", description = "Asistente de inteligencia artificial por solicitud (US-30)")
public class IaSolicitudController {

    private final IaTareaService iaTareaService;
    private final IaChatService iaChatService;
    private final CurrentUserResolver currentUserResolver;

    public IaSolicitudController(
            IaTareaService iaTareaService,
            IaChatService iaChatService,
            CurrentUserResolver currentUserResolver
    ) {
        this.iaTareaService = iaTareaService;
        this.iaChatService = iaChatService;
        this.currentUserResolver = currentUserResolver;
    }

    @Operation(summary = "Listar evaluaciones de IA de la solicitud (más reciente primero)")
    @GetMapping("/evaluaciones")
    public List<IaEvaluacionDto> listarEvaluaciones(@PathVariable("id") UUID id) {
        UserAccount user = requireUser();
        return iaTareaService.consultarEvaluaciones(id, user.getId());
    }

    @Operation(summary = "Re-ejecutar evaluación manual con el criterio vigente de la etapa actual")
    @PostMapping("/evaluaciones")
    public ResponseEntity<IaEvaluacionDto> reejecutarEvaluacion(@PathVariable("id") UUID id) {
        UserAccount user = requireUser();
        IaEvaluacionDto dto = iaTareaService.crearEvaluacionManual(id, user);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(dto);
    }

    @Operation(summary = "Consultar el hilo de chat de IA sobre la solicitud (cronológico)")
    @GetMapping("/chat")
    public List<IaMensajeChatDto> listarChat(@PathVariable("id") UUID id) {
        UserAccount user = requireUser();
        return iaChatService.consultarChat(id, user.getId());
    }

    @Operation(summary = "Enviar una pregunta de chat al asistente de IA sobre el documento vigente")
    @PostMapping("/chat")
    public ResponseEntity<IaMensajeChatDto> enviarPregunta(
            @PathVariable("id") UUID id,
            @RequestBody PreguntaChatRequest request
    ) {
        UserAccount user = requireUser();
        String pregunta = request != null ? request.pregunta() : null;
        IaMensajeChatDto dto = iaChatService.crearChat(id, user, pregunta);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(dto);
    }

    @Operation(summary = "Consultar estado de una tarea de IA para polling (evaluación o mensaje de chat)")
    @GetMapping("/tareas/{tareaId}")
    public ResponseEntity<?> consultarTarea(
            @PathVariable("id") UUID id,
            @PathVariable("tareaId") UUID tareaId
    ) {
        UserAccount user = requireUser();
        Object dto = iaTareaService.consultarTarea(id, tareaId, user.getId());
        return ResponseEntity.ok(dto);
    }

    private UserAccount requireUser() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new AccessDeniedException("Usuario no autenticado"));
    }
}
