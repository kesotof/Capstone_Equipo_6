package com.capstone.sistema.ia.service;

import com.capstone.sistema.flow.exception.AlmacenamientoNoDisponibleException;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.dto.IaAutocompletadoDto;
import com.capstone.sistema.ia.dto.IaErrorMensajes;
import com.capstone.sistema.ia.dto.IaEvaluacionDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.template.service.PlantillaService;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.security.MessageDigest;
import java.util.*;

/**
 * F8 (§6.9, US-29): servicio de autocompletado de formularios a partir de documentos analizados con IA.
 */
@Service
public class IaAutocompletadoService {

    private static final Logger log = LoggerFactory.getLogger(IaAutocompletadoService.class);

    private static final Set<String> EXTENSIONES_VALIDAS = Set.of("pdf", "doc", "docx", "txt");
    private static final Set<String> CONTENT_TYPES_VALIDOS = Set.of(
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "text/plain"
    );

    private final IaProperties iaProperties;
    private final IaTareaRepository iaTareaRepository;
    private final PlantillaService plantillaService;
    private final MinioStorageService minioStorageService;
    private final IaComandoFactory comandoFactory;
    private final MensajePublicador publicador;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    public IaAutocompletadoService(
            IaProperties iaProperties,
            IaTareaRepository iaTareaRepository,
            PlantillaService plantillaService,
            MinioStorageService minioStorageService,
            IaComandoFactory comandoFactory,
            MensajePublicador publicador,
            AuditService auditService,
            ObjectMapper objectMapper
    ) {
        this.iaProperties = iaProperties;
        this.iaTareaRepository = iaTareaRepository;
        this.plantillaService = plantillaService;
        this.minioStorageService = minioStorageService;
        this.comandoFactory = comandoFactory;
        this.publicador = publicador;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public IaAutocompletadoDto iniciarAutocompletado(Long plantillaId, MultipartFile archivo, UserAccount usuario) {
        if (!iaProperties.habilitada()) {
            throw IaException.deshabilitada();
        }
        if (plantillaId == null) {
            throw IaException.noEncontrada("El ID de plantilla es obligatorio.");
        }

        PlantillaVersion versionVigente;
        try {
            versionVigente = plantillaService.obtenerVersionVigenteDisponible(plantillaId, usuario);
        } catch (Exception e) {
            throw IaException.noEncontrada("Plantilla no encontrada o no disponible: " + plantillaId);
        }

        if (archivo == null || archivo.isEmpty()) {
            throw IaException.formatoNoSoportado("El archivo adjunto es obligatorio.");
        }

        long maxBytes = iaProperties.autocompletado().maxBytes();
        if (archivo.getSize() > maxBytes) {
            throw IaException.archivoExcedeTamano("El archivo excede el tamaño máximo permitido de " + (maxBytes / (1024 * 1024)) + " MB.");
        }

        String originalFilename = archivo.getOriginalFilename();
        validarFormatoArchivo(originalFilename, archivo.getContentType());

        UUID tareaId = UUID.randomUUID();
        String safeName = MinioStorageService.cleanFilename(originalFilename);
        String bucket = iaProperties.autocompletado().bucket();
        String storageKey = "autocompletado/" + tareaId + "/" + safeName;

        byte[] fileBytes;
        String sha256;
        try {
            fileBytes = archivo.getBytes();
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(fileBytes);
            sha256 = HexFormat.of().formatHex(hash);
            minioStorageService.uploadToBucket(bucket, storageKey, safeName, archivo.getContentType(), fileBytes);
        } catch (AlmacenamientoNoDisponibleException ande) {
            log.error("MinIO no disponible para autocompletado en bucket '{}'. Asegúrese de ejecutar minio-init: {}", bucket, ande.getMessage());
            throw IaException.noDisponible("El servicio de almacenamiento MinIO no está disponible. Ejecute minio-init.");
        } catch (Exception e) {
            log.error("Error al almacenar archivo para autocompletado en MinIO: {}", e.getMessage(), e);
            throw IaException.noDisponible("Error al almacenar el archivo adjunto: " + e.getMessage());
        }

        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCompletion(int status) {
                    if (status == STATUS_ROLLED_BACK) {
                        try {
                            minioStorageService.removeObject(bucket, storageKey);
                        } catch (Exception ex) {
                            log.warn("No se pudo limpiar objeto temporal {} de MinIO tras rollback: {}", storageKey, ex.getMessage());
                        }
                    }
                }
            });
        }

        String instruccion = "Extraer valores para los campos de la plantilla a partir del documento adjunto.";
        String instruccionSha256 = IaEvaluacionAutomaticaListener.calcularSha256(instruccion);

        IaTarea tarea = new IaTarea(
                TipoTareaIa.AUTOCOMPLETAR,
                OrigenTareaIa.MANUAL,
                null,
                null,
                null,
                versionVigente,
                bucket,
                storageKey,
                originalFilename,
                archivo.getContentType(),
                instruccion,
                instruccionSha256,
                usuario
        );
        iaTareaRepository.save(tarea);

        ComandoTareaIa comando = comandoFactory.crearComando(tarea);
        publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_IA_EJECUTAR, comando, comando.mensajeId());

        String datosAudit = "{\"tareaId\":\"" + tarea.getId() + "\",\"plantillaId\":" + plantillaId + "}";
        auditService.registerAuditEvent("IA_AUTOCOMPLETADO_SOLICITADO", "plantilla", plantillaId.toString(), "EXITO", datosAudit);
        log.info("Tarea de autocompletado iniciada: tarea={} plantilla={} usuario={}",
                tarea.getId(), plantillaId, usuario.getEmail());

        return toAutocompletadoDto(tarea);
    }

    @Transactional(readOnly = true)
    public IaAutocompletadoDto consultarAutocompletado(UUID tareaId, UserAccount usuario) {
        IaTarea tarea = iaTareaRepository.findById(tareaId)
                .orElseThrow(() -> IaException.noEncontrada("Tarea de autocompletado no encontrada"));

        if (tarea.getTipo() != TipoTareaIa.AUTOCOMPLETAR) {
            throw IaException.noEncontrada("Tarea de autocompletado no encontrada");
        }

        // Solo el solicitado_por puede consultar (§6.9; si no, 404)
        if (tarea.getSolicitadoPor() == null || !Objects.equals(tarea.getSolicitadoPor().getId(), usuario.getId())) {
            throw IaException.noEncontrada("Tarea de autocompletado no encontrada");
        }

        return toAutocompletadoDto(tarea);
    }

    /**
     * Valida la aplicabilidad de un autocompletado según §6.9:
     * - Mismo usuario emisor
     * - Estado COMPLETADA
     * - Misma plantilla_version_id
     */
    @Transactional(readOnly = true)
    public void validarAplicabilidad(UUID autocompletadoId, PlantillaVersion versionVigente, UserAccount emisor) {
        if (autocompletadoId == null) {
            return;
        }

        IaTarea tarea = iaTareaRepository.findById(autocompletadoId)
                .orElseThrow(() -> IaException.autocompletadoNoAplicable("La tarea de autocompletado no existe."));

        if (tarea.getTipo() != TipoTareaIa.AUTOCOMPLETAR) {
            throw IaException.autocompletadoNoAplicable("La tarea indicada no corresponde a un autocompletado.");
        }

        if (tarea.getSolicitadoPor() == null || !Objects.equals(tarea.getSolicitadoPor().getId(), emisor.getId())) {
            throw IaException.autocompletadoNoAplicable("La tarea de autocompletado no pertenece al usuario emisor.");
        }

        if (tarea.getEstado() != EstadoTareaIa.COMPLETADA) {
            throw IaException.autocompletadoNoAplicable("La tarea de autocompletado aún no ha completado su procesamiento exitosamente.");
        }

        if (tarea.getPlantillaVersion() == null || versionVigente == null
                || !Objects.equals(tarea.getPlantillaVersion().getId(), versionVigente.getId())) {
            throw IaException.autocompletadoNoAplicable("La tarea de autocompletado no corresponde a la versión de la plantilla utilizada.");
        }
    }

    public IaAutocompletadoDto toAutocompletadoDto(IaTarea tarea) {
        IaAutocompletadoDto.PlantillaDto plantillaDto = null;
        if (tarea.getPlantillaVersion() != null) {
            PlantillaVersion pv = tarea.getPlantillaVersion();
            String nombre = pv.getPlantilla() != null ? pv.getPlantilla().getNombre() : "Plantilla";
            plantillaDto = new IaAutocompletadoDto.PlantillaDto(
                    pv.getPlantilla() != null ? pv.getPlantilla().getId() : null,
                    pv.getVersion(),
                    nombre
            );
        }

        JsonNode camposNode = null;
        List<String> noEncontradosList = List.of();
        if (tarea.getResultado() != null) {
            camposNode = tarea.getResultado().get("sugerencias");
            JsonNode noEncNode = tarea.getResultado().get("noEncontrados");
            if (noEncNode != null && noEncNode.isArray()) {
                List<String> list = new ArrayList<>();
                noEncNode.forEach(n -> list.add(n.asText()));
                noEncontradosList = Collections.unmodifiableList(list);
            }
        }

        IaEvaluacionDto.ErrorDto errorDto = tarea.getEstado() == EstadoTareaIa.FALLIDA
                ? new IaEvaluacionDto.ErrorDto(tarea.getCodigoError(), IaErrorMensajes.mensajeAmigable(tarea.getCodigoError()))
                : null;

        return new IaAutocompletadoDto(
                tarea.getId(),
                tarea.getEstado().name(),
                plantillaDto,
                camposNode,
                noEncontradosList,
                errorDto,
                tarea.getCreatedAt(),
                tarea.getCompletedAt()
        );
    }

    private void validarFormatoArchivo(String filename, String contentType) {
        if (contentType != null && CONTENT_TYPES_VALIDOS.contains(contentType.toLowerCase())) {
            return;
        }
        if (filename != null && filename.contains(".")) {
            String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
            if (EXTENSIONES_VALIDAS.contains(extension)) {
                return;
            }
        }
        throw IaException.formatoNoSoportado("El formato del archivo no es soportado para autocompletado (solo PDF, DOC, DOCX o TXT).");
    }
}
