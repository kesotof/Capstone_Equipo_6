package com.capstone.sistema.rbac.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "control_politica")
public class ControlPolitica {

    @Id
    private Integer id = 1;

    @Column(nullable = false)
    private long version = 1;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    public ControlPolitica() {
    }

    public ControlPolitica(long version) {
        this.id = 1;
        this.version = version;
    }

    @PrePersist
    @PreUpdate
    void onPrePersistOrUpdate() {
        if (updatedAt == null) {
            updatedAt = Instant.now();
        }
    }

    public Integer getId() {
        return id;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public void incrementVersion() {
        this.version++;
        this.updatedAt = Instant.now();
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
