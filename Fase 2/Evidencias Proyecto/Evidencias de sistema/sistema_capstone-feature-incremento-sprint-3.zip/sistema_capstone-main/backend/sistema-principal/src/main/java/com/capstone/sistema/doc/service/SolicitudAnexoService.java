package com.capstone.sistema.doc.service;

import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.dto.AnexoResponse;
import com.capstone.sistema.doc.model.SolicitudAnexo;
import com.capstone.sistema.doc.repository.SolicitudAnexoRepository;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Documentos adjuntos (anexos) de una solicitud: validación, almacenamiento y consulta. */
@Service
public class SolicitudAnexoService {

    private static final Logger log = LoggerFactory.getLogger(SolicitudAnexoService.class);

    public static final int MAX_ANEXOS = 5;
    private static final long MAX_TAMANO = 10L * 1024 * 1024;
    private static final int MAX_NOMBRE = 255;
    // Mismos formatos que admite la tabla 'documento' y el registro con archivo.
    private static final Map<String, String> TIPOS = Map.of(
            "pdf", "application/pdf",
            "doc", "application/msword",
            "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "xml", "application/xml",
            "txt", "text/plain"
    );

    private final SolicitudAnexoRepository anexos;
    private final MinioStorageService storage;
    private final RbacAccessService access;

    public SolicitudAnexoService(SolicitudAnexoRepository anexos, MinioStorageService storage, RbacAccessService access) {
        this.anexos = anexos;
        this.storage = storage;
        this.access = access;
    }

    /** Descarta las partes vacías y valida cantidad, formato y tamaño antes de guardar nada. */
    public List<MultipartFile> validar(List<MultipartFile> archivos) {
        List<MultipartFile> validos = archivos == null ? List.of()
                : archivos.stream().filter(f -> f != null && !f.isEmpty()).toList();
        if (validos.size() > MAX_ANEXOS) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Puede adjuntar hasta " + MAX_ANEXOS + " documentos.");
        }
        for (MultipartFile archivo : validos) {
            if (tipoDe(archivo) == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El archivo '" + nombreDe(archivo)
                        + "' no tiene un formato permitido (.pdf, .doc, .docx, .xml o .txt).");
            }
            if (archivo.getSize() > MAX_TAMANO) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El archivo '" + nombreDe(archivo) + "' supera los 10 MB.");
            }
        }
        return validos;
    }

    /** Sube los anexos ya validados y los registra; si la transacción se revierte, se eliminan de MinIO. */
    public void guardar(Solicitud solicitud, UUID carpeta, List<MultipartFile> archivos, UserAccount autor) {
        for (int i = 0; i < archivos.size(); i++) {
            MultipartFile archivo = archivos.get(i);
            MinioStorageService.MinioUploadResult subido;
            try {
                subido = storage.uploadAnexo(carpeta, i + 1, archivo.getOriginalFilename(), tipoDe(archivo), archivo.getBytes());
            } catch (Exception e) {
                log.error("Error al almacenar anexo en MinIO: {}", e.getMessage(), e);
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al guardar los documentos adjuntos en el almacenamiento.");
            }
            storage.deleteOnRollback(subido.storageKey());
            anexos.save(new SolicitudAnexo(solicitud, nombreDe(archivo), subido.contentType(), subido.storageKey(),
                    subido.sizeBytes(), subido.checksumSha256(), autor));
        }
    }

    /** Anexos de una solicitud visible para el usuario; la descarga se ofrece a quien puede descargar su documento. */
    @Transactional(readOnly = true)
    public List<AnexoResponse> listar(UUID solicitudId) {
        access.clearContext();
        UUID usuarioId = access.context().usuarioId();
        boolean admin = access.context().admin();
        if (!admin && !access.puedeAccederSolicitud(usuarioId, solicitudId)) {
            throw RbacException.missing();
        }
        boolean descarga = admin || access.puedeDescargar(usuarioId, solicitudId);
        return anexos.findBySolicitud_IdOrderByCreatedAtAscNombreArchivoAsc(solicitudId).stream()
                .map(a -> new AnexoResponse(a.getId(), a.getNombreArchivo(), a.getContentType(), a.getSizeBytes(),
                        a.getCreatedAt(), descarga ? "/api/anexos/" + a.getId() + "/download" : null))
                .toList();
    }

    private String tipoDe(MultipartFile archivo) {
        String nombre = nombreDe(archivo);
        int punto = nombre.lastIndexOf('.');
        return punto < 0 ? null : TIPOS.get(nombre.substring(punto + 1).toLowerCase(Locale.ROOT));
    }

    private String nombreDe(MultipartFile archivo) {
        String nombre = archivo.getOriginalFilename() == null ? "" : archivo.getOriginalFilename();
        nombre = nombre.substring(Math.max(nombre.lastIndexOf('/'), nombre.lastIndexOf('\\')) + 1).strip();
        if (nombre.isEmpty()) nombre = "anexo";
        return nombre.length() > MAX_NOMBRE ? nombre.substring(nombre.length() - MAX_NOMBRE) : nombre;
    }
}
