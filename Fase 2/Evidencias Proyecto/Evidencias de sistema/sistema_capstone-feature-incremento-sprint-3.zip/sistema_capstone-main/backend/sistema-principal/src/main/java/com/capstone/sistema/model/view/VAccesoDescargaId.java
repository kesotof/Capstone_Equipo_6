package com.capstone.sistema.model.view;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class VAccesoDescargaId implements Serializable {

    private UUID solicitudId;
    private UUID usuarioId;
    private String motivo;

    public VAccesoDescargaId() {
    }

    public VAccesoDescargaId(UUID solicitudId, UUID usuarioId, String motivo) {
        this.solicitudId = solicitudId;
        this.usuarioId = usuarioId;
        this.motivo = motivo;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public String getMotivo() {
        return motivo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VAccesoDescargaId that = (VAccesoDescargaId) o;
        return Objects.equals(solicitudId, that.solicitudId) &&
                Objects.equals(usuarioId, that.usuarioId) &&
                Objects.equals(motivo, that.motivo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(solicitudId, usuarioId, motivo);
    }
}
