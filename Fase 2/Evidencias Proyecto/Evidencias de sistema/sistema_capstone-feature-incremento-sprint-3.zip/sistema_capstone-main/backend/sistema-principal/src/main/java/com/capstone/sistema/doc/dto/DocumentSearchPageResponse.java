package com.capstone.sistema.doc.dto;

import java.util.List;

public record DocumentSearchPageResponse(List<DocumentSearchItemResponse> contenido, int pagina, int tamanio,
                                         long totalElementos, int totalPaginas, boolean primera, boolean ultima,
                                         String orden, Contadores contadores) {
    public DocumentSearchPageResponse {
        contenido = List.copyOf(contenido);
    }

    /**
     * Conteos por relación con los mismos filtros de texto, tipo, estado, área y fechas, sin relación ni miDecision,
     * y siempre dentro del alcance visible del usuario.
     */
    public record Contadores(long todas, long creadas, long revisadas, long misAreas) { }
}
