package com.capstone.sistema.flow.controller;

import com.capstone.sistema.notificacion.controller.NotificacionController;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.model.enums.CategoriaNotificacion;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.model.enums.RolDestinatario;
import com.capstone.sistema.notificacion.dto.NotificacionResponse;
import com.capstone.sistema.notificacion.service.NotificacionService;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NotificacionController.class)
@Import(SecurityConfig.class)
class NotificacionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NotificacionService notificacionService;

    @MockBean
    private CurrentUserResolver currentUserResolver;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    private UserAccount testUser;

    @BeforeEach
    void setUp() {
        testUser = new UserAccount("kc-1", "usuario@test.local", "Juan", "Perez", true);
        ReflectionTestUtils.setField(testUser, "id", UUID.randomUUID());
    }

    private static NotificacionResponse notif(Long id, String titulo, String tipo,
                                              CategoriaNotificacion categoria, UUID solicitudId, boolean leida) {
        return new NotificacionResponse(id, titulo, "Hay un documento", tipo, categoria,
                RolDestinatario.CUALQUIERA, "/solicitudes/" + solicitudId, "CONT-001", solicitudId,
                leida, Instant.now(), leida ? Instant.now() : null,
                leida ? EstadoCorreo.ENVIADO : EstadoCorreo.NO_APLICA);
    }

    @Test
    void rejectsUnauthenticated() throws Exception {
        mockMvc.perform(get("/api/notificaciones"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void listarMisNotificaciones_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.listarMisNotificaciones(eq(testUser),
                nullable(CategoriaNotificacion.class), eq(false))).thenReturn(List.of(
                notif(1L, "Nueva Solicitud", "REVISION_ASIGNADA", CategoriaNotificacion.ACCION_REQUERIDA, solId, false)
        ));

        mockMvc.perform(get("/api/notificaciones")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Nueva Solicitud"))
                .andExpect(jsonPath("$[0].leida").value(false))
                .andExpect(jsonPath("$[0].categoria").value("ACCION_REQUERIDA"))
                .andExpect(jsonPath("$[0].enlace").value("/solicitudes/" + solId))
                .andExpect(jsonPath("$[0].estadoCorreo").value("NO_APLICA"));
    }

    @Test
    void listarMisNotificaciones_FiltroDeCategoriaYNoLeidas() throws Exception {
        UUID solId = UUID.randomUUID();
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.listarMisNotificaciones(eq(testUser),
                eq(CategoriaNotificacion.ACCION_REQUERIDA), eq(true))).thenReturn(List.of(
                notif(1L, "Requiere acción", "CORRECCION_REQUERIDA", CategoriaNotificacion.ACCION_REQUERIDA, solId, false)
        ));

        mockMvc.perform(get("/api/notificaciones?categoria=accion_requerida&soloNoLeidas=true")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(notificacionService).listarMisNotificaciones(eq(testUser),
                eq(CategoriaNotificacion.ACCION_REQUERIDA), eq(true));
    }

    @Test
    void listarMisNotificaciones_CategoriaInvalida_Retorna400() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));

        mockMvc.perform(get("/api/notificaciones?categoria=NO_EXISTE")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("NOTIFICACION_PARAMETRO_INVALIDO"));
    }

    @Test
    void contarNoLeidas_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.contarNoLeidas(testUser)).thenReturn(5L);

        mockMvc.perform(get("/api/notificaciones/no-leidas/count")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.count").value(5));
    }

    @Test
    void marcarComoLeida_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarComoLeida(10L, testUser)).thenReturn(
                notif(10L, "Aprobada", "SOLICITUD_APROBADA", CategoriaNotificacion.INFORMATIVA,
                        UUID.randomUUID(), true)
        );

        mockMvc.perform(patch("/api/notificaciones/10/leer")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.leida").value(true));
    }

    @Test
    void marcarTodasComoLeidas_Success() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarTodasComoLeidas(testUser)).thenReturn(3);

        mockMvc.perform(patch("/api/notificaciones/marcar-todas-leidas")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.actualizadas").value(3));
    }

    @Test
    void marcarComoLeida_UsuarioNoEsDestinatario_Retorna403Forbidden() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.marcarComoLeida(99L, testUser))
                .thenThrow(new org.springframework.security.access.AccessDeniedException("No tienes permiso para marcar esta notificación"));

        mockMvc.perform(patch("/api/notificaciones/99/leer")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isForbidden());
    }

    @Test
    void listarMisNotificaciones_DistincionEstadoLeidaYNoLeida_YRedireccionPrecisa() throws Exception {
        UUID solId = UUID.randomUUID();
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(testUser));
        when(notificacionService.listarMisNotificaciones(eq(testUser),
                nullable(CategoriaNotificacion.class), eq(false))).thenReturn(List.of(
                notif(1L, "Nueva Solicitud", "REVISION_ASIGNADA", CategoriaNotificacion.ACCION_REQUERIDA, solId, false),
                notif(2L, "Solicitud Aprobada", "SOLICITUD_APROBADA", CategoriaNotificacion.INFORMATIVA, solId, true)
        ));

        mockMvc.perform(get("/api/notificaciones")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].leida").value(false))
                .andExpect(jsonPath("$[0].leidaEn").doesNotExist())
                .andExpect(jsonPath("$[0].solicitudId").value(solId.toString()))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].leida").value(true))
                .andExpect(jsonPath("$[1].leidaEn").exists())
                .andExpect(jsonPath("$[1].solicitudId").value(solId.toString()));
    }
}
