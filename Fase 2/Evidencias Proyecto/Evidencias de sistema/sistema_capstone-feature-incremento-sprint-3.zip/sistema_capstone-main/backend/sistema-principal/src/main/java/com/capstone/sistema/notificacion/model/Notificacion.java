package com.capstone.sistema.notificacion.model;

import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.model.SolicitudTransicion;
import com.capstone.sistema.model.enums.EstadoCorreo;
import com.capstone.sistema.model.enums.EstadoSolicitudEnum;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "notificacion", indexes = {
        @Index(name = "idx_notif_destinatario", columnList = "usuario_id, created_at"),
        @Index(name = "idx_notif_solicitud", columnList = "solicitud_id"),
        @Index(name = "idx_notif_tipo", columnList = "tipo_notificacion_id"),
        @Index(name = "idx_notif_transicion", columnList = "historial_transicion_id")
})
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount destinatario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solicitud_id")
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "historial_transicion_id")
    private HistorialTransicion historialTransicion;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "tipo_notificacion_id", nullable = false)
    private TipoNotificacion tipoNotificacion;

    @Column(nullable = false, length = 255)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String mensaje;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "leida_en")
    private Instant leidaEn;

    /** US-36 (CA 10.4): ruta relativa de navegación (la URL absoluta se arma con app.frontend-base-url). */
    @Column(name = "enlace", length = 300)
    private String enlace;

    /** US-35 (CA 09.x): clave de deduplicación (p. ej. PLAZO_POR_VENCER:{solicitudId}:{usuarioId}). */
    @Column(name = "clave_dedup", length = 150, updatable = false)
    private String claveDedup;

    /** US-35: estado del envío de correo (D3-01 decide el catálogo). */
    @Enumerated(EnumType.STRING)
    @Column(name = "estado_correo", nullable = false, length = 10)
    private EstadoCorreo estadoCorreo = EstadoCorreo.NO_APLICA;

    /** US-35: instante del último intento de publicación del comando de correo. */
    @Column(name = "correo_publicado_en")
    private Instant correoPublicadoEn;

    /** US-35: publicaciones del comando de correo (máximo mensajeria.republicador.max-publicaciones). */
    @Column(name = "correo_publicaciones", nullable = false)
    private short correoPublicaciones = 0;

    protected Notificacion() {
    }

    public Notificacion(
            UserAccount destinatario,
            Solicitud solicitud,
            TipoNotificacion tipoNotificacion,
            String titulo,
            String mensaje
    ) {
        this(destinatario, solicitud, (HistorialTransicion) null, tipoNotificacion, titulo, mensaje);
    }

    public Notificacion(
            UserAccount destinatario,
            Solicitud solicitud,
            HistorialTransicion historialTransicion,
            TipoNotificacion tipoNotificacion,
            String titulo,
            String mensaje
    ) {
        this.destinatario = destinatario;
        this.solicitud = solicitud;
        this.historialTransicion = historialTransicion;
        this.tipoNotificacion = tipoNotificacion;
        this.titulo = titulo;
        this.mensaje = mensaje;
    }

    public Notificacion(
            UserAccount destinatario,
            Solicitud solicitud,
            SolicitudTransicion solicitudTransicion,
            TipoNotificacion tipoNotificacion,
            String titulo,
            String mensaje
    ) {
        this.destinatario = destinatario;
        this.solicitud = solicitud;
        this.tipoNotificacion = tipoNotificacion;
        this.titulo = titulo;
        this.mensaje = mensaje;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public UserAccount getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(UserAccount destinatario) {
        this.destinatario = destinatario;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public HistorialTransicion getHistorialTransicion() {
        return historialTransicion;
    }

    public void setHistorialTransicion(HistorialTransicion historialTransicion) {
        this.historialTransicion = historialTransicion;
    }

    public TipoNotificacion getTipoNotificacion() {
        return tipoNotificacion;
    }

    public void setTipoNotificacion(TipoNotificacion tipoNotificacion) {
        this.tipoNotificacion = tipoNotificacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getLeidaEn() {
        return leidaEn;
    }

    public String getEnlace() {
        return enlace;
    }

    public void setEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String getClaveDedup() {
        return claveDedup;
    }

    public void setClaveDedup(String claveDedup) {
        this.claveDedup = claveDedup;
    }

    public EstadoCorreo getEstadoCorreo() {
        return estadoCorreo;
    }

    public void setEstadoCorreo(EstadoCorreo estadoCorreo) {
        this.estadoCorreo = estadoCorreo;
    }

    public Instant getCorreoPublicadoEn() {
        return correoPublicadoEn;
    }

    public void setCorreoPublicadoEn(Instant correoPublicadoEn) {
        this.correoPublicadoEn = correoPublicadoEn;
    }

    public int getCorreoPublicaciones() {
        return correoPublicaciones;
    }

    public void setCorreoPublicaciones(int correoPublicaciones) {
        this.correoPublicaciones = (short) correoPublicaciones;
    }

    public void setLeidaEn(Instant leidaEn) {
        this.leidaEn = leidaEn;
    }

    public boolean isLeida() {
        return leidaEn != null;
    }

    public void setLeida(boolean leida) {
        this.leidaEn = leida ? Instant.now() : null;
    }

    @Transient
    public Instant getCreatedEn() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Notificacion that = (Notificacion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
