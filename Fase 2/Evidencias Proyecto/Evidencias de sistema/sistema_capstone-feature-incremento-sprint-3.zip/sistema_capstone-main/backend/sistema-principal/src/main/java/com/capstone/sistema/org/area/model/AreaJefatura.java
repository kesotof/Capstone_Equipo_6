package com.capstone.sistema.org.area.model;

import com.capstone.sistema.users.model.Area;
import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "area_jefatura")
@IdClass(AreaJefaturaId.class)
public class AreaJefatura {

    @Id
    @Column(name = "area_id")
    private Long areaId;

    @Id
    @Column(name = "usuario_id")
    private UUID usuarioId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "area_id", insertable = false, updatable = false)
    private Area area;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", insertable = false, updatable = false)
    private UserAccount usuario;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected AreaJefatura() {
    }

    public AreaJefatura(Area area, UserAccount usuario) {
        this.area = area;
        this.usuario = usuario;
        this.areaId = area != null ? area.getId() : null;
        this.usuarioId = usuario != null ? usuario.getId() : null;
    }

    public AreaJefatura(Long areaId, UUID usuarioId) {
        this.areaId = areaId;
        this.usuarioId = usuarioId;
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getAreaId() {
        return areaId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public Area getArea() {
        return area;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
