package com.capstone.sistema.ia.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.dto.IaMensajeChatDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.MensajeriaConfig;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

/**
 * F6 (§6.7, D3-04, US-30): hilo de chat sobre el documento vigente con persistencia por solicitud.
 */
@Service
public class IaChatService {

    private static final Logger log = LoggerFactory.getLogger(IaChatService.class);
    private static final ZoneId ZONA_CHILE = ZoneId.of("America/Santiago");

    private final IaProperties iaProperties;
    private final IaTareaRepository iaTareaRepository;
    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final IaAccesoPolicy accesoPolicy;
    private final IaComandoFactory comandoFactory;
    private final MensajePublicador publicador;
    private final AuditService auditService;

    public IaChatService(
            IaProperties iaProperties,
            IaTareaRepository iaTareaRepository,
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            IaAccesoPolicy accesoPolicy,
            IaComandoFactory comandoFactory,
            MensajePublicador publicador,
            AuditService auditService
    ) {
        this.iaProperties = iaProperties;
        this.iaTareaRepository = iaTareaRepository;
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.accesoPolicy = accesoPolicy;
        this.comandoFactory = comandoFactory;
        this.publicador = publicador;
        this.auditService = auditService;
    }

    @Transactional(readOnly = true)
    public List<IaMensajeChatDto> consultarChat(UUID solicitudId, UUID usuarioId) {
        if (!accesoPolicy.existeSolicitudConAcceso(usuarioId, solicitudId)) {
            throw IaException.noEncontrada("Solicitud no encontrada");
        }
        if (!accesoPolicy.puedeVer(usuarioId, solicitudId)) {
            throw IaException.accesoDenegado();
        }

        List<IaTarea> mensajes = iaTareaRepository.findChatThread(solicitudId);
        return mensajes.stream()
                .map(IaTareaService::toChatDto)
                .toList();
    }

    @Transactional
    public IaMensajeChatDto crearChat(UUID solicitudId, UserAccount usuario, String pregunta) {
        if (!iaProperties.habilitada()) {
            throw IaException.deshabilitada();
        }

        if (pregunta == null || pregunta.trim().isEmpty()) {
            throw IaException.preguntaInvalida("La pregunta no puede estar vacía.");
        }
        String preguntaLimpia = pregunta.trim();
        int maxChars = iaProperties.chat().maxPregunta();
        if (preguntaLimpia.length() > maxChars) {
            throw IaException.preguntaInvalida("La pregunta no puede superar " + maxChars + " caracteres (recibido: " + preguntaLimpia.length() + ").");
        }

        if (!accesoPolicy.existeSolicitudConAcceso(usuario.getId(), solicitudId)) {
            throw IaException.noEncontrada("Solicitud no encontrada");
        }
        if (!accesoPolicy.puedeVer(usuario.getId(), solicitudId)) {
            throw IaException.accesoDenegado();
        }
        if (!accesoPolicy.esRevisorActualOAdmin(usuario.getId(), solicitudId)) {
            throw IaException.accesoDenegado();
        }

        Solicitud solicitud = solicitudRepository.findById(solicitudId)
                .orElseThrow(() -> IaException.noEncontrada("Solicitud no encontrada"));

        String estado = solicitud.getEstadoSolicitud() != null ? solicitud.getEstadoSolicitud().getCodigo() : null;
        if (!"PENDIENTE_REVISION".equals(estado)) {
            throw IaException.solicitudNoEnRevision();
        }

        // Una tarea manual en curso por usuario y solicitud (§6.7 / índice uq_ia_manual_en_curso)
        boolean enCurso = iaTareaRepository.existsBySolicitudIdAndTipoAndSolicitadoPorIdAndEstado(
                solicitudId, TipoTareaIa.CHAT, usuario.getId(), EstadoTareaIa.PENDIENTE
        );
        if (enCurso) {
            throw IaException.tareaEnCurso();
        }

        // Límite diario de preguntas por solicitud (§6.7)
        Instant inicioDia = LocalDate.now(ZONA_CHILE).atStartOfDay(ZONA_CHILE).toInstant();
        long preguntasHoy = iaTareaRepository.countPreguntasChatDesde(solicitudId, inicioDia);
        int maxDiario = iaProperties.chat().maxPreguntasDiaSolicitud();
        if (preguntasHoy >= maxDiario) {
            throw IaException.limiteDiario();
        }

        Documento docVigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> IaException.noEncontrada("No se encontró documento vigente para la solicitud"));
        FlujoEtapa etapaActual = solicitud.getFlujoEtapa();

        String sha256 = IaEvaluacionAutomaticaListener.calcularSha256(preguntaLimpia);

        IaTarea tarea = new IaTarea(
                TipoTareaIa.CHAT,
                OrigenTareaIa.MANUAL,
                solicitud,
                docVigente,
                etapaActual,
                null,
                null,
                null,
                null,
                null,
                preguntaLimpia,
                sha256,
                usuario
        );
        try {
            iaTareaRepository.saveAndFlush(tarea);
        } catch (DataIntegrityViolationException e) {
            log.warn("Violación de integridad al guardar tarea de chat (carrera concurrente): {}", e.getMessage());
            throw IaException.tareaEnCurso();
        }

        ComandoTareaIa comando = comandoFactory.crearComando(tarea);
        publicador.publicarTrasCommit(MensajeriaConfig.ROUTING_IA_EJECUTAR, comando, comando.mensajeId());

        String datosDespues = "{\"tareaId\":\"" + tarea.getId() + "\"}";
        auditService.registerAuditEvent("IA_CONSULTA_REALIZADA", "solicitud", solicitudId.toString(), "EXITO", datosDespues);
        log.info("Consulta a chat de IA registrada: tarea={} solicitud={} usuario={}",
                tarea.getId(), solicitudId, usuario.getEmail());

        return IaTareaService.toChatDto(tarea);
    }
}
