package com.capstone.sistema.rbac.repository;

import com.capstone.sistema.rbac.model.PermisoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PermisoEntityRepository extends JpaRepository<PermisoEntity, Long> {

    Optional<PermisoEntity> findByRecursoAndAccion(String recurso, String accion);

    Optional<PermisoEntity> findByRecursoIgnoreCaseAndAccionIgnoreCase(String recurso, String accion);

    List<PermisoEntity> findByRecurso(String recurso);

    boolean existsByRecursoAndAccion(String recurso, String accion);
}
