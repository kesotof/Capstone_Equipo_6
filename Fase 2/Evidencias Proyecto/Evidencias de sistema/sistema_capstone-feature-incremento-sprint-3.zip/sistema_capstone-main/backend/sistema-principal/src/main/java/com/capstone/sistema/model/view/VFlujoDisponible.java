package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

@Entity
@Table(name = "v_flujo_disponible")
@Immutable
public class VFlujoDisponible {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "version")
    private Integer version;

    @Column(name = "area_id")
    private Long areaId;

    public VFlujoDisponible() {
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getVersion() {
        return version;
    }

    public Long getAreaId() {
        return areaId;
    }
}
