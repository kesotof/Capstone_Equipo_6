package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface VAccesoSolicitudRepository extends JpaRepository<VAccesoSolicitud, VAccesoSolicitudId> {

    List<VAccesoSolicitud> findBySolicitudId(UUID solicitudId);

    List<VAccesoSolicitud> findByUsuarioId(UUID usuarioId);

    boolean existsBySolicitudIdAndUsuarioId(UUID solicitudId, UUID usuarioId);
}
