package com.capstone.sistema.flow.exception;

/** El almacenamiento de archivos (MinIO) no está disponible: se responde 503 ALMACENAMIENTO_NO_DISPONIBLE. */
public class AlmacenamientoNoDisponibleException extends RuntimeException {

    public AlmacenamientoNoDisponibleException(String message, Throwable cause) {
        super(message, cause);
    }
}
