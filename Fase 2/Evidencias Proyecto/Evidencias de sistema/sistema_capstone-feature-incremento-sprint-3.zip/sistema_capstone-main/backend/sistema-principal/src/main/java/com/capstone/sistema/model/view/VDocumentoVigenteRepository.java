package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface VDocumentoVigenteRepository extends JpaRepository<VDocumentoVigente, UUID> {

    Optional<VDocumentoVigente> findBySolicitudId(UUID solicitudId);

    List<VDocumentoVigente> findBySolicitudIdIn(List<UUID> solicitudIds);
}
