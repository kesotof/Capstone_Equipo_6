package com.capstone.sistema.users.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = "com.capstone.sistema.users")
public class UserExceptionHandler {

    @ExceptionHandler(PasswordChangeException.class)
    public ProblemDetail handlePasswordChange(PasswordChangeException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(exception.status(), exception.getMessage());
        problem.setTitle("Cambio de contraseña");
        problem.setProperty("code", exception.code());
        problem.setProperty("codigo", exception.code());
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        if (!exception.invalidFields().isEmpty()) problem.setProperty("invalidFields", exception.invalidFields());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ProblemDetail handleConflict(UserAlreadyExistsException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, exception.getMessage());
        problem.setTitle("Usuario duplicado");
        problem.setProperty("code", "USUARIO_DUPLICADO");
        problem.setProperty("codigo", "USUARIO_DUPLICADO");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(AreaInactivaException.class)
    public ProblemDetail handleAreaInactiva(AreaInactivaException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, exception.getMessage());
        problem.setTitle("Área inactiva");
        problem.setProperty("code", "AREA_INACTIVA");
        problem.setProperty("codigo", "AREA_INACTIVA");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(RutDuplicadoException.class)
    public ProblemDetail handleRutDuplicado(RutDuplicadoException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, exception.getMessage());
        problem.setTitle("RUT ya registrado");
        problem.setProperty("code", "RUT_DUPLICADO");
        problem.setProperty("codigo", "RUT_DUPLICADO");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(RutInvalidoException.class)
    public ProblemDetail handleRutInvalido(RutInvalidoException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, exception.getMessage());
        problem.setTitle("RUT inválido");
        problem.setProperty("code", "RUT_INVALIDO");
        problem.setProperty("codigo", "RUT_INVALIDO");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ProblemDetail handleNotFound(UserNotFoundException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, exception.getMessage());
        problem.setTitle("Usuario no encontrado");
        problem.setProperty("code", "RECURSO_NO_ENCONTRADO");
        problem.setProperty("codigo", "RECURSO_NO_ENCONTRADO");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(UserProvisioningException.class)
    public ProblemDetail handleProvisioning(UserProvisioningException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_GATEWAY, exception.getMessage());
        problem.setTitle("No fue posible crear la cuenta en Keycloak");
        problem.setProperty("code", "KEYCLOAK_PROVISIONING_ERROR");
        problem.setProperty("codigo", "KEYCLOAK_PROVISIONING_ERROR");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(InvalidCurrentPasswordException.class)
    public ProblemDetail handleInvalidCurrentPassword(InvalidCurrentPasswordException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                "La contraseña actual es incorrecta, inténtelo nuevamente."
        );
        problem.setTitle("Contraseña actual incorrecta");
        problem.setProperty("code", "PASSWORD_ACTUAL_INVALIDA");
        problem.setProperty("codigo", "PASSWORD_ACTUAL_INVALIDA");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(PasswordMismatchException.class)
    public ProblemDetail handlePasswordMismatch(PasswordMismatchException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                exception.getMessage() != null ? exception.getMessage() : "Las contraseñas no coinciden."
        );
        problem.setTitle("Las contraseñas no coinciden");
        problem.setProperty("code", "PASSWORD_MISMATCH");
        problem.setProperty("codigo", "PASSWORD_MISMATCH");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(PasswordPolicyException.class)
    public ProblemDetail handlePasswordPolicy(PasswordPolicyException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                exception.getMessage()
        );
        problem.setTitle("Requisitos de contraseña no cumplidos");
        problem.setProperty("code", "PASSWORD_POLICY_VIOLATION");
        problem.setProperty("codigo", "PASSWORD_POLICY_VIOLATION");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ProblemDetail handleIllegalArgument(IllegalArgumentException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                exception.getMessage()
        );
        problem.setTitle("Petición inválida");
        problem.setProperty("code", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("codigo", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(MethodArgumentNotValidException exception) {
        Map<String, String> invalidFields = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error ->
                invalidFields.putIfAbsent(error.getField(), error.getDefaultMessage())
        );

        ProblemDetail problem = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problem.setTitle("Error de validación");
        problem.setDetail("Revisa los campos enviados e inténtalo nuevamente.");
        problem.setProperty("invalidFields", invalidFields);
        problem.setProperty("code", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("codigo", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.http.converter.HttpMessageNotReadableException.class)
    public ProblemDetail handleBody(org.springframework.http.converter.HttpMessageNotReadableException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                "Envía un cuerpo JSON válido con los tipos de datos indicados."
        );
        problem.setTitle("Cuerpo de solicitud inválido");
        problem.setProperty("code", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("codigo", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleTypeMismatch(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException exception) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                String.format("El parámetro '%s' tiene un formato o tipo inválido: '%s'", exception.getName(), exception.getValue())
        );
        problem.setTitle("Parámetro inválido");
        problem.setProperty("parametro", exception.getName());
        problem.setProperty("code", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("codigo", "USUARIO_DATOS_INVALIDOS");
        problem.setProperty("mensaje", problem.getDetail());
        problem.setProperty("message", problem.getDetail());
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }
}
