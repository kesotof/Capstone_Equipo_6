package com.capstone.sistema.notificacion.service;

import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.util.SlaStatusCalculator;
import com.capstone.sistema.notificacion.dto.MensajeNotificacion;
import com.capstone.sistema.notificacion.dto.NotificacionContexto;
import com.capstone.sistema.notificacion.repository.NotificacionRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.users.model.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * F5 (§6.4, D3-08) + C4: alertas de plazo para los revisores de la etapa actual.
 *
 * <ul>
 *   <li>{@code pg_try_advisory_xact_lock(41030, 2)}: instancia única por transacción en {@link TransactionTemplate}.</li>
 *   <li>Candidatas (§6.4): solicitudes {@code PENDIENTE_REVISION} con
 *       {@code deadline <= ahora + 24 h} (por vencer o ya vencidas), unidas a
 *       {@code v_revisor_solicitud} por la etapa <strong>actual</strong>; paginación de a 200
 *       por id.</li>
 *   <li>{@code PLAZO_VENCIDO} si el reloj (bean {@code slaClock}) ya pasó el deadline; si no,
 *       {@code PLAZO_POR_VENCER}. El umbral y la decisión reutilizan
 *       {@link SlaStatusCalculator} — misma regla que las insignias SLA de la UI.</li>
 *   <li>Clave dedup determinista {@code TIPO:{solicitudId}:{usuarioId}}: una segunda ejecución
 *       no duplica (ON CONFLICT de {@code NotificacionService.crear}). Si el job estuvo
 *       detenido y la solicitud ya venció, solo llega «vencido».</li>
 *   <li>{@code CORRECCION_REQUERIDA} no genera alertas: la query filtra por
 *       {@code PENDIENTE_REVISION} (la solicitud está en manos del emisor).</li>
 *   <li>Hereda correo y elegibilidad vía {@code crear(...)} (D3-01 vive en el catálogo).</li>
 * </ul>
 *
 * <p>El umbral NO es configurable: se lee de {@code SlaStatusCalculator.warningWindow()} para
 * que el job y las insignias no diverjan.</p>
 */
@Component
@ConditionalOnProperty(prefix = "app.scheduling", name = "enabled", havingValue = "true")
public class PlazoAlertaScheduler {

    private static final Logger log = LoggerFactory.getLogger(PlazoAlertaScheduler.class);
    static final int LOTE_MAXIMO = 200;

    private final NotificacionRepository notificacionRepository;
    private final SolicitudRepository solicitudRepository;
    private final UserAccountRepository usuarioRepository;
    private final NotificacionMensajeFactory fabrica;
    private final NotificacionService notificaciones;
    private final Clock clock;
    private final TransactionTemplate transactionTemplate;

    public PlazoAlertaScheduler(NotificacionRepository notificacionRepository,
                                SolicitudRepository solicitudRepository,
                                UserAccountRepository usuarioRepository,
                                NotificacionMensajeFactory fabrica,
                                NotificacionService notificaciones,
                                Clock clock,
                                TransactionTemplate transactionTemplate) {
        this.notificacionRepository = notificacionRepository;
        this.solicitudRepository = solicitudRepository;
        this.usuarioRepository = usuarioRepository;
        this.fabrica = fabrica;
        this.notificaciones = notificaciones;
        this.clock = clock;
        this.transactionTemplate = transactionTemplate;
    }

    @Scheduled(cron = "${plazos.alerta.cron}", zone = "${plazos.alerta.zona}")
    public void programado() {
        Integer creadas = transactionTemplate.execute(status -> alertar());
        if (creadas != null && creadas > 0) {
            log.info("Alertas de plazo: {} notificación(es) creada(s)", creadas);
        }
    }

    /** @return alertas efectivamente emitidas (visible para las pruebas). */
    public int alertar() {
        Boolean lock = notificacionRepository.tryAdvisoryLockPlazos();
        if (!Boolean.TRUE.equals(lock)) {
            return 0;
        }

        Instant ahora = clock.instant();
        Instant umbral = ahora.plus(SlaStatusCalculator.warningWindow());
        int creadas = 0;
        UUID ultimoId = null;

        while (true) {
            List<Object[]> lote =
                    notificacionRepository.candidatasDePlazo(umbral, ultimoId, LOTE_MAXIMO);
            if (lote.isEmpty()) {
                break;
            }
            for (Object[] fila : lote) {
                UUID solicitudId = (UUID) fila[0];
                Instant deadline = (Instant) fila[1];
                UUID usuarioId = (UUID) fila[2];
                ultimoId = solicitudId;

                Solicitud solicitud = solicitudRepository.findById(solicitudId).orElse(null);
                UserAccount revisor = usuarioRepository.findById(usuarioId).orElse(null);
                if (solicitud == null || revisor == null || deadline == null) {
                    log.warn("Candidata de plazo incompleta (solicitud {}, usuario {}); se omite",
                            solicitudId, usuarioId);
                    continue;
                }

                String estadoSla = SlaStatusCalculator.status(deadline, ahora);
                String tipo = "VENCIDO".equals(estadoSla) ? "PLAZO_VENCIDO" : "PLAZO_POR_VENCER";

                NotificacionContexto ctx = new NotificacionContexto(
                        solicitudId, null, solicitud.getCorrelativo(), solicitud.getTitulo(),
                        solicitud.getTipoDocumento(), null, null, null, null, null,
                        deadline, null, null);
                MensajeNotificacion mensaje = fabrica.construir(tipo, ctx);
                String clave = tipo + ":" + solicitudId + ":" + usuarioId;

                notificaciones.crear(tipo, revisor, solicitud, null, mensaje, clave);
                creadas++;
            }
            if (lote.size() < LOTE_MAXIMO) {
                break;
            }
        }
        return creadas;
    }
}
