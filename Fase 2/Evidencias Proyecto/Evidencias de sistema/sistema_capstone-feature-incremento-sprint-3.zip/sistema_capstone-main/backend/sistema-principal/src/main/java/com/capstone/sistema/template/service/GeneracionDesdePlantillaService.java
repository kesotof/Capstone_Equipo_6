package com.capstone.sistema.template.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.service.SolicitudAnexoService;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.service.AiAnalysisService;
import com.capstone.sistema.flow.service.FlujoConcurrencyService;
import com.capstone.sistema.flow.service.FlujoIntegrityService;
import com.capstone.sistema.flow.service.SolicitudWorkflowService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.flow.service.SolicitudWorkflowService.CorregirCommand;
import com.capstone.sistema.flow.service.SolicitudWorkflowService.RegistrarCommand;
import com.capstone.sistema.ia.service.IaAutocompletadoService;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.FieldValidationError;
import com.capstone.sistema.template.dto.PlantillaDtos.CorregirSolicitudDesdePlantillaRequest;
import com.capstone.sistema.template.dto.PlantillaDtos.CrearSolicitudDesdePlantillaRequest;
import com.capstone.sistema.template.dto.PlantillaDtos.FormularioPlantillaDto;
import com.capstone.sistema.template.render.TemplateRenderer;
import com.capstone.sistema.template.schema.FieldSchemaBuilder;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Transactional
public class GeneracionDesdePlantillaService {

    private static final Logger log = LoggerFactory.getLogger(GeneracionDesdePlantillaService.class);
    private static final ZoneId ZONA_NEGOCIO = ZoneId.of("America/Santiago");
    private static final DateTimeFormatter FECHA_ARCHIVO = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private final PlantillaService plantillaService;
    private final SolicitudWorkflowService workflowService;
    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final MinioStorageService minioStorageService;
    private final FieldSchemaBuilder schemaBuilder;
    private final TemplateRenderer templateRenderer;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;
    private final IaAutocompletadoService iaAutocompletadoService;
    private final SolicitudAnexoService anexoService;
    private final RbacAccessService rbac;
    private final RbacManagementService rbacManagement;
    private final FlujoConcurrencyService concurrency;
    private final FlujoIntegrityService integrity;
    private final AiAnalysisService aiAnalysisService;

    public GeneracionDesdePlantillaService(
            PlantillaService plantillaService,
            SolicitudWorkflowService workflowService,
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            MinioStorageService minioStorageService,
            FieldSchemaBuilder schemaBuilder,
            TemplateRenderer templateRenderer,
            AuditService auditService,
            ObjectMapper objectMapper,
            @org.springframework.beans.factory.annotation.Autowired(required = false) IaAutocompletadoService iaAutocompletadoService,
            SolicitudAnexoService anexoService,
            RbacAccessService rbac,
            RbacManagementService rbacManagement,
            FlujoConcurrencyService concurrency,
            FlujoIntegrityService integrity,
            @org.springframework.beans.factory.annotation.Autowired(required = false) AiAnalysisService aiAnalysisService
    ) {
        this.plantillaService = plantillaService;
        this.workflowService = workflowService;
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.minioStorageService = minioStorageService;
        this.schemaBuilder = schemaBuilder;
        this.templateRenderer = templateRenderer;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
        this.iaAutocompletadoService = iaAutocompletadoService;
        this.anexoService = anexoService;
        this.rbac = rbac;
        this.rbacManagement = rbacManagement;
        this.concurrency = concurrency;
        this.integrity = integrity;
        this.aiAnalysisService = aiAnalysisService;
    }

    /**
     * Genera la vista previa en memoria del documento generado a partir de la plantilla y los datos provistos.
     * Sin {@code version} usa la vigente; al corregir se pide la versión del documento, aunque exista una más nueva.
     */
    @Transactional(readOnly = true)
    public byte[] generarVistaPrevia(Long plantillaId, Integer version, Map<String, Object> datos, UserAccount actor) {
        int numero = version != null ? version : plantillaService.obtenerFormulario(plantillaId).version();
        List<FieldDefinition> campos = schemaBuilder.parseFields(plantillaService.obtenerVersion(plantillaId, numero).getEsquemaCampos());
        Map<String, Object> datosFinales = FieldSchemaBuilder.aplicarReglas(campos, datos);

        validarCampos(campos, datosFinales);

        byte[] templateBytes = plantillaService.obtenerArchivoVersion(plantillaId, numero);
        return templateRenderer.render(templateBytes, campos, datosFinales);
    }

    /**
     * Word de prueba del editor de plantillas: el DOCX en edición con los datos de prueba (sin validarlos).
     */
    public byte[] generarPrueba(byte[] docx, List<FieldDefinition> campos, Map<String, Object> datos) {
        return templateRenderer.render(docx, campos, FieldSchemaBuilder.aplicarReglas(campos, datos));
    }

    public Solicitud crearSolicitudDesdePlantilla(CrearSolicitudDesdePlantillaRequest req, UserAccount emisor) {
        return crearSolicitudDesdePlantilla(req, List.of(), emisor);
    }

    /**
     * Crea una nueva solicitud a partir de una plantilla, los datos del formulario y sus documentos adjuntos.
     * Aplica las mismas reglas que el registro con archivo: permiso, flujo ejecutable y ámbito de emisión.
     */
    public Solicitud crearSolicitudDesdePlantilla(CrearSolicitudDesdePlantillaRequest req, List<MultipartFile> anexos, UserAccount emisor) {
        if (emisor == null || emisor.getArea() == null) {
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "El usuario emisor no pertenece a ninguna área corporativa.");
        }
        if (req.plantillaId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El ID de plantilla es obligatorio.");
        }
        if (req.flujoId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El ID de flujo es obligatorio.");
        }
        if (req.titulo() == null || req.titulo().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El título de la solicitud es obligatorio.");
        }
        List<MultipartFile> adjuntos = anexoService != null ? anexoService.validar(anexos) : List.of();

        if (rbacManagement != null) rbacManagement.lockPolicy();
        if (rbac != null) rbac.require(Permiso.SOLICITUD_CREAR);
        FlujoDefinicion flujo = concurrency != null ? concurrency.lockDefinition(req.flujoId()) : null;
        if (integrity != null && flujo != null) {
            integrity.requireExecutable(flujo, true);
        }
        if (rbac != null && flujo != null) {
            rbac.requireFlowEmissionScope(flujo);
        }

        FormularioPlantillaDto form = plantillaService.obtenerFormulario(req.plantillaId());
        if (req.plantillaVersion() != null && req.plantillaVersion() != form.version()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El formulario se completó con la versión " + req.plantillaVersion()
                    + " de la plantilla, pero la vigente es la versión " + form.version() + ". Revise los campos y vuelva a enviar.");
        }
        // Se valida y se renderiza con la misma versión que entregó el formulario.
        PlantillaVersion version = plantillaService.obtenerVersion(req.plantillaId(), form.version());
        List<FieldDefinition> campos = form.campos();
        Map<String, Object> datos = FieldSchemaBuilder.aplicarReglas(campos, req.datos());

        validarCampos(campos, datos);

        // F8 (§6.9): Si viene autocompletadoId, validar que sea del mismo usuario, COMPLETADA y misma versión
        if (req.autocompletadoId() != null && iaAutocompletadoService != null) {
            iaAutocompletadoService.validarAplicabilidad(req.autocompletadoId(), version, emisor);
        }

        byte[] templateBytes = plantillaService.obtenerArchivoVersion(req.plantillaId(), version.getVersion());
        byte[] renderedBytes = templateRenderer.render(templateBytes, campos, datos);

        UUID solicitudId = UUID.randomUUID();
        String safeName = nombreDocumento(form.nombre(), emisor, null);

        MinioStorageService.MinioUploadResult uploadResult;
        try {
            uploadResult = minioStorageService.uploadDocument(
                    solicitudId,
                    1,
                    safeName,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    new ByteArrayInputStream(renderedBytes),
                    renderedBytes.length
            );
        } catch (Exception e) {
            log.error("Error al almacenar documento generado en MinIO: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al guardar el documento generado en el almacenamiento.");
        }
        minioStorageService.deleteOnRollback(uploadResult.storageKey());

        String datosJson;
        try {
            datosJson = objectMapper.writeValueAsString(datos);
        } catch (Exception e) {
            datosJson = "{}";
        }

        Map<String, Object> extra = new java.util.LinkedHashMap<>();
        if (req.autocompletadoId() != null) {
            extra.put("autocompletadoIaId", req.autocompletadoId().toString());
        }

        RegistrarCommand cmd = new RegistrarCommand(
                req.titulo().trim(),
                req.descripcion(),
                req.flujoId(),
                form.tipoDocumentoId(),
                emisor,
                safeName,
                uploadResult.contentType(),
                uploadResult.storageKey(),
                uploadResult.sizeBytes(),
                uploadResult.checksumSha256(),
                uploadResult.storageVersionId(),
                version,
                datosJson,
                extra
        );

        Solicitud solicitud = workflowService.registrar(cmd);
        if (integrity != null && flujo != null) {
            for (FlujoEtapa etapa : integrity.orderedStages(flujo)) {
                integrity.requireResponsibility(solicitud, etapa);
            }
        }
        if (anexoService != null) {
            anexoService.guardar(solicitud, solicitudId, adjuntos, emisor);
        }
        if (aiAnalysisService != null) {
            aiAnalysisService.evaluarDocumentoVigente(solicitud);
        }

        auditService.registerEvent(
                "DOCUMENTO_GENERADO",
                emisor,
                "Documento generado desde plantilla '" + form.nombre() + "' v" + version.getVersion() + " para solicitud "
                        + solicitud.getCorrelativo() + (adjuntos.isEmpty() ? "" : " con " + adjuntos.size() + " documento(s) adjunto(s)")
        );

        // F8 (§6.9): auditar IA_AUTOCOMPLETADO_USADO
        if (req.autocompletadoId() != null) {
            String datosAudit = "{\"autocompletadoId\":\"" + req.autocompletadoId() + "\"}";
            String entId = solicitud.getId() != null ? solicitud.getId().toString() : "";
            auditService.registerAuditEvent("IA_AUTOCOMPLETADO_USADO", "solicitud", entId, "EXITO", datosAudit);
            log.info("Autocompletado de IA {} usado en creación de solicitud {}", req.autocompletadoId(), entId);
        }

        return solicitud;
    }

    /**
     * Corrige una solicitud reenviando un nuevo documento renderizado a partir de datos actualizados de la plantilla.
     */
    public Solicitud corregirSolicitudDesdePlantilla(UUID solicitudId, CorregirSolicitudDesdePlantillaRequest req, UserAccount emisor) {
        // Mismas reglas que el reenvío con archivo, antes de renderizar y subir nada.
        Solicitud solicitud = concurrency.lockRequest(solicitudId, req.version());
        rbac.authorize(solicitudId, Permiso.SOLICITUD_REENVIAR);
        integrity.requireCurrentStage(solicitud);

        Documento docVigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No se encontró el documento vigente de la solicitud."));

        PlantillaVersion pltVersion = docVigente.getPlantillaVersion();
        if (pltVersion == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Esta solicitud no fue generada a partir de una plantilla.");
        }
        if (req.titulo() != null && req.titulo().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El título de la solicitud es obligatorio.");
        }

        // F8 (§6.9): Si viene autocompletadoId, validar que sea del mismo usuario, COMPLETADA y misma versión
        if (req.autocompletadoId() != null && iaAutocompletadoService != null) {
            iaAutocompletadoService.validarAplicabilidad(req.autocompletadoId(), pltVersion, emisor);
        }

        List<FieldDefinition> campos = schemaBuilder.parseFields(pltVersion.getEsquemaCampos());
        Map<String, Object> datos = FieldSchemaBuilder.aplicarReglas(campos, req.datos());
        validarCampos(campos, datos);

        byte[] templateBytes = plantillaService.obtenerArchivoVersion(pltVersion.getPlantilla().getId(), pltVersion.getVersion());
        byte[] renderedBytes = templateRenderer.render(templateBytes, campos, datos);

        int nuevaVersionDoc = docVigente.getVersion() + 1;
        String safeName = nombreDocumento(pltVersion.getPlantilla().getNombre(), solicitud.getEmisor(), nuevaVersionDoc - 1);

        MinioStorageService.MinioUploadResult uploadResult;
        try {
            uploadResult = minioStorageService.uploadDocument(
                    solicitudId,
                    nuevaVersionDoc,
                    safeName,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    new ByteArrayInputStream(renderedBytes),
                    renderedBytes.length
            );
        } catch (Exception e) {
            log.error("Error al almacenar documento corregido en MinIO: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al guardar el documento corregido en el almacenamiento.");
        }
        minioStorageService.deleteOnRollback(uploadResult.storageKey());

        if (req.titulo() != null) solicitud.setTitulo(req.titulo().trim());
        if (req.descripcion() != null) solicitud.setDescripcion(req.descripcion().trim());

        String datosJson;
        try {
            datosJson = objectMapper.writeValueAsString(datos);
        } catch (Exception e) {
            datosJson = "{}";
        }

        Map<String, Object> extra = new java.util.LinkedHashMap<>();
        if (req.autocompletadoId() != null) {
            extra.put("autocompletadoIaId", req.autocompletadoId().toString());
        }

        CorregirCommand cmd = new CorregirCommand(
                solicitudId,
                emisor,
                req.comentario() != null ? req.comentario() : "Corrección efectuada desde plantilla",
                safeName,
                uploadResult.contentType(),
                uploadResult.storageKey(),
                uploadResult.sizeBytes(),
                uploadResult.checksumSha256(),
                uploadResult.storageVersionId(),
                pltVersion,
                datosJson,
                req.version(),
                extra
        );

        Solicitud corregida = workflowService.corregir(cmd);
        if (aiAnalysisService != null) {
            aiAnalysisService.evaluarDocumentoVigente(corregida);
        }

        auditService.registerEvent(
                "DOCUMENTO_GENERADO",
                emisor,
                "Documento corregido desde plantilla '" + pltVersion.getPlantilla().getNombre() + "' v" + pltVersion.getVersion() + " para solicitud " + corregida.getCorrelativo()
        );

        return corregida;
    }

    /**
     * Nombre con que se descarga el Word generado: «Plantilla - Emisor - 30-10-2026.docx», y «(corrección N)» al
     * corregir. La clave en el almacenamiento se limpia aparte (MinioStorageService.cleanFilename).
     */
    static String nombreDocumento(String plantilla, UserAccount emisor, Integer correccion) {
        String base = parteDeNombre(plantilla, 100);
        String persona = parteDeNombre(emisor == null ? null : emisor.getNombre(), 80);
        StringBuilder nombre = new StringBuilder(base.isEmpty() ? "Documento" : base);
        if (!persona.isEmpty()) nombre.append(" - ").append(persona);
        nombre.append(" - ").append(LocalDate.now(ZONA_NEGOCIO).format(FECHA_ARCHIVO));
        if (correccion != null && correccion > 0) nombre.append(" (corrección ").append(correccion).append(')');
        return nombre.append(".docx").toString();
    }

    /** Quita los caracteres que no admiten los nombres de archivo y recorta a un largo razonable. */
    private static String parteDeNombre(String texto, int maximo) {
        if (texto == null) return "";
        String limpio = texto.replaceAll("[\\p{Cntrl}\\p{Cf}\\\\/:*?\"<>|]", " ").replaceAll("\\s+", " ").strip();
        return limpio.length() > maximo ? limpio.substring(0, maximo).strip() : limpio;
    }

    private void validarCampos(List<FieldDefinition> campos, Map<String, Object> datos) {
        List<FieldValidationError> errores = schemaBuilder.validateData(campos, datos);
        if (errores.isEmpty()) {
            return;
        }
        Map<String, String> porCampo = new LinkedHashMap<>();
        errores.forEach(err -> porCampo.putIfAbsent(err.field(), err.message()));
        ResponseStatusException ex = new ResponseStatusException(HttpStatus.BAD_REQUEST,
                "Errores de validación en el formulario: " + String.join(" ", porCampo.values()));
        // invalidFields (clave del campo -> mensaje) permite marcar cada campo en el formulario.
        ex.getBody().setProperty("invalidFields", porCampo);
        throw ex;
    }
}
