package com.capstone.sistema.flow.dto;

import java.util.List;
import java.util.UUID;
import com.capstone.sistema.flow.model.TipoAccionEtapa;
import com.capstone.sistema.flow.model.TipoAsignacionRevisor;

/**
 * Etapa de un flujo. {@code revisores} es la lista completa ordenada por nombre (D-05);
 * {@code revisorId}/{@code revisorNombre}/{@code revisorEmail} repiten el primer elemento por compatibilidad.
 * {@code revisorIds} repite los ids de {@code revisores} en el mismo orden.
 */
public record FlujoEtapaResponse(
        Long id,
        int orden,
        String nombre,
        UUID revisorId,
        String revisorNombre,
        String revisorEmail,
        TipoAccionEtapa tipoAccion,
        TipoAsignacionRevisor tipoAsignacion,
        boolean responsableDisponible,
        Integer revisoresDisponibles,
        String modoRevisor,
        List<Revisor> revisores,
        List<UUID> revisorIds,

        /** F6 (§6.5): criterio de IA de la etapa; null cuando no tiene. */
        String criterioIa
) {
    /** Revisor de la etapa. {@code nombre} y {@code nombreCompleto} llevan el mismo valor (email si no hay nombre). */
    public record Revisor(UUID id, String nombre, String nombreCompleto, String email, boolean activo) {}

    public FlujoEtapaResponse {
        revisores = revisores == null ? List.of() : List.copyOf(revisores);
        revisorIds = revisores.stream().map(Revisor::id).toList();
    }

    public FlujoEtapaResponse(Long id, int orden, String nombre, UUID revisorId, String revisorNombre, String revisorEmail,
                              TipoAccionEtapa tipoAccion, TipoAsignacionRevisor tipoAsignacion,
                              boolean responsableDisponible, Integer revisoresDisponibles,
                              String modoRevisor, List<Revisor> revisores) {
        this(id, orden, nombre, revisorId, revisorNombre, revisorEmail, tipoAccion, tipoAsignacion,
             responsableDisponible, revisoresDisponibles, modoRevisor, revisores, null, null);
    }

    public FlujoEtapaResponse(Long id, int orden, String nombre, UUID revisorId, String revisorNombre, String revisorEmail,
                              TipoAccionEtapa tipoAccion, TipoAsignacionRevisor tipoAsignacion,
                              boolean responsableDisponible, Integer revisoresDisponibles,
                              String modoRevisor, List<Revisor> revisores, List<UUID> revisorIds) {
        this(id, orden, nombre, revisorId, revisorNombre, revisorEmail, tipoAccion, tipoAsignacion,
             responsableDisponible, revisoresDisponibles, modoRevisor, revisores, revisorIds, null);
    }

    public FlujoEtapaResponse(Long id, int orden, String nombre, UUID revisorId, String revisorNombre, String revisorEmail,
                              TipoAccionEtapa tipoAccion, TipoAsignacionRevisor tipoAsignacion,
                              boolean responsableDisponible, Integer revisoresDisponibles) {
        this(id, orden, nombre, revisorId, revisorNombre, revisorEmail, tipoAccion, tipoAsignacion,
             responsableDisponible, revisoresDisponibles, "LISTA",
             revisorId != null ? List.of(new Revisor(revisorId, revisorNombre, revisorNombre, revisorEmail, true)) : List.of());
    }

    public FlujoEtapaResponse(Long id, int orden, String nombre, UUID revisorId, String revisorNombre, String revisorEmail, TipoAccionEtapa tipoAccion) {
        this(id, orden, nombre, revisorId, revisorNombre, revisorEmail, tipoAccion, TipoAsignacionRevisor.USUARIO, revisorId != null, null);
    }

    public FlujoEtapaResponse(Long id, int orden, String nombre, UUID revisorId, String revisorNombre, String revisorEmail) {
        this(id, orden, nombre, revisorId, revisorNombre, revisorEmail, TipoAccionEtapa.REVISION);
    }
}
