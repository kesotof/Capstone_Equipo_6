package com.capstone.sistema.notificacion.exception;

import com.capstone.sistema.notificacion.controller.NotificacionAdminController;
import com.capstone.sistema.notificacion.controller.NotificacionController;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * F3 (§7): errores de la API de notificaciones con ProblemDetail (RFC 7807) y propiedad
 * {@code code}, igual que el resto del API.
 */
@RestControllerAdvice(assignableTypes = {NotificacionController.class, NotificacionAdminController.class})
@Order(Ordered.HIGHEST_PRECEDENCE + 46)
public class NotificacionExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ProblemDetail> invalida(IllegalArgumentException ex) {
        return error(HttpStatus.BAD_REQUEST, "Parámetro inválido", ex.getMessage(),
                "NOTIFICACION_PARAMETRO_INVALIDO");
    }

    /** Reenvío de un correo que no está FALLIDO (§7.1). */
    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<ProblemDetail> conflicto(IllegalStateException ex) {
        return error(HttpStatus.CONFLICT, "Estado de correo incompatible", ex.getMessage(),
                "CORREO_NO_FALLIDO");
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> denegado(AccessDeniedException ex) {
        return error(HttpStatus.FORBIDDEN, "Control de acceso", ex.getMessage(), "RBAC_ACCION_DENEGADA");
    }

    private ResponseEntity<ProblemDetail> error(HttpStatus status, String title, String detail, String code) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setProperty("code", code);
        return ResponseEntity.status(status)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .cacheControl(CacheControl.noStore())
                .body(problem);
    }
}
