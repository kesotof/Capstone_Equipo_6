package com.capstone.sistema.users.controller;

import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.ToggleUserStatusRequest;
import com.capstone.sistema.users.dto.UpdateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.service.UserManagementService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@Tag(name = "Usuarios", description = "Administración y sincronización de usuarios con Keycloak")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/users")
@PreAuthorize("isAuthenticated()")
public class UserController {

    private final UserManagementService userManagementService;
    private final RbacAccessService access;

    public UserController(UserManagementService userManagementService, RbacAccessService access) {
        this.userManagementService = userManagementService;
        this.access = access;
    }

    /** Mutaciones y lectura individual: USUARIO.GESTIONAR (Permiso.USUARIO_GESTIONAR). */
    private void requireGestionUsuarios() {
        access.require(Permiso.USUARIO_GESTIONAR);
    }

    @PostMapping
    public ResponseEntity<UserResponse> createUser(@Valid @RequestBody CreateUserRequest request) {
        requireGestionUsuarios();
        UserResponse created = userManagementService.createUser(request);
        return ResponseEntity.created(URI.create("/api/users/" + created.id())).body(created);
    }

    /** Listado: USUARIO.GESTIONAR, o AREA.GESTIONAR (la pantalla de áreas lo usa para elegir miembros y jefaturas). */
    @GetMapping
    public ResponseEntity<List<UserResponse>> listUsers() {
        access.requireAny(Permiso.USUARIO_GESTIONAR, Permiso.AREA_GESTIONAR);
        return ResponseEntity.ok(userManagementService.listUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable UUID id) {
        requireGestionUsuarios();
        return ResponseEntity.ok(userManagementService.getUserById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> updateUser(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateUserRequest request
    ) {
        requireGestionUsuarios();
        return ResponseEntity.ok(userManagementService.updateUser(id, request));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<UserResponse> toggleStatus(
            @PathVariable UUID id,
            @Valid @RequestBody ToggleUserStatusRequest request
    ) {
        requireGestionUsuarios();
        return ResponseEntity.ok(userManagementService.toggleUserStatus(id, request.enabled()));
    }

    @PostMapping("/{id}/unlock")
    public ResponseEntity<UserResponse> unlockUser(@PathVariable UUID id) {
        requireGestionUsuarios();
        return ResponseEntity.ok(userManagementService.unlockUser(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable UUID id) {
        requireGestionUsuarios();
        userManagementService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    @io.swagger.v3.oas.annotations.Operation(summary = "Cambiar contraseña del usuario actualmente autenticado")
    @PostMapping("/me/change-password")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<java.util.Map<String, String>> changePassword(
            @Valid @RequestBody com.capstone.sistema.users.dto.ChangePasswordRequest request
    ) {
        userManagementService.changePassword(request);
        return ResponseEntity.ok(java.util.Map.of("message", "Contraseña actualizada exitosamente"));
    }
}
