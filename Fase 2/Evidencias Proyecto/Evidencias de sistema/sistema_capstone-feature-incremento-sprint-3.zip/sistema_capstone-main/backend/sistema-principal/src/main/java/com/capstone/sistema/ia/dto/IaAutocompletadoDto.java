package com.capstone.sistema.ia.dto;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * F8 (§7.2, US-29): DTO de respuesta para tareas de autocompletado de formulario con IA.
 */
public record IaAutocompletadoDto(
        UUID id,
        String estado,
        PlantillaDto plantilla,
        JsonNode campos,
        List<String> noEncontrados,
        IaEvaluacionDto.ErrorDto error,
        Instant createdAt,
        Instant completedAt
) {
    public record PlantillaDto(
            Long id,
            int version,
            String nombre
    ) {}
}
