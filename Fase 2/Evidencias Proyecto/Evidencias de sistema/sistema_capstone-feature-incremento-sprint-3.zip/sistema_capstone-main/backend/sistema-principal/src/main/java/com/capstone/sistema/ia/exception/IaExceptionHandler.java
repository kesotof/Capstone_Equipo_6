package com.capstone.sistema.ia.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * F6 (§7): manejo de excepciones de IA con ProblemDetail RFC 7807 y propiedad {@code code}.
 */
@RestControllerAdvice(basePackages = "com.capstone.sistema.ia.controller")
@Order(Ordered.HIGHEST_PRECEDENCE + 45)
public class IaExceptionHandler {

    @ExceptionHandler(IaException.class)
    public ResponseEntity<ProblemDetail> handleIaException(IaException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(ex.status(), ex.getMessage());
        problem.setTitle("Servicio de IA");
        problem.setProperty("code", ex.code());
        problem.setProperty("codigo", ex.code());
        problem.setProperty("message", ex.getMessage());
        return ResponseEntity.status(ex.status())
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .cacheControl(CacheControl.noStore())
                .body(problem);
    }
}
