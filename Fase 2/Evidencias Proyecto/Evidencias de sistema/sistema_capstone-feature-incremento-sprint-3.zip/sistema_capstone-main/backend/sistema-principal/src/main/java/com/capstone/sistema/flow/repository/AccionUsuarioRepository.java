package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.AccionUsuario;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AccionUsuarioRepository {

    public Optional<AccionUsuario> findByAccionIgnoreCase(String accion) {
        if (accion == null || accion.isBlank()) return Optional.empty();
        return Optional.of(new AccionUsuario(1L, accion.toUpperCase()));
    }

    public AccionUsuario save(AccionUsuario accion) {
        return accion;
    }
}
