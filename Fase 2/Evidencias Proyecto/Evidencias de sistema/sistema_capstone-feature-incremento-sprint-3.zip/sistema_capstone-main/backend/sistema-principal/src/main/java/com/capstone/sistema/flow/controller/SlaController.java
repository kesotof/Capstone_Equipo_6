package com.capstone.sistema.flow.controller;

import com.capstone.sistema.flow.dto.CreateSlaConfigRequest;
import com.capstone.sistema.flow.dto.SlaConfigResponse;
import com.capstone.sistema.flow.dto.UpdateSlaConfigRequest;
import com.capstone.sistema.flow.service.SlaService;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@Tag(name = "SLA", description = "Administración de plazos contractuales y tiempos de respuesta por tipo de documento")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/sla")
public class SlaController {

    private final SlaService slaService;
    private final RbacAccessService accessService;

    public SlaController(SlaService slaService, RbacAccessService accessService) {
        this.slaService = slaService;
        this.accessService = accessService;
    }

    /** Toda la matriz SLA (lectura y mutaciones) requiere TIPO_DOCUMENTO.GESTIONAR (enum SLA_GESTIONAR); 403 RBAC_ACCION_DENEGADA si no. */
    private void requireGestion() {
        accessService.requireAny(Permiso.SLA_GESTIONAR);
    }

    @Operation(summary = "Listar reglas SLA vigentes")
    @GetMapping
    public ResponseEntity<List<SlaConfigResponse>> listAll() {
        requireGestion();
        return ResponseEntity.ok(slaService.listAll());
    }

    @Operation(summary = "Obtener regla SLA por ID")
    @GetMapping("/{id}")
    public ResponseEntity<SlaConfigResponse> getById(@PathVariable Long id) {
        requireGestion();
        return ResponseEntity.ok(slaService.getById(id));
    }

    @Operation(summary = "Crear nueva regla SLA por tipo de documento")
    @PostMapping
    public ResponseEntity<SlaConfigResponse> create(@Valid @RequestBody CreateSlaConfigRequest request) {
        requireGestion();
        SlaConfigResponse created = slaService.create(request);
        return ResponseEntity.created(URI.create("/api/sla/" + created.id())).body(created);
    }

    @Operation(summary = "Actualizar plazo en días hábiles de una regla SLA")
    @PutMapping("/{id}")
    public ResponseEntity<SlaConfigResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateSlaConfigRequest request
    ) {
        requireGestion();
        return ResponseEntity.ok(slaService.update(id, request));
    }

    @Operation(summary = "Eliminar una regla SLA")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        requireGestion();
        slaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
