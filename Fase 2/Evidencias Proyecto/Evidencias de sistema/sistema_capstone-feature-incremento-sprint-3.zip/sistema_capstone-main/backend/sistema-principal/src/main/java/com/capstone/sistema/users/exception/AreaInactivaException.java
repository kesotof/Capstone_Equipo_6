package com.capstone.sistema.users.exception;

public class AreaInactivaException extends RuntimeException {
    public AreaInactivaException(String message) {
        super(message);
    }
}
