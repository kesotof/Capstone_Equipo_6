package com.capstone.sistema.audit.keycloak;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.idm.EventRepresentation;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.SimpleTransactionStatus;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class KeycloakEventosImporterTest {

    @Mock
    private Keycloak keycloakAdminClient;

    @Mock
    private RealmResource realmResource;

    @Mock
    private UserAccountRepository userAccountRepository;

    @Mock
    private IntegracionCursorRepository cursorRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    private KeycloakAdminProperties properties;
    private ObjectMapper objectMapper;
    private TransactionTemplate transactionTemplate;
    private KeycloakEventosImporter importer;

    @BeforeEach
    void setUp() {
        properties = new KeycloakAdminProperties("http://keycloak:8080", "master", "capstone-realm", "admin-cli", "admin", "admin");
        objectMapper = new ObjectMapper();

        PlatformTransactionManager tm = new PlatformTransactionManager() {
            @Override
            public TransactionStatus getTransaction(TransactionDefinition definition) {
                return new SimpleTransactionStatus();
            }

            @Override
            public void commit(TransactionStatus status) {
            }

            @Override
            public void rollback(TransactionStatus status) {
            }
        };
        transactionTemplate = new TransactionTemplate(tm);

        importer = new KeycloakEventosImporter(
                keycloakAdminClient,
                properties,
                userAccountRepository,
                cursorRepository,
                jdbcTemplate,
                transactionTemplate,
                objectMapper
        );
    }

    @Test
    @DisplayName("Si no obtiene advisory lock, retorna inmediatamente sin consultar Keycloak")
    void importarEventos_sinLock_noHaceNada() throws Exception {
        Connection con = mock(Connection.class);
        PreparedStatement psLock = mock(PreparedStatement.class);
        ResultSet rsLock = mock(ResultSet.class);

        when(con.prepareStatement("SELECT pg_try_advisory_lock(41030, 3)")).thenReturn(psLock);
        when(psLock.executeQuery()).thenReturn(rsLock);
        when(rsLock.next()).thenReturn(true);
        when(rsLock.getBoolean(1)).thenReturn(false);

        when(jdbcTemplate.execute(any(ConnectionCallback.class))).thenAnswer(inv -> {
            ConnectionCallback<?> cb = inv.getArgument(0);
            return cb.doInConnection(con);
        });

        importer.importarEventos();

        verifyNoInteractions(keycloakAdminClient);
        verifyNoInteractions(cursorRepository);
    }

    @Test
    @DisplayName("Fallo de conexión a Keycloak se registra en log y no interrumpe ejecución")
    void importarEventos_keycloakFalla_noLanzaExcepcion() {
        when(cursorRepository.findByNombre("KEYCLOAK_EVENTOS"))
                .thenReturn(Optional.of(new IntegracionCursor("KEYCLOAK_EVENTOS", "1000")));
        when(keycloakAdminClient.realm("capstone-realm")).thenReturn(realmResource);
        when(realmResource.getEvents(anyList(), isNull(), isNull(), anyString(), isNull(), isNull(), eq(0), eq(200)))
                .thenThrow(new RuntimeException("Connection refused"));

        importer.ejecutarLoteImportacion();

        verify(cursorRepository, never()).save(any());
        verify(jdbcTemplate, never()).update(anyString(), any(Object[].class));
    }

    @Test
    @DisplayName("UPDATE_PASSWORD sin solicitud previa se omite y no inserta")
    void importarEventos_updatePasswordSinSolicitudPrevia_seOmite() {
        IntegracionCursor cursor = new IntegracionCursor("KEYCLOAK_EVENTOS", "1000");
        when(cursorRepository.findByNombre("KEYCLOAK_EVENTOS")).thenReturn(Optional.of(cursor));
        when(keycloakAdminClient.realm("capstone-realm")).thenReturn(realmResource);

        EventRepresentation ev = new EventRepresentation();
        ev.setTime(2000L);
        ev.setType("UPDATE_PASSWORD");
        ev.setUserId("kc-solo-update");

        when(realmResource.getEvents(anyList(), isNull(), isNull(), anyString(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev));

        importer.ejecutarLoteImportacion();

        verify(jdbcTemplate, never()).update(eq(KeycloakEventosImporter.INSERTAR_EVENTO), any(), any(), any(), any(), any(), any(), any(), any(), any());
        assertThat(cursor.getValor()).isEqualTo("2000");
        verify(cursorRepository).save(cursor);
    }

    @Test
    @DisplayName("Importación exitosa mapea recuperación, valida solicitud previa y avanza el cursor")
    void importarEventos_exito_mapeaCasosYAvanzaCursor() {
        IntegracionCursor cursor = new IntegracionCursor("KEYCLOAK_EVENTOS", "1000");
        when(cursorRepository.findByNombre("KEYCLOAK_EVENTOS")).thenReturn(Optional.of(cursor));
        when(keycloakAdminClient.realm("capstone-realm")).thenReturn(realmResource);

        UUID userUuid = UUID.randomUUID();
        UserAccount user = new UserAccount("kc-123", "juan@test.cl", "Juan", "Perez", true);
        user.setId(userUuid);
        when(userAccountRepository.findByKeycloakUserId("kc-123")).thenReturn(Optional.of(user));

        EventRepresentation ev1 = new EventRepresentation();
        ev1.setTime(2000L);
        ev1.setType("SEND_RESET_PASSWORD");
        ev1.setUserId("kc-123");
        ev1.setIpAddress("192.168.1.10");
        ev1.setClientId("capstone-client");

        EventRepresentation ev2 = new EventRepresentation();
        ev2.setTime(3000L);
        ev2.setType("SEND_RESET_PASSWORD_ERROR");
        ev2.setIpAddress("192.168.1.11");
        ev2.setError("user_not_found");
        ev2.setDetails(Map.of("username", "desconocido@test.cl"));

        EventRepresentation ev3 = new EventRepresentation();
        ev3.setTime(4000L);
        ev3.setType("RESET_PASSWORD");
        ev3.setUserId("kc-123");
        ev3.setIpAddress("192.168.1.10");

        // UPDATE_PASSWORD con SEND_RESET_PASSWORD previo en memoria (ev1 tiempo 2000L, ev4 tiempo 5000L < 30m)
        EventRepresentation ev4 = new EventRepresentation();
        ev4.setTime(5000L);
        ev4.setType("UPDATE_PASSWORD");
        ev4.setUserId("kc-123");

        // Evento antiguo que debe ignorarse por estar <= cursorMs (1000)
        EventRepresentation evOld = new EventRepresentation();
        evOld.setTime(500L);
        evOld.setType("SEND_RESET_PASSWORD");
        evOld.setUserId("kc-123");

        when(realmResource.getEvents(anyList(), isNull(), isNull(), anyString(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev1, ev2, ev3, ev4, evOld));

        when(jdbcTemplate.update(eq(KeycloakEventosImporter.INSERTAR_EVENTO), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(1);

        importer.ejecutarLoteImportacion();

        // 4 eventos nuevos insertados (evOld ignorado por evTime <= cursorMs)
        verify(jdbcTemplate, times(4)).update(eq(KeycloakEventosImporter.INSERTAR_EVENTO), any(), any(), any(), any(), any(), any(), any(), any(), any());
        assertThat(cursor.getValor()).isEqualTo("5000");
        verify(cursorRepository, atLeastOnce()).save(cursor);
    }
}
