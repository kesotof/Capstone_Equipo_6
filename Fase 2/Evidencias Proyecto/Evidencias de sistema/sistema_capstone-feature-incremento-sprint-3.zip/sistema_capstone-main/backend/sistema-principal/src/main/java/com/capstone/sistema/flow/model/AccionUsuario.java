package com.capstone.sistema.flow.model;

import java.util.Objects;

public class AccionUsuario {

    private Long id;
    private String accion;

    public AccionUsuario() {
    }

    public AccionUsuario(String accion) {
        this.accion = accion;
    }

    public AccionUsuario(Long id, String accion) {
        this.id = id;
        this.accion = accion;
    }

    public Long getId() {
        return id;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccionUsuario that = (AccionUsuario) o;
        return Objects.equals(accion, that.accion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accion);
    }
}
