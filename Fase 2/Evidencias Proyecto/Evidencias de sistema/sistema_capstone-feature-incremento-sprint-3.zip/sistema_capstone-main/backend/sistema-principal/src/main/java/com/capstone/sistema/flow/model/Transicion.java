package com.capstone.sistema.flow.model;

import java.util.Objects;

public class Transicion {

    private Long id;
    private FlujoDefinicion flujoDefinicion;
    private EstadoSolicitud estadoOrigen;
    private EstadoSolicitud estadoDestino;
    private AccionUsuario accionUsuario;

    public Transicion() {
    }

    public Transicion(
            FlujoDefinicion flujoDefinicion,
            EstadoSolicitud estadoOrigen,
            EstadoSolicitud estadoDestino,
            AccionUsuario accionUsuario
    ) {
        this.flujoDefinicion = flujoDefinicion;
        this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.accionUsuario = accionUsuario;
    }

    public Long getId() {
        return id;
    }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public EstadoSolicitud getEstadoOrigen() {
        return estadoOrigen;
    }

    public void setEstadoOrigen(EstadoSolicitud estadoOrigen) {
        this.estadoOrigen = estadoOrigen;
    }

    public EstadoSolicitud getEstadoDestino() {
        return estadoDestino;
    }

    public void setEstadoDestino(EstadoSolicitud estadoDestino) {
        this.estadoDestino = estadoDestino;
    }

    public AccionUsuario getAccionUsuario() {
        return accionUsuario;
    }

    public void setAccionUsuario(AccionUsuario accionUsuario) {
        this.accionUsuario = accionUsuario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Transicion that = (Transicion) o;
        return Objects.equals(flujoDefinicion, that.flujoDefinicion) &&
                Objects.equals(estadoOrigen, that.estadoOrigen) &&
                Objects.equals(estadoDestino, that.estadoDestino) &&
                Objects.equals(accionUsuario, that.accionUsuario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(flujoDefinicion, estadoOrigen, estadoDestino, accionUsuario);
    }
}
