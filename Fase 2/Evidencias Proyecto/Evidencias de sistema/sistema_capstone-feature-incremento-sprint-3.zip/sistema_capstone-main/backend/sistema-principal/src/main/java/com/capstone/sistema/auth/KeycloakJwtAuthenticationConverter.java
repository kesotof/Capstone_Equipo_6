package com.capstone.sistema.auth;

import com.capstone.sistema.rbac.service.AdministradorGlobalService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.InvalidBearerTokenException;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Convierte el JWT de Keycloak en Authentication de Spring Security.
 *
 * <p>La identidad se toma de los claims ({@code sub}, {@code email}, {@code preferred_username}).
 * La autorización <b>no</b> viaja en las <i>authorities</i>: el backend decide por RBAC v5
 * ({@code RbacAccessService}), de modo que el token no aporta permisos.</p>
 *
 * <p>La única lectura del token es el rol de realm que define al administrador global
 * ({@code ADMIN} por defecto), que se refleja en {@code usuario_rol} mediante
 * {@link AdministradorGlobalService} y solo cuando hay diferencia (decisión D-A).</p>
 */
@Component
public class KeycloakJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final UserAccountRepository userAccountRepository;
    private final AdministradorGlobalService administradorGlobalService;

    @Autowired
    public KeycloakJwtAuthenticationConverter(
            UserAccountRepository userAccountRepository,
            AdministradorGlobalService administradorGlobalService) {
        this.userAccountRepository = userAccountRepository;
        this.administradorGlobalService = administradorGlobalService;
    }

    /** Constructor de conveniencia para pruebas unitarias sin sincronización con Keycloak. */
    public KeycloakJwtAuthenticationConverter(UserAccountRepository userAccountRepository) {
        this(userAccountRepository, null);
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        UserAccount localUser = requireActiveLocalUser(jwt);

        // El administrador global sale de Keycloak; se refleja en la base solo si hay diferencia.
        if (administradorGlobalService != null) {
            administradorGlobalService.reflejar(localUser, administradorGlobalService.esAdminSegunToken(jwt));
        }

        String principalName = jwt.getClaimAsString("email");
        if (principalName == null || principalName.isBlank()) {
            principalName = jwt.getClaimAsString("preferred_username");
        }

        return new JwtAuthenticationToken(jwt, Set.of(), principalName);
    }

    private UserAccount requireActiveLocalUser(Jwt jwt) {
        String keycloakUserId = jwt.getSubject();
        if (keycloakUserId == null || keycloakUserId.isBlank()) {
            throw new InvalidBearerTokenException("El token no contiene un identificador de usuario válido");
        }
        return userAccountRepository.findByKeycloakUserId(keycloakUserId)
                .filter(UserAccount::isEnabled)
                .orElseThrow(() -> new InvalidBearerTokenException("La cuenta no existe o no está habilitada"));
    }
}
