package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "v_documento_vigente")
@Immutable
public class VDocumentoVigente {

    @Id
    @Column(name = "id")
    private UUID id;

    @Column(name = "version")
    private Integer version;

    @Column(name = "nombre_archivo")
    private String nombreArchivo;

    @Column(name = "content_type")
    private String contentType;

    @Column(name = "storage_key")
    private String storageKey;

    @Column(name = "size_bytes")
    private Long sizeBytes;

    @Column(name = "checksum_sha256")
    private String checksumSha256;

    @Column(name = "reemplaza_documento_id")
    private UUID reemplazaDocumentoId;

    @Column(name = "solicitud_id")
    private UUID solicitudId;

    @Column(name = "flujo_etapa_id")
    private Long flujoEtapaId;

    @Column(name = "subido_por")
    private UUID subidoPor;

    @Column(name = "subido_en")
    private Instant subidoEn;

    public VDocumentoVigente() {
    }

    public UUID getId() {
        return id;
    }

    public Integer getVersion() {
        return version;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getContentType() {
        return contentType;
    }

    public String getStorageKey() {
        return storageKey;
    }

    public Long getSizeBytes() {
        return sizeBytes;
    }

    public String getChecksumSha256() {
        return checksumSha256;
    }

    public UUID getReemplazaDocumentoId() {
        return reemplazaDocumentoId;
    }

    public UUID getSolicitudId() {
        return solicitudId;
    }

    public Long getFlujoEtapaId() {
        return flujoEtapaId;
    }

    public UUID getSubidoPor() {
        return subidoPor;
    }

    public Instant getSubidoEn() {
        return subidoEn;
    }
}
