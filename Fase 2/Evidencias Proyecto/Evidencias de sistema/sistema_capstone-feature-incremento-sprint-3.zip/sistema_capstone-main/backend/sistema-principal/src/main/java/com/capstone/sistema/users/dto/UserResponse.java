package com.capstone.sistema.users.dto;

import java.time.Instant;
import java.util.UUID;

public record UserResponse(
        UUID id,
        String keycloakUserId,
        String email,
        String rut,
        String firstName,
        String lastName,
        Long areaId,
        String areaNombre,
        boolean enabled,
        boolean temporarilyLocked,
        Instant createdAt,
        java.util.List<com.capstone.sistema.rbac.dto.RbacDtos.ContextRole> rolesFuncionales,
        UUID jefaturaDirectaId,
        String jefaturaDirectaNombre,
        long versionAcceso
) {
    public UserResponse(UUID id,String keycloakUserId,String email,String rut,String firstName,String lastName,
                        Long areaId,String areaNombre,boolean enabled,boolean temporarilyLocked,Instant createdAt) {
        this(id,keycloakUserId,email,rut,firstName,lastName,areaId,areaNombre,enabled,temporarilyLocked,createdAt,java.util.List.of(),null,null,0);
    }

    @com.fasterxml.jackson.annotation.JsonProperty("activo")
    public boolean activo() {
        return enabled;
    }
}
