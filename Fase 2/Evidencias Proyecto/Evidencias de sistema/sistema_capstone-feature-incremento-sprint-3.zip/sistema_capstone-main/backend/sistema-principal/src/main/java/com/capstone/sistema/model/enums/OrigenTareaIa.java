package com.capstone.sistema.model.enums;

/** A-09: origen de la tarea de IA (disparo automático por transición o manual del usuario). */
public enum OrigenTareaIa {
    AUTOMATICO,
    MANUAL
}
