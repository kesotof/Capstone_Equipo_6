-- =============================================================================
-- V7__sprint3_mensajeria_ia_notificaciones.sql
-- Sprint 3: catálogo de notificaciones por rol (US-36), estado de correo (US-35),
-- criterio de IA por etapa y tareas de IA (US-29/30), clave externa de auditoría (US-27)
-- y cursor de integración. SQLSTATE nuevo: CB015.
-- =============================================================================

-- 1. Catálogo de tipos de notificación ----------------------------------------
ALTER TABLE tipo_notificacion
    ADD COLUMN categoria        VARCHAR(20) DEFAULT 'INFORMATIVA' NOT NULL
        CHECK (categoria IN ('ACCION_REQUERIDA', 'INFORMATIVA')),
    ADD COLUMN rol_destinatario VARCHAR(12) DEFAULT 'CUALQUIERA' NOT NULL
        CHECK (rol_destinatario IN ('EMISOR', 'REVISOR', 'CUALQUIERA')),
    ADD COLUMN envia_correo     BOOLEAN     DEFAULT false NOT NULL;

UPDATE tipo_notificacion SET categoria = 'ACCION_REQUERIDA', rol_destinatario = 'REVISOR', envia_correo = true
 WHERE codigo IN ('REVISION_ASIGNADA', 'PLAZO_POR_VENCER', 'PLAZO_VENCIDO');
UPDATE tipo_notificacion SET categoria = 'ACCION_REQUERIDA', rol_destinatario = 'EMISOR', envia_correo = true
 WHERE codigo = 'CORRECCION_REQUERIDA';
UPDATE tipo_notificacion SET categoria = 'INFORMATIVA', rol_destinatario = 'EMISOR', envia_correo = true
 WHERE codigo IN ('SOLICITUD_APROBADA', 'SOLICITUD_RECHAZADA');
UPDATE tipo_notificacion SET categoria = 'INFORMATIVA', rol_destinatario = 'EMISOR', envia_correo = false
 WHERE codigo = 'SOLICITUD_AVANZA';
UPDATE tipo_notificacion SET categoria = 'INFORMATIVA', rol_destinatario = 'REVISOR', envia_correo = false
 WHERE codigo = 'DECISION_ADMIN_GLOBAL';

-- 2. Notificación: enlace, idempotencia y estado del correo -------------------
ALTER TABLE notificacion
    ADD COLUMN enlace               VARCHAR(300),
    ADD COLUMN clave_dedup          VARCHAR(150),
    ADD COLUMN estado_correo        VARCHAR(10) DEFAULT 'NO_APLICA' NOT NULL
        CHECK (estado_correo IN ('NO_APLICA', 'PENDIENTE', 'ENVIADO', 'FALLIDO')),
    ADD COLUMN correo_publicado_en  TIMESTAMPTZ,
    ADD COLUMN correo_publicaciones SMALLINT    DEFAULT 0 NOT NULL CHECK (correo_publicaciones >= 0),
    ADD CONSTRAINT chk_notif_correo_publicado
        CHECK (estado_correo = 'NO_APLICA' OR correo_publicado_en IS NOT NULL);

CREATE UNIQUE INDEX uq_notif_clave_dedup ON notificacion (clave_dedup) WHERE clave_dedup IS NOT NULL;
CREATE INDEX idx_notif_correo_pendiente ON notificacion (correo_publicado_en) WHERE estado_correo = 'PENDIENTE';

-- 3. Intentos de envío (bitácora; V1 ya la hace inmutable con trg_notif_envio_inmutable, CB004)
ALTER TABLE notificacion_envio ADD COLUMN codigo_error VARCHAR(50);
CREATE INDEX idx_notif_envio_notificacion ON notificacion_envio (notificacion_id);

-- 4. Criterio de IA por etapa (D3-03) -----------------------------------------
-- trg_flujo_etapa_en_uso ya permite UPDATE si no cambian orden ni flujo:
-- el criterio se puede editar en flujos con solicitudes.
ALTER TABLE flujo_etapa ADD COLUMN criterio_ia TEXT
    CHECK (criterio_ia IS NULL OR char_length(btrim(criterio_ia)) BETWEEN 10 AND 4000);

-- 5. Tareas de IA (reemplaza ai_analysis) --------------------------------------
DROP TABLE ai_analysis;

CREATE TABLE ia_tarea (
    id                    UUID          DEFAULT gen_random_uuid() PRIMARY KEY,
    tipo                  VARCHAR(15)   NOT NULL CHECK (tipo IN ('EVALUACION', 'CHAT', 'AUTOCOMPLETAR')),
    origen                VARCHAR(12)   NOT NULL CHECK (origen IN ('AUTOMATICO', 'MANUAL')),
    estado                VARCHAR(12)   DEFAULT 'PENDIENTE' NOT NULL
        CHECK (estado IN ('PENDIENTE', 'COMPLETADA', 'FALLIDA')),
    solicitud_id          UUID          REFERENCES solicitud(id),
    documento_id          UUID          REFERENCES documento(id),
    flujo_etapa_id        BIGINT        REFERENCES flujo_etapa(id),
    plantilla_version_id  BIGINT        REFERENCES plantilla_version(id),
    fuente_bucket         VARCHAR(63),
    fuente_storage_key    VARCHAR(500),
    fuente_nombre_archivo VARCHAR(255),
    fuente_content_type   VARCHAR(100),
    instruccion           TEXT          NOT NULL CHECK (char_length(btrim(instruccion)) > 0),
    instruccion_sha256    VARCHAR(64)   NOT NULL CHECK (char_length(instruccion_sha256) = 64),
    resultado             JSONB,
    modelo                VARCHAR(100),
    codigo_error          VARCHAR(50),
    error_detalle         VARCHAR(2000),
    solicitado_por        UUID          REFERENCES usuario(id),
    publicado_en          TIMESTAMPTZ   DEFAULT now() NOT NULL,
    publicaciones         SMALLINT      DEFAULT 1 NOT NULL CHECK (publicaciones >= 1),
    created_at            TIMESTAMPTZ   DEFAULT now() NOT NULL,
    completed_at          TIMESTAMPTZ,
    CONSTRAINT chk_ia_refs_por_tipo CHECK (
        (tipo = 'EVALUACION'
            AND solicitud_id IS NOT NULL AND documento_id IS NOT NULL AND flujo_etapa_id IS NOT NULL
            AND plantilla_version_id IS NULL AND fuente_storage_key IS NULL)
     OR (tipo = 'CHAT' AND origen = 'MANUAL'
            AND solicitud_id IS NOT NULL AND documento_id IS NOT NULL
            AND plantilla_version_id IS NULL AND fuente_storage_key IS NULL)
     OR (tipo = 'AUTOCOMPLETAR' AND origen = 'MANUAL'
            AND solicitud_id IS NULL AND documento_id IS NULL AND flujo_etapa_id IS NULL
            AND plantilla_version_id IS NOT NULL AND fuente_bucket IS NOT NULL
            AND fuente_storage_key IS NOT NULL AND fuente_content_type IS NOT NULL)),
    CONSTRAINT chk_ia_manual_con_autor CHECK (origen = 'AUTOMATICO' OR solicitado_por IS NOT NULL),
    CONSTRAINT chk_ia_estado CHECK (
        (estado = 'PENDIENTE'  AND resultado IS NULL AND completed_at IS NULL)
     OR (estado = 'COMPLETADA' AND resultado IS NOT NULL AND completed_at IS NOT NULL)
     OR (estado = 'FALLIDA'    AND codigo_error IS NOT NULL AND completed_at IS NOT NULL))
);
-- Una evaluación automática por documento + etapa + criterio (idempotencia del disparo)
CREATE UNIQUE INDEX uq_ia_eval_automatica ON ia_tarea (documento_id, flujo_etapa_id, instruccion_sha256)
    WHERE tipo = 'EVALUACION' AND origen = 'AUTOMATICO';
-- Una tarea manual en curso por usuario, solicitud y tipo
CREATE UNIQUE INDEX uq_ia_manual_en_curso ON ia_tarea (solicitud_id, tipo, solicitado_por)
    WHERE estado = 'PENDIENTE' AND origen = 'MANUAL' AND solicitud_id IS NOT NULL;
CREATE INDEX idx_ia_solicitud   ON ia_tarea (solicitud_id, tipo, created_at);
CREATE INDEX idx_ia_pendiente   ON ia_tarea (publicado_en) WHERE estado = 'PENDIENTE';
CREATE INDEX idx_ia_solicitante ON ia_tarea (solicitado_por);
CREATE INDEX idx_ia_documento   ON ia_tarea (documento_id);

-- Una tarea terminada es inmutable; nunca se borra
CREATE OR REPLACE FUNCTION fn_ia_tarea_transicion()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' OR OLD.estado <> 'PENDIENTE' THEN
        RAISE EXCEPTION 'IA_TAREA terminada es inmutable' USING ERRCODE = 'CB015';
    END IF;
    IF NEW.tipo IS DISTINCT FROM OLD.tipo
       OR NEW.solicitud_id IS DISTINCT FROM OLD.solicitud_id
       OR NEW.documento_id IS DISTINCT FROM OLD.documento_id
       OR NEW.instruccion IS DISTINCT FROM OLD.instruccion THEN
        RAISE EXCEPTION 'IA_TAREA: datos de origen inmutables' USING ERRCODE = 'CB015';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_ia_tarea_transicion
BEFORE UPDATE OR DELETE ON ia_tarea
FOR EACH ROW EXECUTE FUNCTION fn_ia_tarea_transicion();

-- 6. Auditoría: clave de eventos externos (US-27) -----------------------------
ALTER TABLE log_evento ADD COLUMN clave_externa VARCHAR(150);
CREATE UNIQUE INDEX uq_log_clave_externa ON log_evento (clave_externa) WHERE clave_externa IS NOT NULL;

-- 7. Cursor de integraciones --------------------------------------------------
CREATE TABLE integracion_cursor (
    nombre     VARCHAR(50)  PRIMARY KEY,
    valor      VARCHAR(100) NOT NULL,
    updated_at TIMESTAMPTZ  DEFAULT now() NOT NULL
);
INSERT INTO integracion_cursor (nombre, valor) VALUES ('KEYCLOAK_EVENTOS', '0');

-- 8. Tipos de evento nuevos ---------------------------------------------------
INSERT INTO tipo_evento (codigo, categoria, descripcion) VALUES
    ('IA_CONSULTA_REALIZADA',        'FLUJO',          'Pregunta al asistente de IA sobre una solicitud'),
    ('IA_AUTOCOMPLETADO_SOLICITADO', 'FLUJO',          'Autocompletado de plantilla con IA solicitado'),
    ('IA_AUTOCOMPLETADO_USADO',      'FLUJO',          'Solicitud emitida con datos propuestos por IA'),
    ('CRITERIO_IA_ACTUALIZADO',      'ADMINISTRACION', 'Criterio de evaluación de IA de una etapa modificado'),
    ('CORREO_REENVIADO',             'ADMINISTRACION', 'Reenvío manual de un correo fallido')
ON CONFLICT (codigo) DO NOTHING;
