package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.SolicitudCompartida;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SolicitudCompartidaRepository extends JpaRepository<SolicitudCompartida, Long> {

    List<SolicitudCompartida> findBySolicitud_Id(UUID solicitudId);

    List<SolicitudCompartida> findByUsuario_Id(UUID usuarioId);

    List<SolicitudCompartida> findByArea_Id(Long areaId);
}
