package com.capstone.sistema.ia.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.ia.dto.IaAutocompletadoDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.exception.IaExceptionHandler;
import com.capstone.sistema.ia.service.IaAutocompletadoService;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(IaAutocompletadoController.class)
@Import({SecurityConfig.class, IaExceptionHandler.class})
class IaAutocompletadoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IaAutocompletadoService autocompletadoService;

    @MockBean
    private CurrentUserResolver currentUserResolver;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    private final UserAccount usuario = new UserAccount("kc-emisor", "emisor@test.cl", "Emisor", "Test", true);

    @Test
    @DisplayName("POST /api/ia/autocompletados inicia autocompletado y responde 202 Accepted")
    void iniciarAutocompletado_responde202Accepted() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuario));

        UUID tareaId = UUID.randomUUID();
        IaAutocompletadoDto dto = new IaAutocompletadoDto(
                tareaId, "PENDIENTE",
                new IaAutocompletadoDto.PlantillaDto(1L, 1, "Contrato"),
                null, List.of(), null, Instant.now(), null
        );

        when(autocompletadoService.iniciarAutocompletado(eq(1L), any(), any()))
                .thenReturn(dto);

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "factura.pdf", "application/pdf", "pdf bytes".getBytes()
        );

        mockMvc.perform(multipart("/api/ia/autocompletados")
                        .file(file)
                        .param("plantillaId", "1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.id").value(tareaId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"));
    }

    @Test
    @DisplayName("GET /api/ia/autocompletados/{id} responde 200 OK con el DTO")
    void consultarAutocompletado_responde200Ok() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuario));

        UUID tareaId = UUID.randomUUID();
        IaAutocompletadoDto dto = new IaAutocompletadoDto(
                tareaId, "COMPLETADA",
                new IaAutocompletadoDto.PlantillaDto(1L, 1, "Contrato"),
                null, List.of(), null, Instant.now(), Instant.now()
        );

        when(autocompletadoService.consultarAutocompletado(eq(tareaId), any()))
                .thenReturn(dto);

        mockMvc.perform(get("/api/ia/autocompletados/" + tareaId)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(tareaId.toString()))
                .andExpect(jsonPath("$.estado").value("COMPLETADA"));
    }

    @Test
    @DisplayName("POST /api/ia/autocompletados con formato no soportado responde 415")
    void iniciarAutocompletado_formatoInvalido_responde415() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(usuario));

        when(autocompletadoService.iniciarAutocompletado(eq(1L), any(), any()))
                .thenThrow(IaException.formatoNoSoportado("Formato no soportado"));

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "archivo.exe", "application/octet-stream", "bin".getBytes()
        );

        mockMvc.perform(multipart("/api/ia/autocompletados")
                        .file(file)
                        .param("plantillaId", "1")
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_USER"))))
                .andExpect(status().isUnsupportedMediaType())
                .andExpect(jsonPath("$.code").value("IA_FORMATO_NO_SOPORTADO"));
    }
}
