package com.capstone.sistema.flow.service;
import com.capstone.sistema.notificacion.controller.NotificacionController;
import com.capstone.sistema.notificacion.service.NotificacionService;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.AccionUsuario;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.HistorialTransicion;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.flow.model.SolicitudTransicion;
import com.capstone.sistema.flow.repository.AccionUsuarioRepository;
import com.capstone.sistema.flow.repository.EstadoSolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.HistorialTransicionRepository;
import com.capstone.sistema.flow.repository.ObservacionRepository;
import com.capstone.sistema.flow.repository.SolicitudRepository;
import com.capstone.sistema.flow.repository.SolicitudTransicionRepository;
import com.capstone.sistema.rbac.model.AccessContext;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.rbac.service.RbacManagementService;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.AreaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class SolicitudServiceAdminGlobalTest {

    private static final Instant AHORA = Instant.parse("2026-10-09T13:00:00Z");

    @Mock
    private SolicitudRepository solicitudRepository;
    @Mock
    private DocumentoRepository documentoRepository;
    @Mock
    private FormatoDocumentoRepository formatoDocumentoRepository;
    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;
    @Mock
    private FlujoEtapaRepository flujoEtapaRepository;
    @Mock
    private EstadoSolicitudRepository estadoSolicitudRepository;
    @Mock
    private AccionUsuarioRepository accionUsuarioRepository;
    @Mock
    private SolicitudTransicionRepository solicitudTransicionRepository;
    @Mock
    private HistorialTransicionRepository historialTransicionRepository;
    @Mock
    private ObservacionRepository observacionRepository;
    @Mock
    private MinioStorageService storageService;
    @Mock
    private NotificacionService notificacionService;
    @Mock
    private AuditService auditService;
    @Mock
    private CurrentUserResolver currentUserResolver;
    @Mock
    private AreaRepository areaRepository;
    @Mock
    private RbacAccessService rbac;
    @Mock
    private RbacManagementService rbacManagementService;
    @Mock
    private FlujoConcurrencyService concurrency;
    @Mock
    private FlujoIntegrityService integrity;
    @Mock
    private com.capstone.sistema.users.repository.UserAccountRepository userAccountRepository;

    private SolicitudService service;
    private com.capstone.sistema.notificacion.service.NotificacionTransicionListener notificacionTransicionListener;
    private org.springframework.context.ApplicationEventPublisher eventPublisher;

    private UserAccount emisor;
    private UserAccount admin;
    private UserAccount revisor;
    private UserAccount revisor2;
    private UUID solicitudId;
    private Solicitud solicitud;
    private FlujoEtapa etapa;

    @BeforeEach
    void setUp() {
        notificacionTransicionListener = new com.capstone.sistema.notificacion.service.NotificacionTransicionListener(
                notificacionService, solicitudRepository, userAccountRepository, flujoEtapaRepository);
        eventPublisher = evento -> notificacionTransicionListener.onTransicion(
                (com.capstone.sistema.flow.event.TransicionSolicitudEvent) evento);

        service = new SolicitudService(
                solicitudRepository,
                documentoRepository,
                formatoDocumentoRepository,
                flujoDefinicionRepository,
                flujoEtapaRepository,
                estadoSolicitudRepository,
                accionUsuarioRepository,
                solicitudTransicionRepository,
                observacionRepository,
                storageService,
                notificacionService,
                auditService,
                currentUserResolver,
                null,
                areaRepository,
                rbac,
                rbacManagementService,
                concurrency,
                integrity,
                Clock.fixed(AHORA, ZoneOffset.UTC),
                null,
                historialTransicionRepository,
                null,
                eventPublisher
        );

        emisor = usuario("kc-emisor", "emisor@test.local", "Juan", "Emisor");
        admin = usuario("kc-admin", "admin@test.local", "Super", "Admin");
        revisor = usuario("kc-revisor", "revisor@test.local", "Carlos", "Revisor");
        revisor2 = usuario("kc-revisor2", "revisor2@test.local", "Ana", "Revisora");

        when(userAccountRepository.findById(any(UUID.class))).thenAnswer(inv -> {
            UUID id = inv.getArgument(0);
            return java.util.Optional.ofNullable(
                    java.util.List.of(emisor, admin, revisor, revisor2).stream()
                            .filter(u -> u.getId() != null && u.getId().equals(id))
                            .findFirst().orElse(null));
        });

        FlujoDefinicion flujo = new FlujoDefinicion("Revisión Simple", "Flujo base");
        ReflectionTestUtils.setField(flujo, "id", 1L);
        etapa = new FlujoEtapa(flujo, 1, "Revisión");
        ReflectionTestUtils.setField(etapa, "id", 1L);

        solicitudId = UUID.randomUUID();
        solicitud = nuevaSolicitud(new EstadoSolicitud(1L, "PENDIENTE_REVISION"), flujo);

        // El listener de transición resuelve la solicitud por id dentro de la misma transacción.
        when(solicitudRepository.findById(solicitudId)).thenReturn(Optional.of(solicitud));

        // Dependencias comunes: la solicitud se bloquea y se lee tal cual, un único paso de flujo.
        when(concurrency.lockRequest(eq(solicitudId), isNull())).thenReturn(solicitud);
        when(integrity.orderedStages(any())).thenReturn(List.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase(anyString())).thenAnswer(i ->
                Optional.of(new EstadoSolicitud(10L, i.getArgument(0))));
        when(accionUsuarioRepository.findByAccionIgnoreCase(anyString())).thenAnswer(i ->
                Optional.of(new AccionUsuario(20L, i.getArgument(0))));
        when(solicitudTransicionRepository.save(nullable(SolicitudTransicion.class))).thenAnswer(i -> i.getArgument(0));
    }

    private UserAccount usuario(String keycloakId, String email, String nombre, String apellido) {
        UserAccount u = new UserAccount(keycloakId, email, nombre, apellido, true);
        ReflectionTestUtils.setField(u, "id", UUID.randomUUID());
        return u;
    }

    private Solicitud nuevaSolicitud(EstadoSolicitud estado, FlujoDefinicion flujo) {
        Solicitud s = new Solicitud(flujo, emisor, "Documento A", "Descripción", estado, etapa);
        ReflectionTestUtils.setField(s, "id", solicitudId);
        return s;
    }

    /**
     * Configura quién actúa, si es admin global y si es revisor asignado de la etapa actual.
     * El contexto de admin solo se publica como tal cuando corresponde.
     */
    private void actuar(UserAccount actor, boolean esAdmin, boolean esRevisorEtapa) {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(actor));
        when(rbac.context()).thenReturn(new AccessContext(
                actor.getId(), null, null, esAdmin, Set.of(), true, List.of(), List.of(),
                Map.<Permiso, Set<com.capstone.sistema.rbac.model.Alcance>>of(), 1L, 1L));
        when(rbac.esRevisorEtapaActual(solicitudId, actor.getId())).thenReturn(esRevisorEtapa);
        when(rbac.revisoresEtapaActual(solicitudId)).thenReturn(List.of(revisor.getId(), revisor2.getId()));
    }

    private void ejecutar(String accion) {
        switch (accion) {
            case "APROBAR" -> service.aprobar(solicitudId);
            case "RECHAZAR" -> service.rechazar(solicitudId, "Motivo de rechazo");
            case "PEDIR_CORRECCION" -> service.pedirCorreccion(solicitudId, "Observación de corrección");
            default -> throw new IllegalArgumentException(accion);
        }
    }

    private String metadataDelHistorial() {
        ArgumentCaptor<HistorialTransicion> captor = ArgumentCaptor.forClass(HistorialTransicion.class);
        verify(historialTransicionRepository).saveAndFlush(captor.capture());
        return captor.getValue().getMetadata();
    }

    // ---------------------------------------------------------------- [US-37] admin no revisor

    @Test
    @DisplayName("[US-37] Admin no revisor aprueba: el historial queda marcado con actuoComoAdmin y avisa a los revisores")
    void adminNoRevisorApruebaMarcaHistorialYNotificaRevisores() {
        actuar(admin, true, false);

        service.aprobar(solicitudId);

        assertThat(metadataDelHistorial()).isEqualTo("{\"actuoComoAdmin\":true}");
        verify(notificacionService).notificarDecisionAdmin(eq(solicitud),
                any(com.capstone.sistema.notificacion.dto.NotificacionContexto.class),
                eq(List.of(revisor.getId(), revisor2.getId())));
        verify(auditService).registerUserManagementEvent(eq("APROBAR_SOLICITUD"), eq(admin),
                contains("[actuoComoAdmin=true]"));
    }

    @Test
    @DisplayName("[US-37] Admin no revisor rechaza: el historial queda marcado con actuoComoAdmin y avisa a los revisores")
    void adminNoRevisorRechazaMarcaHistorialYNotificaRevisores() {
        actuar(admin, true, false);

        service.rechazar(solicitudId, "No cumple con las normas");

        assertThat(metadataDelHistorial()).isEqualTo("{\"actuoComoAdmin\":true}");
        verify(notificacionService).notificarDecisionAdmin(eq(solicitud),
                any(com.capstone.sistema.notificacion.dto.NotificacionContexto.class),
                eq(List.of(revisor.getId(), revisor2.getId())));
        verify(auditService).registerUserManagementEvent(eq("RECHAZAR_SOLICITUD"), eq(admin),
                contains("[actuoComoAdmin=true]"));
    }

    @Test
    @DisplayName("[US-37] Admin no revisor pide corrección: el historial queda marcado y avisa a los revisores")
    void adminNoRevisorPideCorreccionMarcaHistorialYNotificaRevisores() {
        actuar(admin, true, false);

        service.pedirCorreccion(solicitudId, "Falta firma en página 3");

        assertThat(metadataDelHistorial()).isEqualTo("{\"actuoComoAdmin\":true}");
        verify(notificacionService).notificarDecisionAdmin(eq(solicitud),
                any(com.capstone.sistema.notificacion.dto.NotificacionContexto.class),
                eq(List.of(revisor.getId(), revisor2.getId())));
        verify(auditService).registerUserManagementEvent(eq("PEDIR_CORRECCION"), eq(admin),
                contains("[actuoComoAdmin=true]"));
    }

    // ---------------------------------------------------------------- [US-37] revisor asignado

    @ParameterizedTest(name = "[US-37] revisor asignado con admin={1} ejecuta {0} sin marca de actuación admin")
    @CsvSource({
            "APROBAR,true",
            "APROBAR,false",
            "RECHAZAR,true",
            "RECHAZAR,false",
            "PEDIR_CORRECCION,true",
            "PEDIR_CORRECCION,false"
    })
    void revisorAsignadoNoMarcaActuacionNiNotificaRevisores(String accion, boolean esAdmin) {
        actuar(revisor, esAdmin, true);

        ejecutar(accion);

        assertThat(metadataDelHistorial()).isEqualTo("{}");
        verify(notificacionService, never()).notificarDecisionAdmin(
                any(), any(com.capstone.sistema.notificacion.dto.NotificacionContexto.class), any());
        verify(auditService, never()).registerUserManagementEvent(anyString(), any(), contains("actuoComoAdmin"));
    }

    // ---------------------------------------------------------------- [US-37] reenviar

    @Test
    @DisplayName("[US-37] Reenviar: el admin que no es emisor es rechazado aunque tenga el permiso global")
    void reenviarAdminNoEmisorEsRechazado() {
        Solicitud corregida = nuevaSolicitud(new EstadoSolicitud(2L, "CORRECCION_REQUERIDA"),
                solicitud.getFlujoDefinicion());
        when(concurrency.lockRequest(eq(solicitudId), isNull())).thenReturn(corregida);
        actuar(admin, true, false);

        assertThatThrownBy(() -> service.reenviar(solicitudId, "Nuevo título", "Nueva descripción", null))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("Solo el emisor original puede reenviar");

        verify(notificacionService, never()).notificarRevisionAsignada(any(),
                any(com.capstone.sistema.notificacion.dto.NotificacionContexto.class));
        verify(solicitudTransicionRepository, never()).save(any());
    }
}
