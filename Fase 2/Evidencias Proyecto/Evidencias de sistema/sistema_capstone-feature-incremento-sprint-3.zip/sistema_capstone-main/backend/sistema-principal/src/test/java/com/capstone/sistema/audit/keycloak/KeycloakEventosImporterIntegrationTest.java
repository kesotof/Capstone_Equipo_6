package com.capstone.sistema.audit.keycloak;

import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.UserAccountRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.*;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.idm.EventRepresentation;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * C1 — Pruebas de integración contra PostgreSQL real para KeycloakEventosImporter.
 * Verifica la sintaxis ON CONFLICT sobre el índice único parcial de clave_externa,
 * la longitud de entidad_id (solo UUID si existe o null), deduplicación real,
 * filtro de 30m para UPDATE_PASSWORD, paginación múltiple y tolerancia a fallos SQL.
 * Nota: log_evento es inmutable (trigger fn_log_evento_inmutable), por lo que
 * cada caso de prueba genera sus propios timestamps únicos.
 */
class KeycloakEventosImporterIntegrationTest {

    private static DataSource dataSource;
    private static JdbcTemplate jdbc;
    private static TransactionTemplate transactionTemplate;
    private static final AtomicLong TIME_GEN = new AtomicLong(1800000000000L);

    private Keycloak keycloakAdminClient;
    private RealmResource realmResource;
    private UserAccountRepository userAccountRepository;
    private IntegracionCursorRepository cursorRepository;
    private KeycloakAdminProperties properties;
    private ObjectMapper objectMapper;
    private KeycloakEventosImporter importer;

    private UUID usuarioRealId;
    private String usuarioRealEmail = "admin@test.cl";
    private String usuarioRealKcId = "kc-admin-uuid";

    @BeforeAll
    static void setupDatabase() {
        dataSource = resolveDataSource();
        Assumptions.assumeTrue(dataSource != null,
                "PostgreSQL de pruebas no disponible; se omite KeycloakEventosImporterIntegrationTest");

        Flyway flyway = Flyway.configure()
                .dataSource(dataSource)
                .locations("classpath:db/migration")
                .cleanDisabled(false)
                .load();
        flyway.clean();
        flyway.migrate();

        jdbc = new JdbcTemplate(dataSource);
        DataSourceTransactionManager tm = new DataSourceTransactionManager(dataSource);
        transactionTemplate = new TransactionTemplate(tm);
    }

    private static DataSource resolveDataSource() {
        String customUrl = System.getenv("TEST_DATASOURCE_URL");
        if (customUrl != null && !customUrl.isBlank()) {
            DriverManagerDataSource ds = new DriverManagerDataSource();
            ds.setDriverClassName("org.postgresql.Driver");
            ds.setUrl(customUrl);
            ds.setUsername(System.getenv().getOrDefault("TEST_DATASOURCE_USER", "sistema_user"));
            ds.setPassword(System.getenv().getOrDefault("TEST_DATASOURCE_PASS", "sistema_secure_pass"));
            return ds;
        }
        String[] candidateHosts = new String[]{"host.docker.internal", "localhost", "postgres"};
        for (String host : candidateHosts) {
            try {
                DriverManagerDataSource ds = new DriverManagerDataSource();
                ds.setDriverClassName("org.postgresql.Driver");
                ds.setUrl("jdbc:postgresql://" + host + ":5432/sistema_v5_test");
                ds.setUsername("sistema_user");
                ds.setPassword("sistema_secure_pass");
                try (Connection conn = ds.getConnection()) {
                    return ds;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    @BeforeEach
    void setUp() {
        jdbc.execute("DELETE FROM integracion_cursor WHERE nombre = 'KEYCLOAK_EVENTOS'");

        // Asegurar que exista al menos un usuario real en la base de datos
        List<Map<String, Object>> usuarios = jdbc.queryForList("SELECT id, email, keycloak_id FROM usuario LIMIT 1");
        if (usuarios.isEmpty()) {
            usuarioRealId = UUID.randomUUID();
            usuarioRealEmail = "admin@test.cl";
            usuarioRealKcId = "kc-" + usuarioRealId;
            jdbc.update("INSERT INTO usuario (id, email, nombre, apellido, keycloak_id, activo, created_at, updated_at) " +
                            "VALUES (?, ?, 'Admin', 'Test', ?, true, NOW(), NOW())",
                    usuarioRealId, usuarioRealEmail, usuarioRealKcId);
        } else {
            usuarioRealId = (UUID) usuarios.get(0).get("id");
            usuarioRealEmail = (String) usuarios.get(0).get("email");
            usuarioRealKcId = (String) usuarios.get(0).get("keycloak_id");
            if (usuarioRealKcId == null) {
                usuarioRealKcId = "kc-" + usuarioRealId;
                jdbc.update("UPDATE usuario SET keycloak_id = ? WHERE id = ?", usuarioRealKcId, usuarioRealId);
            }
        }

        keycloakAdminClient = mock(Keycloak.class);
        realmResource = mock(RealmResource.class);
        when(keycloakAdminClient.realm(anyString())).thenReturn(realmResource);

        userAccountRepository = mock(UserAccountRepository.class);
        UserAccount mockUser = new UserAccount(usuarioRealKcId, usuarioRealEmail, "Admin", "Test", true);
        mockUser.setId(usuarioRealId);
        lenient().when(userAccountRepository.findByKeycloakUserId(usuarioRealKcId)).thenReturn(Optional.of(mockUser));
        lenient().when(userAccountRepository.findByEmailIgnoreCase(usuarioRealEmail)).thenReturn(Optional.of(mockUser));

        cursorRepository = mock(IntegracionCursorRepository.class);
        when(cursorRepository.findByNombre(anyString())).thenAnswer(inv -> {
            String nombre = inv.getArgument(0);
            List<IntegracionCursor> list = jdbc.query(
                    "SELECT nombre, valor FROM integracion_cursor WHERE nombre = ?",
                    (rs, i) -> new IntegracionCursor(rs.getString("nombre"), rs.getString("valor")),
                    nombre
            );
            return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
        });
        when(cursorRepository.save(any(IntegracionCursor.class))).thenAnswer(inv -> {
            IntegracionCursor c = inv.getArgument(0);
            jdbc.update(
                    "INSERT INTO integracion_cursor (nombre, valor, updated_at) VALUES (?, ?, NOW()) " +
                            "ON CONFLICT (nombre) DO UPDATE SET valor = EXCLUDED.valor, updated_at = NOW()",
                    c.getNombre(), c.getValor()
            );
            return c;
        });

        properties = new KeycloakAdminProperties("http://keycloak:8080", "master", "capstone-realm", "admin-cli", "admin", "admin");
        objectMapper = new ObjectMapper();

        importer = new KeycloakEventosImporter(
                keycloakAdminClient,
                properties,
                userAccountRepository,
                cursorRepository,
                jdbc,
                transactionTemplate,
                objectMapper
        );
    }

    @Test
    @DisplayName("SEND_RESET_PASSWORD de usuario existente inserta 1 fila con usuario_id y entidad_id = usuarioId")
    void sendResetPassword_usuarioExistente_insertaCorrecto() {
        long t = TIME_GEN.addAndGet(100000L);
        EventRepresentation ev = new EventRepresentation();
        ev.setTime(t);
        ev.setType("SEND_RESET_PASSWORD");
        ev.setUserId(usuarioRealKcId);
        ev.setIpAddress("127.0.0.1");

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev));

        importer.ejecutarLoteImportacion();

        Map<String, Object> fila = jdbc.queryForMap(
                "SELECT le.usuario_id, le.entidad_id, le.resultado, le.ip_address, te.codigo as tipo " +
                        "FROM log_evento le JOIN tipo_evento te ON le.tipo_evento_id = te.id " +
                        "WHERE le.clave_externa = ?",
                "kc:" + t + ":SEND_RESET_PASSWORD:" + usuarioRealKcId
        );

        assertThat(fila.get("usuario_id")).isEqualTo(usuarioRealId);
        assertThat(fila.get("entidad_id")).isEqualTo(usuarioRealId.toString());
        assertThat(fila.get("resultado")).isEqualTo("EXITO");
        assertThat(fila.get("ip_address")).isEqualTo("127.0.0.1");
        assertThat(fila.get("tipo")).isEqualTo("RECUPERACION_SOLICITADA");
    }

    @Test
    @DisplayName("SEND_RESET_PASSWORD_ERROR con correo inexistente de 50 caracteres: usuario_id y entidad_id nulos, email preservado")
    void sendResetPasswordError_correoLargoInexistente_noDesbordaEntidadId() {
        long t = TIME_GEN.addAndGet(100000L);
        String correoLargo = "usuario.inexistente.con.correo.largo.de.50.caracteres@test.cl";
        EventRepresentation ev = new EventRepresentation();
        ev.setTime(t);
        ev.setType("SEND_RESET_PASSWORD_ERROR");
        ev.setIpAddress("10.0.0.1");
        ev.setError("user_not_found");
        ev.setDetails(Map.of("username", correoLargo));

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev));

        importer.ejecutarLoteImportacion();

        String clave = "kc:" + t + ":SEND_RESET_PASSWORD_ERROR:" + correoLargo;
        Map<String, Object> fila = jdbc.queryForMap(
                "SELECT le.usuario_id, le.entidad_id, le.usuario_email, le.resultado, te.codigo as tipo " +
                        "FROM log_evento le JOIN tipo_evento te ON le.tipo_evento_id = te.id " +
                        "WHERE le.clave_externa = ?",
                clave
        );

        assertThat(fila.get("usuario_id")).isNull();
        assertThat(fila.get("entidad_id")).isNull();
        assertThat(fila.get("usuario_email")).isEqualTo(correoLargo);
        assertThat(fila.get("resultado")).isEqualTo("FALLO");
        assertThat(fila.get("tipo")).isEqualTo("RECUPERACION_SOLICITADA");
    }

    @Test
    @DisplayName("Segunda ejecución con los mismos eventos deduplica correctamente por clave_externa")
    void deduplicacionReal_mismosEventos_noDuplicaFila() {
        long t = TIME_GEN.addAndGet(100000L);
        EventRepresentation ev = new EventRepresentation();
        ev.setTime(t);
        ev.setType("RESET_PASSWORD");
        ev.setUserId(usuarioRealKcId);

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev));

        importer.ejecutarLoteImportacion();

        // Forzar cursor atrás para simular reprocesamiento
        jdbc.update("UPDATE integracion_cursor SET valor = '0' WHERE nombre = 'KEYCLOAK_EVENTOS'");

        importer.ejecutarLoteImportacion();

        Integer count = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento WHERE clave_externa = ?",
                Integer.class,
                "kc:" + t + ":RESET_PASSWORD:" + usuarioRealKcId
        );
        assertThat(count).isEqualTo(1);
    }

    @Test
    @DisplayName("UPDATE_PASSWORD sin solicitud previa no genera fila; con SEND_RESET_PASSWORD previo genera RECUPERACION_COMPLETADA")
    void updatePassword_validaVentana30Minutos() {
        long t1 = TIME_GEN.addAndGet(100000L);
        long t2 = t1 + (10 * 60 * 1000L); // 10 minutos después
        long t3 = t2 + (60 * 60 * 1000L); // sin solicitud previa

        // 1. SEND_RESET_PASSWORD seguido de UPDATE_PASSWORD a los 10 minutos
        EventRepresentation evSend = new EventRepresentation();
        evSend.setTime(t1);
        evSend.setType("SEND_RESET_PASSWORD");
        evSend.setUserId(usuarioRealKcId);

        EventRepresentation evUpdate = new EventRepresentation();
        evUpdate.setTime(t2);
        evUpdate.setType("UPDATE_PASSWORD");
        evUpdate.setUserId(usuarioRealKcId);

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(evSend, evUpdate));

        importer.ejecutarLoteImportacion();

        Integer countUpdate = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento le JOIN tipo_evento te ON le.tipo_evento_id = te.id " +
                        "WHERE le.clave_externa = ? AND te.codigo = 'RECUPERACION_COMPLETADA'",
                Integer.class,
                "kc:" + t2 + ":UPDATE_PASSWORD:" + usuarioRealKcId
        );
        assertThat(countUpdate).isEqualTo(1);

        // 2. UPDATE_PASSWORD aislado posterior sin solicitud previa
        EventRepresentation evAislado = new EventRepresentation();
        evAislado.setTime(t3);
        evAislado.setType("UPDATE_PASSWORD");
        evAislado.setUserId(usuarioRealKcId);

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(evAislado));

        importer.ejecutarLoteImportacion();

        Integer countAislado = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento WHERE clave_externa = ?",
                Integer.class,
                "kc:" + t3 + ":UPDATE_PASSWORD:" + usuarioRealKcId
        );
        assertThat(countAislado).isZero();
    }

    @Test
    @DisplayName("Paginación de 450 eventos en 3 páginas importa todas las filas y avanza el cursor")
    void paginacionMultiple_procesaTodasLasPaginas() {
        long baseTime = TIME_GEN.addAndGet(1000000L);
        List<EventRepresentation> pag1 = new ArrayList<>();
        List<EventRepresentation> pag2 = new ArrayList<>();
        List<EventRepresentation> pag3 = new ArrayList<>();

        for (int i = 0; i < 200; i++) {
            EventRepresentation ev = new EventRepresentation();
            ev.setTime(baseTime + i);
            ev.setType("RESET_PASSWORD");
            ev.setUserId(usuarioRealKcId);
            pag1.add(ev);
        }
        for (int i = 200; i < 400; i++) {
            EventRepresentation ev = new EventRepresentation();
            ev.setTime(baseTime + i);
            ev.setType("RESET_PASSWORD");
            ev.setUserId(usuarioRealKcId);
            pag2.add(ev);
        }
        for (int i = 400; i < 450; i++) {
            EventRepresentation ev = new EventRepresentation();
            ev.setTime(baseTime + i);
            ev.setType("RESET_PASSWORD");
            ev.setUserId(usuarioRealKcId);
            pag3.add(ev);
        }

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(pag1);
        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(200), eq(200)))
                .thenReturn(pag2);
        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(400), eq(200)))
                .thenReturn(pag3);

        importer.ejecutarLoteImportacion();

        Integer total = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento WHERE created_at >= to_timestamp(?)",
                Integer.class,
                (baseTime / 1000.0)
        );
        assertThat(total).isEqualTo(450);

        String cursorVal = jdbc.queryForObject(
                "SELECT valor FROM integracion_cursor WHERE nombre = 'KEYCLOAK_EVENTOS'",
                String.class
        );
        assertThat(cursorVal).isEqualTo(String.valueOf(baseTime + 449));
    }

    @Test
    @DisplayName("Un evento que provoca error SQL se omite, los demás se insertan y el cursor avanza")
    void eventoConErrorSql_seOmiteYContinua() {
        long t1 = TIME_GEN.addAndGet(100000L);
        long tError = t1 + 1;
        long t2 = t1 + 2;

        EventRepresentation ev1 = new EventRepresentation();
        ev1.setTime(t1);
        ev1.setType("RESET_PASSWORD");
        ev1.setUserId(usuarioRealKcId);

        EventRepresentation evFallo = new EventRepresentation();
        evFallo.setTime(tError);
        evFallo.setType("RESET_PASSWORD");
        evFallo.setUserId(usuarioRealKcId);
        evFallo.setIpAddress("x".repeat(300)); // ip_address es VARCHAR(45) -> provocará DataTruncationException en Postgres

        EventRepresentation ev2 = new EventRepresentation();
        ev2.setTime(t2);
        ev2.setType("RESET_PASSWORD");
        ev2.setUserId(usuarioRealKcId);

        when(realmResource.getEvents(anyList(), isNull(), isNull(), any(), isNull(), isNull(), eq(0), eq(200)))
                .thenReturn(List.of(ev1, evFallo, ev2));

        importer.ejecutarLoteImportacion();

        Integer c1 = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento WHERE clave_externa = ?",
                Integer.class,
                "kc:" + t1 + ":RESET_PASSWORD:" + usuarioRealKcId
        );
        Integer c2 = jdbc.queryForObject(
                "SELECT count(*) FROM log_evento WHERE clave_externa = ?",
                Integer.class,
                "kc:" + t2 + ":RESET_PASSWORD:" + usuarioRealKcId
        );
        assertThat(c1).isEqualTo(1);
        assertThat(c2).isEqualTo(1);

        String cursorVal = jdbc.queryForObject(
                "SELECT valor FROM integracion_cursor WHERE nombre = 'KEYCLOAK_EVENTOS'",
                String.class
        );
        assertThat(cursorVal).isEqualTo(String.valueOf(t2));
    }
}
