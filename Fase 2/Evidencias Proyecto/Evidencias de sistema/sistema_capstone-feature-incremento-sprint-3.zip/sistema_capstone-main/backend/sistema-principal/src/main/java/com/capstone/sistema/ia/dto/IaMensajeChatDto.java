package com.capstone.sistema.ia.dto;

import java.time.Instant;
import java.util.UUID;

/**
 * F6 (§7.2): mensaje individual en el hilo de chat con IA (US-30, D3-04).
 */
public record IaMensajeChatDto(
        UUID id,
        String estado,
        String pregunta,
        String respuesta,
        AutorDto autor,
        Integer documentoVersion,
        IaEvaluacionDto.ErrorDto error,
        Instant createdAt,
        Instant completedAt
) {
    public record AutorDto(UUID id, String nombre) {}
}
