package com.capstone.sistema.doc;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DocController.class)
@Import(SecurityConfig.class)
class DocControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MinioStorageService storageService;

    @MockBean
    private com.capstone.sistema.audit.service.AuditService auditService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @MockBean
    private RbacAccessService accessService;

    @Test
    void rejectsUnauthenticatedUpload() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "dummy".getBytes());
        mockMvc.perform(multipart("/api/doc/upload").file(file))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void rejectsNonAdminUpload() throws Exception {
        doThrow(RbacException.denied()).when(accessService).requireAny(any(Permiso.class));
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "dummy".getBytes());
        mockMvc.perform(multipart("/api/doc/upload")
                        .file(file)
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isForbidden());
    }

    @Test
    void allowsAuthenticatedUploadIntermediatedToMinIO() throws Exception {
        when(storageService.uploadFile(any())).thenReturn("12345_test.xlsx");

        MockMultipartFile file = new MockMultipartFile(
                "file", "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "excel data".getBytes()
        );

        mockMvc.perform(multipart("/api/doc/upload")
                        .file(file)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")).jwt(j -> j.claim("email", "admin@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fileKey").value("12345_test.xlsx"));
    }

    @Test
    void uploadDocument_emptyFile_returnsBadRequest400() throws Exception {
        MockMultipartFile emptyFile = new MockMultipartFile("file", "vacio.pdf", "application/pdf", new byte[0]);

        mockMvc.perform(multipart("/api/doc/upload")
                        .file(emptyFile)
                        .with(jwt().authorities(new SimpleGrantedAuthority("ROLE_ADMIN")).jwt(j -> j.claim("email", "admin@capstone.local"))))
                .andExpect(status().isBadRequest());
    }
}
