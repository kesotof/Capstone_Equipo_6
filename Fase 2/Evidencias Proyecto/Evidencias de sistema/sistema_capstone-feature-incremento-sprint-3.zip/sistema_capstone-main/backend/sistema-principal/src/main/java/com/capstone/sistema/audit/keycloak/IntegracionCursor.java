package com.capstone.sistema.audit.keycloak;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.Objects;

/**
 * US-27: cursor de integraciones incrementales (§4.7). La única fila hoy es
 * {@code KEYCLOAK_EVENTOS} con la marca de tiempo (epoch ms) procesada por el importador.
 */
@Entity
@Table(name = "integracion_cursor")
public class IntegracionCursor {

    @Id
    @Column(name = "nombre", nullable = false, length = 50)
    private String nombre;

    @Column(name = "valor", nullable = false, length = 100)
    private String valor;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected IntegracionCursor() {
    }

    public IntegracionCursor(String nombre, String valor) {
        this.nombre = Objects.requireNonNull(nombre, "nombre");
        this.valor = Objects.requireNonNull(valor, "valor");
    }

    public String getNombre() {
        return nombre;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    @jakarta.persistence.PreUpdate
    @jakarta.persistence.PrePersist
    void stampUpdatedAt() {
        this.updatedAt = Instant.now();
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
