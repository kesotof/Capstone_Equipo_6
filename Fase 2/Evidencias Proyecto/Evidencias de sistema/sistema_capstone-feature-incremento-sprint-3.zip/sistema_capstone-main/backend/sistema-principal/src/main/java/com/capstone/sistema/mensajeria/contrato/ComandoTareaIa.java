package com.capstone.sistema.mensajeria.contrato;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * §5.3 — comando del principal a service-ia (routing «ia.tarea.ejecutar»).
 * `documento` y `contexto`: null en AUTOCOMPLETAR; `campos` solo se llena en AUTOCOMPLETAR;
 * `historial` solo en CHAT (últimos 6 pares completados, del más antiguo al más nuevo).
 */
public record ComandoTareaIa(
        int version,
        UUID mensajeId,
        UUID tareaId,
        String tipo,
        Documento documento,
        Contexto contexto,
        String instruccion,
        List<ParHistorial> historial,
        List<Campo> campos,
        Instant emitidoEn
) {

    public record Documento(String bucket, String storageKey, String nombreArchivo, String contentType) {
    }

    public record Contexto(String correlativo, String titulo, String descripcion, String tipoDocumento,
                           String etapa, Integer versionDocumento) {
    }

    public record ParHistorial(String pregunta, String respuesta) {
    }

    public record Campo(String clave, String etiqueta, String tipo, boolean obligatorio,
                        List<String> opciones, String descripcion) {
    }
}
