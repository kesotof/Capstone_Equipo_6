package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class VAreaDescendienteId implements Serializable {

    @Column(name = "ancestro_id")
    private Long ancestroId;

    @Column(name = "area_id")
    private Long areaId;

    public VAreaDescendienteId() {
    }

    public VAreaDescendienteId(Long ancestroId, Long areaId) {
        this.ancestroId = ancestroId;
        this.areaId = areaId;
    }

    public Long getAncestroId() {
        return ancestroId;
    }

    public Long getAreaId() {
        return areaId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VAreaDescendienteId that = (VAreaDescendienteId) o;
        return Objects.equals(ancestroId, that.ancestroId) && Objects.equals(areaId, that.areaId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ancestroId, areaId);
    }
}
