package com.capstone.sistema.ia.service;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.schema.FieldSchemaBuilder;
import org.springframework.data.domain.PageRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * F6/F8 (§5.3): construcción de {@link ComandoTareaIa} a partir de una {@link IaTarea}.
 * Reconstruye el mensaje directamente desde las filas de negocio (A-04).
 */
@Component
public class IaComandoFactory {

    private final IaTareaRepository iaTareaRepository;
    private final FieldSchemaBuilder schemaBuilder;

    @Value("${minio.bucket:documentos}")
    private String bucketDocumentos = "documentos";

    public IaComandoFactory(IaTareaRepository iaTareaRepository, FieldSchemaBuilder schemaBuilder) {
        this.iaTareaRepository = iaTareaRepository;
        this.schemaBuilder = schemaBuilder;
    }

    public ComandoTareaIa crearComando(IaTarea tarea) {
        UUID mensajeId = UUID.randomUUID();
        TipoTareaIa tipo = tarea.getTipo();

        ComandoTareaIa.Documento docPayload = null;
        ComandoTareaIa.Contexto contextoPayload = null;
        List<ComandoTareaIa.ParHistorial> historial = List.of();
        List<ComandoTareaIa.Campo> campos = List.of();

        if (tipo == TipoTareaIa.EVALUACION || tipo == TipoTareaIa.CHAT) {
            Documento doc = tarea.getDocumento();
            if (doc != null) {
                docPayload = new ComandoTareaIa.Documento(
                        bucketDocumentos != null ? bucketDocumentos : "documentos",
                        doc.getStorageKey(),
                        doc.getNombreArchivo(),
                        doc.getContentType()
                );
            }
            Solicitud s = tarea.getSolicitud();
            if (s != null) {
                String tipoDocNombre = s.getTipoDocumento();
                String etapaNombre = tarea.getFlujoEtapa() != null ? tarea.getFlujoEtapa().getNombre()
                        : (s.getFlujoEtapa() != null ? s.getFlujoEtapa().getNombre() : null);
                Integer version = doc != null ? doc.getVersion() : null;
                contextoPayload = new ComandoTareaIa.Contexto(
                        s.getCorrelativo(),
                        s.getTitulo(),
                        s.getDescripcion(),
                        tipoDocNombre,
                        etapaNombre,
                        version
                );
            }

            if (tipo == TipoTareaIa.CHAT && s != null) {
                // Últimos 6 pares completados del hilo, del más antiguo al más nuevo
                List<IaTarea> ultimosCompletados = iaTareaRepository.findUltimosChatCompletados(
                        s.getId(), PageRequest.of(0, 6)
                );
                List<ComandoTareaIa.ParHistorial> pares = new ArrayList<>();
                for (IaTarea t : ultimosCompletados) {
                    // Evitar incluir la propia tarea si estuviera completada
                    if (tarea.getId() != null && tarea.getId().equals(t.getId())) {
                        continue;
                    }
                    String pregunta = t.getInstruccion();
                    String respuesta = t.getResultado() != null ? t.getResultado().path("respuesta").asText("") : "";
                    pares.add(new ComandoTareaIa.ParHistorial(pregunta, respuesta));
                }
                // Como vienen en DESC (más reciente primero), invertimos para que queden cronológicos
                Collections.reverse(pares);
                historial = List.copyOf(pares);
            }
        } else if (tipo == TipoTareaIa.AUTOCOMPLETAR) {
            docPayload = new ComandoTareaIa.Documento(
                    tarea.getFuenteBucket(),
                    tarea.getFuenteStorageKey(),
                    tarea.getFuenteNombreArchivo(),
                    tarea.getFuenteContentType()
            );
            contextoPayload = null;
            if (tarea.getPlantillaVersion() != null && tarea.getPlantillaVersion().getEsquemaCampos() != null) {
                List<FieldDefinition> fieldDefs = schemaBuilder.parseFields(tarea.getPlantillaVersion().getEsquemaCampos());
                campos = fieldDefs.stream()
                        .map(f -> new ComandoTareaIa.Campo(
                                f.key(),
                                f.label(),
                                f.tipo() != null ? f.tipo().name().toLowerCase() : "texto",
                                f.obligatorio(),
                                f.opciones() != null ? f.opciones() : List.of(),
                                f.descripcion()
                        ))
                        .toList();
            }
        }

        return new ComandoTareaIa(
                1,
                mensajeId,
                tarea.getId(),
                tipo.name(),
                docPayload,
                contextoPayload,
                tarea.getInstruccion(),
                historial,
                campos,
                Instant.now()
        );
    }
}
