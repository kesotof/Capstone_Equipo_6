package com.capstone.sistema.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import org.hibernate.annotations.Immutable;

import java.util.UUID;

@Entity
@Table(name = "v_flujo_disponible_usuario")
@IdClass(VFlujoDisponibleUsuarioId.class)
@Immutable
public class VFlujoDisponibleUsuario {

    @Id
    @Column(name = "flujo_id")
    private Long flujoId;

    @Id
    @Column(name = "usuario_id")
    private UUID usuarioId;

    protected VFlujoDisponibleUsuario() {
    }

    public VFlujoDisponibleUsuario(Long flujoId, UUID usuarioId) {
        this.flujoId = flujoId;
        this.usuarioId = usuarioId;
    }

    public Long getFlujoId() {
        return flujoId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }
}
