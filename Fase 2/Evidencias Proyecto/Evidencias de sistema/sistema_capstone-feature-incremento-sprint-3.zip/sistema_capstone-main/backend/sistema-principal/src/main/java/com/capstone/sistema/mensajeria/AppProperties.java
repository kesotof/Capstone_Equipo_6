package com.capstone.sistema.mensajeria;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * F2: propiedades generales de la aplicación (plan §6.0).
 *
 * @param frontendBaseUrl base absoluta para construir la URL del botón en los correos
 * @param scheduling      habilita {@code SchedulingConfig} (jobs de plazos y republicador)
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(String frontendBaseUrl, Scheduling scheduling) {

    public record Scheduling(boolean enabled) {
    }
}
