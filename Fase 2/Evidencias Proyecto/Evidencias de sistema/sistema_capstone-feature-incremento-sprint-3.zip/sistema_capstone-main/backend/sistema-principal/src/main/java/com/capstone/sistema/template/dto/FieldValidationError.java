package com.capstone.sistema.template.dto;

public record FieldValidationError(
        String field,
        String message,
        Object rejectedValue
) {}
