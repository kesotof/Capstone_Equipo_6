package com.capstone.sistema.template.service;

import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.IaAutocompletado;
import com.capstone.sistema.doc.model.Plantilla;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.doc.repository.IaAutocompletadoRepository;
import com.capstone.sistema.doc.repository.PlantillaRepository;
import com.capstone.sistema.doc.repository.PlantillaVersionRepository;
import com.capstone.sistema.flow.RabbitConfig;
import com.capstone.sistema.flow.model.EstadoAnalisis;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import com.capstone.sistema.template.dto.FieldDefinition;
import com.capstone.sistema.template.dto.PlantillaDtos.AutocompletadoIaDto;
import com.capstone.sistema.template.schema.FieldSchemaBuilder;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Autocompletado con IA del formulario de una plantilla: registra la tarea, la publica para service-ia
 * y guarda solo las sugerencias que el formulario aceptaría al emitir.
 */
@Service
public class AutocompletadoIaService {

    private static final Logger log = LoggerFactory.getLogger(AutocompletadoIaService.class);
    private static final long MAX_ARCHIVO_BYTES = 10L * 1024 * 1024;
    private static final int MAX_INDICACIONES = 2000;
    private static final int MAX_TEXTO_SUGERIDO = 5000;
    private static final Map<String, String> FORMATOS = Map.of(
            ".pdf", "application/pdf",
            ".doc", "application/msword",
            ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".txt", "text/plain"
    );

    private final PlantillaRepository plantillaRepository;
    private final PlantillaVersionRepository versionRepository;
    private final IaAutocompletadoRepository autocompletadoRepository;
    private final FieldSchemaBuilder schemaBuilder;
    private final MinioStorageService storage;
    private final RabbitTemplate rabbitTemplate;
    private final RbacAccessService rbac;
    private final ObjectMapper objectMapper;

    public AutocompletadoIaService(
            PlantillaRepository plantillaRepository,
            PlantillaVersionRepository versionRepository,
            IaAutocompletadoRepository autocompletadoRepository,
            FieldSchemaBuilder schemaBuilder,
            MinioStorageService storage,
            RabbitTemplate rabbitTemplate,
            RbacAccessService rbac,
            ObjectMapper objectMapper
    ) {
        this.plantillaRepository = plantillaRepository;
        this.versionRepository = versionRepository;
        this.autocompletadoRepository = autocompletadoRepository;
        this.schemaBuilder = schemaBuilder;
        this.storage = storage;
        this.rabbitTemplate = rabbitTemplate;
        this.rbac = rbac;
        this.objectMapper = objectMapper;
    }

    /**
     * Sin transacción envolvente a propósito: la tarea queda guardada antes de publicarla, así el
     * resultado de service-ia nunca llega antes que su registro.
     */
    public AutocompletadoIaDto solicitar(Long plantillaId, MultipartFile archivo, String indicaciones, UserAccount actor) {
        rbac.require(Permiso.SOLICITUD_CREAR);
        Plantilla plantilla = plantillaRepository.findById(plantillaId)
                .filter(p -> p.isActivo() && disponiblePara(p, actor))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La plantilla no está disponible para autocompletar."));
        PlantillaVersion vigente = versionRepository.findFirstByPlantilla_IdOrderByVersionDesc(plantillaId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La plantilla no tiene versiones publicadas."));
        // Los campos calculados los completa el sistema, no la IA.
        List<FieldDefinition> campos = schemaBuilder.parseFields(vigente.getEsquemaCampos()).stream()
                .filter(campo -> campo.calculo() == null).toList();

        String texto = indicaciones == null ? "" : indicaciones.strip();
        boolean conArchivo = archivo != null && !archivo.isEmpty();
        if (!conArchivo && texto.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Adjunte un documento o escriba indicaciones para la IA.");
        }
        if (texto.length() > MAX_INDICACIONES) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Las indicaciones no pueden superar los " + MAX_INDICACIONES + " caracteres.");
        }

        String nombreArchivo = null;
        String storageKey = null;
        if (conArchivo) {
            nombreArchivo = MinioStorageService.cleanFilename(archivo.getOriginalFilename());
            String contentType = FORMATOS.get(extension(nombreArchivo));
            if (contentType == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Formato no permitido. Use un documento PDF, Word o TXT.");
            }
            if (archivo.getSize() > MAX_ARCHIVO_BYTES) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El documento supera el máximo de 10 MB.");
            }
            try {
                storageKey = storage.uploadAutocompletado(nombreArchivo, contentType, archivo.getBytes()).storageKey();
            } catch (Exception e) {
                log.error("No se pudo guardar el documento de autocompletado en MinIO: {}", e.getMessage(), e);
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "No se pudo guardar el documento para el autocompletado. Intente nuevamente.");
            }
        }

        IaAutocompletado tarea;
        try {
            tarea = autocompletadoRepository.save(new IaAutocompletado(vigente, actor, nombreArchivo, storageKey, texto.isEmpty() ? null : texto));
        } catch (RuntimeException e) {
            eliminarArchivo(storageKey);
            throw e;
        }

        Map<String, Object> tareaIa = new HashMap<>();
        tareaIa.put("autocompletadoId", tarea.getId().toString());
        tareaIa.put("plantilla", plantilla.getNombre());
        tareaIa.put("campos", campos);
        tareaIa.put("indicaciones", texto);
        if (storageKey != null) {
            tareaIa.put("storageKey", storageKey);
            tareaIa.put("nombreArchivo", nombreArchivo);
        }
        try {
            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_AUTOCOMPLETE_ROUTING_KEY, tareaIa);
            log.info("Tarea de autocompletado {} publicada para la plantilla {} v{}", tarea.getId(), plantillaId, vigente.getVersion());
        } catch (AmqpException e) {
            log.error("No se pudo publicar la tarea de autocompletado {}: {}", tarea.getId(), e.getMessage());
            tarea.completar(EstadoAnalisis.ERROR, null, "No fue posible enviar la tarea al servicio de IA. Intente nuevamente.", null);
            tarea = autocompletadoRepository.save(tarea);
            eliminarArchivo(storageKey);
        }
        return toDto(tarea, campos);
    }

    @Transactional(readOnly = true)
    public AutocompletadoIaDto obtener(UUID id, UserAccount actor) {
        IaAutocompletado tarea = autocompletadoRepository.findByIdAndUsuario_Id(id, actor.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Autocompletado no encontrado."));
        return toDto(tarea, schemaBuilder.parseFields(tarea.getPlantillaVersion().getEsquemaCampos()).stream()
                .filter(campo -> campo.calculo() == null).toList());
    }

    /** Resultado publicado por service-ia; las sugerencias con formato inválido se descartan e informan. */
    @Transactional
    public void procesarResultado(Map<String, Object> resultado) {
        UUID id;
        try {
            id = UUID.fromString(String.valueOf(resultado.get("autocompletadoId")));
        } catch (IllegalArgumentException e) {
            log.error("Resultado de autocompletado sin identificador válido: {}", resultado.get("autocompletadoId"));
            return;
        }
        IaAutocompletado tarea = autocompletadoRepository.findById(id).orElse(null);
        if (tarea == null || tarea.getEstado() != EstadoAnalisis.PENDIENTE) {
            log.warn("Resultado de autocompletado {} descartado: la tarea no existe o ya fue procesada", id);
            return;
        }

        String mensaje = resultado.get("mensaje") instanceof String m && !m.isBlank() ? m.strip() : null;
        String modelo = resultado.get("modeloUsado") instanceof String m ? m : null;
        if (!"COMPLETADO".equals(resultado.get("status"))) {
            tarea.completar(EstadoAnalisis.ERROR, null, mensaje != null ? mensaje : "No fue posible analizar el documento.", modelo);
        } else {
            Map<?, ?> propuestas = resultado.get("sugerencias") instanceof Map<?, ?> m ? m : Map.of();
            Map<String, Object> validas = new LinkedHashMap<>();
            List<String> descartadas = new ArrayList<>();
            for (FieldDefinition campo : schemaBuilder.parseFields(tarea.getPlantillaVersion().getEsquemaCampos())) {
                Object valor = propuestas.get(campo.key());
                if (valor == null) continue;
                if (aceptable(campo, valor)) validas.put(campo.key(), valor);
                else descartadas.add(campo.label());
            }
            if (!descartadas.isEmpty()) {
                mensaje = (mensaje != null ? mensaje + " " : "") + "Algunos valores no tenían el formato correcto y no se usaron: " + String.join(", ", descartadas) + ". Complételos a mano.";
            }
            tarea.completar(EstadoAnalisis.COMPLETADO, escribir(validas), mensaje, modelo);
        }
        log.info("Autocompletado {} actualizado a {}", id, tarea.getEstado());
        eliminarArchivo(tarea.getStorageKey());
    }

    /** Mismo tipo que enviaría el formulario y sin errores según las reglas de emisión. */
    private boolean aceptable(FieldDefinition campo, Object valor) {
        boolean tipoCorrecto = switch (campo.tipo()) {
            case NUMERO, MONTO -> valor instanceof Number;
            case BOOLEANO -> valor instanceof Boolean;
            default -> valor instanceof String s && !s.isBlank() && s.length() <= MAX_TEXTO_SUGERIDO;
        };
        return tipoCorrecto && schemaBuilder.validateData(List.of(campo), Map.of(campo.key(), valor)).isEmpty();
    }

    private boolean disponiblePara(Plantilla plantilla, UserAccount actor) {
        return plantilla.getArea() == null || rbac.context().admin()
                || (actor.getArea() != null && plantilla.getArea().getId().equals(actor.getArea().getId()));
    }

    private AutocompletadoIaDto toDto(IaAutocompletado tarea, List<FieldDefinition> campos) {
        Map<String, Object> sugerencias = leer(tarea.getSugerencias());
        List<String> noIdentificados = tarea.getEstado() == EstadoAnalisis.COMPLETADO
                ? campos.stream().map(FieldDefinition::key).filter(clave -> !sugerencias.containsKey(clave)).toList()
                : List.of();
        return new AutocompletadoIaDto(tarea.getId(), tarea.getEstado().name(), tarea.getNombreArchivo(), sugerencias,
                noIdentificados, tarea.getMensaje(), tarea.getModeloUsado(), tarea.getCreatedAt(), tarea.getCompletedAt());
    }

    private Map<String, Object> leer(String json) {
        if (json == null || json.isBlank()) return Map.of();
        try {
            return objectMapper.readValue(json, new TypeReference<LinkedHashMap<String, Object>>() {});
        } catch (Exception e) {
            log.warn("Sugerencias de autocompletado ilegibles: {}", e.getMessage());
            return Map.of();
        }
    }

    private String escribir(Map<String, Object> sugerencias) {
        try {
            return objectMapper.writeValueAsString(sugerencias);
        } catch (Exception e) {
            throw new IllegalStateException("No se pudieron serializar las sugerencias: " + e.getMessage(), e);
        }
    }

    private void eliminarArchivo(String storageKey) {
        if (storageKey == null) return;
        try {
            storage.deleteFile(storageKey);
        } catch (Exception e) {
            log.warn("No se pudo eliminar el documento temporal {} de MinIO: {}", storageKey, e.getMessage());
        }
    }

    private static String extension(String nombre) {
        int punto = nombre.lastIndexOf('.');
        return punto == -1 ? "" : nombre.substring(punto).toLowerCase(Locale.ROOT);
    }
}
