package com.capstone.sistema.ia.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.ia.dto.IaAutocompletadoDto;
import com.capstone.sistema.ia.service.IaAutocompletadoService;
import com.capstone.sistema.users.model.UserAccount;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.UUID;

/**
 * F8 (§7.1, US-29): endpoints REST para solicitud y consulta de autocompletado de formulario con IA.
 */
@Tag(name = "IA - Autocompletado", description = "Autocompletado de formularios desde documentos analizados con IA")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/ia/autocompletados")
public class IaAutocompletadoController {

    private final IaAutocompletadoService autocompletadoService;
    private final CurrentUserResolver currentUserResolver;

    public IaAutocompletadoController(
            IaAutocompletadoService autocompletadoService,
            CurrentUserResolver currentUserResolver
    ) {
        this.autocompletadoService = autocompletadoService;
        this.currentUserResolver = currentUserResolver;
    }

    @Operation(summary = "Iniciar tarea de autocompletado desde documento para una plantilla")
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<IaAutocompletadoDto> iniciarAutocompletado(
            @RequestParam("plantillaId") Long plantillaId,
            @RequestParam("archivo") MultipartFile archivo
    ) {
        UserAccount usuario = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        IaAutocompletadoDto dto = autocompletadoService.iniciarAutocompletado(plantillaId, archivo, usuario);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(dto);
    }

    @Operation(summary = "Consultar estado o resultado de una tarea de autocompletado")
    @GetMapping("/{id}")
    public ResponseEntity<IaAutocompletadoDto> consultarAutocompletado(@PathVariable("id") UUID id) {
        UserAccount usuario = currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));

        IaAutocompletadoDto dto = autocompletadoService.consultarAutocompletado(id, usuario);
        return ResponseEntity.ok(dto);
    }
}
