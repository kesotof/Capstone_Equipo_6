package com.capstone.sistema.doc;

import com.capstone.sistema.rbac.exception.RbacException;
import com.capstone.sistema.rbac.model.Permiso;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.Map;

/**
 * Endpoint legado de carga directa a MinIO (sin uso en el frontend actual). Se restringe al permiso de
 * gestión de configuración documental TIPO_DOCUMENTO.GESTIONAR (enum SLA_GESTIONAR).
 */
@RestController
@RequestMapping("/api/doc")
@PreAuthorize("isAuthenticated()")
public class DocController {
    private final MinioStorageService storage;
    private final RbacAccessService accessService;
    public DocController(MinioStorageService storage, RbacAccessService accessService) {
        this.storage=storage;
        this.accessService=accessService;
    }
    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(@RequestParam("file") MultipartFile file) throws Exception {
        accessService.requireAny(Permiso.SLA_GESTIONAR);
        if(file==null || file.isEmpty()) throw RbacException.invalid("El archivo es obligatorio.");
        String key=storage.uploadFile(file);
        return ResponseEntity.ok(Map.of("message","Archivo almacenado en MinIO correctamente","fileKey",key,
                "originalName",file.getOriginalFilename()==null?"archivo":file.getOriginalFilename()));
    }
}
