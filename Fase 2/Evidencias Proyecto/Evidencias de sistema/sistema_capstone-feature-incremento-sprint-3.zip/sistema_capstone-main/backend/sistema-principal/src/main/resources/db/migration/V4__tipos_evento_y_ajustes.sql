-- =============================================================================
-- V4__tipos_evento_y_ajustes.sql
-- Completa el catálogo TIPO_EVENTO con los códigos que emite el backend y que V2 no
-- siembra. AuditService ya no crea tipos en ejecución: un código ausente se registra
-- como error en el log y el evento se descarta (la operación de negocio no falla).
-- Categorías según el CHECK de V1: AUTENTICACION | ADMINISTRACION | FLUJO | ACCESO.
-- Idempotente: ON CONFLICT (codigo) DO NOTHING (no altera filas existentes).
-- =============================================================================

INSERT INTO tipo_evento (codigo, categoria, descripcion) VALUES
    -- Autenticación
    ('CAMBIAR_PASSWORD',            'AUTENTICACION',  'Contraseña cambiada por el titular de la cuenta'),

    -- Administración: usuarios
    ('CREAR_USUARIO',               'ADMINISTRACION', 'Usuario creado'),
    ('ACTUALIZAR_USUARIO',          'ADMINISTRACION', 'Datos de usuario actualizados'),
    ('ACTIVAR_USUARIO',             'ADMINISTRACION', 'Usuario activado'),
    ('DESACTIVAR_USUARIO',          'ADMINISTRACION', 'Usuario desactivado'),
    ('ELIMINAR_USUARIO',            'ADMINISTRACION', 'Usuario eliminado'),
    ('DESBLOQUEAR_USUARIO',         'ADMINISTRACION', 'Cuenta desbloqueada manualmente'),
    ('CAMBIAR_AREA_USUARIO',        'ADMINISTRACION', 'Área del usuario modificada (área anterior → nueva)'),
    ('BOOTSTRAP_ADMIN',             'ADMINISTRACION', 'Primer administrador del sistema asignado'),

    -- Administración: áreas y jefaturas
    ('CREAR_AREA',                  'ADMINISTRACION', 'Área creada'),
    ('ACTUALIZAR_AREA',             'ADMINISTRACION', 'Área actualizada'),
    ('ACTIVAR_AREA',                'ADMINISTRACION', 'Área activada'),
    ('DESACTIVAR_AREA',             'ADMINISTRACION', 'Área desactivada'),
    ('ASIGNAR_ADMIN_AREA',          'ADMINISTRACION', 'Administrador de área asignado o cambiado'),
    ('ACTUALIZAR_JEFATURAS_AREA',   'ADMINISTRACION', 'Lista de jefaturas del área actualizada'),

    -- Administración: roles
    ('ROL_ACTIVADO',                'ADMINISTRACION', 'Rol reactivado'),
    ('ROL_ESTADO',                  'ADMINISTRACION', 'Estado del rol modificado'),

    -- Administración: flujos
    ('CREAR_FLUJO',                 'ADMINISTRACION', 'Flujo de aprobación creado'),
    ('ACTUALIZAR_FLUJO',            'ADMINISTRACION', 'Metadatos del flujo actualizados'),
    ('CAMBIAR_ESTADO_FLUJO',        'ADMINISTRACION', 'Estado del flujo modificado'),
    ('CONFIGURAR_ETAPAS_FLUJO',     'ADMINISTRACION', 'Etapas y revisores del flujo configurados'),
    ('DESACTIVAR_FLUJO',            'ADMINISTRACION', 'Flujo desactivado'),
    ('ELIMINAR_FLUJO',              'ADMINISTRACION', 'Flujo eliminado'),
    ('ASIGNAR_RESPONSABLE_ETAPA',   'ADMINISTRACION', 'Responsable de etapa de flujo asignado'),

    -- Administración: tipos de documento, SLA y plantillas
    ('CONFIGURAR_SLA',              'ADMINISTRACION', 'Regla SLA creada, modificada o eliminada'),
    ('TIPO_DOCUMENTO_ACTIVADO',     'ADMINISTRACION', 'Tipo de documento activado'),
    ('TIPO_DOCUMENTO_DESACTIVADO',  'ADMINISTRACION', 'Tipo de documento desactivado'),
    ('TIPO_DOCUMENTO_ELIMINADO',    'ADMINISTRACION', 'Tipo de documento eliminado'),
    ('PLANTILLA_ACTIVADA',          'ADMINISTRACION', 'Plantilla reactivada'),

    -- Flujo operacional
    ('SOLICITUD_CREADA',            'FLUJO',          'Solicitud creada'),
    ('SOLICITUD_CORRECCION_PEDIDA', 'FLUJO',          'Solicitud devuelta con observaciones'),
    ('CREAR_SOLICITUD',             'FLUJO',          'Solicitud registrada'),
    ('APROBAR_SOLICITUD',           'FLUJO',          'Solicitud aprobada'),
    ('RECHAZAR_SOLICITUD',          'FLUJO',          'Solicitud rechazada'),
    ('PEDIR_CORRECCION',            'FLUJO',          'Corrección solicitada'),
    ('REENVIAR_SOLICITUD',          'FLUJO',          'Solicitud corregida y reenviada'),

    -- Acceso y consulta
    ('DESCARGAR_DOCUMENTO',         'ACCESO',         'Documento de solicitud descargado')
ON CONFLICT (codigo) DO NOTHING;
