-- =============================================================================
-- V5__admin_global_keycloak.sql
-- Fase 3 (decisión D-A): el administrador global se define en Keycloak mediante el
-- rol de realm ADMIN. El backend solo lo refleja en usuario_rol y registra el cambio.
-- Se agregan los tipos de evento de esa sincronización (categoría ADMINISTRACION,
-- según el CHECK de V1). Idempotente: ON CONFLICT (codigo) DO NOTHING.
-- BOOTSTRAP_ADMIN NO se borra: hay eventos históricos que lo referencian.
-- =============================================================================

INSERT INTO tipo_evento (codigo, categoria, descripcion) VALUES
    ('ADMIN_GLOBAL_ASIGNADO', 'ADMINISTRACION', 'Administrador global asignado al reflejar el rol ADMIN de Keycloak'),
    ('ADMIN_GLOBAL_REVOCADO', 'ADMINISTRACION', 'Administrador global revocado al dejar de tener el rol ADMIN en Keycloak')
ON CONFLICT (codigo) DO NOTHING;
