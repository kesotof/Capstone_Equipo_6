package com.capstone.sistema.doc.controller;

import com.capstone.sistema.doc.dto.AnexoResponse;
import com.capstone.sistema.doc.service.SolicitudAnexoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@Tag(name = "Anexos de solicitudes", description = "Documentos adjuntos que acompañan al documento vigente de una solicitud")
@SecurityRequirement(name = "bearerAuth")
@RestController
@PreAuthorize("isAuthenticated()")
public class SolicitudAnexoController {

    private final SolicitudAnexoService anexoService;

    public SolicitudAnexoController(SolicitudAnexoService anexoService) {
        this.anexoService = anexoService;
    }

    @Operation(summary = "Listar los documentos adjuntos de una solicitud")
    @GetMapping("/api/solicitudes/{id}/anexos")
    public List<AnexoResponse> listar(@PathVariable UUID id) {
        return anexoService.listar(id);
    }
}
