package com.capstone.sistema.model.view;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface VAccesoDescargaRepository extends JpaRepository<VAccesoDescarga, VAccesoDescargaId> {

    List<VAccesoDescarga> findBySolicitudId(UUID solicitudId);

    List<VAccesoDescarga> findByUsuarioId(UUID usuarioId);

    boolean existsBySolicitudIdAndUsuarioId(UUID solicitudId, UUID usuarioId);
}
