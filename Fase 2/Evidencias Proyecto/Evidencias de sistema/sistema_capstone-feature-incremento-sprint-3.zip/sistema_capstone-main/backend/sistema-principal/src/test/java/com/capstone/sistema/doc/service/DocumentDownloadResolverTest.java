package com.capstone.sistema.doc.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.doc.dto.DocumentDownloadTarget;
import com.capstone.sistema.doc.exception.DocumentDownloadException;
import com.capstone.sistema.doc.repository.DocumentDownloadRepository;
import com.capstone.sistema.model.view.VAccesoDescarga;
import com.capstone.sistema.model.view.VAccesoDescargaRepository;
import com.capstone.sistema.rbac.model.AccessContext;
import com.capstone.sistema.rbac.service.RbacAccessService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DocumentDownloadResolverTest {

    @Mock
    private DocumentDownloadRepository documents;

    @Mock
    private RbacAccessService access;

    @Mock
    private AuditService audit;

    @Mock
    private VAccesoDescargaRepository accesoDescargaRepository;

    @InjectMocks
    private DocumentDownloadResolver resolver;

    private UUID userId;
    private UUID solicitudId;
    private UUID docId;
    private DocumentDownloadTarget sampleTarget;
    private AccessContext userContext;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        solicitudId = UUID.randomUUID();
        docId = UUID.randomUUID();
        sampleTarget = new DocumentDownloadTarget(
                docId,
                solicitudId,
                "contrato.pdf",
                "application/pdf",
                "solicitudes/" + solicitudId + "/v1/contrato.pdf",
                1024L,
                1
        );
        userContext = new AccessContext(
                userId,
                10L,
                "Operaciones",
                null,
                false, // no admin
                Set.of(),
                true,
                List.of(),
                List.of(),
                Map.of(),
                1L,
                1L
        );
        lenient().when(access.context()).thenReturn(userContext);
    }

    @Test
    void testDownloadAuthorized_Emisor() {
        when(documents.byId(docId)).thenReturn(List.of(sampleTarget));
        when(access.puedeAccederSolicitud(userId, solicitudId)).thenReturn(true);
        when(access.puedeDescargar(userId, solicitudId)).thenReturn(true);
        when(accesoDescargaRepository.findBySolicitudId(solicitudId)).thenReturn(List.of(
                new VAccesoDescarga(solicitudId, userId, "EMISOR")
        ));

        DocumentDownloadTarget result = resolver.byId(docId);

        assertThat(result).isNotNull();
        assertThat(result.id()).isEqualTo(docId);
        assertThat(result.solicitudId()).isEqualTo(solicitudId);
        assertThat(result.motivo()).isEqualTo("EMISOR");
    }

    @Test
    void testDownloadDenied_UserCanViewButCannotDownload() {
        when(documents.byId(docId)).thenReturn(List.of(sampleTarget));
        when(access.puedeAccederSolicitud(userId, solicitudId)).thenReturn(true);
        when(access.puedeDescargar(userId, solicitudId)).thenReturn(false);

        assertThatThrownBy(() -> resolver.byId(docId))
                .isInstanceOf(DocumentDownloadException.class)
                .satisfies(ex -> {
                    DocumentDownloadException dde = (DocumentDownloadException) ex;
                    assertThat(dde.status()).isEqualTo(HttpStatus.FORBIDDEN);
                    assertThat(dde.code()).isEqualTo("DOCUMENTO_DESCARGA_DENEGADA");
                });

        verify(audit).registerAuditEvent(
                eq("ACCESO_DENEGADO"),
                eq("documento"),
                eq(docId.toString()),
                eq("DENEGADO"),
                contains("DOCUMENTO_DESCARGA_DENEGADA")
        );
    }

    @Test
    void testDownloadNotFound_SolicitudNotAccessible() {
        when(documents.byId(docId)).thenReturn(List.of(sampleTarget));
        when(access.puedeAccederSolicitud(userId, solicitudId)).thenReturn(false);

        assertThatThrownBy(() -> resolver.byId(docId))
                .isInstanceOf(DocumentDownloadException.class)
                .satisfies(ex -> {
                    DocumentDownloadException dde = (DocumentDownloadException) ex;
                    assertThat(dde.status()).isEqualTo(HttpStatus.NOT_FOUND);
                    assertThat(dde.code()).isEqualTo("RECURSO_NO_ENCONTRADO");
                });

        verifyNoInteractions(audit);
    }

    @Test
    void testDownloadNotFound_DocumentoNotExist() {
        when(documents.byId(docId)).thenReturn(List.of());

        assertThatThrownBy(() -> resolver.byId(docId))
                .isInstanceOf(DocumentDownloadException.class)
                .satisfies(ex -> {
                    DocumentDownloadException dde = (DocumentDownloadException) ex;
                    assertThat(dde.status()).isEqualTo(HttpStatus.NOT_FOUND);
                });

        verifyNoInteractions(audit);
    }
}
