package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.dto.DocumentSearchCriteria;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.model.Solicitud;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.JoinType;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Repository
public class DocumentSearchCatalogRepository {
    private final EntityManager entityManager;

    public DocumentSearchCatalogRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public List<CatalogEntry> findVisible(Specification<Solicitud> visibility) {
        var builder = entityManager.getCriteriaBuilder();
        var query = builder.createTupleQuery();
        var request = query.from(Solicitud.class);
        var document = query.from(Documento.class);

        var replaced = query.subquery(Integer.class);
        var replacer = replaced.from(Documento.class);
        replaced.select(builder.literal(1)).where(builder.equal(replacer.get("reemplazaDocumento").get("id"), document.get("id")));

        var areaOrigen = request.join("area", JoinType.LEFT);
        var flujoDef = request.join("flujoDefinicion", JoinType.LEFT);
        var areaFlujo = flujoDef.join("area", JoinType.LEFT);
        var tipoDoc = request.join("tipoDocumento", JoinType.LEFT);

        query.multiselect(
                areaOrigen.get("id").alias("origen"),
                areaFlujo.get("id").alias("flujo"),
                builder.upper(tipoDoc.get("nombre")).alias("tipo")
        ).distinct(true).where(
                builder.equal(document.get("historialTransicion").get("solicitud").get("id"), request.get("id")),
                builder.not(builder.exists(replaced)),
                visibility.toPredicate(request, query, builder)
        );

        return entityManager.createQuery(query).getResultList().stream()
                .map(row -> new CatalogEntry(
                        row.get("origen", Long.class),
                        row.get("flujo", Long.class),
                        row.get("tipo", String.class)
                )).toList();
    }

    /**
     * Última decisión (APROBAR, RECHAZAR o SOLICITAR_CORRECCION) registrada por el usuario en cada solicitud indicada.
     * Las solicitudes ya están autorizadas por el llamador; solo se leen filas propias del usuario.
     */
    public Map<UUID, LastDecision> lastDecisions(Collection<UUID> solicitudIds, UUID usuarioId) {
        if (solicitudIds.isEmpty() || usuarioId == null) return Map.of();
        List<Object[]> rows = entityManager.createQuery(
                        "select h.solicitud.id, h.accion.codigo, h.createdAt from HistorialTransicion h "
                                + "where h.solicitud.id in :ids and h.usuario.id = :usuario and h.accion.codigo in :acciones "
                                + "order by h.createdAt desc, h.id desc", Object[].class)
                .setParameter("ids", solicitudIds)
                .setParameter("usuario", usuarioId)
                .setParameter("acciones", DocumentSearchCriteria.MiDecision.ACCIONES)
                .getResultList();
        Map<UUID, LastDecision> latest = new HashMap<>();
        for (Object[] row : rows) {
            latest.putIfAbsent((UUID) row[0], new LastDecision((String) row[1], (Instant) row[2]));
        }
        return latest;
    }

    public record CatalogEntry(Long areaOrigenId, Long areaFlujoId, String documentType) { }

    public record LastDecision(String accion, Instant fecha) { }
}
