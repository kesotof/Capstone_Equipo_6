package com.capstone.sistema.ia.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.flow.exception.AlmacenamientoNoDisponibleException;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Plantilla;
import com.capstone.sistema.doc.model.PlantillaVersion;
import com.capstone.sistema.ia.config.IaProperties;
import com.capstone.sistema.ia.dto.IaAutocompletadoDto;
import com.capstone.sistema.ia.exception.IaException;
import com.capstone.sistema.ia.model.IaTarea;
import com.capstone.sistema.ia.repository.IaTareaRepository;
import com.capstone.sistema.mensajeria.MensajePublicador;
import com.capstone.sistema.mensajeria.contrato.ComandoTareaIa;
import com.capstone.sistema.model.enums.EstadoTareaIa;
import com.capstone.sistema.model.enums.OrigenTareaIa;
import com.capstone.sistema.model.enums.TipoTareaIa;
import com.capstone.sistema.template.service.PlantillaService;
import com.capstone.sistema.users.model.UserAccount;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IaAutocompletadoServiceTest {

    @Mock
    private IaProperties iaProperties;

    @Mock
    private IaTareaRepository iaTareaRepository;

    @Mock
    private PlantillaService plantillaService;

    @Mock
    private MinioStorageService minioStorageService;

    @Mock
    private IaComandoFactory comandoFactory;

    @Mock
    private MensajePublicador publicador;

    @Mock
    private AuditService auditService;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private IaAutocompletadoService autocompletadoService;

    private UserAccount usuario;
    private PlantillaVersion versionVigente;

    @BeforeEach
    void setUp() {
        usuario = new UserAccount("kc-emisor", "emisor@test.cl", "Emisor", "Test", true);
        usuario.setId(UUID.randomUUID());

        lenient().when(iaProperties.habilitada()).thenReturn(true);
        lenient().when(iaProperties.autocompletado()).thenReturn(new IaProperties.Autocompletado("ia-temporal", 10485760L));

        Plantilla plantilla = mock(Plantilla.class);
        lenient().when(plantilla.getId()).thenReturn(1L);
        lenient().when(plantilla.getNombre()).thenReturn("Plantilla Contrato");

        versionVigente = mock(PlantillaVersion.class);
        lenient().when(versionVigente.getId()).thenReturn(10L);
        lenient().when(versionVigente.getVersion()).thenReturn(1);
        lenient().when(versionVigente.getPlantilla()).thenReturn(plantilla);
    }

    @Test
    @DisplayName("iniciarAutocompletado exitoso sube a MinIO, guarda tarea PENDIENTE y publica comando")
    void iniciarAutocompletado_exito() throws Exception {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario)).thenReturn(versionVigente);

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "factura.pdf", "application/pdf", "contenido pdf".getBytes()
        );

        UUID msgId = UUID.randomUUID();
        ComandoTareaIa comando = new ComandoTareaIa(1, msgId, UUID.randomUUID(), "AUTOCOMPLETAR", null, null, null, List.of(), List.of(), Instant.now());
        when(comandoFactory.crearComando(any())).thenReturn(comando);

        IaAutocompletadoDto dto = autocompletadoService.iniciarAutocompletado(1L, file, usuario);

        assertThat(dto.estado()).isEqualTo("PENDIENTE");
        assertThat(dto.plantilla().nombre()).isEqualTo("Plantilla Contrato");
        verify(minioStorageService).uploadToBucket(eq("ia-temporal"), anyString(), eq("factura.pdf"), eq("application/pdf"), any(byte[].class));
        verify(iaTareaRepository).save(any(IaTarea.class));
        verify(publicador).publicarTrasCommit(eq("ia.tarea.ejecutar"), eq(comando), eq(msgId));
        verify(auditService).registerAuditEvent(eq("IA_AUTOCOMPLETADO_SOLICITADO"), eq("plantilla"), eq("1"), eq("EXITO"), anyString());
    }

    @Test
    @DisplayName("Archivo con formato inválido (.exe) lanza IA_FORMATO_NO_SOPORTADO (415)")
    void iniciarAutocompletado_formatoInvalido() {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario)).thenReturn(versionVigente);

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "malicioso.exe", "application/octet-stream", "binario".getBytes()
        );

        assertThatThrownBy(() -> autocompletadoService.iniciarAutocompletado(1L, file, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_FORMATO_NO_SOPORTADO");
    }

    @Test
    @DisplayName("Archivo mayor a 10 MB lanza IA_ARCHIVO_EXCEDE_TAMANO (400)")
    void iniciarAutocompletado_archivoExcedeTamano() {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario)).thenReturn(versionVigente);

        byte[] largeBytes = new byte[11 * 1024 * 1024]; // 11 MB
        MockMultipartFile file = new MockMultipartFile(
                "archivo", "enorme.pdf", "application/pdf", largeBytes
        );

        assertThatThrownBy(() -> autocompletadoService.iniciarAutocompletado(1L, file, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_ARCHIVO_EXCEDE_TAMANO");
    }

    @Test
    @DisplayName("consultarAutocompletado por usuario no autor lanza IA_NO_ENCONTRADA (404)")
    void consultarAutocompletado_autorDiferente() {
        UUID tareaId = UUID.randomUUID();
        UserAccount otroUsuario = new UserAccount("kc-otro", "otro@test.cl", "Otro", "User", true);
        otroUsuario.setId(UUID.randomUUID());

        IaTarea tarea = new IaTarea(
                TipoTareaIa.AUTOCOMPLETAR, OrigenTareaIa.MANUAL, null, null, null,
                versionVigente, "ia-temporal", "key", "doc.pdf", "application/pdf",
                "instruccion", "sha256", otroUsuario
        );

        when(iaTareaRepository.findById(tareaId)).thenReturn(Optional.of(tarea));

        assertThatThrownBy(() -> autocompletadoService.consultarAutocompletado(tareaId, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_NO_ENCONTRADA");
    }

    @Test
    @DisplayName("validarAplicabilidad rechaza si estado no es COMPLETADA")
    void validarAplicabilidad_noCompletada() {
        UUID autoId = UUID.randomUUID();
        IaTarea tarea = new IaTarea(
                TipoTareaIa.AUTOCOMPLETAR, OrigenTareaIa.MANUAL, null, null, null,
                versionVigente, "ia-temporal", "key", "doc.pdf", "application/pdf",
                "instruccion", "sha256", usuario
        ); // estado PENDIENTE por defecto

        when(iaTareaRepository.findById(autoId)).thenReturn(Optional.of(tarea));

        assertThatThrownBy(() -> autocompletadoService.validarAplicabilidad(autoId, versionVigente, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "AUTOCOMPLETADO_NO_APLICABLE");
    }

    @Test
    @DisplayName("validarAplicabilidad rechaza si plantilla_version no coincide")
    void validarAplicabilidad_versionDistinta() {
        UUID autoId = UUID.randomUUID();
        PlantillaVersion otraVersion = mock(PlantillaVersion.class);
        lenient().when(otraVersion.getId()).thenReturn(999L);

        IaTarea tarea = new IaTarea(
                TipoTareaIa.AUTOCOMPLETAR, OrigenTareaIa.MANUAL, null, null, null,
                otraVersion, "ia-temporal", "key", "doc.pdf", "application/pdf",
                "instruccion", "sha256", usuario
        );
        tarea.completar(null, "modelo");

        when(iaTareaRepository.findById(autoId)).thenReturn(Optional.of(tarea));

        assertThatThrownBy(() -> autocompletadoService.validarAplicabilidad(autoId, versionVigente, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "AUTOCOMPLETADO_NO_APLICABLE");
    }

    @Test
    @DisplayName("Plantilla inactiva o no disponible lanza IA_NO_ENCONTRADA (404)")
    void iniciarAutocompletado_plantillaNoDisponible() {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario))
                .thenThrow(new RuntimeException("Plantilla no encontrada o no disponible"));

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "factura.pdf", "application/pdf", "contenido pdf".getBytes()
        );

        assertThatThrownBy(() -> autocompletadoService.iniciarAutocompletado(1L, file, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_NO_ENCONTRADA");
    }

    @Test
    @DisplayName("MinIO no disponible (bucket inexistente) lanza IA_NO_DISPONIBLE (503)")
    void iniciarAutocompletado_minioNoDisponible() throws Exception {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario)).thenReturn(versionVigente);

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "factura.pdf", "application/pdf", "contenido pdf".getBytes()
        );

        doThrow(new AlmacenamientoNoDisponibleException("Bucket no existe", null))
                .when(minioStorageService).uploadToBucket(anyString(), anyString(), anyString(), anyString(), any(byte[].class));

        assertThatThrownBy(() -> autocompletadoService.iniciarAutocompletado(1L, file, usuario))
                .isInstanceOf(IaException.class)
                .hasFieldOrPropertyWithValue("code", "IA_NO_DISPONIBLE");
    }

    @Test
    @DisplayName("Rollback de transacción limpia objeto en MinIO llamando removeObject")
    void iniciarAutocompletado_rollbackLimpiaMinio() throws Exception {
        when(plantillaService.obtenerVersionVigenteDisponible(1L, usuario)).thenReturn(versionVigente);

        MockMultipartFile file = new MockMultipartFile(
                "archivo", "factura.pdf", "application/pdf", "contenido pdf".getBytes()
        );

        UUID msgId = UUID.randomUUID();
        ComandoTareaIa comando = new ComandoTareaIa(1, msgId, UUID.randomUUID(), "AUTOCOMPLETAR", null, null, null, List.of(), List.of(), Instant.now());
        when(comandoFactory.crearComando(any())).thenReturn(comando);

        TransactionSynchronizationManager.initSynchronization();
        try {
            autocompletadoService.iniciarAutocompletado(1L, file, usuario);

            List<TransactionSynchronization> syncs = TransactionSynchronizationManager.getSynchronizations();
            assertThat(syncs).isNotEmpty();
            for (TransactionSynchronization sync : syncs) {
                sync.afterCompletion(TransactionSynchronization.STATUS_ROLLED_BACK);
            }

            verify(minioStorageService).removeObject(eq("ia-temporal"), contains("autocompletado/"));
        } finally {
            TransactionSynchronizationManager.clearSynchronization();
        }
    }
}
