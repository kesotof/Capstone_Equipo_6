package com.capstone.sistema.template.controller;

import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.template.dto.PlantillaDtos.BorradorPlantillaDto;
import com.capstone.sistema.template.service.PlantillaBorradorService;
import com.capstone.sistema.users.model.UserAccount;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@Tag(name = "Borradores de plantillas", description = "Trabajo sin publicar del editor de plantillas, de cada persona")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/plantillas/borradores")
public class PlantillaBorradorController {

    private final PlantillaBorradorService borradorService;
    private final CurrentUserResolver currentUserResolver;

    public PlantillaBorradorController(PlantillaBorradorService borradorService, CurrentUserResolver currentUserResolver) {
        this.borradorService = borradorService;
        this.currentUserResolver = currentUserResolver;
    }

    @Operation(summary = "Listar los borradores propios")
    @GetMapping
    public ResponseEntity<List<BorradorPlantillaDto>> listar() {
        return ResponseEntity.ok(borradorService.listar(actor()));
    }

    @Operation(summary = "Obtener un borrador propio con el estado del editor")
    @GetMapping("/{id}")
    public ResponseEntity<BorradorPlantillaDto> obtener(@PathVariable UUID id) {
        return ResponseEntity.ok(borradorService.obtener(id, actor()));
    }

    @Operation(summary = "Descargar el Word de un borrador propio")
    @GetMapping("/{id}/archivo")
    public ResponseEntity<byte[]> archivo(@PathVariable UUID id) {
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"borrador.docx\"")
                .body(borradorService.archivo(id, actor()));
    }

    @Operation(summary = "Crear un borrador (o reemplazar el propio de esa plantilla)")
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<BorradorPlantillaDto> crear(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam("datos") String datos,
            @RequestParam(value = "plantillaId", required = false) Long plantillaId,
            @RequestParam(value = "versionBase", required = false) Integer versionBase
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(borradorService.guardar(null, file, nombre, datos, plantillaId, versionBase, actor()));
    }

    @Operation(summary = "Actualizar un borrador propio (el Word solo si cambió)")
    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<BorradorPlantillaDto> actualizar(
            @PathVariable UUID id,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam("datos") String datos,
            @RequestParam(value = "versionBase", required = false) Integer versionBase
    ) {
        return ResponseEntity.ok(borradorService.guardar(id, file, nombre, datos, null, versionBase, actor()));
    }

    @Operation(summary = "Descartar un borrador propio")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        borradorService.eliminar(id, actor());
        return ResponseEntity.noContent().build();
    }

    private UserAccount actor() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Usuario no autenticado"));
    }
}
