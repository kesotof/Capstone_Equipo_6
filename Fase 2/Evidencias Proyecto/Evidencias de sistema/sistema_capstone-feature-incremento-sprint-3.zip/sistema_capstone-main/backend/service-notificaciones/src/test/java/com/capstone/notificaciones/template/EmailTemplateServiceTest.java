package com.capstone.notificaciones.template;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * F4 (§8.1): layout genérico — marca, título, mensaje escapado con saltos de línea a
 * {@code <br>}, botón de acción y pie «automático»; versión HTML y texto plano.
 * Sin lógica por tipo de notificación.
 */
class EmailTemplateServiceTest {

    private final EmailTemplateService templateService = new EmailTemplateService();

    @Test
    @DisplayName("Layout genérico: marca, título, botón y pie automático")
    void renderGenerico() {
        EmailTemplateService.EmailContent content = templateService.render(
                "CONT-001 fue aprobada",
                "«Informe Q3» completó su flujo de aprobación.",
                "Ver solicitud",
                "http://localhost:3000/solicitudes/1"
        );

        assertThat(content.html())
                .contains("Sistema de Gestión Documental")
                .contains("CONT-001 fue aprobada")
                .contains("completó su flujo de aprobación")
                .contains("href=\"http://localhost:3000/solicitudes/1\"")
                .contains("Ver solicitud")
                .contains("Este es un aviso automático. No respondas este correo.");

        assertThat(content.text())
                .contains("Sistema de Gestión Documental")
                .contains("CONT-001 fue aprobada")
                .contains("Ver solicitud: http://localhost:3000/solicitudes/1")
                .contains("Este es un aviso automático. No respondas este correo.");
    }

    @Test
    @DisplayName("El HTML del usuario se escapa (no rompe el layout ni inyecta marcado)")
    void escapeHtmlDelMensaje() {
        EmailTemplateService.EmailContent content = templateService.render(
                "Título <b>«riesgo»</b>",
                "<script>alert('x')</script>\nSegunda línea",
                null,
                null
        );

        assertThat(content.html())
                .doesNotContain("<script>")
                .contains("&lt;script&gt;alert(&#39;x&#39;)&lt;/script&gt;")
                .contains("&lt;b&gt;");
        // Saltos de línea convertidos a <br> después del escape.
        assertThat(content.html()).contains("&lt;/script&gt;<br>Segunda línea");
        // Sin acción → sin botón.
        assertThat(content.html()).doesNotContain("class=\"btn\"");
        // El texto plano conserva el contenido crudo (no necesita escape).
        assertThat(content.text()).contains("<script>alert('x')</script>\nSegunda línea");
    }

    @Test
    @DisplayName("Sin acción no hay botón en HTML ni línea de URL en texto")
    void sinAccionNoHayBoton() {
        EmailTemplateService.EmailContent content = templateService.render(
                "Título", "Mensaje", "", "");

        assertThat(content.html()).doesNotContain("class=\"btn\"");
        assertThat(content.text()).doesNotContain("http");
    }

    @Test
    @DisplayName("Entradas nulas o vacías usan valores por defecto seguros")
    void entradasNulas() {
        EmailTemplateService.EmailContent content = templateService.render(null, null, null, null);

        assertThat(content.html()).contains("Notificación");
        assertThat(content.html()).contains("Sistema de Gestión Documental");
        assertThat(content.text()).isNotBlank();
    }
}
