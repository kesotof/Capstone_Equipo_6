package com.capstone.notificaciones.contrato;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * F2/F4 — guardia de contrato (plan §5): los JSON canónicos copiados a
 * {@code src/test/resources/contratos/} deben deserializarse en los records de este servicio
 * (F4: {@code main}, mismo paquete) y volver a serializarse sin pérdida. Falla la build si el
 * contrato cambia sin actualizar la copia y los records en los 3 servicios.
 */
class ContratoRoundTripTest {

    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

    private JsonNode original(String nombre) throws Exception {
        try (InputStream in = new ClassPathResource("contratos/" + nombre).getInputStream()) {
            return mapper.readTree(in);
        }
    }

    private void roundTrip(String nombre, Class<?> tipo) throws Exception {
        JsonNode antes = original(nombre);
        // Se re-lee desde la cadena serializada para normalizar tipos numéricos
        // (Long del record vs IntNode del parseo: mismo texto, equals distinto).
        JsonNode despues = mapper.readTree(mapper.writeValueAsString(mapper.convertValue(antes, tipo)));
        assertEquals(antes, despues, "Round-trip de " + nombre + " perdió datos");
    }

    @Test
    @DisplayName("ComandoEnviarCorreo: JSON → record → JSON sin pérdida")
    void comando() throws Exception {
        roundTrip("comando-enviar-correo.json", ComandoEnviarCorreo.class);
        ComandoEnviarCorreo cmd = mapper.convertValue(original("comando-enviar-correo.json"), ComandoEnviarCorreo.class);
        assertEquals("ana.perez@empresa.cl", cmd.destinatario().email());
        assertEquals("ACCION_REQUERIDA", cmd.categoria());
    }

    @Test
    @DisplayName("ResultadoCorreo: JSON → record → JSON sin pérdida (clave «final» mapeada)")
    void resultado() throws Exception {
        roundTrip("resultado-correo.json", ResultadoCorreo.class);
        ResultadoCorreo res = mapper.convertValue(original("resultado-correo.json"), ResultadoCorreo.class);
        assertEquals("FALLIDO", res.resultado());
        assertEquals(false, res.resultadoFinal());
    }
}
