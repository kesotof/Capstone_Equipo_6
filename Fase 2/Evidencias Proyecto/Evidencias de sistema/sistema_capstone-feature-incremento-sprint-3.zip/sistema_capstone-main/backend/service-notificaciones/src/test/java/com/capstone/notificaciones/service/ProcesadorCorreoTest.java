package com.capstone.notificaciones.service;

import com.capstone.notificaciones.client.ResendEmailClient;
import com.capstone.notificaciones.config.RabbitConfig;
import com.capstone.notificaciones.contrato.ComandoEnviarCorreo;
import com.capstone.notificaciones.contrato.ResultadoCorreo;
import com.capstone.notificaciones.template.EmailTemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * F4 — criterio de salida del plan §12: éxito al primer intento; 503 → 503 → 200 (3 resultados,
 * el último {@code final}); 422 → un solo resultado {@code final}; numeración desde
 * {@code intentoInicial}; header de idempotencia; publicación de resultados por intento.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProcesadorCorreoTest {

    @Mock
    private ResendEmailClient resendEmailClient;
    @Mock
    private EmailTemplateService emailTemplateService;
    @Mock
    private RabbitTemplate rabbitTemplate;

    private ProcesadorCorreo procesador;

    private static final ResendEmailClient.ResultadoEnvio OK =
            new ResendEmailClient.ResultadoEnvio(true, "msg_1", 200, null, null);
    private static final ResendEmailClient.ResultadoEnvio E503 =
            new ResendEmailClient.ResultadoEnvio(false, null, 503,
                    ResendEmailClient.CODIGO_PROVEEDOR_NO_DISPONIBLE, "503 Service Unavailable");
    private static final ResendEmailClient.ResultadoEnvio E422 =
            new ResendEmailClient.ResultadoEnvio(false, null, 422,
                    ResendEmailClient.CODIGO_DESTINO_INVALIDO, "destinatario inválido");

    @BeforeEach
    void setUp() {
        when(emailTemplateService.render(any(), any(), any(), any()))
                .thenReturn(new EmailTemplateService.EmailContent("<p>Hola</p>", "Hola"));
        procesador = spy(new ProcesadorCorreo(
                resendEmailClient,
                emailTemplateService,
                rabbitTemplate,
                List.of(Duration.ofSeconds(5), Duration.ofSeconds(30))
        ));
        // Sin espera real en los tests.
        doNothing().when(procesador).esperarEntreIntentos(any());
    }

    private ComandoEnviarCorreo comando(int intentoInicial) {
        return new ComandoEnviarCorreo(
                1, UUID.fromString("11111111-2222-3333-4444-555555555555"), 42L, intentoInicial,
                new ComandoEnviarCorreo.Destinatario("destinatario@empresa.cl", "Ana Pérez"),
                "Solicitud CONT-001 fue aprobada",
                "CONT-001 fue aprobada",
                "«Informe» completó su flujo.",
                new ComandoEnviarCorreo.Accion("Ver solicitud", "http://localhost:3000/solicitudes/1"),
                "INFORMATIVA",
                Instant.parse("2026-10-23T12:00:00Z")
        );
    }

    private List<ResultadoCorreo> resultadosPublicados() {
        ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
        verify(rabbitTemplate, org.mockito.Mockito.atLeastOnce()).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME), eq(RabbitConfig.ROUTING_CORREO_RESULTADO),
                captor.capture(), any(org.springframework.amqp.core.MessagePostProcessor.class));
        return captor.getAllValues().stream().map(ResultadoCorreo.class::cast).toList();
    }

    @Test
    @DisplayName("Éxito al primer intento: un solo resultado ENVIADO y final")
    void exitoAlPrimerIntento() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(OK);

        procesador.procesar(comando(1));

        List<ResultadoCorreo> resultados = resultadosPublicados();
        assertThat(resultados).hasSize(1);
        ResultadoCorreo r = resultados.get(0);
        assertThat(r.resultado()).isEqualTo("ENVIADO");
        assertThat(r.resultadoFinal()).isTrue();
        assertThat(r.intento()).isEqualTo(1);
        assertThat(r.proveedorId()).isEqualTo("msg_1");
        // Header de idempotency: notif-{notificacionId}, fijo por notificación (§8.1).
        verify(resendEmailClient).enviar(eq("destinatario@empresa.cl"), eq("Solicitud CONT-001 fue aprobada"),
                anyString(), anyString(), eq("notif-42"));
        verify(procesador, never()).esperarEntreIntentos(any());
    }

    @Test
    @DisplayName("503 → 503 → 200: 3 resultados, espera 5s/30s, el último final")
    void reintenta503HastaExito() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(E503, E503, OK);

        procesador.procesar(comando(1));

        List<ResultadoCorreo> resultados = resultadosPublicados();
        assertThat(resultados).hasSize(3);
        assertThat(resultados.get(0).resultado()).isEqualTo("FALLIDO");
        assertThat(resultados.get(0).resultadoFinal()).isFalse();
        assertThat(resultados.get(0).codigoError()).isEqualTo("PROVEEDOR_NO_DISPONIBLE");
        assertThat(resultados.get(1).resultado()).isEqualTo("FALLIDO");
        assertThat(resultados.get(1).resultadoFinal()).isFalse();
        assertThat(resultados.get(2).resultado()).isEqualTo("ENVIADO");
        assertThat(resultados.get(2).resultadoFinal()).isTrue();
        assertThat(resultados).extracting(ResultadoCorreo::intento).containsExactly(1, 2, 3);
        verify(procesador).esperarEntreIntentos(Duration.ofSeconds(5));
        verify(procesador).esperarEntreIntentos(Duration.ofSeconds(30));
        verify(resendEmailClient, times(3)).enviar(anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    @DisplayName("422 (no reintentable): un solo resultado final")
    void error422TerminaAlPrimerIntento() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(E422);

        procesador.procesar(comando(1));

        List<ResultadoCorreo> resultados = resultadosPublicados();
        assertThat(resultados).hasSize(1);
        assertThat(resultados.get(0).resultado()).isEqualTo("FALLIDO");
        assertThat(resultados.get(0).resultadoFinal()).isTrue();
        assertThat(resultados.get(0).codigoError()).isEqualTo("DESTINO_INVALIDO");
        verify(resendEmailClient, times(1)).enviar(anyString(), anyString(), anyString(), anyString(), anyString());
        verify(procesador, never()).esperarEntreIntentos(any());
    }

    @Test
    @DisplayName("Numeración desde intentoInicial: 4 → 5 → 6")
    void numeracionDesdeIntentoInicial() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(E503, E503, OK);

        procesador.procesar(comando(4));

        List<ResultadoCorreo> resultados = resultadosPublicados();
        assertThat(resultados).hasSize(3);
        assertThat(resultados).extracting(ResultadoCorreo::intento).containsExactly(4, 5, 6);
    }

    @Test
    @DisplayName("Tres fallos reintentables: el tercero (último) siempre es final")
    void ultimoIntentoSiempreEsFinal() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(E503);

        procesador.procesar(comando(1));

        List<ResultadoCorreo> resultados = resultadosPublicados();
        assertThat(resultados).hasSize(3);
        assertThat(resultados.get(0).resultadoFinal()).isFalse();
        assertThat(resultados.get(1).resultadoFinal()).isFalse();
        assertThat(resultados.get(2).resultadoFinal()).isTrue();
        assertThat(resultados.get(2).resultado()).isEqualTo("FALLIDO");
        verify(resendEmailClient, times(3)).enviar(anyString(), anyString(), anyString(), anyString(), anyString());
        verify(procesador, times(2)).esperarEntreIntentos(any());
    }

    @Test
    @DisplayName("Payload inválido se rechaza sin reenqueue (§3.1)")
    void payloadInvalidoSeRechaza() {
        ComandoEnviarCorreo invalido = new ComandoEnviarCorreo(
                1, UUID.randomUUID(), 42L, 0,   // intentoInicial < 1
                new ComandoEnviarCorreo.Destinatario("d@empresa.cl", "D"),
                "Asunto", "T", "M", null, "INFORMATIVA", Instant.now());

        assertThatThrownBy(() -> procesador.procesar(invalido))
                .isInstanceOf(AmqpRejectAndDontRequeueException.class);
        verify(resendEmailClient, never()).enviar(any(), any(), any(), any(), any());
    }

    @Test
    @DisplayName("Caída del broker al publicar el resultado: log y ack, sin excepción (§8.1)")
    void falloAlPublicarResultadoNoPropaga() {
        doThrow(new RuntimeException("broker caído"))
                .when(rabbitTemplate).convertAndSend(anyString(), anyString(), any(),
                        any(org.springframework.amqp.core.MessagePostProcessor.class));
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(OK);

        org.junit.jupiter.api.Assertions.assertDoesNotThrow(() -> procesador.procesar(comando(1)));
        verify(resendEmailClient, times(1)).enviar(anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    @DisplayName("El resultado lleva mensajeId, notificacionId y versión del comando (§5.2)")
    void resultadoReutilizaIdentidadDelComando() {
        when(resendEmailClient.enviar(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(OK);

        ComandoEnviarCorreo cmd = comando(1);
        procesador.procesar(cmd);

        ResultadoCorreo r = resultadosPublicados().get(0);
        assertThat(r.mensajeId()).isEqualTo(cmd.mensajeId());
        assertThat(r.notificacionId()).isEqualTo(cmd.notificacionId());
        assertThat(r.version()).isEqualTo(1);
        assertThat(r.destino()).isEqualTo("destinatario@empresa.cl");
    }
}
