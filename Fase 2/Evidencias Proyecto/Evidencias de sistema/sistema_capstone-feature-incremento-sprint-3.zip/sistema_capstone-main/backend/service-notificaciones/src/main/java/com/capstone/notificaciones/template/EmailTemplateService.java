package com.capstone.notificaciones.template;

import org.springframework.stereotype.Service;

/**
 * F4 (§8.1): plantilla de correo con <strong>layout genérico</strong> — encabezado con la
 * marca, título, mensaje escapado (HTML) con saltos de línea convertidos a {@code <br>}, botón
 * de la acción y pie «automático». Versión HTML y versión de texto plano.
 *
 * <p>Se elimina la lógica por tipo de notificación (los textos ya vienen escritos por
 * {@code NotificacionMensajeFactory} en el sistema principal, §6.1).</p>
 */
@Service
public class EmailTemplateService {

    private static final String MARCA = "Sistema de Gestión Documental";
    private static final String PIE = "Este es un aviso automático. No respondas este correo.";

    public record EmailContent(String html, String text) {
    }

    /**
     * @param titulo     asunto/título de la notificación.
     * @param mensaje    cuerpo (se escapa; los saltos de línea pasan a {@code <br>} en HTML).
     * @param accionTexto etiqueta del botón; vacía o nula → sin botón.
     * @param accionUrl  URL absoluta del botón.
     */
    public EmailContent render(String titulo, String mensaje, String accionTexto, String accionUrl) {
        String safeTitulo = (titulo != null && !titulo.isBlank()) ? titulo : "Notificación";
        String safeMensaje = (mensaje != null && !mensaje.isBlank()) ? mensaje : "";

        String htmlMensaje = escapar(safeMensaje).replaceAll("\r?\n", "<br>");
        String botonHtml = botonHtml(accionTexto, accionUrl);

        String html = """
                <!DOCTYPE html>
                <html lang="es">
                <head>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <title>%s</title>
                  <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #F3F4F6; margin: 0; padding: 24px; color: #1F2937; }
                    .card { max-width: 600px; margin: 0 auto; background: #FFFFFF; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
                    .header { background: #1E293B; color: #FFFFFF; padding: 24px; text-align: center; }
                    .content { padding: 32px 24px; line-height: 1.6; }
                    .btn { display: inline-block; background: #2563EB; color: #FFFFFF !important; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: 600; margin-top: 16px; }
                    .footer { background: #F9FAFB; padding: 16px 24px; text-align: center; font-size: 12px; color: #6B7280; border-top: 1px solid #E5E7EB; }
                  </style>
                </head>
                <body>
                  <div class="card">
                    <div class="header">
                      <h2 style="margin: 0; font-size: 20px;">%s</h2>
                    </div>
                    <div class="content">
                      <p style="margin: 0 0 8px 0; font-size: 17px; font-weight: 600; color: #111827;">%s</p>
                      <p style="margin: 0; font-size: 14px; color: #374151;">%s</p>
                      %s
                    </div>
                    <div class="footer">
                      <p style="margin: 0;">%s</p>
                    </div>
                  </div>
                </body>
                </html>
                """.formatted(
                escapar(safeTitulo),
                MARCA,
                escapar(safeTitulo),
                htmlMensaje,
                botonHtml,
                PIE
        );

        StringBuilder texto = new StringBuilder()
                .append(MARCA).append("\n\n")
                .append(safeTitulo).append("\n\n")
                .append(safeMensaje);
        if (accionTexto != null && !accionTexto.isBlank() && accionUrl != null && !accionUrl.isBlank()) {
            texto.append("\n\n").append(accionTexto).append(": ").append(accionUrl);
        }
        texto.append("\n\n").append(PIE);

        return new EmailContent(html, texto.toString());
    }

    private String botonHtml(String texto, String url) {
        if (texto == null || texto.isBlank() || url == null || url.isBlank()) {
            return "";
        }
        return "<p style=\"margin: 0;\"><a class=\"btn\" href=\"%s\">%s</a></p>"
                .formatted(escapar(url), escapar(texto));
    }

    /** Escapa el HTML del usuario para que el mensaje no rompa el layout ni inyecte marcado. */
    static String escapar(String valor) {
        if (valor == null) {
            return "";
        }
        return valor
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
