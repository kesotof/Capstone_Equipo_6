package com.capstone.notificaciones.contrato;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.UUID;

/**
 * F4 (§5.2) — resultado al principal (routing «notificacion.correo.resultado»), uno por intento.
 * {@code resultado} ∈ {ENVIADO, FALLIDO}; {@code final = true} cuando no habrá más intentos
 * (el nombre JSON es {@code final}, palabra reservada en Java). Espejo idéntico al record del
 * sistema principal.
 */
public record ResultadoCorreo(
        int version,
        UUID mensajeId,
        Long notificacionId,
        int intento,
        String resultado,
        @JsonProperty("final") boolean resultadoFinal,
        String destino,
        String proveedorId,
        String codigoError,
        String errorDetalle,
        Instant ocurridoEn
) {
}
