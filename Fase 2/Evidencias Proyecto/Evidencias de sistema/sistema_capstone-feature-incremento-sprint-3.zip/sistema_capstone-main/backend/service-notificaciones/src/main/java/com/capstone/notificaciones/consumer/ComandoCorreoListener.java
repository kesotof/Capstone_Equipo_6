package com.capstone.notificaciones.consumer;

import com.capstone.notificaciones.config.RabbitConfig;
import com.capstone.notificaciones.contrato.ComandoEnviarCorreo;
import com.capstone.notificaciones.service.ProcesadorCorreo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * F4 (§8.1): consumidor de {@code notificacion.correo.q} con tipo inferido (§3.1) — delega en
 * {@link ProcesadorCorreo} y no hace nada más (listener delgado).
 *
 * <p>Payload inválido → {@link AmqpRejectAndDontRequeueException} sin reenqueue; la cola y su
 * DLQ las declara {@code RabbitConfig}. Reemplaza al legado {@code NotificationQueueListener}
 * (cola {@code notifications.email.queue}, eliminada en §3.1).</p>
 */
@Component
public class ComandoCorreoListener {

    private static final Logger log = LoggerFactory.getLogger(ComandoCorreoListener.class);

    private final ProcesadorCorreo procesadorCorreo;

    public ComandoCorreoListener(ProcesadorCorreo procesadorCorreo) {
        this.procesadorCorreo = procesadorCorreo;
    }

    @RabbitListener(queues = RabbitConfig.COLA_CORREO)
    public void onComando(ComandoEnviarCorreo comando) {
        log.info("Comando de correo recibido: notificación {} mensaje {} intentoInicial {}",
                comando.notificacionId(), comando.mensajeId(), comando.intentoInicial());
        procesadorCorreo.procesar(comando);
    }
}
