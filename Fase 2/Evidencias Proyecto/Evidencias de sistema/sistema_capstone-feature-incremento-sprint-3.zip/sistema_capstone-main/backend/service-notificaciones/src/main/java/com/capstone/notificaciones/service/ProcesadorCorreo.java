package com.capstone.notificaciones.service;

import com.capstone.notificaciones.client.ResendEmailClient;
import com.capstone.notificaciones.config.RabbitConfig;
import com.capstone.notificaciones.contrato.ComandoEnviarCorreo;
import com.capstone.notificaciones.contrato.ResultadoCorreo;
import com.capstone.notificaciones.template.EmailTemplateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

/**
 * F4 (§8.1): procesa un {@code ComandoEnviarCorreo} con el ciclo de reintentos del plan —
 * {@code intento = intentoInicial … intentoInicial + 2}:
 *
 * <ul>
 *   <li>Envía y publica un {@code ResultadoCorreo} <strong>por intento</strong> (§5.2).</li>
 *   <li>Si el envío fue ENVIADO o el error no es reintentable ({@code DESTINO_INVALIDO},
 *       {@code CONFIGURACION}) → {@code final = true} y termina.</li>
 *   <li>Si es {@code PROVEEDOR_NO_DISPONIBLE} (429/5xx/timeout) espera
 *       {@code correo.reintentos.esperas[i]} (5 s, 30 s) y repite. <strong>El último intento
 *       siempre es {@code final = true}</strong>.</li>
 *   <li>Si la publicación del resultado falla: log {@code error} y ack — el re-publicador del
 *       principal re-envía el comando y Resend deduplica con el {@code Idempotency-Key}
 *       fijo {@code notif-{notificacionId}}.</li>
 * </ul>
 *
 * <p>Payload inválido → {@link AmqpRejectAndDontRequeueException} (sin reenqueue, §3.1).</p>
 */
@Service
public class ProcesadorCorreo {

    private static final Logger log = LoggerFactory.getLogger(ProcesadorCorreo.class);

    /** Intentos adicionales después del inicial: inicial + 2 = 3 intentos máximo. */
    static final int INTENTOS_ADICIONALES = 2;
    private static final Duration ESPERA_FALLBACK = Duration.ofSeconds(30);

    private final ResendEmailClient resendEmailClient;
    private final EmailTemplateService emailTemplateService;
    private final RabbitTemplate rabbitTemplate;
    private final List<Duration> esperas;

    public ProcesadorCorreo(
            ResendEmailClient resendEmailClient,
            EmailTemplateService emailTemplateService,
            RabbitTemplate rabbitTemplate,
            @Value("${correo.reintentos.esperas:5s,30s}") List<Duration> esperas
    ) {
        this.resendEmailClient = resendEmailClient;
        this.emailTemplateService = emailTemplateService;
        this.rabbitTemplate = rabbitTemplate;
        this.esperas = esperas;
    }

    public void procesar(ComandoEnviarCorreo comando) {
        validar(comando);

        EmailTemplateService.EmailContent plantilla = emailTemplateService.render(
                comando.titulo(),
                comando.mensaje(),
                comando.accion() != null ? comando.accion().texto() : null,
                comando.accion() != null ? comando.accion().url() : null
        );
        String idempotencyKey = "notif-" + comando.notificacionId();   // §8.1, fijo por notificación

        int hasta = comando.intentoInicial() + INTENTOS_ADICIONALES;
        for (int intento = comando.intentoInicial(); intento <= hasta; intento++) {
            boolean ultimo = intento == hasta;

            ResendEmailClient.ResultadoEnvio envio = resendEmailClient.enviar(
                    comando.destinatario().email(), comando.asunto(),
                    plantilla.html(), plantilla.text(), idempotencyKey);

            boolean reintentable = ResendEmailClient.CODIGO_PROVEEDOR_NO_DISPONIBLE.equals(envio.codigoError());
            boolean final_ = envio.exito() || !reintentable || ultimo;

            ResultadoCorreo resultado = new ResultadoCorreo(
                    comando.version(),
                    comando.mensajeId(),
                    comando.notificacionId(),
                    intento,
                    envio.exito() ? "ENVIADO" : "FALLIDO",
                    final_,
                    comando.destinatario().email(),
                    envio.proveedorId(),
                    envio.codigoError(),
                    envio.detalle(),
                    Instant.now()
            );
            publicarResultado(resultado);

            if (final_) {
                log.info("Correo notificación {} intento {}: {} (final={}, código={})",
                        comando.notificacionId(), intento, resultado.resultado(), final_, envio.codigoError());
                return;
            }
            log.warn("Correo notificación {} intento {} fallido ({}); se reintenta en {}",
                    comando.notificacionId(), intento, envio.codigoError(),
                    esperaPara(intento - comando.intentoInicial()));
            esperarEntreIntentos(esperaPara(intento - comando.intentoInicial()));
        }
    }

    /** §3.1: campos obligatorios; inválido → sin reenqueue (va a la DLQ). */
    private void validar(ComandoEnviarCorreo c) {
        if (c.version() != 1
                || c.mensajeId() == null
                || c.notificacionId() == null
                || c.intentoInicial() < 1
                || c.destinatario() == null
                || c.destinatario().email() == null
                || c.destinatario().email().isBlank()) {
            log.warn("Comando de correo inválido (mensaje {}); se rechaza sin reenqueue", c != null ? c.mensajeId() : null);
            throw new AmqpRejectAndDontRequeueException(
                    "Comando de correo inválido: version, mensajeId, notificacionId, intentoInicial>=1 y destinatario.email son obligatorios");
        }
    }

    /** §8.1: si publicar el resultado falla → log y ack (el principal re-publica). */
    private void publicarResultado(ResultadoCorreo resultado) {
        try {
            rabbitTemplate.convertAndSend(
                    RabbitConfig.EXCHANGE_NAME,
                    RabbitConfig.ROUTING_CORREO_RESULTADO,
                    resultado,
                    mensaje -> {
                        mensaje.getMessageProperties().setMessageId(resultado.mensajeId().toString());
                        mensaje.getMessageProperties().setHeader("x-contrato-version", resultado.version());
                        return mensaje;
                    }
            );
        } catch (RuntimeException e) {
            log.error("No se pudo publicar ResultadoCorreo notificación {} intento {} (se hace ack; "
                            + "el re-publicador del principal lo re-enviará): {}",
                    resultado.notificacionId(), resultado.intento(), e.getMessage(), e);
        }
    }

    private Duration esperaPara(int indice) {
        if (esperas != null && indice >= 0 && indice < esperas.size()) {
            return esperas.get(indice);
        }
        return ESPERA_FALLBACK;
    }

    /** Visible para las pruebas con reloj falso (se reemplaza por un spy sin espera real). */
    void esperarEntreIntentos(Duration duracion) {
        try {
            Thread.sleep(duracion.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
