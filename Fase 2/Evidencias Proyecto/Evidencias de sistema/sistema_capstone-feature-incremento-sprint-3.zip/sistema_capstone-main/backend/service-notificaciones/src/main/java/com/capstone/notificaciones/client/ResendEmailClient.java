package com.capstone.notificaciones.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * F4 (§8.1): cliente HTTP hacia la API de Resend ({@code POST /emails}).
 *
 * <ul>
 *   <li>Header {@code Idempotency-Key} fijo por notificación ({@code notif-{notificacionId}}):
 *       Resend deduplica los re-envíos del re-publicador del principal.</li>
 *   <li>Timeouts: conexión 5 s, lectura 10 s.</li>
 *   <li><strong>Nunca lanza excepciones</strong>: devuelve
 *       {@link ResultadoEnvio(exito, proveedorId, httpStatus, codigoError, detalle)} con la
 *       clasificación del plan: 2xx → éxito; 400/422 → {@code DESTINO_INVALIDO}; 401/403 →
 *       {@code CONFIGURACION} (ambos no reintentables); 429/5xx/timeout →
 *       {@code PROVEEDOR_NO_DISPONIBLE} (reintentable).</li>
 *   <li>Simulación ({@code resend.simulation-enabled} o clave sin configurar): éxito simulado;
 *       si {@code resend.simulation.fallar-destinos} (regex) coincide con el destinatario,
 *       simula un 503 para probar CA 09.4/09.5 sin red.</li>
 * </ul>
 */
@Component
public class ResendEmailClient {

    private static final Logger log = LoggerFactory.getLogger(ResendEmailClient.class);

    public static final String CODIGO_DESTINO_INVALIDO = "DESTINO_INVALIDO";
    public static final String CODIGO_CONFIGURACION = "CONFIGURACION";
    public static final String CODIGO_PROVEEDOR_NO_DISPONIBLE = "PROVEEDOR_NO_DISPONIBLE";

    /** Resultado de un intento de envío; jamás se lanza excepción hacia el caller. */
    public record ResultadoEnvio(
            boolean exito,
            String proveedorId,
            Integer httpStatus,
            String codigoError,
            String detalle
    ) {
    }

    public record SendEmailRequest(String from, String to, String subject, String html, String text) {
    }

    private final RestClient restClient;
    private final ObjectMapper mapper;
    private final String apiKey;
    private final String fromAddress;
    private final boolean simulationEnabled;
    private final long simulationDelayMs;
    private final Pattern fallarDestinos;

    @Autowired
    public ResendEmailClient(
            @Value("${resend.api-key:your_resend_api_key_here}") String apiKey,
            @Value("${resend.from-address:Capstone Sistema <onboarding@resend.dev>}") String fromAddress,
            @Value("${resend.simulation-enabled:true}") boolean simulationEnabled,
            @Value("${resend.simulation-delay-ms:300}") long simulationDelayMs,
            @Value("${resend.simulation.fallar-destinos:}") String fallarDestinos,
            ObjectMapper jsonMapper
    ) {
        this(conTimeouts(RestClient.builder()),
                apiKey, fromAddress, simulationEnabled, simulationDelayMs, fallarDestinos, jsonMapper);
    }

    /** Forma extensible para pruebas: un {@code RestClient.Builder} externo (MockRestServiceServer). */
    ResendEmailClient(
            RestClient.Builder builder,
            String apiKey,
            String fromAddress,
            boolean simulationEnabled,
            long simulationDelayMs,
            String fallarDestinos,
            ObjectMapper jsonMapper
    ) {
        String key = apiKey != null ? apiKey.trim() : "";
        this.apiKey = key;
        this.fromAddress = fromAddress;
        this.simulationEnabled = simulationEnabled;
        this.simulationDelayMs = simulationDelayMs;
        this.mapper = jsonMapper;

        Pattern parsed = null;
        if (fallarDestinos != null && !fallarDestinos.isBlank()) {
            try {
                parsed = Pattern.compile(fallarDestinos.trim());
            } catch (PatternSyntaxException e) {
                log.error("resend.simulation.fallar-destinos no es una regex válida; se ignora: {}", fallarDestinos);
            }
        }
        this.fallarDestinos = parsed;

        this.restClient = builder
                .baseUrl("https://api.resend.com")
                .defaultHeader("Authorization", "Bearer " + key)
                .defaultHeader("User-Agent", "CapstoneDocumentSystem/1.0")
                .defaultHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    /** §8.1: timeouts de conexión 5 s y lectura 10 s. */
    private static RestClient.Builder conTimeouts(RestClient.Builder builder) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(Duration.ofSeconds(5));
        requestFactory.setReadTimeout(Duration.ofSeconds(10));
        return builder.requestFactory(requestFactory);
    }

    /**
     * @param idempotencyKey header {@code Idempotency-Key} (fijo por notificación); si es
     *                        {@code null} o vacío no se envía el header.
     */
    public ResultadoEnvio enviar(String to, String asunto, String html, String text, String idempotencyKey) {
        if (debeSimular()) {
            return simular(to, asunto);
        }

        try {
            return restClient.post()
                    .uri("/emails")
                    .headers(headers -> {
                        if (idempotencyKey != null && !idempotencyKey.isBlank()) {
                            headers.set("Idempotency-Key", idempotencyKey);
                        }
                    })
                    .body(new SendEmailRequest(fromAddress, to, asunto, html, text))
                    .exchange((request, response) -> clasificar(to, response));
        } catch (RuntimeException e) {
            // Timeout, DNS, conexión rechazada…: reintentable, sin excepciones (§8.1).
            log.warn("Sin respuesta de Resend para {}: {}", to, e.getMessage());
            return new ResultadoEnvio(false, null, null, CODIGO_PROVEEDOR_NO_DISPONIBLE,
                    "Sin respuesta del proveedor: " + e.getMessage());
        }
    }

    private ResultadoEnvio clasificar(String to, org.springframework.http.client.ClientHttpResponse response)
            throws IOException {
        int status;
        try {
            status = response.getStatusCode().value();
        } catch (IOException e) {
            return new ResultadoEnvio(false, null, null, CODIGO_PROVEEDOR_NO_DISPONIBLE,
                    "Sin respuesta del proveedor: " + e.getMessage());
        }
        String body = response.getBody() != null
                ? new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8)
                : "";

        if (status >= 200 && status < 300) {
            String emailId = extraerId(body);
            log.info("Correo enviado a {} (HTTP {}, id: {})", to, status, emailId);
            return new ResultadoEnvio(true, emailId, status, null, null);
        }
        String codigo = clasificarError(status);
        log.warn("Resend rechazó el correo a {} (HTTP {}): {} — {}", to, status, codigo, recortar(body));
        return new ResultadoEnvio(false, null, status, codigo, recortar(body));
    }

    /** §8.1: 400/422 destino inválido, 401/403 configuración, 429/5xx proveedor no disponible. */
    private String clasificarError(int status) {
        if (status == 400 || status == 422) {
            return CODIGO_DESTINO_INVALIDO;
        }
        if (status == 401 || status == 403) {
            return CODIGO_CONFIGURACION;
        }
        return CODIGO_PROVEEDOR_NO_DISPONIBLE;
    }

    private String extraerId(String body) {
        try {
            JsonNode node = mapper.readTree(body);
            JsonNode id = node.get("id");
            return id != null && !id.isNull() ? id.asText() : "unknown";
        } catch (Exception e) {
            return "unknown";
        }
    }

    private String recortar(String body) {
        if (body == null) {
            return "";
        }
        String limpio = body.replaceAll("\\s+", " ").trim();
        return limpio.length() > 500 ? limpio.substring(0, 500) + "…" : limpio;
    }

    private boolean debeSimular() {
        return simulationEnabled
                || apiKey.isEmpty()
                || apiKey.contains("your_resend_api_key_here")
                || apiKey.equals("dummy_key")
                || apiKey.equals("re_test_key");
    }

    private ResultadoEnvio simular(String to, String asunto) {
        if (fallarDestinos != null && fallarDestinos.matcher(to).matches()) {
            log.warn("[SIMULACIÓN] 503 simulado hacia {} (resend.simulation.fallar-destinos coincide)", to);
            return new ResultadoEnvio(false, null, 503, CODIGO_PROVEEDOR_NO_DISPONIBLE,
                    "503 Service Unavailable (simulado)");
        }
        if (simulationDelayMs > 0) {
            try {
                Thread.sleep(simulationDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        String simId = "sim_" + UUID.randomUUID();
        log.info("[SIMULACIÓN] Correo simulado hacia {} — asunto '{}' — id {}", to, asunto, simId);
        return new ResultadoEnvio(true, simId, 200, null, null);
    }
}
