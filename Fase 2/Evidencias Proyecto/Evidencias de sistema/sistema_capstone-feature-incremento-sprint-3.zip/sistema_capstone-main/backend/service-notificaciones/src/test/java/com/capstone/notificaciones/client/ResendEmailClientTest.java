package com.capstone.notificaciones.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

import java.net.SocketTimeoutException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.ExpectedCount.once;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

/**
 * F4 (§8.1): el cliente nunca lanza excepciones; clasifica 2xx/400-422/401-403/429-5xx/timeout;
 * envía {@code Idempotency-Key: notif-{notificacionId}}; la simulación de {@code fallar-destinos}
 * produce un 503 reintentable sin red.
 */
class ResendEmailClientTest {

    private final ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());

    // ------------------------------------------------------------------ simulación

    @Test
    @DisplayName("Simulación activa: éxito simulado sin red")
    void simulacionExito() {
        ResendEmailClient client = new ResendEmailClient(
                RestClient.builder(), "re_123", "Test <a@b.cl>", true, 0, "", mapper);

        ResendEmailClient.ResultadoEnvio r = client.enviar(
                "user@capstone.local", "Asunto", "<p>H</p>", "T", "notif-1");

        assertThat(r.exito()).isTrue();
        assertThat(r.proveedorId()).startsWith("sim_");
        assertThat(r.httpStatus()).isEqualTo(200);
        assertThat(r.codigoError()).isNull();
    }

    @Test
    @DisplayName("simulation.fallar-destinos: 503 simulado reintentable (CA 09.4/09.5 sin red)")
    void simulacionFallaParaDestinoRegex() {
        ResendEmailClient client = new ResendEmailClient(
                RestClient.builder(), "re_123", "Test <a@b.cl>", true, 0, ".*@fallo\\.test", mapper);

        ResendEmailClient.ResultadoEnvio r = client.enviar(
                "destinatario@fallo.test", "Asunto", "<p>H</p>", "T", "notif-2");

        assertThat(r.exito()).isFalse();
        assertThat(r.httpStatus()).isEqualTo(503);
        assertThat(r.codigoError()).isEqualTo(ResendEmailClient.CODIGO_PROVEEDOR_NO_DISPONIBLE);
    }

    @Test
    @DisplayName("Clave sin configurar con simulación apagada: se simula igualmente")
    void claveDummyActivaSimulacion() {
        ResendEmailClient client = new ResendEmailClient(
                RestClient.builder(), "your_resend_api_key_here", "Test <a@b.cl>", false, 0, "", mapper);

        ResendEmailClient.ResultadoEnvio r = client.enviar(
                "user@capstone.local", "Asunto", "<p>H</p>", "T", "notif-3");

        assertThat(r.exito()).isTrue();
        assertThat(r.proveedorId()).startsWith("sim_");
    }

    // ------------------------------------------------------------------ red (clasificación)

    @Test
    @DisplayName("200 → éxito con id del proveedor y header Idempotency-Key (§8.1)")
    void http200EsExito() {
        RestClient.Builder builder = RestClient.builder();
        MockRestServiceServer server = MockRestServiceServer.bindTo(builder).build();
        ResendEmailClient client = new ResendEmailClient(
                builder, "re_real", "Capstone <nr@capstone.cl>", false, 0, "", mapper);

        server.expect(once(), requestTo("https://api.resend.com/emails"))
                .andExpect(header("Idempotency-Key", "notif-42"))
                .andRespond(withSuccess("{\"id\":\"msg_abc\"}", MediaType.APPLICATION_JSON));

        ResendEmailClient.ResultadoEnvio r = client.enviar(
                "d@empresa.cl", "Asunto", "<p>H</p>", "T", "notif-42");

        assertThat(r.exito()).isTrue();
        assertThat(r.proveedorId()).isEqualTo("msg_abc");
        assertThat(r.httpStatus()).isEqualTo(200);
        assertThat(r.codigoError()).isNull();
        server.verify();
    }

    @Test
    @DisplayName("422 → DESTINO_INVALIDO (no reintentable)")
    void http422DestinoInvalido() {
        RestClient.Builder builder = RestClient.builder();
        MockRestServiceServer server = MockRestServiceServer.bindTo(builder).build();
        ResendEmailClient client = new ResendEmailClient(
                builder, "re_real", "Capstone <nr@capstone.cl>", false, 0, "", mapper);

        server.expect(once(), requestTo("https://api.resend.com/emails"))
                .andRespond(withStatus(org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY)
                        .body("{\"message\":\"Invalid\"}")
                        .contentType(MediaType.APPLICATION_JSON));

        ResendEmailClient.ResultadoEnvio r = client.enviar("d@empresa.cl", "A", "h", "t", "k");

        assertThat(r.exito()).isFalse();
        assertThat(r.httpStatus()).isEqualTo(422);
        assertThat(r.codigoError()).isEqualTo(ResendEmailClient.CODIGO_DESTINO_INVALIDO);
        assertThat(r.detalle()).contains("Invalid");
        server.verify();
    }

    @Test
    @DisplayName("401 → CONFIGURACION (no reintentable)")
    void http401Configuracion() {
        RestClient.Builder builder = RestClient.builder();
        MockRestServiceServer server = MockRestServiceServer.bindTo(builder).build();
        ResendEmailClient client = new ResendEmailClient(
                builder, "re_real", "Capstone <nr@capstone.cl>", false, 0, "", mapper);

        server.expect(once(), requestTo("https://api.resend.com/emails"))
                .andRespond(withStatus(org.springframework.http.HttpStatus.UNAUTHORIZED));

        ResendEmailClient.ResultadoEnvio r = client.enviar("d@empresa.cl", "A", "h", "t", "k");

        assertThat(r.exito()).isFalse();
        assertThat(r.codigoError()).isEqualTo(ResendEmailClient.CODIGO_CONFIGURACION);
        server.verify();
    }

    @Test
    @DisplayName("503 → PROVEEDOR_NO_DISPONIBLE (reintentable)")
    void http503ProveedorNoDisponible() {
        RestClient.Builder builder = RestClient.builder();
        MockRestServiceServer server = MockRestServiceServer.bindTo(builder).build();
        ResendEmailClient client = new ResendEmailClient(
                builder, "re_real", "Capstone <nr@capstone.cl>", false, 0, "", mapper);

        server.expect(once(), requestTo("https://api.resend.com/emails"))
                .andRespond(withStatus(org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE)
                        .body("{\"message\":\"unavailable\"}")
                        .contentType(MediaType.APPLICATION_JSON));

        ResendEmailClient.ResultadoEnvio r = client.enviar("d@empresa.cl", "A", "h", "t", "k");

        assertThat(r.exito()).isFalse();
        assertThat(r.httpStatus()).isEqualTo(503);
        assertThat(r.codigoError()).isEqualTo(ResendEmailClient.CODIGO_PROVEEDOR_NO_DISPONIBLE);
        server.verify();
    }

    @Test
    @DisplayName("Timeout de lectura → PROVEEDOR_NO_DISPONIBLE sin excepciones")
    void timeoutNoLanzaExcepciones() {
        RestClient.Builder builder = RestClient.builder();
        MockRestServiceServer server = MockRestServiceServer.bindTo(builder).build();
        ResendEmailClient client = new ResendEmailClient(
                builder, "re_real", "Capstone <nr@capstone.cl>", false, 0, "", mapper);

        server.expect(once(), requestTo("https://api.resend.com/emails"))
                .andRespond(request -> {
                    throw new SocketTimeoutException("Read timed out");
                });

        ResendEmailClient.ResultadoEnvio r = client.enviar("d@empresa.cl", "A", "h", "t", "k");

        assertThat(r.exito()).isFalse();
        assertThat(r.httpStatus()).isNull();
        assertThat(r.codigoError()).isEqualTo(ResendEmailClient.CODIGO_PROVEEDOR_NO_DISPONIBLE);
        assertThat(r.detalle()).contains("Sin respuesta del proveedor");
        server.verify();
    }
}
