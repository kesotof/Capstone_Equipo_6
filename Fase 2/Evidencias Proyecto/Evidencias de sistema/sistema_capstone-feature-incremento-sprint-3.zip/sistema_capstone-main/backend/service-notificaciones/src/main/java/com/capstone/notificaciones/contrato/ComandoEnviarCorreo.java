package com.capstone.notificaciones.contrato;

import java.time.Instant;
import java.util.UUID;

/**
 * F4 (§5.1) — comando del principal a este servicio (routing «notificacion.correo.enviar»).
 * Espejo idéntico al record de {@code sistema-principal}: los tests de round-trip contra
 * {@code src/test/resources/contratos/comando-enviar-correo.json} son el contrato; nunca
 * editar un lado sin actualizar el otro.
 */
public record ComandoEnviarCorreo(
        int version,
        UUID mensajeId,
        Long notificacionId,
        int intentoInicial,
        Destinatario destinatario,
        String asunto,
        String titulo,
        String mensaje,
        Accion accion,
        String categoria,
        Instant emitidoEn
) {

    public record Destinatario(String email, String nombre) {
    }

    public record Accion(String texto, String url) {
    }
}
