package com.capstone.notificaciones.consumer;

import com.capstone.notificaciones.contrato.ComandoEnviarCorreo;
import com.capstone.notificaciones.service.ProcesadorCorreo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

/** F4 (§8.1): listener delgado sobre {@code notificacion.correo.q}; delega y propaga. */
@ExtendWith(MockitoExtension.class)
class ComandoCorreoListenerTest {

    @Mock
    private ProcesadorCorreo procesadorCorreo;

    @InjectMocks
    private ComandoCorreoListener listener;

    private ComandoEnviarCorreo comando() {
        return new ComandoEnviarCorreo(
                1, UUID.randomUUID(), 42L, 1,
                new ComandoEnviarCorreo.Destinatario("d@empresa.cl", "D"),
                "Asunto", "T", "M",
                new ComandoEnviarCorreo.Accion("Ver solicitud", "http://localhost:3000/solicitudes/1"),
                "INFORMATIVA", Instant.now());
    }

    @Test
    @DisplayName("Delega el comando en ProcesadorCorreo sin interpretarlo")
    void delegaEnProcesador() {
        ComandoEnviarCorreo cmd = comando();

        listener.onComando(cmd);

        verify(procesadorCorreo).procesar(cmd);
    }

    @Test
    @DisplayName("Payload inválido: la excepción se propaga al broker (sin reenqueue → DLQ)")
    void propagaRechazo() {
        doThrow(new AmqpRejectAndDontRequeueException("inválido"))
                .when(procesadorCorreo).procesar(any());

        assertThrows(AmqpRejectAndDontRequeueException.class, () -> listener.onComando(comando()));
    }
}
