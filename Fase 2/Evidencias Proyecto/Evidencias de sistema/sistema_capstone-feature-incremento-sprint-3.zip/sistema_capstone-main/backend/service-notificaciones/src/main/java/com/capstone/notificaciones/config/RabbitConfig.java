package com.capstone.notificaciones.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * F4 (§3.1/§8.1): topología RabbitMQ de este servicio como consumidor de
 * {@code notificacion.correo.q}. Declara el exchange y la DLX (idempotentes, todos los
 * servicios) y <strong>únicamente sus propias colas</strong>: la cola con DLX, su binding y la
 * DLQ (regla: cada cola la declara solo su consumidor para evitar PRECONDITION_FAILED).
 *
 * <p>El conversor infiere el tipo del parámetro del listener
 * ({@code setAlwaysConvertToInferredType(true)}): las clases de los otros servicios no están en
 * el classpath, por lo que el header {@code __TypeId__} no sirve.</p>
 *
 * <p>Los resultados (§5.2) salen por el mismo exchange con
 * {@link #ROUTING_CORREO_RESULTADO} vía {@link RabbitTemplate}.</p>
 */
@Configuration
public class RabbitConfig {

    public static final String EXCHANGE_NAME = "capstone.exchange";
    public static final String DLX_NAME = "capstone.dlx";

    public static final String ROUTING_CORREO_ENVIAR = "notificacion.correo.enviar";
    public static final String ROUTING_CORREO_RESULTADO = "notificacion.correo.resultado";

    public static final String COLA_CORREO = "notificacion.correo.q";
    public static final String COLA_CORREO_DLQ = COLA_CORREO + ".dlq";

    @Bean
    public TopicExchange capstoneExchange() {
        return new TopicExchange(EXCHANGE_NAME, true, false);
    }

    @Bean
    public DirectExchange capstoneDlx() {
        return new DirectExchange(DLX_NAME, true, false);
    }

    /** Cola de envío con carta muerta hacia la DLX (§3.1). */
    @Bean
    public Queue colaCorreo() {
        return QueueBuilder.durable(COLA_CORREO)
                .withArgument("x-dead-letter-exchange", DLX_NAME)
                .withArgument("x-dead-letter-routing-key", COLA_CORREO)
                .build();
    }

    @Bean
    public Binding bindingCorreo(TopicExchange capstoneExchange, Queue colaCorreo) {
        return BindingBuilder.bind(colaCorreo).to(capstoneExchange).with(ROUTING_CORREO_ENVIAR);
    }

    @Bean
    public Queue colaCorreoDlq() {
        return QueueBuilder.durable(COLA_CORREO_DLQ).build();
    }

    @Bean
    public Binding bindingCorreoDlq(DirectExchange capstoneDlx, Queue colaCorreoDlq) {
        return BindingBuilder.bind(colaCorreoDlq).to(capstoneDlx).with(COLA_CORREO);
    }

    @Bean
    public Jackson2JsonMessageConverter jsonMessageConverter(ObjectMapper jsonMapper) {
        // ObjectMapper autoconfigurado de Boot (JavaTimeModule + sin timestamps).
        Jackson2JsonMessageConverter converter = new Jackson2JsonMessageConverter(jsonMapper);
        // §3.1: el tipo se infiere del parámetro del listener, no del header __TypeId__.
        converter.setAlwaysConvertToInferredType(true);
        return converter;
    }

    @Bean
    public RabbitTemplate rabbitTemplate(
            org.springframework.amqp.rabbit.connection.ConnectionFactory connectionFactory,
            Jackson2JsonMessageConverter jsonMessageConverter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter);
        return template;
    }
}
