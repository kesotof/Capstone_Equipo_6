package com.capstone.notificaciones.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;

import static org.assertj.core.api.Assertions.assertThat;

class RabbitConfigTest {

    private final RabbitConfig config = new RabbitConfig();

    @Test
    @DisplayName("capstone.dlx debe ser DirectExchange")
    void capstoneDlx_esDirectExchange() {
        DirectExchange dlx = config.capstoneDlx();
        assertThat(dlx.getName()).isEqualTo("capstone.dlx");
        assertThat(dlx.isDurable()).isTrue();
        assertThat(dlx.isAutoDelete()).isFalse();
    }

    @Test
    @DisplayName("bindingCorreoDlq usa DirectExchange con routing key notificacion.correo.q")
    void bindingCorreoDlq_usaClaveCorrecta() {
        DirectExchange dlx = config.capstoneDlx();
        Queue dlq = config.colaCorreoDlq();
        Binding binding = config.bindingCorreoDlq(dlx, dlq);

        assertThat(binding.getExchange()).isEqualTo("capstone.dlx");
        assertThat(binding.getRoutingKey()).isEqualTo("notificacion.correo.q");
        assertThat(binding.getDestination()).isEqualTo("notificacion.correo.q.dlq");
    }
}
