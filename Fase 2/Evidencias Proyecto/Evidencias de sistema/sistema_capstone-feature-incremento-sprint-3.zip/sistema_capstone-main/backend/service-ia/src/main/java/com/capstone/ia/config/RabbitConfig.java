package com.capstone.ia.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * F7 (§3.1, §8.2): configuración de mensajería asíncrona para service-ia.
 * Declara capstone.exchange, capstone.dlx, ia.tarea.q con DLX y ia.tarea.q.dlq.
 */
@Configuration
public class RabbitConfig {

    public static final String EXCHANGE_NAME = "capstone.exchange";
    public static final String DLX_NAME = "capstone.dlx";

    public static final String ROUTING_IA_EJECUTAR = "ia.tarea.ejecutar";
    public static final String ROUTING_IA_RESULTADO = "ia.tarea.resultado";

    public static final String COLA_IA = "ia.tarea.q";
    public static final String COLA_IA_DLQ = COLA_IA + ".dlq";

    public static final String AI_AUTOCOMPLETE_ROUTING_KEY = "ai.autocomplete";
    public static final String AI_AUTOCOMPLETE_RESULT_ROUTING_KEY = "ai.autocomplete.result";
    public static final String AI_FIELDS_ROUTING_KEY = "ai.fields";
    public static final String AI_FIELDS_RESULT_ROUTING_KEY = "ai.fields.result";

    @Bean
    public TopicExchange capstoneExchange() {
        return new TopicExchange(EXCHANGE_NAME, true, false);
    }

    @Bean
    public DirectExchange capstoneDlx() {
        return new DirectExchange(DLX_NAME, true, false);
    }

    /** Cola de tareas de IA con DLX configurada. */
    @Bean
    public Queue colaIa() {
        return QueueBuilder.durable(COLA_IA)
                .withArgument("x-dead-letter-exchange", DLX_NAME)
                .withArgument("x-dead-letter-routing-key", COLA_IA)
                .build();
    }

    @Bean
    public Binding bindingIa(TopicExchange capstoneExchange, Queue colaIa) {
        return BindingBuilder.bind(colaIa).to(capstoneExchange).with(ROUTING_IA_EJECUTAR);
    }

    @Bean
    public Queue colaIaDlq() {
        return QueueBuilder.durable(COLA_IA_DLQ).build();
    }

    @Bean
    public Binding bindingIaDlq(DirectExchange capstoneDlx, Queue colaIaDlq) {
        return BindingBuilder.bind(colaIaDlq).to(capstoneDlx).with(COLA_IA);
    }

    @Bean
    public Jackson2JsonMessageConverter jsonMessageConverter(ObjectMapper jsonMapper) {
        Jackson2JsonMessageConverter converter = new Jackson2JsonMessageConverter(jsonMapper);
        converter.setAlwaysConvertToInferredType(true);
        return converter;
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, Jackson2JsonMessageConverter converter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(converter);
        return template;
    }
}
