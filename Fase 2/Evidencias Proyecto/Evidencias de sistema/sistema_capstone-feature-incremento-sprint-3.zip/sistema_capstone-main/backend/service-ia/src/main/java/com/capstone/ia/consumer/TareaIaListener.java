package com.capstone.ia.consumer;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.contrato.ResultadoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.handler.AutocompletadoHandler;
import com.capstone.ia.handler.HandlerResult;
import com.capstone.ia.handler.ChatHandler;
import com.capstone.ia.handler.EvaluacionHandler;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/**
 * F7 (§8.2): listener AMQP para comandos de ejecución de IA en {@code ia.tarea.q}.
 * Despacha al handler correspondiente y publica el resultado a {@code ia.tarea.resultado}.
 */
@Component
public class TareaIaListener {

    private static final Logger log = LoggerFactory.getLogger(TareaIaListener.class);

    private final EvaluacionHandler evaluacionHandler;
    private final ChatHandler chatHandler;
    private final AutocompletadoHandler autocompletadoHandler;
    private final OpenRouterApiClient openRouterClient;
    private final RabbitTemplate rabbitTemplate;

    public TareaIaListener(
            EvaluacionHandler evaluacionHandler,
            ChatHandler chatHandler,
            AutocompletadoHandler autocompletadoHandler,
            OpenRouterApiClient openRouterClient,
            RabbitTemplate rabbitTemplate
    ) {
        this.evaluacionHandler = evaluacionHandler;
        this.chatHandler = chatHandler;
        this.autocompletadoHandler = autocompletadoHandler;
        this.openRouterClient = openRouterClient;
        this.rabbitTemplate = rabbitTemplate;
    }

    @RabbitListener(queues = RabbitConfig.COLA_IA)
    public void procesarComando(ComandoTareaIa comando) {
        if (comando == null || comando.tareaId() == null || comando.tipo() == null) {
            log.warn("Comando de IA inválido o nulo recibido en cola: {}", comando);
            throw new AmqpRejectAndDontRequeueException("Comando de IA inválido o incompleto: " + comando);
        }

        log.info("Comando de IA recibido: tareaId={} tipo={} version={}",
                comando.tareaId(), comando.tipo(), comando.version());

        ResultadoTareaIa resultado;
        try {
            HandlerResult handlerRes = switch (comando.tipo().toUpperCase()) {
                case "EVALUACION" -> evaluacionHandler.procesar(comando);
                case "CHAT" -> chatHandler.procesar(comando);
                case "AUTOCOMPLETAR" -> autocompletadoHandler.procesar(comando);
                default -> throw IaProcesamientoException.comandoNoSoportado(comando.tipo());
            };

            resultado = ResultadoTareaIa.exitosa(
                    comando.tareaId(),
                    comando.tipo(),
                    handlerRes.data(),
                    handlerRes.modelo()
            );
            log.info("Tarea de IA {} ({}) completada exitosamente", comando.tareaId(), comando.tipo());

        } catch (IaProcesamientoException e) {
            log.warn("Fallo controlado en tarea de IA {}: codigoError={} detalle={}",
                    comando.tareaId(), e.getCodigoError(), e.getMessage());
            resultado = ResultadoTareaIa.fallida(
                    comando.tareaId(),
                    comando.tipo(),
                    e.getCodigoError(),
                    e.getMessage(),
                    openRouterClient.getPrimaryModel()
            );
        } catch (Exception e) {
            log.error("Error inesperado al procesar tarea de IA {}: {}", comando.tareaId(), e.getMessage(), e);
            resultado = ResultadoTareaIa.fallida(
                    comando.tareaId(),
                    comando.tipo(),
                    "ERROR_INTERNO",
                    e.getMessage() != null ? e.getMessage() : "Error interno no especificado",
                    openRouterClient.getPrimaryModel()
            );
        }

        try {
            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.ROUTING_IA_RESULTADO, resultado);
            log.info("Resultado de tarea de IA {} publicado a {} ({})",
                    resultado.tareaId(), RabbitConfig.ROUTING_IA_RESULTADO, resultado.estado());
        } catch (Exception e) {
            log.error("Error crítico al publicar resultado de IA para tarea {}: {}", resultado.tareaId(), e.getMessage(), e);
        }
    }
}
