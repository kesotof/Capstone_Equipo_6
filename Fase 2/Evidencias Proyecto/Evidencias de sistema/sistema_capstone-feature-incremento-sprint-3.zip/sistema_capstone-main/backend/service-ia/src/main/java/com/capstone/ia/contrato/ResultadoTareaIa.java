package com.capstone.ia.contrato;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.UUID;

/**
 * F2/F7 (§5.3): resultado asíncrono de tarea de IA publicado hacia sistema-principal.
 */
public record ResultadoTareaIa(
        int version,
        UUID mensajeId,
        UUID tareaId,
        String tipo,
        String estado,
        JsonNode resultado,
        String modelo,
        String codigoError,
        String errorDetalle,
        Instant ocurridoEn
) {
    public static ResultadoTareaIa exitosa(UUID tareaId, String tipo, JsonNode resultado, String modelo) {
        return new ResultadoTareaIa(
                1,
                UUID.randomUUID(),
                tareaId,
                tipo,
                "COMPLETADA",
                resultado,
                modelo,
                null,
                null,
                Instant.now()
        );
    }

    public static ResultadoTareaIa fallida(UUID tareaId, String tipo, String codigoError, String errorDetalle, String modelo) {
        return new ResultadoTareaIa(
                1,
                UUID.randomUUID(),
                tareaId,
                tipo,
                "FALLIDA",
                null,
                modelo,
                codigoError,
                errorDetalle,
                Instant.now()
        );
    }
}
