package com.capstone.ia.consumer;

import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.service.AutocompletadoFormulario;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Autocompletado del formulario de una plantilla: lee el documento de origen y devuelve las sugerencias. */
@Component
public class AutocompletadoListener {

    private static final Logger log = LoggerFactory.getLogger(AutocompletadoListener.class);

    private final MinioDocumentReader documentReader;
    private final DocumentTextExtractor textExtractor;
    private final AutocompletadoFormulario autocompletado;
    private final RabbitTemplate rabbitTemplate;
    private final ObjectMapper objectMapper;

    public AutocompletadoListener(
            MinioDocumentReader documentReader,
            DocumentTextExtractor textExtractor,
            AutocompletadoFormulario autocompletado,
            RabbitTemplate rabbitTemplate,
            ObjectMapper objectMapper
    ) {
        this.documentReader = documentReader;
        this.textExtractor = textExtractor;
        this.autocompletado = autocompletado;
        this.rabbitTemplate = rabbitTemplate;
        this.objectMapper = objectMapper;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.autocomplete.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = RabbitConfig.AI_AUTOCOMPLETE_ROUTING_KEY
    ))
    public void procesar(Map<String, Object> tarea) {
        if (tarea == null || tarea.get("autocompletadoId") == null) {
            log.debug("Mensaje descartado en AutocompletadoListener (sin autocompletadoId): {}", tarea);
            return;
        }
        String id = String.valueOf(tarea.get("autocompletadoId"));
        String indicaciones = tarea.get("indicaciones") instanceof String texto ? texto : "";
        String storageKey = tarea.get("storageKey") instanceof String clave ? clave : null;
        log.info("Tarea de autocompletado {} recibida (con documento: {})", id, storageKey != null);

        Map<String, Object> resultado = new HashMap<>();
        resultado.put("autocompletadoId", id);
        resultado.put("timestamp", Instant.now().toString());
        try {
            String documento = "";
            if (storageKey != null) {
                try (InputStream stream = documentReader.getDocumentStream(storageKey)) {
                    documento = textExtractor.extractText(stream, String.valueOf(tarea.getOrDefault("nombreArchivo", "documento")));
                }
            }
            if (documento.isBlank() && indicaciones.isBlank()) {
                resultado.put("status", "ERROR");
                resultado.put("mensaje", "El documento no tiene texto legible (por ejemplo, es un escaneo sin reconocimiento de texto). "
                        + "Pruebe con otro archivo o escriba indicaciones.");
            } else {
                List<AutocompletadoFormulario.Campo> campos = objectMapper.convertValue(
                        tarea.get("campos"), new TypeReference<List<AutocompletadoFormulario.Campo>>() {});
                AutocompletadoFormulario.Resultado r = autocompletado.completar(
                        String.valueOf(tarea.getOrDefault("plantilla", "")), campos, indicaciones, documento);
                resultado.put("status", "COMPLETADO");
                resultado.put("sugerencias", r.sugerencias());
                resultado.put("mensaje", r.mensaje());
                resultado.put("modeloUsado", r.modelo());
            }
        } catch (Exception e) {
            log.error("Error al procesar el autocompletado {}: {}", id, e.getMessage(), e);
            resultado.put("status", "ERROR");
            resultado.put("mensaje", "No fue posible leer el documento. Verifique que no esté dañado ni protegido con contraseña.");
        }
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_AUTOCOMPLETE_RESULT_ROUTING_KEY, resultado);
        log.info("Resultado del autocompletado {} publicado ({})", id, resultado.get("status"));
    }
}
