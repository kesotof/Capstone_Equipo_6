package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.client.dto.OpenRouterDto.Message;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * F7 (§8.2, §8.3): handler para tareas de tipo AUTOCOMPLETAR.
 * Extrae texto del documento, solicita sugerencias estructuradas a OpenRouter
 * y normaliza las claves respecto al catálogo de campos de la plantilla.
 */
@Component
public class AutocompletadoHandler {

    private static final Logger log = LoggerFactory.getLogger(AutocompletadoHandler.class);

    private final MinioDocumentReader documentReader;
    private final DocumentTextExtractor textExtractor;
    private final OpenRouterApiClient openRouterClient;
    private final ObjectMapper objectMapper;
    private final String systemPrompt;

    public AutocompletadoHandler(
            MinioDocumentReader documentReader,
            DocumentTextExtractor textExtractor,
            OpenRouterApiClient openRouterClient,
            ObjectMapper objectMapper
    ) {
        this.documentReader = documentReader;
        this.textExtractor = textExtractor;
        this.openRouterClient = openRouterClient;
        this.objectMapper = objectMapper;
        this.systemPrompt = cargarPromptSistema();
    }

    public HandlerResult procesar(ComandoTareaIa comando) {
        if (comando.documento() == null || comando.documento().storageKey() == null || comando.documento().storageKey().isBlank()) {
            throw IaProcesamientoException.documentoNoEncontrado("El comando de autocompletado no especifica documento fuente");
        }

        String documentText;
        try (InputStream stream = documentReader.getDocumentStream(comando.documento().bucket(), comando.documento().storageKey())) {
            documentText = textExtractor.extractText(stream, comando.documento().nombreArchivo());
        } catch (IaProcesamientoException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al extraer texto para autocompletar de {}: {}", comando.documento().storageKey(), e.getMessage());
            throw new RuntimeException("Error al extraer texto del documento fuente: " + e.getMessage(), e);
        }

        if (documentText == null || documentText.trim().isEmpty()) {
            throw IaProcesamientoException.documentoIlegible("El documento fuente no contiene texto legible para autocompletar");
        }

        List<ComandoTareaIa.Campo> campos = comando.campos() != null ? comando.campos() : List.of();
        String userContent = armarContenidoUsuario(campos, documentText);

        List<Message> mensajes = new ArrayList<>();
        mensajes.add(new Message("system", systemPrompt));
        mensajes.add(new Message("user", userContent));

        OpenRouterApiClient.RespuestaLlm rawResponse = openRouterClient.ejecutarConsulta("AUTOCOMPLETAR", mensajes, true);

        JsonNode parsed = validarYParsearJson(rawResponse.contenido());
        if (parsed != null) {
            return new HandlerResult(normalizarResultado(parsed, campos), rawResponse.modeloUtilizado());
        }

        // Intento de reparación (§8.2)
        log.warn("Respuesta de autocompletado para tarea {} no produjo JSON válido. Intentando reparación...", comando.tareaId());
        mensajes.add(new Message("assistant", rawResponse.contenido()));
        mensajes.add(new Message("user", "Tu respuesta previa no es un JSON válido según la estructura de sugerencias y noEncontrados. Corrige el formato y responde ÚNICAMENTE el objeto JSON válido."));

        OpenRouterApiClient.RespuestaLlm repairedResponse = openRouterClient.ejecutarConsulta("AUTOCOMPLETAR", mensajes, true);
        JsonNode repairedParsed = validarYParsearJson(repairedResponse.contenido());
        if (repairedParsed != null) {
            log.info("Reparación de autocompletado exitosa para tarea {}", comando.tareaId());
            return new HandlerResult(normalizarResultado(repairedParsed, campos), repairedResponse.modeloUtilizado());
        }

        throw IaProcesamientoException.respuestaInvalida("El proveedor de IA no generó un JSON de autocompletado válido tras la reparación");
    }

    private JsonNode validarYParsearJson(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            String cleaned = limpiarJson(raw);
            JsonNode node = objectMapper.readTree(cleaned);
            if (node.isObject() && node.has("sugerencias")) {
                return node;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Normalización de claves según §6.9 y §8.2:
     * - Claves no solicitadas se descartan.
     * - Campos solicitados ausentes en sugerencias y noEncontrados se agregan a noEncontrados.
     */
    private JsonNode normalizarResultado(JsonNode original, List<ComandoTareaIa.Campo> camposSolicitados) {
        Set<String> clavesPermitidas = new HashSet<>();
        for (ComandoTareaIa.Campo c : camposSolicitados) {
            if (c.clave() != null) {
                clavesPermitidas.add(c.clave().trim());
            }
        }

        ObjectNode resultadoNormalizado = objectMapper.createObjectNode();
        ObjectNode sugerenciasNormalizadas = resultadoNormalizado.putObject("sugerencias");
        Set<String> noEncontradosSet = new LinkedHashSet<>();

        // Copiar sugerencias válidas
        JsonNode sugerenciasNode = original.get("sugerencias");
        if (sugerenciasNode != null && sugerenciasNode.isObject()) {
            sugerenciasNode.fieldNames().forEachRemaining(key -> {
                if (clavesPermitidas.contains(key)) {
                    sugerenciasNormalizadas.set(key, sugerenciasNode.get(key));
                }
            });
        }

        // Leer noEncontrados reportados
        JsonNode noEncontradosNode = original.get("noEncontrados");
        if (noEncontradosNode != null && noEncontradosNode.isArray()) {
            for (JsonNode item : noEncontradosNode) {
                String key = item.asText();
                if (clavesPermitidas.contains(key) && !sugerenciasNormalizadas.has(key)) {
                    noEncontradosSet.add(key);
                }
            }
        }

        // Agregar campos faltantes a noEncontrados
        for (String clave : clavesPermitidas) {
            if (!sugerenciasNormalizadas.has(clave)) {
                noEncontradosSet.add(clave);
            }
        }

        ArrayNode noEncontradosArray = resultadoNormalizado.putArray("noEncontrados");
        noEncontradosSet.forEach(noEncontradosArray::add);

        return resultadoNormalizado;
    }

    private String armarContenidoUsuario(List<ComandoTareaIa.Campo> campos, String documentText) {
        StringBuilder sb = new StringBuilder();
        sb.append("Campos que deben extraerse para la plantilla:\n");
        for (ComandoTareaIa.Campo c : campos) {
            sb.append("- Clave: ").append(c.clave())
                    .append(" | Etiqueta: ").append(c.etiqueta())
                    .append(" | Tipo: ").append(c.tipo())
                    .append(" | Obligatorio: ").append(c.obligatorio());
            if (c.opciones() != null && !c.opciones().isEmpty()) {
                sb.append(" | Opciones: ").append(String.join(", ", c.opciones()));
            }
            if (c.descripcion() != null && !c.descripcion().isBlank()) {
                sb.append(" | Descripción: ").append(c.descripcion());
            }
            sb.append("\n");
        }
        sb.append("\n<<<DOCUMENTO>>>\n");
        sb.append(documentText);
        sb.append("\n<<<FIN_DOCUMENTO>>>\n");
        return sb.toString();
    }

    private String limpiarJson(String raw) {
        String trimmed = raw.trim();
        if (trimmed.startsWith("```json")) {
            trimmed = trimmed.substring(7);
        } else if (trimmed.startsWith("```")) {
            trimmed = trimmed.substring(3);
        }
        if (trimmed.endsWith("```")) {
            trimmed = trimmed.substring(0, trimmed.length() - 3);
        }
        return trimmed.trim();
    }

    private String cargarPromptSistema() {
        try (InputStream in = new ClassPathResource("prompts/autocompletado.system.txt").getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            log.error("No se pudo cargar autocompletado.system.txt: {}", e.getMessage());
            return "Eres un asistente de autocompletado documental. Extrae los valores de los campos solicitados.";
        }
    }
}
