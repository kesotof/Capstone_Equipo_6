package com.capstone.ia.consumer;

import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.service.SugerenciaCampos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Sugerencias de campos para el editor de plantillas: recibe el texto del Word y responde qué textos convertir. */
@Component
public class SugerenciaCamposListener {

    private static final Logger log = LoggerFactory.getLogger(SugerenciaCamposListener.class);

    private final SugerenciaCampos sugerencias;
    private final RabbitTemplate rabbitTemplate;

    public SugerenciaCamposListener(SugerenciaCampos sugerencias, RabbitTemplate rabbitTemplate) {
        this.sugerencias = sugerencias;
        this.rabbitTemplate = rabbitTemplate;
    }

    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "ai.fields.queue", durable = "true"),
            exchange = @Exchange(value = RabbitConfig.EXCHANGE_NAME, type = "topic"),
            key = RabbitConfig.AI_FIELDS_ROUTING_KEY
    ))
    public void procesar(Map<String, Object> tarea) {
        if (tarea == null || tarea.get("sugerenciaId") == null) {
            log.debug("Mensaje descartado en SugerenciaCamposListener (sin sugerenciaId): {}", tarea);
            return;
        }
        String id = String.valueOf(tarea.get("sugerenciaId"));
        String texto = tarea.get("texto") instanceof String t ? t : "";
        List<String> existentes = tarea.get("existentes") instanceof List<?> lista ? lista.stream().map(String::valueOf).toList() : List.of();
        log.info("Sugerencia de campos {} recibida ({} caracteres)", id, texto.length());

        Map<String, Object> resultado = new HashMap<>();
        resultado.put("sugerenciaId", id);
        try {
            SugerenciaCampos.Resultado r = sugerencias.sugerir(texto, existentes);
            resultado.put("status", "COMPLETADO");
            resultado.put("sugerencias", r.sugerencias());
            resultado.put("modelo", r.modelo());
            resultado.put("mensaje", r.sugerencias().isEmpty()
                    ? "No se encontraron datos variables para sugerir. Puede seleccionar los textos en el documento." : r.mensaje());
        } catch (Exception e) {
            log.error("Error al sugerir campos {}: {}", id, e.getMessage(), e);
            resultado.put("status", "ERROR");
            resultado.put("mensaje", "La IA no pudo analizar el documento en este momento. Puede seleccionar los textos a mano o volver a intentarlo.");
        }
        rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE_NAME, RabbitConfig.AI_FIELDS_RESULT_ROUTING_KEY, resultado);
        log.info("Sugerencia de campos {} publicada ({})", id, resultado.get("status"));
    }
}
