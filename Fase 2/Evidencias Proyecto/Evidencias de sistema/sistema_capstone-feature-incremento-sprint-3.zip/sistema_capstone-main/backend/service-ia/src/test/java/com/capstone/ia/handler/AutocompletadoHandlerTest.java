package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AutocompletadoHandlerTest {

    @Mock
    private MinioDocumentReader documentReader;

    @Mock
    private DocumentTextExtractor textExtractor;

    @Mock
    private OpenRouterApiClient openRouterClient;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private AutocompletadoHandler handler;

    @BeforeEach
    void setUp() {
        handler = new AutocompletadoHandler(documentReader, textExtractor, openRouterClient, objectMapper);
    }

    @Test
    @DisplayName("Autocompletado normaliza: conserva claves solicitadas, descarta desconocidas y agrega faltantes a noEncontrados")
    void autocompletado_normalizacion_exitosa() throws Exception {
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), UUID.randomUUID(), "AUTOCOMPLETAR",
                new ComandoTareaIa.Documento("ia-temporal", "factura.pdf", "factura.pdf", "application/pdf"),
                null, null, List.of(),
                List.of(
                        new ComandoTareaIa.Campo("monto_total", "Monto Total", "numero", true, List.of(), "Monto"),
                        new ComandoTareaIa.Campo("rut_proveedor", "RUT Proveedor", "rut", true, List.of(), "RUT"),
                        new ComandoTareaIa.Campo("fecha_emision", "Fecha Emisión", "fecha", false, List.of(), "Fecha")
                ),
                Instant.now()
        );

        when(documentReader.getDocumentStream("ia-temporal", "factura.pdf"))
                .thenReturn(new ByteArrayInputStream("factura".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("factura.pdf")))
                .thenReturn("Factura N 100 por un monto de $50.000 de proveedor RUT 11.222.333-4.");

        // El modelo devuelve 'monto_total', pero también una clave no solicitada 'clave_fantasma', y no encuentra 'fecha_emision'
        String jsonLlm = """
                {
                  "sugerencias": {
                    "monto_total": {
                      "valor": 50000,
                      "confianza": 0.95,
                      "fuente": "$50.000"
                    },
                    "clave_fantasma": {
                      "valor": "descartar",
                      "confianza": 0.5,
                      "fuente": "nada"
                    }
                  },
                  "noEncontrados": [
                    "rut_proveedor"
                  ]
                }
                """;

        when(openRouterClient.ejecutarConsulta(eq("AUTOCOMPLETAR"), anyList(), eq(true)))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm(jsonLlm, "meta-llama/test"));

        HandlerResult res = handler.procesar(cmd);
        JsonNode resultado = res.data();
        assertThat(res.modelo()).isEqualTo("meta-llama/test");

        assertThat(resultado.has("sugerencias")).isTrue();
        assertThat(resultado.has("noEncontrados")).isTrue();

        JsonNode sugerencias = resultado.get("sugerencias");
        // monto_total debe estar
        assertThat(sugerencias.has("monto_total")).isTrue();
        assertThat(sugerencias.get("monto_total").get("valor").asInt()).isEqualTo(50000);

        // clave_fantasma debe ser descartada
        assertThat(sugerencias.has("clave_fantasma")).isFalse();

        // rut_proveedor venía en noEncontrados, y fecha_emision faltaba por completo en la respuesta
        // Ambos deben estar en noEncontrados normalizados
        JsonNode noEncontrados = resultado.get("noEncontrados");
        assertThat(noEncontrados.isArray()).isTrue();
        List<String> noEncontradosList = new java.util.ArrayList<>();
        noEncontrados.forEach(n -> noEncontradosList.add(n.asText()));

        assertThat(noEncontradosList).contains("rut_proveedor", "fecha_emision");
    }
}
