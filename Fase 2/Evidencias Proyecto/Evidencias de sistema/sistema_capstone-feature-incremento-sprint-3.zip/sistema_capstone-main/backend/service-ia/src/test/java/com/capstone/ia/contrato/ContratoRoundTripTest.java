package com.capstone.ia.contrato;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import java.io.InputStream;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * F2 — guardia de contrato (plan §5): los JSON canónicos copiados a
 * {@code src/test/resources/contratos/} deben deserializarse en los records que este servicio
 * consumirá (S3-F7) y volver a serializarse sin pérdida. Falla la build si el contrato cambia
 * sin actualizar la copia y los records en los 3 servicios.
 */
class ContratoRoundTripTest {

    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

    private JsonNode original(String nombre) throws Exception {
        try (InputStream in = new ClassPathResource("contratos/" + nombre).getInputStream()) {
            return mapper.readTree(in);
        }
    }

    private void roundTrip(String nombre, Class<?> tipo) throws Exception {
        JsonNode antes = original(nombre);
        // Se re-lee desde la cadena serializada para normalizar tipos numéricos
        // (Long del record vs IntNode del parseo: mismo texto, equals distinto).
        JsonNode despues = mapper.readTree(mapper.writeValueAsString(mapper.convertValue(antes, tipo)));
        assertEquals(antes, despues, "Round-trip de " + nombre + " perdió datos");
    }

    @Test
    @DisplayName("ComandoTareaIa: JSON → record → JSON sin pérdida")
    void comando() throws Exception {
        roundTrip("comando-tarea-ia.json", ComandoTareaIa.class);
        ComandoTareaIa cmd = mapper.convertValue(original("comando-tarea-ia.json"), ComandoTareaIa.class);
        assertEquals("EVALUACION", cmd.tipo());
        assertEquals("CONT-014", cmd.contexto().correlativo());
        assertTrue(cmd.historial().isEmpty());
        assertTrue(cmd.campos().isEmpty());
    }

    @Test
    @DisplayName("ResultadoTareaIa: JSON → record → JSON sin pérdida")
    void resultado() throws Exception {
        roundTrip("resultado-tarea-ia.json", ResultadoTareaIa.class);
        ResultadoTareaIa res = mapper.convertValue(original("resultado-tarea-ia.json"), ResultadoTareaIa.class);
        assertEquals("COMPLETADA", res.estado());
        assertEquals(78, res.resultado().get("puntaje").asInt());
    }

    @Test
    @DisplayName("ResultadoTareaIa (Autocompletado): JSON → record → JSON sin pérdida")
    void resultadoAutocompletar() throws Exception {
        roundTrip("resultado-tarea-ia-autocompletar.json", ResultadoTareaIa.class);
        ResultadoTareaIa res = mapper.convertValue(original("resultado-tarea-ia-autocompletar.json"), ResultadoTareaIa.class);
        assertEquals("AUTOCOMPLETAR", res.tipo());
        assertEquals("COMPLETADA", res.estado());
        assertTrue(res.resultado().has("sugerencias"));
        assertEquals(50000, res.resultado().get("sugerencias").get("monto_total").get("valor").asInt());
        assertEquals("fecha_emision", res.resultado().get("noEncontrados").get(0).asText());
    }
}
