package com.capstone.ia.exception;

/**
 * F7 (§8.2): excepción controlada durante el procesamiento de tareas en service-ia.
 * Se traduce directamente en un ResultadoTareaIa con estado FALLIDA y el codigoError indicado.
 */
public class IaProcesamientoException extends RuntimeException {

    private final String codigoError;

    public IaProcesamientoException(String codigoError, String mensaje) {
        super(mensaje);
        this.codigoError = codigoError;
    }

    public IaProcesamientoException(String codigoError, String mensaje, Throwable cause) {
        super(mensaje, cause);
        this.codigoError = codigoError;
    }

    public String getCodigoError() {
        return codigoError;
    }

    public static IaProcesamientoException documentoNoEncontrado(String detalle) {
        return new IaProcesamientoException("DOCUMENTO_NO_ENCONTRADO", detalle);
    }

    public static IaProcesamientoException documentoIlegible(String detalle) {
        return new IaProcesamientoException("DOCUMENTO_ILEGIBLE", detalle);
    }

    public static IaProcesamientoException respuestaInvalida(String detalle) {
        return new IaProcesamientoException("RESPUESTA_INVALIDA", detalle);
    }

    public static IaProcesamientoException iaNoDisponible(String detalle, Throwable cause) {
        return new IaProcesamientoException("IA_NO_DISPONIBLE", detalle, cause);
    }

    public static IaProcesamientoException comandoNoSoportado(String tipo) {
        return new IaProcesamientoException("COMANDO_NO_SOPORTADO", "Tipo de tarea no soportado: " + tipo);
    }
}
