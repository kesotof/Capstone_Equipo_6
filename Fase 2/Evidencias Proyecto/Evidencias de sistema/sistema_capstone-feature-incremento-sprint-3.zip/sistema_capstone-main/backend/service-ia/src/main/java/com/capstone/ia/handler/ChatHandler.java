package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.client.dto.OpenRouterDto.Message;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * F7 (§8.2, §8.3): handler para tareas de tipo CHAT.
 * Mantiene contexto del documento e historial previo de conversación.
 */
@Component
public class ChatHandler {

    private static final Logger log = LoggerFactory.getLogger(ChatHandler.class);

    private final MinioDocumentReader documentReader;
    private final DocumentTextExtractor textExtractor;
    private final OpenRouterApiClient openRouterClient;
    private final ObjectMapper objectMapper;
    private final String systemPromptBase;

    public ChatHandler(
            MinioDocumentReader documentReader,
            DocumentTextExtractor textExtractor,
            OpenRouterApiClient openRouterClient,
            ObjectMapper objectMapper
    ) {
        this.documentReader = documentReader;
        this.textExtractor = textExtractor;
        this.openRouterClient = openRouterClient;
        this.objectMapper = objectMapper;
        this.systemPromptBase = cargarPromptSistema();
    }

    public HandlerResult procesar(ComandoTareaIa comando) {
        String documentText = "";
        if (comando.documento() != null && comando.documento().storageKey() != null && !comando.documento().storageKey().isBlank()) {
            try (InputStream stream = documentReader.getDocumentStream(comando.documento().bucket(), comando.documento().storageKey())) {
                documentText = textExtractor.extractText(stream, comando.documento().nombreArchivo());
            } catch (IaProcesamientoException e) {
                throw e;
            } catch (Exception e) {
                log.error("Error al extraer texto para chat del documento {}: {}", comando.documento().storageKey(), e.getMessage());
                throw new RuntimeException("Error al extraer texto del documento para chat: " + e.getMessage(), e);
            }
        }

        if (documentText == null || documentText.trim().isEmpty()) {
            throw IaProcesamientoException.documentoIlegible("El documento no contiene texto identificable para responder preguntas de chat");
        }

        StringBuilder systemContent = new StringBuilder(systemPromptBase);
        if (comando.contexto() != null) {
            systemContent.append("\n\nContexto de la solicitud:\n");
            if (comando.contexto().correlativo() != null) systemContent.append("- Correlativo: ").append(comando.contexto().correlativo()).append("\n");
            if (comando.contexto().titulo() != null) systemContent.append("- Título: ").append(comando.contexto().titulo()).append("\n");
            if (comando.contexto().tipoDocumento() != null) systemContent.append("- Tipo documento: ").append(comando.contexto().tipoDocumento()).append("\n");
            if (comando.contexto().etapa() != null) systemContent.append("- Etapa: ").append(comando.contexto().etapa()).append("\n");
        }
        systemContent.append("\n<<<DOCUMENTO>>>\n");
        systemContent.append(documentText);
        systemContent.append("\n<<<FIN_DOCUMENTO>>>\n");

        List<Message> mensajes = new ArrayList<>();
        mensajes.add(new Message("system", systemContent.toString()));

        // Historial cronológico previo (§6.7 / §8.2)
        if (comando.historial() != null) {
            for (ComandoTareaIa.ParHistorial par : comando.historial()) {
                if (par.pregunta() != null && !par.pregunta().isBlank()) {
                    mensajes.add(new Message("user", par.pregunta().trim()));
                }
                if (par.respuesta() != null && !par.respuesta().isBlank()) {
                    mensajes.add(new Message("assistant", par.respuesta().trim()));
                }
            }
        }

        // Pregunta actual
        String pregunta = comando.instruccion() != null ? comando.instruccion().trim() : "";
        mensajes.add(new Message("user", pregunta));

        OpenRouterApiClient.RespuestaLlm rawResponse = openRouterClient.ejecutarConsulta("CHAT", mensajes, false);

        return new HandlerResult(normalizarRespuesta(rawResponse.contenido()), rawResponse.modeloUtilizado());
    }

    private JsonNode normalizarRespuesta(String raw) {
        if (raw == null || raw.isBlank()) {
            throw IaProcesamientoException.respuestaInvalida("Respuesta de chat vacía por parte del proveedor");
        }
        try {
            String cleaned = limpiarBloques(raw);
            JsonNode node = objectMapper.readTree(cleaned);
            if (node.isObject() && node.has("respuesta")) {
                return node;
            }
        } catch (Exception ignored) {
            // No era JSON válido, se envuelve en objeto respuesta
        }

        ObjectNode on = objectMapper.createObjectNode();
        on.put("respuesta", raw.trim());
        return on;
    }

    private String limpiarBloques(String raw) {
        String trimmed = raw.trim();
        if (trimmed.startsWith("```json")) {
            trimmed = trimmed.substring(7);
        } else if (trimmed.startsWith("```")) {
            trimmed = trimmed.substring(3);
        }
        if (trimmed.endsWith("```")) {
            trimmed = trimmed.substring(0, trimmed.length() - 3);
        }
        return trimmed.trim();
    }

    private String cargarPromptSistema() {
        try (InputStream in = new ClassPathResource("prompts/chat.system.txt").getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            log.error("No se pudo cargar chat.system.txt, usando fallback: {}", e.getMessage());
            return "Eres un asistente de consulta documental. Responde preguntas basándote en el documento.";
        }
    }
}
