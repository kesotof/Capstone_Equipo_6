package com.capstone.ia.client;

import com.capstone.ia.client.dto.OpenRouterDto.Message;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OpenRouterApiClientTest {

    @Test
    @DisplayName("Debe activar el modo simulación si simulationEnabled es true o API key es dummy")
    void shouldActivateSimulationMode() {
        RestClient.Builder builder = RestClient.builder();
        OpenRouterApiClient client = new OpenRouterApiClient(
                builder,
                "https://openrouter.ai/api/v1",
                "your_openrouter_api_key_here",
                "meta-llama/llama-3.3-70b-instruct:free",
                true,
                50
        );

        assertTrue(client.isSimulationMode());
    }

    @Test
    @DisplayName("Debe generar respuesta estructurada JSON simulada en modo simulación para evaluación")
    void shouldReturnStructuredJsonInSimulationMode() {
        RestClient.Builder builder = RestClient.builder();
        OpenRouterApiClient client = new OpenRouterApiClient(
                builder,
                "https://openrouter.ai/api/v1",
                "dummy_key",
                "meta-llama/llama-3.3-70b-instruct:free",
                true,
                10
        );

        OpenRouterApiClient.RespuestaLlm result = client.ejecutarConsulta(
                "EVALUACION",
                List.of(new Message("user", "Evaluar contrato")),
                true
        );

        assertNotNull(result);
        assertNotNull(result.modeloUtilizado());
        assertTrue(result.contenido().contains("\"cumple\":"));
        assertTrue(result.contenido().contains("\"puntaje\":"));
        assertTrue(result.contenido().contains("\"resumen\":"));
    }

    @Test
    @DisplayName("Debe pasar al siguiente modelo si uno está saturado, sin exigir modo JSON")
    void shouldTryNextModelWhenRateLimited() throws Exception {
        List<String> pedidos = new CopyOnWriteArrayList<>();
        HttpServer server = HttpServer.create(new InetSocketAddress("localhost", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            pedidos.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            boolean saturado = pedidos.size() == 1;
            byte[] cuerpo = (saturado ? "{}" : """
                    {"model":"respaldo","choices":[{"index":0,"message":{"role":"assistant","content":"{\\"ok\\":true}"}}]}
                    """).getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(saturado ? 429 : 200, cuerpo.length);
            exchange.getResponseBody().write(cuerpo);
            exchange.close();
        });
        server.start();
        try {
            OpenRouterApiClient client = new OpenRouterApiClient(
                    RestClient.builder(),
                    "http://localhost:" + server.getAddress().getPort(),
                    "clave-de-prueba",
                    "modelo-principal",
                    false,
                    0
            );

            OpenRouterApiClient.RespuestaLlm result = client.ejecutarConsulta(
                    "EVALUACION",
                    List.of(new Message("user", "Evaluar contrato")),
                    true
            );

            assertEquals("{\"ok\":true}", result.contenido());
            assertEquals("respaldo", result.modeloUtilizado());
            assertEquals(2, pedidos.size());
            assertTrue(pedidos.get(0).contains("\"model\":\"modelo-principal\""));
            assertTrue(pedidos.get(1).contains("\"model\":\"openrouter/free\""));
            assertTrue(pedidos.get(1).contains("\"require_parameters\":false"));
        } finally {
            server.stop(0);
        }
    }
}
