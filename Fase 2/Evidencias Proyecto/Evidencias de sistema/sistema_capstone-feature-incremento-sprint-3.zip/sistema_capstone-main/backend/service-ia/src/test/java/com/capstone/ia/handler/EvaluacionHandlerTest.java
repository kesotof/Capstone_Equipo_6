package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EvaluacionHandlerTest {

    @Mock
    private MinioDocumentReader documentReader;

    @Mock
    private DocumentTextExtractor textExtractor;

    @Mock
    private OpenRouterApiClient openRouterClient;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private EvaluacionHandler handler;

    @BeforeEach
    void setUp() {
        handler = new EvaluacionHandler(documentReader, textExtractor, openRouterClient, objectMapper);
    }

    private ComandoTareaIa crearComando() {
        return new ComandoTareaIa(
                1, UUID.randomUUID(), UUID.randomUUID(), "EVALUACION",
                new ComandoTareaIa.Documento("documentos", "contrato.pdf", "contrato.pdf", "application/pdf"),
                new ComandoTareaIa.Contexto("CONT-001", "Contrato", "Desc", "Contrato", "Revisión", 1),
                "Criterio de prueba", List.of(), List.of(), Instant.now()
        );
    }

    @Test
    @DisplayName("Evaluación con JSON válido retorna JsonNode con cumple y puntaje")
    void evaluacion_jsonValido_retornaJsonNode() throws Exception {
        ComandoTareaIa cmd = crearComando();
        when(documentReader.getDocumentStream("documentos", "contrato.pdf"))
                .thenReturn(new ByteArrayInputStream("contenido".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("contrato.pdf")))
                .thenReturn("Texto extraído del contrato con cláusulas completas.");

        String jsonValido = """
                {
                  "cumple": true,
                  "puntaje": 95,
                  "resumen": "Cumple los requisitos",
                  "observaciones": [],
                  "hallazgos": []
                }
                """;
        when(openRouterClient.ejecutarConsulta(eq("EVALUACION"), anyList(), eq(true)))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm(jsonValido, "meta-llama/test"));

        HandlerResult resultado = handler.procesar(cmd);

        assertThat(resultado.data().get("cumple").asBoolean()).isTrue();
        assertThat(resultado.data().get("puntaje").asInt()).isEqualTo(95);
        assertThat(resultado.modelo()).isEqualTo("meta-llama/test");
        verify(openRouterClient, times(1)).ejecutarConsulta(anyString(), anyList(), anyBoolean());
    }

    @Test
    @DisplayName("JSON inválido en primer intento pero válido en reparación retorna JsonNode")
    void evaluacion_reparacionExitosa_retornaJsonNode() throws Exception {
        ComandoTareaIa cmd = crearComando();
        when(documentReader.getDocumentStream("documentos", "contrato.pdf"))
                .thenReturn(new ByteArrayInputStream("contenido".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("contrato.pdf")))
                .thenReturn("Texto extraído del contrato.");

        String jsonReparado = """
                {
                  "cumple": false,
                  "puntaje": 40,
                  "resumen": "No cumple cláusula obligatoria",
                  "observaciones": ["Falta firma"],
                  "hallazgos": []
                }
                """;
        when(openRouterClient.ejecutarConsulta(eq("EVALUACION"), anyList(), eq(true)))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm("Texto plano sin formato json", "meta-llama/test"))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm(jsonReparado, "meta-llama/test"));

        HandlerResult resultado = handler.procesar(cmd);

        assertThat(resultado.data().get("cumple").asBoolean()).isFalse();
        assertThat(resultado.data().get("puntaje").asInt()).isEqualTo(40);
        verify(openRouterClient, times(2)).ejecutarConsulta(anyString(), anyList(), anyBoolean());
    }

    @Test
    @DisplayName("Dos respuestas inválidas consecutivas lanza RESPUESTA_INVALIDA")
    void evaluacion_dobleFallo_lanzaRespuestaInvalida() throws Exception {
        ComandoTareaIa cmd = crearComando();
        when(documentReader.getDocumentStream("documentos", "contrato.pdf"))
                .thenReturn(new ByteArrayInputStream("contenido".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("contrato.pdf")))
                .thenReturn("Texto extraído.");

        when(openRouterClient.ejecutarConsulta(eq("EVALUACION"), anyList(), eq(true)))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm("Texto no json 1", "meta-llama/test"))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm("Texto no json 2", "meta-llama/test"));

        assertThatThrownBy(() -> handler.procesar(cmd))
                .isInstanceOf(IaProcesamientoException.class)
                .hasFieldOrPropertyWithValue("codigoError", "RESPUESTA_INVALIDA");
    }

    @Test
    @DisplayName("Documento no encontrado en MinIO lanza DOCUMENTO_NO_ENCONTRADO")
    void evaluacion_documentoNoEncontrado_lanzaExcepcion() {
        ComandoTareaIa cmd = crearComando();
        when(documentReader.getDocumentStream("documentos", "contrato.pdf"))
                .thenThrow(IaProcesamientoException.documentoNoEncontrado("No existe objeto"));

        assertThatThrownBy(() -> handler.procesar(cmd))
                .isInstanceOf(IaProcesamientoException.class)
                .hasFieldOrPropertyWithValue("codigoError", "DOCUMENTO_NO_ENCONTRADO");
    }

    @Test
    @DisplayName("Documento sin texto legible lanza DOCUMENTO_ILEGIBLE")
    void evaluacion_documentoIlegible_lanzaExcepcion() throws Exception {
        ComandoTareaIa cmd = crearComando();
        when(documentReader.getDocumentStream("documentos", "contrato.pdf"))
                .thenReturn(new ByteArrayInputStream("vacio".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("contrato.pdf")))
                .thenReturn("   ");

        assertThatThrownBy(() -> handler.procesar(cmd))
                .isInstanceOf(IaProcesamientoException.class)
                .hasFieldOrPropertyWithValue("codigoError", "DOCUMENTO_ILEGIBLE");
    }
}
