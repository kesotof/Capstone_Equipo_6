package com.capstone.ia.consumer;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.config.RabbitConfig;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.contrato.ResultadoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.handler.AutocompletadoHandler;
import com.capstone.ia.handler.ChatHandler;
import com.capstone.ia.handler.EvaluacionHandler;
import com.capstone.ia.handler.HandlerResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TareaIaListenerTest {

    @Mock
    private EvaluacionHandler evaluacionHandler;

    @Mock
    private ChatHandler chatHandler;

    @Mock
    private AutocompletadoHandler autocompletadoHandler;

    @Mock
    private OpenRouterApiClient openRouterClient;

    @Mock
    private RabbitTemplate rabbitTemplate;

    private TareaIaListener listener;
    private final ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        listener = new TareaIaListener(
                evaluacionHandler,
                chatHandler,
                autocompletadoHandler,
                openRouterClient,
                rabbitTemplate
        );
        lenient().when(openRouterClient.getPrimaryModel()).thenReturn("meta-llama/llama-3.3-70b-instruct:free");
    }

    @Test
    @DisplayName("EVALUACION exitosa publica ResultadoTareaIa con estado COMPLETADA")
    void procesarEvaluacion_exitosa() {
        UUID tareaId = UUID.randomUUID();
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), tareaId, "EVALUACION",
                new ComandoTareaIa.Documento("documentos", "doc.pdf", "doc.pdf", "application/pdf"),
                null, "Criterio", List.of(), List.of(), Instant.now()
        );

        ObjectNode json = mapper.createObjectNode();
        json.put("cumple", true);
        json.put("puntaje", 90);
        json.put("resumen", "OK");

        when(evaluacionHandler.procesar(cmd)).thenReturn(new HandlerResult(json, "meta-llama/test"));

        listener.procesarComando(cmd);

        ArgumentCaptor<ResultadoTareaIa> captor = ArgumentCaptor.forClass(ResultadoTareaIa.class);
        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.ROUTING_IA_RESULTADO),
                captor.capture()
        );

        ResultadoTareaIa resultado = captor.getValue();
        assertEquals(tareaId, resultado.tareaId());
        assertEquals("COMPLETADA", resultado.estado());
        assertEquals("EVALUACION", resultado.tipo());
        assertNotNull(resultado.resultado());
        assertEquals(90, resultado.resultado().get("puntaje").asInt());
        assertNull(resultado.codigoError());
    }

    @Test
    @DisplayName("CHAT exitoso despacha a ChatHandler y publica COMPLETADA")
    void procesarChat_exitoso() {
        UUID tareaId = UUID.randomUUID();
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), tareaId, "CHAT",
                null, null, "¿Cuál es el plazo?", List.of(), List.of(), Instant.now()
        );

        ObjectNode json = mapper.createObjectNode();
        json.put("respuesta", "30 días");
        when(chatHandler.procesar(cmd)).thenReturn(new HandlerResult(json, "meta-llama/test"));

        listener.procesarComando(cmd);

        ArgumentCaptor<ResultadoTareaIa> captor = ArgumentCaptor.forClass(ResultadoTareaIa.class);
        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.ROUTING_IA_RESULTADO),
                captor.capture()
        );

        ResultadoTareaIa resultado = captor.getValue();
        assertEquals("COMPLETADA", resultado.estado());
        assertEquals("30 días", resultado.resultado().get("respuesta").asText());
    }

    @Test
    @DisplayName("Comando nulo lanza AmqpRejectAndDontRequeueException para evitar requeue infinito")
    void procesarComando_nulo_lanzaAmqpReject() {
        assertThrows(AmqpRejectAndDontRequeueException.class, () -> listener.procesarComando(null));
        verifyNoInteractions(rabbitTemplate);
    }

    @Test
    @DisplayName("Comando sin tareaId lanza AmqpRejectAndDontRequeueException")
    void procesarComando_sinTareaId_lanzaAmqpReject() {
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), null, "EVALUACION",
                null, null, "Criterio", List.of(), List.of(), Instant.now()
        );
        assertThrows(AmqpRejectAndDontRequeueException.class, () -> listener.procesarComando(cmd));
        verifyNoInteractions(rabbitTemplate);
    }

    @Test
    @DisplayName("Fallo con IaProcesamientoException publica FALLIDA con codigoError correspondiente")
    void procesarFalloControlado_publicaFallida() {
        UUID tareaId = UUID.randomUUID();
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), tareaId, "EVALUACION",
                null, null, "Criterio", List.of(), List.of(), Instant.now()
        );

        when(evaluacionHandler.procesar(cmd)).thenThrow(
                IaProcesamientoException.documentoNoEncontrado("Documento no hallado")
        );

        listener.procesarComando(cmd);

        ArgumentCaptor<ResultadoTareaIa> captor = ArgumentCaptor.forClass(ResultadoTareaIa.class);
        verify(rabbitTemplate).convertAndSend(
                eq(RabbitConfig.EXCHANGE_NAME),
                eq(RabbitConfig.ROUTING_IA_RESULTADO),
                captor.capture()
        );

        ResultadoTareaIa resultado = captor.getValue();
        assertEquals(tareaId, resultado.tareaId());
        assertEquals("FALLIDA", resultado.estado());
        assertEquals("DOCUMENTO_NO_ENCONTRADO", resultado.codigoError());
        assertEquals("Documento no hallado", resultado.errorDetalle());
    }
}
