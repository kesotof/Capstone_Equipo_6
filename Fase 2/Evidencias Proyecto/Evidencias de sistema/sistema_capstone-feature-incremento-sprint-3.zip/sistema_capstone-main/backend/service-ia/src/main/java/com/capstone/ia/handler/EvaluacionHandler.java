package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.client.dto.OpenRouterDto.Message;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.EvaluacionLocal;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * F7 (§8.2, §8.3): handler para tareas de tipo EVALUACION.
 * Extrae texto del documento, ejecuta la evaluación con OpenRouter contra el criterio
 * y asegura que el resultado sea un JSON válido con 1 reintento de reparación.
 */
@Component
public class EvaluacionHandler {

    private static final Logger log = LoggerFactory.getLogger(EvaluacionHandler.class);

    private final MinioDocumentReader documentReader;
    private final DocumentTextExtractor textExtractor;
    private final OpenRouterApiClient openRouterClient;
    private final ObjectMapper objectMapper;
    private final String systemPrompt;

    public EvaluacionHandler(
            MinioDocumentReader documentReader,
            DocumentTextExtractor textExtractor,
            OpenRouterApiClient openRouterClient,
            ObjectMapper objectMapper
    ) {
        this.documentReader = documentReader;
        this.textExtractor = textExtractor;
        this.openRouterClient = openRouterClient;
        this.objectMapper = objectMapper;
        this.systemPrompt = cargarPromptSistema();
    }

    public HandlerResult procesar(ComandoTareaIa comando) {
        if (comando.documento() == null || comando.documento().storageKey() == null || comando.documento().storageKey().isBlank()) {
            throw IaProcesamientoException.documentoNoEncontrado("El comando no especifica documento para evaluar");
        }

        String documentText;
        try (InputStream stream = documentReader.getDocumentStream(comando.documento().bucket(), comando.documento().storageKey())) {
            documentText = textExtractor.extractText(stream, comando.documento().nombreArchivo());
        } catch (IaProcesamientoException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al extraer texto del documento {}: {}", comando.documento().storageKey(), e.getMessage());
            throw new RuntimeException("Error al leer y extraer texto del documento: " + e.getMessage(), e);
        }

        if (documentText == null || documentText.trim().isEmpty()) {
            throw IaProcesamientoException.documentoIlegible("El documento no contiene texto identificable o legible para evaluación");
        }

        String userContent = armarContenidoUsuario(comando, documentText);

        List<Message> mensajes = new ArrayList<>();
        mensajes.add(new Message("system", systemPrompt));
        mensajes.add(new Message("user", userContent));

        OpenRouterApiClient.RespuestaLlm rawResponse = openRouterClient.ejecutarConsulta("EVALUACION", mensajes, true);

        JsonNode parsed = validarYParsearJson(rawResponse.contenido());
        if (parsed != null) {
            return new HandlerResult(parsed, rawResponse.modeloUtilizado());
        }

        // Intento de reparación (§8.2)
        log.warn("Respuesta de IA para tarea {} no produjo JSON de evaluación válido. Intentando reparación...", comando.tareaId());
        mensajes.add(new Message("assistant", rawResponse.contenido()));
        mensajes.add(new Message("user", "Tu respuesta previa no es un objeto JSON válido según la estructura requerida. Corrige el formato y responde ÚNICAMENTE el objeto JSON válido."));

        OpenRouterApiClient.RespuestaLlm repairedResponse = openRouterClient.ejecutarConsulta("EVALUACION", mensajes, true);
        JsonNode repairedParsed = validarYParsearJson(repairedResponse.contenido());
        if (repairedParsed != null) {
            log.info("Reparación de JSON exitosa para tarea {}", comando.tareaId());
            return new HandlerResult(repairedParsed, repairedResponse.modeloUtilizado());
        }

        throw IaProcesamientoException.respuestaInvalida("El proveedor de IA no generó un JSON de evaluación válido tras el intento de reparación");
    }

    private JsonNode validarYParsearJson(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            String cleaned = limpiarJson(raw);
            JsonNode node = objectMapper.readTree(cleaned);
            if (node.isObject() && node.has("puntaje") && node.has("resumen") && (node.has("veredictoSugerido") || node.has("cumple"))) {
                com.fasterxml.jackson.databind.node.ObjectNode obj = (com.fasterxml.jackson.databind.node.ObjectNode) node;
                if (!obj.has("veredictoSugerido") && obj.has("cumple")) {
                    boolean c = obj.get("cumple").asBoolean(true);
                    obj.put("veredictoSugerido", c ? "CUMPLE" : "NO_CUMPLE");
                }
                if (!obj.has("cumple") && obj.has("veredictoSugerido")) {
                    String v = obj.get("veredictoSugerido").asText("CUMPLE");
                    obj.put("cumple", "CUMPLE".equalsIgnoreCase(v) || "CUMPLE_PARCIAL".equalsIgnoreCase(v));
                }
                if (!obj.has("hallazgos")) {
                    obj.putArray("hallazgos");
                }
                if (!obj.has("recomendaciones")) {
                    obj.putArray("recomendaciones");
                }
                return obj;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private String limpiarJson(String raw) {
        String trimmed = raw.trim();
        if (trimmed.startsWith("```json")) {
            trimmed = trimmed.substring(7);
        } else if (trimmed.startsWith("```")) {
            trimmed = trimmed.substring(3);
        }
        if (trimmed.endsWith("```")) {
            trimmed = trimmed.substring(0, trimmed.length() - 3);
        }
        return trimmed.trim();
    }

    private String armarContenidoUsuario(ComandoTareaIa comando, String documentText) {
        StringBuilder sb = new StringBuilder();
        sb.append("Fecha de hoy: ").append(OpenRouterApiClient.hoy()).append("\n\n");
        if (comando.contexto() != null) {
            sb.append("Contexto de la solicitud:\n");
            if (comando.contexto().correlativo() != null) sb.append("- Correlativo: ").append(comando.contexto().correlativo()).append("\n");
            if (comando.contexto().titulo() != null) sb.append("- Título: ").append(comando.contexto().titulo()).append("\n");
            if (comando.contexto().tipoDocumento() != null) sb.append("- Tipo documento: ").append(comando.contexto().tipoDocumento()).append("\n");
            if (comando.contexto().etapa() != null) sb.append("- Etapa actual: ").append(comando.contexto().etapa()).append("\n");
            sb.append("\n");
        }

        sb.append("Criterio de evaluación para la etapa:\n");
        sb.append(comando.instruccion() != null && !comando.instruccion().isBlank() ? comando.instruccion() : "Evaluar consistencia y completitud general.");
        sb.append("\n\n");

        List<String> hechos = EvaluacionLocal.verificaciones(documentText);
        if (!hechos.isEmpty()) {
            sb.append("Verificaciones automáticas ya comprobadas (no las contradigas):\n");
            for (String hecho : hechos) {
                sb.append("- ").append(hecho).append("\n");
            }
            sb.append("\n");
        }

        sb.append("<<<DOCUMENTO>>>\n");
        sb.append(documentText);
        sb.append("\n<<<FIN_DOCUMENTO>>>\n");

        return sb.toString();
    }

    private String cargarPromptSistema() {
        try (InputStream in = new ClassPathResource("prompts/evaluacion.system.txt").getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            log.error("No se pudo cargar evaluacion.system.txt, usando prompt por defecto: {}", e.getMessage());
            return "Eres un asistente de evaluación documental experto. Evalúa contra el criterio y responde un JSON con cumple, puntaje, resumen, observaciones y hallazgos.";
        }
    }
}
