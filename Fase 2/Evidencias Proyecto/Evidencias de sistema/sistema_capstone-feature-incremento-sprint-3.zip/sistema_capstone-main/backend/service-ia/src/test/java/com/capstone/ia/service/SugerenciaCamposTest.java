package com.capstone.ia.service;

import com.capstone.ia.client.OpenRouterApiClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SugerenciaCamposTest {

    private static final String DOCUMENTO = "Comite de proyectos. Monto: $1.250.000";

    private final OpenRouterApiClient client = mock(OpenRouterApiClient.class);
    private final SugerenciaCampos sugerencias = new SugerenciaCampos(client, new ObjectMapper());

    @Test
    @DisplayName("Debe conservar tipo, obligatorio, ayuda y sección propuestos por la IA")
    void shouldKeepFieldDetailsFromModel() {
        when(client.completarFormulario(anyString(), anyString())).thenReturn("""
                {"sugerencias": [{"texto": "Comite de proyectos", "etiqueta": "Nombre del comité", "tipo": "TEXTO",
                  "obligatorio": false, "opciones": [], "descripcion": "Ej.: Comité de riesgos", "seccion": "Datos generales"}]}
                """);

        SugerenciaCampos.Sugerencia sugerencia = sugerencias.sugerir(DOCUMENTO, List.of()).sugerencias().get(0);

        assertEquals("TEXTO", sugerencia.tipo());
        assertFalse(sugerencia.obligatorio());
        assertEquals("Ej.: Comité de riesgos", sugerencia.descripcion());
        assertEquals("Datos generales", sugerencia.seccion());
    }

    @Test
    @DisplayName("Debe avisar que se agotó el cupo diario cuando OpenRouter lo informa")
    void shouldExplainDailyQuota() {
        when(client.completarFormulario(anyString(), anyString()))
                .thenThrow(new IllegalStateException("429 Rate limit exceeded: free-models-per-day"));

        SugerenciaCampos.Resultado resultado = sugerencias.sugerir(DOCUMENTO, List.of());

        assertTrue(resultado.mensaje().startsWith("Se agotó el cupo diario gratuito de la IA"));
        assertEquals("MONTO", resultado.sugerencias().get(0).tipo());
    }
}
