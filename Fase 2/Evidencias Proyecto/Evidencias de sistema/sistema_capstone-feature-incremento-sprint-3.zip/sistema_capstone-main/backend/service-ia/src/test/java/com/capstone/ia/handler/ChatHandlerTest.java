package com.capstone.ia.handler;

import com.capstone.ia.client.OpenRouterApiClient;
import com.capstone.ia.contrato.ComandoTareaIa;
import com.capstone.ia.exception.IaProcesamientoException;
import com.capstone.ia.service.DocumentTextExtractor;
import com.capstone.ia.service.MinioDocumentReader;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChatHandlerTest {

    @Mock
    private MinioDocumentReader documentReader;

    @Mock
    private DocumentTextExtractor textExtractor;

    @Mock
    private OpenRouterApiClient openRouterClient;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private ChatHandler handler;

    @BeforeEach
    void setUp() {
        handler = new ChatHandler(documentReader, textExtractor, openRouterClient, objectMapper);
    }

    @Test
    @DisplayName("Chat exitoso con historial retorna JsonNode con campo respuesta")
    void chat_exitoso_retornaRespuesta() throws Exception {
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), UUID.randomUUID(), "CHAT",
                new ComandoTareaIa.Documento("documentos", "manual.pdf", "manual.pdf", "application/pdf"),
                new ComandoTareaIa.Contexto("SOL-01", "Manual de Operaciones", "Desc", "Manual", "Revisión", 1),
                "¿Cuál es el horario de atención?",
                List.of(new ComandoTareaIa.ParHistorial("¿Dónde opera?", "En Santiago de Chile")),
                List.of(),
                Instant.now()
        );

        when(documentReader.getDocumentStream("documentos", "manual.pdf"))
                .thenReturn(new ByteArrayInputStream("manual".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("manual.pdf")))
                .thenReturn("El horario de atención es de 08:30 a 17:30 horas.");

        when(openRouterClient.ejecutarConsulta(eq("CHAT"), anyList(), eq(false)))
                .thenReturn(new OpenRouterApiClient.RespuestaLlm("{\"respuesta\": \"El horario es de 08:30 a 17:30 hrs.\"}", "meta-llama/test"));

        HandlerResult resultado = handler.procesar(cmd);

        assertThat(resultado.data().has("respuesta")).isTrue();
        assertThat(resultado.data().get("respuesta").asText()).isEqualTo("El horario es de 08:30 a 17:30 hrs.");
        assertThat(resultado.modelo()).isEqualTo("meta-llama/test");
    }

    @Test
    @DisplayName("Documento ilegible en chat lanza DOCUMENTO_ILEGIBLE")
    void chat_documentoIlegible_lanzaExcepcion() throws Exception {
        ComandoTareaIa cmd = new ComandoTareaIa(
                1, UUID.randomUUID(), UUID.randomUUID(), "CHAT",
                new ComandoTareaIa.Documento("documentos", "vacio.pdf", "vacio.pdf", "application/pdf"),
                null, "¿Duda?", List.of(), List.of(), Instant.now()
        );

        when(documentReader.getDocumentStream("documentos", "vacio.pdf"))
                .thenReturn(new ByteArrayInputStream("".getBytes()));
        when(textExtractor.extractText(any(InputStream.class), eq("vacio.pdf")))
                .thenReturn("");

        assertThatThrownBy(() -> handler.procesar(cmd))
                .isInstanceOf(IaProcesamientoException.class)
                .hasFieldOrPropertyWithValue("codigoError", "DOCUMENTO_ILEGIBLE");
    }
}
