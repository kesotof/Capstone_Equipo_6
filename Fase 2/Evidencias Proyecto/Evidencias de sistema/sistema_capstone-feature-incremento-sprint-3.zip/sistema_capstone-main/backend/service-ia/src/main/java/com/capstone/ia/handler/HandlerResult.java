package com.capstone.ia.handler;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * C7.5: Resultado de la ejecución de un handler con los datos parseados y el modelo real que respondió.
 */
public record HandlerResult(
        JsonNode data,
        String modelo
) {
}
