package com.capstone.ia.client;

import com.capstone.ia.client.dto.OpenRouterDto.*;
import com.capstone.ia.exception.IaProcesamientoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.ClientHttpRequestFactories;
import org.springframework.boot.web.client.ClientHttpRequestFactorySettings;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Stream;

/**
 * F7 (§8.2): cliente para la API de OpenRouter con soporte para json_object, respaldo entre modelos
 * gratuitos, reintento en 429/5xx tras 3s y modo simulación determinista.
 */
@Component
public class OpenRouterApiClient {

    private static final Logger log = LoggerFactory.getLogger(OpenRouterApiClient.class);
    // shortcut: modelos gratuitos de OpenRouter a nov-2026; si desaparecen del catálogo, actualizar esta lista.
    private static final List<String> MODELOS_RESPALDO = List.of(
            "openrouter/free",
            "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
            "nvidia/nemotron-3.5-lightning:free",
            "google/gemma-4-26b-a4b-it:free",
            "nvidia/nemotron-3-ultra-550b-a55b:free"
    );
    // Los modelos gratuitos suelen razonar antes de responder: con menos tokens el JSON llega cortado o vacío.
    private static final int MAX_TOKENS = 8192;

    private final RestClient restClient;
    private final String primaryModel;
    private final String apiKey;
    private final boolean simulationEnabled;
    private final long simulationDelayMs;

    public OpenRouterApiClient(
            RestClient.Builder builder,
            @Value("${openrouter.api.url:https://openrouter.ai/api/v1}") String apiUrl,
            @Value("${openrouter.api.key:}") String apiKey,
            @Value("${openrouter.api.model:openrouter/free}") String primaryModel,
            @Value("${openrouter.simulation.enabled:true}") boolean simulationEnabled,
            @Value("${openrouter.simulation.delay-ms:300}") long simulationDelayMs
    ) {
        this.apiKey = apiKey;
        this.primaryModel = primaryModel;
        this.simulationEnabled = simulationEnabled;
        this.simulationDelayMs = simulationDelayMs;
        this.restClient = builder
                .baseUrl(apiUrl)
                .requestFactory(ClientHttpRequestFactories.get(ClientHttpRequestFactorySettings.DEFAULTS
                        .withConnectTimeout(Duration.ofSeconds(10))
                        .withReadTimeout(Duration.ofSeconds(120))))
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + (apiKey != null ? apiKey : ""))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("HTTP-Referer", "http://localhost:3000")
                .defaultHeader("X-Title", "Sistema Capstone Gestion Documental")
                .defaultHeader("X-OpenRouter-App-Visibility", "hidden")
                .build();
    }

    public boolean isSimulationMode() {
        return simulationEnabled || apiKey == null || apiKey.isBlank() || apiKey.startsWith("your_") || apiKey.equals("dummy_key");
    }

    public String getPrimaryModel() {
        return primaryModel;
    }

    public record RespuestaLlm(String contenido, String modeloUtilizado) {}

    /**
     * Ejecuta una consulta al modelo LLM; {@code tipo} elige la respuesta fija del modo simulación.
     */
    public RespuestaLlm ejecutarConsulta(String tipo, List<Message> mensajes, boolean requiereJson) {
        if (isSimulationMode()) {
            return new RespuestaLlm(responderSimulado(tipo), primaryModel);
        }

        ResponseFormat format = requiereJson ? new ResponseFormat("json_object") : null;

        // Intento 1 con retry en 429/5xx tras 3s (§8.2)
        try {
            return probarModelos(mensajes, format);
        } catch (Exception e) {
            if (esReintentable(e)) {
                log.warn("Fallo transitorio al consultar OpenRouter ({}), reintentando en 3s...", e.getMessage());
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw IaProcesamientoException.iaNoDisponible("Llamada a IA interrumpida", ie);
                }
                try {
                    return probarModelos(mensajes, format);
                } catch (Exception reintentoEx) {
                    log.error("Fallo persistente tras reintento en OpenRouter: {}", reintentoEx.getMessage());
                    throw IaProcesamientoException.iaNoDisponible("Proveedor de IA no disponible tras reintento: " + reintentoEx.getMessage(), reintentoEx);
                }
            }
            log.error("Error no reintentable al consultar OpenRouter: {}", e.getMessage());
            throw IaProcesamientoException.iaNoDisponible("Error al consultar proveedor de IA: " + e.getMessage(), e);
        }
    }

    /** Chat con respuesta en JSON para el autocompletado y sugerencias de plantillas. */
    public String completarFormulario(String systemContent, String userContent) {
        log.info("Consultando OpenRouter para autocompletado con modelo primario: {}", primaryModel);
        RespuestaLlm respuesta = ejecutarConsulta("AUTOCOMPLETAR", List.of(
                new Message("system", systemContent),
                new Message("user", userContent)
        ), true);
        return respuesta.contenido();
    }

    /**
     * Los modelos gratuitos se saturan seguido (429) y OpenRouter a veces corta toda la petición en vez de pasar al
     * respaldo: por eso se prueba cada modelo por separado hasta que uno responda.
     */
    private RespuestaLlm probarModelos(List<Message> mensajes, ResponseFormat format) {
        RuntimeException ultimo = null;
        for (String modelo : Stream.concat(Stream.of(primaryModel), MODELOS_RESPALDO.stream()).distinct().toList()) {
            ChatRequest request = new ChatRequest(
                    modelo,
                    null,
                    mensajes,
                    format,
                    0.2,
                    MAX_TOKENS,
                    // Sin exigir modo JSON: ningún modelo gratuito lo garantiza y las respuestas se limpian al leerlas.
                    new ProviderConfig(true, false),
                    false
            );
            try {
                return invocarApi(request);
            } catch (HttpClientErrorException.Unauthorized e) {
                throw e; // Clave inválida: ningún otro modelo va a funcionar.
            } catch (RestClientException | IaProcesamientoException e) {
                log.warn("El modelo {} no respondió ({}); se intenta con el siguiente", modelo, e.getMessage());
                ultimo = e;
            }
        }
        throw ultimo;
    }

    private RespuestaLlm invocarApi(ChatRequest request) {
        ChatResponse response = restClient.post()
                .uri("/chat/completions")
                .body(request)
                .retrieve()
                .body(ChatResponse.class);

        if (response != null && response.choices() != null && !response.choices().isEmpty()) {
            String content = response.choices().get(0).message().content();
            if (content != null && !content.isBlank()) {
                String modeloReal = response.model() != null && !response.model().isBlank() ? response.model() : primaryModel;
                return new RespuestaLlm(content.trim(), modeloReal);
            }
        }
        throw IaProcesamientoException.respuestaInvalida("OpenRouter retornó una respuesta vacía");
    }

    private boolean esReintentable(Exception e) {
        if (e instanceof HttpClientErrorException hce) {
            return hce.getStatusCode().value() == 429;
        }
        if (e instanceof HttpServerErrorException) {
            return true;
        }
        return e instanceof ResourceAccessException;
    }

    private String responderSimulado(String tipo) {
        if (simulationDelayMs > 0) {
            try {
                Thread.sleep(simulationDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        String recurso = switch (tipo != null ? tipo.toUpperCase() : "") {
            case "EVALUACION" -> "simulacion/evaluacion.json";
            case "CHAT" -> "simulacion/chat.json";
            case "AUTOCOMPLETAR" -> "simulacion/autocompletado.json";
            default -> "simulacion/evaluacion.json";
        };
        try (InputStream in = new ClassPathResource(recurso).getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            log.warn("No se pudo cargar fixture de simulación '{}', usando fallback inline: {}", recurso, e.getMessage());
            return switch (tipo != null ? tipo.toUpperCase() : "") {
                case "CHAT" -> "{\"respuesta\": \"Respuesta simulada para chat.\"}";
                case "AUTOCOMPLETAR" -> "{\"sugerencias\": {}, \"noEncontrados\": []}";
                default -> "{\"cumple\": true, \"puntaje\": 80, \"resumen\": \"Evaluación simulada\", \"observaciones\": [], \"hallazgos\": []}";
            };
        }
    }

    /** Los modelos no conocen la fecha actual: sin ella marcan como 'futuras' fechas que no lo son. */
    public static String hoy() {
        return LocalDate.now(ZoneId.of("America/Santiago")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }
}
