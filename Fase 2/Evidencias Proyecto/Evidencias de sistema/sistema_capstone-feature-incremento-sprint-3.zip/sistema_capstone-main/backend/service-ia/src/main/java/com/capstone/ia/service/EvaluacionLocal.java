package com.capstone.ia.service;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Verificaciones deterministas con reglas exactas sobre el texto del documento
 * (campos sin completar, RUT chileno con dígito verificador, cuadratura de neto/IVA/total y fechas).
 * Se entregan a EvaluacionHandler para enriquecer el contexto del modelo y evitar alucinaciones aritméticas.
 */
public final class EvaluacionLocal {

    private static final Pattern MARCADOR = Pattern.compile("\\{\\{\\s*([\\w.-]+)\\s*}}");
    private static final Pattern EN_BLANCO = Pattern.compile("_{5,}|\\[\\s*(?:completar|pendiente)[^]]*]|\\bX{4,}\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONTO = Pattern.compile("^\\s*(?:monto\\s+)?(neto|iva|total)\\b[^:\\n]{0,30}:\\s*\\$?\\s*([\\d.,]+)",
            Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private EvaluacionLocal() {
    }

    /**
     * Hechos comprobados con reglas exactas (RUT, montos, fechas, campos sin completar). Se entregan al modelo
     * para que no los contradiga: los LLM suelen equivocarse al calcular dígitos verificadores o sumas.
     */
    public static List<String> verificaciones(String texto) {
        String contenido = texto == null ? "" : texto.strip();
        if (contenido.length() < 40) return List.of();
        Revision revision = revisar(contenido);
        List<String> hechos = new ArrayList<>(revision.hallazgos());
        hechos.addAll(revision.verificado());
        return hechos;
    }

    private record Revision(List<String> hallazgos, List<String> recomendaciones, List<String> verificado, int penalizacion, boolean grave) {}

    private static Revision revisar(String contenido) {
        List<String> hallazgos = new ArrayList<>();
        List<String> recomendaciones = new ArrayList<>();
        List<String> verificado = new ArrayList<>();
        int penalizacion = 0;
        boolean grave = false;

        Set<String> marcadores = new LinkedHashSet<>();
        Matcher m = MARCADOR.matcher(contenido);
        while (m.find()) marcadores.add(m.group(1));
        if (!marcadores.isEmpty()) {
            penalizacion += 30;
            grave = true;
            hallazgos.add("quedan campos sin completar (" + String.join(", ", marcadores) + ")");
            recomendaciones.add("Pedir al emisor que complete los campos pendientes del documento");
        } else if (EN_BLANCO.matcher(contenido).find()) {
            penalizacion += 10;
            hallazgos.add("hay espacios en blanco o marcas para completar");
            recomendaciones.add("Confirmar que no falte información en los espacios en blanco");
        }

        Set<String> rutValidos = new LinkedHashSet<>();
        Set<String> rutInvalidos = new LinkedHashSet<>();
        m = AutocompletadoFormulario.RUT.matcher(contenido);
        while (m.find()) {
            boolean valido = AutocompletadoFormulario.digitoVerificador(m.group(1).replace(".", "")) == Character.toUpperCase(m.group(2).charAt(0));
            (valido ? rutValidos : rutInvalidos).add(m.group().strip());
        }
        if (!rutInvalidos.isEmpty()) {
            penalizacion += 20;
            grave = true;
            hallazgos.add("el RUT " + String.join(", ", rutInvalidos) + " tiene un dígito verificador incorrecto");
            recomendaciones.add("Verificar con el emisor el RUT " + String.join(", ", rutInvalidos));
        }
        if (!rutValidos.isEmpty()) {
            verificado.add("RUT con dígito verificador válido: " + String.join(", ", rutValidos));
        }

        Map<String, Long> montos = new LinkedHashMap<>();
        m = MONTO.matcher(contenido);
        while (m.find()) {
            if (AutocompletadoFormulario.numero(m.group(2)) instanceof Long valor) montos.putIfAbsent(m.group(1).toLowerCase(Locale.ROOT), valor);
        }
        if (montos.size() == 3) {
            long neto = montos.get("neto"), iva = montos.get("iva"), total = montos.get("total");
            if (Math.abs(neto + iva - total) > 1) {
                penalizacion += 25;
                grave = true;
                hallazgos.add("el total (" + pesos(total) + ") no coincide con neto + IVA (" + pesos(neto + iva) + ")");
                recomendaciones.add("Revisar los montos del documento antes de aprobar el pago");
            } else if (Math.abs(Math.round(neto * 0.19) - iva) > 1) {
                penalizacion += 15;
                hallazgos.add("el IVA (" + pesos(iva) + ") no corresponde al 19% del neto (" + pesos(Math.round(neto * 0.19)) + ")");
                recomendaciones.add("Confirmar si la operación tiene una tasa de IVA distinta o un error de cálculo");
            } else {
                verificado.add("los montos son coherentes: neto " + pesos(neto) + " + IVA " + pesos(iva) + " = total " + pesos(total));
            }
        }

        LocalDate inicio = fechaEtiquetada(contenido, "inicio|desde");
        LocalDate termino = fechaEtiquetada(contenido, "t[ée]rmino|hasta");
        if (inicio != null && termino != null) {
            if (termino.isBefore(inicio)) {
                penalizacion += 20;
                grave = true;
                hallazgos.add("la fecha de término (" + termino.format(FECHA) + ") es anterior a la de inicio (" + inicio.format(FECHA) + ")");
                recomendaciones.add("Corregir el período informado en el documento");
            } else {
                verificado.add("las fechas de inicio (" + inicio.format(FECHA) + ") y término (" + termino.format(FECHA) + ") son coherentes");
            }
        }
        return new Revision(hallazgos, recomendaciones, verificado, penalizacion, grave);
    }

    /** Fecha en la línea cuyo inicio contiene la etiqueta (p. ej. "Fecha de inicio: 09/11/2026"). */
    private static LocalDate fechaEtiquetada(String texto, String etiqueta) {
        Matcher m = Pattern.compile("^[^:\\n]{0,40}\\b(?:" + etiqueta + ")\\b[^:\\n]{0,40}:(.*)$", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE).matcher(texto);
        while (m.find()) {
            String fecha = AutocompletadoFormulario.fecha(m.group(1));
            if (fecha != null) return LocalDate.parse(fecha);
        }
        return null;
    }

    private static String pesos(long valor) {
        return "$" + NumberFormat.getIntegerInstance(Locale.forLanguageTag("es-CL")).format(valor);
    }
}
