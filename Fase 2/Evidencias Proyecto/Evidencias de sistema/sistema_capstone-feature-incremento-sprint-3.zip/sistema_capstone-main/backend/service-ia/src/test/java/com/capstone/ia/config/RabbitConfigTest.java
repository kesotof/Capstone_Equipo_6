package com.capstone.ia.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;

import static org.assertj.core.api.Assertions.assertThat;

class RabbitConfigTest {

    private final RabbitConfig config = new RabbitConfig();

    @Test
    @DisplayName("capstone.dlx debe ser DirectExchange")
    void capstoneDlx_esDirectExchange() {
        DirectExchange dlx = config.capstoneDlx();
        assertThat(dlx.getName()).isEqualTo("capstone.dlx");
        assertThat(dlx.isDurable()).isTrue();
        assertThat(dlx.isAutoDelete()).isFalse();
    }

    @Test
    @DisplayName("bindingIaDlq usa DirectExchange con routing key ia.tarea.q")
    void bindingIaDlq_usaClaveCorrecta() {
        DirectExchange dlx = config.capstoneDlx();
        Queue dlq = config.colaIaDlq();
        Binding binding = config.bindingIaDlq(dlx, dlq);

        assertThat(binding.getExchange()).isEqualTo("capstone.dlx");
        assertThat(binding.getRoutingKey()).isEqualTo("ia.tarea.q");
        assertThat(binding.getDestination()).isEqualTo("ia.tarea.q.dlq");
    }
}
