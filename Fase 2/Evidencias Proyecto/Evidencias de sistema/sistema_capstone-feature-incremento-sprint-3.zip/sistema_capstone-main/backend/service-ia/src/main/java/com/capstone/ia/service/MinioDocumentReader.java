package com.capstone.ia.service;

import com.capstone.ia.exception.IaProcesamientoException;
import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.errors.ErrorResponseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;

@Service
public class MinioDocumentReader {

    private static final Logger log = LoggerFactory.getLogger(MinioDocumentReader.class);

    private final MinioClient minioClient;
    private final String defaultBucketName;

    public MinioDocumentReader(
            MinioClient minioClient,
            @Value("${minio.bucket:documentos}") String defaultBucketName
    ) {
        this.minioClient = minioClient;
        this.defaultBucketName = defaultBucketName;
    }

    public InputStream getDocumentStream(String storageKey) {
        return getDocumentStream(null, storageKey);
    }

    public InputStream getDocumentStream(String bucket, String storageKey) {
        if (storageKey == null || storageKey.isBlank()) {
            throw IaProcesamientoException.documentoNoEncontrado("Clave de almacenamiento ausente");
        }
        String targetBucket = (bucket != null && !bucket.isBlank()) ? bucket.trim() : defaultBucketName;
        log.info("Descargando documento desde MinIO: bucket={}, key={}", targetBucket, storageKey);
        try {
            return minioClient.getObject(
                    GetObjectArgs.builder()
                            .bucket(targetBucket)
                            .object(storageKey)
                            .build()
            );
        } catch (ErrorResponseException e) {
            String code = e.errorResponse().code();
            if ("NoSuchKey".equalsIgnoreCase(code) || "NoSuchBucket".equalsIgnoreCase(code) || "ResourceNotFound".equalsIgnoreCase(code)) {
                log.warn("Documento no encontrado en MinIO: bucket={}, key={}, code={}", targetBucket, storageKey, code);
                throw IaProcesamientoException.documentoNoEncontrado("Documento no encontrado en almacenamiento: " + storageKey);
            }
            log.error("Error MinIO al leer documento bucket={}, key={}: {}", targetBucket, storageKey, e.getMessage());
            throw new RuntimeException("Error al leer archivo desde MinIO: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Excepción inesperada al leer documento bucket={}, key={}: {}", targetBucket, storageKey, e.getMessage());
            throw new RuntimeException("Error al conectar con almacenamiento MinIO: " + e.getMessage(), e);
        }
    }
}
