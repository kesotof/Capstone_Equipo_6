# AGENTS.md — mapa del proyecto para agentes

> Guía de entrada para cualquier agente (Claude Code la carga desde `CLAUDE.md`; opencode y otros, directamente). **No cambia de un sprint a otro.** El estado del día está en [`ESTADO.md`](./ESTADO.md).

## 1. Qué es

**Sistema de Gestión Documental y Flujos de Aprobación** (capstone Duoc UC; la interfaz usa la marca "MasterBase"). Un colaborador registra una **solicitud** con un documento (adjunto o generado desde una plantilla DOCX); la solicitud recorre las **etapas** de un flujo configurable donde **revisores** aprueban, rechazan o piden corrección, con plazos (SLA), correlativos por tipo de documento, versiones del documento, notificaciones (plataforma y correo), auditoría y asistencia de IA. El acceso es RBAC por áreas jerárquicas.

**Stack:** Java 21 + Spring Boot 3.2 (3 servicios) · React + Vite · PostgreSQL 16 (Flyway) · Keycloak 24 · RabbitMQ 3.13 · MinIO · Mailpit · Playwright. Todo en `docker-compose.yml`.

## 2. Al iniciar una sesión

1. Lee [`ESTADO.md`](./ESTADO.md) (rama, tarea en curso, **el** próximo paso, bloqueos). **No leas `claude-progress.md` completo**: es historia; búscalo solo si necesitas el detalle de una fase.
2. Si la tarea viene de un plan, lee solo la sección de ese plan (índice del sprint en `docs/sprint-N/README.md`).
3. Estado de las historias: `node scripts/features.js` (resumen) o `--us US-35` (detalle). **No leas `feature_list.json` entero.**
4. Usa la tabla de la §4 para saber qué más leer. `git log --oneline -5` y `git status`.
5. Entorno: `./init.ps1` (o `./init.sh`). Infraestructura: `docker compose up -d postgres keycloak rabbitmq minio minio-init mailpit`. Todo: `docker compose --profile apps up -d`. Verifica `http://localhost:8081/actuator/health` antes de cambiar código.

## 3. Dónde está el código

| Ruta | Qué hay |
|---|---|
| `backend/sistema-principal/` (:8081) | API REST, motor de flujos, RBAC, plantillas, notificaciones, IA (orquestación). Único dueño de `sistema_db`. Paquetes en `src/main/java/com/capstone/sistema/`: `flow`, `doc`, `template`, `rbac`, `org`, `users`, `audit`, `notificacion`, `ia`, `mensajeria` |
| `backend/sistema-principal/src/main/resources/db/migration/` | Migraciones Flyway `V1`…`V7`. **Nunca edites una migración aplicada: crea la siguiente** |
| `backend/service-notificaciones/` (:8082) | Worker de correo (RabbitMQ → Resend). Sin base de datos |
| `backend/service-ia/` (:8083) | Worker de IA (RabbitMQ → MinIO + Tika → OpenRouter). Sin base de datos |
| `frontend/src/` (:3000) | SPA: `views/`, `components/`, `services/` (clientes API), `hooks/`, `App.jsx` (rutas), `components/shell/navigation.js` (menú y permisos) |
| `tests/e2e/` | Specs Playwright (`src/specs/<módulo>/`), Page Objects, `README.md` con los patrones |
| `docker/` | Keycloak (realm, tema, `configure-login-flow.sh`), MinIO (`create-buckets.sh`), PostgreSQL (init) |
| `scripts/` | `test-changed.*`, `clean-test-db.*`, `run-e2e-tests.*`, `features.js`, `harness-check.js`, `audit_forbidden_patterns.js` |

Catálogo archivo por archivo: [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) (consúltalo por sección, no entero).

## 4. Qué leer según la tarea

| Si vas a… | Lee |
|---|---|
| Implementar una fase de un plan | La sección de esa fase + [`docs/DECISIONES.md`](./docs/DECISIONES.md) del sprint + subagente `impl-dev` |
| Tocar endpoints REST o su consumo en el frontend | [`docs/API_CONTRACTS.md`](./docs/API_CONTRACTS.md) (sección del módulo; Sprint 3 = §16). Con el backend arriba, `/v3/api-docs` da la forma exacta |
| Tocar colas, mensajes o los servicios asíncronos | [`docs/ASYNC_CONTRACTS.md`](./docs/ASYNC_CONTRACTS.md) y `docs/async-contracts/*.json` |
| Cambiar el modelo de datos | `db/migration/V1__schema_v5.sql` (tablas, vistas, triggers, SQLSTATE `CB0xx`) y la última migración |
| Tocar permisos o visibilidad | `rbac/service/RbacAccessService`, vistas `v_acceso_solicitud`, `v_permiso_efectivo`, `v_revisor_solicitud`; `frontend/src/components/access/AccessContext.jsx` |
| Tocar el motor de estados de una solicitud | `flow/service/SolicitudWorkflowService` (v5) y `flow/service/SolicitudService` (legado, aún en uso); ambos publican `TransicionSolicitudEvent` |
| Notificaciones o correo | `notificacion/` (`NotificacionMensajeFactory` = todos los textos) y `service-notificaciones` |
| IA | `ia/` (principal) y `service-ia` (handlers y `resources/prompts/`) |
| Plantillas DOCX | `template/` (scanner, schema, render) y `doc/model/Plantilla*` |
| Escribir backend Java | Skill `spring-boot-best-practices` (`.agents/skills/`), en especial §12 "Trampas" |
| Una duda de Spring que el skill no cubre | Skill `spring-docs-research` |
| Escribir o corregir E2E | [`tests/e2e/README.md`](./tests/e2e/README.md) |
| Credenciales de prueba, flujo base, limpieza de la base | [`docs/SYSTEM_INVARIANTS.md`](./docs/SYSTEM_INVARIANTS.md) |
| Saber qué documento está vigente | [`docs/README.md`](./docs/README.md) |
| Criterios de aceptación de una historia | `node scripts/features.js --us US-xx` o [`docs/PRODUCT_BACKLOG.md`](./docs/PRODUCT_BACKLOG.md) |

## 5. Reglas no negociables

1. **Un tema a la vez:** solo la fase o tarea asignada; nada de refactors de paso.
2. **Pruebas focalizadas:** `scripts/test-changed.ps1` / `.sh`, o `mvn -o -q test -Dtest='com.capstone.sistema.<modulo>.**' -Dsurefire.failIfNoSpecifiedTests=false`. **Nunca `clean` ni `package`** para verificar. Para velocidad: `docker compose --profile dev-tools up -d backend-dev`.
3. **E2E solo si Eduardo lo pide.** Escribir o actualizar specs sí; ejecutarlos, no.
4. **SQL real se prueba contra PostgreSQL real** (Testcontainers + Flyway). Un mock no verifica SQL.
5. **No debilitar pruebas:** sin `skip`, `fixme`, timeouts más altos ni aserciones borradas (`node scripts/audit_forbidden_patterns.js`).
6. **Si el código contradice el plan, detente** y anótalo en el inventario del sprint; no improvises otro diseño.
7. **Sin secretos en el repo.** `.env` es local; `.env.example` lleva marcadores.
8. **Lo que importa queda en archivos** (bitácora, decisiones, inventario), no en el chat.

## 6. Niveles de verificación (`feature_list.json`)

`no_iniciado` → `implementado` → `verificado_unitario` → `verificado_e2e` → `aceptado`.
- Subir de nivel exige una evidencia nueva con **fecha, commit, comando y resultado**.
- Los agentes llegan como máximo a `verificado_e2e`. **`aceptado` lo asigna solo Eduardo** (validación funcional y visual).
- Una entrada por historia de usuario (`US-xx`). Las fases de un plan no son entradas.

## 7. Trampas conocidas

Ya ocurrieron en este repo. Las de backend están detalladas en el skill `spring-boot-best-practices` §12.

- `@Transactional` no se aplica en llamadas dentro de la misma clase (`this.metodo()`), por ejemplo un `@Scheduled` que llama a otro método. Usa `TransactionTemplate`.
- `ON CONFLICT (col)` sobre un índice único parcial necesita `WHERE <predicado>`.
- Capturar una excepción que pasó por un `@Transactional` no evita el rollback. Lo externo (correo, IA, MinIO) va después del commit.
- Columnas `VARCHAR(n)` cortas (`log_evento.entidad_id` = 36).
- RabbitMQ: cambiar argumentos o tipo de una cola/exchange da `PRECONDITION_FAILED`; borra y recrea en `clean-test-db`.
- Keycloak SSO en E2E: antes de iniciar sesión con otro usuario, `await page.context().clearCookies(); await page.goto('/');`.
- Page Objects: inicializa los locators dentro del `constructor(page)`.
- Antes de escribir un selector, verifica el `data-testid` real en el JSX.
- Antes de documentar un endpoint, verifica el controller (`@RequestMapping`, autorización).
- Shell de Windows: no pongas `|` dentro de argumentos entre comillas; para comandos complejos, un `.ps1` en `scratch/`. `git grep -e A -e B` en vez de `A\|B`.
- Los subagentes se pierden si el servidor se reinicia: vuelve a encargar la fase con el mismo prompt.

## 8. Al cerrar una sesión

1. **Bitácora:** agrega una entrada al final de [`claude-progress.md`](./claude-progress.md) con el formato fijo del encabezado de ese archivo.
2. **Historias:** si cambió un nivel, actualiza `feature_list.json` con su evidencia.
3. **Decisiones:** si tomaste o cambiaste una, regístrala en [`docs/DECISIONES.md`](./docs/DECISIONES.md).
4. **Estado:** **sobrescribe** [`ESTADO.md`](./ESTADO.md) (máximo 80 líneas, un solo próximo paso, fecha de hoy).
5. **Estructura:** si agregaste módulos, endpoints o archivos relevantes, actualiza `PROJECT_STRUCTURE.md` y/o los contratos.
6. `node scripts/harness-check.js` en verde (también corre en el hook de pre-commit: `git config core.hooksPath .githooks`).
7. Commit descriptivo si el código compila y las pruebas pasan. Deja los servicios estables.

## 9. Subagentes y skills

| Nombre | Ruta | Para qué |
|---|---|---|
| `impl-dev` | `.agents/agents/impl-dev.md` | Implementa una fase: código + pruebas focalizadas |
| `qa-runner` | `.agents/agents/qa-runner.md` | Verifica una fase y registra evidencia; solo corrige pruebas |
| `reviewer` | `.agents/agents/reviewer.md` | Revisión independiente contra el plan antes de cerrar un sprint o mezclar a `main` |
| `spring-boot-best-practices` | `.agents/skills/` | Estándares del backend y trampas conocidas |
| `spring-docs-research` | `.agents/skills/` | Documentación de Spring en caché local |

Una fase = un `impl-dev` + un `qa-runner`. Se puede paralelizar código en archivos distintos, **nunca** fases que reconstruyan contenedores o corran E2E. **La fuente es `.agents/`** (versionada). Claude Code los busca en `.claude/`: después de clonar o de editar un skill o subagente, ejecuta `node scripts/sync-skills.js`, que copia `.agents/skills` y `.agents/agents` a `.claude/`.
