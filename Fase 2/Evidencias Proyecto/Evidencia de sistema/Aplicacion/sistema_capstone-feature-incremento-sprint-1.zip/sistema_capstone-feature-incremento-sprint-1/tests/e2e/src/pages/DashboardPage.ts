import { Page, Locator, expect } from '@playwright/test';

/**
 * Page Object Model para el Dashboard principal de la aplicación React.
 */
export class DashboardPage {
  readonly page: Page;
  readonly sidebar: Locator;
  readonly brandTitle: Locator;
  readonly dashboardHeading: Locator;
  readonly logoutButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.sidebar = page.locator('aside.sidebar');
    this.brandTitle = page.locator('aside.sidebar .brand h1');
    this.dashboardHeading = page.locator('section.view-container h2');
    this.logoutButton = page.locator('button.logout-btn, button.logout-button, button:has-text("Cerrar sesión")');
  }

  async goto() {
    await this.page.goto('/dashboard');
    await this.isDisplayed();
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.dashboardHeading).toHaveText('Dashboard', { timeout: 15000 });
    return true;
  }

  async logout() {
    await this.logoutButton.click();
  }

  async clickTab(tabName: 'acciones' | 'en_tramite') {
    const tabButton = tabName === 'acciones'
      ? this.page.locator('.dashboard-tab-btn:has-text("Acciones Pendientes")')
      : this.page.locator('.dashboard-tab-btn:has-text("Mis Solicitudes en Trámite")');
    await tabButton.click();
  }

  async getActionRows(): Promise<Locator> {
    return this.page.locator('.dashboard-action-row');
  }

  async clickReview(title: string) {
    const row = this.page.locator(`.dashboard-action-row:has-text("${title}")`);
    await row.locator('.btn-review').click();
  }

  async clickCorrect(title: string) {
    const row = this.page.locator(`.dashboard-action-row:has-text("${title}")`);
    await row.locator('.btn-correct').click();
  }

  async clickTrack(title: string) {
    const row = this.page.locator(`.dashboard-request-row:has-text("${title}")`);
    await row.locator('.btn-track').click();
  }
}

