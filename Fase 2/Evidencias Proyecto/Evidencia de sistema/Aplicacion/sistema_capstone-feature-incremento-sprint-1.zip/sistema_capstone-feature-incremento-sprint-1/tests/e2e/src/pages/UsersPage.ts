import { Page, Locator, expect } from '@playwright/test';

export class UsersPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly addUserButton: Locator;
  readonly refreshButton: Locator;
  readonly userTable: Locator;
  readonly successMessage: Locator;
  readonly errorMessage: Locator;

  // Modal Crear
  readonly createModal: Locator;
  readonly emailInput: Locator;
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly passwordInput: Locator;
  readonly submitCreateButton: Locator;

  // Modal Editar
  readonly editModal: Locator;
  readonly editFirstNameInput: Locator;
  readonly editLastNameInput: Locator;
  readonly submitEditButton: Locator;

  // Modal Eliminar
  readonly deleteModal: Locator;
  readonly confirmDeleteButton: Locator;


  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('h2:has-text("Organización y usuarios"), .page-header h2');
    this.addUserButton = page.locator('button.add-user-button');
    this.refreshButton = page.locator('button[aria-label="Actualizar usuarios"]');
    this.userTable = page.locator('table.data-table');
    this.successMessage = page.locator('.page-message.form-message-success');
    this.errorMessage = page.locator('.page-message.form-message-error, .form-message.form-message-error');

    this.createModal = page.locator('form.user-form-modal[aria-labelledby="create-user-title"]');
    this.emailInput = this.createModal.locator('input[name="email"]');
    this.firstNameInput = this.createModal.locator('input[name="firstName"]');
    this.lastNameInput = this.createModal.locator('input[name="lastName"]');
    this.passwordInput = this.createModal.locator('input[name="password"]');
    this.confirmPasswordInput = this.createModal.locator('input[name="confirmPassword"]');
    this.requirePasswordChangeCheckbox = this.createModal.locator('input[name="requirePasswordChange"]');
    this.submitCreateButton = this.createModal.locator('button[type="submit"]');

    this.editModal = page.locator('form.user-form-modal[aria-labelledby="edit-user-title"]');
    this.editFirstNameInput = this.editModal.locator('input[name="firstName"]');
    this.editLastNameInput = this.editModal.locator('input[name="lastName"]');
    this.editNewPasswordInput = this.editModal.locator('input[name="newPassword"]');
    this.editConfirmPasswordInput = this.editModal.locator('input[name="confirmPassword"]');
    this.editRequirePasswordChangeCheckbox = this.editModal.locator('input[name="requirePasswordChange"]');
    this.submitEditButton = this.editModal.locator('button[type="submit"]');

    this.deleteModal = page.locator('div.user-form-modal[aria-labelledby="delete-user-title"]');
    this.confirmDeleteButton = this.deleteModal.locator('button.danger-btn');
  }

  async goto() {
    const navLink = this.page.locator('aside.sidebar nav a:has-text("Organización y Usuarios")');
    if (await navLink.isVisible({ timeout: 2000 }).catch(() => false)) {
      await navLink.click();
    } else {
      await this.page.goto('/configurar-org-usuarios');
    }
  }

  async isDisplayed(): Promise<boolean> {
    await expect(this.heading).toBeVisible({ timeout: 15000 });
    return true;
  }

  async createUser(email: string, firstName: string, lastName: string, password: string, requirePasswordChange: boolean = false, confirmPassword?: string) {
    await this.addUserButton.click();
    await expect(this.createModal).toBeVisible();
    await this.emailInput.fill(email);
    await this.firstNameInput.fill(firstName);
    await this.lastNameInput.fill(lastName);
    await this.passwordInput.fill(password);
    await this.confirmPasswordInput.fill(confirmPassword !== undefined ? confirmPassword : password);
    if (!requirePasswordChange && await this.requirePasswordChangeCheckbox.isChecked()) {
      await this.requirePasswordChangeCheckbox.uncheck();
    }
    await this.submitCreateButton.click();
    await expect(this.createModal).toBeHidden({ timeout: 10000 });
  }


  getUserRow(email: string) {
    return this.page.locator(`tr[data-user-email="${email}"]`);
  }

  async editUser(
    email: string,
    newFirstName: string,
    newLastName: string,
    newPassword?: string,
    requirePasswordChange: boolean = false
  ) {
    const row = this.getUserRow(email);
    await row.locator('button[title="Editar datos de usuario"]').click();
    await expect(this.editModal).toBeVisible();
    await this.editFirstNameInput.fill(newFirstName);
    await this.editLastNameInput.fill(newLastName);

    if (newPassword) {
      await this.editNewPasswordInput.fill(newPassword);
      await this.editConfirmPasswordInput.fill(newPassword);
      if (requirePasswordChange) {
        if (!await this.editRequirePasswordChangeCheckbox.isChecked()) {
          await this.editRequirePasswordChangeCheckbox.check();
        }
      } else {
        if (await this.editRequirePasswordChangeCheckbox.isChecked()) {
          await this.editRequirePasswordChangeCheckbox.uncheck();
        }
      }
    }

    await this.submitEditButton.click();
    await expect(this.editModal).toBeHidden({ timeout: 10000 });
  }

  async toggleUserStatus(email: string) {
    const row = this.getUserRow(email);
    const toggleButton = row.locator('button.action-btn-toggle-active, button.action-btn-toggle-inactive');
    await toggleButton.click();
  }


  async deleteUser(email: string) {
    const row = this.getUserRow(email);
    await row.locator('button.action-btn-danger').click();
    await expect(this.deleteModal).toBeVisible();
    await this.confirmDeleteButton.click();
    await expect(this.deleteModal).toBeHidden({ timeout: 10000 });
  }
}
