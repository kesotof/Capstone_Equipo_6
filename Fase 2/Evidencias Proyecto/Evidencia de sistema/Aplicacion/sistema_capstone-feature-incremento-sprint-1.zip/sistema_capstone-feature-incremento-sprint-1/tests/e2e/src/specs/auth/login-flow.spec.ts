import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';

test.describe('Flujo de Autenticación OIDC y Control de Acceso (Regresión)', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
  });

  test('1. Debe redirigir automáticamente al login OIDC de Keycloak con branding MasterBase', async ({ page }) => {
    await loginPage.goto();

    // Comprobar redirección OIDC
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/);

    // Verificar presencia de elementos visuales en español
    await expect(loginPage.pageTitle).toContainText('Accede a tu cuenta');
    await expect(loginPage.usernameInput).toBeVisible();
    await expect(loginPage.passwordInput).toBeVisible();
    await expect(loginPage.loginButton).toBeVisible();
  });

  test('2. Debe mostrar error ante credenciales inválidas', async () => {
    await loginPage.goto();
    await loginPage.isDisplayed();

    // Intentar login con credenciales erróneas
    await loginPage.login('usuario_inexistente@capstone.local', 'clave_incorrecta_123');

    // Comprobar mensaje de fallo personalizado configurado en Keycloak
    const errorText = await loginPage.getErrorMessage();
    expect(errorText.toLowerCase()).toContain('credenciales invalidas');
  });

  test('3. Debe iniciar sesión exitosamente con cuenta válida, registrar auditoría de login y acceder al Dashboard', async ({ page }) => {
    let loginAudited = false;
    page.on('response', resp => {
      if (resp.url().includes('/api/audit/login') && resp.status() === 201) {
        loginAudited = true;
      }
    });

    await loginPage.goto();
    await loginPage.isDisplayed();

    // Iniciar sesión con cuenta admin del sistema
    await loginPage.login('admin@capstone.local', 'admin123');

    // Verificar redirección de vuelta al Dashboard en la SPA
    await dashboardPage.isDisplayed();
    await expect(dashboardPage.brandTitle).toHaveText('MasterBase');
    await expect(page).toHaveURL(/.*\/dashboard/);

    // Confirmar que la auditoría de login fue registrada
    expect(loginAudited).toBe(true);
  });

  test('4. Debe cerrar sesión correctamente, registrar auditoría de logout e impedir acceso posterior a URLs protegidas', async ({ page }) => {
    let logoutAudited = false;
    page.on('response', resp => {
      if (resp.url().includes('/api/audit/logout') && resp.status() === 201) {
        logoutAudited = true;
      }
    });

    await loginPage.goto();
    await loginPage.isDisplayed();

    // Iniciar sesión
    await loginPage.login('admin@capstone.local', 'admin123');
    await dashboardPage.isDisplayed();

    // Ejecutar logout
    await dashboardPage.logout();

    // Verificar redirección OIDC de vuelta a la pantalla de login en Keycloak
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 15000 });
    await expect(loginPage.pageTitle).toContainText('Accede a tu cuenta');

    // Confirmar que la auditoría de logout fue registrada
    expect(logoutAudited).toBe(true);

    // Intentar acceder a una URL protegida del sistema (/dashboard)
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 10000 });
    await expect(loginPage.pageTitle).toContainText('Accede a tu cuenta');

    // Intentar acceder a otra URL protegida (/configurar-org-usuarios)
    await page.goto('/configurar-org-usuarios');
    await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 10000 });
    await expect(loginPage.pageTitle).toContainText('Accede a tu cuenta');
  });

  test('5. Sin sesión iniciada, debe proteger las URLs del sistema redirigiendo al login sin errores', async ({ page }) => {
    const protectedUrls = [
      '/dashboard',
      '/configurar-flujos',
      '/configurar-org-usuarios',
      '/configurar-planillas',
      '/nuevo-documento',
      '/mis-documentos',
      '/revisar-documento',
      '/corregir-documento',
      '/estado-solicitudes',
      '/logout',
      '/login'
    ];

    const pageErrors: string[] = [];
    page.on('pageerror', error => pageErrors.push(error.message));

    for (const targetUrl of protectedUrls) {
      await page.goto(targetUrl);

      // Comprobar redirección OIDC hacia Keycloak
      await expect(page).toHaveURL(/.*\/protocol\/openid-connect\/auth.*/, { timeout: 10000 });
      await expect(loginPage.pageTitle).toContainText('Accede a tu cuenta');
    }

    // Comprobar que ninguna URL del sistema arrojó errores de página no controlados
    expect(pageErrors).toHaveLength(0);
  });

  test('6. [CA 1.3] Debe bloquear temporalmente el acceso por 30 minutos tras 4 intentos fallidos consecutivos mostrando mensaje explícito en pantalla', async ({ request }) => {
    const keycloakUrl = process.env.KEYCLOAK_HOST
      ? `http://${process.env.KEYCLOAK_HOST}:${process.env.KEYCLOAK_PORT || '8080'}`
      : 'http://localhost:8080';

    // 1. Obtener token de administración de Keycloak
    const tokenResp = await request.post(`${keycloakUrl}/realms/master/protocol/openid-connect/token`, {
      form: {
        grant_type: 'password',
        client_id: 'admin-cli',
        username: 'admin',
        password: 'admin_secure_pass'
      }
    });
    expect(tokenResp.ok()).toBeTruthy();
    const { access_token } = await tokenResp.json();

    const bruteEmail = `brute_${Date.now()}@capstone.local`;
    const brutePass = 'CorrectPass123!';

    // 2. Crear usuario temporal de prueba en capstone-realm
    const createResp = await request.post(`${keycloakUrl}/admin/realms/capstone-realm/users`, {
      headers: { Authorization: `Bearer ${access_token}` },
      data: {
        username: bruteEmail,
        email: bruteEmail,
        enabled: true,
        credentials: [{ type: 'password', value: brutePass, temporary: false }]
      }
    });
    expect(createResp.status()).toBe(201);

    // Obtener ID del usuario creado para limpieza posterior
    const usersResp = await request.get(`${keycloakUrl}/admin/realms/capstone-realm/users?email=${encodeURIComponent(bruteEmail)}`, {
      headers: { Authorization: `Bearer ${access_token}` }
    });
    const users = await usersResp.json();
    const userId = users[0]?.id;

    try {
      await loginPage.goto();
      await loginPage.isDisplayed();

      // 3. Ejecutar 4 intentos consecutivos con contraseña errónea (con pausa de 1.2s para el detector)
      for (let attempt = 1; attempt <= 4; attempt++) {
        await loginPage.login(bruteEmail, `wrong_pass_${attempt}`);
        const errorText = await loginPage.getErrorMessage();
        if (attempt < 4) {
          expect(errorText.toLowerCase()).toContain('credenciales invalidas');
          await new Promise(r => setTimeout(r, 1200));
        }
      }

      // 4. Tras los fallos, intentar ingresar (incluso con la clave correcta) debe ser rechazado
      // mostrando claramente que la cuenta está bloqueada temporalmente por 30 minutos
      await new Promise(r => setTimeout(r, 1200));
      await loginPage.login(bruteEmail, brutePass);

      const lockError = await loginPage.getErrorMessage();
      console.log('Mensaje de bloqueo observado tras 4 fallos:', lockError);
      expect(lockError.toLowerCase()).toContain('demasiados intentos de inicio de sesión fallidos');
      expect(lockError.toLowerCase()).toContain('30 minutos');
    } finally {
      // 5. Limpieza: eliminar usuario temporal de prueba
      if (userId) {
        await request.delete(`${keycloakUrl}/admin/realms/capstone-realm/users/${userId}`, {
          headers: { Authorization: `Bearer ${access_token}` }
        });
      }
    }
  });
});
