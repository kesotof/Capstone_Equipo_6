# Especificación de Pruebas E2E - Sprint 1 (Playwright)

Este documento define la estrategia, flujos de prueba y mapeo de criterios de aceptación para la suite de pruebas End-to-End (E2E) con Playwright correspondiente al **Sprint 1: Sesiones, Flujo Base y Notificaciones**.

---

## 1. Principios de Diseño de Pruebas E2E

1. **Flujos Integrales de Usuario (Multi-Criterio)**:
   - En lugar de ejecutar pruebas atómicas aisladas que reinician el navegador en cada paso, cada suite simula una jornada completa de usuario (*User Journey*).
   - Un solo flujo E2E valida múltiples criterios de aceptación de forma encadenada (ej. validación de campos vacíos -> subida errónea -> subida correcta -> aparición en lista -> consulta de estado).
2. **Definición de Terminado (DoD) con Validación Visual**:
   - Una historia de usuario se considera terminada cuando su código está completo, la suite E2E automatizada pasa sin fallos y el **desarrollador verifica visualmente el flujo interactivo** (vía `.\scripts\run-e2e-tests.ps1 -UI` o navegador local `--headed`).
3. **Manejo de Pruebas Pendientes de Implementación**:
   - Aquellos flujos cuyas pantallas o endpoints aún no han sido construidos quedan completamente documentados y especificados aquí. Se implementarán incrementalmente junto con el desarrollo de cada historia.

---

## 2. Catálogo de Suites de Prueba E2E (Sprint 1)

### `E2E-AUTH-01`: Flujo Completo de Autenticación OIDC, Control de Acceso y Logout Seguro
- **Archivo**: `src/specs/auth/login-flow.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-01: Iniciar Sesión` (`auth-001`), `HU-02: Cerrar Sesión` (`auth-002`)
- **Criterios de Aceptación Verificados**:
  - `CA 1.1`: Formato de correo obligatorio en credenciales.
  - `CA 1.2`: Mensaje de error personalizado ante credenciales incorrectas (*"credenciales invalidas, intentelo denuevo"*).
  - `CA 1.3`: Bloqueo automático por 30 minutos tras 4 fallos consecutivos.
  - `CA 1.4`: Acceso exitoso a la vista principal (`/dashboard`) tras autenticación.
  - `CA 1.5`: Imposibilidad de acceder a rutas protegidas sin sesión OIDC activa.
  - `CA 2.1`: Cierre de sesión activo al invocar logout.
  - `CA 2.2`: Redirección inmediata a pantalla de acceso de Keycloak.
  - `CA 2.3`: Intento de reingreso a URLs protegidas (`/dashboard`, `/configurar-org-usuarios`) tras logout bloqueado y redirigido.
  - `CA 2.4`: Chequeo exhaustivo de URLs del sistema (`/dashboard`, `/mis-documentos`, `/nuevo-documento`, `/logout`, etc.) sin sesión, redirigiendo a login limpiamente sin errores de consola.
- **Casos Ejecutables en la Suite (100% PASSING)**:
  1. `Debe redirigir automáticamente al login OIDC de Keycloak con branding MasterBase`
  2. `Debe mostrar error ante credenciales inválidas`
  3. `Debe iniciar sesión exitosamente con cuenta válida y acceder al Dashboard`
  4. `Debe cerrar sesión correctamente e impedir acceso posterior a URLs protegidas`
  5. `Sin sesión iniciada, debe proteger las URLs del sistema redirigiendo al login sin errores`
- **Estado**: **IMPLEMENTADO Y ACTIVO (5/5 PASSING)**

---

### `E2E-USER-01`: Ciclo de Gestión de Usuarios y Restricción RBAC
- **Archivo**: `src/specs/users/user-management.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-03: Gestionar Usuarios` (`auth-003`)
- **Criterios de Aceptación Verificados**:
  - `CA 3.1`: Registro de nuevo usuario con correo válido, contraseña y asignación de rol (`ADMIN` / `APPROVER`).
  - `CA 3.2`: Modificación de información (nombre y apellido) del usuario.
  - `CA 3.3`: Desactivación lógica de usuario (sin eliminar historial).
  - `CA 3.4`: Bloqueo y mensaje descriptivo ante intento de registrar correo duplicado.
  - `CA 3.5`: Restricción de acceso a usuarios operativos: verificación de que el rol `APPROVER` no ve el menú de administración y recibe HTTP 403 si intenta invocar la API.
  - `CA 3.6`: Registro de auditoría de cada acción de gestión de usuarios.
- **Estado**: **EN PROGRESO** (Endpoints base POST/GET probados; pendiente UI de administración y edición/desactivación).

---

### `E2E-DOC-01`: Emisión Documental y Carga de Archivos sin Planilla
- **Archivo**: `src/specs/documentos/upload-document.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-04: Registrar documento sin planilla (Emisor)` (`doc-001`)
- **Criterios de Aceptación Verificados**:
  - `CA 4.1`: Soporte exclusivo para formatos `.doc`, `.docx`, `.pdf`, `.xml` y `.txt`. Rechazo de formatos no autorizados.
  - `CA 4.2`: Validación de campos obligatorios (título, descripción, archivo adjunto) antes de permitir el envío.
  - `CA 4.3`: Al enviarse, la solicitud se lista en "Mis Solicitudes" del emisor en estado `"pendiente de revision"`.
  - `CA 4.4`: Visualización clara del estado actual del documento en la tabla de solicitudes.
  - `CA 4.5`: Mensaje interactivo de confirmación / toast tras registro exitoso.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-REV-01`: Bandeja del Revisor y Consulta de Documentos Asignados
- **Archivo**: `src/specs/flujos/reviewer-inbox.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-05: Ver revisiones pendientes (Revisor)` (`flow-001`)
- **Criterios de Aceptación Verificados**:
  - `CA 5.1`: Acceso a bandeja de revisión con listado de documentos pendientes.
  - `CA 5.2`: Visualización de metadatos: nombre del documento, emisor, fecha de envío y estado.
  - `CA 5.3`: Selección de documento para abrir panel de detalle y previsualizar archivo adjunto.
  - `CA 5.4`: Filtrado estricto: solo documentos asignados que requieran revisión humana.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-REV-02`: Aprobación de Documento y Avance del Flujo
- **Archivo**: `src/specs/flujos/approve-flow.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-06: Aprobar documento (Revisor)` (`flow-002`), `HU-05`
- **Criterios de Aceptación Verificados**:
  - `CA 6.1`: Solo el revisor asignado tiene habilitada la acción de aprobación.
  - `CA 6.2`: Diálogo modal de confirmación antes de ejecutar la aprobación.
  - `CA 6.3`: Transición inmediata de estado a `"APROBADO"`.
  - `CA 6.4`: Registro auditable de la aprobación con fecha exacta y usuario ejecutor.
  - `CA 6.5`: Notificación automática enviada a los participantes del flujo.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-REV-03`: Rechazo de Documento con Motivo Justificado Obligatorio
- **Archivo**: `src/specs/flujos/reject-flow.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-07: Rechazar documento (Revisor)` (`flow-003`), `HU-05`
- **Criterios de Aceptación Verificados**:
  - `CA 7.1`: Permiso exclusivo del revisor asignado para rechazar.
  - `CA 7.2`: Campo de motivo obligatorio; bloqueo del botón de envío si el motivo está vacío.
  - `CA 7.3`: Confirmación interactiva antes de fijar el rechazo definitivo.
  - `CA 7.4`: Solicitud marcada como rechazada en el historial del flujo.
  - `CA 7.5`: Notificación entregada al emisor con el motivo detallado del rechazo.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-CORR-01`: Ciclo de Corrección, Observaciones y Reenvío
- **Archivo**: `src/specs/flujos/correction-cycle.spec.ts`
- **Historias de Usuario Cubiertas**:
  - `HU-08: Solicitar corrección a documento (Revisor)` (`flow-004`)
  - `HU-09: Ver observaciones del revisor (Emisor)` (`flow-005`)
  - `HU-10: Corregir documento (Emisor)` (`flow-006`)
- **Criterios de Aceptación Verificados**:
  - `CA 8.1 - 8.5`: Revisor solicita ajustes con observación obligatoria; estado cambia a `"pendiente de corrección"`; emisor notificado.
  - `CA 9.1 - 9.5`: Emisor abre solicitud, lee observaciones en panel visible y bloqueado para terceros no autorizados.
  - `CA 10.1 - 10.6`: Emisor modifica datos/archivo, valida obligatorios y reenvía; estado retorna a `"pendiente de revisión"`; revisor recibe notificación para segunda vuelta.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-HIST-01`: Trazabilidad e Inmutabilidad de la Línea de Tiempo
- **Archivo**: `src/specs/flujos/timeline-history.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-11: Consultar historial de flujos` (`flow-007`)
- **Criterios de Aceptación Verificados**:
  - `CA 11.1`: Historial ordenado cronológicamente según fecha de ocurrencia.
  - `CA 11.2`: Detalle explícito por evento: qué ocurrió, quién lo realizó y timestamp.
  - `CA 11.3`: Control de privacidad: únicamente usuarios con permisos sobre el documento pueden ver el historial.
  - `CA 11.4`: Inmutabilidad comprobada: no existen opciones de edición ni borrado en la vista de historial.
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

### `E2E-NOTIF-01`: Bandeja de Notificaciones Contextuales en Plataforma
- **Archivo**: `src/specs/notificaciones/inbox-notifications.spec.ts`
- **Historias de Usuario Cubiertas**: `HU-12: Revisar notificaciones en bandeja de entrada` (`notif-001`)
- **Criterios de Aceptación Verificados**:
  - `CA 12.1`: Aislamiento: el usuario visualiza únicamente sus propias notificaciones.
  - `CA 12.2`: Contenido descriptivo: indica el evento ocurrido y el identificador de la solicitud.
  - `CA 12.3`: Diferenciación visual clara entre notificaciones leídas y no leídas (badges, estilos).
  - `CA 12.4`: Navegabilidad: hacer clic en una notificación redirige directamente a la solicitud correspondiente.
  - `CA 12.5`: Generación selectiva: solo se generan ante cambios relevantes de estado (acción requerida o fin de flujo).
- **Estado**: **PENDIENTE DE IMPLEMENTACIÓN DEL SISTEMA**

---

## 3. Matriz Resumen de Cobertura E2E vs Criterios de Aceptación

| Código Suite E2E | Criterios Validados Simultáneamente | Nivel de Implementación Actual |
| :--- | :--- | :--- |
| `E2E-AUTH-01` | CA 1.1, CA 1.2, CA 1.3, CA 1.4, CA 1.5 | **100% Implementado** (`login-flow.spec.ts`) |
| `E2E-AUTH-02` | CA 1.6, CA 2.1, CA 2.2, CA 2.3, CA 2.4 | **100% Backend / Integración E2E lista** |
| `E2E-USER-01` | CA 3.1, CA 3.4, CA 3.5 (listos) / CA 3.2, CA 3.3, CA 3.6 (pendientes) | **50% Implementado** (API lista, falta UI) |
| `E2E-DOC-01` | CA 4.1, CA 4.2, CA 4.3, CA 4.4, CA 4.5 | **Especificado** (Pendiente desarrollo) |
| `E2E-REV-01` | CA 5.1, CA 5.2, CA 5.3, CA 5.4, CA 5.5, CA 5.6 | **Especificado** (Pendiente desarrollo) |
| `E2E-REV-02` | CA 6.1, CA 6.2, CA 6.3, CA 6.4, CA 6.5 | **Especificado** (Pendiente desarrollo) |
| `E2E-REV-03` | CA 7.1, CA 7.2, CA 7.3, CA 7.4, CA 7.5 | **Especificado** (Pendiente desarrollo) |
| `E2E-CORR-01` | CA 8.1 - 8.5, CA 9.1 - 9.5, CA 10.1 - 10.6 | **Especificado** (Pendiente desarrollo) |
| `E2E-HIST-01` | CA 11.1, CA 11.2, CA 11.3, CA 11.4 | **Especificado** (Pendiente desarrollo) |
| `E2E-NOTIF-01` | CA 12.1, CA 12.2, CA 12.3, CA 12.4, CA 12.5 | **Especificado** (Pendiente desarrollo) |

---

## 4. Procedimiento de Validación Visual con el Desarrollador

Para dar por cerrada cualquier historia durante el ciclo de desarrollo:

1. **Lanzar la prueba visual**:
   ```powershell
   .\scripts\run-e2e-tests.ps1 -UI
   ```
2. **Revisión conjunta**:
   - Desarrollador y Agente inspeccionan los pasos visuales ejecutados en el navegador.
   - Se validan tiempos de respuesta, renderizado de estilos, mensajes en español y navegación fluida.
3. **Aprobación formal**:
   - Si el resultado es satisfactorio, el desarrollador aprueba el cambio.
   - El agente marca la tarjeta en Trello y actualiza `feature_list.json` a `passing`.
