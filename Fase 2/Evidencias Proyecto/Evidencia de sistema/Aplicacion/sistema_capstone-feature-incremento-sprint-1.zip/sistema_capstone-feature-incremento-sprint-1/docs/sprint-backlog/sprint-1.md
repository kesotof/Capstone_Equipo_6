# Sprint 1 Backlog - Sesiones, Flujo Base y Notificaciones

**Sprint**: 1  
**Tablero Trello**: `sprint 1: sesiones + flujo base + notificaciones`  
**Board ID**: `6aa416e7f9aa35e0fd7d66c4`  
**Lista Trello**: `sprint backlog`  
**Documentos Vivos Asociados en Google Workspace**:
- **Plan de Pruebas (Google Doc)**: [1IJVYgmhlkqEzsfF7tfGzisUNOMW9AQva6ddavRvom9A](https://docs.google.com/document/d/1IJVYgmhlkqEzsfF7tfGzisUNOMW9AQva6ddavRvom9A/edit)
- **Casos de Prueba (Google Sheets)**: [19aAcFH3jr4JMrPwAJ_AUXNoC93aRvmJt6rEvJcq4v5g](https://docs.google.com/spreadsheets/d/19aAcFH3jr4JMrPwAJ_AUXNoC93aRvmJt6rEvJcq4v5g/edit) (Pestaña: *casos prueba sprint 1*)
- **Registro Daily Meeting (Google Sheets)**: [11N00UeYj3RfgC_J060WnS4NfHh505z2U2r8N2VzR3s8](https://docs.google.com/spreadsheets/d/11N00UeYj3RfgC_J060WnS4NfHh505z2U2r8N2VzR3s8/edit)

---

## 1. Resumen Ejecutivo del Sprint

El Sprint 1 tiene como objetivo implementar el núcleo de seguridad, gestión de identidades y el flujo básico documental end-to-end con notificaciones:
1. **Autenticación y Sesiones**: Acceso OIDC centralizado con Keycloak, bloqueo contra fuerza bruta y cierre de sesión seguro y auditado.
2. **Gestión de Usuarios (RBAC)**: Administración de cuentas con roles diferenciados (`ADMIN`, `APPROVER`), unicidad de correo y auditoría.
3. **Gestión Documental Base**: Emisión y carga de documentos (.doc, .docx, .pdf, .xml, .txt) a almacenamiento MinIO S3 con seguimiento de estado.
4. **Motor de Flujos y Revisiones**: Bandeja de revisiones pendientes, ciclo de aprobación, rechazo con justificación obligatoria y solicitud de correcciones con observaciones.
5. **Corrección y Subsanación**: Vista de observaciones para el emisor y reenvío del documento corregido.
6. **Trazabilidad y Notificaciones**: Historial inmutable de eventos por solicitud y bandeja de notificaciones contextuales para los participantes del flujo.

---

## 2. Historias de Usuario y Criterios de Aceptación Oficiales

A continuación se detallan las 12 historias de usuario presentes en el Sprint Backlog de Trello, con sus checklists oficiales de criterios de aceptación y el mapeo a casos de prueba E2E:

---

### Historia 1: Iniciar Sesión (`HU-01` / `auth-001`)
- **Card Trello**: `6aa4187b9959dcd3d1091b3a` | [Ver en Trello](https://trello.com/c/h0zT3Lw5/1-iniciar-sesion)
- **Descripción**: "Como usuario del sistema, quiero iniciar sesión con mi correo y contraseña para acceder a las funcionalidades según mi rol asignado."
- **Criterios de Aceptación (Trello Checklist `criterios`)**:
  - [x] **CA 1.1**: Nombre de usuario solo en formato correos.
  - [x] **CA 1.2**: Si credenciales son inválidas, mostrar un mensaje: *"credenciales invalidas, intentelo denuevo"*.
  - [x] **CA 1.3**: Si falló el inicio 4 veces seguidas, se bloquea el nombre de usuario por 30 minutos.
  - [x] **CA 1.4**: Al ingresar correctamente, el usuario debe acceder a la vista principal con su usuario.
  - [x] **CA 1.5**: No es posible acceder a la vista principal sin haber hecho login.
  - [x] **CA 1.6**: El sistema debe guardar logs del inicio de sesión.
- **Mapeo de Pruebas**:
  - `E2E-AUTH-01` (`login-flow.spec.ts`): Verifica redirección OIDC, validación de correo, credenciales inválidas, bloqueo visual temporal y redirección al Dashboard.
  - Test de integración backend + Keycloak Brute Force Provider.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 2: Cerrar Sesión (`HU-02` / `auth-002`)
- **Card Trello**: `6aa4189df94c3bb8561c5096` | [Ver en Trello](https://trello.com/c/52Lvh86d/2-cerrar-sesion)
- **Descripción**: "Como usuario autenticado, quiero cerrar mi sesión de manera segura para impedir accesos no autorizados a mi cuenta."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 2.1**: Al seleccionar “Cerrar Sesion”, el sistema debe finalizar la sesión activa.
  - [x] **CA 2.2**: El usuario debe ser redirigido a la pantalla de inicio de sesión.
  - [x] **CA 2.3**: Una vez cerrada la sesión, no se debe permitir acceder nuevamente a las funcionalidades del sistema sin iniciar sesión.
  - [x] **CA 2.4**: El sistema debe registrar logs del cierre de sesión.
- **Mapeo de Pruebas**:
  - `E2E-AUTH-01` (Tests 4 y 5 en `login-flow.spec.ts`): Clic en "Cerrar sesión" en Header -> Invalida sesión OIDC -> Redirección a `/login` -> Intento de navegar a `/dashboard` o `/configurar-org-usuarios` es bloqueado y redirige a login -> Validación de todas las URLs del sistema sin sesión ni errores -> Evento `LOGOUT` registrado en tabla PostgreSQL `audit_events`.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 3: Gestionar Usuarios (`HU-03` / `auth-003`)
- **Card Trello**: `6aa4190496e29ad13cb4976f` | [Ver en Trello](https://trello.com/c/N2Jt18GZ/3-gestionar-usuarios)
- **Descripción**: "Como Administrador, quiero crear, actualizar y desactivar cuentas de usuario asignando roles para controlar el acceso al sistema."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 3.1**: Se debe poder agregar un usuario usando un correo válido y una contraseña.
  - [ ] **CA 3.2**: Se debe poder cambiar la información de un usuario: nombre, apellido.
  - [ ] **CA 3.3**: Se debe poder desactivar un usuario sin borrar su historial.
  - [x] **CA 3.4**: No se deben permitir dos usuarios con el mismo correo.
  - [x] **CA 3.5**: Solo los administradores deben poder gestionar usuarios.
  - [ ] **CA 3.6**: Toda acción de gestión de usuario debe quedar registrada en un log.
- **Mapeo de Pruebas**:
  - `E2E-USER-01`: Creación de usuario por ADMIN, intento de duplicado (error 409/validación), edición de datos, toggle de desactivación, validación de acceso 403 para usuarios con rol `APPROVER` y verificación de logs en tabla de auditoría.
- **Estado Técnico**: **EN PROGRESO / IN_PROGRESS** (Backend provisiona y sincroniza usuarios Keycloak/Postgres con RBAC; faltan endpoints/vistas de edición, desactivación lógica y logging específico).

---

### Historia 4: Registrar Documento sin Planilla (Emisor) (`HU-04` / `doc-001`)
- **Card Trello**: `6aa418a858e233dd4995c8b1` | [Ver en Trello](https://trello.com/c/2Y3t19D1/4-registrar-documento-sin-planilla-emisor)
- **Descripción**: "Como Emisor, quiero registrar un nuevo documento adjuntando un archivo (.doc, .docx, .pdf, .xml, .txt, .xlsx, .xls) e ingresando los datos requeridos para iniciar el flujo de aprobación."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 4.1**: Se deben poder adjuntar documentos en formato .doc, .docx, .pdf, .xml, .txt, .xlsx y .xls.
  - [x] **CA 4.2**: Antes de enviar, los datos obligatorios deben estar completos.
  - [x] **CA 4.3**: Después de registrarlo, el documento debe aparecer entre las solicitudes del emisor con estado "pendiente de revision".
  - [x] **CA 4.4**: El emisor debe poder ver el estado actual del documento.
  - [x] **CA 4.5**: Al registrarlo correctamente, se debe mostrar una confirmación.
- **Mapeo de Pruebas**:
  - `E2E-DOC-01` (`simple-request-flow.spec.ts` - Test 1): Formulario de emisión documental -> validación de campos requeridos vacíos -> validación de formato -> subida exitosa de archivo -> confirmación visual -> visualización en "Mis Solicitudes" en estado "pendiente de revision".
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 5: Ver Revisiones Pendientes (Revisor) (`HU-05` / `flow-001`)
- **Card Trello**: `6aa418ba694db4e43a86d6a5` | [Ver en Trello](https://trello.com/c/7Wz18XvY/5-ver-revisiones-pendiente-revisor)
- **Descripción**: "Como Revisor, quiero consultar la lista de documentos que requieren mi revisión para priorizar y gestionar las solicitudes asignadas."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 5.1**: El Revisor debe poder visualizar una lista de documentos pendientes de revisión.
  - [x] **CA 5.2**: Cada documento debe mostrar información relevante: nombre documento, emisor, fecha y estado.
  - [x] **CA 5.3**: El Revisor debe poder seleccionar un documento para revisar su contenido.
  - [x] **CA 5.4**: Solo deben mostrarse como pendientes los documentos que requieren una revisión humana.
  - [x] **CA 5.5**: El sistema debe permitir aprobar, rechazar o solicitar correcciones sobre el documento.
  - [x] **CA 5.6**: Una vez realizada la revisión, el documento debe actualizar su estado y dejar registro de la acción realizada.
- **Mapeo de Pruebas**:
  - `E2E-REV-01` (`simple-request-flow.spec.ts` - Test 2): Bandeja de revisión -> lista de documentos pendientes con columnas requeridas -> selección de fila con modal centrado de detalle y descarga intermediada -> presencia de botones de acción rápida ("Aprobar", "Rechazar", "Pedir Corrección").
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 6: Aprobar Documento (Revisor) (`HU-06` / `flow-002`)
- **Card Trello**: `6aa418c39f263d782561a9a6` | [Ver en Trello](https://trello.com/c/6t9x0ZqA/6-aprobar-documento-revisor)
- **Descripción**: "Como Revisor asignado, quiero aprobar un documento conforme para dar por finalizado el flujo o pasarlo a la siguiente etapa."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 6.1**: Solo el revisor asignado debe poder aprobar la solicitud.
  - [x] **CA 6.2**: Antes de aprobar, se debe pedir una confirmación en pantalla.
  - [x] **CA 6.3**: Al aprobar, la solicitud debe avanzar al siguiente estado correspondiente según la definición del flujo.
  - [x] **CA 6.4**: La aprobación debe quedar registrada con la fecha y el usuario que la realizó.
  - [x] **CA 6.5**: Todos los usuarios relacionados al flujo deben recibir una notificación del cambio, ya sea para continuar con el flujo de revisiones o notificación de que el flujo terminó.
- **Mapeo de Pruebas**:
  - `E2E-REV-02` (`simple-request-flow.spec.ts` - Test 4): Click en "Aprobar" -> Modal de confirmación -> Confirmar aprobación -> Cambio de estado a `APROBADO` -> Verificación de auditoría e in-app notification.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 7: Rechazar Documento (Revisor) (`HU-07` / `flow-003`)
- **Card Trello**: `6aa418cd34fb9f96fb36a9b1` | [Ver en Trello](https://trello.com/c/1b12wK34/7-rechazar-documento-revisor)
- **Descripción**: "Como Revisor asignado, quiero rechazar una solicitud no viable indicando el motivo para cerrar el flujo de manera fundamentada."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 7.1**: Solo el revisor asignado debe poder rechazar la solicitud.
  - [x] **CA 7.2**: Es obligatorio escribir el motivo del rechazo.
  - [x] **CA 7.3**: Antes de confirmar el rechazo, se debe pedir una confirmación en pantalla.
  - [x] **CA 7.4**: La solicitud debe quedar marcada como rechazada en el historial de flujos.
  - [x] **CA 7.5**: El emisor debe recibir una notificación con el motivo.
- **Mapeo de Pruebas**:
  - `E2E-REV-03` (`simple-request-flow.spec.ts` - Test 5): Click en "Rechazar" -> Modal solicitando motivo -> Intento de enviar vacío bloqueado -> Ingreso de motivo justificado -> Confirmación -> Estado pasa a `RECHAZADO` en historial -> Notificación entregada al emisor con el motivo.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 8: Solicitar Corrección a Documento (Revisor) (`HU-08` / `flow-004`)
- **Card Trello**: `6aa418d5f913f6ebc94b2101` | [Ver en Trello](https://trello.com/c/m9pQ5bW7/8-solicitar-correccion-a-documento-revisor)
- **Descripción**: "Como Revisor, quiero solicitar ajustes al emisor con observaciones puntuales para que corrija la solicitud sin reiniciarla desde cero."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 8.1**: Solo el revisor asignado debe poder pedir correcciones al emisor correspondiente.
  - [x] **CA 8.2**: Es obligatorio escribir la observación.
  - [x] **CA 8.3**: Las observaciones deben quedar visibles para el emisor.
  - [x] **CA 8.4**: La solicitud debe quedar marcada como pendiente de corrección.
  - [x] **CA 8.5**: El emisor debe recibir una notificación.
- **Mapeo de Pruebas**:
  - `E2E-REV-04` (`simple-request-flow.spec.ts` - Test 2): Click en "Pedir Corrección" -> Validación de campo de observaciones requerido -> Envío de observaciones -> Estado cambia a `CORRECCION_REQUERIDA` -> Notificación enviada al emisor.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 9: Ver Observaciones del Revisor (Emisor) (`HU-09` / `flow-005`)
- **Card Trello**: `6aa418ec62a2617a42e2263f` | [Ver en Trello](https://trello.com/c/3c8nJp20/9-ver-observaciones-del-revisor-emisor)
- **Descripción**: "Como Emisor, quiero consultar las observaciones hechas por el revisor para saber con exactitud qué corregir en mi documento."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 9.1**: Las observaciones deben mostrarse dentro de la solicitud correspondiente.
  - [x] **CA 9.2**: El emisor debe poder identificar qué información o documento debe corregir.
  - [x] **CA 9.3**: Las observaciones deben quedar disponibles mientras la solicitud esté pendiente de corrección.
  - [x] **CA 9.4**: El emisor debe poder revisar las observaciones antes de modificar la solicitud.
  - [x] **CA 9.5**: Solo las personas con acceso a la solicitud deben poder ver las observaciones.
- **Mapeo de Pruebas**:
  - `E2E-CORR-01` (`simple-request-flow.spec.ts` - Test 3): Emisor ingresa a la solicitud en estado `CORRECCION_REQUERIDA` -> Panel de observaciones visible y legible -> Restricción de acceso para usuarios no autorizados -> Persistencia de las observaciones durante la edición.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 10: Corregir Documento (Emisor) (`HU-10` / `flow-006`)
- **Card Trello**: `6aa418dc0b2fea160c7b581d` | [Ver en Trello](https://trello.com/c/0N8bQ21K/10-corregir-documento-emisor)
- **Descripción**: "Como Emisor, quiero editar los datos y reemplazar los archivos observados para enviar nuevamente el documento a revisión."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 10.1**: El emisor debe poder ver las observaciones del revisor.
  - [x] **CA 10.2**: Solo se deben poder corregir solicitudes que estén pendientes de corrección.
  - [x] **CA 10.3**: El emisor debe poder cambiar la información o archivos necesarios.
  - [x] **CA 10.4**: Antes de volver a enviar, los datos obligatorios deben estar completos.
  - [x] **CA 10.5**: Al reenviar, la solicitud debe volver al estado de "pendiente de revisión".
  - [x] **CA 10.6**: El revisor debe recibir una notificación con el nuevo estado de la solicitud para volver a revisar.
- **Mapeo de Pruebas**:
  - `E2E-CORR-02` (`simple-request-flow.spec.ts` - Test 3): Emisor modifica formulario / sustituye documento adjunto -> validación de obligatoriedad -> clic en "Reenviar a Revisión" -> solicitud transiciona a `PENDIENTE_REVISION` -> revisor recibe notificación en su bandeja.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 11: Consultar Historial de Flujos (`HU-11` / `flow-007`)
- **Card Trello**: `6aa41943332caba2d6f9b720` | [Ver en Trello](https://trello.com/c/5Xj1038G/11-consultar-historial-de-flujos)
- **Descripción**: "Como usuario involucrado, quiero visualizar la línea de tiempo completa de una solicitud para auditar las acciones realizadas."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 11.1**: El historial debe mostrar los nuevos flujos en orden según fecha.
  - [x] **CA 11.2**: Cada acción en el flujo (aprobar, rechazar, agregar observaciones) debe indicar qué ocurrió, quién lo realizó y cuándo.
  - [x] **CA 11.3**: Solo las personas con acceso a la solicitud deben poder ver su historial.
  - [x] **CA 11.4**: La información del historial no debe poder modificarse.
- **Mapeo de Pruebas**:
  - `E2E-HIST-01` (`simple-request-flow.spec.ts` - Test 7): Vista de detalle de solicitud -> Sección "Línea de Tiempo y Detalle" -> Verificar orden cronológico -> Verificar tarjetas de evento con autor, fecha/hora y acción -> Comprobar inmutabilidad visual.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

### Historia 12: Revisar Notificaciones en Bandeja de Entrada (`HU-12` / `notif-001`)
- **Card Trello**: `6aa419297e3e599b08da3f75` | [Ver en Trello](https://trello.com/c/4mZq9X2k/12-revisar-notificaciones-en-bandeja-de-entrada)
- **Descripción**: "Como usuario del sistema, quiero recibir notificaciones dentro de la plataforma para enterarme de los avances y acciones requeridas en mis solicitudes."
- **Criterios de Aceptación (Trello Checklist `criterios aceptacion`)**:
  - [x] **CA 12.1**: El usuario debe ver solo sus propias notificaciones.
  - [x] **CA 12.2**: Cada notificación debe indicar qué ocurrió y a qué solicitud corresponde.
  - [x] **CA 12.3**: Se debe distinguir entre notificaciones leídas y no leídas.
  - [x] **CA 12.4**: Al seleccionar una notificación, se debe poder ir a la solicitud relacionada.
  - [x] **CA 12.5**: Las notificaciones deben aparecer solo cuando exista un cambio importante en una solicitud (acción requerida o flujo terminado).
- **Mapeo de Pruebas**:
  - `E2E-NOTIF-01` (`simple-request-flow.spec.ts` - Test 6): Icono de campana con contador no leído en topbar -> Apertura de bandeja -> Lista de notificaciones in-app -> Diferenciación visual de leídas/no leídas -> Acción de marcar todas leídas.
- **Estado Técnico**: **COMPLETADO / PASSING**

---

## 3. Matriz de Cobertura E2E (1 Test cubre Múltiples Criterios)

Para optimizar el tiempo de ejecución y simular flujos de usuario completos, los criterios de aceptación se consolidan en 8 Suites de Pruebas E2E:

| ID Suite E2E | Nombre del Flujo de Prueba | Historias Cubiertas | Criterios de Aceptación Verificados | Estado de Implementación |
| :--- | :--- | :--- | :--- | :--- |
| **`E2E-AUTH-01`** | Ciclo de Autenticación, Brute Force y RBAC | HU-01, HU-02 | CA 1.1, CA 1.2, CA 1.3, CA 1.4, CA 1.5, CA 2.3 | **Implementado** (`login-flow.spec.ts`) |
| **`E2E-AUTH-02`** | Cierre de Sesión Seguro y Auditoría | HU-01, HU-02 | CA 1.6, CA 2.1, CA 2.2, CA 2.4 | **Implementado** (`login-flow.spec.ts`) |
| **`E2E-USER-01`** | Administración de Usuarios y Restricción RBAC | HU-03 | CA 3.1, CA 3.2, CA 3.3, CA 3.4, CA 3.5, CA 3.6 | **Implementado** (`user-management.spec.ts`) |
| **`E2E-DOC-01`** | Emisión Documental y Validación de Archivos | HU-04 | CA 4.1, CA 4.2, CA 4.3, CA 4.4, CA 4.5 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-REV-01`** | Bandeja del Revisor y Navegación de Documentos | HU-05 | CA 5.1, CA 5.2, CA 5.3, CA 5.4 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-REV-02`** | Flujo de Aprobación y Finalización | HU-05, HU-06 | CA 5.5, CA 5.6, CA 6.1, CA 6.2, CA 6.3, CA 6.4, CA 6.5 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-REV-03`** | Flujo de Rechazo con Motivo Obligatorio | HU-05, HU-07 | CA 5.5, CA 5.6, CA 7.1, CA 7.2, CA 7.3, CA 7.4, CA 7.5 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-CORR-01`** | Ciclo de Corrección, Observaciones y Reenvío | HU-08, HU-09, HU-10 | CA 8.1 - 8.5, CA 9.1 - 9.5, CA 10.1 - 10.6 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-HIST-01`** | Trazabilidad e Inmutabilidad del Historial | HU-11 | CA 11.1, CA 11.2, CA 11.3, CA 11.4 | **Implementado** (`simple-request-flow.spec.ts`) |
| **`E2E-NOTIF-01`**| Bandeja de Notificaciones Contextuales | HU-12 | CA 12.1, CA 12.2, CA 12.3, CA 12.4, CA 12.5 | **Implementado** (`simple-request-flow.spec.ts`) |

---

## 4. Protocolo de Verificación y Criterio de Aceptación (DoD)

Para considerar una Historia de Usuario o Feature como **TERMINADA (`passing`)**:
1. **Implementación de Código Completa**: Backend (REST/JPA/Security/RabbitMQ) y Frontend (React).
2. **Suite E2E Automatizada**: Debe existir un script de prueba con Playwright que cubra los criterios de la historia.
3. **Prueba Visual Conjunta con el Desarrollador**:
   - El agente ejecuta la prueba con navegador visible o genera reporte con capturas/trazas.
   - El desarrollador valida visualmente el flujo en vivo y confirma su correcto funcionamiento.
   - Solo tras la aprobación visual del desarrollador, se marca la historia como terminada en Trello y `feature_list.json`.
