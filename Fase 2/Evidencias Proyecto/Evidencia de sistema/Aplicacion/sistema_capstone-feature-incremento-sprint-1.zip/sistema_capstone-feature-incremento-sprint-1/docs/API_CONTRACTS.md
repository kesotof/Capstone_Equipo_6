# Contratos de API REST (API Contracts) - Sistema Principal Capstone

Este documento es la **referencia directa e inmutable de los contratos REST** del backend (`sistema-principal`, puerto `8081`) para el desarrollo de vistas, servicios y componentes en el frontend.

---

## 1. Convenciones Generales

- **Base URL**: `http://localhost:8081` (o proxy `/api/*` configurado en frontend).
- **Autenticación**: Cabecera HTTP `Authorization: Bearer <access_token>` (JWT emitido por Keycloak, realm `capstone-realm`, client `capstone-client`).
- **Formato de Error Global (RFC 7807 ProblemDetail)**:
  ```json
  {
    "type": "https://capstone.local/errors/<codigo-error>",
    "title": "Descripción corta del error",
    "status": 400,
    "detail": "Explicación detallada del error",
    "timestamp": "2026-09-15T17:00:00Z"
  }
  ```
- **Roles del Sistema**:
  - `ADMIN`: Administrador con control total sobre usuarios, auditoría y flujos.
  - `APPROVER` (en UI mostrado como *"Emisor y Revisor"*): Usuario operativo estándar. Puede emitir y revisar documentos.

---

## 2. Módulo de Solicitudes y Flujo Documental (`/api/solicitudes`)

### 2.1 Registrar Solicitud con Documento Inicial
Crea una solicitud documental en estado `PENDIENTE_REVISION`, sube el archivo a MinIO S3 y genera el documento en versión 1.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes`
- **Seguridad**: Autenticado (`ADMIN` o `APPROVER`)
- **Content-Type**: `multipart/form-data`
- **Parámetros Form-Data**:
  - `titulo` (String, obligatorio): Título del documento.
  - `descripcion` (String, opcional): Resumen o contexto de la solicitud.
  - `file` (File, obligatorio): Archivo adjunto (`.pdf`, `.docx`, `.doc`, `.xml`, `.txt`, `.xlsx`, `.xls`). Máximo: 10 MB.
  - `notificarEmail` (Boolean, opcional, por defecto `false`): Si es `true`, publica el evento a RabbitMQ para despacho de correo vía Resend.
- **Respuesta (201 Created)**:
  ```json
  {
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "656ba77b-2231-4b17-9007-01de7e007d53",
    "estado": "PENDIENTE_REVISION",
    "mensaje": "Documento registrado correctamente y solicitud enviada a revisión"
  }
  ```
- **Errores**:
  - `400 Bad Request`: Formato no permitido (`.exe`, etc.) o archivo > 10MB o título vacío.
  - `401 Unauthorized`: Token no provisto o inválido.

---

### 2.2 Listar Mis Solicitudes (Bandeja del Emisor)
Devuelve las solicitudes emitidas por el usuario logueado en orden cronológico descendente.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/mis-solicitudes`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
      "titulo": "Contrato de Proveedor Q3",
      "descripcion": "Contrato para adquisicion de equipos",
      "estado": "PENDIENTE_REVISION",
      "emisorId": "3194f022-344b-473c-baee-85cc2d6155c7",
      "emisorNombre": "Admin Capstone",
      "emisorEmail": "admin@capstone.local",
      "documentoVigente": {
        "id": "656ba77b-2231-4b17-9007-01de7e007d53",
        "nombreArchivo": "contrato.pdf",
        "contentType": "application/pdf",
        "sizeBytes": 1048576,
        "version": 1,
        "vigente": true,
        "createdAt": "2026-09-15T17:12:24.613Z"
      },
      "createdAt": "2026-09-15T17:12:24.160Z",
      "updatedAt": "2026-09-15T17:12:24.160Z"
    }
  ]
  ```

---

### 2.3 Listar Revisiones Pendientes (Bandeja del Revisor)
Devuelve solicitudes en estado `PENDIENTE_REVISION`. Durante el flujo simplificado del Sprint 1 no existe asignación de revisores: cualquier usuario autenticado puede ver las solicitudes pendientes, incluidas las propias.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/pendientes-revision`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: Mismo schema de lista que en 2.2.

---

### 2.4 Resumen del Dashboard y Acciones Pendientes
Devuelve de manera agregada y atómica las acciones que el usuario autenticado tiene pendientes por realizar (revisiones requeridas o correcciones observadas pendientes de subsanación) junto con la lista de solicitudes emitidas por el usuario que se encuentran en trámite.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/dashboard`
- **Seguridad**: Autenticado (`ADMIN` o `APPROVER`)
- **Respuesta (200 OK)**:
  ```json
  {
    "accionesPendientes": [
      {
        "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Contrato de Arrendamiento Q3",
        "tipoAccion": "REVISION",
        "descripcionAccion": "Requiere tu revisión y decisión",
        "estadoActual": "PENDIENTE_REVISION",
        "emisorNombre": "Juan Pérez",
        "emisorEmail": "jperez@capstone.local",
        "nombreArchivo": "contrato.pdf",
        "version": 1,
        "fecha": "2026-09-15T17:12:24.160Z",
        "ultimaObservacion": null
      },
      {
        "solicitudId": "b123ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Informe Financiero Anual",
        "tipoAccion": "CORRECCION",
        "descripcionAccion": "Requiere subsanación de observaciones",
        "estadoActual": "CORRECCION_REQUERIDA",
        "emisorNombre": "Admin Capstone",
        "emisorEmail": "admin@capstone.local",
        "nombreArchivo": "informe.xlsx",
        "version": 1,
        "fecha": "2026-09-15T18:00:00.000Z",
        "ultimaObservacion": "Falta adjuntar el balance auditado en la hoja 2."
      }
    ],
    "misSolicitudesPendientes": [
      {
        "id": "b123ee1c-fe5a-4293-9eb2-31f2cad77ae9",
        "titulo": "Informe Financiero Anual",
        "descripcion": "Balance anual",
        "estado": "CORRECCION_REQUERIDA",
        "emisorId": "3194f022-344b-473c-baee-85cc2d6155c7",
        "emisorNombre": "Admin Capstone",
        "emisorEmail": "admin@capstone.local",
        "documentoVigente": {
          "id": "656ba77b-2231-4b17-9007-01de7e007d53",
          "nombreArchivo": "informe.xlsx",
          "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "sizeBytes": 524288,
          "version": 1,
          "vigente": true,
          "createdAt": "2026-09-15T17:12:24.613Z"
        },
        "createdAt": "2026-09-15T17:12:24.160Z",
        "updatedAt": "2026-09-15T18:00:00.000Z"
      }
    ]
  }
  ```

---

### 2.5 Obtener Detalle de una Solicitud
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` único (mismo schema individual de 2.2).
- **Errores**: `404 Not Found` si el UUID no existe.

---

### 2.6 Aprobar Solicitud
Transiciona la solicitud de `PENDIENTE_REVISION` a `APROBADO`. Emite notificación y auditoría.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/aprobar`
- **Seguridad**: Autenticado. Revisor ≠ Emisor (excepto si el revisor tiene rol `ADMIN`).
- **Query Params / JSON Body**:
  - `notificarEmail` (Boolean, opcional, por defecto `false`): Si se activa, notifica por correo al emisor.
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` actualizado con `estado: "APROBADO"`.
- **Errores**:
  - `403 Forbidden`: Si el emisor intenta auto-aprobar y no es Admin.
  - `409 Conflict`: Si el estado actual no es `PENDIENTE_REVISION`.

---

### 2.7 Rechazar Solicitud
Transiciona de `PENDIENTE_REVISION` a `RECHAZADO`. Requiere motivo obligatorio, registra la transición y la auditoría, y notifica al emisor. En el flujo simplificado del Sprint 1 cualquier usuario autenticado que esté revisando puede rechazar, incluso si es el emisor.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/rechazar`
- **Seguridad**: Autenticado. Sin restricción de rol o separación entre emisor y revisor durante el Sprint 1.
- **Content-Type**: `application/json` (o query params)
- **Request Body**:
  ```json
  {
    "motivo": "El presupuesto sobrepasa el límite autorizado para el área.",
    "notificarEmail": true
  }
  ```
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` actualizado con `estado: "RECHAZADO"`.
- **Errores**:
  - `400 Bad Request`: Si `motivo` viene vacío.
  - `409 Conflict`: Si la solicitud no está en `PENDIENTE_REVISION`.
- **Notificaciones**: La notificación interna siempre se persiste. Con `notificarEmail: true`, además se publica el evento RabbitMQ para informar al emisor por correo.

---

### 2.8 Solicitar Corrección a Solicitud
Transiciona a `CORRECCION_REQUERIDA` y crea una observación activa visible para el emisor.

- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/pedir-correccion`
- **Seguridad**: Autenticado. Revisor ≠ Emisor (o Admin).
- **Content-Type**: `application/json` (o query params)
- **Request Body**:
  ```json
  {
    "observacion": "Falta adjuntar la firma del responsable técnico en la última página.",
    "notificarEmail": false
  }
  ```
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` con `estado: "CORRECCION_REQUERIDA"`.
- **Errores**:
  - `400 Bad Request`: Si `observacion` viene vacía.
  - `403 Forbidden`: Si emisor intenta auto-observarse (no Admin).
  - `409 Conflict`: Si estado actual no es `PENDIENTE_REVISION`.

---

### 2.9 Reenviar Solicitud Subsanada
Permite al emisor actualizar título/descripción y opcionalmente adjuntar un nuevo archivo. Marca el archivo anterior como `vigente = false`, genera una nueva versión (`version = previous + 1`), resuelve observaciones pendientes y retorna a `PENDIENTE_REVISION`. La actualización de base de datos es transaccional; si falla después de subir un reemplazo, el archivo nuevo se elimina de MinIO como compensación para evitar datos huérfanos.

- **Método**: `PUT`
- **Ruta**: `/api/solicitudes/{id}/reenviar`
- **Seguridad**: Autenticado. Solo el emisor original (o `ADMIN`).
- **Content-Type**: `multipart/form-data`
- **Parámetros Form-Data**:
  - `titulo` (String, opcional): Nuevo título corregido.
  - `descripcion` (String, opcional): Nueva descripción explicativa.
  - `file` (File, opcional): Nuevo archivo sustituto.
  - `notificarEmail` (Boolean, opcional, por defecto `false`): Si se activa, notifica a los revisores.
- **Respuesta (200 OK)**: Objeto `SolicitudResponse` actualizado con `estado: "PENDIENTE_REVISION"`.
- **Errores**:
  - `400 Bad Request`: Si se envía `titulo` vacío o el archivo no cumple formato/tamaño.
  - `403 Forbidden`: Si un usuario distinto al emisor intenta reenviar.
  - `409 Conflict`: Si la solicitud no está en `CORRECCION_REQUERIDA`.

---

### 2.10 Consultar Historial de Transiciones (Línea de Tiempo)
Devuelve todas las transiciones ordenadas cronológicamente (`createdAt` ascendente). Es inmutable.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/historial`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "estadoOrigen": "INICIAL",
      "estadoDestino": "PENDIENTE_REVISION",
      "accion": "CREAR",
      "usuarioEmail": "emisor@capstone.local",
      "usuarioNombre": "Juan Emisor",
      "comentario": "Registro inicial de solicitud y carga de documento",
      "createdAt": "2026-09-15T17:12:24.615Z"
    },
    {
      "id": 2,
      "estadoOrigen": "PENDIENTE_REVISION",
      "estadoDestino": "APROBADO",
      "accion": "APROBAR",
      "usuarioEmail": "revisor@capstone.local",
      "usuarioNombre": "Ana Revisora",
      "comentario": "Solicitud aprobada por Ana Revisora",
      "createdAt": "2026-09-15T17:15:00.000Z"
    }
  ]
  ```

---

### 2.11 Consultar Observaciones de la Solicitud
Devuelve las notas u observaciones formuladas por los revisores en orden cronológico, con autor, fecha y estado de subsanación.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/observaciones`
- **Seguridad**: Autenticado; solo el emisor de la solicitud o un administrador puede consultar estas observaciones.
- **Error**: `403 Forbidden` si otro usuario intenta consultar las observaciones.
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 1,
      "contenido": "Falta firma en página 3",
      "resuelta": false,
      "usuarioEmail": "revisor@capstone.local",
      "usuarioNombre": "Ana Revisora",
      "createdAt": "2026-09-15T17:13:15.104Z"
    }
  ]
  ```

---

### 2.12 Descargar Documento Vigente
Descarga intermediada por el backend Spring Boot (`sistema-principal`) desde el bucket privado de MinIO S3 hacia el cliente. No se permite descarga directa de usuarios al bucket S3 para asegurar el control estricto de autorización mediante token JWT.

- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/documento/descargar`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Respuesta (200 OK)**:
  - Header: `Content-Disposition: attachment; filename="<nombre_archivo>"`
  - Content-Type: el tipo MIME almacenado para el archivo, por ejemplo `application/pdf`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, `application/vnd.ms-excel`, `application/xml` o `text/plain`.
  - Body: Binario del archivo transmitido en streaming desde el backend.

---

### 2.13 Intermediario de Archivos en MinIO Storage (`/api/doc`)

Endpoints utilitarios para carga y descarga intermediada bajo control de seguridad con JWT (el bucket MinIO tiene acceso público denegado / política privada `none`):
- `POST /api/doc/upload`: Requiere `Authorization: Bearer <JWT>`. Sube archivo a MinIO retornando la clave interna del objeto.
- `GET /api/doc/download/{filename}`: Requiere `Authorization: Bearer <JWT>`. Transmite el binario desde MinIO en streaming hacia el cliente. Denegado a usuarios anónimos (`401 Unauthorized`).

### 3.1 Listar Mis Notificaciones
- **Método**: `GET`
- **Ruta**: `/api/notificaciones`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 5,
      "titulo": "Solicitud Aprobada",
      "mensaje": "Tu solicitud 'Contrato Q3' ha sido aprobada por Admin Capstone.",
      "tipo": "APROBACION",
      "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
      "leida": false,
      "createdEn": "2026-09-15T17:12:25.006Z",
      "leidaEn": null
    }
  ]
  ```

---

### 3.2 Conteo de Notificaciones No Leídas
Ideal para badges o indicadores numéricos en la campana de la barra superior.

- **Método**: `GET`
- **Ruta**: `/api/notificaciones/no-leidas/count`
- **Seguridad**: Autenticado
- **Respuesta (200 OK)**:
  ```json
  {
    "count": 3
  }
  ```

---

### 3.3 Marcar Notificación como Leída
- **Método**: `PATCH`
- **Ruta**: `/api/notificaciones/{id}/leer`
- **Seguridad**: Autenticado (solo el destinatario)
- **Respuesta (200 OK)**: Notificación actualizada con `leida: true` y `leidaEn: "<timestamp>"`.
- **Errores**: `403 Forbidden` si la notificación pertenece a otro usuario.

---

## 4. Módulo de Administración de Usuarios (`/api/users`)

- **Seguridad**: Exclusivo para administradores (`ROLE_ADMIN`).

### 4.1 Listar Usuarios
- **Método**: `GET`
- **Ruta**: `/api/users`
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": "3194f022-344b-473c-baee-85cc2d6155c7",
      "email": "admin@capstone.local",
      "firstName": "Admin",
      "lastName": "Capstone",
      "roles": ["ADMIN"],
      "enabled": true,
      "temporarilyLocked": false,
      "createdAt": "2026-09-14T00:00:00Z",
      "updatedAt": "2026-09-14T00:00:00Z"
    }
  ]
  ```

### 4.2 Crear Usuario
- **Método**: `POST`
- **Ruta**: `/api/users`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "email": "nuevo@capstone.local",
    "firstName": "Pedro",
    "lastName": "Pascal",
    "password": "Password123!",
    "roles": ["APPROVER"]
  }
  ```
- **Respuesta (201 Created)**: `UserResponse`.

### 4.3 Actualizar Usuario / Restablecer Contraseña
- **Método**: `PUT`
- **Ruta**: `/api/users/{id}`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "firstName": "Pedro",
    "lastName": "Pascal Modificado",
    "roles": ["APPROVER"],
    "newPassword": "NuevaPassword123!",
    "requirePasswordChange": true
  }
  ```
- **Respuesta (200 OK)**: `UserResponse`.

### 4.4 Activar / Desactivar Estado
- **Método**: `PATCH`
- **Ruta**: `/api/users/{id}/status`
- **Request Body**: `{"enabled": false}`
- **Respuesta (200 OK)**: `UserResponse`.

### 4.5 Eliminar Usuario
- **Método**: `DELETE`
- **Ruta**: `/api/users/{id}`
- **Respuesta (204 No Content)**.

---

## 5. Módulo de Auditoría (`/api/audit`)

- **Seguridad**: Exclusivo para administradores (`ROLE_ADMIN`).
- **Endpoint**: `GET /api/audit/recent?limit=50`
- **Respuesta (200 OK)**:
  ```json
  [
    {
      "id": 384,
      "email": "admin@capstone.local",
      "tipo": "RECHAZAR_SOLICITUD",
      "ipAddress": "127.0.0.1",
      "detalle": "Rechazo de solicitud 'Factura Mayo 2026'. Motivo: [PROTECTED]",
      "createdAt": "2026-09-15T17:13:15.442Z"
    }
  ]
  ```

---

## 6. Módulo de Análisis Documental con IA (`/api/solicitudes/{id}/ai-analysis`)

Permite a los emisores, revisores y administradores solicitar y consultar auditorías inteligentes sobre el documento vigente de una solicitud mediante OpenRouter LLM y RabbitMQ.

### 6.1 Solicitar Análisis con IA
- **Método**: `POST`
- **Ruta**: `/api/solicitudes/{id}/ai-analysis`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Query Params**:
  - `force` (opcional, boolean, default `false`): Si es `true`, fuerza un nuevo análisis ignorando la caché.
- **Request Body** (opcional, `application/json`):
  ```json
  {
    "prompt": "Verificar que el documento incluya cláusulas de confidencialidad y vigencia de al menos 12 meses."
  }
  ```
- **Comportamiento de Caché Inteligente**:
  - Si ya existe un análisis `COMPLETADO` para el mismo documento y el mismo prompt (y `force=false`), retorna **HTTP 200 OK** con `cached: true`.
  - Si el documento cambió, el prompt cambió, o no existe análisis previo, crea una tarea `PENDIENTE`, la encola en RabbitMQ y retorna **HTTP 202 Accepted** con `cached: false`.
- **Respuesta (200 OK - Caché o ya completado)**:
  ```json
  {
    "id": "e4b1b369-026c-486a-bfe0-55e11d0a5f91",
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "b1234567-89ab-cdef-0123-456789abcdef",
    "estado": "COMPLETADO",
    "puntaje": 88,
    "valido": true,
    "observaciones": "El documento cumple con los estándares generales de formato y coherencia respecto a la solicitud.",
    "recomendaciones": [
      "Validar consistencia de fechas en las cláusulas principales",
      "Confirmar la firma digital de los intervinientes"
    ],
    "modeloUsado": "meta-llama/llama-3.3-70b-instruct:free",
    "promptUtilizado": "Verificar que el documento incluya...",
    "cached": true,
    "createdAt": "2026-09-17T21:00:00Z",
    "completedAt": "2026-09-17T21:00:02Z"
  }
  ```
- **Respuesta (202 Accepted - Encolado en proceso)**:
  ```json
  {
    "id": "e4b1b369-026c-486a-bfe0-55e11d0a5f91",
    "solicitudId": "a863ee1c-fe5a-4293-9eb2-31f2cad77ae9",
    "documentoId": "b1234567-89ab-cdef-0123-456789abcdef",
    "estado": "PENDIENTE",
    "puntaje": null,
    "valido": null,
    "observaciones": null,
    "recomendaciones": [],
    "modeloUsado": null,
    "promptUtilizado": "Verificar que el documento...",
    "cached": false,
    "createdAt": "2026-09-17T21:05:00Z",
    "completedAt": null
  }
  ```

---

### 6.2 Consultar Último Análisis con IA
- **Método**: `GET`
- **Ruta**: `/api/solicitudes/{id}/ai-analysis`
- **Seguridad**: Autenticado (`Authorization: Bearer <JWT>`)
- **Respuesta (200 OK)**: Mismo esquema `AiAnalysisResponse`.
- **Respuesta (404 Not Found)**: Si la solicitud no tiene análisis realizados aún (`RFC 7807 ProblemDetail`).

---

### 6.3 Eventos Asíncronos RabbitMQ (Exchange: `capstone.exchange`)
- **Tópico de Tareas**: `ai.analysis`
  - Payload emitido por `sistema-principal` y consumido por `service-ia` (`ai.queue`):
    `{ analysisId, solicitudId, storageKey, nombreArchivo, contentType, titulo, descripcion, prompt }`
- **Tópico de Resultados**: `ai.results`
  - Payload emitido por `service-ia` y consumido por `sistema-principal` (`ai.results.queue`):
    `{ analysisId, solicitudId, status, resultado, modeloUsado, timestamp }`
