# Índice Maestro de Documentación Oficial Spring Boot (Referencias Verificadas)

> **Directorio Local-First para Agentes y Desarrolladores**  
> Antes de realizar llamadas externas o navegar por la web, consulta primero las referencias consolidadas a continuación.
> Todas las fuentes han sido descargadas y validadas contra los sitios oficiales de Spring (`docs.spring.io`). **No se requiere tener Crawl4AI instalado** para utilizar estas referencias locales ni para investigar en la web (existe fallback nativo con `read_url_content`).

---

## Pilares Fundamentales del Proyecto Capstone

| Pilar / Requisito | Archivo de Referencia Local | URL Oficial de Referencia | Versión de Framework | Descripción Clave |
| :--- | :--- | :--- | :--- | :--- |
| **1. REST APIs** | [`rest-apis-problemdetails.md`](./rest-apis-problemdetails.md) | [Spring Boot Web Servlet Docs](https://docs.spring.io/spring-boot/reference/web/servlet.html) & [Spring MVC Problem Details](https://docs.spring.io/spring-framework/reference/web/webmvc/mvc-controller/ann-rest-exceptions.html) | Spring Boot 3.2+ | Controladores `@RestController`, `ResponseEntity`, DTOs con `record` de Java 21, `@Valid` y RFC 7807 (`ProblemDetail`) con `spring.mvc.problemdetails.enabled=true`. |
| **2. JWT y RBAC Interno** | [`security-oauth2-resource-server.md`](./security-oauth2-resource-server.md) | [Spring Security Resource Server JWT](https://docs.spring.io/spring-security/reference/servlet/oauth2/resource-server/jwt.html) | Spring Security 6.2+ | Resource Server stateless, validación contra Keycloak (`jwk-set-uri`), comprobación de cuenta activa local por `sub`, mapeo de roles y `@PreAuthorize("hasRole('...')")`. |
| **3. RabbitMQ & Eventos** | [`amqp-rabbitmq-json.md`](./amqp-rabbitmq-json.md) | [Spring Boot AMQP Messaging](https://docs.spring.io/spring-boot/reference/messaging/amqp.html) & [Spring AMQP Reference](https://docs.spring.io/spring-amqp/reference/) | Spring AMQP 3.1+ | Comunicación orientada a eventos entre microservicios, serialización/deserialización JSON con `Jackson2JsonMessageConverter`, `RabbitTemplate` y `@RabbitListener`. |
| **4. Realtime WebSockets** | [`websocket-stomp-realtime.md`](./websocket-stomp-realtime.md) | [Spring Framework STOMP WebSockets](https://docs.spring.io/spring-framework/reference/web/websocket/stomp.html) | Spring Framework 6.1+ | Notificaciones en tiempo real al frontend React mediante STOMP over WebSocket con SockJS, `/topic` broadcast, `/queue` individual y `SimpMessagingTemplate`. |

---

## Módulos Complementarios

| Módulo / Integración | Archivo de Referencia Local | URL Oficial de Referencia | Descripción Clave |
| :--- | :--- | :--- | :--- |
| **Almacenamiento MinIO S3** | [`minio-s3-integration.md`](./minio-s3-integration.md) | [MinIO Java SDK](https://min.io/docs/minio/linux/developers/java/minio-java.html) | Cliente inyectable `MinioClient`, subida multipart, presigned URLs para visualización y streams seguros. |
| **Cliente HTTP / APIs Externas** | [`restclient-spring-boot-3.md`](./restclient-spring-boot-3.md) | [Spring Boot RestClient](https://docs.spring.io/spring-boot/reference/io/rest-client.html) | Inyección de `RestClient.Builder` para llamadas a APIs de Gemini (IA) y MasterBase (notificaciones SMTP/SMS). |

---

## Historial de Verificación con Crawl4AI
- **2026-09-11**: Scrapeo y verificación en vivo con Crawl4AI MCP de:
  - `https://docs.spring.io/spring-boot/reference/web/servlet.html` (100% OK)
  - `https://docs.spring.io/spring-security/reference/servlet/oauth2/resource-server/jwt.html` (100% OK)
  - `https://docs.spring.io/spring-boot/reference/messaging/amqp.html` (100% OK)
  - `https://docs.spring.io/spring-framework/reference/web/websocket/stomp.html` (100% OK)
