# AGENTS.md

Este archivo es la **guía operativa y mapa de navegación** para agentes de codificación autónomos que operan en el **Sistema de Gestión Documental y Flujos de Aprobación** (Capstone). Su objetivo es dirigir al agente hacia las fuentes especializadas de contexto, mantener un ciclo de trabajo predecible y asegurar la calidad en cada sesión.

---

## Mapa de Referencias del Proyecto

No explores todos los archivos del repositorio para adquirir contexto. Utiliza este mapa directo:

| Referencia | Propósito | Cuándo consultarlo |
| :--- | :--- | :--- |
| [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) | **Catálogo Arquitectónico y de Código**: Detalle exhaustivo de cada carpeta y archivo, tecnologías, diagramas Mermaid, puertos, credenciales, flujos transaccionales y guía de "dónde tocar según la tarea". | **Al iniciar cualquier tarea de código** o cuando requieras entender componentes, contratos REST, colas RabbitMQ o vistas React. |
| [`feature_list.json`](./feature_list.json) | **Fuente Única de Verdad del Backlog**: Lista priorizada de características (`infra-001` a `front-001`), reglas de negocio, criterios de aceptación, estado y evidencia. | **Al iniciar la sesión** para seleccionar la siguiente característica y **al finalizar** para registrar evidencia y actualizar el estado. |
| [`claude-progress.md`](./claude-progress.md) | **Bitácora de Trabajo Continuo**: Historial de hitos completados, decisiones de diseño tomadas, último estado en caliente verificado y el siguiente paso prioritario. | **Al inicio y fin de cada sesión** para asegurar continuidad sin pérdida de contexto entre agentes. |
| [`docker-compose.yml`](./docker-compose.yml) | **Infraestructura y Orquestación**: Definición declarativa de PostgreSQL 16, Keycloak 24, RabbitMQ 3.13, MinIO S3 y los perfiles de microservicios (`--profile apps`). | Cuando necesites levantar servicios, verificar puertos o revisar dependencias entre contenedores. |
| [`.env.example`](./.env.example) / [`.env`](./.env) | **Diccionario de Variables de Entorno**: Puertos, cadenas JDBC, credenciales de desarrollo y claves de APIs externas (Gemini, MasterBase). | Al configurar o verificar variables requeridas por los microservicios. |
| [`init.ps1`](./init.ps1) / [`init.sh`](./init.sh) | **Scripts Estándar de Inicialización**: Validación automática de variables, herramientas Docker y estructura de carpetas. | Al iniciar sesión para validar el entorno de trabajo. |
| [`spring-boot-best-practices`](./.agents/skills/spring-boot-best-practices/SKILL.md) | **Skill de Buenas Prácticas Spring Boot**: Estándares de desarrollo, inyección limpia, DTOs con records, Spring Security 6, JPA, RabbitMQ y control de errores. | **Antes de implementar o modificar código backend** en cualquiera de los 3 microservicios. |
| [`spring-docs-research`](./.agents/skills/spring-docs-research/SKILL.md) | **Skill de Investigación y Cacheo de Docs**: Flujo Local-First para consultar documentación oficial de Spring Boot, o buscar en la web y persistir lo aprendido en Markdown local. Incluye estrategia dual con fallback estándar nativo (`search_web` / `read_url_content`) si el desarrollador no tiene Crawl4AI instalado. | **Cuando una duda técnica de Spring Boot no esté en el resumen de buenas prácticas**: primero local, si no buscar en web y guardar. |
| [`docs/sprint-backlog/sprint-1.md`](./docs/sprint-backlog/sprint-1.md) | **Sprint 1 Backlog Oficial**: Detalle de las 12 historias de usuario de Trello, checklists de criterios de aceptación y mapeo a suites de prueba E2E. | **Al iniciar el desarrollo de cualquier historia del sprint 1** para conocer criterios exactos y estado. |
| [`docs/API_CONTRACTS.md`](./docs/API_CONTRACTS.md) | **Contratos de API REST Backend**: Catálogo completo de endpoints, métodos, esquemas de petición/respuesta (JSON y multipart), códigos HTTP, reglas de negocio y formato RFC 7807 (`ProblemDetail`). | **Al implementar vistas o servicios frontend**, para consumir las APIs directamente sin revisar el código Java del backend. |
| [`tests/e2e/`](./tests/e2e/) / [`SPRINT_1_E2E_SPECS.md`](./tests/e2e/SPRINT_1_E2E_SPECS.md) | **Suite de Pruebas E2E y Regresión con Playwright**: Contenedor oficial, especificación multicriterio y casos de prueba automatizados ejecutables vía `.\scripts\run-e2e-tests.ps1` (o con flag `-UI`). | **Al finalizar cambios o antes de entregar una característica** para validar visualmente junto al dev y prevenir regresiones. |


---

## Flujo de Inicio de Sesión (Startup Workflow)

Antes de escribir o modificar código, sigue estrictamente esta secuencia:

1. **Confirmar directorio de trabajo**: `Get-Location` o `pwd`.
2. **Consultar el estado del trabajo**: Leer [`claude-progress.md`](./claude-progress.md) para conocer el último estado verificado y el siguiente paso.
3. **Seleccionar característica**: Leer [`feature_list.json`](./feature_list.json) y tomar la característica de mayor prioridad con estado `not_started` o `in_progress`.
4. **Obtener contexto técnico**: Consultar la sección correspondiente en [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md) para identificar los archivos exactos a modificar y los contratos de integración.
5. **Revisar últimos commits**: Ejecutar `git log --oneline -5`.
6. **Ejecutar script de inicialización**:
   - En Windows / PowerShell: `.\init.ps1`
   - En Linux / Bash / WSL: `./init.sh`
7. **Levantar la infraestructura necesaria**:
   - Solo infraestructura base: `docker compose up -d postgres keycloak rabbitmq minio minio-init`
   - Todo el stack (incluyendo aplicaciones): `docker compose --profile apps up -d`
8. **Verificación base previa**: Ejecutar smoke tests o llamadas de salud (`/actuator/health`, HTTP 200 en frontend) antes de iniciar nuevo código. Si el estado base está quebrado, resuélvelo antes de continuar.
9. **Suite de regresión E2E (opcional/preventiva)**: Ejecutar `.\scripts\run-e2e-tests.ps1` (o `./scripts/run-e2e-tests.sh`) para asegurar que el sistema se encuentre libre de regresiones antes de tocar código crítico.


---

## Reglas Operativas

- **Una sola característica a la vez**: Trabajar exclusivamente en la característica seleccionada en el backlog.
- **Implementación de Tests E2E Obligatoria**: Cada vez que se implemente una feature o se complete una historia de usuario, se deben implementar o actualizar sus tests E2E correspondientes con Playwright para verificar sus criterios de aceptación.
- **Validación Visual Conjunta con el Desarrollador**: Los tests E2E deben probarse junto al desarrollador (vía `.\scripts\run-e2e-tests.ps1 -UI` o `--headed`). Si el desarrollador los prueba de forma visual y comprueba el correcto funcionamiento en pantalla, la feature se considera aprobada y terminada.
- **Evidencia verificable**: Una característica solo se marca como `passing` si la verificación se ejecutó efectivamente en vivo, con validación visual confirmada y documentada con resultados concretos.
- **Alcance acotado**: No realizar modificaciones innecesarias fuera de la característica activa.
- **Integridad de verificación**: No relajar ni modificar silenciosamente las reglas de prueba para forzar que pasen.
- **Artefactos durables**: Toda decisión, cambio relevante o hallazgo debe persistirse en los documentos del repositorio (`claude-progress.md`, `feature_list.json`, `PROJECT_STRUCTURE.md`), evitando depender del historial temporal de chat.

---

## Criterio de Finalización (Definition of Done)

Una característica o historia de usuario se considera terminada **únicamente** cuando se cumple todo lo siguiente:
1. El comportamiento objetivo está completamente implementado en backend y frontend.
2. Los tests E2E (Playwright) que cubren sus criterios de aceptación están implementados y pasan en verde.
3. El desarrollador probó visualmente la funcionalidad y confirmó su correcto funcionamiento en pantalla.
4. La evidencia quedó documentada en [`feature_list.json`](./feature_list.json) y/o [`claude-progress.md`](./claude-progress.md).
5. El repositorio permanece operable y levantable mediante la ruta estándar de inicio (`init.ps1` / `init.sh` / `docker compose`).

---

## Cierre de Sesión (Handoff)

Antes de terminar la interacción:
1. Actualizar [`claude-progress.md`](./claude-progress.md) con el trabajo efectuado y el próximo paso claro.
2. Actualizar [`feature_list.json`](./feature_list.json) si cambió el estado de alguna característica.
3. Si se agregaron nuevos componentes, endpoints o archivos, actualizar [`PROJECT_STRUCTURE.md`](./PROJECT_STRUCTURE.md).
4. Registrar riesgos o bloqueos pendientes.
5. Realizar `git commit` con un mensaje descriptivo si el código se encuentra en un estado seguro y compilable.
6. Dejar los servicios en estado estable y limpio.