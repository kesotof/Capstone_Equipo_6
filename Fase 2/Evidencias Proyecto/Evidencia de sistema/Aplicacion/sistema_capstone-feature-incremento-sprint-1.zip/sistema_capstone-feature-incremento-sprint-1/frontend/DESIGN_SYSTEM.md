# Sistema de Diseño Frontend — Masterbase

> Estado: guía base de implementación para Sprint 1.  
> Alcance: React + CSS global existente; no requiere Tailwind ni dependencias nuevas.

## 1. Propósito

Esta guía es la fuente de verdad visual del frontend de Masterbase. Toma como referencia la identidad del prototipo de Figma —morado institucional, navegación lateral, marca y jerarquía—, pero establece una dirección **empresarial inspirada en productos Microsoft**: información legible, baja carga visual, acciones inequívocas, densidad moderada y accesibilidad como requisito.

El prototipo de Figma sirve para extraer la identidad y los patrones, no para copiar cada medida o detalle literalmente. Cuando haya conflicto entre el prototipo y esta guía, prevalece esta guía hasta que se acuerde una versión posterior.

## 2. Principios de diseño

1. **Claridad antes que decoración.** Cada pantalla debe responder: dónde estoy, qué información veo y qué acción puedo realizar.
2. **El contenido es el protagonista.** Las solicitudes, documentos, estados y decisiones se presentan sobre fondos claros; el morado queda reservado para identidad, navegación y énfasis controlado.
3. **Consistencia operacional.** Una misma acción conserva etiqueta, icono, color y ubicación en todas las vistas.
4. **Jerarquía visible.** Los títulos, estados, acciones principales y datos críticos no compiten entre sí.
5. **Accesibilidad por defecto.** El color nunca es la única señal de estado; teclado, foco, contraste y texto alternativo son parte del diseño.
6. **Densidad empresarial equilibrada.** Se evita tanto el espacio vacío excesivo como las tablas apretadas. La información se agrupa en bloques escaneables.

## 3. Fundaciones visuales

### 3.1 Paleta de color

Los valores `Figma` reflejan la identidad detectada en el prototipo. Los valores `UI` son los que deben usarse en componentes operativos porque ofrecen contraste y estados más sostenibles.

| Token | Valor | Uso |
| --- | --- | --- |
| `--color-brand-900` | `#37143A` | Sidebar, encabezados institucionales oscuros, footer de navegación. |
| `--color-brand-800` | `#401449` | Texto sobre selección clara, iconos de identidad. |
| `--color-brand-700` | `#5B1A62` | Botón primario y enlaces de énfasis. |
| `--color-brand-600` | `#702878` | Hover del botón primario. |
| `--color-brand-100` | `#F0E1F0` | Fila de navegación activa, superficies de énfasis suave. |
| `--color-brand-50` | `#F8F0F8` | Fondo ligero de secciones o banners informativos. |
| `--color-accent` | `#A63AA8` | Borde decorativo, indicador o foco de marca; no usar como único color de texto pequeño. |
| `--color-canvas` | `#F7F8FA` | Fondo general de la aplicación. |
| `--color-surface` | `#FFFFFF` | Tarjetas, formularios, paneles y tablas. |
| `--color-surface-subtle` | `#F3F4F6` | Cabeceras de tabla, áreas deshabilitadas y fondos secundarios. |
| `--color-border` | `#D1D5DB` | Separadores y bordes estándar. |
| `--color-border-strong` | `#9CA3AF` | Borde de controles en foco o estados de alta visibilidad. |
| `--color-text` | `#1F2937` | Texto principal. |
| `--color-text-secondary` | `#4B5563` | Metadatos y explicaciones. |
| `--color-text-muted` | `#6B7280` | Texto auxiliar; no usar para datos críticos. |
| `--color-text-on-brand` | `#FFFFFF` | Texto sobre fondo de marca. |

Los colores de estado no se sustituyen por morado:

| Estado | Fondo suave | Texto/ícono | Ejemplos |
| --- | --- | --- | --- |
| Información / en revisión | `#EAF3FF` | `#0F5CA8` | En revisión, aviso operativo. |
| Éxito / aprobado | `#E8F5E9` | `#2E7D32` | Aprobado, carga exitosa. |
| Advertencia / requiere acción | `#FFF4CE` | `#8A4B00` | Pendiente, corrección requerida. |
| Error / rechazado | `#FDE7E9` | `#B42318` | Rechazado, validación fallida. |
| Neutro / borrador | `#EEF2F6` | `#475467` | Borrador, archivado. |

### 3.2 Tipografía

- **Interfaz y datos:** `Segoe UI`, `DM Sans`, `Arial`, sans-serif. `Segoe UI` aporta el tono empresarial Microsoft y ya es una fuente de sistema en Windows; `DM Sans` mantiene compatibilidad con el prototipo si se incorpora más adelante.
- **Marca "masterbase":** `Manrope`, sans-serif, solo para el logotipo o piezas de marca.
- No usar más de dos familias tipográficas en una misma pantalla.
- Usar peso `400` para cuerpo, `500–600` para controles y encabezados menores, `700` solo para títulos importantes o la marca.

| Nivel | Tamaño / línea | Peso | Uso |
| --- | --- | --- | --- |
| Título de página | `28px / 36px` | 600 | Nombre de la vista principal. |
| Título de sección | `20px / 28px` | 600 | Bloques dentro de una página. |
| Título de tarjeta | `16px / 24px` | 600 | Resúmenes, paneles, modales. |
| Cuerpo | `14px / 20px` | 400 | Texto habitual y tablas. |
| Etiqueta / control | `14px / 20px` | 500 | Botones, campos, navegación. |
| Metadato | `12px / 18px` | 400 | Fechas, autores y ayudas. |
| Sobrelínea | `11px / 16px` | 600, mayúsculas | Categorías de sidebar; espaciado de letra `0.08em`. |

### 3.3 Espaciado, bordes y elevación

Usar una escala de 4 px. No introducir medidas arbitrarias salvo que un componente lo requiera.

| Token | Valor | Uso típico |
| --- | --- | --- |
| `--space-1` | `4px` | Separación icono/texto mínimo. |
| `--space-2` | `8px` | Controles compactos. |
| `--space-3` | `12px` | Espaciado interno pequeño. |
| `--space-4` | `16px` | Tarjetas compactas y grupos. |
| `--space-5` | `20px` | Separación entre elementos de una sección. |
| `--space-6` | `24px` | Padding habitual de tarjeta y página. |
| `--space-8` | `32px` | Separación de secciones. |
| `--space-10` | `40px` | Bloques principales. |

- Radio estándar: `8px` en controles (`--radius-control`), `10px` en bloques internos (`--radius-md`), `12px` en tarjetas (`--radius-card`, igual que la tarjeta de acceso de Keycloak) y `14px` en modales.
- Bordes: `--color-border` (`#E4E7EC`) para tarjetas, tablas y separadores; `--color-border-control` (`#D0D5DD`) para botones secundarios y filtros; `--color-border-strong` (`#9CA3AF`) para campos de formulario, igual que en el acceso.
- Sombra de tarjeta: `--shadow-card` (`0 1px 2px rgba(16,24,40,.04), 0 1px 3px rgba(16,24,40,.05)`). Solo los elementos flotantes usan `--shadow-popover` o `--shadow-modal`.
- La separación y el borde comunican agrupación antes que la sombra.

### 3.4 Iconografía

- Usar exclusivamente `lucide-react`, ya disponible en el proyecto.
- Tamaño base: `20px`; `16px` en controles densos y `24px` en acciones de encabezado.
- Todo icono accionable necesita `aria-label` o texto visible. Un icono decorativo usa `aria-hidden="true"`.
- No usar caracteres Unicode como iconos de navegación en nuevas vistas.

## 4. Estructura de aplicación

### 4.1 Shell principal

La aplicación usa un layout persistente: sidebar + barra superior + área de trabajo.

| Área | Regla |
| --- | --- |
| Sidebar | Ancho `264px`; fondo plano `--color-brand-900`; navegación fija mientras se desplaza el contenido. |
| Barra superior | Alto `64px` (alineada con la franja de marca del sidebar); fondo blanco; borde inferior `--color-border`; contiene la ruta actual (sección › página) y el centro de notificaciones. |
| Área de contenido | Fondo `--color-canvas`; padding `28px 32px` en escritorio, `24px 20px` en tablet y `20px 16px` en móvil. |
| Contenedor de lectura | Máximo `1320px` (`--page-max-width`) para vistas operativas. Formulario de registro: máximo `1120px` con panel lateral de ayuda. |

El sidebar contiene, en este orden: logotipo MasterBase (`public/masterbase-wordmark.png`, el mismo del acceso) con la leyenda “Gestión documental”; grupos Principal, Documentos, Flujos de aprobación y Configuración; y al pie la tarjeta del usuario (avatar con iniciales, nombre, rol y botón de cerrar sesión). Las rutas aún no implementadas muestran la etiqueta “Pronto”.

### 4.2 Navegación lateral

- Títulos de grupo: `rgba(244, 233, 245, 0.48)`, `0.66rem`, mayúsculas con espaciado `0.1em`.
- Enlace normal: alto `38px`, texto `rgba(244, 233, 245, 0.78)`, fondo transparente.
- Hover: `rgba(255, 255, 255, 0.06)` y texto blanco.
- Activo: fondo `rgba(255, 255, 255, 0.12)`, texto blanco, peso `600`, icono `#F3C3F4` y barra izquierda de `3px` en `--color-accent-soft` (marcador no basado solo en color).
- Los contadores se muestran solo cuando aportan prioridad; deben incluir una etiqueta accesible como `4 solicitudes pendientes`.
- La selección activa debe reflejar la ruta actual mediante `NavLink`, no con una clase manual.

### 4.3 Responsive

| Ancho | Comportamiento |
| --- | --- |
| `>= 1280px` | Sidebar fija, contenido con ancho máximo. |
| `768px–1279px` | Sidebar compacta o colapsable; etiquetas nunca se recortan sin alternativa accesible. |
| `< 768px` | Sidebar dentro de panel lateral modal; topbar ofrece botón de menú; contenido con `16px` de padding. |

No se debe ocultar una acción crítica solo porque disminuye el ancho. Puede reubicarse en un menú `Más acciones` con etiqueta clara.

## 5. Componentes base

### 5.1 Botones

| Variante | Uso | Apariencia |
| --- | --- | --- |
| Primario | Acción principal única: crear solicitud, guardar, enviar a revisión. | Fondo `--color-brand-700`, texto blanco. |
| Secundario | Acción complementaria: cancelar, volver, previsualizar. | Fondo blanco, borde `--color-border-strong`, texto `--color-text`. |
| Terciario | Acción de baja prioridad dentro de un panel. | Sin borde ni fondo inicial; texto `--color-brand-700`. |
| Peligro | Rechazar, eliminar o desactivar. | Fondo `#B42318`, texto blanco; siempre requiere confirmación cuando sea irreversible. |

- Alto mínimo: `36px`; alto recomendado: `40px`.
- Padding horizontal: `12px–16px`; icono separado `8px` del texto.
- El texto debe iniciar con verbo: “Guardar cambios”, “Enviar a revisión”, “Solicitar corrección”.
- Nunca colocar dos botones primarios en la misma zona de decisión.
- Estados obligatorios: normal, hover, active, focus-visible, disabled y loading.

### 5.2 Campos de formulario

- Etiqueta visible arriba del campo; no usar placeholder como etiqueta.
- Campo: alto mínimo `42px`, fondo blanco, borde `--color-border-strong`, radio `8px`.
- Foco: borde `--color-brand-700` más anillo `--focus-ring` (`0 0 0 3px rgba(91, 26, 98, 0.18)`).
- Error: texto de ayuda bajo el campo, icono y borde `#B42318`; explicar cómo corregirlo.
- Agrupar los campos según la tarea: metadatos, archivo, flujo y confirmación. No presentar formularios extensos como una lista plana.

### 5.3 Tarjetas y paneles

- Usar tarjetas solo para agrupar una unidad de decisión o lectura: resumen de solicitud, estado del flujo, metadatos o acciones.
- Fondo blanco, borde `--color-border`, radio `12px`, padding `20px–24px`.
- Encabezado de tarjeta (`.card-header`): título, descripción opcional y acciones alineadas a la derecha, separado del cuerpo por un borde.
- Pie de acciones (`.document-upload-actions`, `.detail-card-footer`): fondo `--color-surface-subtle`, texto que explica la consecuencia a la izquierda y botón primario a la derecha.
- Evitar anidar tarjetas dentro de tarjetas. Para subgrupos usar separadores y espaciado.

### 5.4 Tablas y listas

- Las tablas se reservan para datos comparables: solicitudes, documentos, usuarios, historial.
- Cabecera con fondo `--color-surface-subtle`, texto de `12px/600` y ordenamiento visible cuando corresponda.
- Filas de al menos `48px`; hover suave; acción contextual al final de la fila.
- Estado vacío: explicación concreta y CTA pertinente, por ejemplo: “No hay solicitudes pendientes de revisión. Cuando se envíe una, aparecerá aquí.”
- En espacios angostos, transformar tablas amplias en tarjetas de datos con los campos prioritarios. Implementación: `.table-stackable` en la tabla; el contenedor (`.table-scroll` / `.table-responsive`) es un *container query*, así que el cambio depende del ancho real disponible (con o sin sidebar), no del ancho de la ventana. Bajo `960px` cada fila es una tarjeta: la celda `.cell-primary` encabeza, las demás muestran su `data-label` sobre el valor y `.cell-actions` va al pie (o en la esquina con `.cell-actions--corner` para acciones de solo icono). Bajo `520px` se usan dos columnas y `.cell-wide` ocupa todo el ancho.
- En modo tabla, los bloques con icono (`.cell-with-icon .cell-stack`) tienen un ancho mínimo de `10rem` para que nombres y correos no se corten letra por letra; las fechas usan `DateTimeStack` (fecha y hora en dos líneas).

### 5.5 Estados, etiquetas y notificaciones

- Toda etiqueta de estado combina color, texto e icono o punto indicador (`StatusBadge` dibuja un punto de `6px` antes del texto).
- Correspondencia vigente: `Pendiente de revisión` → información (azul); `Corrección requerida` → advertencia (ámbar); `Aprobado` y `Activo` → éxito; `Rechazado` → error; `Inactivo` → neutro.
- Usar palabras del dominio de forma consistente: `Borrador`, `Pendiente de revisión`, `En revisión`, `Corrección requerida`, `Aprobado`, `Rechazado`.
- Las alertas explican qué pasó, impacto y siguiente acción. No usar solo “Error”.
- Notificaciones transitorias (toast) no sustituyen validaciones persistentes ni mensajes de estado críticos.

### 5.6 Modales y confirmaciones

- Usar modal solo para decisiones, edición enfocada o información que no puede convivir con la vista.
- Título orientado a la acción: “Rechazar solicitud”, no “Confirmación”.
- La acción irreversible va a la derecha y se marca como peligro; la opción segura es “Cancelar”.
- Al abrir, el foco entra al modal; `Escape` lo cierra solo si no se pierde información sin confirmar; al cerrar, el foco vuelve al disparador.

### 5.7 Biblioteca de componentes compartidos

La implementación compartida está en `src/components/ui/index.jsx` y usa los tokens de `src/App.css`:

| Componente | Uso | Props principales |
| --- | --- | --- |
| `Button` | Acciones y enlaces con el mismo tamaño, foco y estado deshabilitado. | `variant` (`primary`, `secondary`, `success`, `warning`, `danger`, `info`, `quiet`), `as`, `loading`, `disabled`. |
| `FormField` | Etiqueta, control y ayuda de formulario. | `label`, `htmlFor`, `optional`, `hint`, `hintId`, `error`. El control se pasa como hijo. |
| `StatusBadge` | Estado documental o de usuario con texto y color coherentes. | `status`, `label` opcional. |
| `FeedbackMessage` | Error, confirmación o información persistente. | `tone` (`error`, `success`, `info`), `title`, contenido hijo. |
| `EmptyState` | Carga, ausencia de datos y siguiente acción. | `icon`, `title`, `loading`, `tone` (`neutral`, `success`), `action`, contenido hijo. |
| `DataTable` | Tabla operativa con cabecera y filas estándar. | Cabecera y cuerpo como hijos; `className` para necesidades de una vista. |
| `Card` | Superficie de contenido y agrupación. | `as`, `className`, contenido hijo. |
| `PageHeader` | Encabezado único de cada vista: sobrelínea, título, descripción, icono y acciones. | `eyebrow`, `title`, `titleId`, `description`, `icon`, `actions`, contenido hijo opcional bajo el título. |
| `FileTypeIcon` | Mosaico con la extensión del archivo y color por tipo (PDF, Word, Excel, TXT, XML). | `fileName`. |
| `DateTimeStack` | Fecha y hora en dos líneas para columnas de tabla. | `value` (ISO). |
| `DetailModal` | Detalle de una vista lista/detalle en pantallas compactas: centrado en tablet y como hoja inferior en teléfono; foco dentro del diálogo, cierre con `Escape` o clic fuera y devolución del foco. | `open`, `onClose`, `labelledBy`, contenido hijo (encabezado `.detail-card-header` y cuerpo `.detail-card-body`). |

Utilidades exportadas: `formatDateTime`, `formatFileSize`, `getStatusLabel`, `useMediaQuery` y `SPLIT_VIEW_COMPACT_QUERY` (`max-width: 1120px`), para que todas las vistas presenten fechas, tamaños y estados con el mismo formato y compartan el mismo punto de quiebre.

Por ahora la interfaz no usa avatares de usuario: las personas se identifican por nombre y correo (`.cell-person`).

**Vistas lista/detalle (Estado de solicitudes, Corregir documento):** en escritorio muestran ambos paneles. Bajo `1120px` solo se muestra la lista (título, fecha y estado apilados, con flecha) y al tocar una fila el detalle se abre en `DetailModal`; si se llega con `?id=` la solicitud se abre directamente. En Corregir, el botón “Reenviar a revisión” queda fijo al pie del modal y el modal se cierra al reenviar con éxito.

Los componentes mantienen clases existentes como `primary-btn`, `data-table` y `status-badge` para facilitar una migración gradual sin cambiar los contratos visuales ni los selectores que ya usan las vistas. Las páginas conservan sus estilos propios solo cuando responden a una necesidad específica, como el calendario de filtros, el visor de archivos o el detalle de una solicitud.

### Ejemplo de uso

```jsx
<FormField label="Título del documento *" htmlFor="titulo" hint="Usa un nombre reconocible.">
  <input id="titulo" name="titulo" required />
</FormField>
<Button type="submit">Guardar cambios</Button>
<StatusBadge status="PENDIENTE_REVISION" />
```

La navegación lateral usa `NavLink` para señalar la ruta activa y en móvil se abre desde la barra superior; el foco se mantiene dentro del menú mientras está abierto.


### 5.8 Acceso y recuperación de contraseña

El acceso se personaliza en `docker/keycloak/themes/capstone/login/`, porque los formularios los sirve Keycloak. Usa la misma paleta, Segoe UI, superficies claras y controles del sistema.

- En escritorio: formulario a la izquierda y personaje SVG a la derecha; en recuperación se intercambian los lados.
- La estrella fugaz acompaña una transición de 650 ms antes de seguir el enlace nativo de Keycloak. Volver al acceso invierte el movimiento. No se reemplazan los formularios, validaciones ni mensajes del servidor.
- `mascot.svg` conserva cuerpo, ojos y párpados como grupos editables. Las pupilas siguen el puntero con desplazamiento limitado.
- Los ojos se cierran al interactuar con la contraseña oculta y se abren al mostrarla. Antes de interactuar con una contraseña vacía permanecen abiertos.
- En móvil se apilan ilustración y formulario. `prefers-reduced-motion` elimina el seguimiento y las transiciones; los enlaces siguen funcionando sin JavaScript.
- El único dato guardado por la animación es una preferencia temporal de posición de panel. Nunca guarda credenciales ni direcciones de autenticación.

## 6. Patrones para flujos documentales

### 6.1 Página de solicitudes

Orden recomendado:

1. Título de página y descripción breve.
2. Acciones principales: “Nueva solicitud” o filtros de contexto.
3. Resumen de conteos por estado, si ayuda a decidir prioridades.
4. Filtros y búsqueda.
5. Tabla o lista de solicitudes.

Cada solicitud debe exponer sin abrirla: nombre, emisor, fecha relevante, estado, responsable o etapa y acción disponible.

### 6.2 Detalle y revisión de documento

La información debe dividirse en tres zonas: resumen y estado actual, documento/metadatos y decisión del revisor. Las acciones `Aprobar`, `Solicitar corrección` y `Rechazar` no se mezclan con acciones secundarias de descarga o navegación.

Las observaciones deben ser visibles, fechadas, atribuibles y permanecer en la línea de tiempo. “Solicitar corrección” exige texto de observación antes de habilitar el envío.

### 6.3 Historial de flujo

- Presentar una línea de tiempo vertical en orden descendente, dejando claro el evento más reciente.
- Cada evento contiene: acción, usuario/rol, fecha y hora local, estado resultante y observación si existe.
- El historial es de solo lectura; no se presentan controles que sugieran edición.

## 7. Accesibilidad y calidad

Antes de considerar lista una vista:

- Contraste mínimo WCAG AA: `4.5:1` para texto normal y `3:1` para texto grande/componentes gráficos.
- Navegación completa por teclado con un foco visible. Nunca usar `outline: none` sin reemplazo.
- Todo control tiene nombre accesible; todos los campos tienen `label` asociado.
- El estado de error, éxito o prioridad tiene texto, no solo color.
- Las actualizaciones dinámicas importantes usan anuncios accesibles cuando corresponde (`aria-live`).
- El objetivo táctil mínimo es `40px × 40px`; usar `44px` cuando la interacción sea principalmente móvil.
- Probar con zoom de navegador al 200 % y sin depender del hover.

## 8. Convenciones de implementación en este repositorio

La guía se implementará gradualmente en `frontend/src/App.css` y en componentes React reutilizables. Mientras no exista una librería de componentes, se usarán clases semánticas, no estilos en línea.

```css
:root {
  --color-brand-900: #37143a;
  --color-brand-800: #401449;
  --color-brand-700: #5b1a62;
  --color-brand-100: #f0e1f0;
  --color-canvas: #f6f7f9;
  --color-surface: #ffffff;
  --color-border: #e4e7ec;
  --color-border-control: #d0d5dd;
  --color-border-strong: #9ca3af;
  --color-text-strong: #111827;
  --color-text: #1f2937;
  --color-text-secondary: #4b5563;
  --radius-control: 8px;
  --radius-card: 12px;
  --page-max-width: 1320px;
}
```

Nombres recomendados de clases iniciales:

| Necesidad | Clase |
| --- | --- |
| Página estándar | `.page`, `.page-header`, `.page-title`, `.page-actions` |
| Agrupación | `.card`, `.card-header`, `.card-body` |
| Botones | `.button`, `.button--primary`, `.button--secondary`, `.button--danger` |
| Formularios | `.field`, `.field__label`, `.field__control`, `.field__hint`, `.field--error` |
| Estados | `.status-badge`, `.status-badge--approved`, `.status-badge--needs-correction` |
| Datos | `.data-table`, `.empty-state`, `.timeline` |

Reglas técnicas:

- No instalar Tailwind ni otra biblioteca de estilos para aplicar esta guía.
- Reutilizar `lucide-react` para iconos; no introducir SVGs copiados del prototipo ni glifos Unicode como controles.
- Usar `NavLink` para que la navegación activa dependa de la ruta.
- Evitar valores hexadecimales repetidos en vistas nuevas: usar variables CSS.
- No crear una vista nueva que solo replique una captura de Figma; debe responder a una tarea de negocio y a datos reales.

## 9. Lista de verificación de revisión visual

- [ ] La vista identifica página, contexto y acción principal en menos de cinco segundos.
- [ ] Hay una sola acción primaria por bloque de decisión.
- [ ] Los estados incluyen nombre legible además de color.
- [ ] El sidebar mantiene la identidad morada y muestra claramente la ruta activa.
- [ ] Formularios, tablas y tarjetas usan los tokens definidos en esta guía.
- [ ] El foco de teclado es visible y los controles tienen nombres accesibles.
- [ ] La pantalla funciona a 320 px, 768 px y escritorio sin ocultar información crítica.
- [ ] La interfaz se percibe empresarial y sobria: sin gradientes, sombras excesivas, animaciones decorativas ni colores de estado usados para ornamentación.

## 10. Evolución prevista

Esta guía debe evolucionar con componentes reales. Cuando se implemente un patrón por segunda vez, se debe extraer a un componente reutilizable y documentar aquí su API visual. Toda modificación de tokens, estados o patrones debe revisarse contra el prototipo Figma vigente y las necesidades de los roles Administrador, Revisor, Solicitante y Auditor.
