import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  Download,
  FileText,
  FolderOpen,
  Plus,
  Search,
  SearchX
} from 'lucide-react';
import api from '../../services/api';
import {
  Button,
  Card,
  DataTable,
  DateTimeStack,
  EmptyState,
  FeedbackMessage,
  FileTypeIcon,
  PageHeader,
  StatusBadge,
  formatFileSize
} from '../../components/ui';

const STATUS_FILTERS = [
  { value: 'TODOS', label: 'Todos' },
  { value: 'PENDIENTE_REVISION', label: 'Pendientes' },
  { value: 'CORRECCION_REQUERIDA', label: 'Con observaciones' },
  { value: 'APROBADO', label: 'Aprobados' },
  { value: 'RECHAZADO', label: 'Rechazados' }
];

export default function MisDocumentosView() {
  const [solicitudes, setSolicitudes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('TODOS');

  const fetchMisDocumentos = async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const response = await api.get('/api/solicitudes/mis-solicitudes');
      setSolicitudes(Array.isArray(response.data) ? response.data : []);
    } catch (err) {
      console.error('Error al cargar documentos', err);
      setErrorMessage('No fue posible cargar el listado de documentos.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMisDocumentos();
  }, []);

  const handleDownload = async (solicitudId, fileName) => {
    try {
      const resp = await api.get(`/api/solicitudes/${solicitudId}/documento/descargar`, {
        responseType: 'blob'
      });
      const blobUrl = window.URL.createObjectURL(new Blob([resp.data]));
      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', fileName || 'documento');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error('Error al descargar archivo', err);
      setErrorMessage('Error al descargar el archivo seleccionado.');
    }
  };

  const normalizedSearch = search.trim().toLowerCase();
  const matchesSearch = (sol) => !normalizedSearch
    || sol.titulo?.toLowerCase().includes(normalizedSearch)
    || sol.documentoVigente?.nombreArchivo?.toLowerCase().includes(normalizedSearch);
  const searchResults = solicitudes.filter(matchesSearch);
  const visibleSolicitudes = statusFilter === 'TODOS'
    ? searchResults
    : searchResults.filter((sol) => sol.estado === statusFilter);
  const countByStatus = (status) => status === 'TODOS'
    ? searchResults.length
    : searchResults.filter((sol) => sol.estado === status).length;

  return (
    <section className="list-page" aria-labelledby="mis-docs-title">
      <PageHeader
        eyebrow="Documentos"
        title="Mis documentos"
        titleId="mis-docs-title"
        description="Consulta y descarga los documentos que has enviado, junto con su estado en el flujo de aprobación."
        icon={FolderOpen}
        actions={(
          <Button as={Link} to="/nuevo-documento">
            <Plus size={18} aria-hidden="true" />
            Nuevo documento
          </Button>
        )}
      />

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}

      <Card as="div" className="list-card">
        <div className="list-toolbar">
          <label className="search-field">
            <Search size={17} aria-hidden="true" />
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Buscar por título o archivo"
              aria-label="Buscar documentos"
            />
          </label>
          <div className="filter-chips" role="group" aria-label="Filtrar por estado">
            {STATUS_FILTERS.map((filter) => (
              <button
                key={filter.value}
                type="button"
                className={`filter-chip${statusFilter === filter.value ? ' is-active' : ''}`}
                aria-pressed={statusFilter === filter.value}
                onClick={() => setStatusFilter(filter.value)}
              >
                {filter.label}
                <span className="filter-chip-count">{countByStatus(filter.value)}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="table-scroll">
          {loading ? (
            <EmptyState loading title="Cargando documentos…" />
          ) : solicitudes.length === 0 ? (
            <EmptyState icon={FileText} title="No hay documentos registrados" action={<Button as={Link} to="/nuevo-documento">Registrar documento</Button>}>
              Comienza subiendo un nuevo archivo desde “Nuevo documento”.
            </EmptyState>
          ) : visibleSolicitudes.length === 0 ? (
            <EmptyState
              icon={SearchX}
              title="Sin resultados"
              action={<Button variant="secondary" onClick={() => { setSearch(''); setStatusFilter('TODOS'); }}>Limpiar filtros</Button>}
            >
              Ningún documento coincide con la búsqueda o el filtro seleccionado.
            </EmptyState>
          ) : (
            <DataTable className="table-stackable">
              <thead>
                <tr>
                  <th>Documento</th>
                  <th>Versión</th>
                  <th>Estado</th>
                  <th>Última carga</th>
                  <th className="text-right"><span className="visually-hidden">Acciones</span></th>
                </tr>
              </thead>
              <tbody>
                {visibleSolicitudes.map((sol) => {
                  const documento = sol.documentoVigente;
                  return (
                    <tr key={sol.id}>
                      <td className="cell-primary">
                        <div className="cell-with-icon">
                          <FileTypeIcon fileName={documento?.nombreArchivo} />
                          <div className="cell-stack">
                            <strong>{sol.titulo}</strong>
                            <span>
                              {documento ? documento.nombreArchivo : 'Sin archivo'}
                              {documento?.sizeBytes ? ` · ${formatFileSize(documento.sizeBytes)}` : ''}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td data-label="Versión"><span className="version-pill">v{documento?.version || 1}</span></td>
                      <td data-label="Estado"><StatusBadge status={sol.estado} /></td>
                      <td data-label="Última carga"><DateTimeStack value={documento?.createdAt || sol.createdAt} /></td>
                      <td className="text-right cell-actions">
                        <div className="row-actions">
                          <Link
                            to={`/estado-solicitudes?id=${sol.id}`}
                            className="action-btn"
                            title="Ver seguimiento"
                            aria-label={`Ver seguimiento de ${sol.titulo}`}
                          >
                            <Activity size={16} aria-hidden="true" />
                          </Link>
                          {documento && (
                            <Button
                              variant="secondary"
                              className="ui-button--compact"
                              onClick={() => handleDownload(sol.id, documento.nombreArchivo)}
                              title="Descargar archivo mediante intermediario seguro"
                            >
                              <Download size={15} aria-hidden="true" />
                              <span>Descargar</span>
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </DataTable>
          )}
        </div>
      </Card>
    </section>
  );
}
