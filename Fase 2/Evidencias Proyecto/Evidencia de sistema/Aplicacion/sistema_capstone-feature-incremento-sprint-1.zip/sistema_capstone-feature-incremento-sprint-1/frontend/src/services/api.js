import axios from 'axios';
import keycloak from './keycloak';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || window.location.origin,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para inyectar token JWT de Keycloak en solicitudes salientes
api.interceptors.request.use(
  async (config) => {
    if (keycloak.authenticated && keycloak.token) {
      // Renovar token si expira en menos de 30 segundos
      try {
        await keycloak.updateToken(30);
      } catch (error) {
        console.warn('Error renovando token Keycloak', error);
      }
      config.headers.Authorization = `Bearer ${keycloak.token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;
