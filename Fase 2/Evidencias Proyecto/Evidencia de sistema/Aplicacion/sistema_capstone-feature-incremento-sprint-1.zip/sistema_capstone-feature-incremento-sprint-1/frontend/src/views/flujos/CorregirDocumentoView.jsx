import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  CheckCircle2,
  ChevronRight,
  FileEdit,
  LoaderCircle,
  RotateCcw,
  Trash2,
  UploadCloud,
  X
} from 'lucide-react';
import api from '../../services/api';
import ObservationTimeline from '../../components/ObservationTimeline';
import {
  Button,
  Card,
  DataTable,
  DetailModal,
  EmptyState,
  FeedbackMessage,
  FileTypeIcon,
  FormField,
  PageHeader,
  SPLIT_VIEW_COMPACT_QUERY,
  StatusBadge,
  formatDateTime,
  formatFileSize,
  useMediaQuery
} from '../../components/ui';

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_EXTENSIONS = ['.doc', '.docx', '.pdf', '.xml', '.txt', '.xlsx', '.xls'];
const ACCEPTED_FILE_TYPES =
  '.doc,.docx,.pdf,.xml,.txt,.xlsx,.xls,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,application/xml,text/xml,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel';

function getFileExtension(fileName) {
  const lastDot = fileName.lastIndexOf('.');
  return lastDot === -1 ? '' : fileName.slice(lastDot).toLowerCase();
}

function selectOnKey(event, callback) {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    callback();
  }
}

export default function CorregirDocumentoView() {
  const [searchParams] = useSearchParams();
  const targetId = searchParams.get('id');
  const isCompact = useMediaQuery(SPLIT_VIEW_COMPACT_QUERY);

  const fileInputRef = useRef(null);
  const [observedList, setObservedList] = useState([]);
  const [selectedSolicitud, setSelectedSolicitud] = useState(null);
  const [observaciones, setObservaciones] = useState([]);
  const [detailOpen, setDetailOpen] = useState(false);

  // Campos de edición
  const [titulo, setTitulo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [replacementFile, setReplacementFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);

  const [loadingList, setLoadingList] = useState(true);
  const [loadingObservaciones, setLoadingObservaciones] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const fetchObservedRequests = async () => {
    setLoadingList(true);
    setErrorMessage('');
    try {
      const resp = await api.get('/api/solicitudes/mis-solicitudes');
      const all = Array.isArray(resp.data) ? resp.data : [];
      const observed = all.filter((s) => s.estado === 'CORRECCION_REQUERIDA');
      setObservedList(observed);

      if (targetId) {
        const found = observed.find((s) => s.id === targetId);
        if (found) {
          if (window.matchMedia(SPLIT_VIEW_COMPACT_QUERY).matches) setDetailOpen(true);
          await selectSolicitud(found);
          return;
        }
        setSelectedSolicitud(null);
        setObservaciones([]);
        setErrorMessage('La solicitud indicada no está pendiente de corrección o no pertenece al usuario actual.');
        return;
      }

      if (observed.length > 0) {
        await selectSolicitud(observed[0]);
      } else {
        setSelectedSolicitud(null);
        setObservaciones([]);
      }
    } catch (err) {
      console.error('Error cargando solicitudes para corrección', err);
      setErrorMessage('No fue posible cargar las solicitudes que requieren corrección.');
    } finally {
      setLoadingList(false);
    }
  };

  const selectSolicitud = async (sol) => {
    setSelectedSolicitud(sol);
    setTitulo(sol.titulo || '');
    setDescripcion(sol.descripcion || '');
    setReplacementFile(null);
    setErrorMessage('');

    setLoadingObservaciones(true);
    try {
      const resp = await api.get(`/api/solicitudes/${sol.id}/observaciones`);
      setObservaciones(Array.isArray(resp.data) ? resp.data : []);
    } catch (err) {
      console.warn('Error cargando observaciones', err);
      setObservaciones([]);
    } finally {
      setLoadingObservaciones(false);
    }
  };

  useEffect(() => {
    fetchObservedRequests();
  }, [targetId]);

  const validateReplacementFile = (candidate) => {
    if (!candidate) return '';
    if (!ALLOWED_EXTENSIONS.includes(getFileExtension(candidate.name))) {
      return 'El archivo debe estar en formato .doc, .docx, .pdf, .xml, .txt, .xlsx o .xls.';
    }
    if (candidate.size > MAX_FILE_SIZE) {
      return 'El archivo supera el tamaño máximo permitido de 10 MB.';
    }
    return '';
  };

  const selectFile = (candidate) => {
    const error = validateReplacementFile(candidate);
    if (error) {
      setErrorMessage(error);
      setReplacementFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    setReplacementFile(candidate);
    setErrorMessage('');
  };

  const removeFile = () => {
    setReplacementFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedSolicitud) return;

    if (!titulo.trim()) {
      setErrorMessage('El título del documento es obligatorio.');
      return;
    }

    if (replacementFile) {
      const fileErr = validateReplacementFile(replacementFile);
      if (fileErr) {
        setErrorMessage(fileErr);
        return;
      }
    }

    setIsSubmitting(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const formData = new FormData();
      formData.append('titulo', titulo.trim());
      formData.append('descripcion', descripcion.trim());
      if (replacementFile) formData.append('file', replacementFile);

      await api.put(`/api/solicitudes/${selectedSolicitud.id}/reenviar`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      setSuccessMessage('Solicitud corregida y reenviada a revisión exitosamente.');
      setReplacementFile(null);
      setDetailOpen(false);
      if (fileInputRef.current) fileInputRef.current.value = '';

      // Refrescar lista
      await fetchObservedRequests();
      setSuccessMessage('Solicitud corregida y reenviada a revisión exitosamente.');
    } catch (err) {
      console.error('Error al reenviar corrección', err);
      setErrorMessage(
        err?.response?.data?.detail ||
          err?.response?.data?.message ||
          'No fue posible reenviar la solicitud corregida.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const openDetail = (sol) => {
    selectSolicitud(sol);
    if (isCompact) setDetailOpen(true);
  };

  const observacionesPendientes = observaciones.filter((observacion) => !observacion.resuelta);
  const observacionesVisibles = observacionesPendientes.length > 0 ? observacionesPendientes : observaciones;
  const documentoVigente = selectedSolicitud?.documentoVigente;
  const showDetailModal = isCompact && detailOpen && Boolean(selectedSolicitud);

  const renderDetailHeader = (inModal) => (
    <div className="detail-card-header">
      <div className="detail-card-heading">
        <p className="page-eyebrow">Subsanar y reenviar</p>
        <h3 id="corregir-detail-heading">{selectedSolicitud.titulo}</h3>
        {inModal && <StatusBadge status="CORRECCION_REQUERIDA" />}
      </div>
      {inModal ? (
        <button className="action-btn" type="button" onClick={() => setDetailOpen(false)} disabled={isSubmitting} aria-label="Cerrar formulario">
          <X size={18} aria-hidden="true" />
        </button>
      ) : (
        <StatusBadge status="CORRECCION_REQUERIDA" />
      )}
    </div>
  );

  const renderDetailForm = (inModal) => (
    <form className="detail-card-body" onSubmit={handleSubmit} noValidate>
      <div className="detail-section">
        <span className="detail-section-title">Observaciones del revisor</span>
        {loadingObservaciones ? (
          <div className="inline-loading"><LoaderCircle className="button-spinner" size={18} aria-hidden="true" />Cargando observaciones…</div>
        ) : observacionesVisibles.length === 0 ? (
          <div className="observations-box">
            <p className="observation-text">
              <em>El revisor no detalló notas adicionales en esta observación.</em>
            </p>
          </div>
        ) : (
          <ObservationTimeline observations={observacionesVisibles} />
        )}
      </div>

      <div className="detail-section">
        <span className="detail-section-title">Datos de la solicitud</span>
        <div className="form-stack">
          <FormField label="Título del documento *" htmlFor="corregir-titulo">
            <input
              id="corregir-titulo"
              data-testid="corregir-titulo-input"
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              maxLength="255"
              disabled={isSubmitting}
              required
            />
          </FormField>

          <FormField label="Descripción / notas de subsanación" htmlFor="corregir-descripcion">
            <textarea
              id="corregir-descripcion"
              data-testid="corregir-descripcion-input"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              maxLength="2000"
              disabled={isSubmitting}
              rows="3"
            />
          </FormField>
        </div>
      </div>

      <div className="detail-section">
        <span className="detail-section-title">Archivo adjunto</span>
        {documentoVigente && (
          <div className={`attachment-card${replacementFile ? ' attachment-card--replaced' : ''}`}>
            <FileTypeIcon fileName={documentoVigente.nombreArchivo} />
            <div className="cell-stack">
              <strong title={documentoVigente.nombreArchivo}>{documentoVigente.nombreArchivo}</strong>
              <span>{replacementFile ? 'Será reemplazado por el nuevo archivo' : `Archivo vigente · versión ${documentoVigente.version}`}</span>
            </div>
          </div>
        )}

        <input
          ref={fileInputRef}
          id="corregir-file"
          className="visually-hidden"
          type="file"
          accept={ACCEPTED_FILE_TYPES}
          onChange={(e) => selectFile(e.target.files?.[0])}
          disabled={isSubmitting}
        />

        {!replacementFile ? (
          <div
            className={`document-dropzone document-dropzone--compact ${isDragging ? 'document-dropzone-dragging' : ''}`}
            role="button"
            tabIndex={0}
            aria-label="Seleccionar archivo corregido"
            onClick={() => !isSubmitting && fileInputRef.current?.click()}
            onKeyDown={(e) => {
              if (!isSubmitting && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                fileInputRef.current?.click();
              }
            }}
            onDragEnter={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragOver={(e) => e.preventDefault()}
            onDragLeave={(e) => {
              e.preventDefault();
              setIsDragging(false);
            }}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              selectFile(e.dataTransfer.files?.[0]);
            }}
          >
            <span className="document-dropzone-icon" aria-hidden="true"><UploadCloud size={20} /></span>
            <strong>Reemplazar archivo <span className="field-optional">(opcional)</span></strong>
            <span>Arrastra el archivo corregido o haz clic para seleccionarlo · máximo 10 MB</span>
          </div>
        ) : (
          <div className="selected-document">
            <FileTypeIcon fileName={replacementFile.name} />
            <div className="selected-document-info">
              <strong>{replacementFile.name}</strong>
              <span><CheckCircle2 size={13} aria-hidden="true" />{formatFileSize(replacementFile.size)} · Nuevo archivo sustituto</span>
            </div>
            <button
              className="selected-document-remove"
              type="button"
              onClick={removeFile}
              disabled={isSubmitting}
              aria-label={`Quitar archivo ${replacementFile.name}`}
              title="Quitar archivo"
            >
              <Trash2 size={16} aria-hidden="true" />
            </button>
          </div>
        )}
      </div>

      {inModal && errorMessage && <FeedbackMessage tone="error">{errorMessage}</FeedbackMessage>}

      <div className="detail-card-footer">
        <p>La solicitud volverá a quedar <strong>pendiente de revisión</strong>.</p>
        <Button
          type="submit"
          disabled={isSubmitting}
          data-testid="btn-reenviar"
        >
          {isSubmitting ? (
            <LoaderCircle className="button-spinner" size={18} aria-hidden="true" />
          ) : (
            <RotateCcw size={18} aria-hidden="true" />
          )}
          <span>{isSubmitting ? 'Reenviando…' : 'Reenviar a revisión'}</span>
        </Button>
      </div>
    </form>
  );

  return (
    <section className="list-page" aria-labelledby="corregir-title">
      <PageHeader
        eyebrow="Flujos de aprobación"
        title="Corregir documento"
        titleId="corregir-title"
        description="Revisa las observaciones del evaluador, ajusta los datos o reemplaza el archivo y vuelve a enviarlo a revisión."
        icon={FileEdit}
      />

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}

      {successMessage && (
        <FeedbackMessage tone="success" title={successMessage} className="page-message">
          <div className="ui-feedback-actions"><Button as={Link} variant="secondary" className="ui-button--compact" to="/estado-solicitudes">Ver estado de solicitudes</Button></div>
        </FeedbackMessage>
      )}

      <div className="master-detail">
        <Card as="div" className="master-list">
          <div className="card-header">
            <div>
              <h3>Solicitudes observadas</h3>
              <p>{observedList.length} {observedList.length === 1 ? 'solicitud pendiente de corrección' : 'solicitudes pendientes de corrección'}</p>
            </div>
          </div>

          <div className="table-scroll">
            {loadingList ? (
              <EmptyState loading title="Cargando solicitudes observadas…" />
            ) : observedList.length === 0 ? (
              <EmptyState icon={CheckCircle2} tone="success" title="Sin correcciones pendientes" data-testid="empty-observadas">
                No tienes solicitudes devueltas con observaciones en este momento.
              </EmptyState>
            ) : (
              <DataTable className="selectable-table">
                <thead>
                  <tr>
                    <th>Solicitud</th>
                    {isCompact ? <th><span className="visually-hidden">Abrir formulario</span></th> : <th>Observada</th>}
                  </tr>
                </thead>
                <tbody>
                  {observedList.map((sol) => {
                    const isSelected = selectedSolicitud?.id === sol.id && (!isCompact || detailOpen);
                    return (
                      <tr
                        key={sol.id}
                        className={`clickable-row ${isSelected ? 'row-selected' : ''}`}
                        onClick={() => openDetail(sol)}
                        onKeyDown={(event) => selectOnKey(event, () => openDetail(sol))}
                        tabIndex={0}
                        aria-current={isSelected ? 'true' : undefined}
                        aria-haspopup={isCompact ? 'dialog' : undefined}
                        data-testid={`solicitud-corregir-${sol.id}`}
                      >
                        <td>
                          <div className="cell-stack">
                            <strong>{sol.titulo}</strong>
                            <span>{sol.documentoVigente?.nombreArchivo || 'Sin archivo'}</span>
                            {isCompact && <span>Observada el {formatDateTime(sol.updatedAt || sol.createdAt)}</span>}
                          </div>
                        </td>
                        {isCompact
                          ? <td className="row-chevron"><ChevronRight size={18} aria-hidden="true" /></td>
                          : <td className="date-cell">{formatDateTime(sol.updatedAt || sol.createdAt)}</td>}
                      </tr>
                    );
                  })}
                </tbody>
              </DataTable>
            )}
          </div>
        </Card>

        {!isCompact && (
          <div className="detail-card">
            {!selectedSolicitud ? (
              <EmptyState icon={FileEdit} title="Nada que corregir por ahora">
                Selecciona una solicitud observada para ver las instrucciones y corregirla.
              </EmptyState>
            ) : (
              <>
                {renderDetailHeader(false)}
                {renderDetailForm(false)}
              </>
            )}
          </div>
        )}
      </div>

      <DetailModal open={showDetailModal} onClose={() => { if (!isSubmitting) setDetailOpen(false); }} labelledBy="corregir-detail-heading">
        {showDetailModal && (
          <>
            {renderDetailHeader(true)}
            {renderDetailForm(true)}
          </>
        )}
      </DetailModal>
    </section>
  );
}
