import React from 'react';

export default function RecuperarPasswordView() {
  return (
    <div className="view-container">
      <h2>Recuperar Contraseña</h2>
      <p>La recuperación de credenciales se gestiona a través del flujo de restablecimiento de contraseña de Keycloak.</p>
    </div>
  );
}
