import React, { useRef, useState } from 'react';
import {
  CheckCircle2,
  FileUp,
  LoaderCircle,
  Trash2,
  UploadCloud
} from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { Button, FeedbackMessage, FileTypeIcon, FormField, PageHeader, formatFileSize } from '../../components/ui';

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const MAX_DESCRIPTION_LENGTH = 2000;
const ALLOWED_EXTENSIONS = ['.doc', '.docx', '.pdf', '.xml', '.txt', '.xlsx', '.xls'];
const ACCEPTED_FILE_TYPES = '.doc,.docx,.pdf,.xml,.txt,.xlsx,.xls,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,application/xml,text/xml,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel';

const PROCESS_STEPS = [
  ['Registra la solicitud', 'Indica un título claro y agrega el contexto que necesite el revisor.'],
  ['Adjunta el documento', 'Sube un único archivo en un formato permitido.'],
  ['Revisión', 'Un revisor aprueba, rechaza o solicita correcciones.'],
  ['Seguimiento', 'Recibirás una notificación con cada cambio de estado.']
];

function getFileExtension(fileName) {
  const lastDot = fileName.lastIndexOf('.');
  return lastDot === -1 ? '' : fileName.slice(lastDot).toLowerCase();
}

function getUploadErrorMessage(error) {
  const serverDetail = error?.response?.data?.detail || error?.response?.data?.message;

  if (serverDetail) return serverDetail;
  if (error?.response?.status === 401) return 'Tu sesión no es válida o expiró. Inicia sesión nuevamente e inténtalo otra vez.';
  if (!error?.response) return 'No fue posible conectar con el servidor. Verifica tu conexión e inténtalo nuevamente.';

  return 'No fue posible registrar el documento. Revisa los datos e inténtalo nuevamente.';
}

export default function NuevoDocumentoView() {
  const fileInputRef = useRef(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const validateFile = (candidate) => {
    if (!candidate) return 'Selecciona un archivo para continuar.';
    if (!ALLOWED_EXTENSIONS.includes(getFileExtension(candidate.name))) return 'El archivo debe estar en formato .doc, .docx, .pdf, .xml, .txt, .xlsx o .xls.';
    if (candidate.size > MAX_FILE_SIZE) return 'El archivo supera el tamaño máximo permitido de 10 MB.';
    return '';
  };

  const selectFile = (candidate) => {
    const validationMessage = validateFile(candidate);
    setSuccessMessage('');

    if (validationMessage) {
      setFile(null);
      setErrorMessage(validationMessage);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setFile(candidate);
    setErrorMessage('');
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setIsDragging(false);
    selectFile(event.dataTransfer.files?.[0]);
  };

  const removeFile = () => {
    setFile(null);
    setUploadProgress(0);
    setErrorMessage('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSuccessMessage('');

    if (!title.trim()) {
      setErrorMessage('Ingresa el título del documento antes de enviarlo a revisión.');
      return;
    }

    const validationMessage = validateFile(file);
    if (validationMessage) {
      setErrorMessage(validationMessage);
      return;
    }

    const formData = new FormData();
    formData.append('titulo', title.trim());
    if (description.trim()) formData.append('descripcion', description.trim());
    formData.append('file', file);

    setIsSubmitting(true);
    setUploadProgress(0);
    setErrorMessage('');

    try {
      const response = await api.post('/api/solicitudes', formData, {
        // Evita el Content-Type JSON configurado por defecto en el cliente Axios.
        // En el navegador Axios deja el boundary final a cargo del FormData.
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          if (!progressEvent.total) return;
          setUploadProgress(Math.round((progressEvent.loaded * 100) / progressEvent.total));
        }
      });

      setUploadProgress(100);
      setSuccessMessage(response.data?.mensaje || 'Documento registrado correctamente y enviado a revisión.');
      setTitle('');
      setDescription('');
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (error) {
      console.error('No fue posible registrar el documento', error);
      setErrorMessage(getUploadErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="document-upload-page" aria-labelledby="document-upload-title">
      <PageHeader
        eyebrow="Documentos"
        title="Registrar documento"
        titleId="document-upload-title"
        description="Completa los datos de la solicitud, adjunta el archivo y envíalo al flujo de revisión."
        icon={FileUp}
      />

      <div className="document-upload-layout">
        <div className="document-upload-card">
          <div className="document-upload-card-header">
            <h3>Datos de la solicitud</h3>
            <p>Los campos marcados con * son obligatorios.</p>
          </div>

          <form className="document-upload-form" onSubmit={handleSubmit} noValidate>
            <div className="document-upload-fields">
              <FormField label="Título del documento *" htmlFor="document-title" hint="Identifica claramente el documento que enviarás a revisión." hintId="document-title-help">
                <input id="document-title" value={title} onChange={(event) => setTitle(event.target.value)} maxLength="255" placeholder="Ej.: Informe de gestión mensual" disabled={isSubmitting} aria-describedby="document-title-help" />
              </FormField>

              <FormField label="Descripción" htmlFor="document-description" optional hint={`${description.length} / ${MAX_DESCRIPTION_LENGTH} caracteres`} hintId="document-description-count">
                <textarea id="document-description" value={description} onChange={(event) => setDescription(event.target.value)} maxLength={MAX_DESCRIPTION_LENGTH} placeholder="Agrega contexto o información relevante para la revisión." disabled={isSubmitting} aria-describedby="document-description-count" />
              </FormField>
            </div>

            <div className="document-file-section">
              <span className="document-file-label">Archivo adjunto *</span>
              <input ref={fileInputRef} id="document-file" className="visually-hidden" type="file" accept={ACCEPTED_FILE_TYPES} onChange={(event) => selectFile(event.target.files?.[0])} disabled={isSubmitting} />

              {!file ? (
                <div
                  className={`document-dropzone ${isDragging ? 'document-dropzone-dragging' : ''}`}
                  role="button"
                  tabIndex={isSubmitting ? -1 : 0}
                  aria-label="Seleccionar archivo para adjuntar"
                  aria-describedby="document-file-help"
                  onClick={() => !isSubmitting && fileInputRef.current?.click()}
                  onKeyDown={(event) => {
                    if (!isSubmitting && (event.key === 'Enter' || event.key === ' ')) {
                      event.preventDefault();
                      fileInputRef.current?.click();
                    }
                  }}
                  onDragEnter={(event) => {
                    event.preventDefault();
                    if (!isSubmitting) setIsDragging(true);
                  }}
                  onDragOver={(event) => event.preventDefault()}
                  onDragLeave={(event) => {
                    event.preventDefault();
                    setIsDragging(false);
                  }}
                  onDrop={(event) => !isSubmitting && handleDrop(event)}
                >
                  <span className="document-dropzone-icon" aria-hidden="true"><UploadCloud size={24} /></span>
                  <strong>Arrastra tu archivo aquí o <span className="document-dropzone-link">selecciónalo</span></strong>
                  <span>PDF, Word, Excel, TXT o XML · máximo 10 MB</span>
                </div>
              ) : (
                <div className="selected-document" aria-label={`Archivo seleccionado: ${file.name}`}>
                  <FileTypeIcon fileName={file.name} />
                  <div className="selected-document-info">
                    <strong>{file.name}</strong>
                    <span><CheckCircle2 size={13} aria-hidden="true" />{formatFileSize(file.size)} · Formato válido</span>
                  </div>
                  <button className="selected-document-remove" type="button" onClick={removeFile} disabled={isSubmitting} aria-label="Quitar archivo seleccionado" title="Quitar archivo">
                    <Trash2 size={17} aria-hidden="true" />
                  </button>
                </div>
              )}
              <p id="document-file-help" className="visually-hidden">Formatos permitidos: .doc, .docx, .pdf, .xml, .txt, .xlsx y .xls. Tamaño máximo: 10 MB.</p>
            </div>

            {isSubmitting && (
              <div className="upload-progress" aria-live="polite">
                <div className="upload-progress-label"><span>Subiendo documento…</span><span>{uploadProgress}%</span></div>
                <div className="upload-progress-track" role="progressbar" aria-label="Progreso de carga" aria-valuemin="0" aria-valuemax="100" aria-valuenow={uploadProgress}>
                  <div className="upload-progress-value" style={{ width: `${uploadProgress}%` }} />
                </div>
              </div>
            )}

            {errorMessage && <FeedbackMessage tone="error" className="document-upload-message">{errorMessage}</FeedbackMessage>}

            {successMessage && (
              <FeedbackMessage tone="success" title={successMessage} className="document-upload-message">
                <div className="ui-feedback-actions">
                  <Button as={Link} variant="secondary" className="ui-button--compact" to="/estado-solicitudes">Ver estado de solicitudes</Button>
                  <Button as={Link} variant="secondary" className="ui-button--compact" to="/mis-documentos">Ir a mis documentos</Button>
                </div>
              </FeedbackMessage>
            )}

            <div className="document-upload-actions">
              <p>Al enviar, la solicitud quedará <strong>pendiente de revisión</strong>.</p>
              <Button className="document-upload-submit" type="submit" disabled={isSubmitting}>
                {isSubmitting ? <LoaderCircle className="button-spinner" size={18} aria-hidden="true" /> : <FileUp size={18} aria-hidden="true" />}
                {isSubmitting ? 'Subiendo documento…' : 'Enviar a revisión'}
              </Button>
            </div>
          </form>
        </div>

        <aside className="document-upload-aside" aria-label="Información del proceso">
          <section className="aside-card">
            <h3>¿Cómo funciona?</h3>
            <ol className="process-steps">
              {PROCESS_STEPS.map(([stepTitle, stepText], index) => (
                <li key={stepTitle}>
                  <span className="process-step-number" aria-hidden="true">{index + 1}</span>
                  <div>
                    <strong>{stepTitle}</strong>
                    <p>{stepText}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        </aside>
      </div>
    </section>
  );
}
