import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, CheckCircle2, FileText, Info, LoaderCircle } from 'lucide-react';

// Debe coincidir con el punto de quiebre de .master-detail en App.css.
export const SPLIT_VIEW_COMPACT_QUERY = '(max-width: 1120px)';

export function useMediaQuery(query) {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mediaQuery = window.matchMedia(query);
    const update = () => setMatches(mediaQuery.matches);
    update();
    mediaQuery.addEventListener('change', update);
    return () => mediaQuery.removeEventListener('change', update);
  }, [query]);
  return matches;
}

const FOCUSABLE = 'button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])';

export function DetailModal({ open, onClose, labelledBy, children }) {
  const dialogRef = useRef(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return undefined;
    const previousFocus = document.activeElement;
    dialogRef.current?.focus();
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== 'Tab' || !dialogRef.current) return;
      const focusable = dialogRef.current.querySelectorAll(FOCUSABLE);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, [open]);

  if (!open) return null;
  return createPortal(
    <div className="sheet-backdrop" role="presentation" onMouseDown={() => onCloseRef.current()}>
      <section
        ref={dialogRef}
        className="sheet-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        tabIndex="-1"
        onMouseDown={(event) => event.stopPropagation()}
      >
        {children}
      </section>
    </div>,
    document.body
  );
}

const BUTTON_VARIANTS = new Set(['primary', 'secondary', 'success', 'warning', 'danger', 'info', 'quiet']);
// Las clases heredadas se conservan porque los tests E2E y algunas vistas las usan como selectores.
const BUTTON_CLASS_NAMES = {
  primary: 'primary-btn', secondary: 'secondary-btn', success: 'success-btn',
  warning: 'warning-btn', danger: 'danger-btn', info: '', quiet: ''
};

export function Button({ as: Component = 'button', variant = 'primary', loading = false, disabled = false, className = '', children, onClick, ...props }) {
  const tone = BUTTON_VARIANTS.has(variant) ? variant : 'primary';
  const isButton = Component === 'button';
  const isDisabled = disabled || loading;
  return (
    <Component
      {...props}
      {...(isButton ? { type: props.type || 'button', disabled: isDisabled } : isDisabled ? { tabIndex: -1 } : {})}
      className={`ui-button ui-button--${tone} ${BUTTON_CLASS_NAMES[tone]} ${className}`.trim()}
      aria-busy={loading || undefined}
      aria-disabled={!isButton && isDisabled ? true : undefined}
      onClick={(event) => {
        if (isDisabled) {
          event.preventDefault();
          return;
        }
        onClick?.(event);
      }}
    >
      {loading && <LoaderCircle className="button-spinner" size={17} aria-hidden="true" />}
      {children}
    </Component>
  );
}

export function PageHeader({ eyebrow, title, titleId, description, icon: Icon, actions, className = '', children }) {
  return (
    <header className={`page-header ${className}`.trim()}>
      <div className="page-header-main">
        {Icon && <span className="page-header-icon" aria-hidden="true"><Icon size={22} /></span>}
        <div className="page-header-text">
          {eyebrow && <p className="page-eyebrow">{eyebrow}</p>}
          <h2 id={titleId}>{title}</h2>
          {description && <p className="page-header-description">{description}</p>}
          {children}
        </div>
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </header>
  );
}

export function FormField({ label, htmlFor, optional = false, hint, hintId, error, className = '', children }) {
  return (
    <label className={`field ui-field ${error ? 'ui-field--error' : ''} ${className}`.trim()} htmlFor={htmlFor}>
      <span className="ui-field-label">{label}{optional && <span className="field-optional"> (opcional)</span>}</span>
      {children}
      {hint && <small id={hintId}>{hint}</small>}
      {error && <small className="ui-field-error">{error}</small>}
    </label>
  );
}

const STATUS_STYLES = {
  PENDIENTE_REVISION: ['pending', 'Pendiente de revisión'],
  CORRECCION_REQUERIDA: ['correction', 'Corrección requerida'],
  APROBADO: ['approved', 'Aprobado'],
  RECHAZADO: ['rejected', 'Rechazado'],
  ACTIVO: ['active', 'Activo'],
  INACTIVO: ['inactive', 'Inactivo']
};

export function getStatusLabel(status) {
  return STATUS_STYLES[status]?.[1] || status?.replaceAll('_', ' ') || 'Sin estado';
}

export function StatusBadge({ status, label, className = '' }) {
  const [tone] = STATUS_STYLES[status] || [''];
  return <span className={`status-badge ui-status-badge ${tone ? `status-badge-${tone}` : ''} ${className}`.trim()}>{label || getStatusLabel(status)}</span>;
}

const FEEDBACK_ICONS = { error: AlertCircle, success: CheckCircle2, info: Info };

export function FeedbackMessage({ tone = 'info', title, children, className = '' }) {
  const Icon = FEEDBACK_ICONS[tone] || Info;
  const role = tone === 'error' ? 'alert' : 'status';
  return (
    <div className={`form-message form-message-${tone} ui-feedback ${className}`.trim()} role={role} aria-live={role === 'status' ? 'polite' : undefined}>
      <Icon size={18} aria-hidden="true" />
      <div className="ui-feedback-content">{title && <strong>{title}</strong>}{children && <div>{children}</div>}</div>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, children, action, loading = false, tone = 'neutral', className = '', ...props }) {
  return (
    <div className={`empty-state ui-empty-state ui-empty-state--${tone} ${className}`.trim()} {...props}>
      {loading
        ? <LoaderCircle className="button-spinner" size={26} aria-hidden="true" />
        : Icon && <span className="empty-state-icon" aria-hidden="true"><Icon size={24} /></span>}
      {title && <strong>{title}</strong>}
      {children && <span>{children}</span>}
      {action && <div className="empty-state-action">{action}</div>}
    </div>
  );
}

export function DataTable({ children, className = '', ...props }) {
  return <table className={`data-table ui-data-table ${className}`.trim()} {...props}>{children}</table>;
}

export function Card({ as: Component = 'section', className = '', children, ...props }) {
  return <Component className={`management-card ui-card ${className}`.trim()} {...props}>{children}</Component>;
}

const FILE_TYPES = {
  pdf: 'pdf', doc: 'word', docx: 'word', xls: 'sheet', xlsx: 'sheet', txt: 'text', xml: 'code'
};

export function FileTypeIcon({ fileName, className = '' }) {
  const extension = fileName?.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
  const tone = FILE_TYPES[extension] || 'generic';
  return (
    <span className={`ui-file-icon ui-file-icon--${tone} ${className}`.trim()} aria-hidden="true">
      {extension ? extension.slice(0, 4).toUpperCase() : <FileText size={17} />}
    </span>
  );
}

export function formatFileSize(bytes) {
  if (!bytes) return '';
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DateTimeStack({ value }) {
  const date = value ? new Date(value) : null;
  if (!date || Number.isNaN(date.getTime())) return <span className="date-stack">—</span>;
  return (
    <time className="date-stack" dateTime={value}>
      <span>{new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short', year: 'numeric' }).format(date)}</span>
      <small>{new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit' }).format(date)}</small>
    </time>
  );
}

export function formatDateTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(date);
}
