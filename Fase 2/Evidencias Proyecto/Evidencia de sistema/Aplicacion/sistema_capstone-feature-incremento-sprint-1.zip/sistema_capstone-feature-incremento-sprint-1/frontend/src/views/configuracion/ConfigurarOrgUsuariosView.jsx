import React, { useCallback, useEffect, useState } from 'react';
import { Edit2, LockKeyhole, Mail, Power, PowerOff, RefreshCw, Search, SearchX, ShieldAlert, ShieldCheck, Trash2, UserCheck, UserPlus, Users, X } from 'lucide-react';
import api from '../../services/api';
import { Button, Card, DataTable, EmptyState, FeedbackMessage, FormField, PageHeader, StatusBadge } from '../../components/ui';

const AVAILABLE_ROLES = [
  { value: 'APPROVER', label: 'Emisor y Revisor' },
  { value: 'ADMIN', label: 'Administrador' }
];

const INITIAL_FORM = {
  email: '',
  firstName: '',
  lastName: '',
  password: '',
  confirmPassword: '',
  roles: ['APPROVER'],
  requirePasswordChange: true
};

function getErrorMessage(error) {
  const problem = error.response?.data;
  const fieldMessage = problem?.invalidFields ? Object.values(problem.invalidFields)[0] : null;
  return fieldMessage || problem?.detail || 'No fue posible completar la operación. Inténtalo nuevamente.';
}

export default function ConfigurarOrgUsuariosView() {
  const [form, setForm] = useState(INITIAL_FORM);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  // Estados para Edición
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [editForm, setEditForm] = useState({
    firstName: '',
    lastName: '',
    newPassword: '',
    confirmPassword: '',
    requirePasswordChange: false
  });

  // Estados para Eliminación
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');

  const loadUsers = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/api/users');
      setUsers(response.data);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const updateField = (event) => {
    const { name, value, checked, type } = event.target;
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const updateEditField = (event) => {
    const { name, value, checked, type } = event.target;
    setEditForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const toggleRole = (role) => {
    setForm((current) => {
      const selected = current.roles.includes(role);
      return {
        ...current,
        roles: selected
          ? current.roles.filter((currentRole) => currentRole !== role)
          : [...current.roles, role]
      };
    });
  };

  // 1. Crear usuario
  const createUser = async (event) => {
    event.preventDefault();
    setError('');
    setSuccess('');

    if (form.roles.length === 0) {
      setError('Selecciona al menos un rol para la cuenta.');
      return;
    }

    if (form.password.length < 8) {
      setError('La contraseña debe contener al menos 8 caracteres.');
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError('Las contraseñas no coinciden. Por favor confirma la contraseña exactamente.');
      return;
    }

    setSubmitting(true);
    try {
      const { confirmPassword, ...createPayload } = form;
      const response = await api.post('/api/users', createPayload);
      setUsers((current) => [...current, response.data].sort((a, b) => a.email.localeCompare(b.email)));
      setSuccess(`La cuenta ${response.data.email} fue creada exitosamente.`);
      setForm(INITIAL_FORM);
      setIsCreateOpen(false);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setSubmitting(false);
    }
  };

  // 2. Modificar usuario (Nombre, Apellido y Contraseña opcional)
  const openEdit = (user) => {
    setError('');
    setSuccess('');
    setEditingUser(user);
    setEditForm({
      firstName: user.firstName,
      lastName: user.lastName,
      newPassword: '',
      confirmPassword: '',
      requirePasswordChange: false
    });
    setIsEditOpen(true);
  };

  const closeEdit = () => {
    if (submitting) return;
    setIsEditOpen(false);
    setEditingUser(null);
  };

  const saveEdit = async (event) => {
    event.preventDefault();
    if (!editingUser) return;
    setError('');
    setSuccess('');

    if (editForm.newPassword) {
      if (editForm.newPassword.length < 8) {
        setError('La nueva contraseña debe contener al menos 8 caracteres.');
        return;
      }
      if (editForm.newPassword !== editForm.confirmPassword) {
        setError('Las nuevas contraseñas no coinciden. Por favor confirma la nueva contraseña.');
        return;
      }
    }

    setSubmitting(true);
    try {
      const payload = {
        firstName: editForm.firstName.trim(),
        lastName: editForm.lastName.trim(),
        ...(editForm.newPassword ? {
          newPassword: editForm.newPassword.trim(),
          requirePasswordChange: editForm.requirePasswordChange
        } : {})
      };

      const response = await api.put(`/api/users/${editingUser.id}`, payload);
      setUsers((current) =>
        current.map((u) => (u.id === editingUser.id ? response.data : u))
      );
      setSuccess(`Datos actualizados correctamente para ${response.data.email}.`);
      setIsEditOpen(false);
      setEditingUser(null);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setSubmitting(false);
    }
  };

  // 3. Desactivar / Activar usuario
  const toggleUserStatus = async (user) => {
    setError('');
    setSuccess('');
    const newEnabledState = !user.enabled;

    try {
      const response = await api.patch(`/api/users/${user.id}/status`, {
        enabled: newEnabledState
      });
      setUsers((current) =>
        current.map((u) => (u.id === user.id ? response.data : u))
      );
      setSuccess(
        newEnabledState
          ? `La cuenta ${user.email} ha sido activada.`
          : `La cuenta ${user.email} ha sido desactivada.`
      );
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    }
  };

  // 4. Eliminar usuario
  const openDelete = (user) => {
    setError('');
    setSuccess('');
    setUserToDelete(user);
    setIsDeleteOpen(true);
  };

  const closeDelete = () => {
    if (submitting) return;
    setIsDeleteOpen(false);
    setUserToDelete(null);
  };

  const confirmDelete = async () => {
    if (!userToDelete) return;
    setError('');
    setSuccess('');
    setSubmitting(true);

    try {
      await api.delete(`/api/users/${userToDelete.id}`);
      setUsers((current) => current.filter((u) => u.id !== userToDelete.id));
      setSuccess(`La cuenta ${userToDelete.email} ha sido eliminada del sistema.`);
      setIsDeleteOpen(false);
      setUserToDelete(null);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setSubmitting(false);
    }
  };

  const openCreateUser = () => {
    setError('');
    setSuccess('');
    setIsCreateOpen(true);
  };

  const closeCreateUser = () => {
    if (submitting) return;
    setError('');
    setForm(INITIAL_FORM);
    setIsCreateOpen(false);
  };

  const normalizedSearch = search.trim().toLowerCase();
  const visibleUsers = normalizedSearch
    ? users.filter((user) => `${user.firstName} ${user.lastName} ${user.email}`.toLowerCase().includes(normalizedSearch))
    : users;
  const activeCount = users.filter((user) => user.enabled).length;
  const adminCount = users.filter((user) => user.roles.includes('ADMIN')).length;

  return (
    <section className="list-page" aria-labelledby="users-title">
      <PageHeader
        eyebrow="Configuración"
        title="Organización y usuarios"
        titleId="users-title"
        description="Administra las cuentas institucionales, actualiza sus datos y controla su acceso a la plataforma."
        icon={Users}
        actions={(
          <Button className="add-user-button" onClick={openCreateUser}>
            <UserPlus size={18} aria-hidden="true" />
            Agregar usuario
          </Button>
        )}
      />

      {success && <FeedbackMessage tone="success" className="page-message">{success}</FeedbackMessage>}
      {!isCreateOpen && !isEditOpen && !isDeleteOpen && error && (
        <FeedbackMessage tone="error" className="page-message">{error}</FeedbackMessage>
      )}

      <Card className="list-card user-list-card">
        <div className="card-header">
          <div>
            <h3>Usuarios registrados</h3>
            <p className="user-summary">
              <span><strong>{users.length}</strong> {users.length === 1 ? 'cuenta' : 'cuentas'}</span>
              <span><strong>{activeCount}</strong> {activeCount === 1 ? 'activa' : 'activas'}</span>
              <span><strong>{users.length - activeCount}</strong> {users.length - activeCount === 1 ? 'inactiva' : 'inactivas'}</span>
              <span><strong>{adminCount}</strong> {adminCount === 1 ? 'administrador' : 'administradores'}</span>
            </p>
          </div>
          <div className="table-header-actions">
            <label className="search-field search-field--compact">
              <Search size={16} aria-hidden="true" />
              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Buscar por nombre o correo"
                aria-label="Buscar usuarios"
              />
            </label>
            <button className="icon-button" type="button" onClick={loadUsers} aria-label="Actualizar usuarios" title="Actualizar" disabled={loading}>
              <RefreshCw size={17} aria-hidden="true" />
            </button>
          </div>
        </div>

        {loading ? (
          <EmptyState loading title="Cargando usuarios…" />
        ) : users.length === 0 ? (
          <EmptyState icon={Users} title="No hay cuentas sincronizadas" action={<Button onClick={openCreateUser}>
              <UserPlus size={17} aria-hidden="true" />
              Agregar usuario
            </Button>}>
            Agrega una cuenta para comenzar a administrar usuarios.
          </EmptyState>
        ) : visibleUsers.length === 0 ? (
          <EmptyState icon={SearchX} title="Sin resultados" action={<Button variant="secondary" onClick={() => setSearch('')}>Limpiar búsqueda</Button>}>
            Ninguna cuenta coincide con “{search.trim()}”.
          </EmptyState>
        ) : (
          <div className="table-scroll">
            <DataTable className="table-stackable users-table">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>Rol</th>
                  <th>Estado</th>
                  <th className="table-actions-cell text-right">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {visibleUsers.map((user) => (
                  <tr key={user.id} data-user-email={user.email}>
                    <td className="cell-primary">
                      <div className="cell-stack cell-person">
                        <strong>{user.firstName} {user.lastName}</strong>
                        <span>{user.email}</span>
                      </div>
                    </td>
                    <td data-label="Rol">
                      <div className="role-badges">
                        {user.roles.map((role) => (
                          <span key={role}>
                            {role === 'APPROVER' ? 'Emisor y Revisor' : role === 'ADMIN' ? 'Administrador' : role}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td data-label="Estado">
                      <StatusBadge status={user.enabled ? 'ACTIVO' : 'INACTIVO'} />
                    </td>
                    <td className="table-actions-cell cell-actions cell-actions--corner">
                      <div className="table-actions">
                        <button
                          type="button"
                          className="action-btn"
                          title="Editar datos de usuario"
                          aria-label={`Editar ${user.email}`}
                          onClick={() => openEdit(user)}
                        >
                          <Edit2 size={15} aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          className={`action-btn ${user.enabled ? 'action-btn-toggle-active' : 'action-btn-toggle-inactive'}`}
                          title={user.enabled ? 'Desactivar usuario' : 'Activar usuario'}
                          aria-label={user.enabled ? `Desactivar ${user.email}` : `Activar ${user.email}`}
                          onClick={() => toggleUserStatus(user)}
                        >
                          {user.enabled ? <PowerOff size={15} aria-hidden="true" /> : <Power size={15} aria-hidden="true" />}
                        </button>
                        <button
                          type="button"
                          className="action-btn action-btn-danger"
                          title="Eliminar usuario"
                          aria-label={`Eliminar ${user.email}`}
                          onClick={() => openDelete(user)}
                        >
                          <Trash2 size={15} aria-hidden="true" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </div>
        )}
      </Card>

      {/* Modal: Crear Usuario */}
      {isCreateOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeCreateUser}>
          <form
            className="management-card user-form user-form-modal"
            onSubmit={createUser}
            role="dialog"
            aria-modal="true"
            aria-labelledby="create-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <UserPlus size={20} aria-hidden="true" />
                <div>
                  <h3 id="create-user-title">Agregar usuario</h3>
                  <p>La cuenta se registrará en Keycloak y en la base de datos del sistema.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeCreateUser} aria-label="Cerrar formulario" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="form-grid">
              <FormField label="Correo electrónico" className="field-wide">
                <span className="field-control-with-icon">
                  <Mail size={18} aria-hidden="true" />
                  <input type="email" name="email" value={form.email} onChange={updateField} placeholder="nombre@institucion.cl" autoComplete="off" autoFocus required />
                </span>
              </FormField>

              <FormField label="Nombre">
                <input type="text" name="firstName" value={form.firstName} onChange={updateField} required />
              </FormField>

              <FormField label="Apellido">
                <input type="text" name="lastName" value={form.lastName} onChange={updateField} required />
              </FormField>

              <FormField label="Contraseña inicial" hint="Mínimo 8 caracteres.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="password"
                    value={form.password}
                    onChange={updateField}
                    minLength={8}
                    autoComplete="new-password"
                    required
                  />
                </span>
              </FormField>

              <FormField label="Confirmar contraseña" hint="Debe coincidir con la contraseña inicial.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="confirmPassword"
                    value={form.confirmPassword}
                    onChange={updateField}
                    minLength={8}
                    autoComplete="new-password"
                    required
                  />
                </span>
              </FormField>
            </div>

            <fieldset className="role-selector">
              <legend>Roles de acceso</legend>
              {AVAILABLE_ROLES.map((role) => (
                <label key={role.value} className="role-option">
                  <input type="checkbox" checked={form.roles.includes(role.value)} onChange={() => toggleRole(role.value)} />
                  <ShieldCheck size={17} aria-hidden="true" />
                  <span>{role.label}</span>
                </label>
              ))}
            </fieldset>

            <label className="password-policy-option">
              <input type="checkbox" name="requirePasswordChange" checked={form.requirePasswordChange} onChange={updateField} />
              <span>Solicitar cambio de contraseña en el primer inicio de sesión</span>
            </label>

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeCreateUser} disabled={submitting}>Cancelar</Button>
              <Button type="submit" disabled={submitting}>
                <UserPlus size={18} aria-hidden="true" />
                {submitting ? 'Creando cuenta…' : 'Crear cuenta'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Editar Usuario (Solo Nombre y Apellido para Sprint 1) */}
      {isEditOpen && editingUser && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeEdit}>
          <form
            className="management-card user-form user-form-modal"
            onSubmit={saveEdit}
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <Edit2 size={20} aria-hidden="true" />
                <div>
                  <h3 id="edit-user-title">Editar usuario</h3>
                  <p>Modifica el nombre y apellido del usuario institucional.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeEdit} aria-label="Cerrar formulario" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="form-grid">
              <FormField label="Correo electrónico" className="field-wide">
                <span className="field-control-with-icon">
                  <Mail size={18} aria-hidden="true" />
                  <input type="email" value={editingUser.email} disabled />
                </span>
              </FormField>

              <FormField label="Nombre">
                <input
                  type="text"
                  name="firstName"
                  value={editForm.firstName}
                  onChange={updateEditField}
                  autoFocus
                  required
                />
              </FormField>

              <FormField label="Apellido">
                <input
                  type="text"
                  name="lastName"
                  value={editForm.lastName}
                  onChange={updateEditField}
                  required
                />
              </FormField>

              <FormField label="Nueva contraseña" optional hint="Mínimo 8 caracteres si se modifica.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="newPassword"
                    value={editForm.newPassword}
                    onChange={updateEditField}
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Dejar en blanco para conservar"
                  />
                </span>
              </FormField>

              <FormField label="Confirmar nueva contraseña" hint="Debe coincidir con la nueva contraseña.">
                <span className="field-control-with-icon">
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    type="password"
                    name="confirmPassword"
                    value={editForm.confirmPassword}
                    onChange={updateEditField}
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Repetir nueva contraseña"
                    disabled={!editForm.newPassword}
                    required={!!editForm.newPassword}
                  />
                </span>
              </FormField>
            </div>

            {editForm.newPassword && (
              <label className="password-policy-option" style={{ marginTop: '0.85rem' }}>
                <input
                  type="checkbox"
                  name="requirePasswordChange"
                  checked={editForm.requirePasswordChange}
                  onChange={updateEditField}
                />
                <span>Solicitar cambio de contraseña en el próximo inicio de sesión</span>
              </label>
            )}

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeEdit} disabled={submitting}>Cancelar</Button>
              <Button type="submit" disabled={submitting}>
                <UserCheck size={18} aria-hidden="true" />
                {submitting ? 'Guardando…' : 'Guardar cambios'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Confirmación Eliminar Usuario */}
      {isDeleteOpen && userToDelete && (
        <div className="modal-backdrop" role="presentation" onMouseDown={closeDelete}>
          <div
            className="management-card user-form user-form-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-user-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="management-card-header">
              <div className="management-card-title">
                <ShieldAlert size={20} color="#dc2626" aria-hidden="true" />
                <div>
                  <h3 id="delete-user-title">Eliminar usuario</h3>
                  <p>Esta acción no se puede deshacer.</p>
                </div>
              </div>
              <button className="icon-button" type="button" onClick={closeDelete} aria-label="Cerrar diálogo" disabled={submitting}>
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="confirm-dialog-content">
              <p>
                ¿Estás seguro de que deseas eliminar permanentemente la cuenta de{' '}
                <strong>{userToDelete.firstName} {userToDelete.lastName}</strong> (<code>{userToDelete.email}</code>)?
              </p>
              <p style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)' }}>
                El usuario será removido del directorio de autenticación y de la base de datos del sistema.
              </p>
            </div>

            {error && <FeedbackMessage tone="error">{error}</FeedbackMessage>}

            <div className="modal-actions">
              <Button variant="secondary" onClick={closeDelete} disabled={submitting}>Cancelar</Button>
              <Button variant="danger" onClick={confirmDelete} disabled={submitting}>
                <Trash2 size={17} aria-hidden="true" />
                {submitting ? 'Eliminando…' : 'Eliminar usuario'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

