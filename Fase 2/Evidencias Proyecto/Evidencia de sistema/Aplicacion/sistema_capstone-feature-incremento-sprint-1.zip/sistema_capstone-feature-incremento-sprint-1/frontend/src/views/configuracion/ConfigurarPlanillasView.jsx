import React from 'react';

export default function ConfigurarPlanillasView() {
  return (
    <div className="view-container">
      <h2>Configuración del Negocio: Configurar Planillas</h2>
      <p>Gestión de plantillas dinámicas y formularios para emisión estandarizada de documentos.</p>
    </div>
  );
}
