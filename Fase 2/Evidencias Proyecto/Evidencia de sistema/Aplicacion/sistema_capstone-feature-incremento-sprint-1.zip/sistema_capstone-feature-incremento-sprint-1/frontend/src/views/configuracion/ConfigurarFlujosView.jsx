import React from 'react';

export default function ConfigurarFlujosView() {
  return (
    <div className="view-container">
      <h2>Configuración del Negocio: Configurar Flujos</h2>
      <p>Definición de etapas, reglas de transición y niveles de aprobación de documentos.</p>
    </div>
  );
}
