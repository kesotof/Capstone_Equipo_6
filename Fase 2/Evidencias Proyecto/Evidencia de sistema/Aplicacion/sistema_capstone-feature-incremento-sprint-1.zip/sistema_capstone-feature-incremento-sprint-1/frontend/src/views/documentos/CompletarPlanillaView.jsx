import React from 'react';

export default function CompletarPlanillaView() {
  return (
    <div className="view-container">
      <h2>Gestión de Documentos: Completar Planilla</h2>
      <p>Formulario dinámico para generación de documentos a partir de plantillas preconfiguradas.</p>
    </div>
  );
}
