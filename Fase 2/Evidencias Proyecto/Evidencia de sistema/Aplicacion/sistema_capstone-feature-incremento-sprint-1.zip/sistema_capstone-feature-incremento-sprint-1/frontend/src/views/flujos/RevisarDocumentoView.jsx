import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Download,
  Eye,
  FileCheck2,
  FileEdit,
  FileText,
  FileX2,
  FilterX,
  Info,
  ListChecks,
  LoaderCircle,
  Search,
  SlidersHorizontal,
  UserRound,
  X
} from 'lucide-react';
import api from '../../services/api';
import { Button, DataTable, DateTimeStack, EmptyState, FeedbackMessage, FileTypeIcon, FormField, PageHeader, StatusBadge } from '../../components/ui';

const PAGE_SIZE = 10;
const INITIAL_FILTERS = { nombreArchivo: '', emisor: '', fechaDesde: '', fechaHasta: '', estado: 'PENDIENTE_REVISION' };
const EMPTY_RESULT = { contenido: [], pagina: 0, tamanio: PAGE_SIZE, totalElementos: 0, totalPaginas: 0, primera: true, ultima: true };
const STATUS_OPTIONS = [
  { value: 'PENDIENTE_REVISION', label: 'Pendiente de revisión' },
  { value: 'CORRECCION_REQUERIDA', label: 'Corrección requerida' },
  { value: 'APROBADO', label: 'Aprobado' },
  { value: 'RECHAZADO', label: 'Rechazado' }
];
const WEEK_DAYS = ['lu', 'ma', 'mi', 'ju', 'vi', 'sá', 'do'];
const CALENDAR_WIDTH = 288;

function toIsoDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function fromIsoDate(value) {
  if (!value) return null;
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function formatFilterDate(value) {
  const date = fromIsoDate(value);
  return date ? new Intl.DateTimeFormat('es-CL').format(date) : 'Seleccionar fecha';
}

function getCalendarDays(monthDate) {
  const firstDay = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
  const mondayOffset = (firstDay.getDay() + 6) % 7;
  const start = new Date(firstDay);
  start.setDate(firstDay.getDate() - mondayOffset);
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return date;
  });
}

function useDismissPopover(ref, open, onClose) {
  useEffect(() => {
    if (!open) return undefined;
    const handlePointerDown = (event) => {
      if (!ref.current?.contains(event.target)) onClose();
    };
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [open, onClose, ref]);
}

function DateFilter({ label, name, value, min, max, onChange }) {
  const containerRef = useRef(null);
  const [open, setOpen] = useState(false);
  const [alignEnd, setAlignEnd] = useState(false);
  const [visibleMonth, setVisibleMonth] = useState(() => fromIsoDate(value) || new Date());
  const close = useCallback(() => setOpen(false), []);
  useDismissPopover(containerRef, open, close);

  const toggle = () => {
    if (!open) {
      setVisibleMonth(fromIsoDate(value) || new Date());
      const bounds = containerRef.current?.getBoundingClientRect();
      setAlignEnd(Boolean(bounds && bounds.left + CALENDAR_WIDTH > window.innerWidth - 12));
    }
    setOpen((current) => !current);
  };
  const selectDate = (date) => {
    onChange(name, toIsoDate(date));
    setOpen(false);
  };
  const today = toIsoDate(new Date());
  const days = getCalendarDays(visibleMonth);
  const rawMonthLabel = new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric' }).format(visibleMonth);
  const monthLabel = rawMonthLabel.charAt(0).toUpperCase() + rawMonthLabel.slice(1);

  return (
    <div className="review-date-field">
      <span>{label}</span>
      <div className="review-picker" ref={containerRef}>
        <button className="review-filter-trigger" type="button" onClick={toggle} aria-haspopup="dialog" aria-expanded={open} data-testid={`${name}-trigger`}>
          <CalendarDays size={16} aria-hidden="true" />
          <span className={value ? '' : 'review-filter-placeholder'}>{formatFilterDate(value)}</span>
          <ChevronDown className="review-filter-chevron" size={15} aria-hidden="true" />
        </button>
        {open && (
          <div className={`review-calendar${alignEnd ? ' review-calendar--end' : ''}`} role="dialog" aria-label={`Seleccionar ${label.toLowerCase()}`}>
            <div className="review-calendar-header">
              <strong>{monthLabel}</strong>
              <div>
                <button type="button" onClick={() => setVisibleMonth((current) => new Date(current.getFullYear(), current.getMonth() - 1, 1))} aria-label="Mes anterior"><ChevronLeft size={17} /></button>
                <button type="button" onClick={() => setVisibleMonth((current) => new Date(current.getFullYear(), current.getMonth() + 1, 1))} aria-label="Mes siguiente"><ChevronRight size={17} /></button>
              </div>
            </div>
            <div className="review-calendar-grid review-calendar-weekdays">{WEEK_DAYS.map((day) => <span key={day}>{day}</span>)}</div>
            <div className="review-calendar-grid">
              {days.map((date) => {
                const isoDate = toIsoDate(date);
                const outsideMonth = date.getMonth() !== visibleMonth.getMonth();
                const disabled = Boolean((min && isoDate < min) || (max && isoDate > max));
                return <button key={isoDate} className={`${outsideMonth ? 'is-outside' : ''} ${isoDate === value ? 'is-selected' : ''} ${isoDate === today ? 'is-today' : ''}`} type="button" onClick={() => selectDate(date)} disabled={disabled} data-value={isoDate}>{date.getDate()}</button>;
              })}
            </div>
            <div className="review-calendar-footer">
              <button type="button" onClick={() => { onChange(name, ''); setOpen(false); }} disabled={!value}>Borrar</button>
              <button type="button" onClick={() => selectDate(new Date())} disabled={Boolean((min && today < min) || (max && today > max))}>Hoy</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusFilter({ value, onChange }) {
  const containerRef = useRef(null);
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  useDismissPopover(containerRef, open, close);
  const selected = STATUS_OPTIONS.find((option) => option.value === value) || STATUS_OPTIONS[0];

  return (
    <div className="review-filter-field">
      <span>Estado</span>
      <div className="review-picker" ref={containerRef}>
        <button className="review-filter-trigger" type="button" onClick={() => setOpen((current) => !current)} aria-haspopup="listbox" aria-expanded={open}>
          <span>{selected.label}</span>
          <ChevronDown className="review-filter-chevron" size={15} aria-hidden="true" />
        </button>
        {open && <div className="review-status-menu" role="listbox" aria-label="Estado de la solicitud">{STATUS_OPTIONS.map((option) => <button key={option.value} className={option.value === value ? 'is-selected' : ''} type="button" role="option" aria-selected={option.value === value} onClick={() => { onChange('estado', option.value); setOpen(false); }}><span>{option.label}</span>{option.value === value && <Check size={16} aria-hidden="true" />}</button>)}</div>}
      </div>
    </div>
  );
}

function getErrorMessage(error, fallback) {
  return error?.response?.data?.detail || error?.response?.data?.message || fallback;
}

function formatDate(value) {
  if (!value) return 'Sin fecha';
  return new Intl.DateTimeFormat('es-CL', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

function formatFileSize(bytes) {
  if (!bytes) return '';
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function canPreview(documento) {
  return ['pdf', 'txt', 'xml'].includes(documento?.nombreArchivo?.split('.').pop()?.toLowerCase());
}

export default function RevisarDocumentoView() {
  const [searchParams] = useSearchParams();
  const queryId = searchParams.get('id');
  const [filters, setFilters] = useState(INITIAL_FILTERS);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [debouncedFilters, setDebouncedFilters] = useState(INITIAL_FILTERS);
  const [page, setPage] = useState(0);
  const [result, setResult] = useState(EMPTY_RESULT);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [selectedSolicitud, setSelectedSolicitud] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [previewError, setPreviewError] = useState('');
  const [activeModal, setActiveModal] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [modalError, setModalError] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const detailDialogRef = useRef(null);
  const lastFocusedElementRef = useRef(null);
  const activeModalRef = useRef(null);
  const actionDialogRef = useRef(null);
  const modalTriggerRef = useRef(null);
  const actionInFlightRef = useRef(false);
  const reviewTableRef = useRef(null);

  activeModalRef.current = activeModal;

  const fetchPendientes = useCallback(async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const response = await api.get('/api/solicitudes/pendientes-revision', {
        params: {
          nombreArchivo: debouncedFilters.nombreArchivo || undefined,
          emisor: debouncedFilters.emisor || undefined,
          fechaDesde: debouncedFilters.fechaDesde ? `${debouncedFilters.fechaDesde}T00:00:00Z` : undefined,
          fechaHasta: debouncedFilters.fechaHasta ? `${debouncedFilters.fechaHasta}T23:59:59Z` : undefined,
          estado: debouncedFilters.estado || undefined,
          pagina: page,
          tamanio: PAGE_SIZE
        }
      });
      setResult(response.data);
    } catch (error) {
      setResult(EMPTY_RESULT);
      setErrorMessage(getErrorMessage(error, 'No fue posible cargar las solicitudes pendientes.'));
    } finally {
      setLoading(false);
    }
  }, [debouncedFilters, page]);

  useEffect(() => {
    const timeout = window.setTimeout(() => setDebouncedFilters(filters), 350);
    return () => window.clearTimeout(timeout);
  }, [filters]);

  useEffect(() => setPage(0), [debouncedFilters]);
  useEffect(() => { fetchPendientes(); }, [fetchPendientes]);
  useEffect(() => { if (queryId) setSelectedId(queryId); }, [queryId]);

  useEffect(() => {
    if (!selectedId) return undefined;
    const controller = new AbortController();
    setLoadingDetail(true);
    setPreviewError('');
    setPreviewUrl(null);
    api.get(`/api/solicitudes/${selectedId}`, { signal: controller.signal })
      .then((response) => setSelectedSolicitud(response.data))
      .catch((error) => {
        if (error.code !== 'ERR_CANCELED') {
          setErrorMessage(getErrorMessage(error, 'No fue posible cargar el detalle de la solicitud.'));
          setSelectedId(null);
        }
      })
      .finally(() => { if (!controller.signal.aborted) setLoadingDetail(false); });
    return () => controller.abort();
  }, [selectedId]);

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  const updateFilter = (event) => setFilters((current) => ({ ...current, [event.target.name]: event.target.value }));
  const updateFilterValue = (name, value) => setFilters((current) => ({ ...current, [name]: value }));
  const openDetailModal = (solicitudId) => {
    lastFocusedElementRef.current = document.activeElement;
    setSelectedId(solicitudId);
  };
  const closeDetailModal = useCallback(() => {
    setSelectedId(null);
    setSelectedSolicitud(null);
    setPreviewError('');
    setPreviewUrl(null);
  }, []);

  useEffect(() => {
    if (!selectedId) return undefined;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const focusFrame = window.requestAnimationFrame(() => detailDialogRef.current?.focus());

    const handleKeyDown = (event) => {
      if (event.key === 'Escape' && !activeModalRef.current) {
        event.preventDefault();
        closeDetailModal();
        return;
      }

      if (event.key !== 'Tab' || activeModalRef.current || !detailDialogRef.current) return;
      const focusableElements = detailDialogRef.current.querySelectorAll(
        'button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
      );
      if (focusableElements.length === 0) return;
      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];

      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = previousOverflow;
      if (lastFocusedElementRef.current?.isConnected) {
        lastFocusedElementRef.current.focus();
      } else {
        reviewTableRef.current?.focus();
      }
    };
  }, [closeDetailModal, selectedId]);

  const handleDownload = async () => {
    const documento = selectedSolicitud?.documentoVigente;
    if (!documento) return;
    try {
      const response = await api.get(`/api/solicitudes/${selectedSolicitud.id}/documento/descargar`, { responseType: 'blob' });
      const url = URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = documento.nombreArchivo;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 0);
    } catch (error) {
      setPreviewError(getErrorMessage(error, 'No fue posible descargar el documento.'));
    }
  };

  const handlePreview = async () => {
    if (!selectedSolicitud?.documentoVigente) return;
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
      return;
    }
    try {
      setPreviewError('');
      const response = await api.get(`/api/solicitudes/${selectedSolicitud.id}/documento/descargar`, { responseType: 'blob' });
      setPreviewUrl(URL.createObjectURL(response.data));
    } catch (error) {
      setPreviewError(getErrorMessage(error, 'No fue posible previsualizar el documento.'));
    }
  };

  const openModal = (type) => {
    if (actionInFlightRef.current) return;
    modalTriggerRef.current = document.activeElement;
    setSuccessMessage(null);
    setActiveModal(type);
    setCommentText('');
    setModalError('');
  };
  const resetActionModal = useCallback(() => {
    setActiveModal(null);
    setCommentText('');
    setModalError('');
  }, []);
  const closeModal = useCallback(() => {
    if (!actionInFlightRef.current) resetActionModal();
  }, [resetActionModal]);

  useEffect(() => {
    if (!activeModal) return undefined;
    const focusFrame = window.requestAnimationFrame(() => {
      const target = activeModal === 'aprobar'
        ? actionDialogRef.current?.querySelector('.review-action-cancel')
        : actionDialogRef.current?.querySelector('textarea');
      (target || actionDialogRef.current)?.focus();
    });
    const handleActionKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeModal();
        return;
      }
      if (event.key !== 'Tab' || !actionDialogRef.current) return;
      const focusable = actionDialogRef.current.querySelectorAll('button:not(:disabled), textarea:not(:disabled)');
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', handleActionKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.removeEventListener('keydown', handleActionKeyDown);
      modalTriggerRef.current?.focus?.();
    };
  }, [activeModal, closeModal]);

  const handleExecuteAction = async () => {
    if (!selectedSolicitud || !activeModal || actionInFlightRef.current) return;
    if ((activeModal === 'rechazar' || activeModal === 'corregir') && !commentText.trim()) {
      setModalError(activeModal === 'rechazar' ? 'Es obligatorio indicar el motivo del rechazo.' : 'Es obligatorio indicar las observaciones para que el emisor pueda corregir.');
      return;
    }

    const actionConfig = {
      aprobar: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/aprobar`, payload: {}, status: 'APROBADO', title: 'Documento aprobado', detail: 'La solicitud fue aprobada exitosamente. La decisión quedó registrada y el emisor recibirá una notificación.' },
      rechazar: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/rechazar`, payload: { motivo: commentText.trim(), notificarEmail: true }, status: 'RECHAZADO', title: 'Documento rechazado', detail: 'La solicitud fue rechazada exitosamente. La decisión y su motivo quedaron registrados.' },
      corregir: { endpoint: `/api/solicitudes/${selectedSolicitud.id}/pedir-correccion`, payload: { observacion: commentText.trim(), notificarEmail: false }, status: 'CORRECCION_REQUERIDA', title: 'Corrección solicitada', detail: 'El emisor podrá consultar tus observaciones y reenviar el documento.' }
    }[activeModal];

    actionInFlightRef.current = true;
    setActionLoading(true);
    setModalError('');
    try {
      await api.post(actionConfig.endpoint, actionConfig.payload);
      setSuccessMessage({ title: actionConfig.title, detail: actionConfig.detail });
      setResult((current) => {
        if (!current.contenido.some((item) => item.id === selectedSolicitud.id)) return current;
        const remainsInFilter = debouncedFilters.estado === actionConfig.status;
        const contenido = remainsInFilter
          ? current.contenido.map((item) => item.id === selectedSolicitud.id ? { ...item, estado: actionConfig.status } : item)
          : current.contenido.filter((item) => item.id !== selectedSolicitud.id);
        const totalElementos = Math.max(0, current.totalElementos - (remainsInFilter ? 0 : 1));
        const totalPaginas = Math.ceil(totalElementos / PAGE_SIZE);
        return { ...current, contenido, totalElementos, totalPaginas, ultima: current.pagina >= totalPaginas - 1 };
      });
      resetActionModal();
      closeDetailModal();
      if (page > 0 && result.contenido.length === 1 && debouncedFilters.estado !== actionConfig.status) {
        setPage(page - 1);
      } else {
        void fetchPendientes();
      }
    } catch (error) {
      setModalError(getErrorMessage(error, 'Ocurrió un error al procesar la acción.'));
    } finally {
      actionInFlightRef.current = false;
      setActionLoading(false);
    }
  };

  const activeFilterCount = Object.entries(filters).filter(([key, value]) => key === 'estado' ? value !== INITIAL_FILTERS.estado : Boolean(value)).length;
  const hasActiveFilters = activeFilterCount > 0;

  return (
    <section className="review-inbox-page" aria-labelledby="revisar-title">
      <PageHeader
        eyebrow="Flujos de aprobación"
        title="Revisar documentos"
        titleId="revisar-title"
        description="Filtra la bandeja, revisa el contenido de cada solicitud y registra tu decisión."
        icon={ListChecks}
        actions={<div className="review-count" aria-live="polite"><FileCheck2 size={18} aria-hidden="true" /><span><strong>{result.totalElementos}</strong> {result.totalElementos === 1 ? 'resultado' : 'resultados'}</span></div>}
      />

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}
      {successMessage && <div className="review-feedback-toast page-message form-message-success" role="status" aria-live="polite"><span className="review-feedback-icon" aria-hidden="true"><CheckCircle2 size={21} /></span><div><strong>{successMessage.title}</strong><p>{successMessage.detail}</p></div><button type="button" onClick={() => setSuccessMessage(null)} aria-label="Cerrar notificación"><X size={17} aria-hidden="true" /></button></div>}

      <button className="review-filter-toggle" type="button" onClick={() => setFiltersOpen((open) => !open)} aria-expanded={filtersOpen} aria-controls="review-filters">
        <SlidersHorizontal size={17} aria-hidden="true" />
        <span>Filtros</span>
        {activeFilterCount > 0 && <span className="filter-chip-count" aria-label={`${activeFilterCount} activos`}>{activeFilterCount}</span>}
        <ChevronDown className="review-filter-chevron" size={16} aria-hidden="true" />
      </button>

      <section id="review-filters" className={`review-filter-card${filtersOpen ? ' is-open' : ''}`} aria-label="Filtros de solicitudes">
        <div className="review-filter-fields">
          <label className="review-filter-field"><span>Nombre del archivo</span><div className="review-filter-input"><Search size={17} aria-hidden="true" /><input name="nombreArchivo" value={filters.nombreArchivo} onChange={updateFilter} placeholder="Ej. contrato" /></div></label>
          <label className="review-filter-field"><span>Emisor</span><div className="review-filter-input"><UserRound size={17} aria-hidden="true" /><input name="emisor" value={filters.emisor} onChange={updateFilter} placeholder="Nombre o correo" /></div></label>
          <DateFilter label="Desde" name="fechaDesde" value={filters.fechaDesde} max={filters.fechaHasta} onChange={updateFilterValue} />
          <DateFilter label="Hasta" name="fechaHasta" value={filters.fechaHasta} min={filters.fechaDesde} onChange={updateFilterValue} />
          <StatusFilter value={filters.estado} onChange={updateFilterValue} />
        </div>
        <Button variant="secondary" className="review-clear-filters" onClick={() => setFilters(INITIAL_FILTERS)} disabled={!hasActiveFilters}><FilterX size={17} aria-hidden="true" />Limpiar filtros</Button>
      </section>

      <section ref={reviewTableRef} className="review-table-card" aria-label="Resultados de solicitudes pendientes" tabIndex="-1">
        <div className="review-table-heading"><div><h3>Bandeja de revisión</h3><p>{loading ? 'Actualizando resultados…' : `${result.totalElementos} solicitud${result.totalElementos === 1 ? '' : 'es'} encontrada${result.totalElementos === 1 ? '' : 's'}`}</p></div>{loading && <LoaderCircle className="button-spinner" size={20} aria-label="Cargando solicitudes" />}</div>
        {!loading && result.contenido.length === 0 ? (
          <EmptyState icon={CheckCircle2} tone="success" title="Bandeja al día" data-testid="empty-pendientes">No hay solicitudes para los filtros seleccionados.</EmptyState>
        ) : (
          <div className="table-scroll"><DataTable className="review-data-table table-stackable"><thead><tr><th>Documento</th><th>Emisor</th><th>Fecha de envío</th><th>Estado</th><th><span className="visually-hidden">Acciones</span></th></tr></thead><tbody>
            {result.contenido.map((solicitud) => <tr key={solicitud.id} className="clickable-row" onClick={() => openDetailModal(solicitud.id)} data-testid={`solicitud-row-${solicitud.id}`}>
              <td className="cell-primary"><div className="cell-with-icon"><FileTypeIcon fileName={solicitud.nombreArchivo} /><div className="cell-stack"><strong>{solicitud.titulo}</strong><span>{solicitud.nombreArchivo || 'Sin archivo'}</span></div></div></td>
              <td className="cell-wide" data-label="Emisor"><div className="cell-stack cell-person"><strong>{solicitud.emisorNombre}</strong><span>{solicitud.emisorEmail}</span></div></td>
              <td data-label="Fecha de envío"><DateTimeStack value={solicitud.fechaCreacion} /></td>
              <td data-label="Estado"><StatusBadge status={solicitud.estado} /></td>
              <td className="table-actions-cell cell-actions cell-actions--corner"><button className="action-btn review-open-detail" type="button" onClick={(event) => { event.stopPropagation(); openDetailModal(solicitud.id); }} aria-label={`Abrir detalle de ${solicitud.titulo}`}><Eye size={17} aria-hidden="true" /></button></td>
            </tr>)}
          </tbody></DataTable></div>
        )}
        <nav className="review-pagination" aria-label="Paginación de solicitudes"><span>Página {result.totalPaginas === 0 ? 0 : result.pagina + 1} de {result.totalPaginas}</span><div><Button variant="secondary" onClick={() => setPage((current) => current - 1)} disabled={loading || result.primera}><ChevronLeft size={17} aria-hidden="true" />Anterior</Button><Button variant="secondary" onClick={() => setPage((current) => current + 1)} disabled={loading || result.ultima}>Siguiente<ChevronRight size={17} aria-hidden="true" /></Button></div></nav>
      </section>

      {selectedId && <div className="review-detail-backdrop" role="presentation" onMouseDown={closeDetailModal}><section ref={detailDialogRef} className="review-detail-modal" role="dialog" aria-modal="true" aria-labelledby="review-detail-title" tabIndex="-1" onMouseDown={(event) => event.stopPropagation()}>
        <header className="review-detail-modal-header"><div><p className="page-eyebrow">Detalle y revisión</p><h3 id="review-detail-title">{selectedSolicitud?.titulo || 'Cargando solicitud…'}</h3></div><button className="action-btn" type="button" onClick={closeDetailModal} aria-label="Cerrar detalle"><X size={18} aria-hidden="true" /></button></header>
        <div className="review-detail-modal-content detail-card-body">
          {loadingDetail || !selectedSolicitud ? <EmptyState loading title="Cargando detalle…" /> : <>
            <div className="review-summary-card"><div><span>Emisor</span><strong>{selectedSolicitud.emisorNombre}</strong><small>{selectedSolicitud.emisorEmail}</small></div><div><span>Fecha</span><strong>{formatDate(selectedSolicitud.createdAt)}</strong></div><div><span>Estado</span><StatusBadge status={selectedSolicitud.estado} /></div></div>
            <section className="review-detail-section"><h4>Título</h4><p data-testid="detail-title">{selectedSolicitud.titulo}</p><h4>Descripción</h4><p>{selectedSolicitud.descripcion || 'Sin descripción informada por el emisor.'}</p></section>
            <section className="review-detail-section"><h4>Documento adjunto vigente</h4>{selectedSolicitud.documentoVigente ? <><div className="review-attachment-card"><FileTypeIcon fileName={selectedSolicitud.documentoVigente.nombreArchivo} /><div><strong title={selectedSolicitud.documentoVigente.nombreArchivo}>{selectedSolicitud.documentoVigente.nombreArchivo}</strong><span>{formatFileSize(selectedSolicitud.documentoVigente.sizeBytes)} · Versión {selectedSolicitud.documentoVigente.version}</span></div></div><div className="review-attachment-actions"><Button variant="secondary" onClick={handleDownload} data-testid="btn-descargar"><Download size={16} aria-hidden="true" />Descargar</Button>{canPreview(selectedSolicitud.documentoVigente) && <Button variant="secondary" onClick={handlePreview} aria-pressed={Boolean(previewUrl)}><Eye size={16} aria-hidden="true" />{previewUrl ? 'Ocultar vista previa' : 'Previsualizar'}</Button>}</div>{previewError && <FeedbackMessage tone="error">{previewError}</FeedbackMessage>}{previewUrl && <div className="review-preview-shell"><iframe className="review-file-preview" title={`Previsualización de ${selectedSolicitud.documentoVigente.nombreArchivo}`} src={`${previewUrl}#view=FitH&zoom=page-width`} /></div>}</> : <p>La solicitud no tiene un archivo adjunto.</p>}</section>
          </>}
        </div>
        {selectedSolicitud?.estado === 'PENDIENTE_REVISION' && <footer className="review-detail-modal-footer"><span>Acciones de revisión</span><div className="detail-actions-bar"><Button variant="success" onClick={() => openModal('aprobar')} data-testid="btn-aprobar"><FileCheck2 size={18} aria-hidden="true" />Aprobar</Button><Button variant="warning" onClick={() => openModal('corregir')} data-testid="btn-pedir-correccion"><FileEdit size={18} aria-hidden="true" />Pedir corrección</Button><Button variant="danger" onClick={() => openModal('rechazar')} data-testid="btn-rechazar"><FileX2 size={18} aria-hidden="true" />Rechazar</Button></div></footer>}
      </section></div>}

      {activeModal && <div className="modal-backdrop" role="presentation"><section ref={actionDialogRef} className="management-card user-form-modal review-action-modal" role="dialog" aria-modal="true" aria-labelledby="review-action-title" aria-describedby="review-action-description" tabIndex="-1">
        <header className="review-action-header">
          <span className={`review-action-icon review-action-icon-${activeModal}`} aria-hidden="true">{activeModal === 'aprobar' ? <FileCheck2 size={24} /> : activeModal === 'corregir' ? <FileEdit size={24} /> : <FileX2 size={24} />}</span>
          <div><span className="review-action-eyebrow">Decisión sobre la solicitud</span><h3 id="review-action-title">{activeModal === 'aprobar' ? 'Aprobar documento' : activeModal === 'corregir' ? 'Solicitar correcciones' : 'Rechazar documento'}</h3><p id="review-action-description">{activeModal === 'aprobar' ? 'Confirma la aprobación antes de cambiar el estado del documento.' : 'Tu mensaje quedará registrado y será visible para el emisor.'}</p></div>
          <button className="action-btn review-action-close" type="button" onClick={closeModal} disabled={actionLoading} aria-label="Cerrar confirmación"><X size={18} aria-hidden="true" /></button>
        </header>
        <div className="review-action-body">
          {modalError && <div className="form-message form-message-error review-action-error" role="alert"><AlertCircle size={18} aria-hidden="true" /><span>{modalError}</span></div>}
          <div className="review-action-document"><span aria-hidden="true"><FileText size={19} /></span><div><small>Solicitud seleccionada</small><strong>{selectedSolicitud?.titulo}</strong><span>{selectedSolicitud?.emisorNombre || selectedSolicitud?.emisorEmail}</span></div></div>
          {activeModal === 'aprobar' ? <>
            <div className="review-action-transition" aria-label="El estado cambiará de Pendiente de revisión a Aprobado"><StatusBadge status="PENDIENTE_REVISION" /><ArrowRight size={18} aria-hidden="true" /><StatusBadge status="APROBADO" /></div>
            <p className="review-action-note"><Info size={17} aria-hidden="true" />La aprobación quedará en el historial y se notificará al emisor.</p>
          </> : <FormField label={activeModal === 'corregir' ? 'Observaciones de mejora *' : 'Motivo del rechazo *'} htmlFor="modal-comment" className="review-action-comment"><textarea id="modal-comment" data-testid="modal-comment-input" value={commentText} onChange={(event) => setCommentText(event.target.value)} disabled={actionLoading} maxLength="2000" rows="4" placeholder={activeModal === 'corregir' ? 'Indica qué debe corregir el emisor…' : 'Explica por qué se rechaza el documento…'} /></FormField>}
        </div>
        <footer className="review-action-footer"><Button variant="secondary" className="review-action-cancel" onClick={closeModal} disabled={actionLoading}>Cancelar</Button><Button variant={activeModal === 'aprobar' ? 'success' : activeModal === 'corregir' ? 'warning' : 'danger'} onClick={handleExecuteAction} disabled={actionLoading} data-testid="modal-confirm-btn">{actionLoading ? <LoaderCircle className="button-spinner" size={18} aria-hidden="true" /> : activeModal === 'aprobar' ? <FileCheck2 size={18} aria-hidden="true" /> : null}{activeModal === 'aprobar' ? 'Confirmar aprobación' : activeModal === 'corregir' ? 'Enviar observaciones' : 'Confirmar rechazo'}</Button></footer>
      </section></div>}
    </section>
  );
}
