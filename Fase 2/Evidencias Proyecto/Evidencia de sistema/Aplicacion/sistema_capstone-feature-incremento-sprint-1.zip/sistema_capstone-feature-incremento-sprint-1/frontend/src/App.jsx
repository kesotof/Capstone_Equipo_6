import React, { useEffect, useRef, useState } from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate, useLocation } from 'react-router-dom';
import {
  Activity, ChevronRight, ClipboardList, FilePlus2, FolderOpen, LayoutDashboard, ListChecks,
  LoaderCircle, LogOut, Menu, PanelsTopLeft, RotateCcw, Settings2, Users, X
} from 'lucide-react';

// Acceso
import RecuperarPasswordView from './views/acceso/RecuperarPasswordView';

// Configuración del negocio
import ConfigurarFlujosView from './views/configuracion/ConfigurarFlujosView';
import ConfigurarOrgUsuariosView from './views/configuracion/ConfigurarOrgUsuariosView';
import ConfigurarPlanillasView from './views/configuracion/ConfigurarPlanillasView';

// Gestión Documentos
import NuevoDocumentoView from './views/documentos/NuevoDocumentoView';
import MisDocumentosView from './views/documentos/MisDocumentosView';
import CompletarPlanillaView from './views/documentos/CompletarPlanillaView';

// Gestión Flujos
import RevisarDocumentoView from './views/flujos/RevisarDocumentoView';
import CorregirDocumentoView from './views/flujos/CorregirDocumentoView';
import EstadoSolicitudesView from './views/flujos/EstadoSolicitudesView';
import DashboardView from './views/dashboard/DashboardView';
import keycloak, { getAuthenticatedUser, hasRealmRole, logout } from './services/keycloak';

import NotificationBell from './components/NotificationBell';

import './App.css';

const ROUTE_TITLES = {
  '/dashboard': ['Principal', 'Dashboard'],
  '/nuevo-documento': ['Documentos', 'Nuevo documento'],
  '/mis-documentos': ['Documentos', 'Mis documentos'],
  '/completar-planilla': ['Documentos', 'Completar planilla'],
  '/revisar-documento': ['Flujos de aprobación', 'Revisar documento'],
  '/corregir-documento': ['Flujos de aprobación', 'Corregir documento'],
  '/estado-solicitudes': ['Flujos de aprobación', 'Estado de solicitudes'],
  '/configurar-flujos': ['Configuración', 'Configurar flujos'],
  '/configurar-org-usuarios': ['Configuración', 'Organización y usuarios'],
  '/configurar-planillas': ['Configuración', 'Configurar planillas'],
  '/recuperar-password': ['Cuenta', 'Recuperar contraseña']
};

function SidebarLink({ to, icon: Icon, children, onNavigate, upcoming = false }) {
  return (
    <NavLink to={to} onClick={onNavigate} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
      <Icon size={18} aria-hidden="true" />
      <span className="nav-link-label">{children}</span>
      {upcoming && <span className="nav-link-tag">Pronto</span>}
    </NavLink>
  );
}

function Breadcrumb() {
  const { pathname } = useLocation();
  const [section, title] = ROUTE_TITLES[pathname] || ROUTE_TITLES['/dashboard'];
  return (
    <nav className="topbar-breadcrumb" aria-label="Ubicación actual">
      <span className="topbar-breadcrumb-section">{section}</span>
      <ChevronRight size={15} aria-hidden="true" />
      <span className="topbar-breadcrumb-page" aria-current="page">{title}</span>
    </nav>
  );
}

function AppShell() {
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuButtonRef = useRef(null);
  const closeButtonRef = useRef(null);
  const sidebarRef = useRef(null);

  useEffect(() => {
    const mobileQuery = window.matchMedia('(max-width: 900px)');
    const closeOnDesktop = () => {
      if (!mobileQuery.matches) setIsMenuOpen(false);
    };
    mobileQuery.addEventListener('change', closeOnDesktop);
    return () => mobileQuery.removeEventListener('change', closeOnDesktop);
  }, []);

  useEffect(() => {
    if (!isMenuOpen) return undefined;
    closeButtonRef.current?.focus();
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setIsMenuOpen(false);
        menuButtonRef.current?.focus();
      }
      if (event.key === 'Tab') {
        const focusable = sidebarRef.current?.querySelectorAll('button:not(:disabled), a[href]');
        if (!focusable?.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isMenuOpen]);

  const user = getAuthenticatedUser();
  const isAdmin = hasRealmRole('ADMIN');
  const canOperate = isAdmin || hasRealmRole('APPROVER');
  const roleLabel = isAdmin ? 'Administrador' : 'Emisor y Revisor';
  const closeMenu = () => {
    if (!isMenuOpen) return;
    setIsMenuOpen(false);
    menuButtonRef.current?.focus();
  };

  const handleLogout = async () => {
    if (isLoggingOut) {
      return;
    }

    setIsLoggingOut(true);
    try {
      await logout();
    } catch (error) {
      console.error('No fue posible cerrar la sesión', error);
      setIsLoggingOut(false);
    }
  };

  return (
    <div className="app-container">
      {isMenuOpen && <button className="sidebar-scrim" type="button" onClick={closeMenu} aria-label="Cerrar menú de navegación" tabIndex={-1} />}
      <aside ref={sidebarRef} id="main-sidebar" className={`sidebar${isMenuOpen ? ' sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-identity">
            <h1>
              <img className="brand-wordmark" src="/masterbase-wordmark.png" alt="" width="132" height="18" />
              <span className="visually-hidden">MasterBase</span>
            </h1>
            <span className="brand-caption">Gestión documental</span>
          </div>
          <button ref={closeButtonRef} className="sidebar-close-btn" type="button" onClick={closeMenu} aria-label="Cerrar menú"><X size={20} aria-hidden="true" /></button>
        </div>

        <nav className="nav-menu" aria-label="Navegación principal">
          <div className="nav-section">
            <h3>Principal</h3>
            <SidebarLink to="/dashboard" icon={LayoutDashboard} onNavigate={closeMenu}>Dashboard</SidebarLink>
          </div>

          <div className="nav-section">
            <h3>Documentos</h3>
            <SidebarLink to="/nuevo-documento" icon={FilePlus2} onNavigate={closeMenu}>Nuevo documento</SidebarLink>
            <SidebarLink to="/mis-documentos" icon={FolderOpen} onNavigate={closeMenu}>Mis documentos</SidebarLink>
            <SidebarLink to="/completar-planilla" icon={ClipboardList} onNavigate={closeMenu} upcoming>Completar planilla</SidebarLink>
          </div>

          <div className="nav-section">
            <h3>Flujos de aprobación</h3>
            {canOperate && <SidebarLink to="/revisar-documento" icon={ListChecks} onNavigate={closeMenu}>Revisar documento</SidebarLink>}
            <SidebarLink to="/corregir-documento" icon={RotateCcw} onNavigate={closeMenu}>Corregir documento</SidebarLink>
            <SidebarLink to="/estado-solicitudes" icon={Activity} onNavigate={closeMenu}>Estado de solicitudes</SidebarLink>
          </div>

          {canOperate && (
            <div className="nav-section">
              <h3>Configuración</h3>
              {isAdmin && <SidebarLink to="/configurar-org-usuarios" icon={Users} onNavigate={closeMenu}>Organización y usuarios</SidebarLink>}
              <SidebarLink to="/configurar-flujos" icon={Settings2} onNavigate={closeMenu} upcoming>Configurar flujos</SidebarLink>
              <SidebarLink to="/configurar-planillas" icon={PanelsTopLeft} onNavigate={closeMenu} upcoming>Configurar planillas</SidebarLink>
            </div>
          )}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="sidebar-user-info">
              <strong title={user.name}>{user.name}</strong>
              <span title={user.email}>{roleLabel}</span>
            </div>
            <button className="logout-btn" type="button" onClick={handleLogout} disabled={isLoggingOut} aria-label="Cerrar sesión" title="Cerrar sesión">
              {isLoggingOut ? <LoaderCircle className="button-spinner" size={18} aria-hidden="true" /> : <LogOut size={18} aria-hidden="true" />}
            </button>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button ref={menuButtonRef} className="mobile-menu-btn" type="button" onClick={() => setIsMenuOpen(true)} aria-label="Abrir menú de navegación" aria-controls="main-sidebar" aria-expanded={isMenuOpen}><Menu size={21} aria-hidden="true" /></button>
          <Breadcrumb />
          <div className="user-area">
            <NotificationBell />
          </div>
        </header>

        <div className="content-body">
          <Routes>
            {/* Acceso */}
            <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="/recuperar-password" element={<RecuperarPasswordView />} />

            {/* Inicio */}
            <Route path="/dashboard" element={<DashboardView />} />

            {/* Configuración */}
            <Route path="/configurar-flujos" element={canOperate ? <ConfigurarFlujosView /> : <Navigate to="/dashboard" replace />} />
            <Route
              path="/configurar-org-usuarios"
              element={isAdmin ? <ConfigurarOrgUsuariosView /> : <Navigate to="/dashboard" replace />}
            />
            <Route path="/configurar-planillas" element={canOperate ? <ConfigurarPlanillasView /> : <Navigate to="/dashboard" replace />} />

            {/* Documentos */}
            <Route path="/nuevo-documento" element={<NuevoDocumentoView />} />
            <Route path="/mis-documentos" element={<MisDocumentosView />} />
            <Route path="/completar-planilla" element={<CompletarPlanillaView />} />

            {/* Flujos */}
            <Route path="/revisar-documento" element={<RevisarDocumentoView />} />
            <Route path="/corregir-documento" element={<CorregirDocumentoView />} />
            <Route path="/estado-solicitudes" element={<EstadoSolicitudesView />} />

            <Route path="/logout" element={<Navigate to="/login" replace />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  if (!keycloak.authenticated) {
    return null;
  }

  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  );
}
