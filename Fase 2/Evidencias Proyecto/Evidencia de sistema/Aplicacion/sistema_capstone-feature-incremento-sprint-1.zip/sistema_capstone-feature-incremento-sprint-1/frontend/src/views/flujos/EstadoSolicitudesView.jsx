import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Activity,
  CheckCircle2,
  ChevronRight,
  Circle,
  Download,
  FileEdit,
  FilePlus2,
  FileText,
  LoaderCircle,
  RotateCcw,
  UserRound,
  X,
  XCircle
} from 'lucide-react';
import api from '../../services/api';
import ObservationTimeline from '../../components/ObservationTimeline';
import {
  Button,
  Card,
  DataTable,
  DetailModal,
  EmptyState,
  FeedbackMessage,
  FileTypeIcon,
  PageHeader,
  SPLIT_VIEW_COMPACT_QUERY,
  StatusBadge,
  formatDateTime,
  formatFileSize,
  getStatusLabel,
  useMediaQuery
} from '../../components/ui';

const ACTION_META = {
  CREAR: { label: 'Solicitud creada', tone: 'brand', icon: FilePlus2 },
  APROBAR: { label: 'Solicitud aprobada', tone: 'success', icon: CheckCircle2 },
  RECHAZAR: { label: 'Solicitud rechazada', tone: 'error', icon: XCircle },
  PEDIR_CORRECCION: { label: 'Corrección solicitada', tone: 'warning', icon: FileEdit },
  REENVIAR: { label: 'Solicitud reenviada', tone: 'info', icon: RotateCcw }
};

function selectOnKey(event, callback) {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    callback();
  }
}

export default function EstadoSolicitudesView() {
  const [searchParams] = useSearchParams();
  const queryId = searchParams.get('id');
  const isCompact = useMediaQuery(SPLIT_VIEW_COMPACT_QUERY);

  const [solicitudes, setSolicitudes] = useState([]);
  const [selectedSolicitud, setSelectedSolicitud] = useState(null);
  const [historial, setHistorial] = useState([]);
  const [observaciones, setObservaciones] = useState([]);
  const [detailOpen, setDetailOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const fetchSolicitudes = async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const response = await api.get('/api/solicitudes/mis-solicitudes');
      const data = Array.isArray(response.data) ? response.data : [];
      setSolicitudes(data);

      if (queryId) {
        const match = data.find((s) => s.id === queryId);
        if (match) {
          selectSolicitud(match);
          if (window.matchMedia(SPLIT_VIEW_COMPACT_QUERY).matches) setDetailOpen(true);
          return;
        }
      }

      if (data.length > 0) {
        selectSolicitud(data[0]);
      } else {
        setSelectedSolicitud(null);
      }
    } catch (err) {
      console.error('Error cargando solicitudes', err);
      setErrorMessage('No fue posible cargar el estado de las solicitudes.');
    } finally {
      setLoading(false);
    }
  };

  const selectSolicitud = async (sol) => {
    setSelectedSolicitud(sol);
    setLoadingDetails(true);

    try {
      const histResp = await api.get(`/api/solicitudes/${sol.id}/historial`);
      setHistorial(Array.isArray(histResp.data) ? histResp.data : []);
    } catch (err) {
      console.warn('Error cargando historial', err);
      setHistorial([]);
    }

    try {
      const obsResp = await api.get(`/api/solicitudes/${sol.id}/observaciones`);
      setObservaciones(Array.isArray(obsResp.data) ? obsResp.data : []);
    } catch (err) {
      console.warn('Error cargando observaciones', err);
      setObservaciones([]);
    } finally {
      setLoadingDetails(false);
    }
  };

  const openDetail = (sol) => {
    selectSolicitud(sol);
    if (isCompact) setDetailOpen(true);
  };

  useEffect(() => {
    fetchSolicitudes();
  }, [queryId]);

  const handleDownload = async (solicitudId, fileName) => {
    try {
      const resp = await api.get(`/api/solicitudes/${solicitudId}/documento/descargar`, {
        responseType: 'blob'
      });
      const blobUrl = window.URL.createObjectURL(new Blob([resp.data]));
      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', fileName || 'documento');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error('Error descargando archivo', err);
      setErrorMessage('No fue posible descargar el archivo solicitado.');
    }
  };

  const documento = selectedSolicitud?.documentoVigente;
  const historialReciente = [...historial].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const showDetailModal = isCompact && detailOpen && Boolean(selectedSolicitud);

  const renderDetailHeader = (inModal) => (
    <div className="detail-card-header">
      <div className="detail-card-heading">
        <p className="page-eyebrow">Detalle de la solicitud</p>
        <h3 id="estado-detail-heading" data-testid="estado-detail-title">{selectedSolicitud.titulo}</h3>
        {inModal && <StatusBadge status={selectedSolicitud.estado} />}
      </div>
      {inModal ? (
        <button className="action-btn" type="button" onClick={() => setDetailOpen(false)} aria-label="Cerrar detalle">
          <X size={18} aria-hidden="true" />
        </button>
      ) : (
        <StatusBadge status={selectedSolicitud.estado} />
      )}
    </div>
  );

  const renderDetailBody = (inModal) => (
    <div className="detail-card-body">
      {inModal && errorMessage && <FeedbackMessage tone="error">{errorMessage}</FeedbackMessage>}

      <dl className="detail-meta-grid">
        <div><dt>Emitida</dt><dd>{formatDateTime(selectedSolicitud.createdAt)}</dd></div>
        <div><dt>Última actualización</dt><dd>{formatDateTime(selectedSolicitud.updatedAt || selectedSolicitud.createdAt)}</dd></div>
        <div><dt>Versión vigente</dt><dd>{documento ? `v${documento.version}` : '—'}</dd></div>
      </dl>

      <div className="detail-section">
        <span className="detail-section-title">Descripción</span>
        <p className="detail-section-content">
          {selectedSolicitud.descripcion || <em>Sin descripción.</em>}
        </p>
      </div>

      <div className="detail-section">
        <span className="detail-section-title">Documento vigente</span>
        {documento ? (
          <div className="attachment-card">
            <FileTypeIcon fileName={documento.nombreArchivo} />
            <div className="cell-stack">
              <strong title={documento.nombreArchivo}>{documento.nombreArchivo}</strong>
              <span>{[formatFileSize(documento.sizeBytes), `Versión ${documento.version}`].filter(Boolean).join(' · ')}</span>
            </div>
            <Button
              variant="secondary"
              className="ui-button--compact"
              onClick={() => handleDownload(selectedSolicitud.id, documento.nombreArchivo)}
              data-testid="estado-btn-descargar"
            >
              <Download size={15} aria-hidden="true" />
              <span>Descargar</span>
            </Button>
          </div>
        ) : (
          <p className="detail-section-content"><em>Sin archivo adjunto.</em></p>
        )}
      </div>

      {selectedSolicitud.estado === 'CORRECCION_REQUERIDA' && (
        <section className="request-correction-panel" aria-label="Correcciones pendientes">
          <div className="request-correction-header">
            <div>
              <span className="request-correction-icon" aria-hidden="true"><FileEdit size={19} /></span>
              <div>
                <strong>Esta solicitud requiere correcciones</strong>
                <p>Revisa las indicaciones del revisor y vuelve a enviarla cuando esté lista.</p>
              </div>
            </div>
            <Button
              as={Link}
              variant="warning"
              to={`/corregir-documento?id=${selectedSolicitud.id}`}
              className="request-correction-action"
              data-testid="btn-ir-a-corregir"
            >
              <FileEdit size={16} aria-hidden="true" />
              <span>Corregir solicitud</span>
            </Button>
          </div>
          {loadingDetails ? (
            <div className="request-correction-loading"><LoaderCircle className="button-spinner" size={18} aria-hidden="true" />Cargando observaciones…</div>
          ) : observaciones.length > 0 ? (
            <ObservationTimeline observations={observaciones} compact />
          ) : (
            <p className="request-correction-empty">Todavía no hay indicaciones disponibles para esta solicitud.</p>
          )}
        </section>
      )}

      <div className="detail-section">
        <span className="detail-section-title">Historial de transiciones</span>
        {loadingDetails ? (
          <div className="inline-loading"><LoaderCircle className="button-spinner" size={18} aria-hidden="true" />Cargando historial…</div>
        ) : historial.length === 0 ? (
          <p className="detail-section-content"><em>No hay transiciones registradas aún.</em></p>
        ) : (
          <ol className="timeline" data-testid="timeline-container">
            {historialReciente.map((item) => {
              const meta = ACTION_META[item.accion] || { label: item.accion, tone: 'neutral', icon: Circle };
              const ActionIcon = meta.icon;
              return (
                <li key={item.id} className={`timeline-item timeline-item--${meta.tone}`} data-testid="timeline-item">
                  <span className="timeline-dot" aria-hidden="true"><ActionIcon size={14} /></span>
                  <div className="timeline-content">
                    <div className="timeline-head">
                      <strong className="timeline-title">{meta.label}</strong>
                      <code className="timeline-code" title="Código de auditoría">{item.accion}</code>
                    </div>
                    <p className="timeline-transition">
                      {item.estadoOrigen && item.estadoOrigen !== 'INICIAL' ? getStatusLabel(item.estadoOrigen) : 'Inicio'} → {getStatusLabel(item.estadoDestino)}
                    </p>
                    <p className="timeline-meta">
                      <UserRound size={13} aria-hidden="true" />
                      <span>{item.usuarioNombre || item.usuarioEmail}</span>
                      <span aria-hidden="true">·</span>
                      <time dateTime={item.createdAt}>{formatDateTime(item.createdAt)}</time>
                    </p>
                    {item.comentario && <blockquote className="timeline-comment">{item.comentario}</blockquote>}
                  </div>
                </li>
              );
            })}
          </ol>
        )}
      </div>
    </div>
  );

  return (
    <section className="list-page" aria-labelledby="estado-title">
      <PageHeader
        eyebrow="Flujos de aprobación"
        title="Estado de solicitudes"
        titleId="estado-title"
        description="Sigue el ciclo de vida de cada solicitud: su estado actual, el documento vigente y cada decisión registrada."
        icon={Activity}
      />

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}

      <div className="master-detail">
        <Card as="div" className="master-list">
          <div className="card-header">
            <div>
              <h3>Mis solicitudes</h3>
              <p>{solicitudes.length} {solicitudes.length === 1 ? 'solicitud registrada' : 'solicitudes registradas'}</p>
            </div>
          </div>

          <div className="table-scroll">
            {loading ? (
              <EmptyState loading title="Cargando solicitudes…" />
            ) : solicitudes.length === 0 ? (
              <EmptyState icon={FileText} title="Sin solicitudes" data-testid="empty-solicitudes" action={<Button as={Link} to="/nuevo-documento">Registrar documento</Button>}>
                Aún no has emitido ningún documento al sistema.
              </EmptyState>
            ) : (
              <DataTable className="selectable-table">
                <thead>
                  <tr>
                    <th>Solicitud</th>
                    {isCompact ? <th><span className="visually-hidden">Abrir detalle</span></th> : <th>Estado</th>}
                  </tr>
                </thead>
                <tbody>
                  {solicitudes.map((sol) => {
                    const isSelected = selectedSolicitud?.id === sol.id && (!isCompact || detailOpen);
                    return (
                      <tr
                        key={sol.id}
                        className={`clickable-row ${isSelected ? 'row-selected' : ''}`}
                        onClick={() => openDetail(sol)}
                        onKeyDown={(event) => selectOnKey(event, () => openDetail(sol))}
                        tabIndex={0}
                        aria-current={isSelected ? 'true' : undefined}
                        aria-haspopup={isCompact ? 'dialog' : undefined}
                        data-testid={`solicitud-item-${sol.id}`}
                      >
                        <td>
                          <div className="cell-stack">
                            <strong>{sol.titulo}</strong>
                            <span>{formatDateTime(sol.createdAt)}</span>
                            {isCompact && <StatusBadge status={sol.estado} />}
                          </div>
                        </td>
                        {isCompact
                          ? <td className="row-chevron"><ChevronRight size={18} aria-hidden="true" /></td>
                          : <td><StatusBadge status={sol.estado} /></td>}
                      </tr>
                    );
                  })}
                </tbody>
              </DataTable>
            )}
          </div>
        </Card>

        {!isCompact && (
          <div className="detail-card">
            {!selectedSolicitud ? (
              <EmptyState icon={FileText} title="Selecciona una solicitud">
                Elige una solicitud de la lista para revisar su trazabilidad.
              </EmptyState>
            ) : (
              <>
                {renderDetailHeader(false)}
                {renderDetailBody(false)}
              </>
            )}
          </div>
        )}
      </div>

      <DetailModal open={showDetailModal} onClose={() => setDetailOpen(false)} labelledBy="estado-detail-heading">
        {showDetailModal && (
          <>
            {renderDetailHeader(true)}
            {renderDetailBody(true)}
          </>
        )}
      </DetailModal>
    </section>
  );
}
