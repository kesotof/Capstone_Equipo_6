import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileCheck2,
  FileEdit,
  FolderOpen,
  Inbox,
  LoaderCircle,
  Plus,
  RotateCw
} from 'lucide-react';
import api from '../../services/api';
import { getAuthenticatedUser, hasRealmRole } from '../../services/keycloak';
import {
  Button,
  Card,
  DateTimeStack,
  FeedbackMessage,
  FileTypeIcon,
  PageHeader,
  StatusBadge
} from '../../components/ui';

function StatTile({ icon: Icon, tone, label, value, hint }) {
  return (
    <div className={`stat-tile stat-tile--${tone}`} role="listitem">
      <div className="stat-tile-top">
        <span className="stat-tile-label">{label}</span>
        <span className="stat-tile-icon" aria-hidden="true"><Icon size={18} /></span>
      </div>
      <strong className="stat-tile-value">{value}</strong>
      <span className="stat-tile-hint">{hint}</span>
    </div>
  );
}

function formatToday() {
  const label = new Intl.DateTimeFormat('es-CL', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export default function DashboardView() {
  const navigate = useNavigate();
  const user = getAuthenticatedUser();
  const isAdmin = hasRealmRole('ADMIN');

  const [activeTab, setActiveTab] = useState('acciones'); // 'acciones' | 'en_tramite'
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [accionesPendientes, setAccionesPendientes] = useState([]);
  const [misSolicitudesPendientes, setMisSolicitudesPendientes] = useState([]);
  const [resumenResueltas, setResumenResueltas] = useState(null);

  const fetchDashboardData = async (isRefresh = false) => {
    if (isRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    setErrorMessage('');

    try {
      const [response, misSolicitudesResponse] = await Promise.all([
        api.get('/api/solicitudes/dashboard'),
        api.get('/api/solicitudes/mis-solicitudes').catch(() => null)
      ]);
      const data = response.data || {};
      setAccionesPendientes(Array.isArray(data.accionesPendientes) ? data.accionesPendientes : []);
      setMisSolicitudesPendientes(
        Array.isArray(data.misSolicitudesPendientes) ? data.misSolicitudesPendientes : []
      );

      const todas = Array.isArray(misSolicitudesResponse?.data) ? misSolicitudesResponse.data : null;
      setResumenResueltas(todas && {
        aprobadas: todas.filter((solicitud) => solicitud.estado === 'APROBADO').length,
        rechazadas: todas.filter((solicitud) => solicitud.estado === 'RECHAZADO').length
      });
    } catch (error) {
      console.error('Error al cargar datos del dashboard', error);
      setErrorMessage(
        error?.response?.data?.detail ||
          error?.response?.data?.message ||
          'No fue posible cargar el resumen del dashboard.'
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const revisionesPendientes = accionesPendientes.filter((item) => item.tipoAccion === 'REVISION').length;
  const correccionesPendientes = accionesPendientes.length - revisionesPendientes;
  const totalResueltas = resumenResueltas ? resumenResueltas.aprobadas + resumenResueltas.rechazadas : null;

  return (
    <section className="view-container dashboard-view" aria-labelledby="dashboard-heading">
      <PageHeader
        eyebrow={formatToday()}
        title="Dashboard"
        titleId="dashboard-heading"
        actions={(
          <>
            <Button
              variant="secondary"
              className="btn-refresh"
              onClick={() => fetchDashboardData(true)}
              disabled={loading || refreshing}
              title="Actualizar datos"
            >
              <RotateCw size={16} className={refreshing ? 'spin-icon' : ''} aria-hidden="true" />
              <span>{refreshing ? 'Actualizando…' : 'Actualizar'}</span>
            </Button>
            <Button as={Link} to="/nuevo-documento" className="btn-new-request">
              <Plus size={18} aria-hidden="true" />
              <span>Nueva solicitud</span>
            </Button>
          </>
        )}
      >
        <p className="dashboard-greeting">
          Bienvenido, <strong>{user.name}</strong>
          <span className="user-role-badge">{isAdmin ? 'Administrador' : 'Emisor y Revisor'}</span>
        </p>
      </PageHeader>

      {errorMessage && <FeedbackMessage tone="error" className="page-message">{errorMessage}</FeedbackMessage>}

      {loading ? (
        <div className="dashboard-loading" role="status">
          <LoaderCircle size={28} className="spin-icon" aria-hidden="true" />
          <p>Cargando tu panel…</p>
        </div>
      ) : (
        <div className="dashboard-body">
          <div className="dashboard-stats" role="list" aria-label="Resumen de solicitudes">
            <StatTile icon={FileCheck2} tone="info" label="Revisiones pendientes" value={revisionesPendientes} hint="Esperan tu decisión" />
            <StatTile icon={FileEdit} tone="warning" label="Correcciones pendientes" value={correccionesPendientes} hint="Documentos tuyos con observaciones" />
            <StatTile icon={Clock} tone="brand" label="En trámite" value={misSolicitudesPendientes.length} hint="Solicitudes enviadas en proceso" />
            <StatTile
              icon={CheckCircle2}
              tone="success"
              label="Resueltas"
              value={totalResueltas ?? '—'}
              hint={resumenResueltas ? `${resumenResueltas.aprobadas} aprobadas · ${resumenResueltas.rechazadas} rechazadas` : 'Sin datos disponibles'}
            />
          </div>

          <Card as="div" className="dashboard-table-card">
            <div className="dashboard-tabs" role="tablist" aria-label="Bandejas del dashboard">
              <button
                type="button"
                role="tab"
                id="tab-acciones"
                aria-selected={activeTab === 'acciones'}
                aria-controls="panel-acciones"
                className={`dashboard-tab-btn ${activeTab === 'acciones' ? 'active' : ''}`}
                onClick={() => setActiveTab('acciones')}
              >
                <FileCheck2 size={17} aria-hidden="true" />
                <span>Acciones pendientes</span>
                <span className="tab-counter-badge">{accionesPendientes.length}</span>
              </button>
              <button
                type="button"
                role="tab"
                id="tab-en-tramite"
                aria-selected={activeTab === 'en_tramite'}
                aria-controls="panel-en-tramite"
                className={`dashboard-tab-btn ${activeTab === 'en_tramite' ? 'active' : ''}`}
                onClick={() => setActiveTab('en_tramite')}
              >
                <Clock size={17} aria-hidden="true" />
                <span>Mis solicitudes en trámite</span>
                <span className="tab-counter-badge">{misSolicitudesPendientes.length}</span>
              </button>
            </div>

            {activeTab === 'acciones' && (
              <div className="dashboard-tab-content" role="tabpanel" id="panel-acciones" aria-labelledby="tab-acciones">
                {accionesPendientes.length === 0 ? (
                  <div className="dashboard-empty-state">
                    <span className="empty-state-icon-wrapper" aria-hidden="true">
                      <CheckCircle2 size={28} />
                    </span>
                    <h3>¡Estás al día!</h3>
                    <p>
                      No tienes solicitudes pendientes de tu revisión ni documentos que requieran corrección en este momento.
                    </p>
                    <div className="empty-state-actions">
                      <Button as={Link} variant="secondary" to="/nuevo-documento">
                        Crear nueva solicitud
                      </Button>
                      <Button as={Link} variant="quiet" to="/mis-documentos">
                        Ver mis documentos
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="dashboard-table table-stackable">
                      <thead>
                        <tr>
                          <th>Documento</th>
                          <th>Emisor</th>
                          <th>Acción requerida</th>
                          <th>Fecha</th>
                          <th className="text-right"><span className="visually-hidden">Acción</span></th>
                        </tr>
                      </thead>
                      <tbody>
                        {accionesPendientes.map((item) => {
                          const isRevision = item.tipoAccion === 'REVISION';
                          return (
                            <tr key={item.solicitudId} className="dashboard-action-row">
                              <td className="cell-primary">
                                <div className="cell-with-icon">
                                  <FileTypeIcon fileName={item.nombreArchivo} />
                                  <div className="cell-stack">
                                    <strong>{item.titulo}</strong>
                                    {item.nombreArchivo && <span>{item.nombreArchivo} · v{item.version}</span>}
                                  </div>
                                </div>
                              </td>
                              <td className="cell-wide" data-label="Emisor">
                                <div className="cell-stack cell-person">
                                  <strong>{item.emisorNombre}</strong>
                                  <span>{item.emisorEmail}</span>
                                </div>
                              </td>
                              <td className="cell-wide" data-label="Acción requerida">
                                <div className="action-cell">
                                {isRevision ? (
                                  <span className="action-tag action-tag-revision">
                                    <FileCheck2 size={14} aria-hidden="true" />
                                    <span>Revisión Requerida</span>
                                  </span>
                                ) : (
                                  <span className="action-tag action-tag-correction">
                                    <FileEdit size={14} aria-hidden="true" />
                                    <span>Subsanación Requerida</span>
                                  </span>
                                )}
                                {item.ultimaObservacion ? (
                                  <div className="obs-snippet" title={item.ultimaObservacion}>
                                    <AlertCircle size={14} className="obs-icon" aria-hidden="true" />
                                    <span>{item.ultimaObservacion}</span>
                                  </div>
                                ) : (
                                  <span className="detail-muted">
                                    {item.descripcionAccion || 'Pendiente de decisión'}
                                  </span>
                                )}
                                </div>
                              </td>
                              <td data-label="Fecha"><DateTimeStack value={item.fecha} /></td>
                              <td className="text-right cell-actions">
                                {isRevision ? (
                                  <Button
                                    variant="secondary"
                                    className="ui-button--compact btn-review"
                                    onClick={() => navigate(`/revisar-documento?id=${item.solicitudId}`)}
                                  >
                                    <span>Revisar</span>
                                    <ArrowRight size={14} aria-hidden="true" />
                                  </Button>
                                ) : (
                                  <Button
                                    variant="secondary"
                                    className="ui-button--compact btn-correct"
                                    onClick={() => navigate(`/corregir-documento?id=${item.solicitudId}`)}
                                  >
                                    <span>Subsanar</span>
                                    <ArrowRight size={14} aria-hidden="true" />
                                  </Button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'en_tramite' && (
              <div className="dashboard-tab-content" role="tabpanel" id="panel-en-tramite" aria-labelledby="tab-en-tramite">
                {misSolicitudesPendientes.length === 0 ? (
                  <div className="dashboard-empty-state">
                    <span className="empty-state-icon-wrapper neutral" aria-hidden="true">
                      <Inbox size={28} />
                    </span>
                    <h3>Sin solicitudes en trámite</h3>
                    <p>
                      Actualmente no tienes documentos en proceso de revisión o subsanación emitidos por tu cuenta.
                    </p>
                    <div className="empty-state-actions">
                      <Button as={Link} to="/nuevo-documento">
                        Registrar nuevo documento
                      </Button>
                      <Button as={Link} variant="quiet" to="/mis-documentos">
                        <FolderOpen size={16} aria-hidden="true" />
                        Ver mis documentos
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="dashboard-table table-stackable">
                      <thead>
                        <tr>
                          <th>Documento</th>
                          <th>Fecha de envío</th>
                          <th>Estado</th>
                          <th className="text-right"><span className="visually-hidden">Seguimiento</span></th>
                        </tr>
                      </thead>
                      <tbody>
                        {misSolicitudesPendientes.map((sol) => (
                          <tr key={sol.id} className="dashboard-request-row">
                            <td className="cell-primary">
                              <div className="cell-with-icon">
                                <FileTypeIcon fileName={sol.documentoVigente?.nombreArchivo} />
                                <div className="cell-stack">
                                  <strong>{sol.titulo}</strong>
                                  <span>
                                    {sol.documentoVigente
                                      ? `${sol.documentoVigente.nombreArchivo} · v${sol.documentoVigente.version}`
                                      : 'Sin archivo adjunto'}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td data-label="Enviada"><DateTimeStack value={sol.createdAt} /></td>
                            <td data-label="Estado"><StatusBadge status={sol.estado} /></td>
                            <td className="text-right cell-actions">
                              <Button
                                variant="secondary"
                                className="ui-button--compact btn-track"
                                onClick={() => navigate(`/estado-solicitudes?id=${sol.id}`)}
                              >
                                <span>Ver estado</span>
                                <ArrowRight size={14} aria-hidden="true" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      )}
    </section>
  );
}
