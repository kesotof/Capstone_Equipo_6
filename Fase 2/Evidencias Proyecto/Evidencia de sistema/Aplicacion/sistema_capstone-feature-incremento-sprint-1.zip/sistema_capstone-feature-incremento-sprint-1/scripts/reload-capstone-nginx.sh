#!/bin/sh
set -eu

if docker ps --filter 'name=^/capstone-frontend$' --format '{{.Names}}' | grep -qx 'capstone-frontend'; then
    docker exec capstone-frontend nginx -s reload
fi
