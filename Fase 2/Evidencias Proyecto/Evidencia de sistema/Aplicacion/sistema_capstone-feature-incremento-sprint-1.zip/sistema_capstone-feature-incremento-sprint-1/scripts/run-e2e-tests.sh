#!/bin/bash
# ==============================================================================
# Script de Ejecución de Pruebas Automatizadas E2E (Playwright en Docker)
# ==============================================================================

set -e

UI_MODE=false
BUILD_IMAGE=false
SPEC_PATH=""

while [[ $# -gt 0 ]]; do
  case $1 in
    --ui|-ui|-UI)
      UI_MODE=true
      shift
      ;;
    --build|-build)
      BUILD_IMAGE=true
      shift
      ;;
    *)
      SPEC_PATH="$1"
      shift
      ;;
  esac
done

echo "=================================================================="
echo "   Suite de Pruebas Automatizadas E2E y de Regresión (Playwright)"
echo "=================================================================="

# 1. Comprobar Docker
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker no se encuentra disponible en el PATH."
    exit 1
fi

# 2. Verificar contenedores del sistema
echo -e "\n[1/3] Verificando estado de los servicios del sistema..."
REQUIRED_CONTAINERS=("capstone-postgres" "capstone-keycloak" "capstone-frontend")
MISSING_CONTAINERS=()

for c in "${REQUIRED_CONTAINERS[@]}"; do
    if [ -z "$(docker ps --filter "name=^/${c}$" --filter "status=running" --format "{{.Names}}")" ]; then
        MISSING_CONTAINERS+=("$c")
    fi
done

if [ ${#MISSING_CONTAINERS[@]} -gt 0 ]; then
    echo "Servicios faltantes: ${MISSING_CONTAINERS[*]}"
    echo "Levantando infraestructura y frontend..."
    docker compose --profile apps up -d --build postgres keycloak frontend sistema-principal
    sleep 5
else
    echo "Servicios base y frontend activos y respondiendo."
fi

# 3. Compilación de imagen si se solicita o no existe
IMAGE_EXISTS=$(docker images -q sistema_capstone-playwright 2>/dev/null)
if [ "$BUILD_IMAGE" = true ] || [ -z "$IMAGE_EXISTS" ]; then
    echo -e "\n[2/3] Construyendo imagen de pruebas Docker (playwright-tests)..."
    docker compose build playwright-tests
else
    echo -e "\n[2/3] Imagen de pruebas lista (sistema_capstone-playwright)."
fi

# 4. Ejecución de pruebas
echo -e "\n[3/3] Ejecutando suite de pruebas en contenedor..."

if [ "$UI_MODE" = true ]; then
    echo ">>> Iniciando servidor interactivo Playwright UI Web en puerto 9323 <<<"
    echo ">>> Abre tu navegador en: http://localhost:9323 <<<"
    docker compose run --rm -p 9323:9323 playwright-tests npm run test:ui:web
    EXIT_CODE=$?
else
    if [ -n "$SPEC_PATH" ]; then
        docker compose run --rm playwright-tests npx playwright test "$SPEC_PATH"
    else
        docker compose run --rm playwright-tests npm test
    fi
    EXIT_CODE=$?
fi


echo -e "\n=================================================================="
if [ $EXIT_CODE -eq 0 ]; then
    echo "✓ Todas las pruebas automatizadas pasaron exitosamente."
    echo "  Grabaciones en video guardadas en: tests/e2e/test-results/"
else
    echo "✗ Se detectaron fallos en la ejecución de pruebas (Exit Code: $EXIT_CODE)."
    echo "  Revisa las capturas o reportes generados en: tests/e2e/test-results/"
fi
echo "=================================================================="

exit $EXIT_CODE
