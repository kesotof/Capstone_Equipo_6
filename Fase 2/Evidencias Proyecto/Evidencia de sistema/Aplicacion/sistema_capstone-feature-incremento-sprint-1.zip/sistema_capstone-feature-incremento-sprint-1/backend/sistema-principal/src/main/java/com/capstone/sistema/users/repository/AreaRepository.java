package com.capstone.sistema.users.repository;

import com.capstone.sistema.users.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AreaRepository extends JpaRepository<Area, Long> {

    Optional<Area> findByNombreIgnoreCase(String nombre);
}
