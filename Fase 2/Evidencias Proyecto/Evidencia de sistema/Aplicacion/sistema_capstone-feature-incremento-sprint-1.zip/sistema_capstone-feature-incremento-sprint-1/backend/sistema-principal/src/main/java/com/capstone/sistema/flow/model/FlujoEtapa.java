package com.capstone.sistema.flow.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "flujo_etapa", uniqueConstraints = {
        @UniqueConstraint(name = "unq_flujo_orden", columnNames = {"flujo_definicion_id", "orden"})
})
public class FlujoEtapa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flujo_definicion_id", nullable = false)
    private FlujoDefinicion flujoDefinicion;

    @Column(nullable = false)
    private int orden;

    @Column(nullable = false, length = 150)
    private String nombre;

    @OneToMany(mappedBy = "flujoEtapa", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FlujoEtapaRoles> roles = new ArrayList<>();

    protected FlujoEtapa() {
    }

    public FlujoEtapa(FlujoDefinicion flujoDefinicion, int orden, String nombre) {
        this.flujoDefinicion = flujoDefinicion;
        this.orden = orden;
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public FlujoDefinicion getFlujoDefinicion() {
        return flujoDefinicion;
    }

    public void setFlujoDefinicion(FlujoDefinicion flujoDefinicion) {
        this.flujoDefinicion = flujoDefinicion;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<FlujoEtapaRoles> getRoles() {
        return roles;
    }

    public void addRol(FlujoEtapaRoles rol) {
        roles.add(rol);
        rol.setFlujoEtapa(this);
    }
}
