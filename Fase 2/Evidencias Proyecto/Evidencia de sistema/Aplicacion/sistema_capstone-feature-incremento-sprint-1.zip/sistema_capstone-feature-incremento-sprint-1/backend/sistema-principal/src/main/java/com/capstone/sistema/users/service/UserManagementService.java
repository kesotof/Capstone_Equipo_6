package com.capstone.sistema.users.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.users.config.KeycloakAdminProperties;
import com.capstone.sistema.users.dto.CreateUserRequest;
import com.capstone.sistema.users.dto.UpdateUserRequest;
import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.exception.UserAlreadyExistsException;
import com.capstone.sistema.users.exception.UserNotFoundException;
import com.capstone.sistema.users.exception.UserProvisioningException;
import com.capstone.sistema.users.mapper.UserMapper;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import com.capstone.sistema.users.repository.RolFlujoRepository;
import com.capstone.sistema.users.repository.UserAccountRepository;
import jakarta.ws.rs.core.Response;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class UserManagementService {

    private static final Logger log = LoggerFactory.getLogger(UserManagementService.class);

    private final UserAccountRepository userAccountRepository;
    private final RolFlujoRepository rolFlujoRepository;
    private final KeycloakLockStatusClient keycloakLockStatusClient;
    private final Keycloak keycloakAdminClient;
    private final KeycloakAdminProperties keycloakProperties;
    private final AuditService auditService;

    public UserManagementService(
            UserAccountRepository userAccountRepository,
            RolFlujoRepository rolFlujoRepository,
            KeycloakLockStatusClient keycloakLockStatusClient,
            Keycloak keycloakAdminClient,
            KeycloakAdminProperties keycloakProperties,
            AuditService auditService
    ) {
        this.userAccountRepository = userAccountRepository;
        this.rolFlujoRepository = rolFlujoRepository;
        this.keycloakLockStatusClient = keycloakLockStatusClient;
        this.keycloakAdminClient = keycloakAdminClient;
        this.keycloakProperties = keycloakProperties;
        this.auditService = auditService;
    }

    @Transactional
    public UserResponse createUser(CreateUserRequest request) {
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (userAccountRepository.existsByEmailIgnoreCase(email)) {
            throw new UserAlreadyExistsException(email);
        }

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        if (!users.searchByEmail(email, true).isEmpty()) {
            throw new UserAlreadyExistsException(email);
        }

        UserRepresentation representation = new UserRepresentation();
        representation.setUsername(email);
        representation.setEmail(email);
        representation.setFirstName(request.firstName().trim());
        representation.setLastName(request.lastName().trim());
        representation.setEmailVerified(true);
        representation.setEnabled(true);

        String keycloakUserId = createInKeycloak(users, representation, email);
        try {
            setInitialPassword(users, keycloakUserId, request.password(), request.requirePasswordChange());
            assignRealmRoles(realm, users, keycloakUserId, request.roles());

            UserAccount user = new UserAccount(
                    keycloakUserId,
                    email,
                    request.firstName().trim(),
                    request.lastName().trim(),
                    true,
                    resolveRolFlujoEntities(request.roles())
            );
            UserAccount saved = userAccountRepository.saveAndFlush(user);
            log.info("Cuenta creada y sincronizada para {} con roles {}", email, request.roles());
            auditService.registerUserManagementEvent("CREAR_USUARIO", saved, "Usuario creado: " + email);
            return UserMapper.toResponse(saved, false);
        } catch (RuntimeException exception) {
            deleteKeycloakUserQuietly(users, keycloakUserId, email);
            if (exception instanceof UserAlreadyExistsException
                    || exception instanceof UserProvisioningException) {
                throw exception;
            }
            throw new UserProvisioningException("No fue posible completar la creación de la cuenta", exception);
        }
    }

    @Transactional
    public UserResponse updateUser(UUID id, UpdateUserRequest request) {
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));

        String firstName = request.firstName().trim();
        String lastName = request.lastName().trim();

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        try {
            UserResource userResource = users.get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setFirstName(firstName);
            rep.setLastName(lastName);

            if (request.newPassword() != null && !request.newPassword().isBlank()) {
                boolean reqPassChange = Boolean.TRUE.equals(request.requirePasswordChange());
                setInitialPassword(users, user.getKeycloakUserId(), request.newPassword().trim(), reqPassChange);
            } else if (request.requirePasswordChange() != null) {
                List<String> actions = rep.getRequiredActions();
                if (actions == null) {
                    actions = new java.util.ArrayList<>();
                }
                if (Boolean.TRUE.equals(request.requirePasswordChange())) {
                    if (!actions.contains("UPDATE_PASSWORD")) {
                        actions.add("UPDATE_PASSWORD");
                    }
                } else {
                    actions.remove("UPDATE_PASSWORD");
                }
                rep.setRequiredActions(actions);
            }

            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al actualizar usuario {} en Keycloak", user.getEmail(), exception);
            throw new UserProvisioningException("No fue posible sincronizar la actualización en Keycloak", exception);
        }

        user.setFirstName(firstName);
        user.setLastName(lastName);
        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String auditDetalle = "Usuario actualizado: " + saved.getEmail() + " (" + firstName + " " + lastName + ")";
        if (request.newPassword() != null && !request.newPassword().isBlank()) {
            auditDetalle += " [Contraseña restablecida]";
        }
        auditService.registerUserManagementEvent(
                "ACTUALIZAR_USUARIO",
                saved,
                auditDetalle
        );

        return UserMapper.toResponse(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public UserResponse toggleUserStatus(UUID id, boolean enabled) {
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));

        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        try {
            UserResource userResource = realm.users().get(user.getKeycloakUserId());
            UserRepresentation rep = userResource.toRepresentation();
            rep.setEnabled(enabled);
            userResource.update(rep);
        } catch (RuntimeException exception) {
            log.error("Error al cambiar estado de usuario {} en Keycloak a enabled={}", user.getEmail(), enabled, exception);
            throw new UserProvisioningException("No fue posible cambiar el estado del usuario en Keycloak", exception);
        }

        user.setEnabled(enabled);
        UserAccount saved = userAccountRepository.saveAndFlush(user);

        String tipo = enabled ? "ACTIVAR_USUARIO" : "DESACTIVAR_USUARIO";
        String detalle = (enabled ? "Cuenta activada" : "Cuenta desactivada") + " para " + saved.getEmail();
        auditService.registerUserManagementEvent(tipo, saved, detalle);

        return UserMapper.toResponse(
                saved,
                keycloakLockStatusClient.isTemporarilyLocked(saved.getKeycloakUserId())
        );
    }

    @Transactional
    public void deleteUser(UUID id) {
        UserAccount user = userAccountRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));

        String email = user.getEmail();
        String keycloakUserId = user.getKeycloakUserId();

        auditService.registerUserManagementEvent(
                "ELIMINAR_USUARIO",
                user,
                "Usuario eliminado: " + email
        );

        userAccountRepository.delete(user);
        userAccountRepository.flush();

        try {
            RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
            realm.users().delete(keycloakUserId).close();
            log.info("Usuario {} eliminado exitosamente de Keycloak", email);
        } catch (RuntimeException exception) {
            log.warn("No fue posible eliminar usuario {} de Keycloak o ya fue removido: {}", email, exception.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<UserResponse> listUsers() {
        return userAccountRepository.findAllByOrderByEmailAsc().stream()
                .map(user -> UserMapper.toResponse(
                        user,
                        keycloakLockStatusClient.isTemporarilyLocked(user.getKeycloakUserId())
                ))
                .toList();
    }

    @Transactional
    public int synchronizeExistingUsers() {
        RealmResource realm = keycloakAdminClient.realm(keycloakProperties.targetRealm());
        UsersResource users = realm.users();
        int synchronizedUsers = 0;

        for (UserRepresentation representation : users.list()) {
            String email = normalizeEmail(representation);
            if (email == null
                    || userAccountRepository.existsByEmailIgnoreCase(email)
                    || userAccountRepository.existsByKeycloakUserId(representation.getId())) {
                continue;
            }

            Set<SystemRole> roles = readSystemRoles(users, representation.getId());
            UserAccount account = new UserAccount(
                    representation.getId(),
                    email,
                    valueOrEmpty(representation.getFirstName()),
                    valueOrEmpty(representation.getLastName()),
                    Boolean.TRUE.equals(representation.isEnabled()),
                    resolveRolFlujoEntities(roles)
            );
            userAccountRepository.save(account);
            synchronizedUsers++;
        }

        userAccountRepository.flush();
        return synchronizedUsers;
    }

    private Set<RolFlujo> resolveRolFlujoEntities(Set<SystemRole> systemRoles) {
        if (systemRoles == null || systemRoles.isEmpty()) {
            return new LinkedHashSet<>();
        }
        Set<RolFlujo> rolEntities = new LinkedHashSet<>();
        for (SystemRole role : systemRoles) {
            RolFlujo rolFlujo = rolFlujoRepository.findByNombreIgnoreCase(role.name())
                    .orElseGet(() -> rolFlujoRepository.save(new RolFlujo(role.name())));
            rolEntities.add(rolFlujo);
        }
        return rolEntities;
    }

    private String createInKeycloak(UsersResource users, UserRepresentation representation, String email) {
        try (Response response = users.create(representation)) {
            if (response.getStatus() == Response.Status.CONFLICT.getStatusCode()) {
                throw new UserAlreadyExistsException(email);
            }
            if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
                throw new UserProvisioningException(
                        "Keycloak rechazó la creación de la cuenta con estado HTTP " + response.getStatus()
                );
            }
            return CreatedResponseUtil.getCreatedId(response);
        } catch (UserAlreadyExistsException | UserProvisioningException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            throw new UserProvisioningException("No fue posible conectar con Keycloak", exception);
        }
    }

    private void setInitialPassword(
            UsersResource users,
            String keycloakUserId,
            String password,
            boolean requirePasswordChange
    ) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(password);
        credential.setTemporary(requirePasswordChange);
        users.get(keycloakUserId).resetPassword(credential);
    }

    private void assignRealmRoles(
            RealmResource realm,
            UsersResource users,
            String keycloakUserId,
            Set<SystemRole> roles
    ) {
        List<RoleRepresentation> roleRepresentations = roles.stream()
                .map(role -> realm.roles().get(role.name()).toRepresentation())
                .toList();
        users.get(keycloakUserId).roles().realmLevel().add(roleRepresentations);
    }

    private void deleteKeycloakUserQuietly(UsersResource users, String keycloakUserId, String email) {
        try {
            users.delete(keycloakUserId).close();
            log.warn("Se eliminó de Keycloak la cuenta {} porque no pudo persistirse completamente", email);
        } catch (RuntimeException exception) {
            log.error("No fue posible compensar la creación incompleta de la cuenta {}", email, exception);
        }
    }

    private Set<SystemRole> readSystemRoles(UsersResource users, String keycloakUserId) {
        Set<SystemRole> roles = EnumSet.noneOf(SystemRole.class);
        users.get(keycloakUserId).roles().realmLevel().listAll().stream()
                .map(RoleRepresentation::getName)
                .forEach(roleName -> {
                    try {
                        roles.add(SystemRole.valueOf(roleName));
                    } catch (IllegalArgumentException ignored) {
                        // Los roles internos de Keycloak no forman parte del dominio de la aplicación.
                    }
                });
        return roles;
    }

    private String normalizeEmail(UserRepresentation representation) {
        if (representation.getEmail() == null || representation.getEmail().isBlank()) {
            return null;
        }
        return representation.getEmail().trim().toLowerCase(Locale.ROOT);
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value.trim();
    }
}
