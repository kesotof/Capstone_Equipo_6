package com.capstone.sistema.flow.dto;

import java.time.Instant;

public record TransicionResponse(
        Long id,
        String estadoOrigen,
        String estadoDestino,
        String accion,
        String usuarioEmail,
        String usuarioNombre,
        String comentario,
        Instant createdAt
) {
}
