package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.SolicitudTransicion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SolicitudTransicionRepository extends JpaRepository<SolicitudTransicion, Long> {

    List<SolicitudTransicion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId);
}
