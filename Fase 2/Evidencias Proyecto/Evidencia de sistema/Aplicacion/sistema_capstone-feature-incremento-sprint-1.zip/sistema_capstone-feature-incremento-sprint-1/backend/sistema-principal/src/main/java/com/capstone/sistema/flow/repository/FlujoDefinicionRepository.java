package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.FlujoDefinicion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FlujoDefinicionRepository extends JpaRepository<FlujoDefinicion, Long> {

    Optional<FlujoDefinicion> findByNombreIgnoreCase(String nombre);
}
