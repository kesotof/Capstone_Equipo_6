package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.users.model.RolFlujo;
import com.capstone.sistema.users.model.SystemRole;
import com.capstone.sistema.users.model.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SolicitudServiceTest {

    @Mock
    private SolicitudRepository solicitudRepository;
    @Mock
    private DocumentoRepository documentoRepository;
    @Mock
    private FormatoDocumentoRepository formatoDocumentoRepository;
    @Mock
    private FlujoDefinicionRepository flujoDefinicionRepository;
    @Mock
    private FlujoEtapaRepository flujoEtapaRepository;
    @Mock
    private EstadoSolicitudRepository estadoSolicitudRepository;
    @Mock
    private AccionUsuarioRepository accionUsuarioRepository;
    @Mock
    private SolicitudTransicionRepository solicitudTransicionRepository;
    @Mock
    private ObservacionRepository observacionRepository;
    @Mock
    private MinioStorageService storageService;
    @Mock
    private NotificacionService notificacionService;
    @Mock
    private AuditService auditService;
    @Mock
    private CurrentUserResolver currentUserResolver;

    private SolicitudService solicitudService;

    private UserAccount emisor;
    private UserAccount revisor;
    private UserAccount admin;
    private FlujoDefinicion flujoDef;
    private FlujoEtapa etapa;
    private EstadoSolicitud estadoPendiente;
    private EstadoSolicitud estadoAprobado;
    private EstadoSolicitud estadoRechazado;
    private EstadoSolicitud estadoCorreccion;
    private AccionUsuario accionCrear;
    private AccionUsuario accionAprobar;
    private AccionUsuario accionRechazar;
    private AccionUsuario accionCorreccion;
    private AccionUsuario accionReenviar;

    @BeforeEach
    void setUp() {
        solicitudService = new SolicitudService(
                solicitudRepository,
                documentoRepository,
                formatoDocumentoRepository,
                flujoDefinicionRepository,
                flujoEtapaRepository,
                estadoSolicitudRepository,
                accionUsuarioRepository,
                solicitudTransicionRepository,
                observacionRepository,
                storageService,
                notificacionService,
                auditService,
                currentUserResolver
        );

        emisor = new UserAccount("kc-emisor", "emisor@test.local", "Juan", "Emisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(emisor, "id", UUID.randomUUID());

        revisor = new UserAccount("kc-revisor", "revisor@test.local", "Carlos", "Revisor", true, Set.of(new RolFlujo("APPROVER")));
        ReflectionTestUtils.setField(revisor, "id", UUID.randomUUID());

        admin = new UserAccount("kc-admin", "admin@test.local", "Super", "Admin", true, Set.of(new RolFlujo("ADMIN")));
        ReflectionTestUtils.setField(admin, "id", UUID.randomUUID());

        flujoDef = new FlujoDefinicion("Revisión Simple", "Flujo base");
        ReflectionTestUtils.setField(flujoDef, "id", 1L);

        etapa = new FlujoEtapa(flujoDef, 1, "Revisión");
        ReflectionTestUtils.setField(etapa, "id", 1L);

        estadoPendiente = new EstadoSolicitud(1L, "PENDIENTE_REVISION");
        estadoCorreccion = new EstadoSolicitud(2L, "CORRECCION_REQUERIDA");
        estadoAprobado = new EstadoSolicitud(3L, "APROBADO");
        estadoRechazado = new EstadoSolicitud(4L, "RECHAZADO");

        accionCrear = new AccionUsuario(1L, "CREAR");
        accionAprobar = new AccionUsuario(2L, "APROBAR");
        accionRechazar = new AccionUsuario(3L, "RECHAZAR");
        accionCorreccion = new AccionUsuario(4L, "PEDIR_CORRECCION");
        accionReenviar = new AccionUsuario(5L, "REENVIAR");
    }

    @Test
    void testCrearSolicitud_Success() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "informe_financiero.pdf", "application/pdf", "Contenido del PDF".getBytes()
        );

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(formatoDocumentoRepository.findByTipoIgnoreCase("pdf")).thenReturn(Optional.of(new FormatoDocumento(1L, "pdf")));
        when(flujoDefinicionRepository.findById(1L)).thenReturn(Optional.of(flujoDef));
        when(flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(1L, 1)).thenReturn(Optional.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("CREAR")).thenReturn(Optional.of(accionCrear));
        when(storageService.uploadFile(file)).thenReturn("informe_financiero_key.pdf");

        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(i -> {
            Solicitud s = i.getArgument(0);
            ReflectionTestUtils.setField(s, "id", UUID.randomUUID());
            return s;
        });
        when(documentoRepository.save(any(Documento.class))).thenAnswer(i -> {
            Documento d = i.getArgument(0);
            ReflectionTestUtils.setField(d, "id", UUID.randomUUID());
            return d;
        });

        CrearSolicitudResponse response = solicitudService.crearSolicitud("Informe Financiero", "Descripción", file);

        assertThat(response).isNotNull();
        assertThat(response.solicitudId()).isNotNull();
        assertThat(response.documentoId()).isNotNull();
        assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");

        verify(notificacionService).notificarNuevaSolicitud(any(Solicitud.class), any(SolicitudTransicion.class), eq(false));
        verify(auditService).registerUserManagementEvent(eq("CREAR_SOLICITUD"), eq(emisor), contains("informe_financiero.pdf"));
    }

    @Test
    void testCrearSolicitud_InvalidFormat_ThrowsInvalidDocumentFormat() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "script.exe", "application/octet-stream", "codigo binario".getBytes()
        );

        assertThatThrownBy(() -> solicitudService.crearSolicitud("Titulo", "Desc", file))
                .isInstanceOf(InvalidDocumentFormatException.class)
                .hasMessageContaining("Formato de archivo no permitido (.exe)");
    }

    @Test
    void testCrearSolicitud_AcceptsXmlAndTxtFormats() throws Exception {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(flujoDefinicionRepository.findById(1L)).thenReturn(Optional.of(flujoDef));
        when(flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(1L, 1)).thenReturn(Optional.of(etapa));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("CREAR")).thenReturn(Optional.of(accionCrear));
        when(solicitudRepository.save(any(Solicitud.class))).thenAnswer(invocation -> {
            Solicitud solicitud = invocation.getArgument(0);
            ReflectionTestUtils.setField(solicitud, "id", UUID.randomUUID());
            return solicitud;
        });
        when(documentoRepository.save(any(Documento.class))).thenAnswer(invocation -> {
            Documento documento = invocation.getArgument(0);
            ReflectionTestUtils.setField(documento, "id", UUID.randomUUID());
            return documento;
        });

        for (String extension : List.of("xml", "txt", "xlsx", "xls")) {
            String mimeType;
            if (extension.equals("xml")) mimeType = "application/xml";
            else if (extension.equals("txt")) mimeType = "text/plain";
            else if (extension.equals("xlsx")) mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            else mimeType = "application/vnd.ms-excel";

            MockMultipartFile file = new MockMultipartFile(
                    "file", "archivo." + extension,
                    mimeType,
                    "contenido válido".getBytes()
            );
            when(formatoDocumentoRepository.findByTipoIgnoreCase(extension))
                    .thenReturn(Optional.of(new FormatoDocumento(extension)));
            when(storageService.uploadFile(file)).thenReturn("documentos/archivo." + extension);

            CrearSolicitudResponse response = solicitudService.crearSolicitud("Documento " + extension, "", file);

            assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");
        }
    }

    @Test
    void testCrearSolicitud_EmptyTitle_ThrowsIllegalArgument() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "documento.pdf", "application/pdf", "Contenido".getBytes()
        );

        assertThatThrownBy(() -> solicitudService.crearSolicitud("", "Desc", file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("título del documento es obligatorio");
    }

    @Test
    void testAprobar_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento A", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("APROBADO")).thenReturn(Optional.of(estadoAprobado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("APROBAR")).thenReturn(Optional.of(accionAprobar));

        SolicitudResponse response = solicitudService.aprobar(solId);

        assertThat(response.estado()).isEqualTo("APROBADO");
        assertThat(solicitud.getEstadoSolicitud().getCodigo()).isEqualTo("APROBADO");

        verify(notificacionService).notificarAprobacion(eq(solicitud), any(SolicitudTransicion.class), eq(revisor), eq(false));
        verify(auditService).registerUserManagementEvent(eq("APROBAR_SOLICITUD"), eq(revisor), contains("Aprobación"));
    }

    @Test
    void testAprobar_EmisorCannotApprove_ThrowsUnauthorized() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento A", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);

        assertThatThrownBy(() -> solicitudService.aprobar(solId))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("no puede aprobar su propio documento");
    }

    @Test
    void testAprobar_AdminCanApproveOwnDocument() {
        // Solicitud emitida por admin
        Solicitud solicitud = new Solicitud(flujoDef, admin, "Documento Admin", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(admin));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(true);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("APROBADO")).thenReturn(Optional.of(estadoAprobado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("APROBAR")).thenReturn(Optional.of(accionAprobar));

        SolicitudResponse response = solicitudService.aprobar(solId);

        assertThat(response.estado()).isEqualTo("APROBADO");
        verify(notificacionService).notificarAprobacion(eq(solicitud), any(SolicitudTransicion.class), eq(admin), eq(false));
    }

    @Test
    void testAprobar_InvalidState_ThrowsInvalidTransition() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoAprobado, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));

        assertThatThrownBy(() -> solicitudService.aprobar(solId))
                .isInstanceOf(InvalidTransitionException.class)
                .hasMessageContaining("No se puede aprobar la solicitud");
    }

    @Test
    void testRechazar_FlujoSinRolesPermiteAlEmisorYNotifica() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento B", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("RECHAZADO")).thenReturn(Optional.of(estadoRechazado));
        when(accionUsuarioRepository.findByAccionIgnoreCase("RECHAZAR")).thenReturn(Optional.of(accionRechazar));

        SolicitudResponse response = solicitudService.rechazar(solId, "No cumple con las normas contables");

        assertThat(response.estado()).isEqualTo("RECHAZADO");
        verify(notificacionService).notificarRechazo(eq(solicitud), any(SolicitudTransicion.class), eq(emisor), eq("No cumple con las normas contables"), eq(false));
        verify(auditService).registerUserManagementEvent(eq("RECHAZAR_SOLICITUD"), eq(emisor), contains("No cumple con las normas contables"));
    }

    @Test
    void testRechazar_EmptyMotivo_ThrowsIllegalArgument() {
        UUID solId = UUID.randomUUID();

        assertThatThrownBy(() -> solicitudService.rechazar(solId, "   "))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("motivo del rechazo es obligatorio");
    }

    @Test
    void testPedirCorreccion_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento C", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("CORRECCION_REQUERIDA")).thenReturn(Optional.of(estadoCorreccion));
        when(accionUsuarioRepository.findByAccionIgnoreCase("PEDIR_CORRECCION")).thenReturn(Optional.of(accionCorreccion));
        when(solicitudTransicionRepository.save(any(SolicitudTransicion.class))).thenAnswer(i -> i.getArgument(0));

        SolicitudResponse response = solicitudService.pedirCorreccion(solId, "Falta firma en página 3");

        assertThat(response.estado()).isEqualTo("CORRECCION_REQUERIDA");
        verify(observacionRepository).save(any(Observacion.class));
        verify(notificacionService).notificarCorreccionRequerida(eq(solicitud), any(SolicitudTransicion.class), eq(revisor), eq("Falta firma en página 3"), eq(false));
    }

    @Test
    void testReenviar_Success() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Documento D", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(emisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);
        when(estadoSolicitudRepository.findByCodigoIgnoreCase("PENDIENTE_REVISION")).thenReturn(Optional.of(estadoPendiente));
        when(accionUsuarioRepository.findByAccionIgnoreCase("REENVIAR")).thenReturn(Optional.of(accionReenviar));
        when(observacionRepository.findBySolicitud_IdAndResueltaFalse(solId)).thenReturn(List.of());

        SolicitudResponse response = solicitudService.reenviar(solId, "Documento D Corregido", "Nueva desc", null);

        assertThat(response.estado()).isEqualTo("PENDIENTE_REVISION");
        verify(notificacionService).notificarReenvio(eq(solicitud), any(SolicitudTransicion.class), eq(false));
        verify(auditService).registerUserManagementEvent(eq("REENVIAR_SOLICITUD"), eq(emisor), contains("Documento D Corregido"));
    }

    @Test
    void testReenviar_NonEmisor_ThrowsUnauthorized() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoCorreccion, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(currentUserResolver.isCurrentUserAdmin()).thenReturn(false);

        assertThatThrownBy(() -> solicitudService.reenviar(solId, "Titulo", "Desc", null))
                .isInstanceOf(UnauthorizedActionException.class)
                .hasMessageContaining("Solo el emisor original puede reenviar");
    }

    @Test
    void testObtenerHistorial_ReturnsTransitionsInOrder() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Doc", "Desc", estadoPendiente, etapa);
        UUID solId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solId);

        SolicitudTransicion t1 = new SolicitudTransicion(solicitud, null, null, estadoPendiente, accionCrear, emisor, "Crear", "{}");
        ReflectionTestUtils.setField(t1, "id", 1L);
        SolicitudTransicion t2 = new SolicitudTransicion(solicitud, null, estadoPendiente, estadoAprobado, accionAprobar, revisor, "Aprobado", "{}");
        ReflectionTestUtils.setField(t2, "id", 2L);

        when(solicitudRepository.findById(solId)).thenReturn(Optional.of(solicitud));
        when(solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solId)).thenReturn(List.of(t1, t2));

        List<TransicionResponse> historial = solicitudService.obtenerHistorial(solId);

        assertThat(historial).hasSize(2);
        assertThat(historial.get(0).accion()).isEqualTo("CREAR");
        assertThat(historial.get(1).accion()).isEqualTo("APROBAR");
    }

    @Test
    void listarRevisionesPendientes_AplicaPaginacionYDevuelveProyeccion() {
        Solicitud solicitud = new Solicitud(flujoDef, emisor, "Contrato marco", "Desc", estadoPendiente, etapa);
        UUID solicitudId = UUID.randomUUID();
        ReflectionTestUtils.setField(solicitud, "id", solicitudId);
        ReflectionTestUtils.setField(solicitud, "createdAt", Instant.parse("2026-09-20T12:00:00Z"));

        Documento documento = new Documento(
                solicitud, new FormatoDocumento("pdf"), "contrato-marco.pdf", "application/pdf",
                "documentos/contrato-marco.pdf", 1024L, 1, true
        );

        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));
        when(solicitudRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(
                List.of(solicitud), PageRequest.of(0, 10), 11
        ));
        when(documentoRepository.findBySolicitud_IdInAndVigenteTrue(List.of(solicitudId)))
                .thenReturn(List.of(documento));

        PaginaSolicitudesPendientesResponse response = solicitudService.listarRevisionesPendientes(
                "contrato", "Juan", Instant.parse("2026-09-01T00:00:00Z"),
                Instant.parse("2026-09-30T23:59:59Z"), "PENDIENTE_REVISION", 0, 10
        );

        assertThat(response.totalElementos()).isEqualTo(11);
        assertThat(response.totalPaginas()).isEqualTo(2);
        assertThat(response.contenido()).singleElement().satisfies(item -> {
            assertThat(item.id()).isEqualTo(solicitudId);
            assertThat(item.nombreArchivo()).isEqualTo("contrato-marco.pdf");
            assertThat(item.emisorEmail()).isEqualTo("emisor@test.local");
        });
        verify(documentoRepository).findBySolicitud_IdInAndVigenteTrue(List.of(solicitudId));
    }

    @Test
    void testObtenerResumenDashboard_Approver() {
        when(currentUserResolver.resolveCurrentUser()).thenReturn(Optional.of(revisor));

        // Solicitud pendiente de revisión emitida por otro usuario
        Solicitud solParaRevisar = new Solicitud(flujoDef, emisor, "Doc de Emisor", "Desc", estadoPendiente, etapa);
        UUID solRevisarId = UUID.randomUUID();
        ReflectionTestUtils.setField(solParaRevisar, "id", solRevisarId);

        when(solicitudRepository.findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc("PENDIENTE_REVISION"))
                .thenReturn(List.of(solParaRevisar));

        // Solicitud propia del revisor que requiere corrección
        Solicitud solPropiaCorreccion = new Solicitud(flujoDef, revisor, "Mi Doc Observado", "Desc", estadoCorreccion, etapa);
        UUID solCorreccionId = UUID.randomUUID();
        ReflectionTestUtils.setField(solPropiaCorreccion, "id", solCorreccionId);

        when(solicitudRepository.findByEmisor_IdOrderByCreatedAtDesc(revisor.getId()))
                .thenReturn(List.of(solPropiaCorreccion));

        Observacion obs = new Observacion(solPropiaCorreccion, null, admin, "Falta la firma digital");
        when(observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solCorreccionId)).thenReturn(List.of(obs));

        DashboardResponse dashboard = solicitudService.obtenerResumenDashboard();

        assertThat(dashboard).isNotNull();
        assertThat(dashboard.accionesPendientes()).hasSize(2);
        assertThat(dashboard.misSolicitudesPendientes()).hasSize(1);

        boolean tieneRevision = dashboard.accionesPendientes().stream()
                .anyMatch(a -> "REVISION".equals(a.tipoAccion()) && a.solicitudId().equals(solRevisarId));
        boolean tieneCorreccion = dashboard.accionesPendientes().stream()
                .anyMatch(a -> "CORRECCION".equals(a.tipoAccion()) && a.solicitudId().equals(solCorreccionId)
                        && "Falta la firma digital".equals(a.ultimaObservacion()));

        assertThat(tieneRevision).isTrue();
        assertThat(tieneCorreccion).isTrue();
    }
}
