package com.capstone.sistema.flow.model;

import com.capstone.sistema.users.model.UserAccount;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "solicitud_transicion", indexes = {
        @Index(name = "idx_transicion_solicitud", columnList = "solicitud_id"),
        @Index(name = "idx_transicion_created", columnList = "created_at")
})
public class SolicitudTransicion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "solicitud_id", nullable = false)
    private Solicitud solicitud;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transicion_id")
    private Transicion transicion;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "estado_origen_id")
    private EstadoSolicitud estadoOrigen;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "estado_destino_id", nullable = false)
    private EstadoSolicitud estadoDestino;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "accion_usuario_id", nullable = false)
    private AccionUsuario accionUsuario;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private UserAccount usuario;

    @Column(columnDefinition = "TEXT")
    private String comentario;

    @Column(length = 4000)
    private String metadata = "{}";

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected SolicitudTransicion() {
    }

    public SolicitudTransicion(
            Solicitud solicitud,
            Transicion transicion,
            EstadoSolicitud estadoOrigen,
            EstadoSolicitud estadoDestino,
            AccionUsuario accionUsuario,
            UserAccount usuario,
            String comentario,
            String metadata
    ) {
        this.solicitud = solicitud;
        this.transicion = transicion;
        this.estadoOrigen = estadoOrigen;
        this.estadoDestino = estadoDestino;
        this.accionUsuario = accionUsuario;
        this.usuario = usuario;
        this.comentario = comentario;
        this.metadata = metadata != null ? metadata : "{}";
    }

    @PrePersist
    void onPrePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public void setSolicitud(Solicitud solicitud) {
        this.solicitud = solicitud;
    }

    public Transicion getTransicion() {
        return transicion;
    }

    public void setTransicion(Transicion transicion) {
        this.transicion = transicion;
    }

    public EstadoSolicitud getEstadoOrigen() {
        return estadoOrigen;
    }

    public void setEstadoOrigen(EstadoSolicitud estadoOrigen) {
        this.estadoOrigen = estadoOrigen;
    }

    public EstadoSolicitud getEstadoDestino() {
        return estadoDestino;
    }

    public void setEstadoDestino(EstadoSolicitud estadoDestino) {
        this.estadoDestino = estadoDestino;
    }

    public AccionUsuario getAccionUsuario() {
        return accionUsuario;
    }

    public void setAccionUsuario(AccionUsuario accionUsuario) {
        this.accionUsuario = accionUsuario;
    }

    public UserAccount getUsuario() {
        return usuario;
    }

    public void setUsuario(UserAccount usuario) {
        this.usuario = usuario;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
