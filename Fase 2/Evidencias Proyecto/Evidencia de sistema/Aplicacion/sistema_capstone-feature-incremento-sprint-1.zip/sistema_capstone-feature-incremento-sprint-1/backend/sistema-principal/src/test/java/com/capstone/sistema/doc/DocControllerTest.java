package com.capstone.sistema.doc;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.io.ByteArrayInputStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DocController.class)
@Import(SecurityConfig.class)
class DocControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MinioStorageService storageService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    void rejectsUnauthenticatedDownload() throws Exception {
        mockMvc.perform(get("/api/doc/download/archivo.pdf"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void rejectsUnauthenticatedUpload() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "dummy".getBytes());
        mockMvc.perform(multipart("/api/doc/upload").file(file))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void allowsAuthenticatedDownloadIntermediatedFromMinIO() throws Exception {
        when(storageService.downloadFile("archivo.pdf"))
                .thenReturn(new ByteArrayInputStream("contenido binario".getBytes()));

        mockMvc.perform(get("/api/doc/download/archivo.pdf")
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(header().string("Content-Disposition", "attachment; filename=\"archivo.pdf\""));
    }

    @Test
    void allowsAuthenticatedUploadIntermediatedToMinIO() throws Exception {
        when(storageService.uploadFile(any())).thenReturn("12345_test.xlsx");

        MockMultipartFile file = new MockMultipartFile(
                "file", "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "excel data".getBytes()
        );

        mockMvc.perform(multipart("/api/doc/upload")
                        .file(file)
                        .with(jwt().jwt(j -> j.claim("email", "user@capstone.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fileKey").value("12345_test.xlsx"));
    }
}
