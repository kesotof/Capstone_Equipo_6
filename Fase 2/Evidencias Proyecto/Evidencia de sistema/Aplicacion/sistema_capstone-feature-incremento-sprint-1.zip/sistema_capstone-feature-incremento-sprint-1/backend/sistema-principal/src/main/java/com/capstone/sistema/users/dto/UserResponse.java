package com.capstone.sistema.users.dto;

import com.capstone.sistema.users.model.SystemRole;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

public record UserResponse(
        UUID id,
        String keycloakUserId,
        String email,
        String firstName,
        String lastName,
        boolean enabled,
        boolean temporarilyLocked,
        Set<SystemRole> roles,
        Instant createdAt
) {
}
