package com.capstone.sistema.users.mapper;

import com.capstone.sistema.users.dto.UserResponse;
import com.capstone.sistema.users.model.UserAccount;

public final class UserMapper {

    private UserMapper() {
    }

    public static UserResponse toResponse(UserAccount user, boolean temporarilyLocked) {
        return new UserResponse(
                user.getId(),
                user.getKeycloakUserId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.isEnabled(),
                temporarilyLocked,
                user.getRoles(),
                user.getCreatedAt()
        );
    }
}
