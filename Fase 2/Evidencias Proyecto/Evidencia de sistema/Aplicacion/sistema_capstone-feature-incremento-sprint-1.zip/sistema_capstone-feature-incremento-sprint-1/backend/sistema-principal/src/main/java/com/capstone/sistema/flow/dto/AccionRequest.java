package com.capstone.sistema.flow.dto;

public record AccionRequest(
        String motivo,
        String observacion,
        Boolean notificarEmail
) {
    public String getComentarioValido() {
        if (motivo != null && !motivo.isBlank()) {
            return motivo.trim();
        }
        if (observacion != null && !observacion.isBlank()) {
            return observacion.trim();
        }
        return "";
    }

    public boolean isNotificarEmail() {
        return Boolean.TRUE.equals(notificarEmail);
    }
}
