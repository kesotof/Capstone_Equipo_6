package com.capstone.sistema.flow.config;

import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.model.AccionUsuario;
import com.capstone.sistema.flow.model.EstadoSolicitud;
import com.capstone.sistema.flow.model.FlujoDefinicion;
import com.capstone.sistema.flow.model.FlujoEtapa;
import com.capstone.sistema.flow.model.Transicion;
import com.capstone.sistema.flow.repository.AccionUsuarioRepository;
import com.capstone.sistema.flow.repository.EstadoSolicitudRepository;
import com.capstone.sistema.flow.repository.FlujoDefinicionRepository;
import com.capstone.sistema.flow.repository.FlujoEtapaRepository;
import com.capstone.sistema.flow.repository.TransicionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/** Garantiza los catálogos mínimos para operar el flujo documental base. */
@Component
public class DefaultFlowCatalogInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DefaultFlowCatalogInitializer.class);
    private static final String FLOW_NAME = "Revisión Simple";

    private final FlujoDefinicionRepository flujoDefinicionRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final EstadoSolicitudRepository estadoSolicitudRepository;
    private final AccionUsuarioRepository accionUsuarioRepository;
    private final TransicionRepository transicionRepository;
    private final FormatoDocumentoRepository formatoDocumentoRepository;

    public DefaultFlowCatalogInitializer(
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionUsuarioRepository accionUsuarioRepository,
            TransicionRepository transicionRepository,
            FormatoDocumentoRepository formatoDocumentoRepository
    ) {
        this.flujoDefinicionRepository = flujoDefinicionRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.estadoSolicitudRepository = estadoSolicitudRepository;
        this.accionUsuarioRepository = accionUsuarioRepository;
        this.transicionRepository = transicionRepository;
        this.formatoDocumentoRepository = formatoDocumentoRepository;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        EstadoSolicitud pendienteRevision = getOrCreateEstado("PENDIENTE_REVISION");
        EstadoSolicitud correccionRequerida = getOrCreateEstado("CORRECCION_REQUERIDA");
        EstadoSolicitud aprobado = getOrCreateEstado("APROBADO");
        EstadoSolicitud rechazado = getOrCreateEstado("RECHAZADO");

        AccionUsuario crear = getOrCreateAccion("CREAR");
        AccionUsuario aprobar = getOrCreateAccion("APROBAR");
        AccionUsuario rechazar = getOrCreateAccion("RECHAZAR");
        AccionUsuario pedirCorreccion = getOrCreateAccion("PEDIR_CORRECCION");
        AccionUsuario reenviar = getOrCreateAccion("REENVIAR");

        for (String formato : new String[]{"pdf", "docx", "doc", "xml", "txt"}) {
            formatoDocumentoRepository.findByTipoIgnoreCase(formato)
                    .orElseGet(() -> formatoDocumentoRepository.save(new FormatoDocumento(formato)));
        }

        FlujoDefinicion flujo = flujoDefinicionRepository.findByNombreIgnoreCase(FLOW_NAME)
                .orElseGet(() -> flujoDefinicionRepository.save(
                        new FlujoDefinicion(FLOW_NAME, "Flujo de 1 etapa para revisión de documentos")
                ));

        flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(flujo.getId(), 1)
                .orElseGet(() -> flujoEtapaRepository.save(new FlujoEtapa(flujo, 1, "Revisión")));

        ensureInitialTransition(flujo, pendienteRevision, crear);
        ensureTransition(flujo, pendienteRevision, aprobado, aprobar);
        ensureTransition(flujo, pendienteRevision, rechazado, rechazar);
        ensureTransition(flujo, pendienteRevision, correccionRequerida, pedirCorreccion);
        ensureTransition(flujo, correccionRequerida, pendienteRevision, reenviar);

        log.info("Catálogo base del flujo documental verificado para '{}'.", FLOW_NAME);
    }

    private EstadoSolicitud getOrCreateEstado(String codigo) {
        return estadoSolicitudRepository.findByCodigoIgnoreCase(codigo)
                .orElseGet(() -> estadoSolicitudRepository.save(new EstadoSolicitud(codigo)));
    }

    private AccionUsuario getOrCreateAccion(String accion) {
        return accionUsuarioRepository.findByAccionIgnoreCase(accion)
                .orElseGet(() -> accionUsuarioRepository.save(new AccionUsuario(accion)));
    }

    private void ensureInitialTransition(FlujoDefinicion flujo, EstadoSolicitud destino, AccionUsuario accion) {
        if (transicionRepository.findInitialTransition(flujo.getId(), accion.getAccion()).isEmpty()) {
            transicionRepository.save(new Transicion(flujo, null, destino, accion));
        }
    }

    private void ensureTransition(FlujoDefinicion flujo, EstadoSolicitud origen, EstadoSolicitud destino, AccionUsuario accion) {
        if (transicionRepository.findByFlujoAndEstadoOrigenAndAccion(
                flujo.getId(), origen.getCodigo(), accion.getAccion()).isEmpty()) {
            transicionRepository.save(new Transicion(flujo, origen, destino, accion));
        }
    }
}
