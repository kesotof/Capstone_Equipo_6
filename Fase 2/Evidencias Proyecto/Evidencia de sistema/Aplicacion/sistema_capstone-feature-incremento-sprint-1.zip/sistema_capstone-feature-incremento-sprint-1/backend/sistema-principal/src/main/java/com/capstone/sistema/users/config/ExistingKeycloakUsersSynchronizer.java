package com.capstone.sistema.users.config;

import com.capstone.sistema.users.service.UserManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class ExistingKeycloakUsersSynchronizer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(ExistingKeycloakUsersSynchronizer.class);

    private final UserManagementService userManagementService;

    public ExistingKeycloakUsersSynchronizer(UserManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }

    @Override
    public void run(ApplicationArguments args) {
        try {
            int synchronizedUsers = userManagementService.synchronizeExistingUsers();
            log.info("Sincronización inicial de Keycloak completada: {} cuenta(s) incorporada(s)", synchronizedUsers);
        } catch (RuntimeException exception) {
            log.warn("No fue posible sincronizar las cuentas existentes de Keycloak al iniciar", exception);
        }
    }
}
