package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Observacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ObservacionRepository extends JpaRepository<Observacion, Long> {

    List<Observacion> findBySolicitud_IdOrderByCreatedAtAsc(UUID solicitudId);

    List<Observacion> findBySolicitud_IdAndResueltaFalse(UUID solicitudId);
}
