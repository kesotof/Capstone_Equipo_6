package com.capstone.sistema.flow.controller;

import com.capstone.sistema.auth.KeycloakJwtAuthenticationConverter;
import com.capstone.sistema.auth.SecurityConfig;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.FlowExceptionHandler;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.service.SolicitudService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SolicitudController.class)
@Import({SecurityConfig.class, FlowExceptionHandler.class})
class SolicitudControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SolicitudService solicitudService;

    @MockBean
    private KeycloakJwtAuthenticationConverter keycloakJwtAuthenticationConverter;

    @Test
    void rejectsUnauthenticatedAccess() throws Exception {
        mockMvc.perform(get("/api/solicitudes/mis-solicitudes"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void crearSolicitud_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();
        when(solicitudService.crearSolicitud(eq("Informe 2026"), eq("Desc"), any(), eq(false)))
                .thenReturn(new CrearSolicitudResponse(solId, docId, "PENDIENTE_REVISION", "Documento registrado"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "informe.pdf", "application/pdf", "Contenido".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "Informe 2026")
                        .param("descripcion", "Desc")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.solicitudId").value(solId.toString()))
                .andExpect(jsonPath("$.documentoId").value(docId.toString()))
                .andExpect(jsonPath("$.estado").value("PENDIENTE_REVISION"));
    }

    @Test
    void crearSolicitud_InvalidFormat_Returns400ProblemDetail() throws Exception {
        when(solicitudService.crearSolicitud(any(), any(), any(), anyBoolean()))
                .thenThrow(new InvalidDocumentFormatException("Formato no permitido"));

        MockMultipartFile file = new MockMultipartFile(
                "file", "archivo.exe", "application/octet-stream", "bad".getBytes()
        );

        mockMvc.perform(multipart("/api/solicitudes")
                        .file(file)
                        .param("titulo", "Titulo")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Documento Inválido"))
                .andExpect(jsonPath("$.detail").value("Formato no permitido"));
    }

    @Test
    void aprobar_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false))).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "APROBADO", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("APROBADO"));
    }

    @Test
    void aprobar_UnauthorizedAction_Returns403ProblemDetail() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false)))
                .thenThrow(new UnauthorizedActionException("El emisor no puede aprobar su propio documento"));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.title").value("Acción No Autorizada"))
                .andExpect(jsonPath("$.detail").value("El emisor no puede aprobar su propio documento"));
    }

    @Test
    void aprobar_InvalidTransition_Returns409ProblemDetail() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.aprobar(eq(solId), eq(false)))
                .thenThrow(new InvalidTransitionException("No se puede aprobar la solicitud"));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/aprobar")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.title").value("Transición de Estado Inválida"));
    }

    @Test
    void rechazar_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.rechazar(eq(solId), eq("No cumple formato"), eq(false))).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "RECHAZADO", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/rechazar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"motivo\": \"No cumple formato\"}")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RECHAZADO"));
    }

    @Test
    void pedirCorreccion_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.pedirCorreccion(eq(solId), eq("Falta firma"), eq(false))).thenReturn(new SolicitudResponse(
                solId, "Titulo", "Desc", "CORRECCION_REQUERIDA", UUID.randomUUID(), "Emisor", "emisor@test.local",
                null, Instant.now(), Instant.now()
        ));

        mockMvc.perform(post("/api/solicitudes/" + solId + "/pedir-correccion")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"observacion\": \"Falta firma\"}")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CORRECCION_REQUERIDA"));
    }

    @Test
    void listarMisSolicitudes_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.listarMisSolicitudes()).thenReturn(List.of(
                new SolicitudResponse(solId, "Mi Solicitud", "Desc", "PENDIENTE_REVISION",
                        UUID.randomUUID(), "Emisor", "emisor@test.local", null, Instant.now(), Instant.now())
        ));

        mockMvc.perform(get("/api/solicitudes/mis-solicitudes")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Mi Solicitud"));
    }

    @Test
    void listarRevisionesPendientes_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        Instant fechaDesde = Instant.parse("2026-09-01T00:00:00Z");
        Instant fechaHasta = Instant.parse("2026-09-16T23:59:59Z");
        when(solicitudService.listarRevisionesPendientes(
                eq("contrato"), eq("emisor@test.local"), eq(fechaDesde), eq(fechaHasta),
                eq("PENDIENTE_REVISION"), eq(1), anyInt()
        )).thenReturn(new PaginaSolicitudesPendientesResponse(
                List.of(new SolicitudPendienteResponse(
                        solId, "Doc a Revisar", "contrato.pdf", "Emisor", "emisor@test.local",
                        Instant.now(), "PENDIENTE_REVISION"
                )),
                1, 10, 11, 2, false, true
        ));

        mockMvc.perform(get("/api/solicitudes/pendientes-revision")
                        .param("nombreArchivo", "contrato")
                        .param("emisor", "emisor@test.local")
                        .param("fechaDesde", fechaDesde.toString())
                        .param("fechaHasta", fechaHasta.toString())
                        .param("estado", "PENDIENTE_REVISION")
                        .param("pagina", "1")
                        .param("tamanio", "10")
                        .with(jwt().jwt(j -> j.claim("email", "revisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[0].titulo").value("Doc a Revisar"))
                .andExpect(jsonPath("$.contenido[0].nombreArchivo").value("contrato.pdf"))
                .andExpect(jsonPath("$.pagina").value(1))
                .andExpect(jsonPath("$.totalElementos").value(11));
    }

    @Test
    void obtenerHistorial_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerHistorial(solId)).thenReturn(List.of(
                new TransicionResponse(1L, "INICIAL", "PENDIENTE_REVISION", "CREAR",
                        "emisor@test.local", "Emisor", "Inicio", Instant.now())
        ));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/historial")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].accion").value("CREAR"));
    }

    @Test
    void obtenerObservaciones_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerObservaciones(solId)).thenReturn(List.of(
                new ObservacionResponse(1L, "Nota de corrección", false,
                        "revisor@test.local", "Revisor", Instant.now())
        ));

        mockMvc.perform(get("/api/solicitudes/" + solId + "/observaciones")
                        .with(jwt().jwt(j -> j.claim("email", "emisor@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].contenido").value("Nota de corrección"));
    }

    @Test
    void obtenerDashboard_Success() throws Exception {
        UUID solId = UUID.randomUUID();
        when(solicitudService.obtenerResumenDashboard()).thenReturn(new DashboardResponse(
                List.of(new AccionPendienteResponse(
                        solId, "Doc Pendiente", "REVISION", "Requiere tu revisión",
                        "PENDIENTE_REVISION", "Emisor Test", "emisor@test.local",
                        "doc.pdf", 1, Instant.now(), null
                )),
                List.of(new SolicitudResponse(
                        solId, "Doc en Trámite", "Desc", "PENDIENTE_REVISION",
                        UUID.randomUUID(), "Emisor", "emisor@test.local", null,
                        Instant.now(), Instant.now()
                ))
        ));

        mockMvc.perform(get("/api/solicitudes/dashboard")
                        .with(jwt().jwt(j -> j.claim("email", "usuario@test.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accionesPendientes[0].titulo").value("Doc Pendiente"))
                .andExpect(jsonPath("$.accionesPendientes[0].tipoAccion").value("REVISION"))
                .andExpect(jsonPath("$.misSolicitudesPendientes[0].titulo").value("Doc en Trámite"));
    }
}
