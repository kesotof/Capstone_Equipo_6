package com.capstone.sistema.flow.dto;

import java.util.List;

public record DashboardResponse(
        List<AccionPendienteResponse> accionesPendientes,
        List<SolicitudResponse> misSolicitudesPendientes
) {
}
