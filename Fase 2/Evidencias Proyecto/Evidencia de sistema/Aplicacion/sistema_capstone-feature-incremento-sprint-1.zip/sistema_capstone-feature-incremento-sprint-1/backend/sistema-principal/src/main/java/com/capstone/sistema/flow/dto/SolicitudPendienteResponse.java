package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

/** Proyección reducida para la tabla de revisiones, sin exponer entidades JPA. */
public record SolicitudPendienteResponse(
        UUID id,
        String titulo,
        String nombreArchivo,
        String emisorNombre,
        String emisorEmail,
        Instant fechaCreacion,
        String estado
) {
}
