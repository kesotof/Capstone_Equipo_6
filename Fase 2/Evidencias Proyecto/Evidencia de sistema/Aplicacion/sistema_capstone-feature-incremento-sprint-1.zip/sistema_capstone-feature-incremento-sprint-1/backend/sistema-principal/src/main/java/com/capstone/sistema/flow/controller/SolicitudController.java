package com.capstone.sistema.flow.controller;

import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.service.SolicitudService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

import java.io.InputStream;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Tag(name = "Solicitudes", description = "Gestión del ciclo de vida documental y motor de flujos de aprobación")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/solicitudes")
@PreAuthorize("isAuthenticated()")
@Validated
public class SolicitudController {

    private final SolicitudService solicitudService;

    public SolicitudController(SolicitudService solicitudService) {
        this.solicitudService = solicitudService;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CrearSolicitudResponse> crearSolicitud(
            @RequestParam("titulo") String titulo,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "notificarEmail", defaultValue = "false") boolean notificarEmail
    ) {
        CrearSolicitudResponse response = solicitudService.crearSolicitud(titulo, descripcion, file, notificarEmail);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/mis-solicitudes")
    public ResponseEntity<List<SolicitudResponse>> listarMisSolicitudes() {
        return ResponseEntity.ok(solicitudService.listarMisSolicitudes());
    }

    @Operation(summary = "Consultar revisiones pendientes", description = "Filtra por archivo, emisor, rango de fechas y estado; retorna una respuesta paginada.")
    @GetMapping("/pendientes-revision")
    public ResponseEntity<PaginaSolicitudesPendientesResponse> listarRevisionesPendientes(
            @RequestParam(required = false) String nombreArchivo,
            @RequestParam(required = false) String emisor,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(defaultValue = "0") @Min(0) int pagina,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int tamanio
    ) {
        return ResponseEntity.ok(solicitudService.listarRevisionesPendientes(
                nombreArchivo, emisor, fechaDesde, fechaHasta, estado, pagina, tamanio
        ));
    }

    @Operation(summary = "Obtener resumen del Dashboard", description = "Retorna las acciones pendientes del usuario y sus solicitudes emitidas en trámite")
    @GetMapping("/dashboard")
    public ResponseEntity<DashboardResponse> obtenerDashboard() {
        return ResponseEntity.ok(solicitudService.obtenerResumenDashboard());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SolicitudResponse> obtenerDetalle(@PathVariable UUID id) {
        return ResponseEntity.ok(solicitudService.obtenerDetalle(id));
    }

    @PostMapping("/{id}/aprobar")
    public ResponseEntity<SolicitudResponse> aprobar(
            @PathVariable UUID id,
            @RequestBody(required = false) AccionRequest request,
            @RequestParam(value = "notificarEmail", defaultValue = "false") boolean notificarEmailParam
    ) {
        boolean notificarEmail = (request != null && request.isNotificarEmail()) || notificarEmailParam;
        return ResponseEntity.ok(solicitudService.aprobar(id, notificarEmail));
    }

    @PostMapping("/{id}/rechazar")
    public ResponseEntity<SolicitudResponse> rechazar(
            @PathVariable UUID id,
            @RequestBody(required = false) AccionRequest request,
            @RequestParam(value = "motivo", required = false) String motivoParam,
            @RequestParam(value = "notificarEmail", defaultValue = "false") boolean notificarEmailParam
    ) {
        String motivo = request != null && request.getComentarioValido() != null && !request.getComentarioValido().isBlank()
                ? request.getComentarioValido()
                : motivoParam;
        boolean notificarEmail = (request != null && request.isNotificarEmail()) || notificarEmailParam;
        return ResponseEntity.ok(solicitudService.rechazar(id, motivo, notificarEmail));
    }

    @PostMapping("/{id}/pedir-correccion")
    public ResponseEntity<SolicitudResponse> pedirCorreccion(
            @PathVariable UUID id,
            @RequestBody(required = false) AccionRequest request,
            @RequestParam(value = "observacion", required = false) String observacionParam,
            @RequestParam(value = "notificarEmail", defaultValue = "false") boolean notificarEmailParam
    ) {
        String observacion = request != null && request.getComentarioValido() != null && !request.getComentarioValido().isBlank()
                ? request.getComentarioValido()
                : observacionParam;
        boolean notificarEmail = (request != null && request.isNotificarEmail()) || notificarEmailParam;
        return ResponseEntity.ok(solicitudService.pedirCorreccion(id, observacion, notificarEmail));
    }

    @PutMapping(value = "/{id}/reenviar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<SolicitudResponse> reenviar(
            @PathVariable UUID id,
            @RequestParam(value = "titulo", required = false) String titulo,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "notificarEmail", defaultValue = "false") boolean notificarEmail
    ) {
        return ResponseEntity.ok(solicitudService.reenviar(id, titulo, descripcion, file, notificarEmail));
    }

    @GetMapping("/{id}/historial")
    public ResponseEntity<List<TransicionResponse>> obtenerHistorial(@PathVariable UUID id) {
        return ResponseEntity.ok(solicitudService.obtenerHistorial(id));
    }

    @GetMapping("/{id}/observaciones")
    public ResponseEntity<List<ObservacionResponse>> obtenerObservaciones(@PathVariable UUID id) {
        return ResponseEntity.ok(solicitudService.obtenerObservaciones(id));
    }

    @GetMapping("/{id}/documento/descargar")
    public ResponseEntity<byte[]> descargarDocumento(@PathVariable UUID id) {
        try {
            Documento documento = solicitudService.obtenerDocumentoVigente(id);
            InputStream stream = solicitudService.descargarDocumento(id);
            byte[] bytes = stream.readAllBytes();

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + documento.getNombreArchivo() + "\"")
                    .contentType(MediaType.parseMediaType(documento.getContentType()))
                    .contentLength(bytes.length)
                    .body(bytes);
        } catch (Exception e) {
            throw new RuntimeException("Error al descargar el documento: " + e.getMessage(), e);
        }
    }
}
