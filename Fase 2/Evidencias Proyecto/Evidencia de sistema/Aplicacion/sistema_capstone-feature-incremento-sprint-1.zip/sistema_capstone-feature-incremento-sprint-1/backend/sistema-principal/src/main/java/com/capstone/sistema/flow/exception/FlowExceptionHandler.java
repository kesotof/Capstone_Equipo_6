package com.capstone.sistema.flow.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.net.URI;
import java.time.Instant;

@RestControllerAdvice
public class FlowExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(FlowExceptionHandler.class);

    @ExceptionHandler(SolicitudNotFoundException.class)
    public ProblemDetail handleSolicitudNotFound(SolicitudNotFoundException ex) {
        log.warn("Solicitud no encontrada: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Solicitud No Encontrada");
        problem.setType(URI.create("https://capstone.local/errors/solicitud-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(InvalidTransitionException.class)
    public ProblemDetail handleInvalidTransition(InvalidTransitionException ex) {
        log.warn("Transición inválida: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problem.setTitle("Transición de Estado Inválida");
        problem.setType(URI.create("https://capstone.local/errors/invalid-transition"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(UnauthorizedActionException.class)
    public ProblemDetail handleUnauthorizedAction(UnauthorizedActionException ex) {
        log.warn("Acción no autorizada en flujo: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, ex.getMessage());
        problem.setTitle("Acción No Autorizada");
        problem.setType(URI.create("https://capstone.local/errors/unauthorized-action"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(InvalidDocumentFormatException.class)
    public ProblemDetail handleInvalidDocumentFormat(InvalidDocumentFormatException ex) {
        log.warn("Documento inválido: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Documento Inválido");
        problem.setType(URI.create("https://capstone.local/errors/invalid-document"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ProblemDetail handleIllegalArgument(IllegalArgumentException ex) {
        log.warn("Solicitud inválida: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Solicitud Inválida");
        problem.setType(URI.create("https://capstone.local/errors/invalid-request"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(AiAnalysisNotFoundException.class)
    public ProblemDetail handleAiAnalysisNotFound(AiAnalysisNotFoundException ex) {
        log.warn("Análisis de IA no encontrado: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Análisis de IA No Encontrado");
        problem.setType(URI.create("https://capstone.local/errors/ai-analysis-not-found"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ProblemDetail handleMaxUploadSize(MaxUploadSizeExceededException ex) {
        log.warn("Tamaño de archivo excedido: {}", ex.getMessage());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST,
                "El tamaño del archivo excede el límite máximo permitido (10 MB)"
        );
        problem.setTitle("Tamaño de Archivo Excedido");
        problem.setType(URI.create("https://capstone.local/errors/max-upload-size"));
        problem.setProperty("timestamp", Instant.now());
        return problem;
    }
}
