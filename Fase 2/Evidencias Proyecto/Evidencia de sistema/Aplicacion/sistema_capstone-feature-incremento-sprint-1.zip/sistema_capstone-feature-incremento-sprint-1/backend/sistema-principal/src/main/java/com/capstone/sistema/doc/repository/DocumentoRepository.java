package com.capstone.sistema.doc.repository;

import com.capstone.sistema.doc.model.Documento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DocumentoRepository extends JpaRepository<Documento, UUID> {

    List<Documento> findBySolicitud_IdOrderByVersionDesc(UUID solicitudId);

    Optional<Documento> findBySolicitud_IdAndVigenteTrue(UUID solicitudId);

    List<Documento> findBySolicitud_IdInAndVigenteTrue(List<UUID> solicitudIds);
}
