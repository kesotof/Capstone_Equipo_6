package com.capstone.sistema.doc;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Map;

@Tag(name = "Documentos (Storage)", description = "Intermediario de almacenamiento y descarga controlada hacia MinIO S3 (Requiere autenticación JWT)")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/doc")
@PreAuthorize("isAuthenticated()")
public class DocController {

    private final MinioStorageService storageService;

    public DocController(MinioStorageService storageService) {
        this.storageService = storageService;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadDocument(@RequestParam("file") MultipartFile file) {
        try {
            String objectKey = storageService.uploadFile(file);
            return ResponseEntity.ok(Map.of(
                    "message", "Archivo almacenado en MinIO correctamente",
                    "fileKey", objectKey,
                    "originalName", file.getOriginalFilename()
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/download/{filename}")
    public ResponseEntity<?> downloadDocument(@PathVariable String filename) {
        try {
            InputStream stream = storageService.downloadFile(filename);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(stream.readAllBytes());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
}
