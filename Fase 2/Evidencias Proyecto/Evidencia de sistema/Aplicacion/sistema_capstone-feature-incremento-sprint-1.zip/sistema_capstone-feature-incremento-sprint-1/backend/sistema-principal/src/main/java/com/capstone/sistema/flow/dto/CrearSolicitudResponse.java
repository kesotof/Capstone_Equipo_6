package com.capstone.sistema.flow.dto;

import java.util.UUID;

public record CrearSolicitudResponse(
        UUID solicitudId,
        UUID documentoId,
        String estado,
        String mensaje
) {
}
