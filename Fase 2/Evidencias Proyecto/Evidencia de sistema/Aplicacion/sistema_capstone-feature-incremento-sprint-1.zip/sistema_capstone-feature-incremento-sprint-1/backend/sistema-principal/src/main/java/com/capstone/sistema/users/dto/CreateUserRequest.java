package com.capstone.sistema.users.dto;

import com.capstone.sistema.users.model.SystemRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record CreateUserRequest(
        @NotBlank(message = "El correo electrónico es obligatorio")
        @Email(message = "El correo electrónico no tiene un formato válido")
        @Size(max = 254, message = "El correo electrónico no puede superar 254 caracteres")
        String email,

        @NotBlank(message = "El nombre es obligatorio")
        @Size(max = 100, message = "El nombre no puede superar 100 caracteres")
        String firstName,

        @NotBlank(message = "El apellido es obligatorio")
        @Size(max = 100, message = "El apellido no puede superar 100 caracteres")
        String lastName,

        @NotBlank(message = "La contraseña inicial es obligatoria")
        @Size(min = 8, max = 128, message = "La contraseña debe tener entre 8 y 128 caracteres")
        String password,

        @NotEmpty(message = "Debe seleccionar al menos un rol")
        Set<@NotNull(message = "El rol no puede ser nulo") SystemRole> roles,

        boolean requirePasswordChange
) {
    @Override
    public String toString() {
        return "CreateUserRequest[email=" + email
                + ", firstName=" + firstName
                + ", lastName=" + lastName
                + ", password=[PROTECTED]"
                + ", roles=" + roles
                + ", requirePasswordChange=" + requirePasswordChange + "]";
    }
}
