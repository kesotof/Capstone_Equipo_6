package com.capstone.sistema.flow.repository;

import com.capstone.sistema.flow.model.Solicitud;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.UUID;

public interface SolicitudRepository extends JpaRepository<Solicitud, UUID>, JpaSpecificationExecutor<Solicitud> {

    @Override
    @EntityGraph(attributePaths = {"emisor", "estadoSolicitud"})
    Page<Solicitud> findAll(Specification<Solicitud> specification, Pageable pageable);

    List<Solicitud> findByEmisor_IdOrderByCreatedAtDesc(UUID emisorId);

    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc(String codigo);

    List<Solicitud> findByEstadoSolicitud_CodigoIgnoreCaseAndEmisor_IdNotOrderByCreatedAtDesc(String codigo, UUID emisorId);
}
