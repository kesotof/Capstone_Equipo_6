package com.capstone.sistema.flow.service;

import com.capstone.sistema.audit.service.AuditService;
import com.capstone.sistema.auth.CurrentUserResolver;
import com.capstone.sistema.doc.MinioStorageService;
import com.capstone.sistema.doc.model.Documento;
import com.capstone.sistema.doc.model.FormatoDocumento;
import com.capstone.sistema.doc.repository.DocumentoRepository;
import com.capstone.sistema.doc.repository.FormatoDocumentoRepository;
import com.capstone.sistema.flow.dto.*;
import com.capstone.sistema.flow.exception.InvalidDocumentFormatException;
import com.capstone.sistema.flow.exception.InvalidTransitionException;
import com.capstone.sistema.flow.exception.SolicitudNotFoundException;
import com.capstone.sistema.flow.exception.UnauthorizedActionException;
import com.capstone.sistema.flow.model.*;
import com.capstone.sistema.flow.repository.*;
import com.capstone.sistema.users.model.UserAccount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class SolicitudService {

    private static final Logger log = LoggerFactory.getLogger(SolicitudService.class);
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("pdf", "docx", "doc", "xml", "txt", "xlsx", "xls");

    private final SolicitudRepository solicitudRepository;
    private final DocumentoRepository documentoRepository;
    private final FormatoDocumentoRepository formatoDocumentoRepository;
    private final FlujoDefinicionRepository flujoDefinicionRepository;
    private final FlujoEtapaRepository flujoEtapaRepository;
    private final EstadoSolicitudRepository estadoSolicitudRepository;
    private final AccionUsuarioRepository accionUsuarioRepository;
    private final SolicitudTransicionRepository solicitudTransicionRepository;
    private final ObservacionRepository observacionRepository;
    private final MinioStorageService storageService;
    private final NotificacionService notificacionService;
    private final AuditService auditService;
    private final CurrentUserResolver currentUserResolver;

    public SolicitudService(
            SolicitudRepository solicitudRepository,
            DocumentoRepository documentoRepository,
            FormatoDocumentoRepository formatoDocumentoRepository,
            FlujoDefinicionRepository flujoDefinicionRepository,
            FlujoEtapaRepository flujoEtapaRepository,
            EstadoSolicitudRepository estadoSolicitudRepository,
            AccionUsuarioRepository accionUsuarioRepository,
            SolicitudTransicionRepository solicitudTransicionRepository,
            ObservacionRepository observacionRepository,
            MinioStorageService storageService,
            NotificacionService notificacionService,
            AuditService auditService,
            CurrentUserResolver currentUserResolver
    ) {
        this.solicitudRepository = solicitudRepository;
        this.documentoRepository = documentoRepository;
        this.formatoDocumentoRepository = formatoDocumentoRepository;
        this.flujoDefinicionRepository = flujoDefinicionRepository;
        this.flujoEtapaRepository = flujoEtapaRepository;
        this.estadoSolicitudRepository = estadoSolicitudRepository;
        this.accionUsuarioRepository = accionUsuarioRepository;
        this.solicitudTransicionRepository = solicitudTransicionRepository;
        this.observacionRepository = observacionRepository;
        this.storageService = storageService;
        this.notificacionService = notificacionService;
        this.auditService = auditService;
        this.currentUserResolver = currentUserResolver;
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file) {
        return crearSolicitud(titulo, descripcion, file, false);
    }

    @Transactional
    public CrearSolicitudResponse crearSolicitud(String titulo, String descripcion, MultipartFile file, boolean notificarEmail) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("El título del documento es obligatorio");
        }
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("El archivo del documento es obligatorio");
        }

        validarArchivo(file);

        UserAccount emisor = getAuthenticatedUser();
        String extension = extraerExtension(file.getOriginalFilename());
        FormatoDocumento formato = getOrCreateFormato(extension);

        FlujoDefinicion flujo = flujoDefinicionRepository.findById(1L)
                .or(() -> flujoDefinicionRepository.findByNombreIgnoreCase("Revisión Simple"))
                .orElseGet(() -> flujoDefinicionRepository.findAll().stream().findFirst()
                        .orElseThrow(() -> new IllegalStateException("No existe definición de flujo configurada en el sistema")));

        FlujoEtapa etapa = flujoEtapaRepository.findByFlujoDefinicion_IdAndOrden(flujo.getId(), 1)
                .orElseGet(() -> flujo.getEtapas().isEmpty() ? null : flujo.getEtapas().get(0));

        if (etapa == null) {
            etapa = flujoEtapaRepository.save(new FlujoEtapa(flujo, 1, "Revisión"));
        }

        EstadoSolicitud estadoPendiente = getEstado("PENDIENTE_REVISION");
        AccionUsuario accionCrear = getAccion("CREAR");

        Solicitud solicitud = new Solicitud(
                flujo,
                emisor,
                titulo.trim(),
                descripcion != null ? descripcion.trim() : "",
                estadoPendiente,
                etapa
        );
        solicitud = solicitudRepository.save(solicitud);

        String storageKey;
        try {
            storageKey = storageService.uploadFile(file);
        } catch (Exception e) {
            log.error("Error al almacenar archivo en MinIO: {}", e.getMessage(), e);
            throw new RuntimeException("Error al almacenar el archivo adjunto: " + e.getMessage(), e);
        }

        Documento documento = new Documento(
                solicitud,
                formato,
                file.getOriginalFilename(),
                file.getContentType() != null ? file.getContentType() : "application/octet-stream",
                storageKey,
                file.getSize(),
                1,
                true
        );
        documento = documentoRepository.save(documento);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                null,
                estadoPendiente,
                accionCrear,
                emisor,
                "Registro inicial de solicitud y carga de documento",
                "{}"
        );
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarNuevaSolicitud(solicitud, transicion, notificarEmail);
        auditService.registerUserManagementEvent("CREAR_SOLICITUD", emisor,
                "Registro de solicitud '" + solicitud.getTitulo() + "' con archivo: " + documento.getNombreArchivo());

        log.info("Solicitud creada exitosamente: id={}, emisor={}, archivo={}, email={}",
                solicitud.getId(), emisor.getEmail(), documento.getNombreArchivo(), notificarEmail);

        return new CrearSolicitudResponse(
                solicitud.getId(),
                documento.getId(),
                estadoPendiente.getCodigo(),
                "Documento registrado correctamente y solicitud enviada a revisión"
        );
    }

    @Transactional
    public SolicitudResponse aprobar(UUID solicitudId) {
        return aprobar(solicitudId, false);
    }

    @Transactional
    public SolicitudResponse aprobar(UUID solicitudId, boolean notificarEmail) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "aprobar");

        UserAccount currentUser = getAuthenticatedUser();
        validarPermisoRevisor(solicitud, currentUser, "aprobar");

        EstadoSolicitud estadoAprobado = getEstado("APROBADO");
        AccionUsuario accionAprobar = getAccion("APROBAR");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoAprobado);
        solicitudRepository.save(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoAprobado,
                accionAprobar,
                currentUser,
                "Solicitud aprobada por " + getNombreCompleto(currentUser),
                "{}"
        );
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarAprobacion(solicitud, transicion, currentUser, notificarEmail);
        auditService.registerUserManagementEvent("APROBAR_SOLICITUD", currentUser,
                "Aprobación de la solicitud '" + solicitud.getTitulo() + "'");

        log.info("Solicitud {} aprobada por {} (email={})", solicitudId, currentUser.getEmail(), notificarEmail);
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse rechazar(UUID solicitudId, String motivo) {
        return rechazar(solicitudId, motivo, false);
    }

    @Transactional
    public SolicitudResponse rechazar(UUID solicitudId, String motivo, boolean notificarEmail) {
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new IllegalArgumentException("El motivo del rechazo es obligatorio");
        }

        String motivoNormalizado = motivo.trim();

        Solicitud solicitud = getSolicitudEntity(solicitudId);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "rechazar");

        UserAccount currentUser = getAuthenticatedUser();

        EstadoSolicitud estadoRechazado = getEstado("RECHAZADO");
        AccionUsuario accionRechazar = getAccion("RECHAZAR");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoRechazado);
        solicitudRepository.save(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoRechazado,
                accionRechazar,
                currentUser,
                motivoNormalizado,
                "{}"
        );
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarRechazo(solicitud, transicion, currentUser, motivoNormalizado, notificarEmail);
        auditService.registerUserManagementEvent("RECHAZAR_SOLICITUD", currentUser,
                "Rechazo de solicitud '" + solicitud.getTitulo() + "'. Motivo: " + motivoNormalizado);

        log.info("Solicitud {} rechazada por {}: motivo={} (email={})", solicitudId, currentUser.getEmail(), motivoNormalizado, notificarEmail);
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse pedirCorreccion(UUID solicitudId, String observacion) {
        return pedirCorreccion(solicitudId, observacion, false);
    }

    @Transactional
    public SolicitudResponse pedirCorreccion(UUID solicitudId, String observacion, boolean notificarEmail) {
        if (observacion == null || observacion.trim().isEmpty()) {
            throw new IllegalArgumentException("La observación es obligatoria para solicitar correcciones");
        }

        Solicitud solicitud = getSolicitudEntity(solicitudId);
        validarEstadoActual(solicitud, "PENDIENTE_REVISION", "pedir corrección sobre");

        UserAccount currentUser = getAuthenticatedUser();
        validarPermisoRevisor(solicitud, currentUser, "solicitar correcciones a");

        EstadoSolicitud estadoCorreccion = getEstado("CORRECCION_REQUERIDA");
        AccionUsuario accionCorreccion = getAccion("PEDIR_CORRECCION");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoCorreccion);
        solicitudRepository.save(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoCorreccion,
                accionCorreccion,
                currentUser,
                observacion.trim(),
                "{}"
        );
        transicion = solicitudTransicionRepository.save(transicion);

        Observacion obs = new Observacion(
                solicitud,
                transicion,
                currentUser,
                observacion.trim()
        );
        observacionRepository.save(obs);

        notificacionService.notificarCorreccionRequerida(solicitud, transicion, currentUser, observacion.trim(), notificarEmail);
        auditService.registerUserManagementEvent("PEDIR_CORRECCION", currentUser,
                "Solicitud de corrección para '" + solicitud.getTitulo() + "'. Observación: " + observacion.trim());

        log.info("Corrección requerida para solicitud {} por {}: observacion={} (email={})",
                solicitudId, currentUser.getEmail(), observacion.trim(), notificarEmail);
        return toDto(solicitud);
    }

    @Transactional
    public SolicitudResponse reenviar(UUID solicitudId, String titulo, String descripcion, MultipartFile nuevoArchivo) {
        return reenviar(solicitudId, titulo, descripcion, nuevoArchivo, false);
    }

    @Transactional
    public SolicitudResponse reenviar(UUID solicitudId, String titulo, String descripcion, MultipartFile nuevoArchivo, boolean notificarEmail) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        validarEstadoActual(solicitud, "CORRECCION_REQUERIDA", "reenviar");

        UserAccount currentUser = getAuthenticatedUser();
        boolean isAdmin = currentUserResolver.isCurrentUserAdmin();
        if (!solicitud.getEmisor().getId().equals(currentUser.getId()) && !isAdmin) {
            throw new UnauthorizedActionException("Solo el emisor original puede reenviar la solicitud corregida");
        }

        if (titulo != null && titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("El título del documento es obligatorio");
        }
        if (titulo != null) {
            solicitud.setTitulo(titulo.trim());
        }
        if (descripcion != null) {
            solicitud.setDescripcion(descripcion.trim());
        }

        if (nuevoArchivo != null && !nuevoArchivo.isEmpty()) {
            validarArchivo(nuevoArchivo);
            String extension = extraerExtension(nuevoArchivo.getOriginalFilename());
            FormatoDocumento formato = getOrCreateFormato(extension);

            Documento documentoPrevio = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId).orElse(null);
            int nuevaVersion = documentoPrevio != null ? documentoPrevio.getVersion() + 1 : 1;

            String storageKey;
            try {
                storageKey = storageService.uploadFile(nuevoArchivo);
                registrarEliminacionEnRollback(storageKey);
            } catch (Exception e) {
                log.error("Error al almacenar archivo corregido en MinIO: {}", e.getMessage(), e);
                throw new RuntimeException("Error al almacenar el nuevo archivo adjunto: " + e.getMessage(), e);
            }

            if (documentoPrevio != null) {
                documentoPrevio.setVigente(false);
                documentoRepository.save(documentoPrevio);
            }

            Documento nuevoDocumento = new Documento(
                    solicitud,
                    formato,
                    nuevoArchivo.getOriginalFilename(),
                    nuevoArchivo.getContentType() != null ? nuevoArchivo.getContentType() : "application/octet-stream",
                    storageKey,
                    nuevoArchivo.getSize(),
                    nuevaVersion,
                    true
            );
            documentoRepository.save(nuevoDocumento);
        }

        List<Observacion> observaciones = observacionRepository.findBySolicitud_IdAndResueltaFalse(solicitudId);
        for (Observacion obs : observaciones) {
            obs.setResuelta(true);
            observacionRepository.save(obs);
        }

        EstadoSolicitud estadoPendiente = getEstado("PENDIENTE_REVISION");
        AccionUsuario accionReenviar = getAccion("REENVIAR");

        EstadoSolicitud estadoOrigen = solicitud.getEstadoSolicitud();
        solicitud.setEstadoSolicitud(estadoPendiente);
        solicitudRepository.save(solicitud);

        SolicitudTransicion transicion = new SolicitudTransicion(
                solicitud,
                null,
                estadoOrigen,
                estadoPendiente,
                accionReenviar,
                currentUser,
                "Solicitud subsanada y reenviada para nueva revisión",
                "{}"
        );
        solicitudTransicionRepository.save(transicion);

        notificacionService.notificarReenvio(solicitud, transicion, notificarEmail);
        auditService.registerUserManagementEvent("REENVIAR_SOLICITUD", currentUser,
                "Reenvío de solicitud corregida '" + solicitud.getTitulo() + "'");

        log.info("Solicitud {} reenviada a revisión por {} (email={})", solicitudId, currentUser.getEmail(), notificarEmail);
        return toDto(solicitud);
    }

    private void registrarEliminacionEnRollback(String storageKey) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            log.warn("No existe una transacción activa para registrar la compensación del archivo {}", storageKey);
            return;
        }

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status != TransactionSynchronization.STATUS_ROLLED_BACK) {
                    return;
                }

                try {
                    storageService.deleteFile(storageKey);
                    log.info("Archivo {} eliminado de MinIO después del rollback del reenvío", storageKey);
                } catch (Exception ex) {
                    log.error("No fue posible compensar el archivo {} en MinIO después del rollback", storageKey, ex);
                }
            }
        });
    }

    @Transactional(readOnly = true)
    public SolicitudResponse obtenerDetalle(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        return toDto(solicitud);
    }

    @Transactional(readOnly = true)
    public List<SolicitudResponse> listarMisSolicitudes() {
        UserAccount currentUser = getAuthenticatedUser();
        return solicitudRepository.findByEmisor_IdOrderByCreatedAtDesc(currentUser.getId())
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public PaginaSolicitudesPendientesResponse listarRevisionesPendientes(
            String nombreArchivo,
            String emisor,
            Instant fechaDesde,
            Instant fechaHasta,
            String estado,
            int pagina,
            int tamanio
    ) {
        getAuthenticatedUser();
        String estadoEfectivo = estado == null || estado.isBlank() ? "PENDIENTE_REVISION" : estado;

        Specification<Solicitud> specification = Specification
                .where(SolicitudSpecifications.conEstado(estadoEfectivo))
                .and(SolicitudSpecifications.conNombreArchivo(nombreArchivo))
                .and(SolicitudSpecifications.emitidaPor(emisor))
                .and(SolicitudSpecifications.creadaDesde(fechaDesde))
                .and(SolicitudSpecifications.creadaHasta(fechaHasta));

        Pageable pageable = PageRequest.of(pagina, tamanio, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Solicitud> solicitudes = solicitudRepository.findAll(specification, pageable);
        Map<UUID, Documento> documentosVigentes = documentosVigentesPorSolicitud(solicitudes.getContent());

        List<SolicitudPendienteResponse> contenido = solicitudes.getContent().stream()
                .map(solicitud -> toPendienteDto(solicitud, documentosVigentes.get(solicitud.getId())))
                .toList();

        return new PaginaSolicitudesPendientesResponse(
                contenido,
                solicitudes.getNumber(),
                solicitudes.getSize(),
                solicitudes.getTotalElements(),
                solicitudes.getTotalPages(),
                solicitudes.isFirst(),
                solicitudes.isLast()
        );
    }

    @Transactional(readOnly = true)
    public DashboardResponse obtenerResumenDashboard() {
        UserAccount currentUser = getAuthenticatedUser();

        // Sprint 1 usa un flujo simplificado sin asignación de revisores: todo usuario
        // autenticado puede ver y revisar solicitudes pendientes, incluso las propias.
        List<Solicitud> pendientesRevision =
                solicitudRepository.findByEstadoSolicitud_CodigoIgnoreCaseOrderByCreatedAtDesc("PENDIENTE_REVISION");

        // 2. Solicitudes del usuario
        List<Solicitud> misSolicitudes = solicitudRepository.findByEmisor_IdOrderByCreatedAtDesc(currentUser.getId());

        // Filtrar las que requieren corrección por parte del usuario
        List<Solicitud> misCorreccionesRequeridas = misSolicitudes.stream()
                .filter(s -> "CORRECCION_REQUERIDA".equalsIgnoreCase(s.getEstadoSolicitud().getCodigo()))
                .toList();

        // Filtrar solicitudes emitidas que siguen en trámite (PENDIENTE_REVISION o CORRECCION_REQUERIDA)
        List<SolicitudResponse> misSolicitudesPendientes = misSolicitudes.stream()
                .filter(s -> {
                    String codigo = s.getEstadoSolicitud().getCodigo();
                    return "PENDIENTE_REVISION".equalsIgnoreCase(codigo) || "CORRECCION_REQUERIDA".equalsIgnoreCase(codigo);
                })
                .map(this::toDto)
                .toList();

        // 3. Construir lista unificada de acciones pendientes
        List<AccionPendienteResponse> accionesPendientes = new ArrayList<>();

        // Agregar revisiones pendientes
        for (Solicitud s : pendientesRevision) {
            Documento vigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
            accionesPendientes.add(new AccionPendienteResponse(
                    s.getId(),
                    s.getTitulo(),
                    "REVISION",
                    "Requiere tu revisión y decisión",
                    s.getEstadoSolicitud().getCodigo(),
                    getNombreCompleto(s.getEmisor()),
                    s.getEmisor().getEmail(),
                    vigente != null ? vigente.getNombreArchivo() : "",
                    vigente != null ? vigente.getVersion() : 1,
                    s.getCreatedAt(),
                    null
            ));
        }

        // Agregar correcciones pendientes del usuario
        for (Solicitud s : misCorreccionesRequeridas) {
            Documento vigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
            List<Observacion> observaciones = observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(s.getId());
            String ultimaObsTexto = null;
            if (!observaciones.isEmpty()) {
                ultimaObsTexto = observaciones.stream()
                        .filter(o -> !o.isResuelta())
                        .reduce((first, second) -> second)
                        .map(Observacion::getContenido)
                        .orElse(observaciones.get(observaciones.size() - 1).getContenido());
            }

            accionesPendientes.add(new AccionPendienteResponse(
                    s.getId(),
                    s.getTitulo(),
                    "CORRECCION",
                    "Requiere subsanación de observaciones",
                    s.getEstadoSolicitud().getCodigo(),
                    getNombreCompleto(s.getEmisor()),
                    s.getEmisor().getEmail(),
                    vigente != null ? vigente.getNombreArchivo() : "",
                    vigente != null ? vigente.getVersion() : 1,
                    s.getUpdatedAt() != null ? s.getUpdatedAt() : s.getCreatedAt(),
                    ultimaObsTexto
            ));
        }

        // Ordenar las acciones por fecha descendente
        accionesPendientes.sort((a, b) -> {
            if (a.fecha() == null && b.fecha() == null) return 0;
            if (a.fecha() == null) return 1;
            if (b.fecha() == null) return -1;
            return b.fecha().compareTo(a.fecha());
        });

        return new DashboardResponse(accionesPendientes, misSolicitudesPendientes);
    }

    @Transactional(readOnly = true)
    public List<TransicionResponse> obtenerHistorial(UUID solicitudId) {
        getSolicitudEntity(solicitudId); // Valida que exista
        return solicitudTransicionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solicitudId)
                .stream()
                .map(t -> new TransicionResponse(
                        t.getId(),
                        t.getEstadoOrigen() != null ? t.getEstadoOrigen().getCodigo() : "INICIAL",
                        t.getEstadoDestino().getCodigo(),
                        t.getAccionUsuario().getAccion(),
                        t.getUsuario().getEmail(),
                        getNombreCompleto(t.getUsuario()),
                        t.getComentario(),
                        t.getCreatedAt()
                ))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<ObservacionResponse> obtenerObservaciones(UUID solicitudId) {
        Solicitud solicitud = getSolicitudEntity(solicitudId);
        UserAccount currentUser = getAuthenticatedUser();
        if (!solicitud.getEmisor().getId().equals(currentUser.getId())
                && !currentUserResolver.isCurrentUserAdmin()) {
            throw new UnauthorizedActionException("Solo el emisor puede consultar las observaciones de esta solicitud");
        }
        return observacionRepository.findBySolicitud_IdOrderByCreatedAtAsc(solicitudId)
                .stream()
                .map(o -> new ObservacionResponse(
                        o.getId(),
                        o.getContenido(),
                        o.isResuelta(),
                        o.getUsuario().getEmail(),
                        getNombreCompleto(o.getUsuario()),
                        o.getCreatedAt()
                ))
                .toList();
    }

    @Transactional(readOnly = true)
    public InputStream descargarDocumento(UUID solicitudId) throws Exception {
        Documento documento = documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new SolicitudNotFoundException("No se encontró un documento vigente para la solicitud " + solicitudId));
        return storageService.downloadFile(documento.getStorageKey());
    }

    @Transactional(readOnly = true)
    public Documento obtenerDocumentoVigente(UUID solicitudId) {
        return documentoRepository.findBySolicitud_IdAndVigenteTrue(solicitudId)
                .orElseThrow(() -> new SolicitudNotFoundException("No se encontró un documento vigente para la solicitud " + solicitudId));
    }

    private void validarArchivo(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidDocumentFormatException("Es obligatorio adjuntar un archivo de documento");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new InvalidDocumentFormatException("El archivo excede el tamaño máximo permitido de 10 MB");
        }
        String filename = file.getOriginalFilename();
        if (filename == null || !filename.contains(".")) {
            throw new InvalidDocumentFormatException("El archivo debe tener una extensión válida (.pdf, .docx, .doc, .xml, .txt, .xlsx, .xls)");
        }
        String extension = extraerExtension(filename);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new InvalidDocumentFormatException(
                    "Formato de archivo no permitido (." + extension + "). Formatos aceptados: .doc, .docx, .pdf, .xml, .txt, .xlsx, .xls"
            );
        }
    }

    private String extraerExtension(String filename) {
        if (filename == null) return "";
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == filename.length() - 1) return "";
        return filename.substring(dotIndex + 1).toLowerCase(Locale.ROOT);
    }

    private void validarEstadoActual(Solicitud solicitud, String estadoEsperado, String accionNombre) {
        String estadoActual = solicitud.getEstadoSolicitud().getCodigo();
        if (!estadoActual.equalsIgnoreCase(estadoEsperado)) {
            throw new InvalidTransitionException(
                    "No se puede " + accionNombre + " la solicitud porque su estado actual es '" +
                    estadoActual + "' (se requiere '" + estadoEsperado + "')"
            );
        }
    }

    private void validarPermisoRevisor(Solicitud solicitud, UserAccount currentUser, String accionNombre) {
        boolean isAdmin = currentUserResolver.isCurrentUserAdmin();
        if (solicitud.getEmisor().getId().equals(currentUser.getId()) && !isAdmin) {
            throw new UnauthorizedActionException(
                    "El emisor de la solicitud no puede " + accionNombre + " su propio documento"
            );
        }
    }

    private Solicitud getSolicitudEntity(UUID id) {
        return solicitudRepository.findById(id)
                .orElseThrow(() -> new SolicitudNotFoundException(id));
    }

    private UserAccount getAuthenticatedUser() {
        return currentUserResolver.resolveCurrentUser()
                .orElseThrow(() -> new UnauthorizedActionException("Usuario no autenticado o no encontrado en el sistema"));
    }

    private EstadoSolicitud getEstado(String codigo) {
        return estadoSolicitudRepository.findByCodigoIgnoreCase(codigo)
                .orElseThrow(() -> new IllegalStateException("Estado no configurado en el sistema: " + codigo));
    }

    private AccionUsuario getAccion(String accion) {
        return accionUsuarioRepository.findByAccionIgnoreCase(accion)
                .orElseThrow(() -> new IllegalStateException("Acción no configurada en el sistema: " + accion));
    }

    private FormatoDocumento getOrCreateFormato(String extension) {
        return formatoDocumentoRepository.findByTipoIgnoreCase(extension)
                .orElseGet(() -> formatoDocumentoRepository.save(new FormatoDocumento(extension)));
    }

    private SolicitudResponse toDto(Solicitud s) {
        Documento docVigente = documentoRepository.findBySolicitud_IdAndVigenteTrue(s.getId()).orElse(null);
        DocumentoResponse docDto = docVigente != null ? new DocumentoResponse(
                docVigente.getId(),
                docVigente.getNombreArchivo(),
                docVigente.getContentType(),
                docVigente.getSizeBytes(),
                docVigente.getVersion(),
                docVigente.isVigente(),
                docVigente.getCreatedAt()
        ) : null;

        return new SolicitudResponse(
                s.getId(),
                s.getTitulo(),
                s.getDescripcion(),
                s.getEstadoSolicitud().getCodigo(),
                s.getEmisor().getId(),
                getNombreCompleto(s.getEmisor()),
                s.getEmisor().getEmail(),
                docDto,
                s.getCreatedAt(),
                s.getUpdatedAt()
        );
    }

    private Map<UUID, Documento> documentosVigentesPorSolicitud(List<Solicitud> solicitudes) {
        if (solicitudes.isEmpty()) {
            return Map.of();
        }

        List<UUID> solicitudIds = solicitudes.stream().map(Solicitud::getId).toList();
        return documentoRepository.findBySolicitud_IdInAndVigenteTrue(solicitudIds).stream()
                .collect(Collectors.toMap(
                        documento -> documento.getSolicitud().getId(),
                        Function.identity(),
                        (primero, ignorado) -> primero
                ));
    }

    private SolicitudPendienteResponse toPendienteDto(Solicitud solicitud, Documento documentoVigente) {
        return new SolicitudPendienteResponse(
                solicitud.getId(),
                solicitud.getTitulo(),
                documentoVigente != null ? documentoVigente.getNombreArchivo() : null,
                getNombreCompleto(solicitud.getEmisor()),
                solicitud.getEmisor().getEmail(),
                solicitud.getCreatedAt(),
                solicitud.getEstadoSolicitud().getCodigo()
        );
    }

    private String getNombreCompleto(UserAccount u) {
        if (u == null) return "";
        String f = u.getFirstName() != null ? u.getFirstName() : "";
        String l = u.getLastName() != null ? u.getLastName() : "";
        String full = (f + " " + l).trim();
        return full.isEmpty() ? u.getEmail() : full;
    }
}
