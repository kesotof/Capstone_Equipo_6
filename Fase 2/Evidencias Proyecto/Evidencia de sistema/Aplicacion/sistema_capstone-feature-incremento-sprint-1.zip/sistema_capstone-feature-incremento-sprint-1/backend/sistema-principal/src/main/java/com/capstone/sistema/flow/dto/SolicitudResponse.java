package com.capstone.sistema.flow.dto;

import java.time.Instant;
import java.util.UUID;

public record SolicitudResponse(
        UUID id,
        String titulo,
        String descripcion,
        String estado,
        UUID emisorId,
        String emisorNombre,
        String emisorEmail,
        DocumentoResponse documentoVigente,
        Instant createdAt,
        Instant updatedAt
) {
}
