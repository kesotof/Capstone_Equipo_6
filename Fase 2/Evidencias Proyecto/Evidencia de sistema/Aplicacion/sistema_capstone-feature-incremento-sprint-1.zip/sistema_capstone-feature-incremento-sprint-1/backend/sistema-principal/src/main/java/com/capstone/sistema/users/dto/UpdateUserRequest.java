package com.capstone.sistema.users.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record UpdateUserRequest(
        @NotBlank(message = "El nombre es obligatorio")
        @Size(max = 100, message = "El nombre no puede superar 100 caracteres")
        String firstName,

        @NotBlank(message = "El apellido es obligatorio")
        @Size(max = 100, message = "El apellido no puede superar 100 caracteres")
        String lastName,

        @Size(min = 8, message = "La nueva contraseña debe contener al menos 8 caracteres")
        String newPassword,

        Boolean requirePasswordChange
) {
    public UpdateUserRequest(String firstName, String lastName) {
        this(firstName, lastName, null, null);
    }

    @Override
    public String toString() {
        return "UpdateUserRequest[firstName=" + firstName
                + ", lastName=" + lastName
                + ", newPassword=" + (newPassword != null ? "[PROTECTED]" : "null")
                + ", requirePasswordChange=" + requirePasswordChange + "]";
    }
}
