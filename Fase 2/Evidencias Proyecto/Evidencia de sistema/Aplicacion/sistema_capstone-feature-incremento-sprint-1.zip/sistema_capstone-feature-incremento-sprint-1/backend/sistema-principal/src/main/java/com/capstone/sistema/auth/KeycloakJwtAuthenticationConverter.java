package com.capstone.sistema.auth;

import com.capstone.sistema.users.repository.UserAccountRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.InvalidBearerTokenException;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;

@Component
public class KeycloakJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final UserAccountRepository userAccountRepository;

    public KeycloakJwtAuthenticationConverter(UserAccountRepository userAccountRepository) {
        this.userAccountRepository = userAccountRepository;
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        validateActiveLocalUser(jwt);
        Collection<GrantedAuthority> authorities = extractRealmRoles(jwt);
        String principalName = jwt.getClaimAsString("email");

        if (principalName == null || principalName.isBlank()) {
            principalName = jwt.getClaimAsString("preferred_username");
        }

        return new JwtAuthenticationToken(jwt, authorities, principalName);
    }

    private void validateActiveLocalUser(Jwt jwt) {
        String keycloakUserId = jwt.getSubject();
        if (keycloakUserId == null || keycloakUserId.isBlank()) {
            throw new InvalidBearerTokenException("El token no contiene un identificador de usuario válido");
        }

        boolean activeUser = userAccountRepository.findByKeycloakUserId(keycloakUserId)
                .map(user -> user.isEnabled())
                .orElse(false);
        if (!activeUser) {
            throw new InvalidBearerTokenException("La cuenta no existe o no está habilitada");
        }
    }

    private Collection<GrantedAuthority> extractRealmRoles(Jwt jwt) {
        Map<String, Object> realmAccess = jwt.getClaimAsMap("realm_access");
        if (realmAccess == null) {
            return List.of();
        }

        Object rolesClaim = realmAccess.get("roles");
        if (!(rolesClaim instanceof Collection<?> roles)) {
            return List.of();
        }

        return roles.stream()
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .<GrantedAuthority>map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                .toList();
    }
}
