# Estructura del Proyecto y Catálogo Arquitectónico

> **Documento de Contexto Rápido para Agentes y Desarrolladores**  
> Este documento centraliza la arquitectura física, el catálogo exhaustivo de archivos y los flujos de integración del **Sistema de Gestión Documental y Flujos de Aprobación (Capstone)**. Permite a cualquier agente autónomo situarse de inmediato en el repositorio sin necesidad de escanear o leer todos los archivos individualmente.

---

## 1. Visión General de la Arquitectura

El sistema está diseñado bajo una arquitectura de microservicios desacoplados orientados a eventos, complementados por un frontend SPA en React y servicios base contenerizados:

```mermaid
graph TD
    User["Usuario / Navegador"] -->|HTTP / SPA :3000| Front["Frontend (React + Vite)"]
    Front -->|OIDC Login / Token JWT| KC["Keycloak SSO (:8080)"]
    Front -->|REST API + Bearer JWT :8081| SisPrin["Sistema Principal (:8081)\nSpring Boot 3.2"]

    SisPrin -->|Validación JWT Certs| KC
    SisPrin -->|Persistencia Metadatos :5432| PG_Sis[("PostgreSQL\nsistema_db")]
    KC -->|Persistencia Realm :5432| PG_KC[("PostgreSQL\nkeycloak_db")]
    SisPrin -->|Almacenamiento S3 :9000| MinIO[("MinIO S3\nBucket 'documentos'")]
    SisPrin -->|Eventos Topic :5672| RMQ{{"RabbitMQ Broker\ncapstone.exchange"}}

    RMQ -->|notifications.email\nnotifications.email.queue| SvcNotif["Service Notificaciones (:8082)\nSpring Boot 3.2"]
    RMQ -->|ai.analysis\nai.queue| SvcIA["Service Consultas IA (:8083)\nSpring Boot 3.2"]

    SvcNotif -->|REST API HTTPS| Resend["Resend API\n(Despacho Correos)"]
    SvcIA -->|REST API HTTPS| OpenRouter["OpenRouter API\n(Análisis Documental)"]
    SvcIA -->|Descarga S3| MinIO
    SvcIA -->|ai.results\nai.results.queue| RMQ
```

---

## 2. Catálogo de Archivos y Responsabilidades

### 2.1 Raíz del Repositorio

| Archivo / Carpeta | Propósito / Responsabilidad |
| :--- | :--- |
| [`AGENTS.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/AGENTS.md) | **Mapa y guía maestra** para agentes de codificación. Define el flujo de inicio, reglas operativas y referencias a este catálogo. |
| [`PROJECT_STRUCTURE.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/PROJECT_STRUCTURE.md) | Este documento: inventario técnico completo, arquitectura detallada y guía de contexto rápido. |
| [`feature_list.json`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/feature_list.json) | **Única fuente de verdad** del backlog del proyecto. Lista de épicas (`infra-001` a `front-001`), criterios de aceptación, estado y evidencia. |
| [`claude-progress.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/claude-progress.md) | Bitácora de trabajo continuo: registra el último estado verificado, decisiones técnicas y el siguiente paso inmediato. |
| [`docker-compose.yml`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docker-compose.yml) | Definición orquestada de todos los servicios: PostgreSQL, Keycloak, RabbitMQ, MinIO, más las 4 aplicaciones bajo el profile `apps`. |
| [`docker-compose.vps.yml`](./docker-compose.vps.yml) | Ajustes del VPS: Keycloak en modo servidor, Nginx con HTTPS y el certificado montado desde el host. Combinar con `docker-compose.yml`. |
| [`.gitattributes`](./.gitattributes) | Conserva finales LF en scripts shell para ejecutarlos dentro de contenedores Linux, también desde checkouts de Windows. |
| [`.env`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.env) / [`.env.example`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.env.example) | Parámetros de entorno centralizados: credenciales de base de datos, puertos, claves de APIs (Gemini, MasterBase) y endpoints. |
| [`init.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/init.ps1) | Script de arranque y diagnóstico para Windows PowerShell. |
| [`init.sh`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/init.sh) | Script de arranque y diagnóstico para Linux / Bash / WSL. |
| [`tests/e2e/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/) | **Suite de Pruebas E2E y Regresión**: Casos de prueba Playwright en contenedor oficial (`mcr.microsoft.com/playwright`), con soporte headless y servidor UI web interactivo. |
| [`scripts/run-e2e-tests.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.ps1) / [`.sh`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.sh) | Scripts unificados para ejecutar la suite de Playwright en Docker con verificación previa de servicios. |
| [`scripts/reload-capstone-nginx.sh`](./scripts/reload-capstone-nginx.sh) | Hook de Certbot que recarga Nginx después de renovar el certificado TLS del VPS. |
| [`.agents/skills/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/.agents/skills/) | **Habilidades y Conocimiento para Agentes**: Skills de buenas prácticas de Spring Boot 3 y recopilación Local-First de documentación oficial de Spring. |
| [`docs/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/) | **Gobernanza, Backlog y Contratos**: Contratos REST ([`docs/API_CONTRACTS.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/API_CONTRACTS.md)), Swagger UI (`http://localhost:8081/swagger-ui.html`), matriz de permisos/roles de artefactos en Google Drive ([`GOBERNANZA_DOCUMENTAL.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/GOBERNANZA_DOCUMENTAL.md)) y réplicas locales del Sprint Backlog ([`docs/sprint-backlog/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docs/sprint-backlog/)). |
| [`README.md`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/README.md) | Documentación de presentación para humanos y descripción del proyecto académico Capstone. |


---

### 2.2 Frontend SPA (`frontend/`)

- **Tecnologías**: React 18, Vite 5, React Router DOM 6, Axios, Keycloak-js.
- **Puerto expuesto en Docker**: `3000` (Nginx Alpine reverse proxy a `index.html`).

```
frontend/
├── Dockerfile                  # Construcción multi-stage (Node 20 build -> Nginx Alpine runtime)
├── .dockerignore               # Excluye dependencias, compilaciones y archivos .env del contexto Docker
├── nginx.conf                  # SPA y proxy de /api al backend para frontend y API en el mismo origen
├── nginx.vps.conf              # HTTPS, validación ACME y proxy privado hacia Keycloak/API en el VPS
├── package.json                # Dependencias (react, react-router-dom, axios, keycloak-js)
├── DESIGN_SYSTEM.md            # Guía visual empresarial: tokens, patrones UI, accesibilidad y responsive
├── vite.config.js              # Configuración de compilación Vite y servidor dev (puerto 3000)
├── index.html                  # Plantilla HTML base (título "MasterBase · Gestión documental", favicon autómata)
├── public/
│   ├── masterbase-wordmark.png # Logotipo del sidebar (copia del usado en el tema de Keycloak)
│   └── masterbase-automata.png # Favicon
└── src/
    ├── main.jsx                # Inicializa la sesión Keycloak y monta la aplicación React
    ├── App.jsx                 # Shell: sidebar (logo, navegación por grupos, tarjeta de usuario con cierre de sesión), topbar con ruta actual y rutas según roles
    ├── App.css                 # Estilos globales por secciones: tokens, shell, componentes, vistas y responsive
    ├── services/
    │   ├── keycloak.js         # Cliente OIDC: login-required, PKCE S256, logout y consulta de roles
    │   └── api.js              # Cliente Axios con interceptor que inyecta Bearer JWT automáticamente
    ├── components/
    │   ├── NotificationBell.jsx    # Centro de actividad: tipos, filtros, lectura y enlaces contextuales
    │   ├── ObservationTimeline.jsx # Línea de tiempo de observaciones con autor, fecha y estado
    │   └── ui/index.jsx            # Biblioteca compartida: Button, PageHeader, FormField, StatusBadge, FeedbackMessage, EmptyState, DataTable, Card, FileTypeIcon, DateTimeStack, DetailModal, useMediaQuery y utilidades de formato
    └── views/
        ├── acceso/
        │   └── RecuperarPasswordView.jsx   # Instrucciones para recuperación de clave en Keycloak
        ├── configuracion/
        │   ├── ConfigurarFlujosView.jsx       # Gestión de etapas, nombres de flujo y aprobadores
        │   ├── ConfigurarOrgUsuariosView.jsx  # Administración de departamentos y asignación de roles
        │   └── ConfigurarPlanillasView.jsx    # Diseñador de planillas y formularios dinámicos
        ├── dashboard/
        │   └── DashboardView.jsx              # Cockpit operativo: indicadores (revisiones, correcciones, en trámite, resueltas), acciones requeridas y solicitudes en trámite
        ├── documentos/
        │   ├── NuevoDocumentoView.jsx      # Registro de solicitudes: formulario + panel "¿Cómo funciona?", drag-and-drop, validación (10 MB), progreso Axios y confirmación
        │   ├── MisDocumentosView.jsx       # Listado de documentos con búsqueda y filtros por estado (en cliente), seguimiento y descarga
        │   └── CompletarPlanillaView.jsx   # Llenado de campos para planillas estructuradas
        └── flujos/
            ├── RevisarDocumentoView.jsx    # Bandeja de revisión: filtros, paginación, modal centrado, previsualización y confirmaciones; soporte ?id=
            ├── CorregirDocumentoView.jsx   # Lista/detalle (modal bajo 1120 px): observaciones del revisor, edición de datos, reemplazo de archivo y reenvío
            └── EstadoSolicitudesView.jsx   # Lista/detalle (modal bajo 1120 px): estado, documento vigente y línea de tiempo (más reciente primero, con código de auditoría)
```

---

### 2.3 Backend: Sistema Principal (`backend/sistema-principal/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring Data JPA, Spring Security OAuth2 Resource Server, Spring AMQP (RabbitMQ), MinIO SDK 8.5.10, PostgreSQL Driver.
- **Puerto expuesto**: `8081`.
- **Base de Datos**: PostgreSQL (`sistema_db`).

```
backend/sistema-principal/
├── Dockerfile                  # Multi-stage: Maven 3.9 + Eclipse Temurin 21 -> Temurin 21 JRE
├── pom.xml                     # Web, Security, AMQP, JPA, MinIO, Actuator, Validation y Keycloak Admin Client
└── src/
    └── main/
        ├── java/com/capstone/sistema/
        │   ├── SistemaPrincipalApplication.java  # Clase principal Spring Boot
        │   ├── auth/
        │   │   ├── SecurityConfig.java           # OAuth2 Resource Server, CORS y seguridad por métodos
        │   │   └── KeycloakJwtAuthenticationConverter.java
        │   │                                     # Valida usuario activo local por JWT sub y convierte realm_access.roles a ROLE_*
        │   ├── audit/                            # Auditoría de acciones de seguridad (log_evento)
        │   │   ├── controller/AuditController.java # POST /api/audit/login y POST /api/audit/logout
        │   │   ├── dto/AuditEventResponse.java     # Contrato inmutable de respuesta
        │   │   ├── model/                          # LogEvento y TipoEvento JPA
        │   │   ├── repository/                     # LogEventoRepository y TipoEventoRepository
        │   │   └── service/AuditService.java       # Persistencia de auditoría (login, logout, gestión de usuarios con actor, IP y sanitización CWE-532)
        │   ├── doc/
        │   │   ├── DocController.java            # Endpoints: POST /api/doc/upload, GET /api/doc/download/{file}
        │   │   ├── model/                        # Documento y FormatoDocumento JPA
        │   │   ├── repository/                   # DocumentoRepository y FormatoDocumentoRepository
        │   │   └── MinioStorageService.java      # Servicio wrapper S3: subida, descarga y verificación de bucket
        │   ├── flow/
        │   │   ├── controller/
        │   │   │   ├── SolicitudController.java    # REST API: POST /api/solicitudes (multipart), mis-solicitudes, pendientes, dashboard, aprobar, rechazar, pedir-correccion, reenviar, historial, observaciones, descargar
        │   │   │   └── NotificacionController.java # REST API: GET /api/notificaciones, /no-leidas/count, PATCH /{id}/leer
        │   │   ├── dto/                            # Records Java 21: CrearSolicitudResponse, SolicitudResponse, DashboardResponse, AccionPendienteResponse, DocumentoResponse, TransicionResponse, ObservacionResponse, AccionRequest, NotificacionResponse
        │   │   ├── exception/                      # SolicitudNotFoundException, InvalidTransitionException, UnauthorizedActionException, InvalidDocumentFormatException, FlowExceptionHandler (ProblemDetail RFC 7807)
        │   │   ├── service/
        │   │   │   ├── SolicitudService.java       # Motor de flujos: ciclo de vida documental, validación de formatos (.pdf/.docx/.doc/.xml/.txt), MinIO S3, versionamiento, máquina de estados y auditoría
        │   │   │   └── NotificacionService.java    # Notificaciones in-app contextuales persistidas en PostgreSQL
        │   │   ├── model/                          # FlujoDefinicion, FlujoEtapa, FlujoEtapaRoles, Solicitud,
        │   │   │                                   # Transicion, SolicitudTransicion, Observacion, Notificacion,
        │   │   │                                   # AccionUsuario, EstadoSolicitud, TipoNotificacion
        │   │   ├── repository/                     # Repositorios JPA: SolicitudRepository, TransicionRepository, FlujoEtapaRepository, NotificacionRepository, ObservacionRepository, etc.
        │   │   ├── FlowController.java             # Stubs previos de flujo y eventos RabbitMQ
        │   │   ├── RabbitConfig.java               # Declaración del TopicExchange "capstone.exchange"
        │   │   └── config/DefaultFlowCatalogInitializer.java # Crea catálogos y flujo base si faltan semillas
        │   ├── org/
        │   │   └── OrgController.java            # Endpoints: GET /api/org/config, GET /api/org/users
        │   └── users/                            # Administración de cuentas y organización (usuario, area, rol_flujo)
        │       ├── config/                        # Cliente administrativo y sincronización inicial desde Keycloak
        │       ├── controller/UserController.java # POST, GET, PUT /{id}, PATCH /{id}/status, DELETE /{id}
        │       ├── dto/                           # CreateUserRequest, UpdateUserRequest, ToggleUserStatusRequest, UserResponse
        │       ├── exception/                     # Errores ProblemDetail 400/404/409/502 (UserNotFoundException, etc.)
        │       ├── mapper/UserMapper.java
        │       ├── model/                         # UserAccount (usuario), Area, RolFlujo y SystemRole
        │       ├── repository/                    # UserAccountRepository, AreaRepository, RolFlujoRepository
        │       └── service/UserManagementService.java
        └── resources/
            ├── application.yml                   # Configuración DataSource PostgreSQL, RabbitMQ, Keycloak JWK, MinIO
            └── schema-postgresql.sql             # DDL PostgreSQL con 19 tablas, constraints, índices y semillas iniciales
└── src/test/java/com/capstone/sistema/
    ├── auth/KeycloakJwtAuthenticationConverterTest.java # Pruebas de roles y principal por correo
    ├── audit/controller/AuditControllerTest.java        # Pruebas HTTP 201 login/logout y 401 sin JWT
    ├── audit/service/AuditServiceTest.java              # Registro de login/logout con captura de IP
    ├── flow/DataModelEntitiesTest.java                  # Pruebas unitarias de todo el modelo relacional JPA
    └── users/service/UserManagementServiceTest.java     # Pruebas de provisión con resolución de RolFlujo
```

---

### 2.4 Backend: Servicio Notificaciones (`backend/service-notificaciones/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring AMQP, Spring Web (`RestClient`).
- **Puerto expuesto**: `8082`.
- **Responsabilidad**: Consumidor asíncrono desacoplado para despacho de emails transaccionales a través de la API de MasterBase®.

```
backend/service-notificaciones/
├── Dockerfile
├── pom.xml
└── src/
    └── main/
        ├── java/com/capstone/notificaciones/
        │   ├── NotificacionesApplication.java
        │   ├── config/
        │   │   └── RabbitConfig.java               # Configuración de Jackson2JsonMessageConverter para RabbitMQ
        │   ├── consumer/
        │   │   └── NotificationQueueListener.java  # @RabbitListener en "notifications.email.queue", key "notifications.email"
        │   ├── template/
        │   │   └── EmailTemplateService.java       # Motor de plantillas HTML y texto plano para notificaciones transaccionales
        │   └── client/
        │       └── ResendEmailClient.java          # Cliente HTTP hacia Resend API (/emails) con soporte de simulación y timer
        └── resources/
            └── application.yml                     # Configuración RabbitMQ y parámetros Resend (Key, From, Simulación)
```

---

### 2.5 Backend: Servicio Consultas IA (`backend/service-ia/`)

- **Tecnologías**: Java 21, Spring Boot 3.2.5, Spring AMQP, MinIO S3 SDK, Apache Tika 2.9, Spring Web (`RestClient`).
- **Puerto expuesto**: `8083`.
- **Responsabilidad**: Worker asíncrono desacoplado para auditoría documental inteligente y evaluación contra reglas de negocio con OpenRouter API (modelos LLM como LLaMA 3.3 70B Instruct). Utiliza el Claim Check Pattern para descargar documentos desde MinIO S3 y Apache Tika para extracción universal de texto (.pdf, .docx, .doc, .xlsx, .xls, .xml, .txt).

```
backend/service-ia/
├── Dockerfile
├── pom.xml
└── src/
    └── main/
        ├── java/com/capstone/ia/
        │   ├── IaApplication.java
        │   ├── config/
        │   │   ├── MinioConfig.java            # Configuración de MinioClient
        │   │   └── RabbitConfig.java           # Jackson2JsonMessageConverter y RabbitTemplate
        │   ├── service/
        │   │   ├── MinioDocumentReader.java    # Descarga de stream desde bucket documentos
        │   │   └── DocumentTextExtractor.java  # Extracción universal de texto con Apache Tika y truncado
        │   ├── client/
        │   │   ├── dto/
        │   │   │   └── OpenRouterDto.java      # Records Java 21 para Chat Completions API
        │   │   └── OpenRouterApiClient.java    # Cliente HTTP OpenRouter con modo simulación y fallbacks
        │   └── consumer/
        │       └── AiTaskListener.java         # @RabbitListener en "ai.queue" (key "ai.analysis"), emite a "ai.results"
        └── resources/
            └── application.yml                 # RabbitMQ, MinIO S3, OpenRouter y límite de caracteres
```

---

### 2.6 Infraestructura y Provisionamiento Docker (`docker/`)

```
docker/
├── keycloak/
│   ├── Dockerfile              # Imagen Keycloak 24.0.5 + proveedor local y tema de mensajes
│   ├── capstone-realm.json     # Realm "capstone-realm": cliente, roles, login por correo y fuerza bruta; carga inicialmente con el flujo browser estándar
│   ├── configure-login-flow.sh # Provisiona de forma idempotente el flujo browser personalizado
│   ├── provider/               # JAR Maven: reemplaza solo el formulario usuario/contraseña
│   │   └── src/main/...        # Muestra el aviso explícito de bloqueo temporal (30 minutos) por fuerza bruta
│   └── themes/capstone/login/  # Acceso empresarial MasterBase con animación y recuperación
│       ├── template.ftl        # Layout compartido; mantiene formularios y sesión nativos de Keycloak 24
│       ├── mascot.svg          # Personaje vectorial editable, incluido inline por FreeMarker
│       ├── resources/css/capstone-login.css # Paneles intercambiables, responsive y movimiento reducido
│       └── resources/js/capstone-login.js   # Mirada, párpados y transición al enlace nativo de recuperación
├── minio/
│   └── create-buckets.sh       # Script para contenedor minio-init: conecta mc y crea bucket "documentos"
├── postgres/
│   └── init/
│       └── 01-init-databases.sh # Script ejecutado al primer inicio de PostgreSQL:
│                                # - Crea BD 'keycloak_db' y usuario 'keycloak_user'
│                                # - Crea BD 'sistema_db' y usuario 'sistema_user'
│                                # - Asigna privilegios sobre esquema public
└── mcp-gws/
    ├── README.md               # Guía del servidor MCP Google Workspace y Protocolo de Ediciones Seguras
    └── credentials/            # Credenciales Service Account / OAuth (ignoradas en git)
        ├── credentials.example.json
        └── client_secret.example.json
```

---

### 2.7 Habilidades y Base de Conocimiento de Agentes (`.agents/skills/`)

Skills de espacio de trabajo que dotan a los agentes autónomos de mejores prácticas y un mecanismo eficiente para investigar y consultar documentación oficial de Spring Boot:

```
.agents/skills/
├── spring-boot-best-practices/
│   ├── SKILL.md                # Guía de estándares: arquitectura de capas, inyección limpia,
│   │                           # DTO records, Spring Security 6, JPA, RabbitMQ y testing.
│   └── references/
│       ├── rest-api-standards.md        # Nomenclatura REST, códigos HTTP y ProblemDetail.
│       ├── jpa-performance-rules.md     # Prevención N+1, FetchType.LAZY y proyecciones.
│       └── security-rbac-guidelines.md  # Configuración RBAC @PreAuthorize con Keycloak.
│
└── spring-docs-research/
    ├── SKILL.md                # Protocolo Local-First: busca en local; si no existe, busca
    │                           # en docs.spring.io y persiste el conocimiento en Markdown.
    └── references/
        ├── INDEX.md            # Índice maestro de documentación técnica local.
        ├── security-oauth2-resource-server.md # Spring Security 6.2 Resource Server JWT.
        ├── amqp-rabbitmq-json.md              # Spring AMQP y serialización Jackson JSON.
        ├── minio-s3-integration.md            # MinIO Java SDK 8.5+ con Spring Boot.
        └── restclient-spring-boot-3.md        # API fluida RestClient (Spring Boot 3.2+).
```

---

### 2.8 Suite de Pruebas Automatizadas y de Regresión E2E (`tests/e2e/`)

Módulo contenerizado con la suite oficial de pruebas de extremo a extremo y regresión continua del sistema:

```
tests/e2e/
├── Dockerfile                  # Contenedor oficial mcr.microsoft.com/playwright con socat
├── docker-entrypoint.sh        # Enrutamiento de localhost hacia los contenedores de red Docker
├── package.json                # Dependencias (@playwright/test, typescript) y scripts npm
├── tsconfig.json               # Configuración de TypeScript
├── playwright.config.ts        # Configuración de Playwright (Chromium, reporter list/html, traces)
├── README.md                   # Manual de uso y guía de extensión para desarrolladores
└── src/
    ├── pages/                  # Page Object Models (POM) reutilizables
    │   ├── LoginPage.ts        # Interacción con formulario OIDC Keycloak MasterBase
    │   ├── DashboardPage.ts    # Interacción con Dashboard y layout principal
    │   └── UsersPage.ts        # Interacción con vista y modales de Organización y Usuarios
    └── specs/                  # Casos de prueba automatizados por módulo
        └── auth/
            ├── login-flow.spec.ts      # Regresión: redirección OIDC, errores y login exitoso
            └── user-management.spec.ts # HU-03: Alta, edición, desactivación, reactivación, unicidad y baja de usuarios
```

**Ejecución Rápida**:
- En Windows: `.\scripts\run-e2e-tests.ps1` (o con flag interactivo: `.\scripts\run-e2e-tests.ps1 -UI`)
- En Linux / Bash: `./scripts/run-e2e-tests.sh`
- Con Docker Compose: `docker compose run --rm playwright-tests`


---

## 3. Matriz de Servicios, Puertos y Credenciales

| Contenedor Docker | Servicio | Puerto Host | Credenciales por Defecto | Variables de Entorno Clave |
| :--- | :--- | :--- | :--- | :--- |
| `capstone-postgres` | PostgreSQL 16 | `5432` | `postgres` / `postgres_secure_pass`<br>`sistema_user` / `sistema_secure_pass`<br>`keycloak_user` / `keycloak_secure_pass` | `POSTGRES_PASSWORD`, `SISTEMA_DB_*`, `KEYCLOAK_DB_*` |
| `capstone-keycloak` | Keycloak 24.0.5 con extensión local de aviso de bloqueo | `8080` | Consola Admin: `admin` / `admin_secure_pass`<br>Usuarios Realm: ver catálogo `capstone-realm.json` | `KC_DB_URL`, `KEYCLOAK_ADMIN`, `KEYCLOAK_ADMIN_PASSWORD` |
| `capstone-keycloak-init` | Inicializador efímero del flujo de autenticación | — | Usa el administrador técnico de Keycloak | `KEYCLOAK_ADMIN`, `KEYCLOAK_ADMIN_PASSWORD`, `KEYCLOAK_REALM` |
| `capstone-rabbitmq` | RabbitMQ 3.13 | `5672` (AMQP)<br>`15672` (UI) | `guest` / `guest` | `RABBITMQ_DEFAULT_USER`, `RABBITMQ_DEFAULT_PASS` |
| `capstone-minio` | MinIO S3 API / UI | `9000` (API)<br>`9001` (UI) | `minioadmin` / `minioadmin_secure_pass` | `MINIO_ROOT_USER`, `MINIO_ROOT_PASSWORD` |
| `capstone-sistema-principal` | Spring Boot (App Principal) | `8081` | Requiere Token Bearer JWT (Keycloak) | `SPRING_DATASOURCE_URL`, `KEYCLOAK_AUTH_SERVER_URL` |
| `capstone-service-notificaciones` | Spring Boot (Notificaciones Resend) | `8082` | No expone endpoints de negocio | `RESEND_API_KEY`, `RESEND_FROM_ADDRESS`, `RESEND_SIMULATION_ENABLED` |
| `capstone-service-ia` | Spring Boot (IA OpenRouter) | `8083` | No expone endpoints de negocio | `OPENROUTER_API_KEY`, `OPENROUTER_MODEL`, `OPENROUTER_SIMULATION_ENABLED` |
| `capstone-frontend` | React SPA (Nginx) | `3000` | Acceso mediante Keycloak Login | `VITE_API_URL`, `VITE_KEYCLOAK_URL` |

Con `docker-compose.vps.yml`, el frontend se publica por HTTPS en el puerto 443 y redirige HTTP del puerto 80. La API, Keycloak, PostgreSQL, RabbitMQ y MinIO quedan ligados a localhost en el VPS; el navegador accede a Keycloak por `/auth` a través de Nginx. En el VPS RackNerd, las credenciales temporales están en `/root/capstone-deployment-credentials.txt`; no se guardan en el repositorio.

---

## 4. Flujos de Datos Transaccionales

### 4.1 Flujo de Autenticación y Autorización (OIDC / JWT)
1. **Frontend**: Al abrir la aplicación, `keycloak.js` exige autenticación y redirige automáticamente a Keycloak (`capstone-client`) mediante Authorization Code + PKCE S256, sin formulario intermedio en React.
2. **Keycloak**: Autentica por correo o nombre de usuario mediante Authorization Code + PKCE y entrega un token JWT con `realm_access.roles`: `ADMIN` para gestión de cuentas y `APPROVER` como usuario operativo general.
3. **Frontend Interceptor**: [`api.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/api.js) adjunta automáticamente el header `Authorization: Bearer <token>` y renueva el token cuando expira.
4. **Backend Security**: [`SecurityConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/auth/SecurityConfig.java) valida el token contra los certificados públicos de Keycloak (`jwk-set-uri`); luego `KeycloakJwtAuthenticationConverter` exige que el `sub` exista en `usuario.keycloak_id` y que la cuenta esté activa antes de convertir roles y aplicar RBAC con `@PreAuthorize`. Una cuenta ausente o inactiva recibe HTTP 401 incluso con JWT vigente.

### 4.2 Flujo de Administración de Usuarios
1. Un usuario con rol `ADMIN` completa el formulario de “Organización y Usuarios”; el frontend envía `POST /api/users` con correo, datos personales, contraseña inicial y roles.
2. `UserManagementService` verifica duplicados, crea la identidad en Keycloak, configura su contraseña y asigna los roles del realm.
3. La cuenta se vincula en PostgreSQL mediante `app_users` y `app_user_roles`. Si falla un paso posterior a la creación remota, se elimina la identidad de Keycloak para evitar estados parciales.
4. `GET /api/users` entrega el listado persistido únicamente a administradores; otros roles reciben HTTP 403.
5. Al iniciar el backend, `ExistingKeycloakUsersSynchronizer` incorpora de forma idempotente las cuentas preexistentes del realm para que el administrador y los usuarios base también estén representados en PostgreSQL.

### 4.3 Flujo de Cierre de Sesión Auditado
1. El usuario selecciona “Cerrar sesión” en React y el cliente renueva el JWT si corresponde.
2. React invoca `POST /api/audit/logout` con el Bearer JWT; `AuditController` exige autenticación y `AuditService` guarda el evento `LOGOUT`, correo, identificador de Keycloak y hora en `audit_events`.
3. El cliente invoca el endpoint de logout OIDC de Keycloak, que finaliza la sesión centralizada y devuelve al navegador a `/login`.
4. Una solicitud posterior sin JWT recibe HTTP 401 desde Spring Security; al cargar React, `login-required` redirige de nuevo al formulario de Keycloak.

### 4.4 Flujo de Carga y Descarga de Documentos
1. **Registro y Upload**: `NuevoDocumentoView` valida título, extensiones `.doc`/`.docx`/`.pdf`/`.xml`/`.txt` y máximo 10 MB; luego envía `titulo`, `descripcion` opcional y `file` como `multipart/form-data` a `POST /api/solicitudes`, mostrando el progreso reportado por Axios.
2. **Catálogo y persistencia**: `DefaultFlowCatalogInitializer` garantiza al arrancar los estados, acciones, formatos y flujo base requeridos. Luego `SolicitudService` almacena el binario mediante `MinioStorageService`, crea `documento` y una `solicitud` en `PENDIENTE_REVISION`, y notifica a los revisores.
3. **Confirmación y descarga**: La respuesta de creación habilita la confirmación visual; `GET /api/solicitudes/{id}/documento/descargar` recupera el archivo vigente.

### 4.5 Flujo Asíncrono de Flujos de Aprobación
1. **Envío de Solicitud**: Usuario o aprobador invoca `POST /api/flow/submit`.
2. **Broker RabbitMQ**: [`FlowController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/FlowController.java) publica el mensaje en el exchange `capstone.exchange` (tipo `topic`):
   - Con routing key `notifications.routingKey` hacia `notifications.queue`.
   - Con routing key `ai.routingKey` hacia `ai.queue`.
3. **Consumo Desacoplado**:
   - [`NotificationQueueListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/consumer/NotificationQueueListener.java) recibe el mensaje y procesa el envío de correos vía Resend API.
   - [`AiTaskListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/consumer/AiTaskListener.java) recibe el mensaje, descarga el documento desde MinIO y consulta a OpenRouter API para auditoría documental.

---

## 5. Guía Rápida para Agentes: Dónde Tocar según la Tarea

| Si tu tarea es... | Archivos directos a modificar / consultar |
| :--- | :--- |
| **Control de roles RBAC / Seguridad JWT** | [`SecurityConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/auth/SecurityConfig.java), [`capstone-realm.json`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/docker/keycloak/capstone-realm.json). |
| **Creación y listado administrativo de usuarios** | `backend/sistema-principal/src/main/java/com/capstone/sistema/users/`, `frontend/src/views/configuracion/ConfigurarOrgUsuariosView.jsx`. |
| **Persistencia de entidades de Base de Datos** | `backend/sistema-principal/src/main/java/com/capstone/sistema/` (crear paquetes `entity` y `repository`), [`application.yml`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/resources/application.yml). |
| **Lógica de negocio y estados de Flujos** | [`FlowController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/FlowController.java), [`RabbitConfig.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/flow/RabbitConfig.java). |
| **Gestor de Documentos o buckets S3** | [`DocController.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/doc/DocController.java), [`MinioStorageService.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/sistema-principal/src/main/java/com/capstone/sistema/doc/MinioStorageService.java). |
| **Consumo de Notificaciones o Resend** | [`NotificationQueueListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/consumer/NotificationQueueListener.java), [`ResendEmailClient.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-notificaciones/src/main/java/com/capstone/notificaciones/client/ResendEmailClient.java). |
| **Consumo de IA o OpenRouter API** | [`AiTaskListener.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/consumer/AiTaskListener.java), [`OpenRouterApiClient.java`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/backend/service-ia/src/main/java/com/capstone/ia/client/OpenRouterApiClient.java). |
| **Vistas y UI del usuario** | `frontend/src/views/` (subcarpetas `acceso`, `configuracion`, `documentos`, `flujos`), [`App.jsx`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/App.jsx). |
| **Clientes API frontend / Tokens** | [`api.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/api.js), [`keycloak.js`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/frontend/src/services/keycloak.js). |
| **Pruebas automatizadas y regresión E2E** | [`tests/e2e/`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/), [`run-e2e-tests.ps1`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/scripts/run-e2e-tests.ps1), [`playwright.config.ts`](file:///c:/Users/Eduardo%20K/Documents/duoc/sistema_capstone/tests/e2e/playwright.config.ts). |

